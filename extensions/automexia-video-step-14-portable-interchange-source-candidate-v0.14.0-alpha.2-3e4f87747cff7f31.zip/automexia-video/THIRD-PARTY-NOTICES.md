# Source-distribution and dependency notes

This source package does **not** bundle FFmpeg/ffprobe, a compiler, model weights,
fonts, editing applications or third-party crate source. Test samples retained
from earlier steps are labelled generated/synthetic in their originating reports.
No source recording was downloaded during Step 11.

## Project license not selected here

The supplied 0.10.1 source had no project license file or Cargo license expression.
This candidate does not invent a copyright holder or select distribution terms on
the owner's behalf. `publish = false` remains in Cargo.toml. Before a public
release, the owner must supply the applicable project license and notices.
A license choice is not resolved by a passing test or a source ZIP checksum.

## Declared dependencies, not an audited transitive inventory

| Dependency | Declaration retained in Cargo.toml | Use |
|---|---|---|
| serde | 1.0, derive | Data models |
| serde_json | 1.0, float_roundtrip | Projects and bounded interchange |
| sha2 | 0.10 | Content identities |
| tempfile | 3.10, optional/native and development | Temporary ownership |
| same-file | 1.0, optional/native | File identity checks |
| fs2 | =0.4.3, optional/native | Model-store advisory filesystem locking |
| nix | 0.29, optional/Unix native | Process-group signals and safe OS flag constants |
| resvg | =0.45.1, optional/graphics | Static SVG/text rasterization |
| image | =0.25.5, PNG/JPEG only | Graphic pixels |
| roxmltree | =0.20.0 | Restricted XML/SVG parsing and tests |
| ttf-parser | =0.25.1, optional/graphics | Explicit font inspection |

These are version expressions, not resolved versions. No Cargo.lock was present,
and the toolchain/network needed to generate one was unavailable in this local
run. After an actual Cargo resolution, retain Cargo.lock and use
`cargo metadata --locked --all-features --format-version 1` to capture exact direct/transitive
versions, sources and declared license metadata. Review the corresponding license
files and any source/binary obligations before distributing that resolved build.

## Runtime arrangement

The initial arrangement remains an **explicitly configured, approved installed
FFmpeg and ffprobe**, not an automatic downloader or bundled runtime. The user/host
chooses their paths. Do not silently fetch codecs, update tools, alter PATH, or
install model packs while processing footage. Record the runtime versions/build
configuration. Codec availability and a distro's runtime license are not a blanket
permission to redistribute every configuration or codec implementation.

Fonts are user-selected inputs; this archive intentionally excludes font files.
Text rendering tests need an explicit VIDEO_TEST_FONT path. Do not copy a system
font into a release to make a test self-contained. Media/graphics used by an actual
user remain that user's inputs, not assets automatically cleared for redistribution.

This is a distribution checklist and factual inventory of the source, not legal
approval of a public release or a complete software bill of materials.

## Step 13 optional source-only speech adapter

`ort` and `ort-sys` =2.0.0-rc.10 are explicit optional Cargo dependencies with default
features disabled and dynamic runtime loading enabled. Generate/review the lockfile
and complete license/notices review for their transitive dependency graph before
distribution. No ONNX Runtime native binary or model weight is bundled here.
The host/component owner must separately review the exact runtime deployment,
model provenance, weight terms and required notices. A manifest's license string
is a declaration, not evidence that distribution rights were granted.

[Exact-asset model procedure](docs/MODEL-PACKS.md) · [API references](docs/STEP-13-SOURCES.md)

## Alpha.5 resolution status

No Cargo.lock or resolved transitive inventory was available in this continuation. [Dependency status](reports/alpha5/dependency-status.json) records declarations and the blocked resolution; `tools/dependency_inventory.py` creates a fresh inventory only after actual successful locked all-feature Cargo metadata. A prior release inventory does not qualify these bytes. `face-onnx` shares the explicitly optional ORT dependency boundary; the RNNoise/whisper.cpp provider source does not bundle selected runtime/model files.
