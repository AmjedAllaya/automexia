# Step 14A preview and interchange implementation notes

Source root: `/workspace/scratch/83af03b3be05/step14/automexia-video`.

Changed production files: `src/preview.rs`, `src/review_workflow.rs`, `src/interchange/build.rs`, `src/interchange/workflow.rs`.

- `ReviewTarget::AssemblyVariant` supports hypothetical approval while preserving original revision, disposition and locks.
- Active variant assembly always uses the complete proposed sequence in review, including ordinary operation previews. Source-window clipping cannot silently drop or reorder repeated occurrences.
- Assembly preview only accepts `PreviewFocus::Whole`; source-time focuses cannot identify a unique repeated occurrence.
- Before plays selected source coverage once, chronologically, at normal speed with processing disabled. Proposed retains every occurrence, its effective speed and resolved processing. The description explicitly discloses these semantics.
- Source-window metadata is a coverage envelope, including possible unplayed gaps. Exact played ranges are the before/proposed timelines. Both complete proxy durations must fit the requested budget (maximum 30 seconds) before host access or staging.
- Proposed assembly projects preserve the original baseline keep list, operation ownership, selected framing/presentation/timing and enhancement metadata. Unused enhanced audio is not inspected when the proposed sequence has no media.
- Normal-speed OTIO, FCP7 XML and CMX3600 EDL preserve reordered/repeated video and matching audio occurrences. Markers independently map to every retained occurrence with unique exported IDs.
- Pending assembly blocks export. Per-entry speed requires explicit visual baking, even if an audio stem is requested.
- Compatibility preflight checks source/output frame boundaries, repeated marker limits, EDL event limits and source/record endpoint timecodes before optional media publication. Explicit CFR baking reserves one frame of final duration-verification tolerance.
- Explicit source splits multiplied by repeated occurrences are capped at `MAX_EXPORT_ITEMS` (8192) before unbounded document construction. Marker expansion is capped at 4096 with early termination.
- Removed a pre-existing reference to the `media` variable before its declaration in the export workflow. The valid source preflight remains after verified media preparation and before audio-stem publication.

Authored regression tests: 26 pure tests in `tests/assembly_preview_export.rs`, two native additions to `tests/native_review.rs`, four native additions to `tests/native_interchange.rs`. Rust tests have not run because Rust is unavailable. They are executable source tests, not claimed results.

Independent source review by `/root/next_build_probe` found the end-timecode preflight gap, now fixed and covered by pure and native no-publication tests. It found no other obvious compilation or A/B semantic defect in the first pass. Final recheck requested.

A correctly retargeted lexical scanner inspected 146 Step14 Rust files with no delimiter, include-path or tracked literal issues. This is not Rust parsing, type checking or compilation.
