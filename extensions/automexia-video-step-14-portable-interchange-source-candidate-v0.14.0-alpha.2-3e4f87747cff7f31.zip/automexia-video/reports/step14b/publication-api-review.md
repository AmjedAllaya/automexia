# Read-only native publication API review

Current source: `step14b/automexia-video`, based on Step 14A alpha.1. No source changes made by this review.

## Reusable existing pieces

- `src/native.rs::private_tempdir`: creates a random job-owned staging directory; Unix permissions are supplied at creation as 0700. Parent may be explicitly supplied so commit stays on one filesystem. TempDir owns cleanup on drop.
- `src/native.rs::open_regular_file`: Unix O_NOFOLLOW | O_NONBLOCK plus regular-file handle metadata, preventing a final-component symlink or FIFO substitution. Parent ownership and non-Unix reparse handling remain host responsibilities.
- `src/native.rs::fingerprint`: cancellation-aware 64 KiB streaming SHA256 with byte cap; checks initial/final open-handle and final path identity. Returns size, mtime, SHA256, device/inode where available. Prefer streaming copy with simultaneous SHA256 and source revalidation to whole-media allocation.
- `src/native.rs::read_selected_bytes`: cancellation-aware bounded in-memory reads appropriate for project/manifests and small graphics, explicitly not bulk-media hashing.
- `MediaHost::stage_output` and `OutputLease`: private single-file lease, input and destination revalidation, file sync, CreateNew via persist_noclobber, ReplaceReviewed stamp check then persist; commit is final publication; post-commit directory sync is best effort and cannot turn committed output into ordinary failure.
- `NativeMediaHost::publish_interchange`: validates document extension/size, canonical destination parent, protected project/source/asset aliases, all referenced media identities; verifies staged document bytes before lease commit.
- `ProjectStore::save_project`: bounded staged JSON, source/asset destination guards, source-relative path base checks, CreateNew or exact reviewed replacement; no fallible operation after commit.
- `native_model_store.rs::write_owned_file` pattern: create_new, Unix 0600, bounded chunk writes and file sync. `canonical_directory` pattern rejects traversal, symlinks and noncanonical parents. These helpers are private, but their patterns are useful.

## Important limits for portable bundles

1. There is no existing public directory lease or general atomic no-clobber directory publication primitive. Do not represent repeated single-file OutputLease commits as an atomic multi-file bundle.
2. Model-pack directory publication uses plain fs::rename only within a protected private model store held under an exclusive OS lock. Its assumptions do not transfer to a user-selected arbitrary export directory: on Unix a late empty destination directory could be replaced by rename.
3. A user-directory implementation needs a race-safe no-replace directory commit supported by its platform, or an explicitly narrower supported platform contract that returns Unsupported before copying on unsupported systems. Plain exists-check followed by rename is not no-clobber.
4. Stage all documents/media beneath one same-filesystem private parent, validate the complete file set and every content identity, then perform exactly one commit. Files with content-identical hashes may share one physical copy only if manifest references remain deterministic and all selected original inputs are revalidated.
5. Bundle paths should be generated portable relative names, with deterministic collision handling and traversal/reserved-name rules. Do not let serialized paths control arbitrary local reads or writes. A bundle import/verification path must not accept unmanifested symlinks or missing/inconsistent sizes/hashes.
6. Keep pre-commit failure/cancellation cleanup restricted to owned staging. A successful commit is success even if subsequent cancellation or optional read-back fails; report PublishedUnverified separately if the API elects read-back.
7. Current independent native adapter is not the host permission broker. No new filesystem feature should imply it grants access to arbitrary paths.

## Build evidence

`environment.json` records no Rust/Cargo found in PATH or ten bounded standard/runtime locations, FFmpeg and ffprobe 6.1.1-3ubuntu5, Python 3.12.14, GCC 13.3.0. No compiler installation or network retry was attempted; current environment matches prior probe. Native media paths retain their documented FFmpeg/ffprobe >= 7.1 runtime gate.
