# Original combined execution record

This directory retains the original combined qualification output. Subsequent delivery verification found four persisted files did not match the hashes captured by the runner: media-color.log, media-color.json, media-speech.log and media-hdr.log. The color report retained an earlier in-progress snapshot. The cause is not established, and these files have not been silently corrected.

See [the focused recovery record](../evidence-recovery/recovery.json) for fresh synchronous color/speech/HDR runs with the same source identity. [The reconciled record](../qualification-reconciled.json) explicitly selects those verified reruns and retains the other original checks. It is not represented as another single combined run.
