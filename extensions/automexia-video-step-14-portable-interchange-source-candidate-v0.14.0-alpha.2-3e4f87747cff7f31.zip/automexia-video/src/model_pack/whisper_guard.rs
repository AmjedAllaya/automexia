//! Bounded structural validation for the legacy embedded whisper.cpp GGML format.
//! This is not a proof of model quality or a native-code sandbox. Quantized/GGUF,
//! large models, external tensors and alternate frontend contracts are rejected.
use crate::{Cancellation,Error,Result};
use std::collections::BTreeSet;

pub fn check_whisper_ggml(bytes:&[u8],cancel:&Cancellation)->Result<()> {
    cancel.check()?;
    if bytes.len()>160*1024*1024 {return Err(Error::LimitExceeded("whisper model bytes"));}
    let mut reader=Reader{bytes,offset:0,cancel};
    if reader.u32()?!=0x67676d6c {return Err(Error::Unsupported("whisper requires legacy embedded GGML magic"));}
    let mut h=[0u32;11];for item in &mut h {*item=reader.u32()?;}
    let (vocab,audio_ctx,state,heads,layers,text_ctx,text_state,text_heads,text_layers,mels,ftype)=
        (h[0],h[1],h[2],h[3],h[4],h[5],h[6],h[7],h[8],h[9],h[10]);
    if !matches!(vocab,51864|51865) || audio_ctx!=1500 || text_ctx!=448 || mels!=80
        || !matches!((state,heads,layers),(384,6,4)|(512,8,6))
        || (text_state,text_heads,text_layers)!=(state,heads,layers) || !matches!(ftype,0|1) {
        return Err(Error::Unsupported("whisper supports unquantized tiny/base 80-mel GGML only"));
    }
    if reader.u32()?!=80 || reader.u32()?!=201 {return Err(Error::Unsupported("whisper mel filter dimensions"));}
    for _ in 0..80*201 {if !f32::from_bits(reader.u32()?).is_finite(){return Err(Error::InvalidInput("whisper mel filter coefficient"));}}
    // Legacy conversion files may omit the synthetic special/language/timestamp
    // vocabulary: whisper.cpp reconstructs it from hparams.n_vocab. Accept the
    // known base-token counts as well as a fully embedded vocabulary.
    let stored_vocab=reader.u32()?;
    if !((vocab==51864&&matches!(stored_vocab,50256|50257|51864))
        ||(vocab==51865&&matches!(stored_vocab,50257|51865))) {
        return Err(Error::InvalidInput("whisper embedded vocabulary count"));
    }
    let mut vocabulary_bytes=0usize;
    for _ in 0..stored_vocab {
        let n=reader.u32()? as usize;
        if n>4096 {return Err(Error::LimitExceeded("whisper vocabulary token"));}
        vocabulary_bytes=vocabulary_bytes.checked_add(n).ok_or(Error::LimitExceeded("whisper vocabulary"))?;
        if vocabulary_bytes>4*1024*1024 {return Err(Error::LimitExceeded("whisper vocabulary bytes"));}
        reader.take(n)?;
    }
    let mut names=BTreeSet::new();
    let mut required=BTreeSet::new();
    while reader.offset<bytes.len() {
        cancel.check()?;
        let dimensions=reader.u32()? as usize;let name_length=reader.u32()? as usize;let kind=reader.u32()?;
        if !(1..=3).contains(&dimensions)||name_length==0||name_length>256||names.len()>=1024 {
            return Err(Error::LimitExceeded("whisper tensor header"));
        }
        let item_bytes=match kind {0=>4usize,1=>2usize,_=>return Err(Error::Unsupported("quantized whisper tensor"))};
        let mut shape=Vec::with_capacity(dimensions);let mut size=item_bytes;
        for _ in 0..dimensions {let n=reader.u32()?;
            if n==0||n>51865 {return Err(Error::InvalidInput("whisper tensor shape"));}
            size=size.checked_mul(n as usize).ok_or(Error::LimitExceeded("whisper tensor size"))?;shape.push(n);
        }
        let name=std::str::from_utf8(reader.take(name_length)?).map_err(|_|Error::InvalidInput("whisper tensor name UTF-8"))?;
        if !name.bytes().all(|b|b.is_ascii_alphanumeric()||b"._".contains(&b))||!names.insert(name) {
            return Err(Error::InvalidInput("whisper tensor name duplicate or invalid"));
        }
        let expected:Option<Vec<u32>>=match name {
            "encoder.conv1.weight"=>Some(vec![3,80,state]),
            "encoder.conv2.weight"=>Some(vec![3,state,state]),
            "decoder.token_embedding.weight"=>Some(vec![state,vocab]),
            "encoder.positional_embedding"=>Some(vec![state,1500]),
            "decoder.positional_embedding"=>Some(vec![state,448]),
            _=>None,
        };
        if let Some(expected)=expected {if shape!=expected {return Err(Error::InvalidInput("whisper essential tensor shape"));}required.insert(name);}
        reader.take(size)?;
    }
    if required.len()!=5 || names.len()<100 {return Err(Error::InvalidInput("whisper model is missing tensors"));}
    cancel.check()
}
struct Reader<'a>{bytes:&'a[u8],offset:usize,cancel:&'a Cancellation}
impl<'a> Reader<'a> {
    fn take(&mut self,n:usize)->Result<&'a[u8]> {
        self.cancel.check()?;
        let end=self.offset.checked_add(n).filter(|end|*end<=self.bytes.len()).ok_or(Error::InvalidInput("truncated whisper model"))?;
        let result=&self.bytes[self.offset..end];self.offset=end;Ok(result)
    }
    fn u32(&mut self)->Result<u32> {Ok(u32::from_le_bytes(self.take(4)?.try_into().map_err(|_|Error::InvalidInput("whisper integer"))?))}
}
#[cfg(test)]
mod tests {
    use super::*;
    fn header(state:u32,head:u32,layer:u32)->Vec<u8>{[0x67676d6c,51864,1500,state,head,layer,448,state,head,layer,80,1].into_iter().flat_map(u32::to_le_bytes).collect()}
    #[test]fn empty_and_truncated_are_rejected(){for bytes in [&[][..],&[0x6c,0x6d,0x67,0x67][..]]{assert!(check_whisper_ggml(bytes,&Cancellation::new()).is_err());}}
    #[test]fn large_model_header_is_rejected(){assert!(matches!(check_whisper_ggml(&header(1024,16,24),&Cancellation::new()),Err(Error::Unsupported(_))));}
    #[test]fn gguf_is_not_misread_as_ggml(){assert!(check_whisper_ggml(b"GGUF\0\0\0\0",&Cancellation::new()).is_err());}
    #[test]fn cancelled_validation_is_immediate(){let c=Cancellation::new();c.cancel();assert_eq!(check_whisper_ggml(&header(384,6,4),&c),Err(Error::Cancelled));}
    #[test]fn tiny_header_needs_remaining_tensors(){assert!(matches!(check_whisper_ggml(&header(384,6,4),&Cancellation::new()),Err(Error::InvalidInput(_))));}
    #[test]fn quantized_header_is_rejected(){let mut h=header(384,6,4);h[44..48].copy_from_slice(&2u32.to_le_bytes());assert!(matches!(check_whisper_ggml(&h,&Cancellation::new()),Err(Error::Unsupported(_))));}
}
