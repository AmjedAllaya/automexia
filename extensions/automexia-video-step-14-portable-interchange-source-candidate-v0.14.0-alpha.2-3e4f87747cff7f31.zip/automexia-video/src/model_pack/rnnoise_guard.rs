//! Strict bounded parser for the standard RNNoise text topology consumed by
//! FFmpeg's arnndn adapter. Verifying a model is not a quality certification.
use crate::{Cancellation, Error, Result};

pub fn check_rnnoise_model(bytes: &[u8], cancel: &Cancellation) -> Result<()> {
    cancel.check()?;
    if bytes.is_empty() || bytes.len() > super::MODEL_BYTES_LIMIT {
        return Err(Error::LimitExceeded("RNNoise model bytes"));
    }
    let text = std::str::from_utf8(bytes)
        .map_err(|_| Error::InvalidInput("RNNoise model must be ASCII text"))?;
    if !text.is_ascii() || text.bytes().any(|b| b.is_ascii_control() && !b.is_ascii_whitespace()) {
        return Err(Error::InvalidInput("RNNoise model text"));
    }
    let mut lines = text.lines();
    if lines.next() != Some("rnnoise-nu model file version 1") {
        return Err(Error::Unsupported("RNNoise text model version"));
    }
    // Admit one known topology rather than allowing arbitrary neural graph
    // dimensions to enter the native parser. Each array occupies its own line.
    for (input, output, recurrent) in [
        (42usize, 24usize, false), (24, 24, true), (90, 48, true),
        (114, 96, true), (96, 22, false), (24, 1, false),
    ] {
        cancel.check()?;
        let header = lines.next().ok_or(Error::InvalidInput("RNNoise missing layer"))?;
        let dims: Vec<_> = header.split_ascii_whitespace().collect();
        if dims.len() != 3 || dims[0].parse::<usize>().ok() != Some(input)
            || dims[1].parse::<usize>().ok() != Some(output)
            || !matches!(dims[2].parse::<u8>(), Ok(0..=2)) {
            return Err(Error::Unsupported("RNNoise standard layer topology"));
        }
        let multiplicity = if recurrent { 3 } else { 1 };
        let mut counts = vec![input * output * multiplicity];
        if recurrent { counts.push(output * output * 3); }
        counts.push(output * multiplicity);
        for expected in counts {
            let array = lines.next().ok_or(Error::InvalidInput("RNNoise missing weight array"))?;
            let mut count = 0usize;
            for value in array.split_ascii_whitespace() {
                if count % 4096 == 0 { cancel.check()?; }
                if count >= expected || value.len() > 4 || value.parse::<i8>().is_err() {
                    return Err(Error::InvalidInput("RNNoise weight value/count"));
                }
                count += 1;
            }
            if count != expected { return Err(Error::InvalidInput("RNNoise truncated weight array")); }
        }
    }
    if lines.any(|line| !line.trim().is_empty()) {
        return Err(Error::InvalidInput("RNNoise trailing model data"));
    }
    cancel.check()
}

#[cfg(test)]
mod tests {
    use super::*;
    fn fixture() -> String {
        let mut text = String::from("rnnoise-nu model file version 1\n");
        for (input, output, recurrent) in [(42,24,false),(24,24,true),(90,48,true),(114,96,true),(96,22,false),(24,1,false)] {
            text.push_str(&format!("{input} {output} 0\n"));
            let factor=if recurrent {3}else{1};
            for n in std::iter::once(input*output*factor).chain(if recurrent {Some(output*output*3)}else{None}).chain(std::iter::once(output*factor)) {
                text.push_str(&"0 ".repeat(n));text.push('\n');
            }
        }
        text
    }
    #[test] fn accepts_complete_standard_topology() {check_rnnoise_model(fixture().as_bytes(),&Cancellation::new()).unwrap();}
    #[test] fn rejects_foreign_topology() {assert!(check_rnnoise_model(fixture().replacen("42 24 0","42 25 0",1).as_bytes(),&Cancellation::new()).is_err());}
    #[test] fn rejects_truncated_and_extra_weights() {let f=fixture();let extra=format!("{f}0\n");for s in [&f[..f.len()/2],extra.as_str()] {assert!(check_rnnoise_model(s.as_bytes(),&Cancellation::new()).is_err());}}
    #[test] fn rejects_out_of_range_weight() {let f=fixture().replacen("\n0 ","\n128 ",1);assert!(check_rnnoise_model(f.as_bytes(),&Cancellation::new()).is_err());}
    #[test] fn observes_revocation() {let c=Cancellation::new();c.cancel();assert_eq!(check_rnnoise_model(fixture().as_bytes(),&c),Err(Error::Cancelled));}
}
