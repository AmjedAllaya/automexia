//! Minimal, bounded protobuf traversal of ONNX file-reference surfaces.
//! This is not a tensor evaluator, model-quality check or OS sandbox.
use crate::{Cancellation, Error, Result};
const MAX_FIELDS: usize = 1_000_000;
const MAX_DEPTH: usize = 24;
struct Reader<'a> { data: &'a [u8], at: usize }
impl<'a> Reader<'a> {
    fn varint(&mut self) -> Result<u64> {
        let mut n=0u64;
        for i in 0..10 {
            let b=*self.data.get(self.at).ok_or(Error::InvalidInput("truncated ONNX varint"))?;
            self.at+=1;
            if i==9 && b>1 { return Err(Error::InvalidInput("ONNX varint overflow")); }
            n |= u64::from(b & 127) << (7*i);
            if b & 128 == 0 { return Ok(n); }
        }
        Err(Error::InvalidInput("ONNX varint overflow"))
    }
    fn take(&mut self, n:usize)->Result<&'a [u8]> {
        let end=self.at.checked_add(n).ok_or(Error::LimitExceeded("ONNX field bytes"))?;
        let v=self.data.get(self.at..end).ok_or(Error::InvalidInput("truncated ONNX field"))?;
        self.at=end;Ok(v)
    }
}
#[derive(Clone,Copy)] enum Message { Model, Graph, Node, Attribute, Tensor, Opset }
pub fn check_embedded_onnx(bytes:&[u8],cancel:&Cancellation)->Result<()> {
    if bytes.is_empty() || bytes.len()>super::MODEL_BYTES_LIMIT { return Err(Error::LimitExceeded("ONNX bytes")); }
    let mut count=0;
    visit(bytes,Message::Model,0,&mut count,cancel)
}
fn visit(bytes:&[u8],kind:Message,depth:usize,count:&mut usize,cancel:&Cancellation)->Result<()> {
    if depth>MAX_DEPTH {return Err(Error::LimitExceeded("ONNX graph depth"));}
    let mut r=Reader{data:bytes,at:0};let mut graph_count=0;let mut ir=false;
    while r.at<r.data.len() {
        *count+=1;if *count>MAX_FIELDS{return Err(Error::LimitExceeded("ONNX field count"));}
        if *count%256==0{cancel.check()?;}
        let key=r.varint()?;let field=key>>3;let wire=key&7;
        if field==0||field>536_870_911{return Err(Error::InvalidInput("ONNX field key"));}
        let mut scalar=None;let mut data=None;
        match wire {
            0=>scalar=Some(r.varint()?),1=>{r.take(8)?;},
            2=>{let n=usize::try_from(r.varint()?).map_err(|_|Error::LimitExceeded("ONNX length"))?;data=Some(r.take(n)?);},
            5=>{r.take(4)?;},_=>return Err(Error::InvalidInput("unsupported ONNX wire type")),
        }
        let child=match (kind,field) {
            (Message::Model,1)=>{if scalar.is_none(){return Err(Error::InvalidInput("ONNX IR wire type"));}ir=true;None},
            (Message::Model,7)=>{graph_count+=1;Some(Message::Graph)},
            (Message::Model,8)=>Some(Message::Opset),
            (Message::Model,20|25)=>return Err(Error::Unsupported("ONNX training graphs/local functions")),
            (Message::Graph,1)=>Some(Message::Node),
            (Message::Graph,5)=>Some(Message::Tensor),
            (Message::Graph,15)=>return Err(Error::Unsupported("sparse ONNX initializers")),
            (Message::Node,5)=>Some(Message::Attribute),
            (Message::Node,7)|(Message::Opset,1)=>{
                let s=data.ok_or(Error::InvalidInput("ONNX domain wire type"))?;
                if s!=b"" && s!=b"ai.onnx"{return Err(Error::Unsupported("custom ONNX domain"));}None
            },
            (Message::Attribute,5|10)=>Some(Message::Tensor),
            (Message::Attribute,6|11)=>Some(Message::Graph),
            (Message::Attribute,22|23)=>return Err(Error::Unsupported("sparse ONNX attributes")),
            (Message::Tensor,13)=>return Err(Error::Unsupported("external ONNX tensor data")),
            (Message::Tensor,14)=>{
                if scalar!=Some(0){return Err(Error::Unsupported("external ONNX data location"));}None
            },
            _=>None,
        };
        if let Some(child)=child {
            visit(data.ok_or(Error::InvalidInput("ONNX message wire type"))?,child,depth+1,count,cancel)?;
        }
    }
    cancel.check()?;
    if matches!(kind,Message::Model)&&(!ir||graph_count!=1){return Err(Error::InvalidInput("ONNX requires one graph and an IR version"));}
    Ok(())
}
