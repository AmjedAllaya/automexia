//! Step-8 API helpers. Media rendering uses the existing render_project and
//! preview_edit entry points. No separate application, scheduler or renderer UI.
use crate::{Cancellation,Error,Result,VideoExtension};
use crate::host::{MediaHost,OutputPolicy};
use crate::project::Project;
use crate::subtitles::SubtitleFormat;
use serde::Serialize;
use std::path::{Path,PathBuf};
#[derive(Debug,Clone,Serialize)]
pub struct SubtitleExport {pub output:PathBuf,pub cue_parts:usize,pub source_cues:usize,pub warnings:Vec<String>}
impl<H:MediaHost> VideoExtension<H> {
    /// User selected the supplied subtitle bytes; this parser does no I/O and
    /// starts no tool. A host may use its existing file picker/asset access owner.
    pub fn import_subtitles(&self,bytes:&[u8],format:SubtitleFormat)->Result<crate::subtitles::SubtitleDocument>{
        let _job=self.begin(&Cancellation::new())?;crate::subtitles::SubtitleDocument::parse(bytes,format)
    }
    /// Explicit sidecar publication. No automatic extra output during rendering.
    /// The host receives bounded text only after edit/presentation review gates.
    pub fn export_subtitles(&self,project:&Project,variant:&str,project_file:&Path,destination:&Path,format:SubtitleFormat,policy:&OutputPolicy,cancel:&Cancellation)->Result<SubtitleExport>{
        project.validate()?;
        let profile=project.variant(variant)?.presentation.as_ref().ok_or(Error::InvalidProject("variant has no supplied captions"))?;
        profile.ensure_resolved()?;if !profile.active(){return Err(Error::InvalidInput("presentation is disabled"));}
        let captions=profile.captions.as_ref().ok_or(Error::InvalidProject("variant has no supplied captions"))?;
        let expected=if format==SubtitleFormat::Srt{"srt"}else{"vtt"};
        if !destination.is_absolute()||!destination.extension().and_then(|s|s.to_str()).is_some_and(|s|s.eq_ignore_ascii_case(expected)){return Err(Error::InvalidInput("absolute matching subtitle sidecar path"));}
        let edit=crate::edit_render::EditRender::from_variant(project,variant)?;
        let timeline=crate::presentation_render::effective_timeline(&edit)?;
        let prepared=captions.document.for_timeline(&timeline,&project.sources[0].id)?;
        let cues=prepared.remap(&timeline,&project.sources[0].id)?;
        let bytes=crate::subtitles::sidecar(&cues,format)?;
        let job=self.begin(cancel)?;let source=&project.sources[0];let input=self.host().inspect_input(&source.resolve(project_file)?,&job.cancel)?;source.check_input(&input)?;
        let mut protected=vec![project_file.to_owned()];for s in &project.sources{protected.push(s.resolve(project_file)?);}
        for v in &project.variants{if let Some(p)=&v.presentation{for a in p.all_asset_refs(){protected.push(a.resolve(project_file)?);}}}
        if let Some(enhancement)=&project.settings.voice_enhancement{protected.push(enhancement.resolve(project_file)?);}
        protected.sort();protected.dedup();
        if protected.len()>256{return Err(Error::LimitExceeded("sidecar protected paths"));}
        let output=self.host().publish_subtitles(&input,&protected,destination,policy,&bytes,&job.cancel)?;
        Ok(SubtitleExport{output,cue_parts:cues.len(),source_cues:captions.document.cues.len(),warnings:vec!["Sidecar timestamps quantize outward to milliseconds; burned-in composition uses the render microsecond clock.".into(),"Plain-text subset only; no WebVTT styling or sidecar font guarantee.".into(),"Repeated ranges emit a caption for each output occurrence. Generated captions split at all retained source boundaries, consistently with burn-in.".into()]})
    }
}
