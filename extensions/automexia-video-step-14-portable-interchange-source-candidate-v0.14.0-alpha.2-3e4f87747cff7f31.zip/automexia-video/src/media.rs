use crate::{Error, Result, Rational};
use serde::{Deserialize, Serialize};
use serde_json::{Value, Map};
use std::collections::{BTreeMap, BTreeSet};

pub const MAX_PROBE_BYTES: usize = 8 * 1024 * 1024;
pub const MAX_STREAMS: usize = 64;
pub const MAX_HEAD_PACKETS: usize = 64;

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct StreamInfo {
    pub index: u32,
    pub kind: String,
    pub codec: Option<String>,
    pub time_base: Option<Rational>,
    pub start_pts: Option<i64>,
    pub duration_ts: Option<i64>,
    pub start_time: Option<Rational>,
    pub duration: Option<Rational>,
    pub average_frame_rate: Option<Rational>,
    pub nominal_frame_rate: Option<Rational>,
    pub width: Option<u32>,
    pub height: Option<u32>,
    pub sample_aspect_ratio: Option<Rational>,
    pub pixel_format: Option<String>,
    pub bits_per_raw_sample: Option<u32>,
    pub field_order: Option<String>,
    pub color_range: Option<String>,
    pub color_space: Option<String>,
    pub color_transfer: Option<String>,
    pub color_primaries: Option<String>,
    pub sample_rate: Option<u32>,
    pub channels: Option<u32>,
    pub channel_layout: Option<String>,
    pub initial_padding: Option<u32>,
    pub trailing_padding: Option<u32>,
    pub disposition: BTreeMap<String, bool>,
    pub tags: BTreeMap<String, String>,
    pub side_data: Vec<Value>,
}
impl StreamInfo {
    pub fn is_default(&self)->bool{self.disposition.get("default").copied().unwrap_or(false)}
    pub fn is_attached_picture(&self)->bool{self.disposition.get("attached_pic").copied().unwrap_or(false)}
    pub fn exact_start(&self)->Option<Rational>{
        self.time_base.zip(self.start_pts).and_then(|(t,p)|t.ticks(p).ok()).or(self.start_time)
    }
    pub fn exact_duration(&self)->Option<Rational>{
        self.time_base.zip(self.duration_ts).and_then(|(t,p)|t.ticks(p).ok()).or(self.duration)
    }
    /// Metadata rates alone do not establish whether a stream is constant-rate.
    pub fn frame_rate_evidence(&self)->&'static str {
        match (self.average_frame_rate, self.nominal_frame_rate) {
            (Some(a),Some(n)) if a != n => "possibly_variable_not_proven",
            (Some(_),_) | (_,Some(_)) => "metadata_only_not_proven_constant",
            _ => "unknown",
        }
    }
    /// Only orthogonal, non-mirrored display transforms are admitted for rendering.
    pub fn rotation_degrees(&self)->Result<i32>{
        let mut found=None;
        for side in &self.side_data {
            if side.get("side_data_type").and_then(Value::as_str)!=Some("Display Matrix"){continue;}
            let rotation=number_text(side.get("rotation")).map(|s|s.parse::<Rational>()).transpose()
                .map_err(|_|Error::Unsupported("non-orthogonal rotation"))?.unwrap_or(Rational::new(0,1)?);
            if rotation.denominator()!=1 || rotation.numerator()%90!=0 {
                return Err(Error::Unsupported("non-orthogonal rotation"));
            }
            let angle=rotation.numerator().rem_euclid(360) as i32;
            if let Some(matrix)=side.get("displaymatrix").and_then(Value::as_str) {
                let cells: Vec<i64>=matrix.lines().filter_map(|l|l.split_once(':').map(|(_,r)|r))
                    .flat_map(str::split_whitespace).map(str::parse).collect::<std::result::Result<_,_>>()
                    .map_err(|_|Error::Unsupported("unrecognized display matrix"))?;
                if cells.len()!=9 || cells[2]!=0 || cells[5]!=0 || cells[6]!=0 || cells[7]!=0 || cells[8]!=1_073_741_824 {
                    return Err(Error::Unsupported("translated, sheared or perspective display matrix"));
                }
                let m=[cells[0],cells[1],cells[3],cells[4]];
                if ![[65536,0,0,65536],[-65536,0,0,-65536],[0,-65536,65536,0],[0,65536,-65536,0]].contains(&m) {
                    return Err(Error::Unsupported("mirrored or scaled display matrix"));
                }
                if (angle%180!=0)!=(cells[0]==0) {return Err(Error::InvalidProbe("inconsistent rotation matrix"));}
            }
            if found.is_some(){return Err(Error::InvalidProbe("multiple display matrices"));}
            found=Some(angle);
        }
        if let Some(angle)=found {return Ok(angle);}
        if let Some(tag)=self.tags.get("rotate") {
            let angle: i32=tag.parse().map_err(|_|Error::Unsupported("rotation tag"))?;
            if angle%90!=0{return Err(Error::Unsupported("non-orthogonal rotation"));}
            return Ok(angle.rem_euclid(360));
        }
        Ok(0)
    }
}
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PacketTiming {
    pub stream_index: u32,
    pub pts: Option<i64>,
    pub dts: Option<i64>,
    pub duration: Option<i64>,
    /// Includes first-packet Skip Samples information when the demuxer exposes it.
    pub side_data: Vec<Value>,
}
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MediaInfo {
    pub format_names: Vec<String>,
    pub start_time: Option<Rational>,
    pub duration: Option<Rational>,
    pub streams: Vec<StreamInfo>,
    pub head_packets: Vec<PacketTiming>,
    pub tags: BTreeMap<String,String>,
    /// Bounded original JSON retained without losing unmodelled timing/color fields.
    pub raw: Value,
}
#[derive(Debug,Clone,Copy,Default,Serialize,Deserialize)]
#[serde(tag="mode",content="index",rename_all="snake_case")]
pub enum VideoSelection { #[default] Auto, Index(u32) }
#[derive(Debug,Clone,Copy,Default,Serialize,Deserialize)]
#[serde(tag="mode",content="index",rename_all="snake_case")]
pub enum AudioSelection { #[default] Auto, Index(u32), None }
#[derive(Debug,Clone,Copy,Default,Serialize,Deserialize)]
#[serde(default,deny_unknown_fields)]
pub struct StreamSelection {pub video:VideoSelection,pub audio:AudioSelection}
#[derive(Debug,Clone,Copy,PartialEq,Eq,Serialize,Deserialize)]
pub struct SelectedStreams {pub video:u32,pub audio:Option<u32>}
impl MediaInfo {
    pub fn stream(&self,index:u32)->Result<&StreamInfo>{self.streams.iter().find(|s|s.index==index).ok_or(Error::MissingStream(index))}
    pub fn select(&self,selection:StreamSelection)->Result<SelectedStreams>{
        let videos:Vec<_>=self.streams.iter().filter(|s|s.kind=="video"&&!s.is_attached_picture()).collect();
        let audios:Vec<_>=self.streams.iter().filter(|s|s.kind=="audio").collect();
        let video=match selection.video {
            VideoSelection::Index(i)=>*videos.iter().find(|s|s.index==i).ok_or(Error::MissingStream(i))?,
            VideoSelection::Auto=>choose(&videos,"video")?.ok_or(Error::Unsupported("input contains no video stream"))?,
        };
        let audio=match selection.audio {
            AudioSelection::None=>None,
            AudioSelection::Index(i)=>Some(*audios.iter().find(|s|s.index==i).ok_or(Error::MissingStream(i))?),
            AudioSelection::Auto=>choose(&audios,"audio")?,
        };
        Ok(SelectedStreams{video:video.index,audio:audio.map(|s|s.index)})
    }
}
fn choose<'a>(streams:&[&'a StreamInfo],kind:&'static str)->Result<Option<&'a StreamInfo>>{
    if streams.is_empty(){return Ok(None);} if streams.len()==1{return Ok(Some(streams[0]));}
    let defaults:Vec<_>=streams.iter().filter(|s|s.is_default()).collect();
    if defaults.len()==1 {Ok(Some(*defaults[0]))} else {Err(Error::AmbiguousStream(kind))}
}

/// Parse bounded ffprobe JSON, keeping exact integer time bases and raw metadata.
/// `-show_packets -read_intervals %+#64` supplies a bounded head sample; it is NOT
/// a complete VFR/corruption scan. Full decoding is a separate validation task.
pub fn parse_probe(bytes:&[u8])->Result<MediaInfo>{
    if bytes.len()>MAX_PROBE_BYTES{return Err(Error::LimitExceeded("probe bytes"));}
    let raw:Value=serde_json::from_slice(bytes).map_err(|_|Error::InvalidProbe("JSON"))?;
    let mut nodes=0; check_tree(&raw,0,&mut nodes)?;
    let root=raw.as_object().ok_or(Error::InvalidProbe("root object"))?;
    if root.contains_key("error"){return Err(Error::InvalidProbe("ffprobe reported an error"));}
    let items=root.get("streams").and_then(Value::as_array).ok_or(Error::InvalidProbe("streams"))?;
    if items.is_empty()||items.len()>MAX_STREAMS{return Err(Error::LimitExceeded("stream count"));}
    let mut streams=Vec::new();let mut seen=BTreeSet::new();
    for item in items {
        let o=item.as_object().ok_or(Error::InvalidProbe("stream object"))?;
        let index=u32_field(o,"index")?.ok_or(Error::InvalidProbe("stream index"))?;
        if !seen.insert(index){return Err(Error::InvalidProbe("duplicate stream index"));}
        let kind=text(o,"codec_type")?.ok_or(Error::InvalidProbe("stream type"))?;
        let time_base=rational(o,"time_base")?;
        if time_base.is_some_and(|t|!t.positive()){return Err(Error::InvalidProbe("nonpositive time base"));}
        let disposition=match o.get("disposition") {
            None=>BTreeMap::new(), Some(Value::Object(m))=>m.iter().map(|(k,v)|{
                match v.as_i64(){Some(0)=>Ok((k.clone(),false)),Some(1)=>Ok((k.clone(),true)),_=>Err(Error::InvalidProbe("disposition"))}
            }).collect::<Result<_>>()?,_=>return Err(Error::InvalidProbe("disposition object")),
        };
        let sar=match text(o,"sample_aspect_ratio")? {
            None=>None,Some(s) if s=="0:1"||s=="0/1"=>None,
            Some(s)=>Some(s.replace(':',"/").parse::<Rational>().map_err(|_|Error::InvalidProbe("sample aspect ratio"))?),
        };
        streams.push(StreamInfo {
            index,kind,codec:text(o,"codec_name")?,time_base,
            start_pts:i64_field(o,"start_pts")?,duration_ts:i64_field(o,"duration_ts")?,
            start_time:rational(o,"start_time")?,duration:rational(o,"duration")?,
            average_frame_rate:rate(o,"avg_frame_rate")?,nominal_frame_rate:rate(o,"r_frame_rate")?,
            width:u32_field(o,"width")?,height:u32_field(o,"height")?,sample_aspect_ratio:sar,
            pixel_format:text(o,"pix_fmt")?,bits_per_raw_sample:u32_field(o,"bits_per_raw_sample")?,field_order:text(o,"field_order")?,
            color_range:text(o,"color_range")?,color_space:text(o,"color_space")?,
            color_transfer:text(o,"color_transfer")?,color_primaries:text(o,"color_primaries")?,
            sample_rate:u32_field(o,"sample_rate")?,channels:u32_field(o,"channels")?,channel_layout:text(o,"channel_layout")?,
            initial_padding:u32_field(o,"initial_padding")?,trailing_padding:u32_field(o,"trailing_padding")?,
            disposition,tags:tags(o)?,side_data:side_data(o)?,
        });
    }
    for stream in &streams {
        if let Some(t)=stream.time_base {
            if let Some(pts)=stream.start_pts {t.ticks(pts).map_err(|_|Error::InvalidProbe("start timestamp overflow"))?;}
            if let Some(ticks)=stream.duration_ts {if ticks<0{return Err(Error::InvalidProbe("negative stream duration"));}t.ticks(ticks).map_err(|_|Error::InvalidProbe("duration overflow"))?;}
        }
        if stream.duration.is_some_and(|t|t.numerator()<0){return Err(Error::InvalidProbe("negative stream duration"));}
    }
    let format=root.get("format").and_then(Value::as_object).ok_or(Error::InvalidProbe("format"))?;
    let format_names=text(format,"format_name")?.ok_or(Error::InvalidProbe("format name"))?.split(',').map(str::to_owned).collect();
    let packets=match root.get("packets"){None=>&[][..],Some(Value::Array(a))=>a.as_slice(),_=>return Err(Error::InvalidProbe("packets array"))};
    if packets.len()>MAX_HEAD_PACKETS{return Err(Error::LimitExceeded("head packet count"));}
    let mut head_packets=Vec::new();
    for p in packets {
        let p=p.as_object().ok_or(Error::InvalidProbe("packet"))?;
        let index=u32_field(p,"stream_index")?.ok_or(Error::InvalidProbe("packet stream index"))?;
        if !seen.contains(&index){return Err(Error::InvalidProbe("unknown packet stream"));}
        head_packets.push(PacketTiming {stream_index:index,pts:i64_field(p,"pts")?,dts:i64_field(p,"dts")?,duration:i64_field(p,"duration")?,side_data:side_data(p)?});
    }
    Ok(MediaInfo{format_names,start_time:rational(format,"start_time")?,duration:rational(format,"duration")?,
        streams,head_packets,tags:tags(format)?,raw})
}
fn check_tree(v:&Value,depth:usize,nodes:&mut usize)->Result<()> {
    *nodes+=1;if depth>32||*nodes>100_000{return Err(Error::LimitExceeded("probe structure"));}
    match v {
        Value::String(s) if s.len()>16_384=>return Err(Error::LimitExceeded("probe string")),
        Value::Object(o)=>for (k,v) in o {if k.len()>256{return Err(Error::LimitExceeded("probe key"));}check_tree(v,depth+1,nodes)?;},
        Value::Array(a)=>for v in a{check_tree(v,depth+1,nodes)?;},_=>{},
    } Ok(())
}
fn number_text(v:Option<&Value>)->Option<String>{match v {Some(Value::Number(n))=>Some(n.to_string()),Some(Value::String(s)) if s!="N/A"=>Some(s.clone()),_=>None}}
fn text(o:&Map<String,Value>,k:&str)->Result<Option<String>>{match o.get(k){None|Some(Value::Null)=>Ok(None),Some(Value::String(s)) if s=="N/A"=>Ok(None),Some(Value::String(s))=>Ok(Some(s.clone())),_=>Err(Error::InvalidProbe("string field"))}}
fn i64_field(o:&Map<String,Value>,k:&str)->Result<Option<i64>>{
    match o.get(k){None|Some(Value::Null)=>Ok(None),Some(Value::String(s)) if s=="N/A"=>Ok(None),
        Some(Value::String(s))=>s.parse().map(Some).map_err(|_|Error::InvalidProbe("integer field")),
        Some(Value::Number(n))=>n.as_i64().map(Some).ok_or(Error::InvalidProbe("integer field")),_=>Err(Error::InvalidProbe("integer field"))}
}
fn u32_field(o:&Map<String,Value>,k:&str)->Result<Option<u32>>{i64_field(o,k)?.map(|v|u32::try_from(v).map_err(|_|Error::InvalidProbe("unsigned field"))).transpose()}
fn rational(o:&Map<String,Value>,k:&str)->Result<Option<Rational>>{text(o,k)?.map(|s|s.parse().map_err(|_|Error::InvalidProbe("rational field"))).transpose()}
fn rate(o:&Map<String,Value>,k:&str)->Result<Option<Rational>>{match text(o,k)?{None=>Ok(None),Some(s) if s=="0/0"||s=="0/1"=>Ok(None),Some(s)=>{let r:Rational=s.parse().map_err(|_|Error::InvalidProbe("frame rate"))?;if !r.positive(){Err(Error::InvalidProbe("frame rate"))}else{Ok(Some(r))}}}}
fn tags(o:&Map<String,Value>)->Result<BTreeMap<String,String>>{match o.get("tags"){None=>Ok(BTreeMap::new()),Some(Value::Object(m))=>m.iter().map(|(k,v)|v.as_str().map(|s|(k.clone(),s.to_owned())).ok_or(Error::InvalidProbe("tag"))).collect(),_=>Err(Error::InvalidProbe("tags object"))}}
fn side_data(o:&Map<String,Value>)->Result<Vec<Value>>{match o.get("side_data_list"){None=>Ok(vec![]),Some(Value::Array(a)) if a.len()<=64=>Ok(a.clone()),_=>Err(Error::InvalidProbe("side data"))}}
