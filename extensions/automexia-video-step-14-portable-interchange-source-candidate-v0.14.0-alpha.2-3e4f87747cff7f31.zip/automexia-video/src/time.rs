use crate::{Error, Result};
use serde::{Deserialize, Serialize};
use std::{fmt, str::FromStr};

/// Exact rational seconds, frame rates or time bases. No early float conversion.
/// Serialized as `numerator/denominator`; use checked operations for source ticks.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(try_from = "String", into = "String")]
pub struct Rational { num: i64, den: i64 }
impl Rational {
    pub fn new(num: i64, den: i64) -> Result<Self> {
        if den <= 0 || num == i64::MIN { return Err(Error::InvalidInput("invalid rational")); }
        let mut a = num.unsigned_abs(); let mut b = den as u64;
        while b != 0 { let r = a % b; a = b; b = r; }
        let gcd = if a == 0 { 1 } else { a as i64 };
        Ok(Self { num: num / gcd, den: den / gcd })
    }
    pub fn numerator(self) -> i64 { self.num }
    pub fn denominator(self) -> i64 { self.den }
    pub fn positive(self) -> bool { self.num > 0 }
    pub fn as_f64(self) -> f64 { self.num as f64 / self.den as f64 }
    pub fn inverse(self) -> Result<Self> { Self::new(self.den, self.num) }
    pub fn ticks(self, ticks: i64) -> Result<Self> {
        let num = (self.num as i128).checked_mul(ticks as i128)
            .ok_or(Error::InvalidInput("timestamp overflow"))?;
        Self::from_i128(num, self.den as i128)
    }
    pub fn checked_add(self, rhs: Self) -> Result<Self> {
        Self::from_i128(self.num as i128 * rhs.den as i128 + rhs.num as i128 * self.den as i128,
                        self.den as i128 * rhs.den as i128)
    }
    pub fn checked_mul(self,rhs:Self)->Result<Self> {
        Self::from_i128(self.num as i128*rhs.num as i128,self.den as i128*rhs.den as i128)
    }
    pub fn checked_div(self, rhs: Self) -> Result<Self> {
        if !rhs.positive() { return Err(Error::InvalidInput("positive divisor required")); }
        Self::from_i128(self.num as i128 * rhs.den as i128, self.den as i128 * rhs.num as i128)
    }
    /// FFmpeg time-base conversion rounds half away from zero.
    pub fn nearest_units(self, units_per_second:i64) -> Result<i64> {
        if units_per_second<=0 {return Err(Error::InvalidInput("positive time scale required"));}
        let n=self.num as i128 * units_per_second as i128;let d=self.den as i128;
        let value=if n>=0 {(n+d/2)/d} else {-((-n+d/2)/d)};
        i64::try_from(value).map_err(|_|Error::InvalidInput("timestamp overflow"))
    }
    pub fn floor_units(self, units_per_second: i64) -> Result<i64> {
        if units_per_second <= 0 { return Err(Error::InvalidInput("positive time scale required")); }
        let n=self.num as i128 * units_per_second as i128;
        i64::try_from(n.div_euclid(self.den as i128)).map_err(|_|Error::InvalidInput("timestamp overflow"))
    }
    pub fn ceil_units(self, units_per_second: i64) -> Result<i64> {
        if units_per_second <= 0 { return Err(Error::InvalidInput("positive time scale required")); }
        let n=self.num as i128 * units_per_second as i128;
        let d=self.den as i128;
        i64::try_from(n.div_euclid(d) + (if n.rem_euclid(d) != 0 {1} else {0}))
            .map_err(|_|Error::InvalidInput("timestamp overflow"))
    }
    pub fn checked_sub(self, rhs: Self) -> Result<Self> {
        Self::from_i128(self.num as i128 * rhs.den as i128 - rhs.num as i128 * self.den as i128,
                        self.den as i128 * rhs.den as i128)
    }
    fn from_i128(num: i128, den: i128) -> Result<Self> {
        let mut a = num.unsigned_abs(); let mut b = den as u128;
        while b != 0 { let r=a%b; a=b; b=r; }
        let g = if a == 0 {1} else {a as i128};
        Self::new(i64::try_from(num/g).map_err(|_| Error::InvalidInput("timestamp overflow"))?,
                  i64::try_from(den/g).map_err(|_| Error::InvalidInput("timestamp overflow"))?)
    }
}
impl fmt::Display for Rational {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result { write!(f,"{}/{}",self.num,self.den) }
}
impl FromStr for Rational {
    type Err = Error;
    fn from_str(s: &str) -> Result<Self> {
        if s.is_empty() || s.len()>48 || s.trim()!=s { return Err(Error::InvalidInput("invalid rational text")); }
        if let Some((a,b)) = s.split_once('/') {
            return Self::new(a.parse().map_err(|_| Error::InvalidInput("rational numerator"))?,
                             b.parse().map_err(|_| Error::InvalidInput("rational denominator"))?);
        }
        // Decimal ffprobe timestamps are exact decimal observations, not floats.
        let negative=s.starts_with('-'); let u=if negative {&s[1..]} else {s};
        let (whole, fraction)=u.split_once('.').unwrap_or((u,""));
        if whole.is_empty() || !whole.bytes().all(|b|b.is_ascii_digit())
            || !fraction.bytes().all(|b|b.is_ascii_digit()) || fraction.len()>12 {
            return Err(Error::InvalidInput("invalid decimal timestamp"));
        }
        let den=10_i64.pow(fraction.len() as u32);
        let w: i64=whole.parse().map_err(|_|Error::InvalidInput("timestamp overflow"))?;
        let frac: i64=if fraction.is_empty(){0}else{fraction.parse().map_err(|_|Error::InvalidInput("timestamp overflow"))?};
        let num=w.checked_mul(den).and_then(|v|v.checked_add(frac)).ok_or(Error::InvalidInput("timestamp overflow"))?;
        Self::new(if negative{-num}else{num},den)
    }
}
impl TryFrom<String> for Rational { type Error=Error; fn try_from(s:String)->Result<Self>{s.parse()} }
impl From<Rational> for String { fn from(r:Rational)->String{r.to_string()} }

impl PartialOrd for Rational {
    fn partial_cmp(&self, other:&Self)->Option<std::cmp::Ordering>{Some(self.cmp(other))}
}
impl Ord for Rational {
    fn cmp(&self, other:&Self)->std::cmp::Ordering {
        (self.num as i128 * other.den as i128).cmp(&(other.num as i128 * self.den as i128))
    }
}
