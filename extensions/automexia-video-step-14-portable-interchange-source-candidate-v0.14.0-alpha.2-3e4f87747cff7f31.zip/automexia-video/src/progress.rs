use crate::{Error,Result};
use serde::{Serialize,Deserialize};

#[derive(Debug,Clone,Copy,Serialize,Deserialize,PartialEq,Eq)]
#[serde(rename_all="snake_case")]
pub enum Stage {Inspecting,RuntimeCheck,Probing,LoadingModel,Transcribing,AnalyzingSpeech,EnhancingAudio,AnalyzingFaces,Analyzing,AnalyzingVideo,MeasuringAudio,PreparingGraphics,VerifyingTimeline,Exporting,Rendering,Validating,Publishing}
#[derive(Debug,Clone,Serialize,Deserialize,PartialEq,Eq)]
pub struct Progress {
    pub stage:Stage,
    pub out_time_us:Option<u64>,
    pub frame:Option<u64>,
    /// Encoder progress=end is NOT output validation or successful publication.
    pub encoding_finished:bool,
}
impl Progress {pub fn stage(stage:Stage)->Self{Self{stage,out_time_us:None,frame:None,encoding_finished:false}}}
/// Incremental bounded FFmpeg key=value parser. Unknown keys are ignored;
/// diagnostics are not interpreted as commands. No unbounded line allocation.
#[derive(Default)]
pub struct ProgressParser {line:Vec<u8>,time:Option<u64>,frame:Option<u64>,last_time:u64}
impl ProgressParser {
    pub fn feed(&mut self,bytes:&[u8])->Result<Vec<Progress>> {
        let mut events=Vec::new();
        for b in bytes {
            if *b==b'\n' {
                let line=std::str::from_utf8(&self.line).map_err(|_|Error::InvalidOutput("non-UTF-8 progress"))?;
                if let Some((k,v))=line.trim_end_matches('\r').split_once('=') {
                    match k {
                        "out_time_us"=>{if let Ok(n)=v.parse::<i64>(){self.time=Some(n.max(0) as u64);}},
                        "frame"=>{self.frame=v.trim().parse().ok();},
                        "progress" if v=="continue"||v=="end"=>{
                            if let Some(t)=self.time{self.last_time=self.last_time.max(t);}
                            events.push(Progress{stage:Stage::Rendering,out_time_us:self.time.map(|_|self.last_time),frame:self.frame,encoding_finished:v=="end"});
                            self.time=None;self.frame=None;
                        },_=>{},
                    }
                }
                self.line.clear();
            } else {
                if self.line.len()>=4096{return Err(Error::LimitExceeded("progress line"));}
                self.line.push(*b);
            }
        }
        Ok(events)
    }
}
