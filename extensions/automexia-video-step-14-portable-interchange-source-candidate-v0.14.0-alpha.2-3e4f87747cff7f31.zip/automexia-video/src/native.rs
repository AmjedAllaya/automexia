//! Optional native/provider-side adapter. This is NOT a sandbox or a replacement
//! for the terminal's permission broker. Use only with approved executables and
//! explicitly granted paths. Map MediaHost into the current terminal as needed.
use crate::{Cancellation,Error,Result};
use crate::host::{FileStamp,InputFile,MediaHost,MediaTask,OutputLease,OutputPolicy,ProgressSink,RuntimeCapabilities,ToolOutput};
use sha2::{Sha256,Digest};
use std::{collections::BTreeSet,ffi::OsString,fs::{self,File},io::Read,path::{Path,PathBuf},
    sync::Mutex,time::{Duration,UNIX_EPOCH}};
mod runner;
mod transcript;
mod hdr;
mod bundle;
pub(crate) use transcript::run_whisper_task;
use runner::{CaptureMode,run_process,run_process_stream,run_process_dual_stream};
#[cfg(test)] use runner::check_output_limit;
use tempfile::{NamedTempFile,TempDir};

#[derive(Debug,Clone)]
pub struct NativeSettings {
    pub ffmpeg:PathBuf,pub ffprobe:PathBuf,
    pub probe_timeout:Duration,pub render_timeout:Duration,
    pub max_input_bytes:u64,pub max_output_bytes:u64,
}
impl NativeSettings {
    pub fn new(ffmpeg:impl Into<PathBuf>,ffprobe:impl Into<PathBuf>)->Self{
        Self{ffmpeg:ffmpeg.into(),ffprobe:ffprobe.into(),probe_timeout:Duration::from_secs(30),render_timeout:Duration::from_secs(7200),max_input_bytes:512*1024*1024*1024,max_output_bytes:64*1024*1024*1024}
    }
    fn validate(&self)->Result<()>{
        if !self.ffmpeg.is_absolute()||!self.ffprobe.is_absolute(){return Err(Error::InvalidInput("absolute approved media executable paths are required"));}
        if self.probe_timeout.is_zero()||self.render_timeout.is_zero()||self.probe_timeout>Duration::from_secs(600)||self.render_timeout>Duration::from_secs(86400)||self.max_input_bytes==0||self.max_output_bytes==0{
            return Err(Error::InvalidInput("native media limits"));
        }Ok(())
    }
}
#[derive(Clone)]
struct PinnedTool {path:PathBuf,stamp:FileStamp}
pub struct NativeMediaHost {settings:NativeSettings,tools:Mutex<Option<(PinnedTool,PinnedTool)>>,capabilities:Mutex<Option<RuntimeCapabilities>>}
impl NativeMediaHost {
    /// Validates settings only. No filesystem access or process startup.
    /// The explicitly configured tools are pinned on the first media operation.
    pub fn new(settings:NativeSettings)->Result<Self>{
        settings.validate()?;
        Ok(Self{settings,tools:Mutex::new(None),capabilities:Mutex::new(None)})
    }
    fn pinned(&self,cancel:&Cancellation)->Result<(PinnedTool,PinnedTool)>{
        cancel.check()?;
        let mut tools=self.tools.lock().map_err(|_|Error::Poisoned)?;
        if let Some(pinned)=tools.as_ref(){return Ok(pinned.clone());}
        let pinned=(pin(&self.settings.ffmpeg,cancel)?,pin(&self.settings.ffprobe,cancel)?);
        *tools=Some(pinned.clone());Ok(pinned)
    }
    /// Obtain this stamp before asking the user to approve replacement. Passing
    /// it later authorizes no host operation by itself; host consent stays outside.
    pub fn review_existing_output(&self,path:&Path,cancel:&Cancellation)->Result<FileStamp>{
        let path=local_file(path)?;fingerprint(&path,self.settings.max_input_bytes,cancel)
    }
    fn execute(&self,tool:&PinnedTool,name:&'static str,args:&[OsString],timeout:Duration,mode:CaptureMode,watch:Option<(PathBuf,u64)>,cancel:&Cancellation,progress:&mut ProgressSink<'_>)->Result<Vec<u8>>{
        cancel.check()?;
        if fingerprint(&tool.path,512*1024*1024,cancel)?!=tool.stamp{return Err(Error::ToolIdentityChanged);}
        for arg in args {if arg.as_encoded_bytes().contains(&0){return Err(Error::InvalidInput("NUL in tool argument"));}}
        let output=run_process(&tool.path,name,args,timeout,mode,watch,cancel,progress)?;
        if fingerprint(&tool.path,512*1024*1024,cancel)?!=tool.stamp{return Err(Error::ToolIdentityChanged);}
        cancel.check()?;Ok(output)
    }
}
impl MediaHost for NativeMediaHost {
    fn run_hdr(&self,task:&crate::hdr::HdrTask,cancel:&Cancellation,progress:&mut ProgressSink<'_>)->Result<ToolOutput>{
        hdr::run(self,task,cancel,progress)
    }
    fn verify_timing(&self,input:&InputFile,media:&crate::MediaInfo,stream:u32,rate:crate::interchange::EditRate,cancel:&Cancellation)->Result<crate::interchange::CfrEvidence>{
        <Self as crate::interchange::InterchangeHost>::verify_cfr(self,input,media,stream,rate,cancel)
    }
    fn prepare_presentation(&self,plan:&crate::presentation_render::PresentationRender,project_file:&Path,cancel:&Cancellation)->Result<Box<dyn crate::presentation_render::PresentationLease>>{
        crate::graphics_native::prepare(self,plan,project_file,cancel)
    }
    fn publish_subtitles(&self,source:&InputFile,protected:&[PathBuf],destination:&Path,policy:&OutputPolicy,bytes:&[u8],cancel:&Cancellation)->Result<PathBuf>{
        if bytes.len()>4*crate::subtitles::MAX_SUBTITLE_BYTES||!destination.extension().and_then(|s|s.to_str()).is_some_and(|s|s.eq_ignore_ascii_case("srt")||s.eq_ignore_ascii_case("vtt")){return Err(Error::InvalidInput("bounded SRT/VTT sidecar destination"));}
        let guard=||->Result<()>{if protected.len()>256{return Err(Error::LimitExceeded("sidecar protected paths"));}
            for path in protected{if path==destination{return Err(Error::SameFile);}if path.exists()&&destination.exists()&&same_file::is_same_file(path,destination).map_err(|_|Error::Io("compare sidecar protected path"))?{return Err(Error::SameFile);}}Ok(())};
        cancel.check()?;guard()?;let lease=self.stage_output(source,destination,policy,cancel)?;
        fs::write(lease.path(),bytes).map_err(|_|Error::Io("write staged subtitle sidecar"))?;self.revalidate_input(source,cancel)?;guard()?;lease.publish(cancel)
    }

    fn inspect_input(&self,path:&Path,cancel:&Cancellation)->Result<InputFile>{
        cancel.check()?;let path=local_file(path)?;let stamp=fingerprint(&path,self.settings.max_input_bytes,cancel)?;
        if stamp.size==0{return Err(Error::InvalidInput("empty media file"));}Ok(InputFile{canonical_path:path,stamp})
    }
    fn revalidate_input(&self,input:&InputFile,cancel:&Cancellation)->Result<()>{
        if fingerprint(&input.canonical_path,self.settings.max_input_bytes,cancel)?!=input.stamp{return Err(Error::InputChanged);}Ok(())
    }
    fn runtime_capabilities(&self,cancel:&Cancellation)->Result<RuntimeCapabilities>{
        let (ffmpeg,ffprobe)=self.pinned(cancel)?;
        cancel.check()?;
        // A cache hit saves the six subprocesses, NOT executable verification.
        if fingerprint(&ffmpeg.path,512*1024*1024,cancel)?!=ffmpeg.stamp ||
            fingerprint(&ffprobe.path,512*1024*1024,cancel)?!=ffprobe.stamp {return Err(Error::ToolIdentityChanged);}
        if let Some(value)=self.capabilities.lock().map_err(|_|Error::Poisoned)?.clone(){cancel.check()?;return Ok(value);}
        // Do not hold the memo lock while hashing or running child processes.
        // Concurrent first calls can safely perform duplicate, bounded probes.
        let mut ignore=|_|{};
        let query=|tool:&PinnedTool,name:&'static str,args:&[&str],sink:&mut ProgressSink<'_>|{
            let args:Vec<OsString>=args.iter().map(|s|OsString::from(*s)).collect();
            self.execute(tool,name,&args,self.settings.probe_timeout,CaptureMode::Text,None,cancel,sink)
        };
        let fv=query(&ffmpeg,"ffmpeg",&["-version"],&mut ignore)?;
        let pv=query(&ffprobe,"ffprobe",&["-version"],&mut ignore)?;
        let enc=query(&ffmpeg,"ffmpeg",&["-hide_banner","-encoders"],&mut ignore)?;
        let mux=query(&ffmpeg,"ffmpeg",&["-hide_banner","-muxers"],&mut ignore)?;
        let bitstream_filters=query(&ffmpeg,"ffmpeg",&["-hide_banner","-bsfs"],&mut ignore)?;
        let filters=query(&ffmpeg,"ffmpeg",&["-hide_banner","-filters"],&mut ignore)?;
        let ffmpeg_version=first_line(&fv,"ffmpeg version ")?;
        let ffprobe_version=first_line(&pv,"ffprobe version ")?;
        if !release_at_least_7_1(&ffmpeg_version)||!release_at_least_7_1(&ffprobe_version){return Err(Error::Unsupported("native adapter requires an identified FFmpeg/ffprobe release 7.1 or newer"));}
        let value=RuntimeCapabilities{ffmpeg_version,ffprobe_version,supports_demux_time_base:true,
            ffmpeg_identity:Some(ffmpeg.stamp.sha256.clone()),ffprobe_identity:Some(ffprobe.stamp.sha256.clone()),
            encoders:parse_capabilities(&enc,true),muxers:parse_capabilities(&mux,false),filters:parse_filters(&filters),bitstream_filters:String::from_utf8_lossy(&bitstream_filters).lines().map(str::trim).filter(|s|!s.is_empty()&&s.bytes().all(|b|b.is_ascii_alphanumeric()||b==b'_')).map(str::to_owned).collect()};
        if fingerprint(&ffmpeg.path,512*1024*1024,cancel)?!=ffmpeg.stamp ||
            fingerprint(&ffprobe.path,512*1024*1024,cancel)?!=ffprobe.stamp {return Err(Error::ToolIdentityChanged);}
        cancel.check()?;*self.capabilities.lock().map_err(|_|Error::Poisoned)?=Some(value.clone());Ok(value)
    }
    fn run(&self,task:&MediaTask,cancel:&Cancellation,progress:&mut ProgressSink<'_>)->Result<ToolOutput>{
        cancel.check()?;let args=task.arguments()?;
        if let MediaTask::Render{input,staged_output,plan}=task{guard_task_output(staged_output,std::iter::once(input.as_path()).chain(plan.enhanced_audio_path()))?;}
        let (ffmpeg,ffprobe)=self.pinned(cancel)?;
        let (tool,timeout,mode)=match task {
            MediaTask::Probe{..}=>(&ffprobe,self.settings.probe_timeout,CaptureMode::Probe),
            MediaTask::Render{..}=>(&ffmpeg,self.settings.render_timeout,CaptureMode::Progress),
            MediaTask::ValidateDecode{..}=>(&ffmpeg,self.settings.render_timeout,CaptureMode::Text),
        };
        let watch=match task{MediaTask::Render{staged_output,plan,..}=>Some((staged_output.clone(),plan.output_byte_limit().unwrap_or(self.settings.max_output_bytes).min(self.settings.max_output_bytes))),_=>None};
        self.execute(tool,task.tool_name(),&args,timeout,mode,watch,cancel,progress).map(|stdout|ToolOutput{stdout})
    }
    fn stream_voice_pcm(&self,request:&crate::voice_render::VoiceScan,cancel:&Cancellation,sink:&mut crate::voice_render::PcmSink<'_>)->Result<()> {
        cancel.check()?;self.revalidate_input(request.input(),cancel)?;
        let (ffmpeg,_)=self.pinned(cancel)?;
        if fingerprint(&ffmpeg.path,512*1024*1024,cancel)?!=ffmpeg.stamp{return Err(Error::ToolIdentityChanged);}
        let args=request.arguments()?;
        for arg in &args{if arg.as_encoded_bytes().contains(&0){return Err(Error::InvalidInput("NUL in audio argument"));}}
        let mut ignore=|_|{};
        run_process_stream(&ffmpeg.path,"ffmpeg",&args,request.timeout().min(self.settings.render_timeout),CaptureMode::Metrics,None,cancel,&mut ignore,Some(sink))?;
        if fingerprint(&ffmpeg.path,512*1024*1024,cancel)?!=ffmpeg.stamp{return Err(Error::ToolIdentityChanged);}
        self.revalidate_input(request.input(),cancel)?;cancel.check()
    }
    fn run_audio(&self,task:&crate::voice_render::AudioTask,cancel:&Cancellation,progress:&mut ProgressSink<'_>)->Result<ToolOutput> {
        cancel.check()?;self.revalidate_input(task.input(),cancel)?;
        if let Some(input)=task.additional_input(){self.revalidate_input(input,cancel)?;}
        let enhanced=match task{crate::voice_render::AudioTask::MeasurePlan{plan,..}|crate::voice_render::AudioTask::RenderStem{plan,..}=>plan.enhanced_audio_path().map(|path|self.inspect_input(path,cancel)).transpose()?,_=>None};
        if let Some(output)=task.output(){guard_task_output(output,std::iter::once(task.input().canonical_path.as_path()).chain(task.additional_input().map(|input|input.canonical_path.as_path())).chain(enhanced.as_ref().map(|input|input.canonical_path.as_path())))?;}
        let (ffmpeg,ffprobe)=self.pinned(cancel)?;let args=task.arguments()?;
        let tool=if task.tool_name()=="ffprobe"{&ffprobe}else{&ffmpeg};
        let mode=if task.measurement(){CaptureMode::Loudness}else if task.output().is_some(){CaptureMode::Progress}else{CaptureMode::Text};
        let maximum=task.maximum_output_bytes()?.unwrap_or(self.settings.max_output_bytes).min(self.settings.max_output_bytes);
        let watch=task.output().map(|p|(p.to_owned(),maximum));
        let stdout=self.execute(tool,task.tool_name(),&args,task.timeout().min(self.settings.render_timeout),mode,watch,cancel,progress)?;
        self.revalidate_input(task.input(),cancel)?;if let Some(input)=task.additional_input(){self.revalidate_input(input,cancel)?;}if let Some(input)=&enhanced{self.revalidate_input(input,cancel)?;}cancel.check()?;Ok(ToolOutput{stdout})
    }
    fn stream_video_frames(&self, request:&crate::color_workflow::VideoScan, cancel:&Cancellation,
        sink:&mut crate::color_analysis::VideoFrameSink<'_>)->Result<()> {
        use std::cell::RefCell;
        cancel.check()?; self.revalidate_input(request.input(),cancel)?;
        let (ffmpeg,_)=self.pinned(cancel)?;
        if fingerprint(&ffmpeg.path,512*1024*1024,cancel)?!=ffmpeg.stamp{return Err(Error::ToolIdentityChanged);}
        let args=request.arguments()?;
        for arg in &args {if arg.as_encoded_bytes().contains(&0){return Err(Error::InvalidInput("NUL in video scan argument"));}}
        let (width,height)=request.dimensions();
        let pipe=RefCell::new(crate::video_pipe::VideoPipe::new(width,height,request.time_base(),request.max_frames(),request.full_range())?);
        {
            let sink=RefCell::new(sink);
            let mut stdout=|bytes:&[u8]| {cancel.check()?;pipe.borrow_mut().pixels(bytes,&mut **sink.borrow_mut())};
            let mut stderr=|bytes:&[u8]| {cancel.check()?;pipe.borrow_mut().diagnostics(bytes,&mut **sink.borrow_mut())};
            let mut ignore=|_|{};
            run_process_dual_stream(&ffmpeg.path,"ffmpeg",&args,request.timeout().min(self.settings.render_timeout),
                CaptureMode::Metrics,None,cancel,&mut ignore,Some(&mut stdout),Some(&mut stderr))?;
        }
        pipe.into_inner().finish()?;
        if fingerprint(&ffmpeg.path,512*1024*1024,cancel)?!=ffmpeg.stamp{return Err(Error::ToolIdentityChanged);}
        self.revalidate_input(request.input(),cancel)?;cancel.check()
    }
    fn stage_output(&self,input:&InputFile,destination:&Path,policy:&OutputPolicy,cancel:&Cancellation)->Result<Box<dyn OutputLease>>{
        let name=destination.file_name().ok_or(Error::InvalidInput("output filename"))?;
        let parent=destination.parent().filter(|p|!p.as_os_str().is_empty()).unwrap_or(Path::new("."));
        let parent=fs::canonicalize(parent).map_err(|_|Error::Io("resolve output directory"))?;
        if !parent.is_dir(){return Err(Error::InvalidInput("output parent directory"));}
        let destination=parent.join(name);
        check_destination(input,&destination,policy,self.settings.max_input_bytes,cancel)?;
        let dir=private_tempdir(".automexia-video-",Some(&parent)).map_err(|_|Error::Io("create job staging directory"))?;
        let ext=destination.extension().and_then(|s|s.to_str()).ok_or(Error::InvalidInput("output extension"))?;
        if ext.len()>16||!ext.bytes().all(|b|b.is_ascii_alphanumeric()){return Err(Error::InvalidInput("portable output extension"));}
        let suffix=format!(".{ext}");
        let temp=tempfile::Builder::new().prefix("render-").suffix(&suffix).tempfile_in(dir.path()).map_err(|_|Error::Io("create staged output"))?;
        Ok(Box::new(NativeLease{temp:Some(temp),_dir:dir,destination,input:input.clone(),policy:policy.clone(),max_bytes:self.settings.max_input_bytes,max_output_bytes:self.settings.max_output_bytes}))
    }
}
/// Public typed tasks must not overwrite their inputs even when called outside
/// a workflow lease. A workflow additionally keeps its output in private staging.
pub(crate) fn guard_task_output<'a>(output:&Path,inputs:impl IntoIterator<Item=&'a Path>)->Result<()> {
    if !output.is_absolute()||output.components().any(|c|matches!(c,std::path::Component::ParentDir))||output.as_os_str().as_encoded_bytes().contains(&0){return Err(Error::InvalidInput("absolute task output without traversal required"));}
    for input in inputs {
        if input==output||(output.exists()&&same_file::is_same_file(input,output).map_err(|_|Error::Io("compare task input/output aliases"))?){return Err(Error::SameFile);}
    }
    match fs::symlink_metadata(output){
        Ok(metadata) if metadata.file_type().is_symlink()||!metadata.is_file()=>Err(Error::InvalidInput("task output must be a regular nonsymlink file")),
        Ok(_)=>Ok(()),Err(error) if error.kind()==std::io::ErrorKind::NotFound=>Ok(()),Err(_)=>Err(Error::Io("inspect task output")),
    }
}
/// Private generated contents are protected before any file is written.
/// Windows uses the selected host directory's access-control policy.
pub(crate) fn private_tempdir(prefix:&str,parent:Option<&Path>)->std::io::Result<TempDir> {
    let mut builder=tempfile::Builder::new();builder.prefix(prefix);
    #[cfg(unix)] {use std::os::unix::fs::PermissionsExt;builder.permissions(fs::Permissions::from_mode(0o700));}
    match parent {Some(path)=>builder.tempdir_in(path),None=>builder.tempdir()}
}
struct NativeLease {temp:Option<NamedTempFile>,_dir:TempDir,destination:PathBuf,input:InputFile,policy:OutputPolicy,max_bytes:u64,max_output_bytes:u64}
impl OutputLease for NativeLease {
    fn path(&self)->&Path {self.temp.as_ref().expect("lease has unconsumed temporary file").path()}
    fn publish(mut self:Box<Self>,cancel:&Cancellation)->Result<PathBuf>{
        cancel.check()?;
        if fingerprint(&self.input.canonical_path,self.max_bytes,cancel)?!=self.input.stamp{return Err(Error::InputChanged);}
        check_destination(&self.input,&self.destination,&self.policy,self.max_bytes,cancel)?;
        let temp=self.temp.take().ok_or(Error::Io("staged output already consumed"))?;
        if temp.as_file().metadata().map_err(|_|Error::Io("staged output metadata"))?.len()>self.max_output_bytes{return Err(Error::LimitExceeded("output file size"));}
        temp.as_file().sync_all().map_err(|_|Error::Io("synchronize staged output"))?;
        cancel.check()?;
        let result=match self.policy {
            OutputPolicy::CreateNew=>temp.persist_noclobber(&self.destination),
            OutputPolicy::ReplaceReviewed(_)=>temp.persist(&self.destination),
        };
        result.map_err(|e|if e.error.kind()==std::io::ErrorKind::AlreadyExists{Error::OutputExists}else{Error::Io("publish output")})?;
        // Commit is complete. Directory fsync is best effort, not a post-commit
        // failure that could induce the caller to repeat a completed operation.
        #[cfg(unix)] if let Some(parent)=self.destination.parent(){if let Ok(d)=File::open(parent){let _=d.sync_all();}}
        Ok(self.destination.clone())
    }
}
fn check_destination(input:&InputFile,destination:&Path,policy:&OutputPolicy,max_bytes:u64,cancel:&Cancellation)->Result<()>{
    if destination==input.canonical_path{return Err(Error::SameFile);}
    match fs::symlink_metadata(destination) {
        Ok(m)=>{
            if m.file_type().is_symlink()||!m.is_file(){return Err(Error::InvalidInput("output is not a regular non-symlink file"));}
            if same_file::is_same_file(&input.canonical_path,destination).map_err(|_|Error::Io("compare source/output identity"))?{return Err(Error::SameFile);}
            match policy {
                OutputPolicy::CreateNew=>Err(Error::OutputExists),
                OutputPolicy::ReplaceReviewed(expected)=>{
                    if fingerprint(destination,max_bytes,cancel)?!=*expected{Err(Error::OutputChanged)}else{Ok(())}
                }
            }
        },
        Err(e) if e.kind()==std::io::ErrorKind::NotFound=>match policy{OutputPolicy::CreateNew=>Ok(()),_=>Err(Error::OutputChanged)},
        Err(_)=>Err(Error::Io("inspect output destination")),
    }
}
fn local_file(path:&Path)->Result<PathBuf>{
    if path.as_os_str().is_empty(){return Err(Error::InvalidInput("empty path"));}
    if path.to_string_lossy().contains("://"){return Err(Error::InvalidInput("only selected local files are accepted"));}
    let path=fs::canonicalize(path).map_err(|_|Error::Io("resolve selected local file"))?;
    if !fs::metadata(&path).map_err(|_|Error::Io("read selected file metadata"))?.is_file(){return Err(Error::InvalidInput("not a regular file"));}Ok(path)
}
fn pin(path:&Path,cancel:&Cancellation)->Result<PinnedTool>{let path=local_file(path)?;let stamp=fingerprint(&path,512*1024*1024,cancel)?;Ok(PinnedTool{path,stamp})}
/// Open an explicitly selected regular file without following a last-component
/// link or blocking on a substituted special file on Unix. Parent ownership and
/// Windows reparse-point hardening remain host/platform responsibilities.
pub(crate) fn open_regular_file(path:&Path)->Result<File>{
    let mut options=fs::OpenOptions::new();options.read(true);
    #[cfg(unix)] {use std::os::unix::fs::OpenOptionsExt;
        options.custom_flags(nix::libc::O_NOFOLLOW | nix::libc::O_NONBLOCK);}
    let file=options.open(path).map_err(|_|Error::Io("open selected regular file"))?;
    if !file.metadata().map_err(|_|Error::Io("selected file metadata"))?.is_file(){
        return Err(Error::InvalidInput("selected file is not regular"));
    }Ok(file)
}
/// Bounded reads for project/graphic assets. Do not use this for media hashing.
pub(crate) fn read_selected_bytes(path:&Path,limit:u64,cancel:&Cancellation)->Result<Vec<u8>>{
    cancel.check()?;
    let mut file=open_regular_file(path)?;
    if file.metadata().map_err(|_|Error::Io("selected bytes metadata"))?.len()>limit{
        return Err(Error::LimitExceeded("selected bytes"));
    }
    let mut bytes=Vec::new();let mut part=[0u8;16384];
    loop {cancel.check()?;let n=file.read(&mut part).map_err(|_|Error::Io("read selected bytes"))?;
        if n==0{break;}
        let next=bytes.len().checked_add(n).ok_or(Error::LimitExceeded("selected bytes"))?;
        if next as u64>limit{return Err(Error::LimitExceeded("selected bytes"));}
        bytes.extend_from_slice(&part[..n]);
    }cancel.check()?;Ok(bytes)
}
pub(crate) fn fingerprint(path:&Path,max_bytes:u64,cancel:&Cancellation)->Result<FileStamp>{
    cancel.check()?;
    let mut file=open_regular_file(path)?;
    let before=file.metadata().map_err(|_|Error::Io("file metadata"))?;
    if !before.is_file(){return Err(Error::InvalidInput("not a regular file"));}
    if before.len()>max_bytes{return Err(Error::LimitExceeded("file size"));}
    let mut digest=Sha256::new();let mut buffer=[0u8;65536];let mut total=0u64;
    loop {cancel.check()?;let n=file.read(&mut buffer).map_err(|_|Error::Io("read selected file"))?;if n==0{break;}
        total=total.checked_add(n as u64).ok_or(Error::LimitExceeded("file size"))?;if total>max_bytes{return Err(Error::LimitExceeded("file size"));}digest.update(&buffer[..n]);}
    let after=file.metadata().map_err(|_|Error::Io("file metadata after read"))?;
    let path_after=fs::symlink_metadata(path).map_err(|_|Error::InputChanged)?;
    if path_after.file_type().is_symlink() || !path_after.is_file(){return Err(Error::InputChanged);}
    if total!=before.len()||metadata_id(&before)!=metadata_id(&after)||metadata_id(&before)!=metadata_id(&path_after){return Err(Error::InputChanged);}
    Ok(FileStamp{size:total,modified_ns:before.modified().ok().and_then(|t|t.duration_since(UNIX_EPOCH).ok()).map(|d|d.as_nanos()),sha256:format!("{:x}",digest.finalize()),file_id:platform_id(&before)})
}
fn metadata_id(m:&fs::Metadata)->(u64,Option<std::time::SystemTime>,Option<String>){(m.len(),m.modified().ok(),platform_id(m))}
fn platform_id(m:&fs::Metadata)->Option<String>{
    #[cfg(unix)] {use std::os::unix::fs::MetadataExt;Some(format!("{}:{}",m.dev(),m.ino()))}
    #[cfg(not(unix))] {let _=m;None}
}
fn first_line(bytes:&[u8],prefix:&str)->Result<String>{let text=std::str::from_utf8(bytes).map_err(|_|Error::InvalidOutput("tool version UTF-8"))?;let line=text.lines().next().unwrap_or("");if !line.starts_with(prefix)||line.len()>1024{return Err(Error::InvalidOutput("tool version identity"));}Ok(line.to_owned())}
fn parse_capabilities(bytes:&[u8],encoder:bool)->BTreeSet<String>{
    String::from_utf8_lossy(bytes).lines().filter_map(|line|{
        let mut fields=line.split_whitespace();let flags=fields.next()?;let name=fields.next()?;
        let ok=if encoder{flags.len()==6&&flags.bytes().all(|b|b.is_ascii_alphabetic()||b==b'.')}else{flags.contains('E')&&flags.len()<=2};
        if ok&&name!="="{Some(name.split(',').map(str::to_owned).collect::<Vec<_>>())}else{None}
    }).flatten().collect()
}

fn release_at_least_7_1(line:&str)->bool{
    let version=line.split_whitespace().nth(2).unwrap_or("");
    let mut parts=version.split(|c:char|!c.is_ascii_digit());
    match (parts.next().and_then(|v|v.parse::<u32>().ok()),parts.next().and_then(|v|v.parse::<u32>().ok())) {
        (Some(major),Some(minor))=>major>7||(major==7&&minor>=1),_=>false
    }
}

fn parse_filters(bytes:&[u8])->BTreeSet<String>{
    String::from_utf8_lossy(bytes).lines().filter_map(|line|{
        let mut fields=line.split_whitespace();let flags=fields.next()?;let name=fields.next()?;
        if flags.len()==3 && flags.bytes().all(|b|b==b'.'||b.is_ascii_alphabetic()) && name!="=" {Some(name.to_owned())} else {None}
    }).collect()
}

impl crate::project_store::ProjectStore for NativeMediaHost {
    fn load_project(&self,path:&Path,cancel:&Cancellation)->Result<crate::project_store::LoadedProject>{
        check_project_path(path)?;cancel.check()?;
        let metadata=fs::symlink_metadata(path).map_err(|_|Error::Io("inspect project"))?;
        if metadata.file_type().is_symlink()||!metadata.is_file(){return Err(Error::InvalidProject("project must be a regular non-symlink file"));}
        let canonical=fs::canonicalize(path).map_err(|_|Error::Io("resolve project"))?;
        let stamp=fingerprint(&canonical,crate::project::MAX_PROJECT_BYTES as u64,cancel)?;
        let bytes=read_selected_bytes(&canonical,crate::project::MAX_PROJECT_BYTES as u64,cancel)?;
        if bytes.len() as u64!=stamp.size||format!("{:x}",Sha256::digest(&bytes))!=stamp.sha256||fingerprint(&canonical,crate::project::MAX_PROJECT_BYTES as u64,cancel)?!=stamp{return Err(Error::InputChanged);}
        let project=crate::project::Project::from_json(&bytes)?;cancel.check()?;
        Ok(crate::project_store::LoadedProject{path:canonical,stamp,project})
    }
    fn save_project(&self,project:&crate::project::Project,path:&Path,policy:&OutputPolicy,cancel:&Cancellation)->Result<crate::project_store::SavedProject>{
        use std::io::Write;
        check_project_path(path)?;cancel.check()?;let bytes=project.to_json()?;
        let parent=fs::canonicalize(path.parent().ok_or(Error::InvalidProject("project parent"))?).map_err(|_|Error::Io("resolve project directory"))?;
        let destination=parent.join(path.file_name().ok_or(Error::InvalidProject("project filename"))?);
        // Reject symlinked parent aliases for relative-source projects rather
        // than silently change the reference base at save/reopen time.
        if path.parent()!=Some(parent.as_path()) && (project.sources.iter().any(|s|s.path.is_relative())||project.settings.voice_enhancement.as_ref().is_some_and(|e|e.stem_path.is_relative())||project.variants.iter().filter_map(|v|v.presentation.as_ref()).flat_map(|p|p.all_asset_refs()).any(|a|a.path.is_relative())) {return Err(Error::InvalidProject("use the canonical project directory for relative media references"));}
        check_project_destination(project,&destination,policy,cancel)?;
        let mut temp=tempfile::Builder::new().prefix(".amxv-save-").tempfile_in(&parent).map_err(|_|Error::Io("create project staging file"))?;
        for part in bytes.chunks(16384){cancel.check()?;temp.write_all(part).map_err(|_|Error::Io("write project staging file"))?;}
        temp.as_file().sync_all().map_err(|_|Error::Io("synchronize project"))?;
        let stamp=fingerprint(temp.path(),crate::project::MAX_PROJECT_BYTES as u64,cancel)?;
        check_project_destination(project,&destination,policy,cancel)?;cancel.check()?;
        let result=match policy{OutputPolicy::CreateNew=>temp.persist_noclobber(&destination),OutputPolicy::ReplaceReviewed(_)=>temp.persist(&destination)};
        result.map_err(|e|if e.error.kind()==std::io::ErrorKind::AlreadyExists{Error::OutputExists}else{Error::Io("publish project")})?;
        #[cfg(unix)] if let Ok(d)=File::open(&parent){let _=d.sync_all();}
        // No fallible operation after commit: callers must not retry a successful
        // save because post-publication stat/hash/notification failed.
        Ok(crate::project_store::SavedProject{path:destination,stamp})
    }
}
fn check_project_path(path:&Path)->Result<()> {
    if !path.is_absolute()||!path.extension().and_then(|s|s.to_str()).is_some_and(|s|s.eq_ignore_ascii_case("amxv")){
        return Err(Error::InvalidProject("absolute .amxv location required"));
    }
    if path.components().any(|c|matches!(c,std::path::Component::ParentDir)){return Err(Error::InvalidProject("parent traversal in project location"));}Ok(())
}
fn check_project_destination(project:&crate::project::Project,destination:&Path,policy:&OutputPolicy,cancel:&Cancellation)->Result<()> {
    cancel.check()?;
    let existing=match fs::symlink_metadata(destination){
        Ok(m)=>{if m.file_type().is_symlink()||!m.is_file(){return Err(Error::InvalidProject("project destination is not a regular file"));}true},
        Err(e) if e.kind()==std::io::ErrorKind::NotFound=>false,Err(_)=>return Err(Error::Io("inspect project destination")),
    };
    for source in &project.sources {
        let source_path=source.resolve(destination)?;
        if source_path==destination{return Err(Error::SameFile);}
        if existing {
            match fs::metadata(&source_path) {
                Ok(_)=>{if same_file::is_same_file(&source_path,destination).map_err(|_|Error::Io("compare project/media identity"))?{return Err(Error::SameFile);}},
                Err(e) if e.kind()==std::io::ErrorKind::NotFound=>{},Err(_)=>return Err(Error::Io("inspect source before project save")),
            }
        }
    }
    if let Some(enhancement)=&project.settings.voice_enhancement{
        let stem_path=enhancement.resolve(destination)?;
        if stem_path==destination{return Err(Error::SameFile);}
        if existing{match fs::metadata(&stem_path){
            Ok(_)=>{if same_file::is_same_file(&stem_path,destination).map_err(|_|Error::Io("compare enhancement/project identity"))?{return Err(Error::SameFile);}},
            Err(e) if e.kind()==std::io::ErrorKind::NotFound=>{},Err(_)=>return Err(Error::Io("inspect enhancement before project save")),
        }}
    }
    for p in project.variants.iter().filter_map(|v|v.presentation.as_ref()) {for a in p.all_asset_refs(){
        let asset_path=a.resolve(destination)?;
        if asset_path==destination{return Err(Error::SameFile);}
        if existing {match fs::metadata(&asset_path){
            Ok(_)=>{if same_file::is_same_file(&asset_path,destination).map_err(|_|Error::Io("compare graphic/project identity"))?{return Err(Error::SameFile);}},
            Err(e) if e.kind()==std::io::ErrorKind::NotFound=>{},Err(_)=>return Err(Error::Io("inspect graphic before project save")),
        }}
    }}
    match (existing,policy){
        (true,OutputPolicy::CreateNew)=>Err(Error::OutputExists),
        (false,OutputPolicy::ReplaceReviewed(_))=>Err(Error::OutputChanged),
        (true,OutputPolicy::ReplaceReviewed(expected))=>{
            if fingerprint(destination,crate::project::MAX_PROJECT_BYTES as u64,cancel)?!=*expected{Err(Error::OutputChanged)}else{Ok(())}
        },_=>Ok(())
    }
}


impl crate::pause_workflow::AudioAnalysisHost for NativeMediaHost {
    fn stream_energy(&self,request:&crate::pause_workflow::AnalysisDecode,cancel:&Cancellation,sink:&mut crate::pause_workflow::EnergySink<'_>)->Result<()> {
        use crate::pause_metrics::MetricParser;
        cancel.check()?;
        self.revalidate_input(request.input(),cancel)?;
        let (ffmpeg,_)=self.pinned(cancel)?;
        if fingerprint(&ffmpeg.path,512*1024*1024,cancel)?!=ffmpeg.stamp{return Err(Error::ToolIdentityChanged);}
        let args=request.arguments()?;
        for arg in &args {if arg.as_encoded_bytes().contains(&0){return Err(Error::InvalidInput("NUL in analysis argument"));}}
        let mut parser=MetricParser::new(request.channels())?;
        let mut ignore=|_|{};
        {
            let mut consume=|bytes:&[u8]|{cancel.check()?;parser.feed(bytes,sink)};
            run_process_stream(&ffmpeg.path,"ffmpeg",&args,request.timeout().min(self.settings.render_timeout),
                CaptureMode::Metrics,None,cancel,&mut ignore,Some(&mut consume))?;
        }
        cancel.check()?;
        std::panic::catch_unwind(std::panic::AssertUnwindSafe(||parser.finish(sink))).map_err(|_|Error::CallbackPanicked)??;
        if fingerprint(&ffmpeg.path,512*1024*1024,cancel)?!=ffmpeg.stamp{return Err(Error::ToolIdentityChanged);}
        self.revalidate_input(request.input(),cancel)?;cancel.check()
    }
}

// Step 10: optional adapter to existing media scanning and publication owners.
impl crate::interchange::InterchangeHost for NativeMediaHost {
    fn verify_cfr(&self,input:&InputFile,media:&crate::MediaInfo,stream:u32,rate:crate::interchange::EditRate,cancel:&Cancellation)->Result<crate::interchange::CfrEvidence>{
        use crate::interchange::timing::{CfrVerifier,CFR_PROBE_PREFIX};
        self.revalidate_input(input,cancel)?;
        let video=media.stream(stream)?;
        if video.kind!="video"||video.is_attached_picture(){return Err(Error::InvalidInput("CFR scan selects moving video"));}
        let origin=video.exact_start().or(media.start_time).ok_or(Error::InvalidProbe("video origin"))?;
        let duration=video.exact_duration().ok_or(Error::InvalidProbe("video duration"))?;
        let tb=video.time_base.ok_or(Error::InvalidProbe("video time base"))?;
        let mut verifier=CfrVerifier::new(input.clone(),stream,rate,origin,duration,tb)?;
        let (_,tool)=self.pinned(cancel)?;
        if fingerprint(&tool.path,512*1024*1024,cancel)?!=tool.stamp{return Err(Error::ToolIdentityChanged);}
        let mut args:Vec<OsString>=CFR_PROBE_PREFIX.iter().map(|s|OsString::from(*s)).collect();
        args.extend([OsString::from("-select_streams"),OsString::from(stream.to_string())]);
        args.push(input.canonical_path.as_os_str().to_owned());
        {let mut sink=|bytes:&[u8]|verifier.feed(bytes,cancel);let mut ignore=|_|{};
            run_process_stream(&tool.path,"ffprobe",&args,self.settings.render_timeout,CaptureMode::Metrics,None,cancel,&mut ignore,Some(&mut sink))?;}
        let result=verifier.finish(cancel)?;
        if fingerprint(&tool.path,512*1024*1024,cancel)?!=tool.stamp{return Err(Error::ToolIdentityChanged);}
        self.revalidate_input(input,cancel)?;cancel.check()?;Ok(result)
    }
    fn publish_interchange(&self,source:&InputFile,protected:&[PathBuf],document:&crate::interchange::ExportDocument,destination:&Path,policy:&OutputPolicy,cancel:&Cancellation)->Result<PathBuf>{
        use std::io::Write;
        document.validate_destination(destination)?;
        let parent=destination.parent().ok_or(Error::InvalidInput("export parent"))?;
        if fs::canonicalize(parent).map_err(|_|Error::Io("canonical export directory"))?!=parent{return Err(Error::InvalidInput("native interchange requires a canonical destination directory"));}
        if document.bytes().len()>crate::interchange::MAX_EXPORT_BYTES||protected.len()>4096{return Err(Error::LimitExceeded("interchange publication bounds"));}
        let guard=||->Result<()>{for path in protected{
            if path==destination{return Err(Error::SameFile);}
            if path.exists()&&destination.exists()&&same_file::is_same_file(path,destination).map_err(|_|Error::Io("compare export protected paths"))?{return Err(Error::SameFile);}
        }Ok(())};
        let media_guard=||->Result<()>{self.revalidate_input(source,cancel)?;self.revalidate_input(&document.timeline().video.file,cancel)?;if let Some(a)=&document.timeline().audio{self.revalidate_input(&a.file,cancel)?;}Ok(())};
        cancel.check()?;guard()?;media_guard()?;
        let lease=self.stage_output(source,destination,policy,cancel)?;
        {let mut file=File::options().write(true).truncate(true).open(lease.path()).map_err(|_|Error::Io("open staged interchange"))?;
            for chunk in document.bytes().chunks(16384){cancel.check()?;file.write_all(chunk).map_err(|_|Error::Io("write interchange"))?;}
            file.sync_all().map_err(|_|Error::Io("sync interchange"))?;}
        let actual=fingerprint(lease.path(),crate::interchange::MAX_EXPORT_BYTES as u64,cancel)?;
        if actual.sha256!=document.sha256()||actual.size!=document.bytes().len() as u64{return Err(Error::InvalidOutput("staged interchange identity"));}
        media_guard()?;guard()?;lease.publish(cancel)
    }
}

#[cfg(test)]
mod release_boundary_tests {
    use super::*;
    #[test]
    fn cancelled_asset_read_does_not_open_path() {
        let c=Cancellation::new();c.cancel();
        assert!(matches!(read_selected_bytes(Path::new("/missing"),1024,&c),Err(Error::Cancelled)));
    }
    #[test]
    fn asset_read_rejects_oversize_without_loading_it() {
        let d=tempfile::tempdir().unwrap();let p=d.path().join("asset");
        fs::write(&p,b"12345").unwrap();
        assert!(matches!(read_selected_bytes(&p,4,&Cancellation::new()),Err(Error::LimitExceeded(_))));
        assert_eq!(read_selected_bytes(&p,5,&Cancellation::new()).unwrap(),b"12345");
    }
    #[test]
    fn selected_directory_is_rejected_by_reader() {
        let d=tempfile::tempdir().unwrap();
        assert!(open_regular_file(d.path()).is_err());
    }
    #[cfg(unix)]
    #[test]
    fn asset_read_rejects_symlink() {
        let d=tempfile::tempdir().unwrap();let p=d.path().join("asset");let l=d.path().join("link");
        fs::write(&p,b"123").unwrap();std::os::unix::fs::symlink(&p,&l).unwrap();
        assert!(read_selected_bytes(&l,1024,&Cancellation::new()).is_err());
    }

    #[test]
    fn cancelled_request_is_checked_before_spawn() {
        let cancel = Cancellation::new(); cancel.cancel();
        let result = run_process(Path::new("/not-a-real-media-tool"), "ffmpeg", &[],
            Duration::from_secs(1), CaptureMode::Text, None, &cancel, &mut |_| {});
        assert!(matches!(result, Err(Error::Cancelled)));
    }
    #[test]
    fn zero_deadline_is_checked_before_spawn() {
        let result = run_process(Path::new("/not-a-real-media-tool"), "ffmpeg", &[],
            Duration::ZERO, CaptureMode::Text, None, &Cancellation::new(), &mut |_| {});
        assert!(matches!(result, Err(Error::InvalidInput(_))));
    }
    #[cfg(unix)]
    #[test]
    fn successful_process_cannot_return_after_replacing_its_pinned_executable() {
        use std::os::unix::fs::PermissionsExt;
        let dir=tempfile::tempdir().unwrap();let path=dir.path().join("mutating-tool");
        fs::write(&path,b"#!/bin/sh\nprintf '\\n# changed\\n' >> \"$0\"\nprintf 'result\\n'\n").unwrap();
        fs::set_permissions(&path,fs::Permissions::from_mode(0o700)).unwrap();
        let cancel=Cancellation::new();let tool=pin(&path,&cancel).unwrap();
        let host=NativeMediaHost::new(NativeSettings::new(&path,&path)).unwrap();
        assert!(matches!(host.execute(&tool,"test",&[],Duration::from_secs(5),CaptureMode::Text,None,&cancel,&mut |_|{}),Err(Error::ToolIdentityChanged)));
    }
    #[cfg(unix)]
    #[test]
    fn shared_operation_deadline_interrupts_a_longer_native_task() {
        use std::os::unix::fs::PermissionsExt;
        let dir=tempfile::tempdir().unwrap();let path=dir.path().join("waiting-tool");
        fs::write(&path,b"#!/bin/sh\nwhile :; do :; done\n").unwrap();fs::set_permissions(&path,fs::Permissions::from_mode(0o700)).unwrap();
        let owner=Cancellation::new();let tool=pin(&path,&owner).unwrap();let host=NativeMediaHost::new(NativeSettings::new(&path,&path)).unwrap();
        let started=std::time::Instant::now();let cancel=owner.with_deadline(started+Duration::from_millis(50));
        assert!(matches!(host.execute(&tool,"test",&[],Duration::from_secs(30),CaptureMode::Text,None,&cancel,&mut |_|{}),Err(Error::Timeout)));
        assert!(started.elapsed()<Duration::from_secs(2));assert!(owner.check().is_ok());
    }
    #[cfg(unix)]
    #[test]
    fn staged_output_symlink_is_not_followed() {
        let dir = tempfile::tempdir().unwrap(); let real = dir.path().join("real");
        fs::write(&real, b"keep").unwrap(); let alias = dir.path().join("alias");
        std::os::unix::fs::symlink(&real, &alias).unwrap();
        assert!(matches!(check_output_limit(&Some((alias, 1024))), Err(Error::InvalidOutput(_))));
        assert_eq!(fs::read(real).unwrap(), b"keep");
    }
}

// Step 13B uses the existing runner; no new executable/permission path.
impl crate::speech_workflow::SpeechAudioHost for NativeMediaHost {
    fn stream_speech_audio(&self,request:&crate::speech_workflow::SpeechScan,cancel:&Cancellation,
        sink:&mut crate::speech_pipe::SpeechAudioSink<'_>)->Result<()> {
        cancel.check()?;self.revalidate_input(request.input(),cancel)?;
        let (ffmpeg,_)=self.pinned(cancel)?;
        if fingerprint(&ffmpeg.path,512*1024*1024,cancel)?!=ffmpeg.stamp{return Err(Error::ToolIdentityChanged);}
        let args=request.arguments()?;
        let pipe=std::cell::RefCell::new(crate::speech_pipe::SpeechPcmPipe::new(sink));
        run_process_dual_stream(&ffmpeg.path,"ffmpeg",&args,request.timeout().min(self.settings.render_timeout),
            CaptureMode::Metrics,None,cancel,&mut |_|{},
            Some(&mut |bytes|pipe.borrow_mut().pcm(bytes)),
            Some(&mut |bytes|pipe.borrow_mut().diagnostics(bytes)))?;
        pipe.into_inner().finish()?;
        if fingerprint(&ffmpeg.path,512*1024*1024,cancel)?!=ffmpeg.stamp{return Err(Error::ToolIdentityChanged);}
        self.revalidate_input(request.input(),cancel)?;cancel.check()
    }
}
