//! Face-detector orchestration on the existing timestamped low-resolution RGB path.
use crate::{Cancellation,Error,Rational,Result,VideoExtension};
use crate::color::{ColorMode,ColorSettings,CreativeLook};
use crate::color_workflow::VideoScan;
use crate::extension::emit;
use crate::face::{build_report,FaceDetector,FaceFramingReport,FaceInput,FaceSample,FaceSettings};
use crate::host::{MediaHost,ProgressSink};
use crate::model_pack::ModelActivation;
use crate::progress::{Progress,Stage};
use crate::project::Project;
use std::{path::PathBuf,time::{Duration,Instant}};

#[derive(Debug,Clone)]pub struct FaceFramingRequest{pub project_file:PathBuf,pub variant_id:String,pub settings:FaceSettings,pub timeout:Duration}
impl FaceFramingRequest{pub fn validate(&self)->Result<()>{if !self.project_file.is_absolute(){return Err(Error::InvalidInput("absolute project path required"));}crate::project::id_ok(&self.variant_id)?;self.settings.validate()?;if self.timeout.is_zero()||self.timeout>Duration::from_secs(86400){return Err(Error::InvalidInput("face analysis timeout"));}Ok(())}}

impl<H:MediaHost> VideoExtension<H>{
    pub fn analyze_faces(&self,project:&Project,request:&FaceFramingRequest,detector:&dyn FaceDetector,activation:&ModelActivation,cancel:&Cancellation,progress:&mut ProgressSink<'_>)->Result<FaceFramingReport>{
        project.validate()?;request.validate()?;activation.check()?;let started=Instant::now();
        let target=project.variant(&request.variant_id)?;target.framing.as_ref().ok_or(Error::InvalidProject("face framing requires an explicit output framing target"))?.validate(&project.sources[0])?;
        let detector_identity=std::panic::catch_unwind(std::panic::AssertUnwindSafe(||detector.identity().clone())).map_err(|_|Error::CallbackPanicked)?;detector_identity.validate()?;
        if &detector_identity!=activation.identity(){return Err(Error::InputChanged);}
        if !matches!(activation.identity().contract.as_str(),crate::model_pack::YUNET_CONTRACT|crate::model_pack::ULTRAFACE_CONTRACT){return Err(Error::Unsupported("face detector model contract"));}let scope=activation.scope(cancel)?;let owner=self.workflow_scope(&scope)?;let job=self.begin(&owner)?;let deadline=started.checked_add(request.timeout).ok_or(Error::LimitExceeded("face analysis deadline"))?;let operation_cancel=job.cancel.with_deadline(deadline);let cancel=&operation_cancel;let source=&project.sources[0];
        emit(progress,Stage::Inspecting)?;let input=self.host().inspect_input(&source.resolve(&request.project_file)?,cancel)?;source.check_input(&input)?;
        emit(progress,Stage::RuntimeCheck)?;let runtime=self.host().runtime_capabilities(cancel)?;let current=self.probe_path(&input.canonical_path,cancel,progress)?;source.check_media(&current)?;
        std::panic::catch_unwind(std::panic::AssertUnwindSafe(||detector.revalidate(cancel))).map_err(|_|Error::CallbackPanicked)??;activation.check()?;
        let mut color=ColorSettings::off();color.exposure=ColorMode::Off;color.gamma=ColorMode::Off;color.contrast=ColorMode::Off;color.saturation=ColorMode::Off;color.white_balance=ColorMode::Off;color.look=CreativeLook::None;color.analysis_width=192;color.analysis_height=192;color.max_analysis_seconds=u32::try_from(source.duration.ceil_units(1)?).unwrap_or(u32::MAX).min(14_400);color.max_frames=crate::color::MAX_VIDEO_FRAMES;color.max_shots=crate::color::MAX_COLOR_SHOTS;
        let scan=VideoScan::new(project,input.clone(),&color,request.timeout)?;scan.check_runtime(&runtime)?;let(width,height)=scan.dimensions();let interval=Rational::new(i64::from(request.settings.sample_interval_ms),1000)?;let mut next=Rational::new(0,1)?;let shots=crate::face::shot_ranges(project)?;let mut previous_shot=None;let mut last_pts=None;let mut samples=Vec::new();let mut last_second=-1i64;
        emit(progress,Stage::AnalyzingFaces)?;
        self.host().stream_video_frames(&scan,cancel,&mut |frame|{cancel.check()?;if started.elapsed()>=request.timeout{return Err(Error::Timeout);}activation.check()?;let at=frame.pts.checked_sub(source.timeline_origin)?;
            if frame.width!=width||frame.height!=height||frame.rgb.len()!=width as usize*height as usize*3||at.numerator()<0||at>=source.duration||last_pts.is_some_and(|p|at<=p){return Err(Error::InvalidOutput("face decoded frame shape or clock"));}last_pts=Some(at);
            let shot=shots.iter().position(|r|r.contains(at)).ok_or(Error::InvalidOutput("face frame outside shots"))?;
            if at<next&&previous_shot==Some(shot){return Ok(());}previous_shot=Some(shot);if samples.len()>=crate::face::MAX_FACE_SAMPLES{return Err(Error::LimitExceeded("face sample count"));}std::panic::catch_unwind(std::panic::AssertUnwindSafe(||detector.revalidate(cancel))).map_err(|_|Error::CallbackPanicked)??;let detections=std::panic::catch_unwind(std::panic::AssertUnwindSafe(||detector.detect(FaceInput{width,height,source_time:at,rgb:frame.rgb},cancel))).map_err(|_|Error::CallbackPanicked)??;if started.elapsed()>=request.timeout{return Err(Error::Timeout);}samples.push(FaceSample{at,detections});next=at.checked_add(interval)?;let sec=at.floor_units(1)?;if sec>last_second{let mut p=Progress::stage(Stage::AnalyzingFaces);p.out_time_us=Some(u64::try_from(at.ceil_units(1_000_000)?).map_err(|_|Error::LimitExceeded("face progress"))?);std::panic::catch_unwind(std::panic::AssertUnwindSafe(||progress(p))).map_err(|_|Error::CallbackPanicked)?;last_second=sec;}Ok(())})?;
        self.host().revalidate_input(&input,cancel)?;std::panic::catch_unwind(std::panic::AssertUnwindSafe(||detector.revalidate(cancel))).map_err(|_|Error::CallbackPanicked)??;activation.check()?;cancel.check()?;if started.elapsed()>=request.timeout{return Err(Error::Timeout);}let final_identity=std::panic::catch_unwind(std::panic::AssertUnwindSafe(||detector.identity().clone())).map_err(|_|Error::CallbackPanicked)?;if final_identity!=detector_identity{return Err(Error::InputChanged);}let mut report=build_report(project,&request.variant_id,samples,request.settings.clone(),activation)?;cancel.check()?;report.bind_owner(&owner);Ok(report)
    }
}

/// Registered only by a host that explicitly enables the face-model capability.
pub const FACE_ACTIONS:&[crate::extension::ActionDescriptor]=&[
    crate::extension::ActionDescriptor{id:"video.faces.analyze",label:"Analyze selected face model for framing and placement proposals",writes_output:false},
    crate::extension::ActionDescriptor{id:"video.faces.apply",label:"Adopt face framing as pending review keys",writes_output:false},
    crate::extension::ActionDescriptor{id:"video.faces.apply_choices",label:"Adopt selected face-safe anchors and punch-ins for review",writes_output:false},
];
