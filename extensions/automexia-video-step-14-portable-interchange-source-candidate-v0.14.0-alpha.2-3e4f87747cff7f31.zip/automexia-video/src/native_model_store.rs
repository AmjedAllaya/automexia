//! Optional local storage adapter for the existing component owner. A persistent
//! OS lock excludes another manager/process; projects never choose this directory.
use crate::model_pack::{hash, ModelManifest, VerifiedModelPack, MODEL_MANIFEST_LIMIT, MODEL_NOTICES_LIMIT};
use crate::model_store::{ModelInventory, ModelStorage, ModelStore, MODEL_INVENTORY_LIMIT};
use crate::{Cancellation, Error, Result};
use std::fs::{self, File, OpenOptions};
use std::io::Write;
use std::path::{Component, Path, PathBuf};

pub type NativeModelStore = ModelStore<NativeModelStorage>;
pub struct NativeModelStorage { root: PathBuf, packs: PathBuf, _lock: File }
impl NativeModelStorage {
    /// Root must be an explicitly chosen canonical directory in protected host
    /// storage. Creates that one directory, never recursively follows a path.
    /// On Unix the owner supplies a private directory (0700); created files are
    /// 0600. Other platforms require equivalent host-managed ACLs.
    pub fn open(root: &Path, cancel: &Cancellation) -> Result<Self> {
        cancel.check()?;
        absolute(root)?;
        let parent = root.parent().ok_or(Error::InvalidInput("model store parent"))?;
        canonical_directory(parent)?;
        create_private_dir(root)?;
        canonical_directory(root)?;
        #[cfg(unix)] {
            use std::os::unix::fs::PermissionsExt;
            if fs::metadata(root).map_err(|_| Error::Io("model store permissions"))?.permissions().mode() & 0o077 != 0 {
                return Err(Error::InvalidInput("model store must be private to its owner"));
            }
        }
        let lock_path = root.join("model-store.lock");
        let mut options = OpenOptions::new();
        options.read(true).write(true).create(true).truncate(false);
        #[cfg(unix)] {
            use std::os::unix::fs::OpenOptionsExt;
            options.mode(0o600).custom_flags(nix::libc::O_NOFOLLOW | nix::libc::O_NONBLOCK);
        }
        let lock = options.open(&lock_path).map_err(|_| Error::Io("open model store lock"))?;
        if !lock.metadata().map_err(|_| Error::Io("model lock metadata"))?.is_file()
            || fs::symlink_metadata(&lock_path).map_err(|_| Error::Io("model lock path"))?.file_type().is_symlink() {
            return Err(Error::InvalidInput("model store lock must be regular"));
        }
        fs2::FileExt::try_lock_exclusive(&lock).map_err(|e| {
            if e.kind() == std::io::ErrorKind::WouldBlock || (cfg!(windows) && e.raw_os_error() == Some(33)) { Error::Busy } else { Error::Io("lock model store") }
        })?;
        let packs = root.join("packs");
        create_private_dir(&packs)?;
        canonical_directory(&packs)?;
        cancel.check()?;
        Ok(Self { root: root.to_owned(), packs, _lock: lock })
    }
    pub fn into_store(self, cancel: &Cancellation) -> Result<NativeModelStore> { ModelStore::open(self, cancel) }
    fn pack_path(&self, manifest: &str) -> Result<PathBuf> { hash(manifest)?; Ok(self.packs.join(manifest)) }
}

/// Read only the three explicit local files, checking the externally pinned
/// manifest before allocating model bytes. Available with `native`, independently
/// of the optional ONNX runtime adapter (also used for RNNoise/whisper packs).
pub fn read_selected_pack(manifest: &Path, weights: &Path, notices: &Path, expected_manifest: &str, cancel: &Cancellation) -> Result<VerifiedModelPack> {
    hash(expected_manifest)?;
    cancel.check()?;
    for path in [manifest, weights, notices] { absolute(path)?; }
    let metadata = crate::native::read_selected_bytes(manifest, MODEL_MANIFEST_LIMIT as u64, cancel)?;
    if crate::model_pack::digest(&metadata, cancel)? != expected_manifest { return Err(Error::InputChanged); }
    let parsed = ModelManifest::from_json(&metadata)?;
    let data = crate::native::read_selected_bytes(weights, parsed.weights_bytes, cancel)?;
    let notices = crate::native::read_selected_bytes(notices, MODEL_NOTICES_LIMIT as u64, cancel)?;
    VerifiedModelPack::verify(&metadata, data, &notices, expected_manifest, cancel)
}

impl ModelStorage for NativeModelStorage {
    fn load_inventory(&self, cancel: &Cancellation) -> Result<ModelInventory> {
        cancel.check()?;
        let path = self.root.join("inventory.json");
        match fs::symlink_metadata(&path) {
            Err(e) if e.kind() == std::io::ErrorKind::NotFound => Ok(ModelInventory::default()),
            Err(_) => Err(Error::Io("model inventory metadata")),
            Ok(meta) if !meta.is_file() || meta.file_type().is_symlink() => Err(Error::InvalidInput("model inventory must be regular")),
            Ok(_) => ModelInventory::from_json(&crate::native::read_selected_bytes(&path, MODEL_INVENTORY_LIMIT as u64, cancel)?),
        }
    }
    fn read_pack(&self, manifest: &str, cancel: &Cancellation) -> Result<VerifiedModelPack> {
        let path = self.pack_path(manifest)?;
        canonical_directory(&path)?;
        read_selected_pack(&path.join("manifest.json"), &path.join("weights.bin"), &path.join("notices.txt"), manifest, cancel)
    }
    fn write_pack(&self, pack: &VerifiedModelPack, cancel: &Cancellation) -> Result<()> {
        cancel.check()?;
        let target = self.pack_path(&pack.identity().manifest_sha256)?;
        match fs::symlink_metadata(&target) {
            Ok(_) => {
                // An orphan from a cancelled install may be reused only after
                // its full content has been reverified against this exact pack.
                let existing = self.read_pack(&pack.identity().manifest_sha256, cancel)?;
                if existing.identity() != pack.identity() { return Err(Error::InputChanged); }
                return Ok(());
            }
            Err(e) if e.kind() == std::io::ErrorKind::NotFound => (),
            Err(_) => return Err(Error::Io("installed pack metadata")),
        }
        let staging = tempfile::Builder::new().prefix(".model-install-").tempdir_in(&self.packs)
            .map_err(|_| Error::Io("create model installation staging"))?;
        private_dir_permissions(staging.path())?;
        for (name, bytes) in [("manifest.json", pack.manifest_bytes()), ("weights.bin", pack.weights()), ("notices.txt", pack.notices())] {
            write_owned_file(&staging.path().join(name), bytes, cancel)?;
        }
        sync_directory(staging.path());
        cancel.check()?;
        fs::rename(staging.path(), &target).map_err(|_| Error::Io("publish immutable model pack"))?;
        sync_directory(&self.packs);
        // Commit is the directory rename. A later cancellation is observed by
        // inventory commit, leaving an unselected, verified orphan for retry.
        Ok(())
    }
    fn commit_inventory(&self, expected_generation: u64, next: &ModelInventory, cancel: &Cancellation) -> Result<()> {
        next.validate()?;
        if next.generation != expected_generation.checked_add(1).ok_or(Error::LimitExceeded("model inventory generation"))? {
            return Err(Error::InvalidInput("model inventory revision must advance once"));
        }
        if self.load_inventory(cancel)?.generation != expected_generation { return Err(Error::InputChanged); }
        let bytes = serde_json::to_vec_pretty(next).map_err(|_| Error::InvalidInput("encode model inventory"))?;
        if bytes.len() > MODEL_INVENTORY_LIMIT { return Err(Error::LimitExceeded("model inventory bytes")); }
        let mut staged = tempfile::Builder::new().prefix(".model-inventory-").tempfile_in(&self.root)
            .map_err(|_| Error::Io("stage model inventory"))?;
        staged.write_all(&bytes).map_err(|_| Error::Io("write model inventory"))?;
        staged.as_file().sync_all().map_err(|_| Error::Io("flush model inventory"))?;
        cancel.check()?;
        staged.persist(self.root.join("inventory.json")).map_err(|_| Error::Io("commit model inventory"))?;
        sync_directory(&self.root);
        Ok(())
    }
    fn remove_pack(&self, manifest: &str) -> bool {
        let Ok(path) = self.pack_path(manifest) else { return false; };
        if canonical_directory(&path).is_err() { return false; }
        // Remove only known owned names. Unexpected files are retained for host
        // inspection instead of recursively deleting an arbitrary directory.
        let Ok(entries) = fs::read_dir(&path) else { return false; };
        for entry in entries {
            let Ok(entry) = entry else { return false; };
            if !["manifest.json", "weights.bin", "notices.txt"].iter().any(|name| entry.file_name() == *name)
                || !entry.file_type().is_ok_and(|kind| kind.is_file() && !kind.is_symlink()) { return false; }
        }
        for name in ["manifest.json", "weights.bin", "notices.txt"] {
            if let Err(e) = fs::remove_file(path.join(name)) {
                if e.kind() != std::io::ErrorKind::NotFound { return false; }
            }
        }
        let removed = fs::remove_dir(&path).is_ok();
        if removed { sync_directory(&self.packs); }
        removed
    }
}
fn absolute(path: &Path) -> Result<()> {
    if !path.is_absolute() || path.components().any(|c| matches!(c, Component::ParentDir | Component::CurDir)) {
        return Err(Error::InvalidInput("absolute model storage path without traversal"));
    }
    Ok(())
}
fn canonical_directory(path: &Path) -> Result<()> {
    let meta = fs::symlink_metadata(path).map_err(|_| Error::Io("model directory metadata"))?;
    if !meta.is_dir() || meta.file_type().is_symlink() || fs::canonicalize(path).map_err(|_| Error::Io("resolve model directory"))? != path {
        return Err(Error::InvalidInput("canonical non-symlink model directory required"));
    }
    Ok(())
}
fn create_private_dir(path: &Path) -> Result<()> {
    let mut builder = fs::DirBuilder::new();
    #[cfg(unix)] { use std::os::unix::fs::DirBuilderExt; builder.mode(0o700); }
    match builder.create(path) {
        Ok(()) => Ok(()),
        Err(e) if e.kind() == std::io::ErrorKind::AlreadyExists => Ok(()),
        Err(_) => Err(Error::Io("create model storage directory")),
    }
}
fn private_dir_permissions(path: &Path) -> Result<()> {
    #[cfg(unix)] {
        use std::os::unix::fs::PermissionsExt;
        fs::set_permissions(path, fs::Permissions::from_mode(0o700)).map_err(|_| Error::Io("private model staging permissions"))?;
    }
    let _ = path;
    Ok(())
}
fn write_owned_file(path: &Path, bytes: &[u8], cancel: &Cancellation) -> Result<()> {
    let mut options = OpenOptions::new();
    options.create_new(true).write(true);
    #[cfg(unix)] { use std::os::unix::fs::OpenOptionsExt; options.mode(0o600); }
    let mut file = options.open(path).map_err(|_| Error::Io("create model pack file"))?;
    for chunk in bytes.chunks(64 * 1024) { cancel.check()?; file.write_all(chunk).map_err(|_| Error::Io("write model pack"))?; }
    file.sync_all().map_err(|_| Error::Io("flush model pack"))
}
fn sync_directory(path: &Path) {
    // Some target filesystems do not implement directory fsync. Never report a
    // failed transaction after the atomic rename has already made it visible.
    if let Ok(directory) = File::open(path) { let _ = directory.sync_all(); }
}
