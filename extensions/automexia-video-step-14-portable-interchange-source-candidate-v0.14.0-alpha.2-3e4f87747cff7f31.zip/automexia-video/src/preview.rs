//! Short, explicitly hypothetical A/B proxies. All rendering reuses MediaHost and
//! the real Step 2 edit planner. Proxies are private output leases, never delivery
//! files: dropping a PreviewSet removes both owned files through the host.
use crate::host::{InputFile, OutputLease, RuntimeCapabilities};
use crate::media::MediaInfo;
use crate::plan::{build_edited_plan, RenderPlan, SpeedPreset};
use crate::project::{Disposition, KeepClip, Project, TimeRange, Timeline};
use crate::review::{resolved_review_copy, ReviewBinding, ReviewTarget};
use crate::{Error, Rational, Result};
use serde::Serialize;
use sha2::{Digest, Sha256};
use std::path::{Path, PathBuf};

pub const MAX_PROXY_SECONDS: i64 = 30;
pub const MAX_PROXY_BYTES: u64 = 64 * 1024 * 1024;

#[derive(Debug, Clone, Serialize)]
pub struct PreviewOptions {
    /// Maximum duration of either proxy. For chronological edits this also
    /// bounds the source window; assembly review requires the whole sequence.
    pub max_window: Rational,
    pub context: Rational,
    pub max_width: u32,
    pub max_height: u32,
    /// Per file; pair <= 2 * max_bytes. The host also applies its stricter limit.
    pub max_bytes: u64,
}
impl Default for PreviewOptions {
    fn default() -> Self {
        Self { max_window: Rational::new(12,1).expect("constant"), context: Rational::new(2,1).expect("constant"),
            max_width: 640, max_height: 360, max_bytes: 32*1024*1024 }
    }
}
impl PreviewOptions {
    pub fn validate(&self) -> Result<()> {
        if !self.max_window.positive() || self.max_window > Rational::new(MAX_PROXY_SECONDS,1)?
            || self.context.numerator() < 0 || self.context > self.max_window {
            return Err(Error::InvalidInput("preview window must be positive and <=30 seconds, with bounded context"));
        }
        if self.max_width < 2 || self.max_width > 1280 || self.max_height < 2 || self.max_height > 720
            || self.max_width % 2 != 0 || self.max_height % 2 != 0 {
            return Err(Error::InvalidInput("preview bounds require even dimensions, at most 1280x720"));
        }
        if self.max_bytes < 1024 || self.max_bytes > MAX_PROXY_BYTES {
            return Err(Error::InvalidInput("preview file limit must be 1 KiB..64 MiB"));
        }
        Ok(())
    }
}
#[derive(Debug, Clone, Copy, Serialize)]
#[serde(tag="kind", content="time", rename_all="snake_case")]
pub enum PreviewFocus {
    /// Include the whole operation plus context; reject rather than crop silently.
    Whole,
    StartBoundary,
    EndBoundary,
    /// Exact source time relative to the selected video origin, not output time.
    At(Rational),
}
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize)]
#[serde(rename_all="snake_case")]
pub enum PreviewIntent {
    /// Only resolved current decisions; other pending proposals are disclosed.
    CurrentResolved,
    /// Apply ONLY the selected operation hypothetically, without approval/save.
    ApplySelected,
}
#[derive(Debug, Clone)]
pub struct PreviewRequest {
    pub project_file: PathBuf,
    pub scratch_directory: PathBuf,
    pub binding: ReviewBinding,
    pub target: ReviewTarget,
    /// Saved output variant whose timing/profile is being reviewed.
    pub variant_id: String,
    pub focus: PreviewFocus,
    pub intent: PreviewIntent,
    pub options: PreviewOptions,
}
impl PreviewRequest {
    pub fn new(project: &Project, project_file: impl Into<PathBuf>, scratch_directory: impl Into<PathBuf>, target: ReviewTarget) -> Result<Self> {
        project.validate()?;
        Ok(Self { project_file: project_file.into(), scratch_directory: scratch_directory.into(),
            binding: ReviewBinding::capture(project)?, variant_id: match &target{ReviewTarget::FramingVariant(id)|ReviewTarget::PresentationVariant(id)|ReviewTarget::TimingVariant(id)|ReviewTarget::AssemblyVariant(id)=>id.clone(),_=>project.variants[0].id.clone()}, target, focus: PreviewFocus::Whole,
            intent: PreviewIntent::ApplySelected, options: PreviewOptions::default() })
    }
    pub fn validate(&self, project: &Project) -> Result<()> {
        self.binding.check(project)?;
        self.options.validate()?;
        local_absolute(&self.project_file)?; local_absolute(&self.scratch_directory)?;
        if !self.project_file.extension().and_then(|s|s.to_str()).is_some_and(|s|s.eq_ignore_ascii_case("amxv")) {
            return Err(Error::InvalidInput("preview requires an absolute .amxv project location"));
        }
        if project.sources.len() != 1 { return Err(Error::Unsupported("review proxies currently support one source")); }
        if !project.variants.iter().any(|v| v.id == self.variant_id) {
            return Err(Error::InvalidInput("unknown preview output variant"));
        }
        if let ReviewTarget::FramingVariant(id)|ReviewTarget::PresentationVariant(id)|ReviewTarget::TimingVariant(id)|ReviewTarget::AssemblyVariant(id)=&self.target {
            if id!=&self.variant_id{return Err(Error::InvalidInput("variant preview must use its own output variant"));}
        }
        target_range(project, &self.target)?;
        Ok(())
    }
}
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize)]
#[serde(rename_all="snake_case")]
pub enum PreviewSide { Before, Proposed }

#[derive(Debug, Clone, Serialize)]
pub struct PreviewDescription {
    pub binding: ReviewBinding,
    pub target: ReviewTarget,
    /// Source-time coverage envelope. For assembly previews this may include
    /// unrendered gaps; the exact played intervals are in the two timelines.
    pub source_window: TimeRange,
    pub variant_id: String,
    pub coverage: PreviewFocus,
    pub intent: PreviewIntent,
    pub omitted_pending_ids: Vec<String>,
    pub before_timeline: Timeline,
    /// None means the proposed edit leaves no media in this window, not failure.
    pub proposed_timeline: Option<Timeline>,
    /// Request identity only. Not a persistent cache entry or runtime identity.
    pub request_key: String,
    pub audio_available: bool,
    pub notes: Vec<String>,
}

/// Pure preparation. Keeps derived proxy projects private, outside `.amxv`.
/// It never changes original dispositions, locks, revision or render history.
pub struct PreviewPlan {
    description: PreviewDescription,
    before: Project,
    proposed: Option<Project>,
    options: PreviewOptions,
    voice_reference: Project,
}
impl PreviewPlan {
    pub fn build(project: &Project, request: &PreviewRequest) -> Result<Self> {
        request.validate(project)?;
        let source = &project.sources[0];
        let operation_range = target_range(project, &request.target)?;
        let (mut candidate, mut omitted) = resolved_review_copy(project);
        if request.intent == PreviewIntent::ApplySelected {
            if let ReviewTarget::Operation(id) = &request.target {
                let old = project.operations.iter().find(|op| &op.id == id).ok_or(Error::InvalidProject("preview operation"))?;
                if old.locked && (!old.enabled || old.disposition != Disposition::AutoApply) { return Err(Error::LockedEdit); }
                let op = candidate.operations.iter_mut().find(|op| &op.id == id).ok_or(Error::InvalidProject("preview operation"))?;
                op.enabled = true; op.disposition = Disposition::AutoApply;
                // This is exactly the explicit approval semantics used by review.
                // A locked, already-applied decision is viewed with its existing
                // semantics. An unlocked explicit approval is a user override.
                if !old.locked { op.user_override = true; }
                omitted.retain(|other| other != id);
            }
        }
        if request.intent==PreviewIntent::ApplySelected {
            if let ReviewTarget::ColorShot(id)=&request.target {
                let old=project.settings.color_correction.as_ref().and_then(|p|p.shots.iter().find(|s|&s.id==id)).ok_or(Error::InvalidProject("preview color shot"))?;
                if old.locked&&(!old.enabled||old.disposition!=Disposition::AutoApply){return Err(Error::LockedEdit);}
                let profile=candidate.settings.color_correction.as_mut().ok_or(Error::InvalidProject("preview color profile"))?;
                profile.enabled=true;
                let shot=profile.shots.iter_mut().find(|s|&s.id==id).ok_or(Error::InvalidProject("preview color shot"))?;
                shot.enabled=true;shot.disposition=Disposition::AutoApply;
                omitted.retain(|s|s!=&format!("color:{id}"));
            }
        }
        if request.intent==PreviewIntent::ApplySelected {
            if let ReviewTarget::FramingVariant(id)=&request.target {
                let old=project.variant(id)?.framing.as_ref().ok_or(Error::InvalidProject("preview framing"))?;
                if old.locked&&(!old.enabled||old.disposition!=Disposition::AutoApply){return Err(Error::LockedEdit);}
                let f=candidate.variants.iter_mut().find(|v|&v.id==id).and_then(|v|v.framing.as_mut()).ok_or(Error::InvalidProject("preview framing"))?;
                f.enabled=true;f.disposition=Disposition::AutoApply;omitted.retain(|s|s!=&format!("framing:{id}"));
            }
        }
        if request.intent==PreviewIntent::ApplySelected {
            if let ReviewTarget::TimingVariant(id)=&request.target {
                let old=project.variant(id)?.timing.as_ref().ok_or(Error::InvalidProject("preview timing"))?;
                if old.locked&&(!old.enabled||old.disposition!=Disposition::AutoApply){return Err(Error::LockedEdit);}
                let t=candidate.variants.iter_mut().find(|v|&v.id==id).and_then(|v|v.timing.as_mut()).ok_or(Error::InvalidProject("preview timing"))?;
                t.enabled=true;t.disposition=Disposition::AutoApply;omitted.retain(|s|s!=&format!("timing:{id}"));
            }
        }
        if request.intent==PreviewIntent::ApplySelected {
            if let ReviewTarget::AssemblyVariant(id)=&request.target {
                let old=project.variant(id)?.assembly.as_ref().ok_or(Error::InvalidProject("preview assembly"))?;
                if old.locked&&(!old.enabled||old.disposition!=Disposition::AutoApply){return Err(Error::LockedEdit);}
                let assembly=candidate.variants.iter_mut().find(|v|&v.id==id).and_then(|v|v.assembly.as_mut()).ok_or(Error::InvalidProject("preview assembly"))?;
                assembly.enabled=true;assembly.disposition=Disposition::AutoApply;
                omitted.retain(|s|s!=&format!("assembly:{id}"));
            }
        }
        if request.intent==PreviewIntent::ApplySelected {
            if let ReviewTarget::PresentationVariant(id)=&request.target {
                let old=project.variant(id)?.presentation.as_ref().ok_or(Error::InvalidProject("preview presentation"))?;
                if old.locked&&(!old.enabled||old.disposition!=Disposition::AutoApply){return Err(Error::LockedEdit);}
                let p=candidate.variants.iter_mut().find(|v|&v.id==id).and_then(|v|v.presentation.as_mut()).ok_or(Error::InvalidProject("preview presentation"))?;
                p.enabled=true;p.disposition=Disposition::AutoApply;omitted.retain(|s|s!=&format!("presentation:{id}"));
            }
        }
        // Reordering/repetition cannot be represented by clipping one source
        // window: that loses occurrences or changes the reviewed sequence.
        let assembly_preview=candidate.variant(&request.variant_id)?.assembly.as_ref().is_some_and(|a|a.active())
            || matches!(&request.target,ReviewTarget::AssemblyVariant(_));
        let (mut before,proposed,window,requested_window)=if assembly_preview {
            if !matches!(request.focus,PreviewFocus::Whole) {
                return Err(Error::Unsupported("assembly previews require whole-sequence coverage; source-time boundary focuses do not identify a unique occurrence"));
            }
            let ranges=assembly_before_ranges(&candidate,&request.variant_id)?;
            let window=TimeRange::new(ranges.first().ok_or(Error::EmptyTimeline)?.start,ranges.last().ok_or(Error::EmptyTimeline)?.end)?;
            let before=fragment(project,&ranges,&request.variant_id)?;
            let proposed=match candidate.timeline_for_variant(&request.variant_id) {
                Ok(_)=>Some(whole_variant_fragment(&candidate,&request.variant_id)?),
                Err(Error::EmptyTimeline)=>None,Err(error)=>return Err(error),
            };
            (before,proposed,window,window)
        } else {
            let requested_window=preview_window(source.duration,operation_range,request.focus,&request.options)?;
            let window=timing_preview_window(&candidate,&request.variant_id,requested_window,&request.options)?;
            let before=fragment(project,&[window],&request.variant_id)?;
            let ranges=match candidate.timeline() {
                Ok(timeline)=>timeline.segments.iter().filter_map(|s| {
                    let start=s.source_range.start.max(window.start);let end=s.source_range.end.min(window.end);
                    (start<end).then_some(TimeRange{start,end})
                }).collect::<Vec<_>>(),
                Err(Error::EmptyTimeline)=>vec![],Err(error)=>return Err(error),
            };
            let proposed=if ranges.is_empty(){None}else{Some(resolved_fragment(&candidate,window,&request.variant_id)?)};
            (before,proposed,window,requested_window)
        };
        before.settings.voice_cleanup=None;before.settings.voice_enhancement=None;
        before.settings.color_correction=None;
        for variant in &mut before.variants{variant.framing=None;variant.presentation=None;variant.timing=None;variant.assembly=None;}
        let before_timeline=before.timeline_for_variant("preview")?;
        let proposed_timeline=proposed.as_ref().map(|p|p.timeline_for_variant("preview")).transpose()?;
        if before_timeline.duration>request.options.max_window
            || proposed_timeline.as_ref().is_some_and(|t|t.duration>request.options.max_window) {
            return Err(Error::Unsupported("the complete proposed or original proxy exceeds its duration budget; enlarge the preview limit, up to thirty seconds"));
        }
        let options_bytes = serde_json::to_vec(&(&request.binding, &request.target, window, &request.variant_id, request.focus, request.intent, &request.options))
            .map_err(|_|Error::InvalidProject("preview identity"))?;
        let request_key = format!("{:x}", Sha256::digest(options_bytes));
        let description = PreviewDescription {
            binding: request.binding.clone(), target: request.target.clone(), source_window: window,
            variant_id: request.variant_id.clone(), coverage: request.focus, intent: request.intent, omitted_pending_ids: omitted,
            before_timeline, proposed_timeline,
            request_key, audio_available: source.media.audio.is_some(),
            notes: vec![
                if assembly_preview {
                    "Before is the selected source coverage once in chronological order at normal speed, with effects disabled. Proposed preserves every assembly occurrence, its reviewed speed, and resolved processing. Both proxies cover their complete sequences.".into()
                } else if request.intent == PreviewIntent::ApplySelected {
                    "Before is original footage in the source window; proposed includes the selected hypothetical approval plus resolved edits.".into()
                } else {
                    "Before is original footage in the source window; proposed includes only currently resolved edits, not an extra hypothetical approval.".into()
                },
                if assembly_preview {"The displayed source window is a coverage envelope; distant gaps are not played. Exact chronological and assembled intervals are disclosed in the before/proposed timelines.".into()}else if window!=requested_window {"Timing preview boundaries were aligned to the source frame clock and retained dissolve handles; the displayed source window records the exact coverage.".into()}else{"Preview coverage uses the displayed source-time window.".into()},
                "A proxy is not an approval, a saved project or final delivery media. Other pending decisions, if listed, are omitted only from this review.".into(),
                if source.media.audio.is_some(){"Both MP4s carry the selected audio for A/B listening; cuts, repeats and speed changes mean their elapsed playback positions are not source-time equivalents.".into()}else{"The selected source has no audio; these are video-only proxies.".into()},
                "Bounded output duration/resolution does not guarantee fast seeking: the shared decoder may scan preceding footage, subject to the existing host deadline.".into(),
            ],
        };
        Ok(Self { description, before, proposed, options: request.options.clone(), voice_reference:candidate })
    }
    /// Measure the full candidate's accepted audio, not a short proxy window.
    /// This preserves the final-render gain while users compare A/B excerpts.
    pub(crate) fn voice_reference_plan(&self,current:&MediaInfo,runtime:&RuntimeCapabilities)->Result<Option<RenderPlan>> {
        if self.proposed.is_none()||!self.voice_reference.settings.voice_cleanup.as_ref().is_some_and(|p|p.active()){return Ok(None);}
        Ok(Some(crate::plan::build_audio_plan(&self.voice_reference,&self.description.variant_id,current,runtime)?))
    }
    pub fn description(&self) -> &PreviewDescription { &self.description }
    pub fn options(&self) -> &PreviewOptions { &self.options }
    pub fn render_plan(&self, side: PreviewSide, current: &MediaInfo, runtime: &RuntimeCapabilities) -> Result<Option<RenderPlan>> {
        let project = match side { PreviewSide::Before => Some(&self.before), PreviewSide::Proposed => self.proposed.as_ref() };
        project.map(|project| {
            let plan = build_edited_plan(project, "preview", current, runtime)?;
            plan.for_review_proxy(self.options.max_width, self.options.max_height, self.options.max_bytes, runtime)
        }).transpose()
    }
}

#[derive(Debug, Clone, Serialize)]
pub struct ProxyMetadata {
    pub side: PreviewSide,
    pub duration: Rational,
    pub width: u32,
    pub height: u32,
    pub sample_aspect_ratio: Rational,
    pub byte_length: u64,
    pub sha256: String,
    pub full_decode_validated: bool,
    pub audio_available: bool,
    pub audio:Option<crate::voice_render::AudioRenderReport>,
}
pub(crate) struct ProxyClip {
    pub(crate) presentation:Option<Box<dyn crate::presentation_render::PresentationLease>>,
    pub(crate) lease: Box<dyn OutputLease>,
    pub(crate) identity: InputFile,
    pub(crate) metadata: ProxyMetadata,
}
/// Keep alive while the host plays a proxy; Drop cleans only the owned leases.
/// No automatic unbounded disk cache, no global retained preview registry.
pub struct PreviewSet {
    pub(crate) source: InputFile,
    pub(crate) description: PreviewDescription,
    pub(crate) runtime: RuntimeCapabilities,
    pub(crate) before: ProxyClip,
    pub(crate) proposed: Option<ProxyClip>,
}
impl PreviewSet {
    pub fn description(&self) -> &PreviewDescription { &self.description }
    pub fn runtime(&self) -> &RuntimeCapabilities { &self.runtime }
    pub fn metadata(&self, side: PreviewSide) -> Option<&ProxyMetadata> { self.clip(side).map(|c| &c.metadata) }
    pub fn check_current(&self, project: &Project) -> Result<()> { self.description.binding.check(project) }
    pub fn retained_bytes(&self) -> u64 {
        self.before.metadata.byte_length + self.proposed.as_ref().map(|p|p.metadata.byte_length).unwrap_or(0)
    }
    pub(crate) fn clip(&self, side: PreviewSide) -> Option<&ProxyClip> {
        match side { PreviewSide::Before => Some(&self.before), PreviewSide::Proposed => self.proposed.as_ref() }
    }
}

/// Borrowed, revalidated proxy. The host must keep the owning PreviewSet alive
/// for playback and close playback before dropping its leases.
pub struct VerifiedPreview<'a> {
    pub(crate) file: &'a InputFile,
    pub(crate) metadata: &'a ProxyMetadata,
    pub(crate) description: &'a PreviewDescription,
}
impl<'a> VerifiedPreview<'a> {
    pub fn file(&self) -> &'a InputFile { self.file }
    pub fn metadata(&self) -> &'a ProxyMetadata { self.metadata }
    pub fn description(&self) -> &'a PreviewDescription { self.description }
}
/// Map to an ALREADY approved playback/file-open facility. No OS opener, shell,
/// executable path, browser widget or player is invented by this library.
pub trait PreviewOpener {
    fn open(&mut self, preview: &VerifiedPreview<'_>) -> Result<()>;
}

fn fragment(parent: &Project, ranges: &[TimeRange], variant_id: &str) -> Result<Project> {
    let mut result = parent.clone();
    result.renders.clear(); result.operations.clear();
    result.assembly = ranges.iter().enumerate().map(|(i,range)| KeepClip {
        id: format!("proxy-clip-{i}"), source_id: parent.sources[0].id.clone(), range: *range, locked: false,
    }).collect();
    let mut settings = parent.variants.iter().find(|v|v.id == variant_id)
        .ok_or(Error::InvalidInput("unknown preview output variant"))?.render.clone();
    settings.crf = 28; settings.speed = SpeedPreset::Fast; settings.threads = settings.threads.min(2);
    result.variants = vec![crate::project::OutputVariant { assembly:None, timing:parent.variant(variant_id)?.timing.clone(), output_profile:None,presentation:parent.variant(variant_id)?.presentation.clone(), id: "preview".into(), render: settings, framing:parent.variant(variant_id)?.framing.clone() }];
    result.validate()?;
    Ok(result)
}
// Build one complete selected variant without clipping its source-time
// settings, source bindings, enhancement reference or operation ownership.
fn whole_variant_fragment(parent:&Project,variant_id:&str)->Result<Project>{
    let mut result=parent.clone();result.renders.clear();
    let mut variant=parent.variant(variant_id)?.clone();
    variant.id="preview".into();variant.output_profile=None;
    variant.render.crf=28;variant.render.speed=SpeedPreset::Fast;variant.render.threads=variant.render.threads.min(2);
    result.variants=vec![variant];result.validate()?;Ok(result)
}
// The before side plays each selected original interval once, chronologically.
// Intersect with the authored keep list, but retain operation removals so the
// A/B comparison can still reveal the selected hypothetical cut.
fn assembly_before_ranges(parent:&Project,variant_id:&str)->Result<Vec<TimeRange>>{
    let mut ranges=vec![];
    if let Some(assembly)=parent.variant(variant_id)?.assembly.as_ref().filter(|a|a.active()) {
        for entry in &assembly.clips {for keep in &parent.assembly {
            let start=entry.range.start.max(keep.range.start);let end=entry.range.end.min(keep.range.end);
            if start<end{ranges.push(TimeRange::new(start,end)?);}
        }}
    }else{ranges.extend(parent.assembly.iter().map(|clip|clip.range));}
    ranges.sort_by_key(|range|(range.start,range.end));
    let mut merged:Vec<TimeRange>=vec![];
    for range in ranges {if let Some(last)=merged.last_mut(){if range.start<=last.end{last.end=last.end.max(range.end);continue;}}merged.push(range);}
    if merged.is_empty(){return Err(Error::EmptyTimeline);}Ok(merged)
}
// Preserve the original operation ownership for sample fades. Converting the
// already-cut output into new keep ranges loses the evidence that a gap came
// from a pause decision and can change the proposed preview's audio treatment.
fn resolved_fragment(parent:&Project,window:TimeRange,variant_id:&str)->Result<Project>{
    let mut result=fragment(parent,&[window],variant_id)?;
    result.operations=parent.operations.clone();
    result.assembly=parent.assembly.iter().filter_map(|clip|{let start=clip.range.start.max(window.start);let end=clip.range.end.min(window.end);if start>=end{None}else{let mut copy=clip.clone();copy.range=TimeRange{start,end};Some(copy)}}).collect();
    result.validate()?;Ok(result)
}
pub(crate) fn target_range(project: &Project, target: &ReviewTarget) -> Result<TimeRange> {
    match target {
        ReviewTarget::Clip(id) => project.assembly.iter().find(|clip| &clip.id == id).map(|clip|clip.range),
        ReviewTarget::Operation(id) => project.operations.iter().find(|op| &op.id == id).map(|op|op.range),
        ReviewTarget::ColorShot(id) => project.settings.color_correction.as_ref().and_then(|p|p.shots.iter().find(|s|&s.id==id)).map(|s|s.range),
        ReviewTarget::AssemblyVariant(id) => project.variants.iter().find(|v|&v.id==id&&v.assembly.is_some()).map(|_|TimeRange{start:Rational::new(0,1).expect("constant"),end:project.sources[0].duration}),
        ReviewTarget::TimingVariant(id) => project.variants.iter().find(|v|&v.id==id&&v.timing.is_some()).map(|_|TimeRange{start:Rational::new(0,1).expect("constant"),end:project.sources[0].duration}),
        ReviewTarget::PresentationVariant(id) => project.variants.iter().find(|v|&v.id==id&&v.presentation.is_some()).map(|_|TimeRange{start:Rational::new(0,1).expect("constant"),end:project.sources[0].duration}),
        ReviewTarget::FramingVariant(id) => project.variants.iter().find(|v|&v.id==id&&v.framing.is_some()).map(|_|TimeRange{start:Rational::new(0,1).expect("constant"),end:project.sources[0].duration}),
    }.ok_or(Error::InvalidInput("unknown review target"))
}
fn preview_window(duration: Rational, range: TimeRange, focus: PreviewFocus, options: &PreviewOptions) -> Result<TimeRange> {
    options.validate()?;
    let zero = Rational::new(0,1)?;
    if let PreviewFocus::Whole = focus {
        let start = range.start.checked_sub(options.context)?.max(zero);
        let end = range.end.checked_add(options.context)?.min(duration);
        if end.checked_sub(start)? > options.max_window {
            return Err(Error::InvalidInput("whole edit exceeds preview window; select start, end or a source-time focus"));
        }
        return TimeRange::new(start, end);
    }
    let center = match focus { PreviewFocus::StartBoundary => range.start, PreviewFocus::EndBoundary => range.end,
        PreviewFocus::At(time) => time, PreviewFocus::Whole => unreachable!() };
    if center < zero || center > duration { return Err(Error::InvalidInput("preview focus outside source")); }
    let span = options.max_window.min(duration);
    let half = span.checked_div(Rational::new(2,1)?)?;
    let start = center.checked_sub(half)?.max(zero).min(duration.checked_sub(span)?);
    TimeRange::new(start, start.checked_add(span)?)
}
pub(crate) fn local_absolute(path: &Path) -> Result<()> {
    if !path.is_absolute() || path.components().any(|c|matches!(c, std::path::Component::ParentDir))
        || path.as_os_str().is_empty() || path.to_string_lossy().contains("://") {
        return Err(Error::InvalidInput("an explicit absolute local path without parent traversal is required"));
    }
    Ok(())
}

/// Quantize only a hypothetical preview window. Authored cuts and timing intent
/// remain unchanged. Doubled playback needs paired source frames; dissolved
/// boundary fragments need the same handles required by the full render.
fn timing_preview_window(project:&Project,variant:&str,window:TimeRange,options:&PreviewOptions)->Result<TimeRange>{
    let Some(timing)=project.variant(variant)?.timing.as_ref().filter(|t|t.active()) else{return Ok(window)};
    if timing.speed==crate::timing::PlaybackSpeed::Normal&&!timing.dissolve.positive(){return Ok(window);}
    let timeline=project.timeline()?;
    timing.apply(&timeline)?;
    let video=&project.sources[0].media.video;
    let rate=video.nominal_frame_rate.or(video.average_frame_rate).ok_or(Error::Unsupported("timing preview requires a known source frame rate"))?;
    let edit_rate=crate::interchange::EditRate::new(rate,false)?;
    let mut start=window.start.checked_mul(rate)?.ceil_units(1)?;
    let mut end=window.end.checked_mul(rate)?.floor_units(1)?;
    let quantum=if timing.speed==crate::timing::PlaybackSpeed::Double{2}else{1};
    let mut clips=Vec::new();
    for segment in &timeline.segments {
        let first=edit_rate.exact_frames(segment.source_range.start)?;
        let last=edit_rate.exact_frames(segment.source_range.end)?;
        if last<=start||first>=end{continue;}
        if start>first {start=first+(start-first+quantum-1)/quantum*quantum;}
        if end<last {end=first+(end-first)/quantum*quantum;}
        if first.max(start)<last.min(end){clips.push((first,last));}
    }
    if timing.dissolve.positive()&&clips.len()>1 {
        let minimum=timing.dissolve.ticks(2)?.checked_mul(timing.speed.ratio())?.checked_mul(rate)?.ceil_units(1)?;
        let (first,last)=clips[0];let retained_end=last.min(end);
        if retained_end-first.max(start)<minimum {start=(retained_end-minimum).max(first);}
        let (first,last)=clips[clips.len()-1];let retained_start=first.max(start);
        if last.min(end)-retained_start<minimum {end=(retained_start+minimum).min(last);}
    }
    if start>=end{return Err(Error::Unsupported("timing preview window contains no complete output frame; enlarge the window"));}
    let result=TimeRange::new(Rational::new(start,1)?.checked_div(rate)?,Rational::new(end,1)?.checked_div(rate)?)?;
    if result.duration()?>options.max_window{return Err(Error::Unsupported("timing preview needs more dissolve handles than its source-window budget; enlarge the window"));}
    Ok(result)
}
