//! Strict JSON values for project import. Serde's normal Value map accepts a
//! repeated key using last-write-wins, which is inappropriate for edit intent.
use serde::{de::{self, MapAccess, SeqAccess, Visitor}, Deserialize, Deserializer};
use serde_json::{Map, Number, Value};
use std::fmt;
use crate::{Error, Result};
struct Unique(Value);
impl<'de> Deserialize<'de> for Unique {
    fn deserialize<D:Deserializer<'de>>(d:D)->std::result::Result<Self,D::Error>{
        struct V;
        impl<'de> Visitor<'de> for V {
            type Value=Unique;
            fn expecting(&self,f:&mut fmt::Formatter)->fmt::Result{f.write_str("JSON without duplicate keys")}
            fn visit_bool<E:de::Error>(self,v:bool)->std::result::Result<Unique,E>{Ok(Unique(Value::Bool(v)))}
            fn visit_i64<E:de::Error>(self,v:i64)->std::result::Result<Unique,E>{Ok(Unique(Value::Number(v.into())))}
            fn visit_u64<E:de::Error>(self,v:u64)->std::result::Result<Unique,E>{Ok(Unique(Value::Number(v.into())))}
            fn visit_f64<E:de::Error>(self,v:f64)->std::result::Result<Unique,E>{Number::from_f64(v).map(|n|Unique(Value::Number(n))).ok_or_else(||E::custom("non-finite number"))}
            fn visit_str<E:de::Error>(self,v:&str)->std::result::Result<Unique,E>{Ok(Unique(Value::String(v.into())))}
            fn visit_string<E:de::Error>(self,v:String)->std::result::Result<Unique,E>{Ok(Unique(Value::String(v)))}
            fn visit_unit<E:de::Error>(self)->std::result::Result<Unique,E>{Ok(Unique(Value::Null))}
            fn visit_none<E:de::Error>(self)->std::result::Result<Unique,E>{Ok(Unique(Value::Null))}
            fn visit_seq<A:SeqAccess<'de>>(self,mut a:A)->std::result::Result<Unique,A::Error>{let mut v=Vec::new();while let Some(Unique(x))=a.next_element()?{v.push(x);}Ok(Unique(Value::Array(v)))}
            fn visit_map<A:MapAccess<'de>>(self,mut a:A)->std::result::Result<Unique,A::Error>{
                let mut v=Map::new();while let Some(k)=a.next_key::<String>()?{if v.contains_key(&k){return Err(de::Error::custom("duplicate key"));}let Unique(x)=a.next_value()?;v.insert(k,x);}Ok(Unique(Value::Object(v)))
            }
        }
        d.deserialize_any(V)
    }
}
pub(crate) fn parse_unique(bytes:&[u8])->Result<Value>{
    let value:Unique=serde_json::from_slice(bytes).map_err(|_|Error::InvalidProject("malformed JSON or duplicate field"))?;Ok(value.0)
}
