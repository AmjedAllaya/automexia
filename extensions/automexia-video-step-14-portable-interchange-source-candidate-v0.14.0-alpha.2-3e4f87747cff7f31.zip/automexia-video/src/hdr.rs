//! A bounded HDR preservation route. Encoded video is copied and then proved
//! identical by packet/header hashes, decoded pixels, exact clocks and metadata.
use crate::{Cancellation,Error,Rational,Result};
use crate::host::{words,InputFile};
use crate::project::{Project,TimeRange};
use crate::interchange::EditRate;
use serde::Serialize;
use serde_json::Value;
use std::{ffi::OsString,path::{Path,PathBuf},time::Duration};

pub use crate::hdr_workflow::{HdrRequest,HdrResult};

pub const MAX_HDR_FRAMES:usize=20_000;
pub const MAX_HDR_EVIDENCE_BYTES:usize=8*1024*1024;
#[derive(Debug,Clone,Serialize)]
pub struct HdrPlan {
    pub(crate) range:TimeRange,pub(crate) origin:Rational,pub(crate) source_duration:Rational,
    pub(crate) rate:EditRate,pub(crate) stream:u32,pub(crate) width:u32,pub(crate) height:u32,
    pub(crate) movie_timescale:u32,pub(crate) transfer:String,pub(crate) sample_aspect_ratio:Rational,
}
impl HdrPlan {
    pub fn from_project(project:&Project,variant:&str)->Result<Self>{
        project.validate()?;let selected=project.variant(variant)?;
        if let Some(color)=&project.settings.color_correction{color.ensure_resolved()?;if color.active_count()>0{return Err(Error::Unsupported("HDR color processing is not qualified"));}}
        if let Some(f)=&selected.framing{f.ensure_resolved()?;if f.active(){return Err(Error::Unsupported("HDR framing is not qualified"));}}
        if let Some(p)=&selected.presentation{p.ensure_resolved()?;if p.active()&&(p.has_pixels()||p.fades.is_some()){return Err(Error::Unsupported("HDR graphics/fades are not qualified"));}}
        if let Some(t)=&selected.timing{t.ensure_resolved()?;if t.active()&&(t.speed!=crate::timing::PlaybackSpeed::Normal||t.dissolve.positive()){return Err(Error::Unsupported("HDR speed and dissolves require a separate qualified renderer"));}}
        let timeline=project.timeline_for_variant(variant)?;
        if timeline.segments.len()!=1{return Err(Error::Unsupported("HDR preservation requires one contiguous retained source interval"));}
        if timeline.segments[0].source_range.duration()?!=timeline.segments[0].output_range.duration()?{return Err(Error::Unsupported("HDR preservation cannot apply per-clip playback speed"));}
        let source=&project.sources[0];qualify_stream(&source.media.video)?;
        if !source.media.format_names.iter().any(|s|s=="mov"||s=="mp4"){return Err(Error::Unsupported("HDR packet preservation is limited to MOV/MP4 sources"));}
        let v=&source.media.video;
        let rate=EditRate::new(v.nominal_frame_rate.ok_or(Error::Unsupported("HDR nominal frame rate required"))?,false)?;
        if matches!(selected.render.frame_rate,crate::FrameRateMode::Constant(requested) if requested != rate.fps) {
            return Err(Error::Unsupported("HDR preservation cannot change the selected frame rate"));
        }
        let count=rate.exact_frames(source.duration)?;
        if count<=0||count as u64>MAX_HDR_FRAMES as u64{return Err(Error::LimitExceeded("HDR full-source verification frame budget"));}
        let range=timeline.segments[0].source_range;rate.exact_frames(range.start)?;rate.exact_frames(range.end)?;
        let absolute=source.timeline_origin.checked_add(range.start)?;
        exact_microseconds(absolute)?;exact_microseconds(range.duration()?)?;
        let movie_timescale=movie_timescale(rate.fps.numerator(),source.media.audio.as_ref().and_then(|a|a.sample_rate))?;
        Ok(Self{range,origin:source.timeline_origin,source_duration:source.duration,rate,stream:v.index,width:v.width.unwrap(),height:v.height.unwrap(),movie_timescale,transfer:v.color_transfer.clone().unwrap(),sample_aspect_ratio:v.sample_aspect_ratio.unwrap()})
    }
    pub fn duration(&self)->Result<Rational>{self.range.duration()}
    pub fn retained_range(&self)->TimeRange{self.range}
    pub fn is_trim(&self)->bool{self.range.start.numerator()!=0||self.range.end!=self.source_duration}
    pub fn frames(&self)->Result<usize>{usize::try_from(self.rate.exact_frames(self.duration()?)?).map_err(|_|Error::LimitExceeded("HDR frame count"))}
}
fn movie_timescale(fps_numerator:i64,audio:Option<u32>)->Result<u32>{
    let a=u64::try_from(fps_numerator).map_err(|_|Error::InvalidInput("HDR frame rate"))?;let b=u64::from(audio.unwrap_or(1));
    if a==0||b==0{return Err(Error::InvalidInput("HDR timescale"));}let(mut x,mut y)=(a,b);while y!=0{let r=x%y;x=y;y=r;}
    let result=a.checked_div(x).and_then(|v|v.checked_mul(b)).ok_or(Error::LimitExceeded("HDR movie timescale"))?;
    if result>i32::MAX as u64{return Err(Error::LimitExceeded("HDR movie timescale"));}Ok(result as u32)
}
fn exact_microseconds(time:Rational)->Result<i64>{let n=time.checked_mul(Rational::new(1_000_000,1)?)?;if n.denominator()!=1||n.numerator()<0{return Err(Error::Unsupported("HDR seek/duration must be exactly representable in FFmpeg's microsecond clock"));}Ok(n.numerator())}
fn decimal(time:Rational)->Result<String>{let us=exact_microseconds(time)?;Ok(format!("{}.{:06}",us/1_000_000,us%1_000_000))}
fn local(path:&Path)->Result<()>{if !path.is_absolute()||path.components().any(|c|matches!(c,std::path::Component::ParentDir|std::path::Component::CurDir))||path.as_os_str().as_encoded_bytes().contains(&0){return Err(Error::InvalidInput("absolute normalized HDR path"));}Ok(())}

#[derive(Debug,Clone)]
pub enum HdrTask {
    Summary{input:InputFile,audio_only:bool,timeout:Duration},
    ValidateDecode{input:InputFile,has_audio:bool,timeout:Duration},
    Packets{input:InputFile,stream:u32,timeout:Duration},Frames{input:InputFile,stream:u32,timeout:Duration},Pixels{input:InputFile,stream:u32,time_base:Rational,timeout:Duration},
    Mux{input:InputFile,audio:Option<InputFile>,output:PathBuf,plan:HdrPlan,timeout:Duration},
}
impl HdrTask {
    pub fn timeout(&self)->Duration{match self{Self::Summary{timeout,..}|Self::ValidateDecode{timeout,..}|Self::Packets{timeout,..}|Self::Frames{timeout,..}|Self::Pixels{timeout,..}|Self::Mux{timeout,..}=>*timeout}}
    pub fn input(&self)->&InputFile{match self{Self::Summary{input,..}|Self::ValidateDecode{input,..}|Self::Packets{input,..}|Self::Frames{input,..}|Self::Pixels{input,..}|Self::Mux{input,..}=>input}}
    pub fn additional_input(&self)->Option<&InputFile>{match self{Self::Mux{audio,..}=>audio.as_ref(),_=>None}}
    pub fn output(&self)->Option<&Path>{match self{Self::Mux{output,..}=>Some(output),_=>None}}
    pub fn tool_name(&self)->&'static str{if matches!(self,Self::Summary{..}|Self::Packets{..}|Self::Frames{..}){"ffprobe"}else{"ffmpeg"}}
    pub fn arguments(&self)->Result<Vec<OsString>>{
        crate::voice_render::validate_timeout(self.timeout())?;local(&self.input().canonical_path)?;
        match self{
            Self::Summary{input,audio_only,..}=>{let mut a=words(&["-v","error","-threads","2","-max_alloc","268435456","-protocol_whitelist","file","-format_whitelist",if *audio_only{"wav"}else{"mov,matroska,webm"},"-show_streams","-show_format","-of","json","-i"]);a.push(input.canonical_path.as_os_str().to_owned());Ok(a)},
            Self::ValidateDecode{input,has_audio,..}=>{let mut a=words(crate::host::DECODE_PREFIX);a.push(input.canonical_path.as_os_str().to_owned());a.extend(words(&["-map","0:v:0"]));if *has_audio{a.extend(words(&["-map","0:a:0"]));}a.extend(words(&["-f","null","-"]));Ok(a)},
            Self::Packets{input,stream,..}|Self::Frames{input,stream,..}=>{
                let mut a=words(&["-v","error","-threads","2","-max_alloc","268435456","-protocol_whitelist","file","-format_whitelist","mov,matroska,webm","-select_streams",&stream.to_string()]);
                if matches!(self,Self::Packets{..}){a.extend(words(&["-show_streams","-show_packets","-show_data_hash","sha256","-show_entries","stream=index,codec_name,pix_fmt,width,height,color_range,color_space,color_transfer,color_primaries,field_order,sample_aspect_ratio,time_base,extradata_hash:stream_side_data:packet=pts,dts,duration,flags,data_hash"]));}
                else{a.extend(words(&["-show_frames","-show_entries","frame=pts,duration,pkt_duration,key_frame,pict_type,interlaced_frame,repeat_pict,width,height,pix_fmt,color_range,color_space,color_transfer,color_primaries:frame_side_data"]));}
                a.extend(words(&["-of","json"]));a.push(input.canonical_path.as_os_str().to_owned());Ok(a)
            },
            Self::Pixels{input,stream,time_base,..}=>{if !time_base.positive(){return Err(Error::InvalidInput("HDR decoded hash time base"));}let mut a=words(&["-v","error","-nostdin","-xerror","-max_alloc","268435456","-copyts","-threads","2","-protocol_whitelist","file","-format_whitelist","mov,matroska,webm","-i"]);a.push(input.canonical_path.as_os_str().to_owned());a.extend(words(&["-map",&format!("0:{stream}"),"-an","-sn","-dn","-fps_mode","passthrough","-enc_time_base:v",&time_base.to_string(),"-pix_fmt","yuv420p10le","-c:v","rawvideo","-threads:v","1","-f","framehash","-hash","sha256","pipe:1"]));Ok(a)},
            Self::Mux{input,audio,output,plan,..}=>{
                local(output)?;if output==&input.canonical_path||audio.as_ref().is_some_and(|a|&a.canonical_path==output){return Err(Error::SameFile);}let start=plan.origin.checked_add(plan.range.start)?;let zero=Rational::new(0,1)?;
                let mut a=words(&["-v","error","-nostdin","-xerror","-max_alloc","268435456","-y","-copyts","-threads","2"]);
                if start>zero{a.extend(words(&["-seek_timestamp","1","-ss",&decimal(start)?,"-itsoffset",&format!("-{}",decimal(start)?)]));}
                a.extend(words(&["-protocol_whitelist","file","-format_whitelist","mov,matroska,webm","-i"]));a.push(input.canonical_path.as_os_str().to_owned());
                if let Some(audio)=audio{local(&audio.canonical_path)?;a.extend(words(&["-protocol_whitelist","file","-format_whitelist","wav","-i"]));a.push(audio.canonical_path.as_os_str().to_owned());}
                a.extend(words(&["-map",&format!("0:{}",plan.stream),"-c:v","copy","-map_metadata","-1","-map_chapters","-1","-sn","-dn"]));
                if audio.is_some(){a.extend(words(&["-map","1:a:0","-c:a","aac","-b:a","192k","-threads:a","1"]));}else{a.push("-an".into());}
                a.extend(words(&["-t",&decimal(plan.duration()?)?,"-avoid_negative_ts","disabled","-movie_timescale",&plan.movie_timescale.to_string(),"-movflags","+faststart+write_colr","-progress","pipe:1","-nostats","-f","mp4"]));a.push(output.as_os_str().to_owned());Ok(a)
            }
        }
    }
}

#[derive(Debug,Clone)]
struct Packet{pts:Rational,dts:Rational,duration:Rational,hash:String,key:bool}
#[derive(Debug,Clone)]
struct Frame{pts:Rational,duration:Rational,metadata:Vec<Value>,kind:String}
#[derive(Debug,Clone)]
pub(crate) struct HdrEvidence{stream:Value,header:String,packets:Vec<Packet>,frames:Vec<Frame>,pixels:Vec<String>}
fn integer(v:&Value,key:&str)->Result<i64>{v.get(key).and_then(Value::as_i64).ok_or(Error::InvalidProbe("HDR evidence integer"))}
fn string<'a>(v:&'a Value,key:&str)->Result<&'a str>{v.get(key).and_then(Value::as_str).ok_or(Error::InvalidProbe("HDR evidence string"))}
fn hash(s:&str,prefix:bool)->Result<String>{let s=if prefix{s.strip_prefix("SHA256:").ok_or(Error::InvalidProbe("HDR SHA256 algorithm"))?}else{s};if s.len()!=64||!s.bytes().all(|b|b.is_ascii_digit()||(b'a'..=b'f').contains(&b)){return Err(Error::InvalidProbe("HDR SHA256 digest"));}Ok(s.into())}
fn json(bytes:&[u8])->Result<Value>{if bytes.len()>MAX_HDR_EVIDENCE_BYTES{return Err(Error::LimitExceeded("HDR evidence bytes"));}crate::project_json::parse_unique(bytes)}
impl HdrEvidence {
    pub(crate) fn packet_time_base(bytes:&[u8])->Result<Rational>{let v=json(bytes)?;let stream=v.get("streams").and_then(Value::as_array).filter(|s|s.len()==1).and_then(|s|s.first()).ok_or(Error::InvalidProbe("HDR evidence stream"))?;let tb=string(stream,"time_base")?.parse::<Rational>()?;if !tb.positive(){return Err(Error::InvalidProbe("HDR evidence clock"));}Ok(tb)}
    pub(crate) fn parse(packet_bytes:&[u8],frame_bytes:&[u8],pixel_bytes:&[u8],plan:&HdrPlan,output:bool,cancel:&Cancellation)->Result<Self>{
        cancel.check()?;let packets_json=json(packet_bytes)?;let frame_json=json(frame_bytes)?;
        let streams=packets_json.get("streams").and_then(Value::as_array).ok_or(Error::InvalidProbe("HDR evidence streams"))?;
        if streams.len()!=1{return Err(Error::InvalidProbe("HDR selected stream count"));}let stream=streams[0].clone();
        if string(&stream,"codec_name")? != "hevc"
            || integer(&stream,"index")? != i64::from(if output { 0 } else { plan.stream })
            || string(&stream,"field_order")? != "progressive"
            || string(&stream,"sample_aspect_ratio")?.replace(':',"/").parse::<Rational>()? != plan.sample_aspect_ratio {
            return Err(Error::InvalidProbe("HDR selected stream identity or display interpretation"));
        }
        qualify_object(&stream,plan.width,plan.height,&plan.transfer)?;metadata(&stream)?;
        let tb=string(&stream,"time_base")?.parse::<Rational>()?;if !tb.positive(){return Err(Error::InvalidProbe("HDR evidence time base"));}
        let header=hash(string(&stream,"extradata_hash")?,true)?;
        let values=packets_json.get("packets").and_then(Value::as_array).ok_or(Error::InvalidProbe("HDR packets"))?;
        if values.is_empty()||values.len()>MAX_HDR_FRAMES{return Err(Error::LimitExceeded("HDR packet count"));}let mut packets=Vec::new();
        for v in values{cancel.check()?;let duration=tb.ticks(integer(v,"duration")?)?;if !duration.positive(){return Err(Error::InvalidProbe("HDR packet duration"));}let flags=string(v,"flags")?;if flags.is_empty()||flags.len()>8||!flags.bytes().all(|c|matches!(c,b'K'|b'_')){return Err(Error::Unsupported("discarded or corrupt HDR packets"));}packets.push(Packet{pts:tb.ticks(integer(v,"pts")?)?,dts:tb.ticks(integer(v,"dts")?)?,duration,hash:hash(string(v,"data_hash")?,true)?,key:flags.contains('K')});}
        let mut pts=std::collections::BTreeSet::new();let mut last_dts=None;
        for packet in &packets{if !pts.insert(packet.pts)||last_dts.is_some_and(|last|packet.dts<=last){return Err(Error::InvalidProbe("HDR duplicate/reordered packet clock"));}last_dts=Some(packet.dts);}
        let values=frame_json.get("frames").and_then(Value::as_array).ok_or(Error::InvalidProbe("HDR frames"))?;
        let duration=if output{plan.duration()?}else{plan.source_duration};let expected=usize::try_from(plan.rate.exact_frames(duration)?).map_err(|_|Error::LimitExceeded("HDR frame count"))?;
        if values.len()!=expected||packets.len()!=expected{return Err(Error::InvalidProbe("HDR packet/frame coverage"));}
        let origin=if output{Rational::new(0,1)?}else{plan.origin};let mut frames=Vec::new();
        for packet in &packets {
            cancel.check()?;
            let frame = plan.rate.exact_frames(packet.pts.checked_sub(origin)?)?;
            if frame < 0 || frame as usize >= expected || packet.duration != plan.rate.seconds(1)? {
                return Err(Error::InvalidProbe("HDR packet presentation grid or duration"));
            }
        }
        for (i,v) in values.iter().enumerate(){cancel.check()?;if integer(v,"interlaced_frame")?!=0||integer(v,"repeat_pict")?!=0{return Err(Error::Unsupported("HDR interlaced/repeated frames are not qualified"));}qualify_object(v,plan.width,plan.height,&plan.transfer)?;let pts=tb.ticks(integer(v,"pts")?)?;let duration=tb.ticks(v.get("duration").or_else(||v.get("pkt_duration")).and_then(Value::as_i64).ok_or(Error::InvalidProbe("HDR frame duration"))?)?;
            if pts!=origin.checked_add(plan.rate.seconds(i as i64)?)?||duration!=plan.rate.seconds(1)?{return Err(Error::Unsupported("HDR preservation requires complete exact CFR frame evidence"));}
            let kind=string(v,"pict_type")?;
            if !matches!(kind,"I"|"P"|"B") || !matches!(integer(v,"key_frame")?,0|1) {return Err(Error::InvalidProbe("HDR frame coding metadata"));}
            frames.push(Frame{pts,duration,metadata:metadata(v)?,kind:kind.into()});
        }
        if pixel_bytes.len()>MAX_HDR_EVIDENCE_BYTES{return Err(Error::LimitExceeded("HDR pixel evidence bytes"));}
        let text=std::str::from_utf8(pixel_bytes).map_err(|_|Error::InvalidProbe("HDR pixel hash UTF8"))?;let mut pixels=Vec::new();
        let mut headers=std::collections::BTreeMap::new();
        for line in text.lines(){
            cancel.check()?;
            if let Some(header)=line.strip_prefix('#') {if let Some((key,value))=header.split_once(':'){if headers.insert(key.trim(),value.trim()).is_some(){return Err(Error::InvalidProbe("duplicate HDR pixel hash header"));}}continue;}
            if line.trim().is_empty(){continue;}
            let fields:Vec<_>=line.split(',').map(str::trim).collect();
            if fields.len()!=6||fields[0]!="0"||fields[4].parse::<u64>().ok()!=Some(u64::from(plan.width)*u64::from(plan.height)*3)||pixels.len()>=frames.len(){return Err(Error::InvalidProbe("HDR pixel hash record"));}
            let frame=&frames[pixels.len()];let parse_tick=|field:&str|->Result<Rational>{tb.ticks(field.parse::<i64>().map_err(|_|Error::InvalidProbe("HDR pixel hash clock"))?)};
            if parse_tick(fields[1])?!=frame.pts||parse_tick(fields[2])?!=frame.pts||parse_tick(fields[3])?!=frame.duration{return Err(Error::InvalidProbe("HDR decoded hash/frame timestamp mismatch"));}
            pixels.push(hash(fields[5],false)?);
        }
        if headers.get("format")!=Some(&"frame checksums")||headers.get("version")!=Some(&"2")||headers.get("hash")!=Some(&"SHA256")||headers.get("media_type 0")!=Some(&"video")||headers.get("codec_id 0")!=Some(&"rawvideo")||headers.get("tb 0").and_then(|v|v.parse::<Rational>().ok())!=Some(tb)||headers.get("dimensions 0").copied()!=Some(format!("{}x{}",plan.width,plan.height).as_str())||headers.get("sar 0").and_then(|v|v.parse::<Rational>().ok())!=Some(plan.sample_aspect_ratio){return Err(Error::InvalidProbe("HDR decoded hash headers"));}
        if pixels.len()!=expected||!text.ends_with('\n'){return Err(Error::InvalidProbe("HDR decoded pixel coverage"));}
        let result=Self{stream,header,packets,frames,pixels};if !output{result.validate_trim(plan)?;}Ok(result)
    }
    fn validate_trim(&self,plan:&HdrPlan)->Result<()>{
        let start=plan.origin.checked_add(plan.range.start)?;let end=plan.origin.checked_add(plan.range.end)?;
        if plan.is_trim(){if self.packets.iter().any(|p|p.pts!=p.dts)||self.frames.iter().any(|f|f.kind=="B"){return Err(Error::Unsupported("HDR trim requires a non-reordered GOP; full-source preservation supports B frames"));}
            if !self.packets.iter().any(|p|p.pts==start&&p.key){return Err(Error::Unsupported("HDR trim must begin on a verified keyframe"));}}
        if self.packets.iter().filter(|p|p.pts>=start&&p.pts<end).count()!=plan.frames()?{return Err(Error::InvalidProbe("HDR retained packet coverage"));}Ok(())
    }
    pub(crate) fn compare(&self,out:&Self,plan:&HdrPlan,cancel:&Cancellation)->Result<()> {
        cancel.check()?;if self.header!=out.header{return Err(Error::InvalidOutput("HDR codec header changed"));}
        for key in ["codec_name","pix_fmt","width","height","color_range","color_space","color_transfer","color_primaries","field_order","sample_aspect_ratio"]{if self.stream.get(key)!=out.stream.get(key){return Err(Error::InvalidOutput("HDR stream interpretation changed"));}}
        if metadata(&self.stream)?!=metadata(&out.stream)?{return Err(Error::InvalidOutput("HDR stream metadata changed"));}
        let start=plan.origin.checked_add(plan.range.start)?;let end=plan.origin.checked_add(plan.range.end)?;
        let packets:Vec<_>=self.packets.iter().filter(|p|p.pts>=start&&p.pts<end).collect();if packets.len()!=out.packets.len(){return Err(Error::InvalidOutput("HDR packet count changed"));}
        for (a,b) in packets.iter().zip(&out.packets){cancel.check()?;if a.hash!=b.hash||a.pts.checked_sub(start)?!=b.pts||a.dts.checked_sub(start)?!=b.dts||a.duration!=b.duration||a.key!=b.key{return Err(Error::InvalidOutput("HDR packet bytes or timestamps changed"));}}
        let first=usize::try_from(plan.rate.exact_frames(plan.range.start)?).map_err(|_|Error::InvalidInput("HDR frame slice"))?;let count=plan.frames()?;
        for i in 0..count{cancel.check()?;let a=&self.frames[first+i];let b=&out.frames[i];if a.pts.checked_sub(start)?!=b.pts||a.duration!=b.duration||a.metadata!=b.metadata||self.pixels[first+i]!=out.pixels[i]{return Err(Error::InvalidOutput("HDR decoded pixels, metadata or frame clock changed"));}}
        Ok(())
    }
}
fn qualify_object(v:&Value,width:u32,height:u32,transfer:&str)->Result<()>{
    if v.get("codec_name").is_some_and(|s|s.as_str()!=Some("hevc"))||string(v,"pix_fmt")?!="yuv420p10le"||integer(v,"width")?!=i64::from(width)||integer(v,"height")?!=i64::from(height)||string(v,"color_range")?!="tv"||string(v,"color_space")?!="bt2020nc"||string(v,"color_primaries")?!="bt2020"||string(v,"color_transfer")?!=transfer{return Err(Error::Unsupported("HDR frame/stream interpretation changed"));}Ok(())
}
fn qualify_stream(v:&crate::media::StreamInfo)->Result<()>{
    if v.codec.as_deref()!=Some("hevc")||v.pixel_format.as_deref()!=Some("yuv420p10le")||v.color_range.as_deref()!=Some("tv")||v.color_space.as_deref()!=Some("bt2020nc")||v.color_primaries.as_deref()!=Some("bt2020")||!matches!(v.color_transfer.as_deref(),Some("smpte2084"|"arib-std-b67"))||v.field_order.as_deref()!=Some("progressive")||v.rotation_degrees()?!=0||!v.width.is_some_and(|n|n>0&&n<=8192&&n%2==0)||!v.height.is_some_and(|n|n>0&&n<=8192&&n%2==0)||!v.sample_aspect_ratio.is_some_and(|r|r.positive()){return Err(Error::Unsupported("HDR preservation requires unrotated progressive limited-range HEVC 4:2:0 10-bit BT.2020 PQ/HLG"));}
    metadata(&serde_json::json!({"side_data_list":v.side_data}))?;Ok(())
}
fn metadata(v:&Value)->Result<Vec<Value>>{
    let Some(items)=v.get("side_data_list")else{return Ok(Vec::new())};
    let items=items.as_array().ok_or(Error::InvalidProbe("HDR side metadata list"))?;
    if items.len()>32{return Err(Error::LimitExceeded("HDR metadata groups"));}
    let mut result=Vec::new();let mut seen=std::collections::BTreeSet::new();
    for item in items {
        let kind=string(item,"side_data_type")?;
        match kind {
            // Encoded packet/header equality independently proves preservation of
            // the raw SEI payload; ffprobe exposes no calibrated display semantics.
            "H.26[45] User Data Unregistered SEI message"=>{},
            "Mastering display metadata"=>{
                if !seen.insert(kind){return Err(Error::InvalidProbe("duplicate HDR mastering metadata"));}
                const PRIMARIES:[&str;8]=["red_x","red_y","green_x","green_y","blue_x","blue_y","white_point_x","white_point_y"];
                known_metadata_fields(item,&["side_data_type","red_x","red_y","green_x","green_y","blue_x","blue_y","white_point_x","white_point_y","min_luminance","max_luminance"])?;
                let has_primaries=PRIMARIES.iter().any(|key|item.get(*key).is_some());
                let has_luminance=["min_luminance","max_luminance"].iter().any(|key|item.get(*key).is_some());
                if !has_primaries&&!has_luminance{return Err(Error::InvalidProbe("empty HDR mastering metadata"));}
                if has_primaries {
                    for pair in PRIMARIES.chunks_exact(2) {
                        let x=string(item,pair[0])?.parse::<Rational>()?;
                        let y=string(item,pair[1])?.parse::<Rational>()?;
                        if x.numerator()<0||y.numerator()<0||x.checked_add(y)?>Rational::new(1,1)? {
                            return Err(Error::InvalidProbe("HDR mastering chromaticity"));
                        }
                    }
                }
                if has_luminance {
                    let lo=string(item,"min_luminance")?.parse::<Rational>()?;
                    let hi=string(item,"max_luminance")?.parse::<Rational>()?;
                    if lo.numerator()<0||hi<lo||hi>Rational::new(10000,1)? {return Err(Error::InvalidProbe("HDR mastering luminance"));}
                }
                result.push(item.clone());
            },
            "Content light level metadata"=>{
                if !seen.insert(kind){return Err(Error::InvalidProbe("duplicate HDR content-light metadata"));}
                known_metadata_fields(item,&["side_data_type","max_content","max_average"])?;
                let max=integer(item,"max_content")?;let average=integer(item,"max_average")?;
                if !(0..=65535).contains(&max)||!(0..=65535).contains(&average)||max>0&&average>max{return Err(Error::InvalidProbe("HDR content-light values"));}
                result.push(item.clone());
            },
            _=>return Err(Error::Unsupported("dynamic, unknown or unqualified HDR side metadata")),
        }
    }
    result.sort_by(|a,b|a["side_data_type"].as_str().cmp(&b["side_data_type"].as_str()));Ok(result)
}
fn known_metadata_fields(item:&Value,allowed:&[&str])->Result<()> {
    let fields=item.as_object().ok_or(Error::InvalidProbe("HDR metadata object"))?;
    if fields.keys().any(|key|!allowed.contains(&key.as_str())) {return Err(Error::Unsupported("unknown HDR metadata field"));}
    Ok(())
}

#[cfg(test)]mod tests{
    use super::*;
    #[test]fn movie_clock_represents_ntsc_and_audio_exactly(){assert_eq!(movie_timescale(30000,Some(48000)).unwrap(),240000);}
    #[test]fn movie_clock_rejects_zero_and_overflow(){assert!(movie_timescale(0,Some(48000)).is_err());assert!(movie_timescale(i64::MAX,Some(48000)).is_err());}
    #[test]fn dynamic_hdr_is_not_silently_copied(){assert!(metadata(&serde_json::json!({"side_data_list":[{"side_data_type":"DOVI configuration record"}]})).is_err());}
    #[test]fn hashes_require_exact_algorithm_and_size(){assert!(hash(&format!("SHA256:{}","a".repeat(64)),true).is_ok());assert!(hash(&format!("MD5:{}","a".repeat(64)),true).is_err());assert!(hash("abcd",false).is_err());}
    #[test]fn fractional_seek_is_rejected_instead_of_rounded(){assert!(exact_microseconds(Rational::new(1,30).unwrap()).is_err());assert_eq!(exact_microseconds(Rational::new(1001,10000).unwrap()).unwrap(),100100);}
}

#[cfg(test)]
#[path = "hdr_tests.rs"]
mod proof_tests;
