use crate::{Cancellation, Result};
use crate::plan::RenderPlan;
use crate::progress::Progress;
use serde::{Deserialize, Serialize};
use std::{collections::BTreeSet, ffi::OsString, path::{Path,PathBuf}};

#[derive(Debug,Clone,Serialize,Deserialize,PartialEq,Eq)]
pub struct FileStamp {
    pub size:u64,
    pub modified_ns:Option<u128>,
    pub sha256:String,
    /// Host-specific stable identity, for example device/inode. Not an authority token.
    pub file_id:Option<String>,
}
#[derive(Debug,Clone,Serialize,Deserialize)]
pub struct InputFile {pub canonical_path:PathBuf,pub stamp:FileStamp}
#[derive(Debug,Clone,Default,Serialize,Deserialize)]
#[serde(tag="policy",content="stamp",rename_all="snake_case",deny_unknown_fields)]
pub enum OutputPolicy {
    #[default] CreateNew,
    /// The host must obtain explicit user consent for this exact observed target.
    /// The local adapter rechecks it but is not an OS security sandbox.
    ReplaceReviewed(FileStamp),
}
#[derive(Debug,Clone,Default,Serialize,Deserialize)]
pub struct RuntimeCapabilities {
    pub ffmpeg_version:String,
    pub ffprobe_version:String,
    pub ffmpeg_identity:Option<String>,
    pub ffprobe_identity:Option<String>,
    pub encoders:BTreeSet<String>,
    pub muxers:BTreeSet<String>,
    #[serde(default)]
    pub filters:BTreeSet<String>,
    #[serde(default)]
    pub bitstream_filters:BTreeSet<String>,
    /// Set only for a runtime supporting -enc_time_base:v demux.
    pub supports_demux_time_base:bool,
}
impl RuntimeCapabilities {
    pub fn supports_mp4(&self,audio:bool)->bool {
        self.encoders.contains("libx264")&&(!audio||self.encoders.contains("aac"))&&self.muxers.contains("mp4")
    }
}
pub type ProgressSink<'a> = dyn FnMut(Progress) + 'a;

/// Typed domain operations only; no shell text, executable path or arbitrary argv
/// supplied by the extension. Map these to the current host's reviewed tool plans.
#[derive(Debug,Clone)]
pub enum MediaTask {
    Probe {input:PathBuf},
    Render {input:PathBuf,staged_output:PathBuf,plan:RenderPlan},
    ValidateDecode {input:PathBuf,has_audio:bool},
}
impl MediaTask {
    pub fn tool_name(&self)->&'static str{match self{Self::Probe{..}=>"ffprobe",_=>"ffmpeg"}}
    pub fn arguments(&self)->Result<Vec<OsString>> {
        match self {
            Self::Probe{input}=>{
                let mut a=words(PROBE_PREFIX);a.push(input.as_os_str().to_owned());Ok(a)
            },
            Self::Render{input,staged_output,plan}=>plan.arguments(input,staged_output),
            Self::ValidateDecode{input,has_audio}=>{
                let mut a=words(DECODE_PREFIX);a.push(input.as_os_str().to_owned());
                a.extend(words(&["-map","0:v:0"]));
                if *has_audio{a.extend(words(&["-map","0:a:0"]));}
                a.extend(words(&["-f","null","-"]));Ok(a)
            },
        }
    }
}
pub(crate) fn words(a:&[&str])->Vec<OsString>{a.iter().map(|s|OsString::from(*s)).collect()}
// The real-media fixture runner reads these literal arrays directly. Keep them
// plain literals; Rust unit tests also compare the complete generated argument list.
pub const PROBE_PREFIX:&[&str]=&[
    "-v","error","-max_alloc","268435456","-protocol_whitelist","file",
    "-format_whitelist","mov,matroska,webm","-show_error","-show_streams","-show_format",
    "-show_packets","-read_intervals","%+#64","-of","json","-i"
];
pub const DECODE_PREFIX:&[&str]=&[
    "-hide_banner","-loglevel","error","-nostdin","-xerror","-max_alloc","268435456",
    "-threads","2","-protocol_whitelist","file","-format_whitelist","mov,matroska,webm","-i"
];
#[derive(Debug,Clone)]
pub struct ToolOutput {pub stdout:Vec<u8>}

/// Implement this adapter against Automexia's existing authority and job owners.
/// All methods execute on an existing host worker, not its UI/PTY hot path.
pub trait MediaHost:Send+Sync {
    /// Bounded HDR evidence/copy operations. The workflow validates the entire
    /// selected video before publishing; this method never commits a destination.
    fn run_hdr(&self,_task:&crate::hdr::HdrTask,_cancel:&Cancellation,_progress:&mut ProgressSink<'_>)->Result<ToolOutput>{
        Err(crate::Error::MissingCapability("host verified HDR preservation adapter"))
    }
    /// Whole selected-video frame scan before speed changes or dissolves. Nominal
    /// frame-rate tags alone cannot prove a continuous source sample clock.
    fn verify_timing(&self,_input:&InputFile,_media:&crate::MediaInfo,_stream:u32,_rate:crate::interchange::EditRate,_cancel:&Cancellation)->Result<crate::interchange::CfrEvidence>{
        Err(crate::Error::MissingCapability("host whole-stream timing verifier"))
    }
    /// Explicitly granted assets only. Core hosts may use their existing rasterizer.
    /// Returned files must remain private and leased until rendering is finished.
    fn prepare_presentation(&self,_plan:&crate::presentation_render::PresentationRender,_project_file:&Path,_cancel:&Cancellation)->Result<Box<dyn crate::presentation_render::PresentationLease>>{
        Err(crate::Error::MissingCapability("host presentation asset/raster adapter"))
    }
    /// Protect the project, all source/asset paths and aliases before and after staging.
    fn publish_subtitles(&self,_source:&InputFile,_protected:&[PathBuf],_destination:&Path,_policy:&OutputPolicy,_bytes:&[u8],_cancel:&Cancellation)->Result<PathBuf>{
        Err(crate::Error::MissingCapability("host subtitle sidecar writer"))
    }

    fn inspect_input(&self,path:&Path,cancel:&Cancellation)->Result<InputFile>;
    fn revalidate_input(&self,input:&InputFile,cancel:&Cancellation)->Result<()>;
    fn runtime_capabilities(&self,cancel:&Cancellation)->Result<RuntimeCapabilities>;
    fn run(&self,task:&MediaTask,cancel:&Cancellation,progress:&mut ProgressSink<'_>)->Result<ToolOutput>;
    fn stage_output(&self,input:&InputFile,destination:&Path,policy:&OutputPolicy,cancel:&Cancellation)->Result<Box<dyn OutputLease>>;
    /// Optional Step-6 single-pass video decode. RGB must be display-oriented,
    /// full-range Rec.709 with original presentation timestamps. A failure may
    /// not be reported as successful partial coverage. Native adapter supplied.
    fn stream_video_frames(&self,_request:&crate::color_workflow::VideoScan,_cancel:&Cancellation,
        _sink:&mut crate::color_analysis::VideoFrameSink<'_>)->Result<()> {
        Err(crate::Error::MissingCapability("host timestamped RGB analysis adapter"))
    }
    /// Optional Step-5 operation: bounded selected-channel float PCM on an
    /// existing worker. Default preserves compatibility with earlier adapters.
    fn stream_voice_pcm(&self,_request:&crate::voice_render::VoiceScan,_cancel:&Cancellation,_sink:&mut crate::voice_render::PcmSink<'_>)->Result<()> {
        Err(crate::Error::MissingCapability("host float PCM analysis adapter"))
    }
    /// Optional typed measurement/stem operations. No arbitrary shell or tool API.
    fn run_audio(&self,_task:&crate::voice_render::AudioTask,_cancel:&Cancellation,_progress:&mut ProgressSink<'_>)->Result<ToolOutput> {
        Err(crate::Error::MissingCapability("host audio measurement/stem adapter"))
    }

}
/// Drop must clean only the job-owned temporary output. Publish is the commit
/// point; cancellation after successful publication does not undo a completed file.
/// Success must preserve the verified staged bytes at the returned destination.
/// Implementations must not transform or replace those bytes during publication.
pub trait OutputLease:Send {
    fn path(&self)->&Path;
    fn publish(self:Box<Self>,cancel:&Cancellation)->Result<PathBuf>;
}
