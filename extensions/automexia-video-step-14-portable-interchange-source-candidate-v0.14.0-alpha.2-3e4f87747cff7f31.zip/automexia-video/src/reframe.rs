//! Step 7: reversible, variant-local framing. No file, process, UI or model I/O.
//!
//! Coordinates are normalized in the display-oriented SOURCE image. Keyframe
//! times are exact seconds relative to the selected video's original origin,
//! never the edited output clock. Each shot is independent (no interpolation
//! across a shot reset). Nothing here detects faces, people or active speakers.
use crate::{Error, Rational, Result};
use crate::project::{Disposition, FrozenRenderSettings, OutputVariant, Project, ProjectSource, TimeRange};
use serde::{Deserialize, Serialize};

pub const FRAMING_VERSION: u32 = 1;
pub const MAX_CROP_SHOTS: usize = 16;
pub const MAX_CROP_KEYS: usize = 32;
pub const MAX_OUTPUT_EDGE: u32 = 8192;
pub const MAX_OUTPUT_PIXELS: u64 = 33_554_432;
pub const MAX_SCALED_EDGE: u32 = 16384;
pub const MAX_SCALED_PIXELS: u64 = 67_108_864;

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct OutputSize { pub width: u32, pub height: u32 }
impl OutputSize {
    pub fn new(width:u32,height:u32)->Result<Self>{let value=Self{width,height};value.validate()?;Ok(value)}
    pub fn validate(self)->Result<()> {
        if self.width<2||self.height<2||self.width%2!=0||self.height%2!=0
            ||self.width>MAX_OUTPUT_EDGE||self.height>MAX_OUTPUT_EDGE
            ||u64::from(self.width)*u64::from(self.height)>MAX_OUTPUT_PIXELS {
            return Err(Error::InvalidProject("framing requires bounded even output dimensions"));
        }
        Ok(())
    }
    pub fn aspect(self)->Result<Rational>{self.validate()?;Rational::new(i64::from(self.width),i64::from(self.height))}
    /// Exact aspect and exact longest edge, not a silently rounded size.
    /// Use explicit even dimensions when an arbitrary aspect cannot be expressed.
    pub fn from_aspect(aspect:Rational,long_edge:u32)->Result<Self>{
        if !aspect.positive(){return Err(Error::InvalidInput("positive target aspect required"));}
        let n=u32::try_from(aspect.numerator()).map_err(|_|Error::InvalidInput("target aspect numerator"))?;
        let d=u32::try_from(aspect.denominator()).map_err(|_|Error::InvalidInput("target aspect denominator"))?;
        if n.max(d)>MAX_OUTPUT_EDGE||long_edge>MAX_OUTPUT_EDGE||long_edge==0||long_edge%n.max(d)!=0{
            return Err(Error::InvalidInput("long edge must exactly express the requested aspect"));
        }
        let k=long_edge/n.max(d);Self::new(n*k,d*k)
    }
}

#[derive(Debug,Clone,Copy,PartialEq,Serialize,Deserialize)]
#[serde(deny_unknown_fields)]
pub struct UnitPoint {pub x:f64,pub y:f64}
impl UnitPoint {
    pub fn center()->Self{Self{x:0.5,y:0.5}}
    pub fn validate(self)->Result<()>{finite_range(self.x,0.0,1.0,"horizontal anchor")?;finite_range(self.y,0.0,1.0,"vertical anchor")}
}
#[derive(Debug,Clone,Copy,PartialEq,Serialize,Deserialize)]
#[serde(deny_unknown_fields)]
pub struct DisplayRect {pub x:f64,pub y:f64,pub width:f64,pub height:f64}
impl DisplayRect {
    pub fn validate(self)->Result<()>{
        finite_range(self.x,0.0,1.0,"crop x")?;finite_range(self.y,0.0,1.0,"crop y")?;
        finite_range(self.width,0.000001,1.0,"crop width")?;finite_range(self.height,0.000001,1.0,"crop height")?;
        if self.x+self.width>1.0+1e-10||self.y+self.height>1.0+1e-10{return Err(Error::InvalidProject("crop exceeds displayed source"));}Ok(())
    }
}
#[derive(Debug,Clone,Copy,PartialEq,Eq,Serialize,Deserialize)]
#[serde(deny_unknown_fields)]
pub struct RgbColor {pub red:u8,pub green:u8,pub blue:u8}
impl RgbColor {pub fn black()->Self{Self{red:0,green:0,blue:0}}pub(crate) fn ffmpeg(self)->String{format!("0x{:02x}{:02x}{:02x}",self.red,self.green,self.blue)}}

/// Safe-zone guides, in 1/10000 of the OUTPUT canvas. They are metadata for the
/// host/Step-8 layout, not black bars, pixel masks, or current platform promises.
#[derive(Debug,Clone,Copy,PartialEq,Eq,Serialize,Deserialize)]
#[serde(deny_unknown_fields)]
pub struct SafeZone {pub left:u16,pub top:u16,pub right:u16,pub bottom:u16}
#[derive(Debug,Clone,Copy,PartialEq,Eq,Serialize,Deserialize)]
#[serde(deny_unknown_fields)]
pub struct PixelRect {pub x:u32,pub y:u32,pub width:u32,pub height:u32}
impl SafeZone {
    pub fn none()->Self{Self{left:0,top:0,right:0,bottom:0}}
    pub fn validate(self)->Result<()>{
        if u32::from(self.left)+u32::from(self.right)>=10000||u32::from(self.top)+u32::from(self.bottom)>=10000{
            return Err(Error::InvalidProject("safe-zone margins leave no usable canvas"));
        }Ok(())
    }
    pub fn pixels(self,size:OutputSize)->Result<PixelRect>{
        self.validate()?;size.validate()?;
        let inset=|n:u32,b:u16|((u64::from(n)*u64::from(b)+9999)/10000) as u32;
        let(x,y)=(inset(size.width,self.left),inset(size.height,self.top));
        let(r,b)=(inset(size.width,self.right),inset(size.height,self.bottom));
        if x+r>=size.width||y+b>=size.height{return Err(Error::InvalidProject("safe-zone is empty at this output resolution"));}
        Ok(PixelRect{x,y,width:size.width-x-r,height:size.height-y-b})
    }
}

#[derive(Debug,Clone,Copy,PartialEq,Serialize,Deserialize)]
#[serde(deny_unknown_fields)]
pub struct ScaleLimits {
    /// Maximum resampling enlargement per coded source axis. 1 means no upscale.
    /// In Fit mode the image stays smaller and is padded. Crop mode refuses an
    /// infeasible fixed canvas; it never silently changes the requested crop.
    pub max_upscale:f64,
    pub max_intermediate_pixels:u64,
}
impl Default for ScaleLimits {fn default()->Self{Self{max_upscale:4.0,max_intermediate_pixels:MAX_SCALED_PIXELS}}}
impl ScaleLimits {
    pub fn validate(self)->Result<()>{finite_range(self.max_upscale,1.0,16.0,"upscale bound")?;
        if self.max_intermediate_pixels<4||self.max_intermediate_pixels>MAX_SCALED_PIXELS{return Err(Error::InvalidProject("intermediate pixel bound"));}Ok(())}
}

#[derive(Debug,Clone,Copy,PartialEq,Serialize,Deserialize)]
#[serde(deny_unknown_fields)]
pub struct CropPose {pub center:UnitPoint,pub zoom:f64}
impl CropPose {
    pub fn centered()->Self{Self{center:UnitPoint::center(),zoom:1.0}}
    pub fn rectangle(self,source:SourceGeometry,target:OutputSize)->Result<DisplayRect>{
        self.center.validate()?;finite_range(self.zoom,1.0,8.0,"crop zoom")?;target.validate()?;
        let(base_w,base_h)=source.base_crop(target)?;
        let(width,height)=(base_w/self.zoom,base_h/self.zoom);
        let rect=DisplayRect{x:self.center.x-width/2.0,y:self.center.y-height/2.0,width,height};
        // Permit only tiny roundoff at the mathematical source boundary.
        if rect.x< -1e-10||rect.y< -1e-10||rect.x+width>1.0+1e-10||rect.y+height>1.0+1e-10{
            return Err(Error::InvalidProject("crop center/zoom places part of the crop outside the source"));
        }
        Ok(DisplayRect{x:rect.x.max(0.0),y:rect.y.max(0.0),..rect})
    }
    /// Convert an explicit display-space rectangle without stretching it to fit.
    pub fn from_rectangle(rect:DisplayRect,source:SourceGeometry,target:OutputSize)->Result<Self>{
        rect.validate()?;target.validate()?;let(w,h)=source.display_size()?;
        if ((rect.width*w/(rect.height*h))/(f64::from(target.width)/f64::from(target.height))-1.0).abs()>1e-7{
            return Err(Error::InvalidProject("explicit crop aspect differs from target; use a matching crop or Fit"));
        }
        let(base,_) = source.base_crop(target)?;
        let pose=Self{center:UnitPoint{x:rect.x+rect.width/2.0,y:rect.y+rect.height/2.0},zoom:(base/rect.width).max(1.0)};
        pose.rectangle(source,target)?;Ok(pose)
    }
}

/// Normalized center/zoom derivative bounds. Quintic smoothstep stops at each
/// keyframe. Impossible user timing is rejected, never silently retimed.
#[derive(Debug,Clone,Copy,PartialEq,Serialize,Deserialize)]
#[serde(deny_unknown_fields)]
pub struct MotionLimits {
    pub dead_zone:f64,
    pub max_center_speed:f64,
    pub max_center_acceleration:f64,
    pub max_zoom_speed:f64,
    pub max_zoom_acceleration:f64,
}
impl Default for MotionLimits{fn default()->Self{Self{dead_zone:0.002,max_center_speed:0.75,max_center_acceleration:3.0,max_zoom_speed:2.0,max_zoom_acceleration:8.0}}}
impl MotionLimits {
    pub fn validate(self)->Result<()>{
        finite_range(self.dead_zone,0.0,0.05,"crop dead zone")?;
        finite_range(self.max_center_speed,0.001,10.0,"crop speed limit")?;
        finite_range(self.max_center_acceleration,0.001,100.0,"crop acceleration limit")?;
        finite_range(self.max_zoom_speed,0.001,16.0,"zoom speed limit")?;
        finite_range(self.max_zoom_acceleration,0.001,160.0,"zoom acceleration limit")
    }
}
#[derive(Debug,Clone,PartialEq,Serialize,Deserialize)]
#[serde(deny_unknown_fields)]
pub struct CropKeyframe {pub at:Rational,pub pose:CropPose}
#[derive(Debug,Clone,PartialEq,Serialize,Deserialize)]
#[serde(deny_unknown_fields)]
pub struct CropShot {pub range:TimeRange,pub keyframes:Vec<CropKeyframe>}
#[derive(Debug,Clone,PartialEq,Serialize,Deserialize)]
#[serde(deny_unknown_fields)]
pub struct CropTrack {pub shots:Vec<CropShot>,pub motion:MotionLimits}
impl CropTrack {
    /// Whether the source viewport changes size. Such tracks use fixed-raster
    /// sampling: FFmpeg crop cannot safely follow variable input dimensions.
    pub fn has_varying_zoom(&self)->bool {
        let mut first=None;
        for shot in &self.shots { for key in &shot.keyframes {
            match first { None=>first=Some(key.pose.zoom), Some(z) if z!=key.pose.zoom=>return true, _=>{} }
        }}
        false
    }

    pub fn centered(duration:Rational)->Result<Self>{Ok(Self{shots:vec![CropShot{range:TimeRange::new(Rational::new(0,1)?,duration)?,keyframes:vec![CropKeyframe{at:Rational::new(0,1)?,pose:CropPose::centered()}]}],motion:MotionLimits::default()})}
    /// Pure, explicit dead-zone editing. It does not move timestamps, remove
    /// keyframes, change zoom, or guess scene boundaries. Review/save the result.
    pub fn suppress_small_moves(&self)->Result<Self>{
        self.motion.validate()?;let mut result=self.clone();
        for shot in &mut result.shots{
            let mut previous:Option<UnitPoint>=None;
            for key in &mut shot.keyframes{
                key.pose.center.validate()?;
                if let Some(p)=previous{
                    if distance(p,key.pose.center)<=self.motion.dead_zone{key.pose.center=p;}
                }
                previous=Some(key.pose.center);
            }
        }Ok(result)
    }
    pub fn validate(&self,source:SourceGeometry,target:OutputSize,duration:Rational)->Result<()>{
        self.motion.validate()?;
        if self.shots.is_empty()||self.shots.len()>MAX_CROP_SHOTS||self.shots.iter().map(|s|s.keyframes.len()).sum::<usize>()>MAX_CROP_KEYS{
            return Err(Error::LimitExceeded("crop shots/keyframes"));
        }
        let mut cursor=Rational::new(0,1)?;
        for shot in &self.shots{
            shot.range.validate()?;
            if shot.range.start!=cursor||shot.range.end>duration||shot.keyframes.is_empty(){return Err(Error::InvalidProject("crop shots must partition the source without gaps"));}
            if shot.keyframes[0].at!=shot.range.start{return Err(Error::InvalidProject("first crop keyframe must be at the shot start"));}
            for key in &shot.keyframes {
                if key.at<shot.range.start||key.at>shot.range.end{return Err(Error::InvalidProject("crop keyframe outside its source shot"));}
                key.pose.rectangle(source,target)?;
            }
            for keys in shot.keyframes.windows(2){
                if keys[0].at>=keys[1].at{return Err(Error::InvalidProject("crop keyframes must be strictly increasing"));}
                let dt=keys[1].at.checked_sub(keys[0].at)?.as_f64();
                let d=distance(keys[0].pose.center,keys[1].pose.center);
                let z=(keys[0].pose.zoom-keys[1].pose.zoom).abs();
                // Exact upper bounds for q(u)=6u^5-15u^4+10u^3:
                // max q'=15/8; max |q''|=10/sqrt(3).
                if 1.875*d/dt>self.motion.max_center_speed+1e-10||5.773502692*d/(dt*dt)>self.motion.max_center_acceleration+1e-10
                    ||1.875*z/dt>self.motion.max_zoom_speed+1e-10||5.773502692*z/(dt*dt)>self.motion.max_zoom_acceleration+1e-10{
                    return Err(Error::InvalidProject("crop movement exceeds saved speed/acceleration limits; space keys farther apart or use a shot reset"));
                }
            }
            cursor=shot.range.end;
        }
        if cursor!=duration{return Err(Error::InvalidProject("crop track must cover the entire source duration"));}Ok(())
    }
    pub fn pose_at(&self,time:Rational)->Result<CropPose>{
        // Includes the final endpoint for editor inspection; rendered intervals
        // remain half-open. Call validate() before using a programmatic track.
        let shot=self.shots.iter().find(|s|s.range.contains(time))
            .or_else(||self.shots.last().filter(|s|time==s.range.end))
            .ok_or(Error::InvalidInput("crop time is outside the source"))?;
        let first=shot.keyframes.first().ok_or(Error::InvalidProject("empty crop keyframe list"))?;
        for keys in shot.keyframes.windows(2){
            if time<keys[1].at{
                let span=keys[1].at.checked_sub(keys[0].at)?;
                if !span.positive(){return Err(Error::InvalidProject("crop keyframe order"));}
                let u=time.checked_sub(keys[0].at)?.checked_div(span)?.as_f64().clamp(0.0,1.0);
                return Ok(interpolate(keys[0].pose,keys[1].pose,smoothstep(u)));
            }
        }
        Ok(shot.keyframes.last().unwrap_or(first).pose)
    }
    /// A saved known scene cut may not lie strictly inside a moving interval.
    /// Constant framing needs no extra knots; scene discovery stays in Step 6.
    pub(crate) fn check_known_cut(&self,at:Rational)->Result<()>{
        for shot in &self.shots{for k in shot.keyframes.windows(2){
            if k[0].at<at&&at<k[1].at&&k[0].pose!=k[1].pose{return Err(Error::InvalidProject("moving crop crosses a known source cut; split the crop shot at that cut"));}
        }}Ok(())
    }
}
fn smoothstep(u:f64)->f64{u*u*u*(u*(u*6.0-15.0)+10.0)}
fn interpolate(a:CropPose,b:CropPose,u:f64)->CropPose{CropPose{center:UnitPoint{x:a.center.x+(b.center.x-a.center.x)*u,y:a.center.y+(b.center.y-a.center.y)*u},zoom:a.zoom+(b.zoom-a.zoom)*u}}
fn distance(a:UnitPoint,b:UnitPoint)->f64{(a.x-b.x).hypot(a.y-b.y)}

#[derive(Debug,Clone,PartialEq,Serialize,Deserialize)]
#[serde(tag="mode",rename_all="snake_case",deny_unknown_fields)]
pub enum FramingMode {
    /// Keep the full composition, optionally smaller than the canvas. Even-raster
    /// quantization is reported; arbitrary aspect stretching is never requested.
    Fit {anchor:UnitPoint,background:RgbColor},
    /// Fill the canvas. Pan/zoom are manual keys in source display coordinates.
    Crop {track:CropTrack},
}
#[derive(Debug,Clone,Copy,PartialEq,Eq,Serialize,Deserialize)]
#[serde(rename_all="snake_case")]
pub enum TargetPreset {#[serde(rename="youtube")] YouTube,#[serde(rename="tiktok")] TikTok,Reel,Feed,Square,Master}
#[derive(Debug,Clone,Copy,PartialEq,Eq,Serialize,Deserialize)]
#[serde(deny_unknown_fields)]
pub struct PresetStamp {pub name:TargetPreset,pub revision:u32}

#[derive(Debug,Clone,PartialEq,Serialize,Deserialize)]
#[serde(deny_unknown_fields)]
pub struct FramingSettings {
    pub version:u32,
    pub target:OutputSize,
    pub mode:FramingMode,
    pub safe_zone:SafeZone,
    pub limits:ScaleLimits,
    pub preset:Option<PresetStamp>,
    pub enabled:bool,
    pub disposition:Disposition,
    pub locked:bool,
}
impl FramingSettings {
    /// Authoring produces a reviewable proposal; call decide_framing(Approve)
    /// explicitly. Neither preset creation nor preview implies approval.
    pub fn fit(target:OutputSize)->Result<Self>{target.validate()?;Ok(Self{version:FRAMING_VERSION,target,mode:FramingMode::Fit{anchor:UnitPoint::center(),background:RgbColor::black()},safe_zone:SafeZone::none(),limits:ScaleLimits::default(),preset:None,enabled:true,disposition:Disposition::NeedsReview,locked:false})}
    pub fn center_crop(target:OutputSize,duration:Rational)->Result<Self>{let mut value=Self::fit(target)?;value.mode=FramingMode::Crop{track:CropTrack::centered(duration)?};Ok(value)}
    pub fn preset(preset:TargetPreset,source:&ProjectSource)->Result<Self>{
        let geometry=SourceGeometry::from_source(source)?;
        let (size,safe)=match preset{
            TargetPreset::YouTube=>(OutputSize::new(1920,1080)?,SafeZone{left:500,top:500,right:500,bottom:500}),
            TargetPreset::TikTok|TargetPreset::Reel=>(OutputSize::new(1080,1920)?,SafeZone{left:500,top:1000,right:1200,bottom:1800}),
            TargetPreset::Feed=>(OutputSize::new(1080,1350)?,SafeZone{left:500,top:500,right:500,bottom:1000}),
            TargetPreset::Square=>(OutputSize::new(1080,1080)?,SafeZone{left:500,top:500,right:500,bottom:500}),
            TargetPreset::Master=>{let(w,h)=geometry.display_size()?;(OutputSize::new(even_nearest(w)?,even_nearest(h)?)?,SafeZone::none())},
        };
        // Fit is intentionally the preset default: selecting a target alone
        // must not discard edge content. Crop is an explicit separate choice.
        let mut result=Self::fit(size)?;result.safe_zone=safe;result.preset=Some(PresetStamp{name:preset,revision:1});Ok(result)
    }
    pub fn active(&self)->bool{self.enabled&&self.disposition==Disposition::AutoApply}
    pub fn ensure_resolved(&self)->Result<()>{if self.enabled&&self.disposition==Disposition::NeedsReview{Err(Error::UnresolvedEdits)}else{Ok(())}}
    pub fn validate(&self,source:&ProjectSource)->Result<()>{
        if self.version!=FRAMING_VERSION{return Err(Error::InvalidProject("unsupported framing version"));}
        if self.preset.is_some_and(|p|p.revision!=1){return Err(Error::InvalidProject("unsupported target-preset revision"));}
        self.target.validate()?;self.safe_zone.pixels(self.target)?;self.limits.validate()?;
        let geometry=SourceGeometry::from_source(source)?;
        match &self.mode{
            FramingMode::Fit{anchor,..}=>{anchor.validate()?;geometry.fit(self.target,*anchor,self.limits)?;},
            FramingMode::Crop{track}=>{
                track.validate(geometry,self.target,source.duration)?;
                // Animated zoom samples a fixed 4:4:4 raster at the original
                // oriented resolution. Limit that buffer as well as the virtual
                // enlargement used to express crop resolution/quality limits.
                if track.has_varying_zoom() && u64::from(geometry.width)*u64::from(geometry.height)>self.limits.max_intermediate_pixels {
                    return Err(Error::LimitExceeded("animated crop source raster"));
                }
                for shot in &track.shots{for key in &shot.keyframes{geometry.crop(self.target,key.pose,self.limits)?;}}
            },
        }Ok(())
    }
    pub fn geometry_at(&self,source:&ProjectSource,time:Rational)->Result<FrameGeometry>{
        self.validate(source)?;
        if time.numerator()<0||time>source.duration{return Err(Error::InvalidInput("framing inspection time"));}
        let geometry=SourceGeometry::from_source(source)?;
        let mut result=match &self.mode{
            FramingMode::Fit{anchor,..}=>geometry.fit(self.target,*anchor,self.limits)?,
            FramingMode::Crop{track}=>geometry.crop(self.target,track.pose_at(time)?,self.limits)?,
        };
        result.safe_region=self.safe_zone.pixels(self.target)?;Ok(result)
    }
}

#[derive(Debug,Clone,Copy,PartialEq,Serialize,Deserialize)]
#[serde(deny_unknown_fields)]
pub struct SourceGeometry {pub width:u32,pub height:u32,pub sar:Rational}
impl SourceGeometry {
    pub fn from_source(source:&ProjectSource)->Result<Self>{
        let v=&source.media.video;let w=v.width.ok_or(Error::InvalidProject("source width"))?;let h=v.height.ok_or(Error::InvalidProject("source height"))?;
        let sar=v.sample_aspect_ratio.unwrap_or(Rational::new(1,1)?);let rotation=v.rotation_degrees()?;
        let result=if rotation%180!=0{Self{width:h,height:w,sar:sar.inverse()?}}else{Self{width:w,height:h,sar}};
        result.display_size()?;Ok(result)
    }
    pub fn display_size(self)->Result<(f64,f64)>{
        if self.width<2||self.height<2||self.width>16384||self.height>16384||u64::from(self.width)*u64::from(self.height)>67_108_864
            ||!self.sar.positive()||self.sar.as_f64()<0.01||self.sar.as_f64()>100.0{return Err(Error::InvalidProject("bounded display geometry required"));}
        Ok((f64::from(self.width)*self.sar.as_f64(),f64::from(self.height)))
    }
    pub fn base_crop(self,target:OutputSize)->Result<(f64,f64)>{
        target.validate()?;let(w,h)=self.display_size()?;let aspect=f64::from(target.width)/f64::from(target.height);
        if w/h>aspect{Ok((aspect*h/w,1.0))}else{Ok((1.0,w/(aspect*h)))}
    }
    pub(crate) fn cover_size(self,target:OutputSize)->Result<(f64,f64)>{
        target.validate()?;let(w,h)=self.display_size()?;let s=(f64::from(target.width)/w).max(f64::from(target.height)/h);Ok((w*s,h*s))
    }
    fn check_scaled(self,w:u32,h:u32,limits:ScaleLimits)->Result<()>{
        limits.validate()?;
        if w<2||h<2||w>MAX_SCALED_EDGE||h>MAX_SCALED_EDGE||u64::from(w)*u64::from(h)>limits.max_intermediate_pixels{return Err(Error::LimitExceeded("framing intermediate raster"));}
        if f64::from(w)>f64::from(self.width)*limits.max_upscale+1e-7||f64::from(h)>f64::from(self.height)*limits.max_upscale+1e-7{
            return Err(Error::InvalidProject("framing exceeds explicit source upscale limit; lower output/zoom or raise the saved limit"));
        }Ok(())
    }
    pub fn fit(self,target:OutputSize,anchor:UnitPoint,limits:ScaleLimits)->Result<FrameGeometry>{
        target.validate()?;anchor.validate()?;limits.validate()?;
        if u64::from(target.width)*u64::from(target.height)>limits.max_intermediate_pixels{
            return Err(Error::LimitExceeded("padded output raster exceeds saved intermediate budget"));
        }
        let(w,h)=self.display_size()?;
        let factor=(f64::from(target.width)/w).min(f64::from(target.height)/h)
            .min(limits.max_upscale/self.sar.as_f64()).min(limits.max_upscale);
        let(sw,sh)=(even_floor(w*factor)?,even_floor(h*factor)?);self.check_scaled(sw,sh,limits)?;
        let x=even_offset(target.width-sw,anchor.x);let y=even_offset(target.height-sh,anchor.y);
        Ok(FrameGeometry{target,scaled_width:sw,scaled_height:sh,crop:None,content:PixelRect{x,y,width:sw,height:sh},
            safe_region:PixelRect{x:0,y:0,width:target.width,height:target.height},desired_crop:None})
    }
    pub fn crop(self,target:OutputSize,pose:CropPose,limits:ScaleLimits)->Result<FrameGeometry>{
        let rect=pose.rectangle(self,target)?;let(w,h)=self.cover_size(target)?;
        let(sw,sh)=(even_ceil(w*pose.zoom)?,even_ceil(h*pose.zoom)?);self.check_scaled(sw,sh,limits)?;
        let x=(pose.center.x*f64::from(sw)-f64::from(target.width)/2.0).round().clamp(0.0,f64::from(sw-target.width)) as u32;
        let y=(pose.center.y*f64::from(sh)-f64::from(target.height)/2.0).round().clamp(0.0,f64::from(sh-target.height)) as u32;
        Ok(FrameGeometry{target,scaled_width:sw,scaled_height:sh,crop:Some(PixelRect{x,y,width:target.width,height:target.height}),
            content:PixelRect{x:0,y:0,width:target.width,height:target.height},safe_region:PixelRect{x:0,y:0,width:target.width,height:target.height},desired_crop:Some(rect)})
    }
}
#[derive(Debug,Clone,PartialEq,Serialize)]
pub struct FrameGeometry {
    pub target:OutputSize,pub scaled_width:u32,pub scaled_height:u32,
    /// Crop location in the conceptual scaled square-pixel intermediate.
    /// Animated zoom uses a fixed-raster sampler instead; desired_crop is the
    /// authoritative viewport and these integer coordinates are a UI guide.
    pub crop:Option<PixelRect>,
    /// Image rectangle within the final canvas (Fit may have padding).
    pub content:PixelRect,pub safe_region:PixelRect,
    /// Ideal normalized source rectangle; integer raster rounding is also visible.
    pub desired_crop:Option<DisplayRect>,
}
fn even_floor(n:f64)->Result<u32>{checked_even(n, false)}
fn even_ceil(n:f64)->Result<u32>{checked_even(n, true)}
fn checked_even(n:f64,up:bool)->Result<u32>{
    if !n.is_finite()||n<2.0||n>f64::from(MAX_SCALED_EDGE){return Err(Error::LimitExceeded("framing raster dimension"));}
    let result=(if up{(n/2.0-1e-10).ceil()}else{(n/2.0+1e-10).floor()})*2.0;
    if result<2.0||result>f64::from(MAX_SCALED_EDGE){return Err(Error::LimitExceeded("framing raster rounding"));}Ok(result as u32)
}
fn even_nearest(n:f64)->Result<u32>{if !n.is_finite()||n<2.0||n>f64::from(MAX_OUTPUT_EDGE){return Err(Error::LimitExceeded("Master square-pixel target"));}Ok(((n/2.0).round()*2.0) as u32)}
fn even_offset(room:u32,anchor:f64)->u32{((f64::from(room)*anchor/2.0).round()*2.0).min(f64::from(room)) as u32}
fn finite_range(v:f64,lo:f64,hi:f64,what:&'static str)->Result<()>{if !v.is_finite()||v<lo||v>hi{Err(Error::InvalidProject(what))}else{Ok(())}}

#[derive(Debug,Clone,Copy)]
pub enum FramingDecision {Approve,Reject,Enable(bool),Lock(bool)}
impl Project {
    pub fn add_output_variant(&mut self,id:&str,render:FrozenRenderSettings,framing:Option<FramingSettings>)->Result<()>{
        self.edit(|p|{crate::project::id_ok(id)?;if p.variants.iter().any(|v|v.id==id){return Err(Error::InvalidProject("duplicate output variant"));}
            let framing=framing.map(|mut f|{f.disposition=Disposition::NeedsReview;f.locked=false;f});
            p.variants.push(OutputVariant{ assembly:None,timing:None,output_profile:None,presentation:None,id:id.into(),render,framing});Ok(())})
    }
    /// Replacing settings is a new proposal, never an inherited approval/lock.
    /// None explicitly restores the previous no-framing path.
    pub fn set_variant_framing(&mut self,id:&str,framing:Option<FramingSettings>)->Result<()>{
        self.edit(|p|{let v=p.variants.iter_mut().find(|v|v.id==id).ok_or(Error::InvalidProject("unknown framing variant"))?;
            if v.framing.as_ref().is_some_and(|f|f.locked){return Err(Error::LockedEdit);}
            v.framing=framing.map(|mut f|{f.disposition=Disposition::NeedsReview;f.locked=false;f});Ok(())})
    }
    pub fn decide_framing(&mut self,id:&str,decision:FramingDecision)->Result<()>{
        self.edit(|p|{let f=p.variants.iter_mut().find(|v|v.id==id).and_then(|v|v.framing.as_mut()).ok_or(Error::InvalidProject("unknown framing variant"))?;
            if let FramingDecision::Lock(on)=decision{f.locked=on;return Ok(());}
            if f.locked{return Err(Error::LockedEdit);}
            match decision{FramingDecision::Approve=>{f.enabled=true;f.disposition=Disposition::AutoApply;},FramingDecision::Reject=>{f.enabled=false;f.disposition=Disposition::Ignore;},FramingDecision::Enable(on)=>f.enabled=on,FramingDecision::Lock(_)=>{}}
            Ok(())})
    }
    pub(crate) fn check_framing(&self,f:&FramingSettings)->Result<()>{
        if self.sources.len()!=1{return Err(Error::Unsupported("framing currently supports one source"));}
        f.validate(&self.sources[0])?;
        if let FramingMode::Crop{track}=&f.mode{
            if let Some(color)=&self.settings.color_correction{for shot in &color.shots{track.check_known_cut(shot.range.start)?;}}
        }Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    fn r(s:&str)->Rational{s.parse().unwrap()}
    fn track()->CropTrack{CropTrack{motion:MotionLimits::default(),shots:vec![CropShot{range:TimeRange::new(r("0"),r("4")).unwrap(),keyframes:vec![CropKeyframe{at:r("0"),pose:CropPose{center:UnitPoint{x:0.3,y:0.5},zoom:1.0}},CropKeyframe{at:r("4"),pose:CropPose{center:UnitPoint{x:0.7,y:0.5},zoom:1.0}}]}]}}
    #[test] fn known_cut_cannot_be_crossed_by_movement(){assert!(track().check_known_cut(r("2")).is_err());}
    #[test] fn constant_framing_can_span_known_cut(){let mut t=track();t.shots[0].keyframes[1].pose=t.shots[0].keyframes[0].pose;assert!(t.check_known_cut(r("2")).is_ok());}
    #[test] fn exactly_at_key_is_not_crossing(){assert!(track().check_known_cut(r("4")).is_ok());}
    #[test] fn dead_zone_never_changes_zoom(){let mut t=track();t.shots[0].keyframes[1].pose.center.x=0.301;t.shots[0].keyframes[1].pose.zoom=1.5;let s=t.suppress_small_moves().unwrap();assert_eq!(s.shots[0].keyframes[1].pose.zoom,1.5);assert_eq!(s.shots[0].keyframes[1].pose.center.x,0.3);}
}
