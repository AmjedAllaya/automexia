use crate::{Cancellation,Error,Result};
use crate::host::{MediaHost,InputFile,MediaTask,ProgressSink,RuntimeCapabilities};
use crate::media::{MediaInfo,parse_probe};
use crate::plan::{build_plan,validate_output,RenderRequest,RenderResult};
use crate::progress::{Progress,Stage};
use serde::{Serialize,Deserialize};
use std::{path::Path,time::Duration};
use crate::lifecycle::{JobRegistry,Permit,DrainStatus};

pub const EXTENSION_ID:&str="org.automexia.video";
pub const HELP:&str="Automexia Video provides editable local .amxv projects, explicit stream selection, chronological trim/cut review, before/proposed proxies, and verified rendering through the existing host. Source files remain immutable. Construction and status do not start media processing. Conservative energy-based pause proposals, classical voice cleanup, measured loudness, PCM24 stems, reviewed SDR color, variant-local Fit/crop/pan/zoom, supplied captions, graphics and bounded presentation effects are implemented. Variant-local clip assembly supports explicit single-source range order, repeats and per-clip speeds, while shared source cuts remain authoritative. Assembly changes require review and respect locks. Variant timing supports reviewed 0.5x, 1x and 2x playback and bounded adjacent dissolves with exact frame/sample planning; unsupported timing or export combinations fail before publication. Placement analysis returns explicit reviewable anchor choices. Software H.264/HEVC, VP9/AV1 WebM, ProRes, frozen presets, sequential retries and editable OTIO/FCP7 XML/modern FCPXML 1.10/CMX3600 export are available within their documented profiles. An explicit BundleHost capability provides create-new portable OTIO/FCPXML ZIP64 handoffs with copied media, hashes and private optional bakes. A separate explicit host capability enables restricted HEVC PQ/HLG HDR preservation with proof checks. Optional speech protection, RNNoise enhancement, UltraFace framing/placement choices and whisper.cpp transcription require explicit verified model packs, selected providers and host execution capability. Installation never selects or downloads models; inference never automatically approves edits. Transcripts support corrections, locks, search, subtitles and reviewable filler/punch-in suggestions. The host owns action registration, permissions, playback, jobs and deployment. Actual host installation, target-editor import and perceptual model quality require separate acceptance.";
#[derive(Debug,Clone,Copy,Serialize)]
pub struct ActionDescriptor {pub id:&'static str,pub label:&'static str,pub writes_output:bool}
/// Metadata to map into the existing Action Registry. These are library action
/// names, not claims about an already-shipped host manifest or command ABI.
pub const ACTIONS:&[ActionDescriptor]=&[
    ActionDescriptor{id:"video.export.assess",label:"Assess editor export compatibility without writing media",writes_output:false},
    ActionDescriptor{id:"video.export.bundle",label:"Export a portable ZIP64 interchange and media bundle",writes_output:true},
    ActionDescriptor{id:"video.export",label:"Export editable interchange with an explicit compatibility report",writes_output:true},
    ActionDescriptor{id:"video.run",label:"Prepare and deliver a frozen video workflow",writes_output:true},
    ActionDescriptor{id:"video.render",label:"Render saved variants without repeating analysis",writes_output:true},
    ActionDescriptor{id:"video.delivery.retry",label:"Retry unsuccessful targets; revalidate completed outputs",writes_output:true},
    ActionDescriptor{id:"video.subtitles.import",label:"Import selected plain-text SRT or WebVTT",writes_output:false},
    ActionDescriptor{id:"video.subtitles.export",label:"Export reviewed, cut-aware subtitle sidecar",writes_output:true},
    ActionDescriptor{id:"video.presentation.set",label:"Propose captions, graphics or effect settings",writes_output:false},
    ActionDescriptor{id:"video.presentation.decide",label:"Review, bypass or lock presentation",writes_output:false},
    ActionDescriptor{id:"video.timing.set",label:"Propose explicit variant speed and adjacent dissolves",writes_output:false},
    ActionDescriptor{id:"video.timing.decide",label:"Review, approve, bypass or lock variant timing",writes_output:false},
    ActionDescriptor{id:"video.assembly.set",label:"Propose single-source clip order, repeats, ranges and per-clip speed",writes_output:false},
    ActionDescriptor{id:"video.assembly.decide",label:"Review, approve, bypass or lock variant clip assembly",writes_output:false},
    ActionDescriptor{id:"video.placement.analyze",label:"Measure candidate graphic and caption anchors",writes_output:false},
    ActionDescriptor{id:"video.placement.apply",label:"Apply explicit placement choices for review",writes_output:false},
    ActionDescriptor{id:"video.variant.add",label:"Add an output composition variant",writes_output:false},
    ActionDescriptor{id:"video.framing.inspect",label:"Inspect crop geometry and safe-zone guides",writes_output:false},
    ActionDescriptor{id:"video.framing.set",label:"Propose variant framing or keyframe changes",writes_output:false},
    ActionDescriptor{id:"video.framing.decide",label:"Review, approve, bypass or lock variant framing",writes_output:false},
    ActionDescriptor{id:"video.color.analyze",label:"Detect shots and propose conservative SDR corrections",writes_output:false},
    ActionDescriptor{id:"video.color.apply",label:"Add color proposals to editable project",writes_output:false},
    ActionDescriptor{id:"video.voice.analyze",label:"Inspect audio and propose classical cleanup settings",writes_output:false},
    ActionDescriptor{id:"video.voice.apply",label:"Accept audio cleanup settings in the project",writes_output:false},
    ActionDescriptor{id:"video.audio.export",label:"Export accepted audio as PCM24 WAV",writes_output:true},
    ActionDescriptor{id:"video.pauses.analyze",label:"Propose conservative quiet-interval cuts",writes_output:false},
    ActionDescriptor{id:"video.pauses.apply",label:"Add pause proposals to editable project",writes_output:false},
    ActionDescriptor{id:"video.review.open",label:"Review saved video edits",writes_output:false},
    ActionDescriptor{id:"video.review.decide",label:"Approve, reject or lock a video edit",writes_output:false},
    ActionDescriptor{id:"video.review.preview",label:"Render disposable before/proposed preview",writes_output:true},
    ActionDescriptor{id:"video.review.open_preview",label:"Open validated preview through host",writes_output:false},
    ActionDescriptor{id:"video.project.create",label:"Create editable video project",writes_output:false},
    ActionDescriptor{id:"video.project.save",label:"Save video project without rendering",writes_output:true},
    ActionDescriptor{id:"video.project.load",label:"Open video project",writes_output:false},
    ActionDescriptor{id:"video.project.dry_run",label:"Inspect planned video edits",writes_output:false},
    ActionDescriptor{id:"video.project.render",label:"Render saved video edits",writes_output:true},
    ActionDescriptor{id:"video.status",label:"Video status",writes_output:false},
    ActionDescriptor{id:"video.probe",label:"Inspect selected media",writes_output:false},
    ActionDescriptor{id:"video.render_unedited",label:"Render unedited MP4",writes_output:true},
];
#[derive(Debug,Clone,Serialize,Deserialize)]
#[serde(default,deny_unknown_fields)]
pub struct VideoSettings {pub max_concurrent_jobs:usize}
impl Default for VideoSettings{fn default()->Self{Self{max_concurrent_jobs:1}}}
impl VideoSettings{pub fn validate(&self)->Result<()>{if self.max_concurrent_jobs==0||self.max_concurrent_jobs>4{Err(Error::InvalidInput("concurrent jobs must be 1..4"))}else{Ok(())}}}
#[derive(Debug,Clone,Serialize)]
pub struct VideoStatus {pub extension_id:&'static str,pub enabled:bool,pub active_jobs:usize,pub runtime:Option<RuntimeCapabilities>}
#[derive(Debug,Clone,Serialize)]
pub struct ProbedInput {pub input:InputFile,pub media:MediaInfo}

/// Host-independent extension entry object. No terminal imports, global thread
/// pool, hidden downloads, registry writes, shell integration or model runtime.
pub struct VideoExtension<H:MediaHost> {
    jobs:JobRegistry, host:H,
}
impl<H:MediaHost> VideoExtension<H> {
    pub fn new(host:H,settings:VideoSettings)->Result<Self>{
        settings.validate()?;
        Ok(Self{host,jobs:JobRegistry::new(settings.max_concurrent_jobs)})
    }
    pub fn host(&self)->&H{&self.host}
    pub fn enable(&self)->Result<()>{self.jobs.enable()}
    pub fn disable(&self)->Result<()>{self.jobs.disable()}
    pub fn cancel_all(&self)->Result<()>{self.jobs.cancel_all()}
    /// Disable, cancel and wait for admitted core jobs on a host lifecycle worker.
    /// Completion does not release host-owned player handles or unload a plugin.
    pub fn disable_and_drain(&self,timeout:Duration)->Result<DrainStatus>{self.jobs.drain(timeout)}
    /// Pure snapshot. Querying status never probes tools or touches source files.
    pub fn status(&self)->Result<VideoStatus>{
        let (enabled,active_jobs)=self.jobs.snapshot()?;
        Ok(VideoStatus{extension_id:EXTENSION_ID,enabled,active_jobs,runtime:None})
    }
    pub fn check_runtime(&self,cancel:&Cancellation)->Result<VideoStatus>{
        let job=self.begin(cancel)?;let runtime=self.host.runtime_capabilities(&job.cancel)?;job.cancel.check()?;drop(job);
        let mut status=self.status()?;status.runtime=Some(runtime);Ok(status)
    }
    pub fn probe(&self,path:&Path,cancel:&Cancellation,progress:&mut ProgressSink<'_>)->Result<ProbedInput>{
        let job=self.begin(cancel)?;emit(progress,Stage::Inspecting)?;
        let input=self.host.inspect_input(path,&job.cancel)?;
        let media=self.probe_path(&input.canonical_path,&job.cancel,progress)?;
        self.host.revalidate_input(&input,&job.cancel)?;
        Ok(ProbedInput{input,media})
    }
    pub fn render_unedited(&self,request:&RenderRequest,cancel:&Cancellation,progress:&mut ProgressSink<'_>)->Result<RenderResult>{
        request.options.validate()?;
        if !request.output.extension().and_then(|s|s.to_str()).is_some_and(|s|s.eq_ignore_ascii_case("mp4")){
            return Err(Error::InvalidInput("this output profile requires an .mp4 destination"));
        }
        let job=self.begin(cancel)?;emit(progress,Stage::Inspecting)?;
        let input=self.host.inspect_input(&request.input,&job.cancel)?;
        emit(progress,Stage::RuntimeCheck)?;
        let runtime=self.host.runtime_capabilities(&job.cancel)?;
        let source=self.probe_path(&input.canonical_path,&job.cancel,progress)?;
        let plan=build_plan(&source,&request.options,&runtime)?;
        job.cancel.check()?;
        let staged=self.host.stage_output(&input,&request.output,&request.output_policy,&job.cancel)?;
        self.host.revalidate_input(&input,&job.cancel)?;
        emit(progress,Stage::Rendering)?;
        self.host.run(&MediaTask::Render{input:input.canonical_path.clone(),staged_output:staged.path().to_owned(),plan:plan.clone()},&job.cancel,progress)?;
        job.cancel.check()?;emit(progress,Stage::Validating)?;
        let output=self.probe_path(staged.path(),&job.cancel,progress)?;
        validate_output(&source,&output,&plan)?;
        self.host.run(&MediaTask::ValidateDecode{input:staged.path().to_owned(),has_audio:plan.selected().audio.is_some()},&job.cancel,progress)?;
        self.host.revalidate_input(&input,&job.cancel)?;
        job.cancel.check()?;emit(progress,Stage::Publishing)?;
        let destination=staged.publish(&job.cancel)?;
        Ok(RenderResult{delivery_profile:plan.output_profile().cloned(),output:destination,input,selected:plan.selected(),runtime,output_media:output,warnings:plan.warnings.clone(),full_decode_validated:true})
    }
    pub(crate) fn probe_path(&self,path:&Path,cancel:&Cancellation,progress:&mut ProgressSink<'_>)->Result<MediaInfo>{
        cancel.check()?;emit(progress,Stage::Probing)?;
        let result=self.host.run(&MediaTask::Probe{input:path.to_owned()},cancel,progress)?;
        cancel.check()?;parse_probe(&result.stdout)
    }
    pub(crate) fn workflow_operation(&self,parent:&Cancellation)->Result<crate::lifecycle::WorkflowPermit<'_>>{self.jobs.workflow(parent)}
    pub(crate) fn workflow_scope(&self,parent:&Cancellation)->Result<Cancellation>{self.jobs.scope(parent)}
    pub(crate) fn begin(&self,parent:&Cancellation)->Result<Permit<'_>>{self.jobs.begin(parent)}
}
pub(crate) fn emit(sink:&mut ProgressSink<'_>,stage:Stage)->Result<()>{
    std::panic::catch_unwind(std::panic::AssertUnwindSafe(||sink(Progress::stage(stage)))).map_err(|_|Error::CallbackPanicked)
}
