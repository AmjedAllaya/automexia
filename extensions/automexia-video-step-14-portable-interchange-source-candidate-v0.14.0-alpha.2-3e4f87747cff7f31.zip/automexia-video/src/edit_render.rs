//! Compile saved single-source edits and reviewed sequence assembly. Ordinary
//! chronological cuts keep timestamp-preserving selection; repeats, reorder and
//! speed changes use explicit trim branches. No user strings enter filters.
use crate::{Error,Result,Rational};
use crate::project::{Project,Timeline,MAX_RENDER_SEGMENTS};
use serde::Serialize;

// Literal templates are shared with the independent FFmpeg recipe tests. Those
// tests do not execute this Rust code; Cargo tests compare actual Rust output.
pub const VIDEO_BASE: &str = "[0:{video}]select='{select}',settb=expr=1/1000000,setpts='{mapping}'{color}[vout]";
pub const AUDIO_BASE: &str = "[0:{audio}]asetpts=PTS-({origin_num}/{origin_den})/TB,aresample={rate}:async=1:first_pts=0,apad=whole_len={source_samples},atrim=end_sample={source_samples}";
pub const AUDIO_TRIM: &str = "[a{index}]atrim=start_sample={start}:end_sample={end},asetpts=PTS-STARTPTS[t{index}]";
pub const AUDIO_FADE_IN: &str = ",afade=t=in:ss=0:ns={samples}:curve=tri";
pub const AUDIO_FADE_OUT: &str = ",afade=t=out:ss={start}:ns={samples}:curve=tri";
pub const VIDEO_PREDICATE: &str = "gte(pts,{start})*lt(pts,{end})";
pub const DURATION_BSF: &str = "setts=pts=PTS:dts=DTS:duration=if(eq(DURATION\\,0)\\,{den}/({num}*TB)\\,DURATION)";
pub const VIDEO_SHIFT: &str = "gte(PTS,{start})*lt(PTS,{end})*({shift})";
pub const EDITED_PREFIX: &[&str] = &[
    "-hide_banner","-loglevel","error","-nostdin","-xerror","-max_alloc","268435456","-y","-copyts"
];
/// Conservative pixel/audio payload budget for frames retained by a reordered
/// split graph. Process, codec and fixed filter overhead are additional.
pub const MAX_ASSEMBLY_BUFFER_BYTES:u64=256*1024*1024;
/// Windowed pitch-preserving audio is not suitable for tiny retained fragments.
pub const MIN_TEMPO_SEGMENT_MS:u32=100;
/// Flush the bounded tempo windows before trimming the exact output interval.
pub const TEMPO_TAIL_GUARD_MS:u32=250;
pub const TEMPO_WARNING:&str="Pitch-preserving speed changes require at least 100 ms of source and output per audio segment. Windowed time stretching can shift or remove isolated transients; exact sample counts do not imply transient preservation.";

#[derive(Debug,Clone,Serialize)]
pub struct RenderedSegment {
    /// Source seconds per output second, including entry and global speed.
    pub speed:Rational,
    pub start_pts:i64,pub end_pts:i64,
    pub start_us:i64,pub end_us:i64,pub input_start_us:i64,pub output_start_us:i64,
    pub start_sample:Option<i64>,pub end_sample:Option<i64>,
    pub output_end_us:i64, pub output_samples:Option<i64>,
}
#[derive(Debug,Clone,Serialize)]
pub struct EditRender {
    pub requested:Timeline,
    /// The variant-wide speed, retained for compatibility. Rendering uses the
    /// effective speed on each segment, including reviewed assembly entry rate.
    pub speed:Rational,pub dissolve:Rational,
    pub segments:Vec<RenderedSegment>,
    pub duration:Rational,
    pub origin:Rational,
    pub nominal_frame_rate:Rational,
    pub source_samples:Option<i64>,pub sample_rate:Option<u32>,
    /// (fade-in samples, fade-out samples), only at applied pause-cut joins.
    /// Fades change amplitude, never segment length or video/audio time mapping.
    pub join_fades_samples:Vec<(i64,i64)>,
}
impl EditRender {
    pub fn from_project(project:&Project)->Result<Self>{
        Self::from_variant(project,&project.variants.first().ok_or(Error::InvalidProject("no output variant"))?.id)
    }
    pub fn from_variant(project:&Project,variant:&str)->Result<Self>{
        Self::compile_variant(project,variant,true)
    }
    pub(crate) fn from_audio_variant(project:&Project,variant:&str)->Result<Self>{
        Self::compile_variant(project,variant,false)
    }
    fn compile_variant(project:&Project,variant:&str,include_video_budget:bool)->Result<Self>{
        let requested=project.timeline_for_variant(variant)?;let source=&project.sources[0];
        let settings=project.variant(variant)?.timing.as_ref().filter(|s|s.active());
        let speed=settings.map(|s|s.speed.ratio()).unwrap_or(Rational::new(1,1)?);
        let dissolve=settings.map(|s|s.dissolve).unwrap_or(Rational::new(0,1)?);
        let sample_rate=source.media.audio.as_ref().map(|s|s.sample_rate.ok_or(Error::InvalidProject("audio sample rate"))).transpose()?;
        if sample_rate==Some(0){return Err(Error::InvalidProject("zero sample rate"));}
        let nominal_frame_rate=source.media.video.nominal_frame_rate.or(source.media.video.average_frame_rate).ok_or(Error::Unsupported("edited output needs a known nominal frame duration"))?;
        if !nominal_frame_rate.positive()||nominal_frame_rate>Rational::new(240,1)?{return Err(Error::Unsupported("edited output nominal frame rate"));}
        let scale=i64::from(sample_rate.unwrap_or(1_000_000));
        let video_tb=source.media.video.time_base.ok_or(Error::InvalidProject("video time base"))?;
        let mut segments=Vec::new();
        for s in &requested.segments {
            if s.source_id!=source.id{return Err(Error::Unsupported("assembly rendering requires one selected source"));}
            let segment_speed=s.source_range.duration()?.checked_div(s.output_range.duration()?)?;
            tempo_filters(segment_speed)?;
            validate_tempo_span(segment_speed,sample_rate,s.source_range.duration()?,s.output_range.duration()?)?;
            let start=s.source_range.start.ceil_units(scale)?;let end=s.source_range.end.ceil_units(scale)?;
            if start>=end{return Err(Error::InvalidProject("range is shorter than render timing resolution"));}
            // Select BEFORE rescaling: ceil(microseconds) can otherwise skip a
            // frame exactly at a rational source boundary (e.g. 1/30 seconds).
            let absolute_start=source.timeline_origin.checked_add(s.source_range.start)?;
            let absolute_end=source.timeline_origin.checked_add(s.source_range.end)?;
            let start_pts=absolute_start.checked_div(video_tb)?.ceil_units(1)?;
            let end_pts=absolute_end.checked_div(video_tb)?.ceil_units(1)?;
            let start_us=video_tb.ticks(start_pts)?.nearest_units(1_000_000)?;
            let end_us=video_tb.ticks(end_pts)?.nearest_units(1_000_000)?;
            let input_start_us=absolute_start.nearest_units(1_000_000)?;
            let output_start_us=s.output_range.start.nearest_units(1_000_000)?;
            let output_end_us=s.output_range.end.nearest_units(1_000_000)?;
            let output_samples=sample_rate.map(|r|->Result<i64>{Ok(s.output_range.end.ceil_units(i64::from(r))?-s.output_range.start.ceil_units(i64::from(r))?)}).transpose()?;
            // FFmpeg expression evaluation uses floating point. Reject timestamps
            // outside its exact-integer range rather than silently misselect frames.
            if [start_pts,end_pts,start_us,end_us,input_start_us,output_start_us,output_end_us].iter().any(|n|n.unsigned_abs()>9_007_199_254_740_991){return Err(Error::Unsupported("edit timestamp exceeds exact filter-expression range"));}
            segments.push(RenderedSegment{speed:segment_speed,start_pts,end_pts,start_us,end_us,input_start_us,output_start_us,output_end_us,output_samples,start_sample:sample_rate.map(|_|start),end_sample:sample_rate.map(|_|end)});
        }
        let mut join_fades_samples=vec![(0,0);segments.len()];
        if let (Some(rate),Some(settings))=(sample_rate,project.settings.pause_cleanup.as_ref()) {
            let fade=Rational::new(i64::from(settings.join_fade_ms),1000)?.ceil_units(i64::from(rate))?;
            if fade>0 && !dissolve.positive() {
                // Reuse the authoritative timeline rules. A pause operation
                // completely covered by a manual removal (or blocked by a
                // protection) must not add processing to that unrelated cut.
                let mut without_pauses=project.clone();
                for op in &mut without_pauses.operations {if crate::pause::ours(op){op.enabled=false;}}
                let without_pauses=without_pauses.timeline()?;
                let with_pauses=project.timeline()?;
                for i in 1..requested.segments.len() {
                    let left=&requested.segments[i-1].source_range;let right=&requested.segments[i].source_range;
                    if left.end>=right.start{continue;}
                    let gap=crate::project::TimeRange::new(left.end,right.start)?;
                    // An assembly may omit retained material by choice. Such
                    // an authored jump is not a generated pause-cut join.
                    if with_pauses.segments.iter().any(|s|s.source_range.overlaps(&gap)){continue;}
                    if without_pauses.segments.iter().any(|s|s.source_range.overlaps(&gap)) {
                        let left_len=segments[i-1].output_samples.unwrap();
                        let right_len=segments[i].output_samples.unwrap();
                        join_fades_samples[i-1].1=fade.min(left_len/4);
                        join_fades_samples[i].0=fade.min(right_len/4);
                    }
                }
            }
        }
        let duration=requested.duration;
        if segments.iter().any(|s|s.speed!=Rational::new(1,1).unwrap()) || dissolve.positive() || segments.windows(2).any(|pair|pair[1].start_pts<pair[0].end_pts) {
            let rate=crate::interchange::EditRate::new(nominal_frame_rate,false)?;
            for s in &requested.segments {for t in [s.source_range.start,s.source_range.end,s.output_range.start,s.output_range.end]{rate.exact_frames(t)?;}}
            rate.exact_frames(dissolve)?;rate.exact_frames(duration)?;
        }
        bound_assembly_buffer(project,variant,&requested,nominal_frame_rate,sample_rate,include_video_budget)?;
        let result=Self{requested,speed,dissolve,segments,join_fades_samples,duration,origin:source.timeline_origin,nominal_frame_rate,
            source_samples:sample_rate.map(|r|source.duration.ceil_units(i64::from(r))).transpose()?,sample_rate};
        result.validate()?;Ok(result)
    }
    /// Repeated/out-of-order selections cannot use a single monotonic select
    /// expression: every occurrence needs a separate trim and clock reset.
    pub fn requires_branching(&self)->bool {
        self.segments.iter().any(|s|s.speed!=Rational::new(1,1).unwrap()) || self.dissolve.positive()
            || self.segments.windows(2).any(|pair|pair[1].start_pts<pair[0].end_pts)
    }
    /// Branch rendering also requires the verified CFR input contract even
    /// when all effective speeds are one (e.g. reverse occurrence order).
    pub fn changes_timing(&self)->bool { self.requires_branching() }
    pub fn required_filters(&self)->Vec<&'static str> {
        let mut filters=vec!["settb","setpts","select"];
        if self.changes_timing(){filters.extend(["trim","fps","split","tpad","null"]);if self.dissolve.positive(){filters.push("xfade");}else if self.segments.len()>1{filters.push("concat");}}
        if self.sample_rate.is_some(){filters.extend(["asetpts","aresample","apad","atrim","anull"]);if self.segments.len()>1{filters.extend(["asplit","concat"]);}if self.segments.iter().any(|s|s.speed!=Rational::new(1,1).unwrap()){filters.push("atempo");}if self.dissolve.positive()&&self.segments.len()>1{filters.extend(["acrossfade","asetnsamples"]);}}
        if self.join_fades_samples.iter().any(|(a,b)|*a>0||*b>0){filters.push("afade");} filters
    }
    pub fn filter_graph(&self,video:u32,audio:Option<u32>,full_range:bool)->Result<String>{
        if audio.is_some()!=self.sample_rate.is_some(){return Err(Error::InvalidProject("audio timeline selection"));}
        let mut graph=self.video_filter_graph(video,full_range,"")?;
        if let Some(audio)=audio{graph.push(';');graph.push_str(&self.audio_filter_graph(audio,"","")?);}Ok(graph)
    }
    /// source_filters are constructed only from typed in-crate processing plans.
    /// They run on the original source clock before speed changes and overlaps.
    pub(crate) fn video_filter_graph(&self,video:u32,full_range:bool,source_filters:&str)->Result<String>{
        self.validate()?;
        let prefix=if source_filters.is_empty(){String::new()}else{format!("{source_filters},")};
        if self.changes_timing(){
            let n=self.segments.len();
            let mut graph=format!("[0:{video}]{prefix}split={n}");
            for i in 0..n {graph.push_str(&format!("[vs{i}]"));}
            for (i,s) in self.segments.iter().enumerate(){
                let frames=crate::interchange::EditRate::new(self.nominal_frame_rate,false)?.exact_frames(self.requested.segments[i].output_range.duration()?)?;
                graph.push_str(&format!(";[vs{i}]trim=start_pts={}:end_pts={},settb=expr=1/1000000,setpts='(PTS-{})*{}/{}',fps=fps={}:start_time=0:round=near,tpad=stop_mode=clone:stop_duration=1,trim=end_frame={frames},settb=expr=1/1000000{}[vt{i}]",s.start_pts,s.end_pts,s.input_start_us,s.speed.denominator(),s.speed.numerator(),self.nominal_frame_rate,if full_range{",scale=in_range=pc:out_range=pc"}else{""}));
            }
            if n==1{graph.push_str(";[vt0]null[vassembled]");}
            else if self.dissolve.positive(){let mut previous="vt0".to_owned();for i in 1..n {let next=if i+1==n{"vassembled".to_owned()}else{format!("vx{i}")};let offset=self.requested.segments[i].output_range.start;graph.push_str(&format!(";[{previous}][vt{i}]xfade=transition=fade:duration={}:offset={}[{next}]",decimal(self.dissolve)?,decimal(offset)?));previous=next;}}
            else {graph.push(';');for i in 0..n{graph.push_str(&format!("[vt{i}]"));}graph.push_str(&format!("concat=n={n}:v=1:a=0[vassembled]"));}
            // concat rounds every clip boundary onto its microsecond clock.
            // Re-anchor all resulting frames on one global CFR grid so repeated
            // short NTSC entries cannot accumulate those rounding errors.
            let total_frames=crate::interchange::EditRate::new(self.nominal_frame_rate,false)?.exact_frames(self.duration)?;
            graph.push_str(&format!(";[vassembled]trim=end_frame={total_frames},settb=expr={},setpts=N,settb=expr=1/1000000[vout]",self.nominal_frame_rate.inverse()?));
            if graph.len()>32*1024{return Err(Error::LimitExceeded("timing video filter graph"));}return Ok(graph);
        }
        let mut select=Vec::new();let mut shifts=Vec::new();
        for s in &self.segments {
            select.push(VIDEO_PREDICATE.replace("{start}",&s.start_pts.to_string()).replace("{end}",&s.end_pts.to_string()));
            shifts.push(VIDEO_SHIFT.replace("{start}",&s.start_us.to_string()).replace("{end}",&s.end_us.to_string())
                .replace("{shift}",&s.output_start_us.checked_sub(s.input_start_us).ok_or(Error::LimitExceeded("edit timestamp shift"))?.to_string()));
        }
        let graph=VIDEO_BASE.replace("{video}",&video.to_string())
            .replace("{select}",&select.join("+")).replace("{mapping}",&format!("PTS+{}",shifts.join("+")))
            .replace("{color}",if full_range{",scale=in_range=pc:out_range=pc"}else{""})
            .replacen(&format!("[0:{video}]"),&format!("[0:{video}]{prefix}"),1);
        if graph.len()>24*1024{return Err(Error::LimitExceeded("edit filter graph"));}Ok(graph)
    }
    /// Audio-only graph shared by full render, measurement, preview and WAV
    /// stems. pre_filters has a trailing comma; post_filters a leading comma.
    /// Callers inside this crate construct both from bounded typed parameters.
    pub(crate) fn audio_filter_graph(&self,audio:u32,pre_filters:&str,post_filters:&str)->Result<String>{
        self.validate()?;let mut graph=String::new();
            let rate=self.sample_rate.ok_or(Error::InvalidProject("audio rate"))?;
            graph.push_str(&AUDIO_BASE.replace("{audio}",&audio.to_string()).replace("{origin_num}",&self.origin.numerator().to_string())
                .replace("{origin_den}",&self.origin.denominator().to_string()).replace("{rate}",&rate.to_string())
                .replace("{source_samples}",&self.source_samples.ok_or(Error::InvalidProject("audio duration"))?.to_string())
                .replacen(&format!("[0:{audio}]"),&format!("[0:{audio}]{pre_filters}"),1));
            if self.segments.len()==1{graph.push_str("[a0]");}
            else {graph.push_str(&format!(",asplit={}",self.segments.len()));for i in 0..self.segments.len(){graph.push_str(&format!("[a{i}]"));}}
            for (i,s) in self.segments.iter().enumerate(){
                let (fade_in,fade_out)=self.join_fades_samples[i];
                let mut fades=String::new();
                let target=s.output_samples.ok_or(Error::InvalidProject("output audio samples"))?;
                if s.speed!=Rational::new(1,1)? {
                    // Flush atempo's lookahead with bounded silence BEFORE the
                    // transform. Padding a short/empty result afterwards hides
                    // lost content and can turn a real clip into silent audio.
                    let guard=Rational::new(i64::from(TEMPO_TAIL_GUARD_MS),1000)?.ceil_units(i64::from(rate))?;
                    fades.push_str(&format!(",apad=pad_len={guard}"));fades.push_str(tempo_filters(s.speed)?);
                    fades.push_str(&format!(",atrim=end_sample={target}"));
                }else if self.changes_timing() || Some(target)!=s.end_sample.zip(s.start_sample).map(|(e,b)|e-b) {fades.push_str(&format!(",apad=whole_len={target},atrim=end_sample={target}"));}
                if fade_in>0 {fades.push_str(&AUDIO_FADE_IN.replace("{samples}",&fade_in.to_string()));}
                if fade_out>0 {
                    let length=s.output_samples.ok_or(Error::InvalidProject("output audio samples"))?;
                    fades.push_str(&AUDIO_FADE_OUT.replace("{start}",&(length-fade_out).to_string()).replace("{samples}",&fade_out.to_string()));
                }
                // acrossfade can prematurely finish when upstream tempo
                // filters emit variable-sized frames. Regularize packet sizes
                // without adding any samples; the final packet stays partial.
                if self.dissolve.positive()&&self.segments.len()>1{fades.push_str(",asetnsamples=n=1024:p=0");}
                graph.push(';');graph.push_str(&AUDIO_TRIM.replace("{index}",&i.to_string())
                    .replace("{start}",&s.start_sample.ok_or(Error::InvalidProject("audio start"))?.to_string())
                    .replace("{end}",&s.end_sample.ok_or(Error::InvalidProject("audio end"))?.to_string())
                    .replace(&format!("[t{i}]"),&format!("{fades}[t{i}]")));
            }
            graph.push(';');
            if self.dissolve.positive() && self.segments.len()>1 {
                let mut previous="t0".to_owned();for i in 1..self.segments.len(){let samples=self.requested.segments[i-1].output_range.end.ceil_units(i64::from(rate))?-self.requested.segments[i].output_range.start.ceil_units(i64::from(rate))?;let next=format!("ax{i}");if i>1{graph.push(';');}graph.push_str(&format!("[{previous}][t{i}]acrossfade=ns={samples}:c1=tri:c2=tri[{next}]"));previous=next;}
                graph.push_str(&format!(";[{previous}]anull"));
            }else{
                for i in 0..self.segments.len(){graph.push_str(&format!("[t{i}]"));}
                if self.segments.len()==1{graph.push_str("anull");}else{graph.push_str(&format!("concat=n={}:v=0:a=1",self.segments.len()));}
            }
            let output_samples=self.duration.ceil_units(i64::from(rate))?;
            if !self.segments.iter().any(|s|s.speed!=Rational::new(1,1).unwrap()) {graph.push_str(&format!(",apad=whole_len={output_samples}"));}
            graph.push_str(&format!(",atrim=end_sample={output_samples}"));
            graph.push_str(post_filters);graph.push_str("[aout]");
        if graph.len()>24*1024{return Err(Error::LimitExceeded("audio filter graph"));}Ok(graph)
    }
    pub fn duration_bitstream_filter(&self)->String {
        DURATION_BSF.replace("{den}",&self.nominal_frame_rate.denominator().to_string())
            .replace("{num}",&self.nominal_frame_rate.numerator().to_string())
    }
    pub fn duration_argument(&self)->Result<String>{
        let us=self.duration.ceil_units(1_000_000)?;Ok(format!("{}.{:06}",us/1_000_000,us%1_000_000))
    }
    pub fn validate(&self)->Result<()> {
        if ![Rational::new(1,2)?,Rational::new(1,1)?,Rational::new(2,1)?].contains(&self.speed) || self.dissolve.numerator()<0 || self.dissolve>Rational::new(5,1)? {return Err(Error::InvalidProject("render timing settings"));}
        if self.requested.segments.len()!=self.segments.len()||self.requested.duration!=self.duration {return Err(Error::InvalidProject("render timing provenance"));}
        if self.segments.is_empty()||self.segments.len()>MAX_RENDER_SEGMENTS||!self.duration.positive(){return Err(Error::InvalidProject("render segments or duration"));}
        if self.join_fades_samples.len()!=self.segments.len(){return Err(Error::InvalidProject("audio join-fade count"));}
        for (s,(fade_in,fade_out)) in self.segments.iter().zip(&self.join_fades_samples){
            if *fade_in<0||*fade_out<0{return Err(Error::InvalidProject("negative audio join fade"));}
            if let Some(rate)=self.sample_rate {
                let len=s.output_samples.ok_or(Error::InvalidProject("audio join samples"))?;
                if *fade_in>len/4||*fade_out>len/4||*fade_in>Rational::new(1,100)?.ceil_units(i64::from(rate))?||*fade_out>Rational::new(1,100)?.ceil_units(i64::from(rate))?{return Err(Error::InvalidProject("audio join-fade bound"));}
            }else if *fade_in!=0||*fade_out!=0{return Err(Error::InvalidProject("audio fade without audio"));}
        }
        let mut previous_output=-1;
        let mut cursor=Rational::new(0,1)?;
        let rate=if self.requires_branching(){Some(crate::interchange::EditRate::new(self.nominal_frame_rate,false)?)}else{None};
        for (i,(s,requested)) in self.segments.iter().zip(&self.requested.segments).enumerate() {
            tempo_filters(s.speed)?;
            if s.speed!=requested.source_range.duration()?.checked_div(requested.output_range.duration()?)? {return Err(Error::InvalidProject("render segment speed provenance"));}
            validate_tempo_span(s.speed,self.sample_rate,requested.source_range.duration()?,requested.output_range.duration()?)?;
            if i>0{cursor=cursor.checked_sub(self.dissolve)?;}
            if requested.output_range.start!=cursor || s.output_start_us!=cursor.nearest_units(1_000_000)? || s.output_end_us!=requested.output_range.end.nearest_units(1_000_000)? {
                return Err(Error::InvalidProject("render output clock provenance"));
            }
            if self.segments.len()>1 && self.dissolve.ticks(2)?>requested.output_range.duration()?{return Err(Error::InvalidProject("render dissolve overlap"));}
            if let Some(rate)=rate{for time in [requested.source_range.start,requested.source_range.end,requested.output_range.start,requested.output_range.end]{rate.exact_frames(time)?;}}
            if s.start_pts>=s.end_pts || s.start_us>=s.end_us || s.output_start_us<=previous_output {return Err(Error::InvalidProject("render segment ordering"));}
            if self.sample_rate.is_some() && !(s.start_sample.zip(s.end_sample).is_some_and(|(a,b)|a>=0&&b>a)&&s.output_samples.is_some_and(|v|v>0)){return Err(Error::InvalidProject("audio segment range"));}
            if let Some(rate)=self.sample_rate {
                let scale=i64::from(rate);
                if s.start_sample!=Some(requested.source_range.start.ceil_units(scale)?) || s.end_sample!=Some(requested.source_range.end.ceil_units(scale)?)
                    || s.output_samples!=Some(requested.output_range.end.ceil_units(scale)?-requested.output_range.start.ceil_units(scale)?) {
                    return Err(Error::InvalidProject("render sample clock provenance"));
                }
            }
            previous_output=s.output_start_us;cursor=requested.output_range.end;
        }
        if cursor!=self.duration{return Err(Error::InvalidProject("render terminal clock"));}Ok(())
    }
}

/// Keep each atempo stage inside the supported [0.5, 2] range. Exact
/// literals avoid rounding an unsupported or corrupted rate into a valid one.
fn tempo_filters(speed:Rational)->Result<&'static str>{
    if speed==Rational::new(1,4)?{Ok(",atempo=0.5,atempo=0.5")}
    else if speed==Rational::new(1,2)?{Ok(",atempo=0.5")}
    else if speed==Rational::new(1,1)?{Ok("")}
    else if speed==Rational::new(2,1)?{Ok(",atempo=2.0")}
    else if speed==Rational::new(4,1)?{Ok(",atempo=2.0,atempo=2.0")}
    else{Err(Error::Unsupported("effective segment speed must be 0.25, 0.5, 1, 2 or 4"))}
}

fn validate_tempo_span(speed:Rational,sample_rate:Option<u32>,source_length:Rational,output_length:Rational)->Result<()> {
    let minimum=Rational::new(i64::from(MIN_TEMPO_SEGMENT_MS),1000)?;
    if sample_rate.is_some() && speed!=Rational::new(1,1)? && (source_length<minimum || output_length<minimum) {
        return Err(Error::Unsupported("speed-changed audio requires at least 100 ms of selected source and output per segment; use longer entries, a larger preview window or omit audio"));
    }
    Ok(())
}

fn bound_assembly_buffer(project:&Project,variant:&str,timeline:&Timeline,frame_rate:Rational,sample_rate:Option<u32>,include_video:bool)->Result<()> {
    if !timeline.segments.windows(2).any(|pair|pair[1].source_range.start<pair[0].source_range.end){return Ok(());}
    let source=&project.sources[0];
    let mut width=if include_video{u64::from(source.media.video.width.ok_or(Error::InvalidProject("assembly source width"))?)}else{0};
    let mut height=if include_video{u64::from(source.media.video.height.ok_or(Error::InvalidProject("assembly source height"))?)}else{0};
    if let Some(f)=project.variant(variant)?.framing.as_ref().filter(|f|f.active()) {
        width=width.max(u64::from(f.target.width));height=height.max(u64::from(f.target.height));
    }
    // Account for aligned RGBA-sized frames, even when the actual branch uses
    // less memory in YUV420. Repeated occurrences are counted independently.
    let aligned_height=height.checked_add(63).ok_or(Error::LimitExceeded("assembly frame dimensions"))?/64*64;
    let bytes_per_frame=width.checked_add(63).and_then(|w|(w/64*64).checked_mul(aligned_height)).and_then(|p|p.checked_mul(4)).and_then(|p|p.checked_add(4096)).ok_or(Error::LimitExceeded("assembly frame dimensions"))?;
    let channels=u64::from(source.media.audio.as_ref().and_then(|a|a.channels).unwrap_or(0));
    let mut decoded_to=Rational::new(0,1)?;
    for (i,current) in timeline.segments.iter().enumerate() {
        decoded_to=decoded_to.max(current.source_range.end);
        let mut bytes=0u64;
        for future in timeline.segments.iter().skip(i+1) {
            let end=future.source_range.end.min(decoded_to);
            if end<=future.source_range.start{continue;}
            let retained=end.checked_sub(future.source_range.start)?;
            let speed=future.source_range.duration()?.checked_div(future.output_range.duration()?)?;
            let payload_duration=retained.max(retained.checked_div(speed)?);
            let frames=u64::try_from(payload_duration.checked_mul(frame_rate)?.ceil_units(1)?).map_err(|_|Error::LimitExceeded("assembly buffered frames"))?;
            let video_bytes=if include_video{frames.checked_mul(bytes_per_frame).ok_or(Error::LimitExceeded("assembly video buffer"))?}else{0};
            let audio_bytes=if let Some(rate)=sample_rate {u64::try_from(payload_duration.ceil_units(i64::from(rate))?).ok().and_then(|n|n.checked_mul(channels)).and_then(|n|n.checked_mul(8)).ok_or(Error::LimitExceeded("assembly audio buffer"))?}else{0};
            bytes=bytes.checked_add(video_bytes).and_then(|b|b.checked_add(audio_bytes)).ok_or(Error::LimitExceeded("assembly buffer"))?;
            if bytes>MAX_ASSEMBLY_BUFFER_BYTES{return Err(Error::LimitExceeded("reordered assembly retained payload exceeds 256 MiB; use shorter entries or a smaller source"));}
        }
    }
    Ok(())
}

fn decimal(time:Rational)->Result<String>{let us=time.nearest_units(1_000_000)?;Ok(format!("{}.{:06}",us/1_000_000,us%1_000_000))}
