//! Opt-in CPU ONNX adapter for a host-selected, pinned monolithic Silero graph.
//! No downloader, package installer, custom operators or GPU providers. Call only
//! inside the existing trusted native/provider boundary, never the terminal UI.
//! `ort`'s environment/library are process-global: use one runtime per provider
//! process and restart that process to change/unload the runtime itself.
use crate::{Cancellation,Error,Result};
use crate::model_pack::{VerifiedModelPack,ModelIdentity,digest,hash};
use crate::speech::{SpeechModelProvider,SpeechSession,SpeechTensorOutput,SPEECH_INPUT,SPEECH_STATE};
use ort::{session::{Session,RunOptions},session::builder::GraphOptimizationLevel,value::{Tensor,ValueType},tensor::TensorElementType};
use std::{path::{Path,PathBuf},sync::{Arc,Mutex,Condvar,OnceLock,atomic::{AtomicBool,AtomicUsize,Ordering}},
          thread::{self,JoinHandle},time::{Duration,Instant}};

pub const ORT_ADAPTER:&str="ort-2.0.0-rc.10-cpu-v1";
const RUNTIME_LIMIT:u64=512*1024*1024;
static RUNTIME:OnceLock<Mutex<Option<(PathBuf,String,String)>>>=OnceLock::new();
static SESSIONS:AtomicUsize=AtomicUsize::new(0);

/// Loads ONLY the three explicitly chosen data files. No directory scan or URL.
/// Selection authority and distribution rights must be established by the host.
pub fn read_selected_pack(manifest:&Path,weights:&Path,notices:&Path,expected_manifest:&str,
                          cancel:&Cancellation)->Result<VerifiedModelPack>{
    crate::native_model_store::read_selected_pack(manifest, weights, notices, expected_manifest, cancel)
}

/// Explicitly initialize an approved native runtime and report its build hash.
/// This is a privileged setup operation for the component owner, not a harmless
/// status lookup: it loads native code. Must precede ANY other ort API call.
pub fn initialize_selected_runtime(path:&Path,expected_artifact:&str,cancel:&Cancellation)->Result<String>{
    hash(expected_artifact)?;cancel.check()?;
    if !path.is_absolute()||path.components().any(|c|matches!(c,std::path::Component::ParentDir)){
        return Err(Error::InvalidInput("absolute reviewed ONNX Runtime path"));
    }
    let canonical=std::fs::canonicalize(path).map_err(|_|Error::Io("resolve ONNX Runtime"))?;
    if canonical!=path{return Err(Error::InvalidInput("canonical non-symlink ONNX Runtime path required"));}
    let before=crate::native::fingerprint(path,RUNTIME_LIMIT,cancel)?;
    if before.sha256!=expected_artifact{return Err(Error::ToolIdentityChanged);}
    let mut global=RUNTIME.get_or_init(||Mutex::new(None)).lock().map_err(|_|Error::Poisoned)?;
    if let Some((old_path,old_hash,build))=global.as_ref(){
        if old_path!=path||old_hash!=expected_artifact{return Err(Error::ToolIdentityChanged);}
        return Ok(build.clone());
    }
    let runtime_path=path.to_str().ok_or(Error::InvalidInput("UTF-8 ONNX Runtime library path"))?;
    // A pre-existing ort environment may have different providers/telemetry.
    // Reject it rather than overriding another component's process-wide state.
    let initialized=std::panic::catch_unwind(std::panic::AssertUnwindSafe(||{
        ort::init_from(runtime_path).with_name("automexia-video-speech")
            .with_telemetry(false).commit()
    })).map_err(|_|Error::InvalidOutput("ONNX Runtime initialization panic"))?
        .map_err(|_|Error::InvalidOutput("ONNX Runtime initialization"))?;
    if !initialized{return Err(Error::Unsupported("ort already initialized outside the reviewed Video adapter"));}
    let after=crate::native::fingerprint(path,RUNTIME_LIMIT,cancel)?;
    if before!=after{return Err(Error::ToolIdentityChanged);}
    let build=digest(ort::info().as_bytes(),cancel)?;
    *global=Some((canonical,expected_artifact.to_owned(),build.clone()));
    Ok(build)
}

/// Constructing a provider keeps verified model bytes but does not build a model
/// session or load a native runtime. At most one session per provider, four per
/// process. The caller's existing host job system remains the scheduler.
pub struct SileroCpuProvider {pack:VerifiedModelPack,runtime:PathBuf,active:Arc<AtomicBool>,inference_timeout:Duration}
impl SileroCpuProvider {
    pub fn new(pack:VerifiedModelPack,runtime:PathBuf,inference_timeout:Duration)->Result<Self>{
        pack.identity().validate()?;
        if pack.identity().contract != crate::model_pack::SILERO_CONTRACT || pack.identity().preprocessing != crate::model_pack::SPEECH_PROCESSING {
            return Err(Error::Unsupported("Silero model contract"));
        }
        if pack.identity().runtime.adapter!=ORT_ADAPTER{return Err(Error::Unsupported("ORT adapter identity"));}
        if !runtime.is_absolute()||inference_timeout<Duration::from_millis(10)||inference_timeout>Duration::from_secs(30){
            return Err(Error::InvalidInput("selected runtime/inference timeout"));
        }
        Ok(Self{pack,runtime,active:Arc::new(AtomicBool::new(false)),inference_timeout})
    }
}
impl SpeechModelProvider for SileroCpuProvider {
    fn identity(&self)->&ModelIdentity{self.pack.identity()}
    fn revalidate(&self,cancel:&Cancellation)->Result<()> {
        cancel.check()?;
        let observed=crate::native::fingerprint(&self.runtime,RUNTIME_LIMIT,cancel)?;
        if observed.sha256!=self.identity().runtime.artifact_sha256{return Err(Error::ToolIdentityChanged);}
        // Immutable verified bytes cannot change. The component manager separately
        // owns activation revocation; no model filepath is reopened for inference.
        Ok(())
    }
    fn open(&self,cancel:&Cancellation)->Result<Box<dyn SpeechSession>>{
        self.revalidate(cancel)?;
        let permit=SessionPermit::take(Arc::clone(&self.active))?;
        let build=initialize_selected_runtime(&self.runtime,&self.identity().runtime.artifact_sha256,cancel)?;
        if build!=self.identity().runtime.build_info_sha256{return Err(Error::ToolIdentityChanged);}
        cancel.check()?;
        let make=||->ort::Result<Session>{
            Session::builder()?
                .with_no_environment_execution_providers()?
                .with_intra_threads(1)?.with_inter_threads(1)?
                .with_parallel_execution(false)?.with_memory_pattern(false)?
                .with_intra_op_spinning(false)?.with_inter_op_spinning(false)?
                .with_optimization_level(GraphOptimizationLevel::Level1)?
                .commit_from_memory(self.pack.weights())
        };
        let session=std::panic::catch_unwind(std::panic::AssertUnwindSafe(make))
            .map_err(|_|Error::InvalidOutput("model loading panic"))?
            .map_err(|_|Error::InvalidOutput("load selected embedded speech model"))?;
        cancel.check()?;self.revalidate(cancel)?;
        let mut inputs:Vec<&str>=session.inputs.iter().map(|i|i.name.as_str()).collect();inputs.sort_unstable();
        let mut outputs:Vec<&str>=session.outputs.iter().map(|i|i.name.as_str()).collect();outputs.sort_unstable();
        if inputs!=["input","sr","state"]||outputs!=["output","stateN"]{
            return Err(Error::Unsupported("Silero input/output names differ from selected contract"));
        }
        for input in &session.inputs {
            let (kind, shape): (TensorElementType, &[i64]) = match input.name.as_str() {
                "input" => (TensorElementType::Float32, &[1, SPEECH_INPUT as i64]),
                "state" => (TensorElementType::Float32, &[2, 1, 128]),
                "sr" => (TensorElementType::Int64, &[]),
                _ => return Err(Error::Unsupported("Silero input name")),
            };
            check_tensor_contract(&input.input_type, kind, shape)?;
        }
        for output in &session.outputs {
            let shape: &[i64] = match output.name.as_str() {
                "output" => &[1, 1], "stateN" => &[2, 1, 128],
                _ => return Err(Error::Unsupported("Silero output name")),
            };
            check_tensor_contract(&output.output_type, TensorElementType::Float32, shape)?;
        }
        let watch=InferenceWatch::new()?;
        Ok(Box::new(OrtSpeechSession{session,identity:self.identity().clone(),owner:cancel.clone(),watch,
            timeout:self.inference_timeout,failed:false,_permit:permit}))
    }
}
fn shape_matches(actual: &[i64], expected: &[i64]) -> bool {
    actual.len() == expected.len() && actual.iter().zip(expected).all(|(a, e)| *a == *e || *a == -1)
}
fn check_tensor_contract(value: &ValueType, expected: TensorElementType, dimensions: &[i64]) -> Result<()> {
    match value {
        ValueType::Tensor { ty, shape, .. } if *ty == expected && shape_matches(&shape[..], dimensions) => Ok(()),
        _ => Err(Error::Unsupported("Silero tensor type or declared shape")),
    }
}

struct SessionPermit {active:Arc<AtomicBool>}
impl SessionPermit {
    fn take(active:Arc<AtomicBool>)->Result<Self>{
        if active.compare_exchange(false,true,Ordering::AcqRel,Ordering::Acquire).is_err(){return Err(Error::Busy);}
        if SESSIONS.fetch_update(Ordering::AcqRel,Ordering::Acquire,|n|(n<4).then_some(n+1)).is_err(){
            active.store(false,Ordering::Release);return Err(Error::Busy);
        }Ok(Self{active})
    }
}
impl Drop for SessionPermit {fn drop(&mut self){SESSIONS.fetch_sub(1,Ordering::AcqRel);self.active.store(false,Ordering::Release);}}

fn inference_stop_error(cancel:&Cancellation,deadline:Instant)->Option<Error> {
    // Preserve Timeout from an inherited whole-operation deadline. Treating
    // is_cancelled() as a boolean here would incorrectly relabel it Cancelled.
    cancel.check().err().or_else(||(Instant::now()>=deadline).then_some(Error::Timeout))
}
struct WatchState {active:Option<(Cancellation,Instant)>,stop:bool,error:Option<Error>}
pub(crate) struct InferenceWatch {pub(crate) options:Arc<RunOptions>,shared:Arc<(Mutex<WatchState>,Condvar)>,thread:Option<JoinHandle<()>>}
impl InferenceWatch {
    pub(crate) fn new()->Result<Self>{
        let options=Arc::new(RunOptions::new().map_err(|_|Error::InvalidOutput("create model run options"))?);
        let shared=Arc::new((Mutex::new(WatchState{active:None,stop:false,error:None}),Condvar::new()));
        let worker_shared=Arc::clone(&shared);let worker_options=Arc::clone(&options);
        let thread=thread::Builder::new().name("video-model-cancel".into()).spawn(move||{
            let (lock,notify)=&*worker_shared;
            loop {
                let mut state=match lock.lock(){Ok(v)=>v,Err(_)=>{let _=worker_options.terminate();return;}};
                if state.stop{return;}
                if let Some((cancel,deadline))=&state.active {
                    let error=inference_stop_error(cancel,*deadline);
                    if let Some(error)=error{state.error=Some(error);let _=worker_options.terminate();return;}
                }
                // Sleep while idle as well; one thread per LOADED session only.
                if notify.wait_timeout(state,Duration::from_millis(10)).is_err(){let _=worker_options.terminate();return;}
            }
        }).map_err(|_|Error::Io("start model cancellation observer"))?;
        Ok(Self{options,shared,thread:Some(thread)})
    }
    pub(crate) fn begin(&self,cancel:Cancellation,timeout:Duration)->Result<()> {
        cancel.check()?;let mut state=self.shared.0.lock().map_err(|_|Error::Poisoned)?;
        if let Some(error)=&state.error{return Err(error.clone());}
        state.active=Some((cancel,Instant::now().checked_add(timeout).ok_or(Error::InvalidInput("model inference deadline"))?));self.shared.1.notify_one();Ok(())
    }
    pub(crate) fn end(&self)->Result<()> {
        let mut state=self.shared.0.lock().map_err(|_|Error::Poisoned)?;
        // Check synchronously too, so a fast return cannot outrun the watcher.
        let error=state.error.clone().or_else(||state.active.as_ref().and_then(|(c,d)|{
            inference_stop_error(c,*d)
        }));
        state.active=None;if let Some(error)=error{state.error=Some(error.clone());Err(error)}else{Ok(())}
    }
}
impl Drop for InferenceWatch {
    fn drop(&mut self){if let Ok(mut state)=self.shared.0.lock(){state.stop=true;self.shared.1.notify_one();}
        let _=self.options.terminate();if let Some(thread)=self.thread.take(){let _=thread.join();}}
}
struct OrtSpeechSession {session:Session,identity:ModelIdentity,owner:Cancellation,watch:InferenceWatch,timeout:Duration,failed:bool,_permit:SessionPermit}
impl SpeechSession for OrtSpeechSession {
    fn identity(&self)->&ModelIdentity{&self.identity}
    fn infer(&mut self,input:&[f32;SPEECH_INPUT],state:&[f32;SPEECH_STATE],cancel:&Cancellation)->Result<SpeechTensorOutput>{
        if self.failed{return Err(Error::InvalidOutput("failed model session"));}
        let result=(||{
            self.owner.check()?;cancel.check()?;
            if input.iter().any(|v|!v.is_finite()||v.abs()>1.0)||state.iter().any(|v|!v.is_finite()||v.abs()>1e6){return Err(Error::InvalidInput("speech input tensor values"));}
            let audio=Tensor::from_array(([1usize,SPEECH_INPUT],input.to_vec())).map_err(|_|Error::InvalidOutput("speech input tensor"))?;
            let recurrent=Tensor::from_array(([2usize,1,128],state.to_vec())).map_err(|_|Error::InvalidOutput("speech state tensor"))?;
            let rate=Tensor::from_array((Vec::<usize>::new(),vec![16000i64])).map_err(|_|Error::InvalidOutput("speech rate tensor"))?;
            self.watch.begin(self.owner.linked(cancel)?,self.timeout)?;
            let run=self.session.run_with_options(ort::inputs!{"input"=>audio,"state"=>recurrent,"sr"=>rate},&*self.watch.options);
            let cancellation=self.watch.end();cancellation?;
            let output=run.map_err(|_|Error::InvalidOutput("speech inference failed"))?;
            let (shape,p)=output.get("output").ok_or(Error::InvalidOutput("speech probability missing"))?
                .try_extract_tensor::<f32>().map_err(|_|Error::InvalidOutput("speech probability type"))?;
            let (state_shape,values)=output.get("stateN").ok_or(Error::InvalidOutput("speech state missing"))?
                .try_extract_tensor::<f32>().map_err(|_|Error::InvalidOutput("speech state type"))?;
            if &shape[..]!=[1i64,1]||p.len()!=1||&state_shape[..]!=[2i64,1,128]||values.len()!=SPEECH_STATE{
                return Err(Error::InvalidOutput("speech output tensor shapes"));
            }
            if !p[0].is_finite()||!(0.0..=1.0).contains(&p[0])||values.iter().any(|v|!v.is_finite()||v.abs()>1e6){return Err(Error::InvalidOutput("speech output tensor values"));}
            let mut next=[0.0;SPEECH_STATE];next.copy_from_slice(values);self.owner.check()?;cancel.check()?;
            Ok(SpeechTensorOutput{probability:p[0],state:next})
        })();
        if result.is_err(){self.failed=true;}result
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn declared_tensor_shapes_admit_dynamic_axes_but_not_incompatible_fixed_axes() {
        assert!(shape_matches(&[-1, -1], &[1, SPEECH_INPUT as i64]));
        assert!(shape_matches(&[2, -1, 128], &[2, 1, 128]));
        assert!(shape_matches(&[], &[]));
        assert!(!shape_matches(&[1], &[]));
        assert!(!shape_matches(&[1, 512], &[1, SPEECH_INPUT as i64]));
        assert!(!shape_matches(&[2, 1, 64], &[2, 1, 128]));
        assert!(!shape_matches(&[0, 576], &[1, SPEECH_INPUT as i64]));
        assert!(!shape_matches(&[-2, 576], &[1, SPEECH_INPUT as i64]));
    }
    #[test]
    fn inherited_deadline_remains_timeout_in_shared_inference_watcher() {
        let expired=Cancellation::new().with_deadline(Instant::now());
        assert_eq!(inference_stop_error(&expired,Instant::now()+Duration::from_secs(60)),Some(Error::Timeout));
        let cancelled=Cancellation::new();cancelled.cancel();
        assert_eq!(inference_stop_error(&cancelled,Instant::now()+Duration::from_secs(60)),Some(Error::Cancelled));
        assert_eq!(inference_stop_error(&Cancellation::new(),Instant::now()),Some(Error::Timeout));
    }
    #[test]
    fn malformed_expected_digest_fails_before_selected_file_io() {
        let path=Path::new("/does-not-exist-model-pack");
        assert!(matches!(read_selected_pack(path,path,path,"not-a-sha256",&Cancellation::new()),Err(Error::InvalidInput(_))));
    }
}
