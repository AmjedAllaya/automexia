//! Explicit, owner-scoped, bounded in-memory reuse of SOURCE OBSERVATIONS.
//!
//! Never stores projects, approval, paths, raw frames, PCM or rendered media.
//! Entries are typed private values: no deserialization/import of untrusted caches.
//! Existing analyze_* APIs remain uncached; *_cached opts in using this object.
use crate::{Cancellation, Error, Result};
use crate::host::{InputFile, MediaHost, RuntimeCapabilities};
use crate::project::Project;
use crate::pause::EnergyObservation;
use crate::voice::AudioPreflight;
use crate::voice_render::LoudnessMeasurement;
use crate::color::{BoundaryKind, ColorProfile, ColorReport, ColorSettings, ColorShot, ShotEvidence, COLOR_VERSION};
use serde::Serialize;
use sha2::{Digest, Sha256};
use std::{collections::BTreeMap, io::Write, mem::size_of};

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize)]
pub struct CacheLimits {
    pub max_entries: usize,
    /// Charged owned payload capacity; not an allocator/RSS limit.
    pub max_payload_bytes: usize,
    pub max_entry_bytes: usize,
}
impl Default for CacheLimits {
    fn default() -> Self { Self { max_entries: 16, max_payload_bytes: 8*1024*1024, max_entry_bytes: 1024*1024 } }
}
impl CacheLimits {
    pub fn validate(&self) -> Result<()> {
        if self.max_entries == 0 || self.max_entries > 64 || self.max_entry_bytes == 0 ||
            self.max_entry_bytes > self.max_payload_bytes || self.max_payload_bytes > 64*1024*1024 {
            return Err(Error::InvalidInput("observation cache limits"));
        } Ok(())
    }
}
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize)]
#[serde(rename_all="snake_case")]
pub enum CacheUse { Disabled, UnpinnedRuntime, Hit, MissStored, MissNotStored }
#[derive(Debug)]
pub struct CachedAnalysis<T> { pub report: T, pub cache: CacheUse }
#[derive(Debug, Clone, Copy, Default, PartialEq, Eq, Serialize)]
pub struct CacheStats {
    pub entries: usize, pub charged_bytes: usize, pub hits: u64,
    pub misses: u64, pub evictions: u64,
}
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Debug)]
pub(crate) struct ObservationKey([u8;32]);
#[derive(Debug, Clone, Copy, Serialize)]
pub(crate) enum AnalysisKind { PauseV1, VoiceV1, ColorV1 }

/// Small per-shot facts, not previously accepted color settings or edit intent.
#[derive(Debug, Clone)]
pub(crate) struct ObservedShot {
    range: crate::project::TimeRange, boundary: BoundaryKind, evidence: ShotEvidence,
}
#[derive(Debug, Clone)]
pub(crate) struct ColorObservation {
    shots: Vec<ObservedShot>, frames:u64, width:u32, height:u32,
}
impl ColorObservation {
    pub(crate) fn from_report(r:&ColorReport)->Self {
        Self {shots:r.profile().shots.iter().map(|s|ObservedShot {range:s.range,
            boundary:s.boundary,evidence:s.evidence.clone()}).collect(),frames:r.decoded_frames,
            width:r.analysis_width,height:r.analysis_height}
    }
    pub(crate) fn report(&self,p:&Project,settings:&ColorSettings)->Result<ColorReport> {
        p.validate()?;settings.validate()?;
        let source=p.sources.first().ok_or(Error::InvalidProject("color source"))?;
        let mut shots=Vec::with_capacity(self.shots.len());
        for (i,s) in self.shots.iter().enumerate() {
            s.evidence.validate()?;s.range.validate()?;
            let (adjustment,reason)=crate::color_analysis::recommend(&s.evidence,s.range.duration()?,settings)?;
            let changed=!adjustment.is_identity();
            shots.push(ColorShot {id:format!("shot-{}",i+1),range:s.range,boundary:s.boundary,
                evidence:s.evidence.clone(),adjustment,reason,enabled:changed,locked:false,user_override:false,
                disposition:if changed {crate::Disposition::NeedsReview} else {crate::Disposition::Ignore}});
        }
        ColorReport::new(p,ColorProfile {version:COLOR_VERSION,source_id:source.id.clone(),
            source_sha256:source.fingerprint.sha256.clone(),stream_index:source.media.video.index,
            duration:source.duration,enabled:true,settings:settings.clone(),shots},self.frames,self.width,self.height)
    }
}
#[derive(Debug, Clone)]
pub(crate) enum Observation {
    Pause(EnergyObservation),
    Voice { preflight: AudioPreflight, loudness: LoudnessMeasurement },
    Color(ColorObservation),
}
impl Observation {
    fn heap_capacity(&self)->Result<usize> {
        let n=match self {
            Self::Pause(v)=>v.quiet.capacity().checked_mul(size_of::<crate::pause::QuietInterval>()),
            Self::Color(v)=>v.shots.capacity().checked_mul(size_of::<ObservedShot>()),
            Self::Voice{preflight:v,..}=>{
                let mut n=v.channels.capacity().checked_mul(size_of::<crate::voice::ChannelPreflight>())
                    .and_then(|n|v.warnings.capacity().checked_mul(size_of::<String>()).and_then(|w|n.checked_add(w)))
                    .ok_or(Error::LimitExceeded("cache accounting"))?;
                for w in &v.warnings {n=n.checked_add(w.capacity()).ok_or(Error::LimitExceeded("cache accounting"))?;}
                Some(n)
            }
        };n.ok_or(Error::LimitExceeded("cache accounting"))
    }
}
struct Entry { source: String, value: Observation, charged: usize, used: u64 }
/// Scope one cache to one trusted user/workspace owner. Source authorization is
/// checked again on EVERY hit. No filesystem cache, models, threads or global state.
pub struct ObservationCache {
    limits: CacheLimits, owner: Cancellation, entries: BTreeMap<ObservationKey,Entry>,
    bytes: usize, clock: u64, hits: u64, misses: u64, evictions: u64,
}
impl ObservationCache {
    pub fn new(limits:CacheLimits)->Result<Self>{Self::with_owner(limits,Cancellation::new())}
    pub fn with_owner(limits:CacheLimits,owner:Cancellation)->Result<Self>{
        limits.validate()?;owner.check()?;
        Ok(Self{limits,owner,entries:BTreeMap::new(),bytes:0,clock:0,hits:0,misses:0,evictions:0})
    }
    /// Drop retained facts. This does not resurrect a cancelled cache owner.
    pub fn clear(&mut self){self.entries.clear();self.bytes=0;self.clock=0;}
    pub fn invalidate_source(&mut self,sha256:&str)->Result<usize>{
        self.live()?;if !hash_ok(sha256){return Err(Error::InvalidInput("source fingerprint"));}
        let keys:Vec<_>=self.entries.iter().filter(|(_,e)|e.source==sha256).map(|(k,_)|*k).collect();
        for k in &keys {self.remove(k);}
        Ok(keys.len())
    }
    /// Cancellation clears retained facts on the next access; the host should
    /// drop the cache on workspace revoke/unload rather than wait for an access.
    pub fn stats(&mut self)->CacheStats{
        if self.owner.is_cancelled(){self.clear();}
        CacheStats{entries:self.entries.len(),charged_bytes:self.bytes,hits:self.hits,misses:self.misses,evictions:self.evictions}
    }
    pub(crate) fn live(&mut self)->Result<()>{if self.owner.is_cancelled(){self.clear();return Err(Error::Cancelled);}Ok(())}
    fn tick(&mut self)->u64{
        if self.clock==u64::MAX {
            let mut order:Vec<_>=self.entries.iter().map(|(k,e)|(*k,e.used)).collect();
            order.sort_by_key(|(k,t)|(*t,*k));
            for (i,(k,_)) in order.iter().enumerate(){self.entries.get_mut(k).expect("known cache entry").used=i as u64+1;}
            self.clock=order.len() as u64;
        }
        self.clock+=1;self.clock
    }
    pub(crate) fn get(&mut self,k:&ObservationKey)->Result<Option<Observation>>{
        self.live()?;let now=self.tick();
        if let Some(e)=self.entries.get_mut(k){e.used=now;self.hits=self.hits.saturating_add(1);Ok(Some(e.value.clone()))}
        else{self.misses=self.misses.saturating_add(1);Ok(None)}
    }
    fn remove(&mut self,k:&ObservationKey){if let Some(e)=self.entries.remove(k){self.bytes-=e.charged;}}
    pub(crate) fn put(&mut self,k:ObservationKey,source:&str,value:Observation)->Result<CacheUse>{
        self.live()?;if !hash_ok(source){return Err(Error::InvalidInput("cache source identity"));}
        let source=source.to_owned();
        let charged=size_of::<Entry>().checked_add(size_of::<ObservationKey>()).and_then(|n|n.checked_add(source.capacity()))
            .and_then(|n|n.checked_add(value.heap_capacity().ok()?)).ok_or(Error::LimitExceeded("cache accounting"))?;
        if charged>self.limits.max_entry_bytes||charged>self.limits.max_payload_bytes{return Ok(CacheUse::MissNotStored);}
        // Encoding/validation/budget checks precede eviction: failed admission
        // does not discard a valid older observation.
        self.remove(&k);
        while self.entries.len()>=self.limits.max_entries||self.bytes>self.limits.max_payload_bytes-charged {
            let oldest=self.entries.iter().min_by_key(|(k,e)|(e.used,**k)).map(|(k,_)|*k).ok_or(Error::InvalidInput("cache accounting invariant"))?;
            self.remove(&oldest);self.evictions=self.evictions.saturating_add(1);
        }
        let used=self.tick();self.bytes+=charged;
        self.entries.insert(k,Entry{source,value,charged,used});Ok(CacheUse::MissStored)
    }
}
impl<H:MediaHost> crate::VideoExtension<H> {
    /// Cache lifetime follows this extension; ordinary calls remain uncached.
    pub fn observation_cache(&self,limits:CacheLimits)->Result<ObservationCache>{
        ObservationCache::with_owner(limits,self.workflow_scope(&Cancellation::new())?)
    }
}
fn hash_ok(s:&str)->bool{s.len()==64&&s.bytes().all(|b|b.is_ascii_digit()||(b'a'..=b'f').contains(&b))}
/// Stream settings into a bounded digest without allocating a large JSON string.
struct KeyDigest {hash:Sha256,bytes:usize}
impl Write for KeyDigest {
    fn write(&mut self,b:&[u8])->std::io::Result<usize>{
        if b.len()>1024*1024-self.bytes{return Err(std::io::Error::new(std::io::ErrorKind::InvalidData,"cache key budget"));}
        self.hash.update(b);self.bytes+=b.len();Ok(b.len())
    }
    fn flush(&mut self)->std::io::Result<()>{Ok(())}
}
pub(crate) fn key<S:Serialize,E:Serialize>(p:&Project,input:&InputFile,runtime:&RuntimeCapabilities,kind:AnalysisKind,settings:&S,extra:&E)->Result<Option<ObservationKey>>{
    p.validate()?;let source=p.sources.first().ok_or(Error::InvalidProject("analysis source"))?;source.check_input(input)?;
    if !runtime.ffmpeg_identity.as_deref().is_some_and(hash_ok)||!runtime.ffprobe_identity.as_deref().is_some_and(hash_ok){return Ok(None);}
    let material=("automexia-source-observation-v1",kind,&source.fingerprint,&source.media,
        source.timeline_origin,source.duration,settings,extra,runtime);
    let mut out=KeyDigest{hash:Sha256::new(),bytes:0};
    serde_json::to_writer(&mut out,&material).map_err(|_|Error::LimitExceeded("observation key serialization"))?;
    let bytes:[u8;32]=out.hash.finalize().into();Ok(Some(ObservationKey(bytes)))
}

// Tests may inspect private values; no external caller can insert unverified facts.
#[cfg(test)]
mod tests {
    use super::*;
    fn obs()->Observation{Observation::Color(ColorObservation{shots:vec![],frames:0,width:1,height:1})}
    fn k(n:u8)->ObservationKey{ObservationKey([n;32])}
    #[test]fn defaults_are_bounded(){CacheLimits::default().validate().unwrap();}
    #[test]fn rejects_zero_or_unbounded_capacity(){for l in [CacheLimits{max_entries:0,..Default::default()},CacheLimits{max_payload_bytes:0,..Default::default()},CacheLimits{max_entries:65,..Default::default()},CacheLimits{max_entry_bytes:usize::MAX,..Default::default()}]{assert!(l.validate().is_err());}}
    #[test]fn no_implicit_entries(){assert_eq!(ObservationCache::new(CacheLimits::default()).unwrap().stats().entries,0);}
    #[test]fn charged_bytes_are_released(){let mut c=ObservationCache::new(CacheLimits::default()).unwrap();c.put(k(1),&"a".repeat(64),obs()).unwrap();assert!(c.stats().charged_bytes>0);c.clear();assert_eq!(c.stats().charged_bytes,0);}
    #[test]fn exact_key_hit(){let mut c=ObservationCache::new(CacheLimits::default()).unwrap();c.put(k(1),&"a".repeat(64),obs()).unwrap();assert!(c.get(&k(1)).unwrap().is_some());assert!(c.get(&k(2)).unwrap().is_none());assert_eq!(c.stats().hits,1);}
    #[test]fn least_recent_entry_is_evicted(){let mut c=ObservationCache::new(CacheLimits{max_entries:2,..Default::default()}).unwrap();for n in 1..=2{c.put(k(n),&"a".repeat(64),obs()).unwrap();}c.get(&k(1)).unwrap();c.put(k(3),&"a".repeat(64),obs()).unwrap();assert!(c.get(&k(2)).unwrap().is_none());assert!(c.get(&k(1)).unwrap().is_some());}
    #[test]fn oversized_value_is_not_retained(){let mut c=ObservationCache::new(CacheLimits{max_payload_bytes:1,max_entry_bytes:1,..Default::default()}).unwrap();assert_eq!(c.put(k(1),&"a".repeat(64),obs()).unwrap(),CacheUse::MissNotStored);assert_eq!(c.stats().entries,0);}
    #[test]fn replacement_does_not_double_charge(){let mut c=ObservationCache::new(CacheLimits::default()).unwrap();c.put(k(1),&"a".repeat(64),obs()).unwrap();let bytes=c.stats().charged_bytes;c.put(k(1),&"a".repeat(64),obs()).unwrap();assert_eq!(c.stats().charged_bytes,bytes);}
    #[test]fn invalidation_is_source_specific(){let mut c=ObservationCache::new(CacheLimits::default()).unwrap();c.put(k(1),&"a".repeat(64),obs()).unwrap();c.put(k(2),&"b".repeat(64),obs()).unwrap();assert_eq!(c.invalidate_source(&"a".repeat(64)).unwrap(),1);assert!(c.get(&k(2)).unwrap().is_some());}
    #[test]fn cancelled_owner_clears_entries(){let owner=Cancellation::new();let mut c=ObservationCache::with_owner(CacheLimits::default(),owner.clone()).unwrap();c.put(k(1),&"a".repeat(64),obs()).unwrap();owner.cancel();assert!(matches!(c.get(&k(1)),Err(Error::Cancelled)));assert_eq!(c.stats().entries,0);}
    #[test]fn clear_does_not_revive_owner(){let owner=Cancellation::new();let mut c=ObservationCache::with_owner(CacheLimits::default(),owner.clone()).unwrap();owner.cancel();c.clear();assert!(c.live().is_err());}
    #[test]fn recency_overflow_is_renumbered(){let mut c=ObservationCache::new(CacheLimits{max_entries:2,..Default::default()}).unwrap();c.put(k(1),&"a".repeat(64),obs()).unwrap();c.put(k(2),&"a".repeat(64),obs()).unwrap();c.clock=u64::MAX;c.get(&k(1)).unwrap();c.put(k(3),&"a".repeat(64),obs()).unwrap();assert!(c.get(&k(2)).unwrap().is_none());}
    fn material()->(Project,InputFile,RuntimeCapabilities){
        use crate::project::{ProjectSource,ResolvedSettings,FrozenRenderSettings};
        use crate::host::FileStamp;
        let loc=std::env::temp_dir().join("cache-key.amxv");
        let m=crate::media::parse_probe(include_bytes!("../tests/fixtures/probe-base.json")).unwrap();
        let input=InputFile{canonical_path:loc.with_file_name("source.mp4"),stamp:FileStamp{size:100,sha256:"a".repeat(64),file_id:None,modified_ns:None}};
        let source=ProjectSource::from_probe("source-1",&input,&m,m.select(crate::StreamSelection::default()).unwrap(),&loc).unwrap();
        let p=Project::new("keys",source,ResolvedSettings{workflow:None,voice_cleanup:None,voice_enhancement:None,color_correction:None,pause_cleanup:None,preset_name:None,preset_revision:None,render:FrozenRenderSettings::from_options(&crate::RenderOptions::default()).unwrap()}).unwrap();
        (p,input,RuntimeCapabilities{ffmpeg_identity:Some("b".repeat(64)),ffprobe_identity:Some("c".repeat(64)),..Default::default()})
    }
    #[test]fn kind_separates_observation_types(){let(p,i,r)=material();assert_ne!(key(&p,&i,&r,AnalysisKind::PauseV1,&(),&()).unwrap(),key(&p,&i,&r,AnalysisKind::ColorV1,&(),&()).unwrap());}
    #[test]fn selected_stream_identity_changes_key(){let(mut p,i,r)=material();let a=key(&p,&i,&r,AnalysisKind::PauseV1,&(),&()).unwrap();p.sources[0].media.audio.as_mut().unwrap().index=3;assert_ne!(a,key(&p,&i,&r,AnalysisKind::PauseV1,&(),&()).unwrap());}
    #[test]fn settings_and_declared_boundaries_change_key(){let(p,i,r)=material();let a=key(&p,&i,&r,AnalysisKind::ColorV1,&1,&Vec::<u8>::new()).unwrap();assert_ne!(a,key(&p,&i,&r,AnalysisKind::ColorV1,&2,&Vec::<u8>::new()).unwrap());assert_ne!(a,key(&p,&i,&r,AnalysisKind::ColorV1,&1,&vec![1u8]).unwrap());}
    #[test]fn settings_key_has_bounded_serialization(){let(p,i,r)=material();assert!(matches!(key(&p,&i,&r,AnalysisKind::PauseV1,&"x".repeat(1024*1024),&()),Err(Error::LimitExceeded(_))));}
    #[test]fn missing_runtime_pin_declines_reuse(){let(p,i,mut r)=material();r.ffprobe_identity=None;assert!(key(&p,&i,&r,AnalysisKind::PauseV1,&(),&()).unwrap().is_none());}
    #[test]fn capability_change_invalidates_key(){let(p,i,mut r)=material();let a=key(&p,&i,&r,AnalysisKind::PauseV1,&(),&()).unwrap();r.filters.insert("new-filter".into());assert_ne!(a,key(&p,&i,&r,AnalysisKind::PauseV1,&(),&()).unwrap());}

}
