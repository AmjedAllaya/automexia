//! Step 3: renderer-independent review of the *real* project model.
//!
//! The host displays these values in its existing list/detail surfaces and maps
//! keyboard, pointer and palette actions to the same `dispatch` method. This is
//! not a new terminal renderer, input hook, permission service or event loop.
use crate::project::{Disposition, EditKind, EditOrigin, Project, TimeRange};
use crate::{Cancellation, Error, Rational, Result};
use serde::Serialize;
use std::sync::atomic::{AtomicU64, Ordering};

pub const MAX_REVIEW_QUERY_BYTES: usize = 256;
pub const MAX_REVIEW_PAGE: usize = 100;
static NEXT_SESSION: AtomicU64 = AtomicU64::new(1);

#[derive(Debug, Clone, PartialEq, Eq, Serialize)]
#[serde(tag = "kind", content = "id", rename_all = "snake_case")]
pub enum ReviewTarget {
    Clip(String),
    Operation(String),
    ColorShot(String),
    FramingVariant(String),
    PresentationVariant(String),
    TimingVariant(String),
    AssemblyVariant(String),
}
impl ReviewTarget {
    pub fn id(&self) -> &str {
        match self { Self::Clip(id) | Self::Operation(id) | Self::ColorShot(id) | Self::FramingVariant(id) | Self::PresentationVariant(id) | Self::TimingVariant(id) | Self::AssemblyVariant(id) => id }
    }
}

/// Integrity/optimistic-concurrency identity, NOT a signature or permission.
/// The digest also catches hand-edited project contents with an unchanged revision.
#[derive(Debug, Clone, PartialEq, Eq, Serialize)]
pub struct ReviewBinding {
    pub project_id: String,
    pub project_revision: u64,
    pub decision_sha256: String,
}
impl ReviewBinding {
    pub fn capture(project: &Project) -> Result<Self> {
        Ok(Self {
            project_id: project.id.clone(),
            project_revision: project.revision,
            decision_sha256: project.decision_digest()?,
        })
    }
    pub fn check(&self, project: &Project) -> Result<()> {
        if *self != Self::capture(project)? { return Err(Error::StaleReview); }
        Ok(())
    }
}

/// Issued for a particular session/view. Callers keep this value, not a row index.
/// It is intentionally not deserializable into an authority-bearing object.
#[derive(Debug, Clone, PartialEq, Eq, Serialize)]
pub struct ReviewToken {
    session: u64,
    view_revision: u64,
    binding: ReviewBinding,
}

/// One requested preview for one view, including its focus/options/variant.
/// A newer request cancels this ticket even if the project and selection did not
/// change. Keep it beside the async job; never infer currency from file names.
#[derive(Debug, Clone)]
pub struct ReviewPreviewTicket {
    token: ReviewToken,
    serial: u64,
    request_key: String,
    cancel: Cancellation,
}
impl ReviewPreviewTicket {
    pub fn cancellation(&self) -> Cancellation { self.cancel.clone() }
    pub fn request_key(&self) -> &str { &self.request_key }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize)]
#[serde(rename_all = "snake_case")]
pub enum ReviewPage { List, Detail, Closed }

#[derive(Debug, Clone, Serialize)]
pub struct ReviewRow {
    pub target: ReviewTarget,
    pub source_id: String,
    pub kind: String,
    pub source_range: TimeRange,
    pub original_interval_duration: Rational,
    pub reason: String,
    pub origin: EditOrigin,
    /// There is no calibrated confidence in the Step 2 schema. Do not invent one.
    pub confidence: Option<f64>,
    pub disposition: Disposition,
    pub enabled: bool,
    pub locked: bool,
    pub user_override: bool,
}

#[derive(Debug, Clone, Serialize)]
pub struct ReviewSummary {
    pub operation_count: usize,
    pub active_pending_count: usize,
    /// None for unresolved, fully removed or over-budget edit assemblies.
    pub final_duration: Option<Rational>,
    /// Only edit readiness, not codec/permission/file/runtime qualification.
    pub decisions_renderable: bool,
    pub render_blocker: Option<String>,
}

#[derive(Debug, Clone, Serialize)]
pub struct ReviewDetail {
    pub row: ReviewRow,
    pub color_adjustment:Option<crate::color::ColorAdjustment>,
    pub framing:Option<crate::reframe::FramingSettings>,
    pub presentation:Option<crate::presentation::PresentationSettings>,
    pub timing:Option<crate::timing::TimingSettings>,
    pub assembly:Option<crate::assembly::AssemblySettings>,
    /// Counterfactual durations with other unresolved edits omitted explicitly.
    pub duration_without_selected: Option<Rational>,
    pub duration_with_selected: Option<Rational>,
    pub omitted_pending_ids: Vec<String>,
    pub effect_note: String,
    pub can_approve: bool,
    pub can_reject: bool,
    pub can_change_enabled: bool,
    pub can_lock: bool,
    pub can_unlock: bool,
}

#[derive(Debug, Clone, Serialize)]
pub struct ReviewView {
    pub token: ReviewToken,
    pub page: ReviewPage,
    pub query: String,
    pub total_count: usize,
    pub matched_count: usize,
    pub offset: usize,
    pub has_more: bool,
    pub rows: Vec<ReviewRow>,
    pub selected: Option<ReviewTarget>,
    pub detail: Option<ReviewDetail>,
    pub summary: ReviewSummary,
    pub dirty: bool,
    pub voice_cleanup:Option<crate::voice::VoiceCleanup>,
    pub color_correction:Option<crate::color::ColorProfile>,
    /// A host instruction, not a claim that this core changed OS focus.
    pub restore_host_focus: bool,
}

#[derive(Debug, Clone)]
pub enum ReviewCommand {
    Next, Previous, First, Last,
    Select(ReviewTarget),
    Filter(String),
    Inspect, Back, Close,
    Approve, Reject, SetEnabled(bool), SetLocked(bool),
    ChangeRange(TimeRange),
    ChangeColor(crate::color::ColorAdjustment),
    ChangeFraming(crate::reframe::FramingSettings),
    ChangePresentation(crate::presentation::PresentationSettings),
    ChangeTiming(crate::timing::TimingSettings),
    ChangeAssembly(crate::assembly::AssemblySettings),
}

/// One project snapshot, one selection, no workers or filesystem access.
/// Closing/dropping cancels children supplied by `preview_cancellation`.
pub struct ReviewSession {
    id: u64,
    view_revision: u64,
    project: Project,
    saved_digest: String,
    page: ReviewPage,
    selected: Option<ReviewTarget>,
    query: String,
    page_size: usize,
    owner_cancel: Cancellation,
    preview_cancel: Cancellation,
    preview_serial: u64,
    active_preview: Option<(u64, String)>,
}
impl Drop for ReviewSession {
    fn drop(&mut self) { self.preview_cancel.cancel(); }
}
impl ReviewSession {
    pub fn new(project: Project) -> Result<Self> {
        Self::with_page_size(project, 50)
    }
    pub fn with_page_size(project: Project, page_size: usize) -> Result<Self> {
        project.validate()?;
        if page_size == 0 || page_size > MAX_REVIEW_PAGE {
            return Err(Error::InvalidInput("review page size must be 1..100"));
        }
        let saved_digest = project.decision_digest()?;
        let id = NEXT_SESSION.fetch_update(Ordering::AcqRel, Ordering::Acquire, |n| n.checked_add(1))
            .map_err(|_| Error::LimitExceeded("review session identities"))?;
        let mut session = Self {
            id, view_revision: 1, project, saved_digest, page: ReviewPage::List,
            selected: None, query: String::new(), page_size,
            owner_cancel: Cancellation::new(), preview_cancel: Cancellation::new(), preview_serial: 0, active_preview: None,
        };
        session.reselect()?;
        Ok(session)
    }
    /// Bind an extension-created review to its existing owner lifetime. Pure
    /// caller-created ReviewSession::new sessions remain caller-owned.
    pub(crate) fn with_owner(project: Project, owner: Cancellation) -> Result<Self> {
        owner.check()?;
        let mut session = Self::new(project)?;
        session.preview_cancel = owner.child()?;
        session.owner_cancel = owner;
        Ok(session)
    }
    pub fn project(&self) -> &Project { &self.project }
    pub fn binding(&self) -> Result<ReviewBinding> { ReviewBinding::capture(&self.project) }
    pub fn is_closed(&self) -> bool { self.page == ReviewPage::Closed || self.owner_cancel.is_cancelled() }
    pub fn preview_cancellation(&self, token: &ReviewToken) -> Result<Cancellation> {
        self.check(token)?;
        self.preview_cancel.child()
    }
    /// Prepare on the owning host task, then pass the cancellation clone into
    /// VideoExtension::preview_edit on its ordinary worker. This starts no work.
    pub fn begin_preview(&mut self, token: &ReviewToken, request: &crate::preview::PreviewRequest) -> Result<ReviewPreviewTicket> {
        self.check(token)?;
        if self.selected.as_ref() != Some(&request.target) { return Err(Error::StaleReview); }
        let prepared = crate::preview::PreviewPlan::build(&self.project, request)?;
        let key = prepared.description().request_key.clone();
        let serial = self.preview_serial.checked_add(1).ok_or(Error::LimitExceeded("preview request identities"))?;
        let next = self.owner_cancel.child()?;
        let child = next.child()?;
        self.preview_cancel.cancel(); self.preview_cancel = next;
        self.preview_serial = serial; self.active_preview = Some((serial, key.clone()));
        Ok(ReviewPreviewTicket { token: token.clone(), serial, request_key: key, cancel: child })
    }
    /// Check BEFORE displaying or retaining an async result. This rejects an old
    /// focus/variant request even when its selected operation is still current.
    pub fn accept_preview(&self, ticket: &ReviewPreviewTicket, result: &crate::preview::PreviewSet) -> Result<()> {
        self.check(&ticket.token)?;
        ticket.cancel.check()?;
        if self.active_preview.as_ref() != Some(&(ticket.serial, ticket.request_key.clone()))
            || result.description().request_key != ticket.request_key {
            return Err(Error::StaleReview);
        }
        self.validate_preview(&ticket.token, result)
    }
    pub fn selected_target(&self, token: &ReviewToken) -> Result<ReviewTarget> {
        self.check(token)?;
        self.selected.clone().ok_or(Error::InvalidInput("no review selection"))
    }
    pub fn snapshot(&self) -> Result<ReviewView> {
        let page = if self.is_closed() { ReviewPage::Closed } else { self.page };
        let selected = if self.is_closed() { None } else { self.selected.clone() };
        self.view_for(&self.project, page, &selected, &self.query, self.view_revision, &self.saved_digest)
    }
    fn view_for(&self, project:&Project, page:ReviewPage, selected:&Option<ReviewTarget>, query:&str,
        view_revision:u64, saved_digest:&str) -> Result<ReviewView> {
        project.validate()?;
        let all = review_rows(project)?;
        let total_count = all.len();
        let rows = filter_rows(all, query);
        let matched_count = rows.len();
        let selected_index = selected.as_ref().and_then(|target| rows.iter().position(|r| &r.target == target));
        let offset = selected_index.map(|i| (i / self.page_size) * self.page_size).unwrap_or(0);
        let detail = if page == ReviewPage::Detail {
            selected.as_ref().map(|target| detail(project, target)).transpose()?
        } else { None };
        let binding=ReviewBinding::capture(project)?;
        Ok(ReviewView {
            token: ReviewToken{session:self.id,view_revision,binding:binding.clone()}, page, query: query.into(),
            total_count, matched_count, offset,
            has_more: offset.saturating_add(self.page_size) < matched_count,
            rows: if page == ReviewPage::Closed { vec![] } else { rows.into_iter().skip(offset).take(self.page_size).collect() },
            selected: if page == ReviewPage::Closed { None } else { selected.clone() },
            detail, summary: summary_for_variant(project,match selected {Some(ReviewTarget::FramingVariant(id)|ReviewTarget::PresentationVariant(id)|ReviewTarget::TimingVariant(id)|ReviewTarget::AssemblyVariant(id))=>id,_=>&project.variants[0].id})?, dirty: binding.decision_sha256 != saved_digest,
            restore_host_focus: page == ReviewPage::Closed,
            voice_cleanup:project.settings.voice_cleanup.clone(),
            color_correction:project.settings.color_correction.clone(),
        })
    }
    pub fn dispatch(&mut self, expected: &ReviewToken, command: ReviewCommand) -> Result<ReviewView> {
        self.check(expected)?;
        let next = self.view_revision.checked_add(1).ok_or(Error::LimitExceeded("review view revision"))?;
        // All changes are made on a clone first: failure cannot half-apply an edit.
        let mut project = self.project.clone();
        let mut page = self.page;
        let mut query = self.query.clone();
        let mut selected = self.selected.clone();
        let mut changed_project = false;
        match command {
            ReviewCommand::Filter(value) => {
                query_ok(&value)?; query = value; page = ReviewPage::List;
                let rows = filter_rows(review_rows(&project)?, &query);
                if !rows.iter().any(|r| Some(&r.target) == selected.as_ref()) {
                    selected = rows.first().map(|r| r.target.clone());
                }
            }
            ReviewCommand::Select(target) => {
                if !filter_rows(review_rows(&project)?, &query).iter().any(|r| r.target == target) {
                    return Err(Error::InvalidInput("review target is absent from the current list"));
                }
                selected = Some(target);
            }
            ReviewCommand::Next | ReviewCommand::Previous | ReviewCommand::First | ReviewCommand::Last => {
                let rows = filter_rows(review_rows(&project)?, &query);
                if !rows.is_empty() {
                    let i = selected.as_ref().and_then(|target| rows.iter().position(|r| &r.target == target)).unwrap_or(0);
                    let i = match command {
                        ReviewCommand::Next => (i + 1).min(rows.len() - 1),
                        ReviewCommand::Previous => i.saturating_sub(1),
                        ReviewCommand::First => 0,
                        ReviewCommand::Last => rows.len() - 1,
                        _ => unreachable!(),
                    };
                    selected = Some(rows[i].target.clone());
                }
            }
            ReviewCommand::Inspect => {
                if selected.is_none() { return Err(Error::InvalidInput("no review selection")); }
                page = ReviewPage::Detail;
            }
            ReviewCommand::Back => {
                page = if page == ReviewPage::Detail { ReviewPage::List } else { ReviewPage::Closed };
            }
            ReviewCommand::Close => page = ReviewPage::Closed,
            mutation => {
                let target = selected.as_ref().ok_or(Error::InvalidInput("no review selection"))?;
                match (target, mutation) {
                    (ReviewTarget::Operation(id), ReviewCommand::Approve) => project.review_operation(id, Disposition::AutoApply, true)?,
                    (ReviewTarget::Operation(id), ReviewCommand::Reject) => project.review_operation(id, Disposition::Ignore, false)?,
                    (ReviewTarget::Operation(id), ReviewCommand::SetEnabled(on)) => project.set_operation_enabled(id, on)?,
                    (ReviewTarget::Operation(id), ReviewCommand::SetLocked(on)) => project.set_operation_locked(id, on)?,
                    (ReviewTarget::Operation(id), ReviewCommand::ChangeRange(range)) => project.change_operation_range(id, range)?,
                    (ReviewTarget::ColorShot(id), ReviewCommand::Approve) => project.decide_color(id,crate::color::ColorDecision::Approve)?,
                    (ReviewTarget::ColorShot(id), ReviewCommand::Reject) => project.decide_color(id,crate::color::ColorDecision::Reject)?,
                    (ReviewTarget::ColorShot(id), ReviewCommand::SetEnabled(on)) => project.decide_color(id,crate::color::ColorDecision::Enable(on))?,
                    (ReviewTarget::ColorShot(id), ReviewCommand::SetLocked(on)) => project.decide_color(id,crate::color::ColorDecision::Lock(on))?,
                    (ReviewTarget::ColorShot(id), ReviewCommand::ChangeColor(value)) => project.decide_color(id,crate::color::ColorDecision::Adjust(value))?,
                    (ReviewTarget::FramingVariant(id), ReviewCommand::Approve) => project.decide_framing(id,crate::reframe::FramingDecision::Approve)?,
                    (ReviewTarget::FramingVariant(id), ReviewCommand::Reject) => project.decide_framing(id,crate::reframe::FramingDecision::Reject)?,
                    (ReviewTarget::FramingVariant(id), ReviewCommand::SetEnabled(on)) => project.decide_framing(id,crate::reframe::FramingDecision::Enable(on))?,
                    (ReviewTarget::FramingVariant(id), ReviewCommand::SetLocked(on)) => project.decide_framing(id,crate::reframe::FramingDecision::Lock(on))?,
                    (ReviewTarget::FramingVariant(id), ReviewCommand::ChangeFraming(value)) => project.set_variant_framing(id,Some(value))?,
                    (ReviewTarget::PresentationVariant(id), ReviewCommand::Approve) => project.review_presentation(id,Disposition::AutoApply,true)?,
                    (ReviewTarget::PresentationVariant(id), ReviewCommand::Reject) => project.review_presentation(id,Disposition::Ignore,false)?,
                    (ReviewTarget::PresentationVariant(id), ReviewCommand::SetEnabled(on)) => {let d=project.variant(id)?.presentation.as_ref().ok_or(Error::InvalidProject("presentation"))?.disposition;project.review_presentation(id,d,on)?;},
                    (ReviewTarget::PresentationVariant(id), ReviewCommand::SetLocked(on)) => project.set_presentation_locked(id,on)?,
                    (ReviewTarget::PresentationVariant(id), ReviewCommand::ChangePresentation(value)) => project.set_presentation(id,Some(value))?,
                    (ReviewTarget::TimingVariant(id), ReviewCommand::Approve) => project.review_timing(id,Disposition::AutoApply,true)?,
                    (ReviewTarget::TimingVariant(id), ReviewCommand::Reject) => project.review_timing(id,Disposition::Ignore,false)?,
                    (ReviewTarget::TimingVariant(id), ReviewCommand::SetEnabled(on)) => {let d=project.variant(id)?.timing.as_ref().ok_or(Error::InvalidProject("timing"))?.disposition;project.review_timing(id,d,on)?;},
                    (ReviewTarget::TimingVariant(id), ReviewCommand::SetLocked(on)) => project.set_timing_locked(id,on)?,
                    (ReviewTarget::TimingVariant(id), ReviewCommand::ChangeTiming(value)) => project.set_timing(id,Some(value))?,
                    (ReviewTarget::AssemblyVariant(id), ReviewCommand::Approve) => project.review_assembly(id,Disposition::AutoApply,true)?,
                    (ReviewTarget::AssemblyVariant(id), ReviewCommand::Reject) => project.review_assembly(id,Disposition::Ignore,false)?,
                    (ReviewTarget::AssemblyVariant(id), ReviewCommand::SetEnabled(on)) => {let d=project.variant(id)?.assembly.as_ref().ok_or(Error::InvalidProject("assembly"))?.disposition;project.review_assembly(id,d,on)?;},
                    (ReviewTarget::AssemblyVariant(id), ReviewCommand::SetLocked(on)) => project.set_assembly_locked(id,on)?,
                    (ReviewTarget::AssemblyVariant(id), ReviewCommand::ChangeAssembly(value)) => project.set_assembly(id,Some(value))?,
                    (ReviewTarget::Clip(id), ReviewCommand::SetLocked(on)) => project.set_clip_locked(id, on)?,
                    (ReviewTarget::Clip(id), ReviewCommand::ChangeRange(range)) => project.trim_clip(id, range)?,
                    _ => return Err(Error::Unsupported("this review action does not apply to an assembly clip")),
                }
                changed_project = true;
            }
        }
        // Materialize/validate the resulting view BEFORE committing state.
        let view=self.view_for(&project,page,&selected,&query,next,&self.saved_digest)?;
        let changed_view=selected!=self.selected || query!=self.query || page!=self.page;
        let next_cancel=if changed_project||changed_view||page==ReviewPage::Closed {Some(self.owner_cancel.child()?)}else{None};
        self.project = project; self.page = page; self.query = query; self.selected = selected;
        self.view_revision = next;
        if let Some(cancel)=next_cancel {
            self.preview_cancel.cancel(); self.active_preview = None;self.preview_cancel=cancel;
            if self.is_closed() { self.preview_cancel.cancel(); }
        }
        Ok(view)
    }
    /// Adopt newly analyzed pause proposals without pretending they were loaded
    /// from disk. The old saved digest is preserved, so the result remains dirty.
    /// The report itself is bound to the exact project and leaves every new cut
    /// pending. An old view token cannot apply an asynchronous result.
    /// Apply only while both this review and the selected model operation remain valid.
    pub fn apply_speech_report(&mut self, expected:&ReviewToken, report:&crate::speech::SpeechPauseReport)->Result<ReviewView> {
        self.apply_pause_report(expected,report.checked_report()?)
    }
    /// Adopt a face-aware framing proposal through the current review owner.
    /// The detector only supplied observations; the report contains editable crop
    /// keys and remains pending until the normal framing approval action.
    pub fn apply_face_report(&mut self, expected:&ReviewToken, report:&crate::face::FaceFramingReport, activation:&crate::model_pack::ModelActivation)->Result<ReviewView> {
        self.apply_face_choices(expected,report,activation,&crate::face::FaceApplyChoices::default())
    }
    pub fn apply_face_choices(&mut self,expected:&ReviewToken,report:&crate::face::FaceFramingReport,activation:&crate::model_pack::ModelActivation,choices:&crate::face::FaceApplyChoices)->Result<ReviewView>{
        self.check(expected)?;let mut project=self.project.clone();report.apply_choices(&mut project,activation,choices)?;
        self.adopt_review_project(project,Some(ReviewTarget::FramingVariant(report.variant_id.clone())))
    }
    pub fn apply_placement(&mut self,expected:&ReviewToken,report:&crate::placement::PlacementReport,choices:&[crate::placement::PlacementChoice])->Result<ReviewView>{
        self.check(expected)?;let mut project=self.project.clone();report.apply(&mut project,choices)?;
        self.adopt_review_project(project,self.selected.clone())
    }
    pub fn apply_transcript_report(&mut self,expected:&ReviewToken,report:&crate::transcript_workflow::TranscriptReport)->Result<ReviewView>{
        self.check(expected)?;let mut project=self.project.clone();report.apply(&mut project)?;
        self.adopt_review_project(project,self.selected.clone())
    }
    /// Accept or bypass a validated enhanced stem through the current review.
    /// Source and receipt validation is shared with the final render path.
    pub fn set_voice_enhancement(&mut self,expected:&ReviewToken,enhancement:Option<crate::enhancement::VoiceEnhancement>)->Result<ReviewView>{
        self.check(expected)?;let mut project=self.project.clone();project.set_voice_enhancement(enhancement)?;
        self.adopt_review_project(project,self.selected.clone())
    }
    pub fn correct_transcript_word(&mut self,expected:&ReviewToken,id:&str,text:String,range:TimeRange)->Result<ReviewView>{
        self.check(expected)?;let mut project=self.project.clone();project.correct_transcript_word(id,text,range)?;
        self.adopt_review_project(project,self.selected.clone())
    }
    pub fn review_transcript_word(&mut self,expected:&ReviewToken,id:&str)->Result<ReviewView>{
        self.check(expected)?;let mut project=self.project.clone();project.review_transcript_word(id)?;
        self.adopt_review_project(project,self.selected.clone())
    }
    pub fn set_transcript_word_locked(&mut self,expected:&ReviewToken,id:&str,locked:bool)->Result<ReviewView>{
        self.check(expected)?;let mut project=self.project.clone();project.set_transcript_word_locked(id,locked)?;
        self.adopt_review_project(project,self.selected.clone())
    }
    pub fn propose_transcript_fillers(&mut self,expected:&ReviewToken,words:&[String])->Result<ReviewView>{
        self.check(expected)?;let mut project=self.project.clone();project.propose_transcript_fillers(words)?;
        self.adopt_review_project(project,self.selected.clone())
    }
    pub fn clear_transcript(&mut self,expected:&ReviewToken)->Result<ReviewView>{
        self.check(expected)?;let mut project=self.project.clone();project.clear_transcript()?;
        self.adopt_review_project(project,self.selected.clone())
    }
    pub fn set_timing(&mut self,expected:&ReviewToken,variant:&str,settings:Option<crate::timing::TimingSettings>)->Result<ReviewView>{
        self.check(expected)?;let mut project=self.project.clone();project.set_timing(variant,settings)?;
        self.adopt_review_project(project,Some(ReviewTarget::TimingVariant(variant.into())))
    }
    pub fn set_assembly(&mut self,expected:&ReviewToken,variant:&str,settings:Option<crate::assembly::AssemblySettings>)->Result<ReviewView>{
        self.check(expected)?;let mut project=self.project.clone();project.set_assembly(variant,settings)?;
        self.adopt_review_project(project,Some(ReviewTarget::AssemblyVariant(variant.into())))
    }
    fn adopt_review_project(&mut self,project:Project,preferred:Option<ReviewTarget>)->Result<ReviewView>{
        let next=self.view_revision.checked_add(1).ok_or(Error::LimitExceeded("review view revision"))?;
        let rows=filter_rows(review_rows(&project)?,&self.query);
        let selected=if rows.iter().any(|r|Some(&r.target)==preferred.as_ref()){preferred}else{rows.first().map(|r|r.target.clone())};
        let view=self.view_for(&project,ReviewPage::List,&selected,&self.query,next,&self.saved_digest)?;
        let cancel=self.owner_cancel.child()?;
        self.preview_cancel.cancel();self.preview_cancel=cancel;self.active_preview=None;
        self.project=project;self.selected=selected;self.page=ReviewPage::List;self.view_revision=next;Ok(view)
    }
    pub fn apply_pause_report(&mut self, expected:&ReviewToken, report:&crate::pause::PauseReport)->Result<ReviewView> {
        self.check(expected)?;
        let next=self.view_revision.checked_add(1).ok_or(Error::LimitExceeded("review view revision"))?;
        let mut project=self.project.clone();report.apply(&mut project)?;
        let rows=filter_rows(review_rows(&project)?,&self.query);
        let selected=if rows.iter().any(|r|Some(&r.target)==self.selected.as_ref()){self.selected.clone()}
            else{rows.first().map(|r|r.target.clone())};
        let view=self.view_for(&project,ReviewPage::List,&selected,&self.query,next,&self.saved_digest)?;
        self.preview_cancel.cancel();self.active_preview=None;self.preview_cancel=self.owner_cancel.child()?;
        self.project=project;self.selected=selected;self.page=ReviewPage::List;self.view_revision=next;
        Ok(view)
    }
    /// Explicitly accept the source-bound audio treatment and invalidate proxies.
    pub fn apply_voice_report(&mut self, expected:&ReviewToken, report:&crate::voice::VoiceReport)->Result<ReviewView> {
        self.check(expected)?;
        let next=self.view_revision.checked_add(1).ok_or(Error::LimitExceeded("review view revision"))?;
        let mut project=self.project.clone();report.apply(&mut project)?;
        let rows=filter_rows(review_rows(&project)?,&self.query);
        let selected=if rows.iter().any(|r|Some(&r.target)==self.selected.as_ref()){self.selected.clone()}
            else{rows.first().map(|r|r.target.clone())};
        let view=self.view_for(&project,ReviewPage::List,&selected,&self.query,next,&self.saved_digest)?;
        self.preview_cancel.cancel();self.active_preview=None;self.preview_cancel=self.owner_cancel.child()?;
        self.project=project;self.selected=selected;self.page=ReviewPage::List;self.view_revision=next;
        Ok(view)
    }
    /// Adopt shot observations and pending corrections using the same review owner.
    pub fn apply_color_report(&mut self, expected:&ReviewToken, report:&crate::color::ColorReport)->Result<ReviewView> {
        self.check(expected)?;
        let next=self.view_revision.checked_add(1).ok_or(Error::LimitExceeded("review view revision"))?;
        let mut project=self.project.clone();report.apply(&mut project)?;
        let rows=filter_rows(review_rows(&project)?,&self.query);
        let selected=if rows.iter().any(|r|Some(&r.target)==self.selected.as_ref()){self.selected.clone()}
            else{rows.first().map(|r|r.target.clone())};
        let view=self.view_for(&project,ReviewPage::List,&selected,&self.query,next,&self.saved_digest)?;
        self.preview_cancel.cancel();self.active_preview=None;self.preview_cancel=self.owner_cancel.child()?;
        self.project=project;self.selected=selected;self.page=ReviewPage::List;self.view_revision=next;
        Ok(view)
    }
    /// Apply explicit frozen workflow/output settings without losing unsaved edits.
    pub fn apply_workflow_snapshot(&mut self, expected:&ReviewToken, snapshot:&crate::presets::WorkflowSnapshot, variant:&str)->Result<ReviewView> {
        self.check(expected)?;
        let next=self.view_revision.checked_add(1).ok_or(Error::LimitExceeded("review view revision"))?;
        let mut project=self.project.clone();snapshot.apply(&mut project,variant)?;
        let rows=filter_rows(review_rows(&project)?,&self.query);
        let selected=if rows.iter().any(|r|Some(&r.target)==self.selected.as_ref()){self.selected.clone()}
            else{rows.first().map(|r|r.target.clone())};
        let view=self.view_for(&project,ReviewPage::List,&selected,&self.query,next,&self.saved_digest)?;
        self.preview_cancel.cancel();self.active_preview=None;self.preview_cancel=self.owner_cancel.child()?;
        self.project=project;self.selected=selected;self.page=ReviewPage::List;self.view_revision=next;
        Ok(view)
    }
    /// Reject a late result for another view/selection, even if project data did
    /// not change. For async latest-request protection, use begin_preview and
    /// accept_preview; this lower-level method checks only view and selection.
    pub fn validate_preview(&self, token:&ReviewToken, preview:&crate::preview::PreviewSet)->Result<()> {
        self.check(token)?;
        preview.check_current(&self.project)?;
        if self.selected.as_ref()!=Some(&preview.description().target){return Err(Error::StaleReview);}
        Ok(())
    }
    /// Call only after the existing ProjectStore saved this exact digest.
    /// An unrelated or stale save completion cannot clear the dirty indicator.
    pub fn mark_saved(&mut self, binding: &ReviewBinding) -> Result<()> {
        binding.check(&self.project)?;
        self.saved_digest = binding.decision_sha256.clone();
        Ok(())
    }
    /// Explicitly adopt a reread project. Default prevents discarding unsaved work.
    pub fn reload(&mut self, project: Project, discard_unsaved: bool) -> Result<ReviewView> {
        if self.is_closed() { return Err(Error::ReviewClosed); }
        project.validate()?;
        if project.id != self.project.id { return Err(Error::InvalidProject("review project identity changed")); }
        if !discard_unsaved && self.project.decision_digest()? != self.saved_digest {
            return Err(Error::InvalidInput("unsaved review decisions; save or explicitly discard before reload"));
        }
        let next = self.view_revision.checked_add(1).ok_or(Error::LimitExceeded("review view revision"))?;
        let digest=project.decision_digest()?;
        let rows=filter_rows(review_rows(&project)?,&self.query);
        let selected=if rows.iter().any(|r|Some(&r.target)==self.selected.as_ref()){self.selected.clone()}
            else{rows.first().map(|r|r.target.clone())};
        let view=self.view_for(&project,ReviewPage::List,&selected,&self.query,next,&digest)?;
        self.preview_cancel.cancel(); self.active_preview = None; self.preview_cancel = self.owner_cancel.child()?;
        self.saved_digest = digest; self.project = project; self.view_revision = next;
        self.page = ReviewPage::List; self.selected=selected;
        Ok(view)
    }
    /// Use the existing host form/action to submit variant-local geometry. No
    /// geometry widgets or global keyboard hooks are installed by this method.
    pub fn set_framing(&mut self,token:&ReviewToken,variant:&str,settings:Option<crate::reframe::FramingSettings>)->Result<ReviewView>{
        self.check(token)?;
        let next=self.view_revision.checked_add(1).ok_or(Error::LimitExceeded("review view revision"))?;
        let mut project=self.project.clone();project.set_variant_framing(variant,settings)?;
        let rows=filter_rows(review_rows(&project)?,&self.query);
        let target=ReviewTarget::FramingVariant(variant.into());
        let selected=if rows.iter().any(|r|r.target==target){Some(target)}else{rows.first().map(|r|r.target.clone())};
        let view=self.view_for(&project,ReviewPage::List,&selected,&self.query,next,&self.saved_digest)?;
        self.preview_cancel.cancel();self.preview_cancel=self.owner_cancel.child()?;self.active_preview=None;
        self.project=project;self.view_revision=next;self.selected=selected;self.page=ReviewPage::List;Ok(view)
    }
    /// Use the existing host form/action to submit variant-local presentation. No
    /// presentation widgets or global keyboard hooks are installed by this method.
    pub fn set_presentation(&mut self,token:&ReviewToken,variant:&str,settings:Option<crate::presentation::PresentationSettings>)->Result<ReviewView>{
        self.check(token)?;
        let next=self.view_revision.checked_add(1).ok_or(Error::LimitExceeded("review view revision"))?;
        let mut project=self.project.clone();project.set_presentation(variant,settings)?;
        let rows=filter_rows(review_rows(&project)?,&self.query);
        let target=ReviewTarget::PresentationVariant(variant.into());
        let selected=if rows.iter().any(|r|r.target==target){Some(target)}else{rows.first().map(|r|r.target.clone())};
        let view=self.view_for(&project,ReviewPage::List,&selected,&self.query,next,&self.saved_digest)?;
        self.preview_cancel.cancel();self.preview_cancel=self.owner_cancel.child()?;self.active_preview=None;
        self.project=project;self.view_revision=next;self.selected=selected;self.page=ReviewPage::List;Ok(view)
    }
    /// Existing host lifecycle hooks call this on focus loss, disable or removal.
    /// No project is saved/discarded by closing; the caller still owns this session.
    pub fn close(&mut self) {
        self.preview_cancel.cancel(); self.active_preview = None; self.page = ReviewPage::Closed; self.selected = None;
    }
    fn token(&self) -> Result<ReviewToken> {
        Ok(ReviewToken { session: self.id, view_revision: self.view_revision, binding: self.binding()? })
    }
    fn check(&self, token: &ReviewToken) -> Result<()> {
        if self.is_closed() { return Err(Error::ReviewClosed); }
        if *token != self.token()? { return Err(Error::StaleReview); }
        Ok(())
    }
    fn reselect(&mut self) -> Result<()> {
        let rows = filter_rows(review_rows(&self.project)?, &self.query);
        if !rows.iter().any(|r| Some(&r.target) == self.selected.as_ref()) {
            self.selected = rows.first().map(|r| r.target.clone());
        }
        Ok(())
    }
}

pub fn summary(project:&Project)->Result<ReviewSummary>{
    project.validate()?;summary_for_variant(project,&project.variants[0].id)
}
pub fn summary_for_variant(project: &Project,variant_id:&str) -> Result<ReviewSummary> {
    project.validate()?;let variant=project.variant(variant_id)?;
    let (final_duration, mut render_blocker) = match project.timeline_for_variant(variant_id) {
        Ok(t) => (Some(t.duration), None),
        Err(Error::UnresolvedEdits) => (None, Some("Resolve or disable pending proposals before final rendering.".into())),
        Err(Error::EmptyTimeline) => (None, Some("No retained media remains.".into())),
        Err(Error::LimitExceeded(_)) => (None, Some("The edit exceeds the current render-segment limit.".into())),
        Err(Error::Unsupported(_)) => (None, Some("This assembly is outside the current render profile.".into())),
        Err(e) => return Err(e),
    };
    let color_pending=project.settings.color_correction.as_ref().map(|p|if p.enabled {p.shots.iter().filter(|s|s.enabled&&s.disposition==Disposition::NeedsReview).count()}else{0}).unwrap_or(0);
    if color_pending>0 {render_blocker=Some("Resolve or disable pending color corrections before final rendering.".into());}
    let framing_pending=usize::from(variant.framing.as_ref().is_some_and(|f|f.enabled&&f.disposition==Disposition::NeedsReview));
    if framing_pending>0&&render_blocker.is_none(){render_blocker=Some("Resolve or disable pending framing for the selected output variant. Other resolved variants can still render.".into());}
    let presentation_pending=usize::from(variant.presentation.as_ref().is_some_and(|p|p.enabled&&p.disposition==Disposition::NeedsReview));
    let timing_pending=usize::from(variant.timing.as_ref().is_some_and(|t|t.enabled&&t.disposition==Disposition::NeedsReview));
    let assembly_pending=usize::from(variant.assembly.as_ref().is_some_and(|a|a.enabled&&a.disposition==Disposition::NeedsReview));
    if presentation_pending>0&&render_blocker.is_none(){render_blocker=Some("Resolve or disable presentation for the selected variant. Other resolved variants remain independent.".into());}
    Ok(ReviewSummary {
        operation_count: usize::from(variant.assembly.is_some())+usize::from(variant.timing.is_some())+usize::from(variant.presentation.is_some())+usize::from(variant.framing.is_some())+project.operations.len()+project.settings.color_correction.as_ref().map(|p|p.shots.len()).unwrap_or(0),
        active_pending_count: project.operations.iter().filter(|o| o.enabled && o.disposition == Disposition::NeedsReview).count()+color_pending+framing_pending+presentation_pending+timing_pending+assembly_pending,
        decisions_renderable: render_blocker.is_none(), final_duration, render_blocker,
    })
}

pub fn review_rows(project: &Project) -> Result<Vec<ReviewRow>> {
    project.validate()?;
    let mut rows = Vec::with_capacity(project.assembly.len() + project.operations.len());
    for clip in &project.assembly {
        rows.push(ReviewRow {
            target: ReviewTarget::Clip(clip.id.clone()), source_id: clip.source_id.clone(),
            kind: "keep_clip".into(), source_range: clip.range,
            original_interval_duration: clip.range.duration()?,
            reason: "Manually selected source interval; review does not alter the original footage.".into(),
            origin: EditOrigin::Manual, confidence: None, disposition: Disposition::AutoApply,
            enabled: true, locked: clip.locked, user_override: true,
        });
    }
    for op in &project.operations {
        rows.push(ReviewRow {
            target: ReviewTarget::Operation(op.id.clone()), source_id: op.source_id.clone(),
            kind: match op.kind { EditKind::RemoveRange => "remove_range", EditKind::ProtectRange => "protect_range" }.into(),
            source_range: op.range, original_interval_duration: op.range.duration()?,
            reason: literal_display(&op.reason), origin: op.origin.clone(), confidence: None,
            disposition: op.disposition, enabled: op.enabled, locked: op.locked, user_override: op.user_override,
        });
    }
    if let Some(profile)=&project.settings.color_correction {
        for shot in &profile.shots {
            rows.push(ReviewRow{target:ReviewTarget::ColorShot(shot.id.clone()),source_id:profile.source_id.clone(),
                kind:"color_correction".into(),source_range:shot.range,original_interval_duration:shot.range.duration()?,
                reason:literal_display(&shot.reason),origin:EditOrigin::Generator{id:"video-color".into(),version:crate::color::COLOR_VERSION.to_string()},
                confidence:None,disposition:shot.disposition,enabled:shot.enabled&&profile.enabled,locked:shot.locked,user_override:shot.user_override});
        }
    }
    for variant in &project.variants {
        if let Some(f)=&variant.framing {
            let range=TimeRange::new(Rational::new(0,1)?,project.sources[0].duration)?;
            rows.push(ReviewRow{target:ReviewTarget::FramingVariant(variant.id.clone()),source_id:project.sources[0].id.clone(),
                kind:"output_framing".into(),source_range:range,original_interval_duration:range.duration()?,
                reason:format!("Output variant {}: {} x {}, {}. Source-time framing only; shared cuts/audio unchanged. Safe zones are editable guides.",variant.id,f.target.width,f.target.height,match &f.mode{crate::reframe::FramingMode::Fit{..}=>"Fit with padding",crate::reframe::FramingMode::Crop{..}=>"explicit crop/keyframes"}),
                origin:EditOrigin::Manual,confidence:None,disposition:f.disposition,enabled:f.enabled,locked:f.locked,user_override:true});
        }
    }
    for variant in &project.variants {if let Some(p)=&variant.presentation {
        let range=TimeRange::new(Rational::new(0,1)?,project.sources[0].duration)?;
        rows.push(ReviewRow{target:ReviewTarget::PresentationVariant(variant.id.clone()),source_id:project.sources[0].id.clone(),kind:"presentation".into(),source_range:range,original_interval_duration:range.duration()?,
            reason:format!("Variant {}: {} supplied graphics, {} supplied captions. Manual settings; no transcription or object understanding.",variant.id,p.overlays.len(),p.captions.as_ref().map(|c|c.document.cues.len()).unwrap_or(0)),
            origin:EditOrigin::Manual,confidence:None,disposition:p.disposition,enabled:p.enabled,locked:p.locked,user_override:true});
    }}
    for variant in &project.variants {if let Some(t)=&variant.timing {
        let range=TimeRange::new(Rational::new(0,1)?,project.sources[0].duration)?;
        rows.push(ReviewRow{target:ReviewTarget::TimingVariant(variant.id.clone()),source_id:project.sources[0].id.clone(),kind:"output_timing".into(),source_range:range,original_interval_duration:range.duration()?,
            reason:format!("Variant {}: {:?} playback speed and {} seconds of dissolve at retained joins.",variant.id,t.speed,t.dissolve),
            origin:EditOrigin::Manual,confidence:None,disposition:t.disposition,enabled:t.enabled,locked:t.locked,user_override:true});
    }}
    for variant in &project.variants {if let Some(a)=&variant.assembly {
        let range=TimeRange::new(Rational::new(0,1)?,project.sources[0].duration)?;
        rows.push(ReviewRow{target:ReviewTarget::AssemblyVariant(variant.id.clone()),source_id:project.sources[0].id.clone(),kind:"output_assembly".into(),source_range:range,original_interval_duration:range.duration()?,
            reason:format!("Variant {}: {} authored clip occurrences with explicit source ranges and playback speeds. Source removals and protections remain authoritative.",variant.id,a.clips.len()),
            origin:EditOrigin::Manual,confidence:None,disposition:a.disposition,enabled:a.enabled,locked:a.locked,user_override:true});
    }}
    rows.sort_by(|a,b| a.source_id.cmp(&b.source_id).then(a.source_range.start.cmp(&b.source_range.start))
        .then(a.source_range.end.cmp(&b.source_range.end)).then(a.kind.cmp(&b.kind)).then(a.target.id().cmp(b.target.id())));
    Ok(rows)
}

pub fn detail(project: &Project, target: &ReviewTarget) -> Result<ReviewDetail> {
    let row = review_rows(project)?.into_iter().find(|r| &r.target == target)
        .ok_or(Error::InvalidInput("unknown review target"))?;
    let (base, mut omitted_pending_ids) = resolved_review_copy(project);
    let mut without = base.clone();
    let mut with = base;
    let operation = matches!(target, ReviewTarget::Operation(_));
    let color = matches!(target, ReviewTarget::ColorShot(_));
    let framing = matches!(target,ReviewTarget::FramingVariant(_));
    let presentation=matches!(target,ReviewTarget::PresentationVariant(_));
    let timing=matches!(target,ReviewTarget::TimingVariant(_));
    let assembly=matches!(target,ReviewTarget::AssemblyVariant(_));
    if assembly{omitted_pending_ids.retain(|other|other!=&format!("assembly:{}",target.id()));}
    if timing{omitted_pending_ids.retain(|other|other!=&format!("timing:{}",target.id()));}
    if presentation{omitted_pending_ids.retain(|other|other!=&format!("presentation:{}",target.id()));}
    if framing{omitted_pending_ids.retain(|other|other!=&format!("framing:{}",target.id()));}
    if color {omitted_pending_ids.retain(|other|other!=&format!("color:{}",target.id()));}
    if operation {
        let id = target.id();
        omitted_pending_ids.retain(|other| other != id);
        let off = without.operations.iter_mut().find(|o| o.id == id).ok_or(Error::InvalidProject("review operation"))?;
        off.enabled = false; off.disposition = Disposition::Ignore;
        let on = with.operations.iter_mut().find(|o| o.id == id).ok_or(Error::InvalidProject("review operation"))?;
        on.enabled = true; on.disposition = Disposition::AutoApply;
        if !row.locked { on.user_override = true; }
    }
    if timing {
        without.variants.iter_mut().find(|v|v.id==target.id()).and_then(|v|v.timing.as_mut()).ok_or(Error::InvalidProject("review timing"))?.enabled=false;
        let on=with.variants.iter_mut().find(|v|v.id==target.id()).and_then(|v|v.timing.as_mut()).ok_or(Error::InvalidProject("review timing"))?;
        on.enabled=true;on.disposition=Disposition::AutoApply;
    }
    if assembly {
        without.variants.iter_mut().find(|v|v.id==target.id()).and_then(|v|v.assembly.as_mut()).ok_or(Error::InvalidProject("review assembly"))?.enabled=false;
        let on=with.variants.iter_mut().find(|v|v.id==target.id()).and_then(|v|v.assembly.as_mut()).ok_or(Error::InvalidProject("review assembly"))?;
        on.enabled=true;on.disposition=Disposition::AutoApply;
    }
    let variant_id=if timing||framing||presentation||assembly {target.id()}else{&project.variants[0].id};
    let duration_without_selected = duration_or_empty(&without,variant_id)?;
    let duration_with_selected = duration_or_empty(&with,variant_id)?;
    Ok(ReviewDetail {
        color_adjustment:if color {project.settings.color_correction.as_ref().and_then(|p|p.shots.iter().find(|s|s.id==target.id())).map(|s|s.adjustment)}else{None},
        framing:if framing{project.variant(target.id())?.framing.clone()}else{None},
        presentation:if presentation{project.variant(target.id())?.presentation.clone()}else{None},
        timing:if timing{project.variant(target.id())?.timing.clone()}else{None},
        assembly:if assembly{project.variant(target.id())?.assembly.clone()}else{None},
        can_approve: (operation||color||framing||presentation||timing||assembly) && !row.locked,
        can_reject: (operation||color||framing||presentation||timing||assembly) && !row.locked,
        can_change_enabled: (operation||color||framing||presentation||timing||assembly) && !row.locked,
        can_lock: !row.locked, can_unlock: row.locked,
        effect_note: if assembly {
            "This variant plays explicit single-source clip occurrences in authored order, including repeats and per-clip speeds. Shared source removals still apply to every occurrence. Editing the sequence returns it to review; preview does not approve.".into()
        } else if timing {
            "Playback speed and pairwise dissolves affect this variant. Counterfactual durations include the selected timing settings; source observations and editable source-time decisions retain their original clocks. Preview does not approve.".into()
        } else if presentation {
            "Captions, graphics, fades and attenuation keys remain editable in this variant. Preview does not approve. Cut-aware timing is computed from the effective render timeline; graphics cannot recognize faces or baked-in source text.".into()
        } else if framing {
            "Framing changes only this variant's composition. Dimensions, safe-zone guides, source-time keys and scale limits are editable. Preview is hypothetical; an adjustment needs a new explicit approval. No face or subject tracking is performed.".into()
        } else if color {
            "Color changes pixels, not time. The shown settings remain pending until approval; preview does not approve. A globally disabled color profile stays bypassed in final renders.".into()
        } else if operation {
            "Counterfactual whole-project durations with this decision off/on. Unlocked decisions use explicit-user-override semantics; a locked decision retains its original semantics and cannot be changed until unlocked. Other pending decisions are omitted; overlapping cuts may make the marginal change zero. An explicit user approval can override generator-only keep/protection rules. This does not approve the project.".into()
        } else {
            "Assembly clips are already explicit manual choices; approve/reject is not applicable. Both durations describe the currently resolved assembly, not an invented earlier trim.".into()
        },
        row, duration_without_selected, duration_with_selected, omitted_pending_ids,
    })
}

/// Used ONLY for inspection/preview. Never replace the final-render decision gate
/// with this helper. Its caller must disclose the omitted pending operations.
pub(crate) fn resolved_review_copy(project: &Project) -> (Project, Vec<String>) {
    let mut draft = project.clone();
    draft.renders.clear();
    let mut omitted = Vec::new();
    for op in &mut draft.operations {
        if op.enabled && op.disposition == Disposition::NeedsReview {
            omitted.push(op.id.clone()); op.disposition = Disposition::Ignore;
        }
    }
    if let Some(profile)=&mut draft.settings.color_correction {
        for shot in &mut profile.shots {
            if shot.enabled && shot.disposition==Disposition::NeedsReview {
                omitted.push(format!("color:{}",shot.id));shot.disposition=Disposition::Ignore;
            }
        }
    }
    for variant in &mut draft.variants {
        if let Some(f)=&mut variant.framing {
            if f.enabled&&f.disposition==Disposition::NeedsReview {omitted.push(format!("framing:{}",variant.id));f.disposition=Disposition::Ignore;}
        }
    }
    for variant in &mut draft.variants{if let Some(p)=&mut variant.presentation{if p.enabled&&p.disposition==Disposition::NeedsReview{omitted.push(format!("presentation:{}",variant.id));p.disposition=Disposition::Ignore;}}}
    for variant in &mut draft.variants{if let Some(t)=&mut variant.timing{if t.enabled&&t.disposition==Disposition::NeedsReview{omitted.push(format!("timing:{}",variant.id));t.disposition=Disposition::Ignore;}}}
    for variant in &mut draft.variants{if let Some(a)=&mut variant.assembly{if a.enabled&&a.disposition==Disposition::NeedsReview{omitted.push(format!("assembly:{}",variant.id));a.disposition=Disposition::Ignore;}}}
    (draft, omitted)
}
fn duration_or_empty(project: &Project,variant_id:&str) -> Result<Option<Rational>> {
    match project.timeline_for_variant(variant_id) {
        Ok(t) => Ok(Some(t.duration)),
        Err(Error::EmptyTimeline) => Ok(Some(Rational::new(0, 1)?)),
        Err(Error::LimitExceeded(_)) | Err(Error::Unsupported(_)) => Ok(None),
        Err(e) => Err(e),
    }
}
fn filter_rows(rows: Vec<ReviewRow>, query: &str) -> Vec<ReviewRow> {
    let words: Vec<_> = query.split_whitespace().map(str::to_lowercase).collect();
    rows.into_iter().filter(|row| {
        let text = format!("{} {} {} {}", row.target.id(), row.source_id, row.kind, row.reason).to_lowercase();
        words.iter().all(|word| text.contains(word))
    }).collect()
}
fn query_ok(query: &str) -> Result<()> {
    if query.len() > MAX_REVIEW_QUERY_BYTES || query.chars().any(|c| c.is_control() || is_format_control(c)) {
        return Err(Error::InvalidInput("review search must be bounded literal text"));
    }
    Ok(())
}
fn is_format_control(c: char) -> bool {
    matches!(c, '\u{061c}' | '\u{200b}'..='\u{200f}' | '\u{202a}'..='\u{202e}' | '\u{2060}'..='\u{206f}' | '\u{feff}')
}
fn literal_display(text: &str) -> String {
    let mut out = String::new();
    for c in text.chars() {
        if c.is_control() || is_format_control(c) { out.push_str(&format!("\\u{{{:x}}}", c as u32)); }
        else { out.push(c); }
    }
    out
}
