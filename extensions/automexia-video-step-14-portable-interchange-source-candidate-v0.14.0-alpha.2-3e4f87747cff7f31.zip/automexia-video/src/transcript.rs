//! Editable source-time transcription. Observations are evidence, never edit approval.
//! No model, executable path or activation authority is serialized in a project.
use crate::model_pack::{ModelIdentity, WHISPER_CONTRACT, WHISPER_PROCESSING};
use crate::project::{ContentFingerprint, Disposition, EditKind, EditOperation, EditOrigin, Project, TimeRange};
use crate::subtitles::{CaptionCue, SubtitleDocument, SubtitleFormat};
use crate::{Error, Rational, Result};
use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};
use std::collections::BTreeSet;

pub const MAX_TRANSCRIPT_WORDS: usize = 8192;
pub const MAX_WORD_BYTES: usize = 256;
pub const MAX_TRANSCRIPT_SECONDS: i64 = 1800;
pub const TRANSCRIPT_GENERATOR: &str = "transcript-fillers";
pub const TRANSCRIPT_GENERATOR_VERSION: &str = "1";

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct TranscriptSettings {
    /// Explicit Whisper language code, or "auto" for local language detection.
    pub language: String,
    pub analysis_channel: u16,
    pub low_confidence_below: f64,
}
impl Default for TranscriptSettings {
    fn default() -> Self {
        Self { language: "auto".into(), analysis_channel: 0, low_confidence_below: 0.65 }
    }
}
impl TranscriptSettings {
    pub fn validate(&self) -> Result<()> {
        language(&self.language)?;
        if self.analysis_channel > 7 || !self.low_confidence_below.is_finite()
            || !(0.0..=1.0).contains(&self.low_confidence_below) {
            return Err(Error::InvalidInput("transcript settings"));
        }
        Ok(())
    }
}
pub(crate) fn language(value: &str) -> Result<()> {
    if value != "auto" && !(value.len() >= 2 && value.len() <= 3
        && value.bytes().all(|b| b.is_ascii_lowercase())) {
        return Err(Error::InvalidInput("explicit transcript language code"));
    }
    Ok(())
}

/// A provider result in seconds relative to the first sample of its supplied PCM.
/// Confidence is the minimum token probability in this word, not a calibration claim.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct RecognizedWord {
    pub text: String,
    pub range: TimeRange,
    pub confidence: Option<f64>,
}
impl RecognizedWord {
    pub fn validate(&self, duration: Rational) -> Result<()> {
        word_text(&self.text)?;
        self.range.validate()?;
        if self.range.end > duration { return Err(Error::InvalidOutput("transcript word exceeds audio")); }
        if self.confidence.is_some_and(|p| !p.is_finite() || !(0.0..=1.0).contains(&p)) {
            return Err(Error::InvalidOutput("transcript probability"));
        }
        Ok(())
    }
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct TranscriptWord {
    pub id: String,
    pub range: TimeRange,
    pub text: String,
    pub locked: bool,
    /// Set only by an explicit review/correction. Low confidence remains in the original.
    pub reviewed: bool,
    pub corrected: bool,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct TranscriptProvenance {
    pub model: ModelIdentity,
    pub settings: TranscriptSettings,
    pub ffmpeg_sha256: String,
    pub ffprobe_sha256: String,
    pub recognized_language: String,
    pub audio_start: Rational,
    pub audio_samples: u64,
    pub timestamp_repairs: u64,
    pub clipped_samples: u64,
}
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Transcript {
    source_id: String,
    source_fingerprint: ContentFingerprint,
    source_metadata_sha256: String,
    provenance: TranscriptProvenance,
    /// Immutable original observations in source-relative time, including uncertain words.
    original: Vec<RecognizedWord>,
    original_sha256: String,
    words: Vec<TranscriptWord>,
}

impl Transcript {
    pub fn from_observations(project: &Project, source_id: &str,
        provenance: TranscriptProvenance, mut words: Vec<RecognizedWord>) -> Result<Self> {
        project.validate()?;
        let source = project.source(source_id)?;
        let audio_duration = Rational::new(i64::try_from(provenance.audio_samples)
            .map_err(|_| Error::LimitExceeded("transcript sample count"))?, 16000)?;
        validate_observations(&words, audio_duration)?;
        for word in &mut words {
            word.range.start = word.range.start.checked_add(provenance.audio_start)?;
            word.range.end = word.range.end.checked_add(provenance.audio_start)?;
        }
        let edits = words.iter().map(|word| Ok(TranscriptWord {
            id: word_id(source_id, word)?, range: word.range, text: word.text.clone(),
            locked: false, reviewed: false, corrected: false,
        })).collect::<Result<Vec<_>>>()?;
        let value = Self { source_id: source_id.into(), source_fingerprint: source.fingerprint.clone(),source_metadata_sha256:source_metadata_digest(source)?,
            original_sha256: observations_digest(&words)?, original: words,
            words: edits, provenance };
        value.validate(project)?;
        Ok(value)
    }
    pub fn source_id(&self) -> &str { &self.source_id }
    pub fn provenance(&self) -> &TranscriptProvenance { &self.provenance }
    pub fn original(&self) -> &[RecognizedWord] { &self.original }
    pub fn words(&self) -> &[TranscriptWord] { &self.words }
    pub fn validate(&self, project: &Project) -> Result<()> {
        if project.sources.len()!=1 {return Err(Error::Unsupported("transcription currently requires one source"));}
        let source = project.source(&self.source_id)?;
        if source.fingerprint != self.source_fingerprint || source_metadata_digest(source)?!=self.source_metadata_sha256 { return Err(Error::InputChanged); }
        let p = &self.provenance;
        p.model.validate()?;
        if p.model.contract != WHISPER_CONTRACT || p.model.preprocessing != WHISPER_PROCESSING {
            return Err(Error::InvalidProject("transcript model contract"));
        }
        p.settings.validate()?;
        let audio=source.media.audio.as_ref().ok_or(Error::InvalidProject("transcript requires selected audio"))?;
        if !audio.channels.is_some_and(|n|n>u32::from(p.settings.analysis_channel)&&n<=8)
            || !audio.sample_rate.is_some_and(|r|(7350..=192000).contains(&r)) {
            return Err(Error::InvalidProject("transcript selected audio metadata"));
        }
        language(&p.recognized_language)?;
        if p.recognized_language == "auto" || (p.settings.language != "auto" && p.settings.language != p.recognized_language) {
            return Err(Error::InvalidProject("transcript recognized language"));
        }
        crate::model_pack::hash(&p.ffmpeg_sha256)?;
        crate::model_pack::hash(&p.ffprobe_sha256)?;
        if p.audio_samples == 0 || p.audio_samples > MAX_TRANSCRIPT_SECONDS as u64 * 16000
            || p.audio_start.numerator() < 0 || p.timestamp_repairs > p.audio_samples
            || p.clipped_samples > p.audio_samples {
            return Err(Error::InvalidProject("transcript audio provenance"));
        }
        let end = p.audio_start.checked_add(Rational::new(p.audio_samples as i64, 16000)?)?;
        // The last resampled sample may straddle the half-open video endpoint.
        if end > source.duration.checked_add(Rational::new(1,16000)?)? {
            return Err(Error::InvalidProject("transcript audio exceeds source"));
        }
        validate_observations(&self.original, source.duration)?;
        if self.original.len() != self.words.len() || observations_digest(&self.original)? != self.original_sha256 {
            return Err(Error::InvalidProject("transcript original integrity"));
        }
        let mut ids = BTreeSet::new();
        let mut previous = Rational::new(0,1)?;
        for (original, word) in self.original.iter().zip(&self.words) {
            if original.range.start < p.audio_start || original.range.end > end {
                return Err(Error::InvalidProject("transcript observation outside decoded coverage"));
            }
            if word.id != word_id(&self.source_id, original)? || !ids.insert(&word.id) {
                return Err(Error::InvalidProject("transcript word identity"));
            }
            word_text(&word.text)?; word.range.validate()?;
            if word.range.start < previous || word.range.end > source.duration {
                return Err(Error::InvalidProject("transcript correction timing/order"));
            }
            if !word.corrected && (word.text != original.text || word.range != original.range) {
                return Err(Error::InvalidProject("unmarked transcript correction"));
            }
            if word.corrected && !word.reviewed {
                return Err(Error::InvalidProject("transcript correction needs explicit review"));
            }
            previous = word.range.end;
        }
        Ok(())
    }
    pub fn word_uncertain(&self, id: &str) -> Result<bool> {
        self.query_bounds()?;
        let index = self.words.iter().position(|w| w.id == id)
            .ok_or(Error::InvalidInput("unknown transcript word"))?;
        self.uncertain_at(index)
    }
    fn uncertain_at(&self,index:usize)->Result<bool> {
        let original=self.original.get(index).ok_or(Error::InvalidProject("transcript original/word count mismatch"))?;
        if original.confidence.is_some_and(|p|!p.is_finite()||!(0.0..=1.0).contains(&p)) {
            return Err(Error::InvalidProject("transcript confidence"));
        }
        Ok(original.confidence.is_none_or(|p| p < self.provenance.settings.low_confidence_below)
            || self.provenance.timestamp_repairs > 0 || self.provenance.clipped_samples > 0)
    }
    fn query_bounds(&self)->Result<()> {
        if self.words.len()>MAX_TRANSCRIPT_WORDS||self.original.len()>MAX_TRANSCRIPT_WORDS {
            return Err(Error::LimitExceeded("transcript word count"));
        }
        if self.original.len()!=self.words.len(){return Err(Error::InvalidProject("transcript original/word count mismatch"));}
        self.provenance.settings.validate()
    }
    /// Literal Unicode lowercase search; no regex execution or guessed semantic matches.
    pub fn search(&self, query: &str) -> Result<Vec<TranscriptMatch>> {
        self.query_bounds()?;
        word_text(query)?;
        let needle = query.to_lowercase();
        let mut result = Vec::new();
        for (first, word) in self.words.iter().enumerate() {
            let mut text = String::new();
            for last in first..self.words.len().min(first + 32) {
                append_word(&mut text, &self.words[last].text);
                let found=if query.split_whitespace().count()==1 {
                    last==first&&text.to_lowercase().contains(&needle)
                } else {text.to_lowercase().starts_with(&needle)};
                if found {
                    result.push(TranscriptMatch { first_word: word.id.clone(), last_word: self.words[last].id.clone(),
                        range: TimeRange::new(word.range.start, self.words[last].range.end)?, text });
                    break;
                }
                if query.split_whitespace().count()==1 {break;}
                if text.len() > MAX_WORD_BYTES * 2 { break; }
            }
            if result.len() >= 256 { break; }
        }
        Ok(result)
    }
    /// Punctuation/gap/length heuristic; no claim of linguistic forced alignment.
    pub fn sentences(&self) -> Result<Vec<TranscriptSentence>> {
        self.query_bounds()?;
        let mut result = Vec::new();
        let mut start = 0;
        while start < self.words.len() {
            let mut text = String::new(); let mut end = start;
            let mut uncertain = false;
            while end < self.words.len() {
                let word = &self.words[end];
                if end > start && (word.range.start.checked_sub(self.words[end-1].range.end)? > Rational::new(1,1)?
                    || text.len() + word.text.len() > 160 || end-start >= 20) { break; }
                append_word(&mut text, &word.text);
                uncertain |= self.uncertain_at(end)? && !word.reviewed;
                end += 1;
                if word.text.ends_with(['.','!','?','。','！','？']) { break; }
            }
            result.push(TranscriptSentence { id: format!("sentence-{}", self.words[start].id),
                first_word: self.words[start].id.clone(), last_word: self.words[end-1].id.clone(),
                range: TimeRange::new(self.words[start].range.start,self.words[end-1].range.end)?, text, uncertain });
            start = end;
        }
        Ok(result)
    }
    pub fn chapter_suggestions(&self, minimum_spacing: Rational) -> Result<Vec<ChapterSuggestion>> {
        if minimum_spacing < Rational::new(30,1)? || minimum_spacing > Rational::new(600,1)? {
            return Err(Error::InvalidInput("chapter spacing must be 30 to 600 seconds"));
        }
        let mut result: Vec<ChapterSuggestion> = Vec::new();
        for sentence in self.sentences()? {
            if sentence.uncertain { continue; }
            if result.last().is_none_or(|last| sentence.range.start.checked_sub(last.at).is_ok_and(|v| v >= minimum_spacing)) {
                result.push(ChapterSuggestion { at: sentence.range.start, title: sentence.text.chars().take(80).collect(),
                    sentence_id: sentence.id, reason: "Reviewed sentence boundary and requested minimum spacing; verify chapter meaning.".into() });
            }
            if result.len() == 128 { break; }
        }
        Ok(result)
    }
    pub fn subtitle_document(&self, format: SubtitleFormat) -> Result<SubtitleDocument> {
        let sentences = self.sentences()?;
        if sentences.len() > crate::subtitles::MAX_CUES { return Err(Error::LimitExceeded("generated subtitle cue count")); }
        let cues: Vec<CaptionCue> = sentences.into_iter().enumerate().map(|(i,s)| CaptionCue {
            id: format!("transcript-cue-{}",i+1), range:s.range,text:s.text,
        }).collect();
        let mapped = cues.iter().map(|c| crate::subtitles::MappedCue {
            source_id:c.id.clone(),part:1,range:c.range,text:c.text.clone(),
        }).collect::<Vec<_>>();
        let bytes = crate::subtitles::sidecar(&mapped,format)?;
        let original = String::from_utf8(bytes).map_err(|_|Error::InvalidOutput("generated subtitle UTF-8"))?;
        let mut generated_words=Vec::new();
        for cue in &cues {for word in self.words.iter().filter(|w|w.range.start>=cue.range.start&&w.range.end<=cue.range.end) {
            generated_words.push(crate::subtitles::CaptionWord{cue_id:cue.id.clone(),range:word.range,text:word.text.clone()});
        }}
        let document = SubtitleDocument { format, original_sha256:format!("{:x}",Sha256::digest(original.as_bytes())),original,cues,generated_words };
        document.validate()?; Ok(document)
    }
    /// Captions remain source-time evidence and follow the project's current cuts.
    pub fn subtitles_for_project(&self, project:&Project, format:SubtitleFormat) -> Result<Vec<u8>> {
        self.validate(project)?;
        let timeline=project.timeline()?;
        let prepared=self.subtitle_document(format)?.for_timeline(&timeline,&self.source_id)?;
        crate::subtitles::sidecar(&prepared.remap(&timeline,&self.source_id)?,format)
    }
    pub fn subtitles_for_variant(&self,project:&Project,variant:&str,format:SubtitleFormat)->Result<Vec<u8>> {
        self.validate(project)?;
        let timeline=project.timeline_for_variant(variant)?;
        let prepared=self.subtitle_document(format)?.for_timeline(&timeline,&self.source_id)?;
        crate::subtitles::sidecar(&prepared.remap(&timeline,&self.source_id)?,format)
    }
    pub fn filler_proposals(&self, project: &Project, explicit_words: &[String]) -> Result<Vec<EditOperation>> {
        self.validate(project)?;
        if explicit_words.is_empty() || explicit_words.len() > 32 { return Err(Error::InvalidInput("explicit filler vocabulary")); }
        let mut vocabulary = BTreeSet::new();
        for text in explicit_words { word_text(text)?;
            if text.split_whitespace().count() != 1 { return Err(Error::InvalidInput("filler vocabulary requires individual words")); }
            vocabulary.insert(lexical(text));
        }
        let mut result = Vec::new();
        for word in &self.words {
            if word.locked || !word.reviewed || !vocabulary.contains(&lexical(&word.text)) || protected(project,&self.source_id,word.range)
                || word.range.duration()? > Rational::new(1,1)? { continue; }
            result.push(EditOperation { id: format!("filler-{}",word.id),source_id:self.source_id.clone(),kind:EditKind::RemoveRange,
                range:word.range,reason:format!("Explicit filler vocabulary matched reviewed word '{}'; verify the boundary by listening. model={} manifest={} original={}",word.text,self.provenance.model.id,self.provenance.model.manifest_sha256,self.original_sha256),
                origin:EditOrigin::Generator{id:TRANSCRIPT_GENERATOR.into(),version:TRANSCRIPT_GENERATOR_VERSION.into()},
                disposition:Disposition::NeedsReview,enabled:true,locked:false,user_override:false });
            if result.len() > crate::project::MAX_OPERATIONS { return Err(Error::LimitExceeded("transcript filler proposals")); }
        }
        Ok(result)
    }
    pub fn punch_in_suggestions(&self, project:&Project) -> Result<Vec<SentencePunchIn>> {
        self.validate(project)?;
        Ok(self.sentences()?.into_iter().filter(|s| !s.uncertain
            && s.range.duration().is_ok_and(|d| d >= Rational::new(2,1).unwrap() && d <= Rational::new(12,1).unwrap())
            && !protected(project,&self.source_id,s.range)).map(|s| SentencePunchIn {
                sentence_id:s.id,range:s.range,reason:"Sentence timing suggestion only. Check subject visibility and existing crop motion before accepting a punch-in.".into(),
            }).collect())
    }
    fn preserve_corrections(&mut self, old:&Self) -> Result<()> {
        if old.source_id != self.source_id || old.source_fingerprint != self.source_fingerprint
            ||old.source_metadata_sha256!=self.source_metadata_sha256 { return Err(Error::InputChanged); }
        for previous in old.words.iter().filter(|w| w.locked || w.corrected || w.reviewed) {
            let Some(new) = self.words.iter_mut().find(|w| w.id == previous.id) else {
                return Err(Error::LockedEdit);
            };
            *new = previous.clone();
        }
        Ok(())
    }
}

#[derive(Debug,Clone,PartialEq,Serialize)]
pub struct TranscriptMatch { pub first_word:String,pub last_word:String,pub range:TimeRange,pub text:String }
#[derive(Debug,Clone,PartialEq,Serialize)]
pub struct TranscriptSentence { pub id:String,pub first_word:String,pub last_word:String,pub range:TimeRange,pub text:String,pub uncertain:bool }
#[derive(Debug,Clone,PartialEq,Serialize)]
pub struct ChapterSuggestion { pub at:Rational,pub title:String,pub sentence_id:String,pub reason:String }
#[derive(Debug,Clone,PartialEq,Serialize)]
pub struct SentencePunchIn { pub sentence_id:String,pub range:TimeRange,pub reason:String }

impl Project {
    pub fn set_transcript(&mut self, mut transcript:Transcript) -> Result<()> {
        self.edit(|p| { transcript.validate(p)?;
            if let Some(old) = &p.transcript { transcript.preserve_corrections(old)?; }
            transcript.validate(p)?; p.transcript=Some(transcript); Ok(()) })
    }
    pub fn clear_transcript(&mut self) -> Result<()> {
        self.edit(|p| { if p.transcript.as_ref().is_some_and(|t| t.words.iter().any(|w|w.locked)) { return Err(Error::LockedEdit); }
            p.transcript=None; Ok(()) })
    }
    pub fn correct_transcript_word(&mut self,id:&str,text:String,range:TimeRange)->Result<()> {
        self.edit(|p| { let w=transcript_word_mut(p,id)?; if w.locked { return Err(Error::LockedEdit); }
            w.text=text;w.range=range;w.corrected=true;w.reviewed=true;Ok(()) })
    }
    pub fn review_transcript_word(&mut self,id:&str)->Result<()> {
        self.edit(|p| { let w=transcript_word_mut(p,id)?; if w.locked { return Err(Error::LockedEdit); } w.reviewed=true;Ok(()) })
    }
    pub fn set_transcript_word_locked(&mut self,id:&str,locked:bool)->Result<()> {
        self.edit(|p| { transcript_word_mut(p,id)?.locked=locked;Ok(()) })
    }
    pub fn propose_transcript_fillers(&mut self,explicit_words:&[String])->Result<()> {
        let proposals=self.transcript.as_ref().ok_or(Error::InvalidInput("project has no transcript"))?.filler_proposals(self,explicit_words)?;
        self.replace_generated(TRANSCRIPT_GENERATOR,TRANSCRIPT_GENERATOR_VERSION,proposals)
    }
    /// Explicitly install generated source-time captions through the existing
    /// presentation review/render path. Existing supplied/edited captions win.
    pub fn install_transcript_captions(&mut self,variant:&str,style:Option<crate::presentation::TextStyle>,
        placement:Option<crate::presentation::Placement>,burn_in:bool)->Result<()> {
        let transcript=self.transcript.as_ref().ok_or(Error::InvalidInput("project has no transcript"))?;
        transcript.validate(self)?;
        let document=transcript.subtitle_document(SubtitleFormat::WebVtt)?;
        let mut presentation=self.variant(variant)?.presentation.clone().unwrap_or_default();
        if presentation.locked{return Err(Error::LockedEdit);}
        if presentation.captions.is_some(){return Err(Error::InvalidInput("existing captions require explicit removal before transcript installation"));}
        presentation.captions=Some(crate::presentation::CaptionLayer{document,style,placement,burn_in});
        presentation.enabled=true;
        self.set_presentation(variant,Some(presentation))
    }
    /// Explicitly refresh a still-generated caption layer after transcript word
    /// corrections. Individually edited cues lose their word annotations and
    /// block refresh so manually supplied caption work cannot be overwritten.
    pub fn refresh_transcript_captions(&mut self,variant:&str)->Result<()> {
        let transcript=self.transcript.as_ref().ok_or(Error::InvalidInput("project has no transcript"))?;
        transcript.validate(self)?;
        let mut presentation=self.variant(variant)?.presentation.clone().ok_or(Error::InvalidInput("variant has no generated captions"))?;
        if presentation.locked{return Err(Error::LockedEdit);}
        let captions=presentation.captions.as_mut().ok_or(Error::InvalidInput("variant has no generated captions"))?;
        if captions.document.generated_words.is_empty()||captions.document.cues.iter().any(|c|
            !captions.document.generated_words.iter().any(|w|w.cue_id==c.id)) {
            return Err(Error::InvalidInput("manual caption corrections require explicit reconciliation"));
        }
        captions.document=transcript.subtitle_document(captions.document.format)?;
        self.set_presentation(variant,Some(presentation))
    }
    /// Sentence selection only proposes a restrained crop; normal framing review
    /// must still approve it. A preexisting crop is never silently replaced.
    pub fn propose_transcript_punch_ins(&mut self,variant:&str,selected_sentences:&[String],
        target:crate::reframe::OutputSize,zoom:f64)->Result<()> {
        if selected_sentences.is_empty()||selected_sentences.len()>16{return Err(Error::InvalidInput("explicit sentence punch-in selection"));}
        if self.variant(variant)?.framing.as_ref().is_some_and(|f|f.locked){return Err(Error::LockedEdit);}
        if self.variant(variant)?.framing.is_some(){return Err(Error::Unsupported("sentence punch-in installation requires an empty framing layer; preserve existing crop edits"));}
        let transcript=self.transcript.as_ref().ok_or(Error::InvalidInput("project has no transcript"))?;
        let candidates=transcript.punch_in_suggestions(self)?;
        let mut unique=BTreeSet::new();let mut intervals=Vec::new();
        for id in selected_sentences {
            if !unique.insert(id){return Err(Error::InvalidInput("duplicate sentence punch-in selection"));}
            intervals.push(candidates.iter().find(|c|c.sentence_id==*id).ok_or(Error::InvalidInput("unknown or uncertain sentence punch-in"))?.range);
        }
        intervals.sort_by_key(|r|r.start);
        let source=self.source(transcript.source_id())?;
        let cuts=crate::face::shot_ranges(self)?.iter().map(|r|r.start).filter(|at|*at>Rational::new(0,1).unwrap()).collect::<Vec<_>>();
        let framing=crate::presentation::explicit_punch_ins(source,target,&intervals,&cuts,zoom,Rational::new(1,1)?)?;
        self.set_variant_framing(variant,Some(framing))
    }
}
fn transcript_word_mut<'a>(p:&'a mut Project,id:&str)->Result<&'a mut TranscriptWord> {
    p.transcript.as_mut().and_then(|t|t.words.iter_mut().find(|w|w.id==id)).ok_or(Error::InvalidInput("unknown transcript word"))
}
fn protected(p:&Project,source_id:&str,range:TimeRange)->bool {
    p.assembly.iter().any(|c|c.source_id==source_id&&c.locked&&c.range.overlaps(&range))
        || p.operations.iter().any(|o|o.source_id==source_id&&o.enabled&&o.range.overlaps(&range)
            && (o.locked || (o.kind==EditKind::ProtectRange && o.disposition!=Disposition::Ignore)))
}
pub(crate) fn validate_observations(words:&[RecognizedWord],duration:Rational)->Result<()> {
    if words.len()>MAX_TRANSCRIPT_WORDS { return Err(Error::LimitExceeded("transcript word count")); }
    let mut end=Rational::new(0,1)?;
    for word in words { word.validate(duration)?;
        if word.range.start<end { return Err(Error::InvalidOutput("transcript words overlap or are out of order")); }
        end=word.range.end;
    } Ok(())
}
fn observations_digest(words:&[RecognizedWord])->Result<String> {
    Ok(format!("{:x}",Sha256::digest(serde_json::to_vec(words).map_err(|_|Error::InvalidProject("transcript observations serialization"))?)))
}
fn source_metadata_digest(source:&crate::project::ProjectSource)->Result<String> {
    Ok(format!("{:x}",Sha256::digest(serde_json::to_vec(&(&source.media,source.timeline_origin,source.duration))
        .map_err(|_|Error::InvalidProject("transcript source metadata serialization"))?)))
}
fn word_id(source_id:&str,word:&RecognizedWord)->Result<String> {
    let data=serde_json::to_vec(&(source_id,word.range,&word.text)).map_err(|_|Error::InvalidProject("transcript identity serialization"))?;
    Ok(format!("word-{}",&format!("{:x}",Sha256::digest(data))[..24]))
}
pub(crate) fn word_text(text:&str)->Result<()> {
    crate::subtitles::valid_text(text,MAX_WORD_BYTES,false)?;
    if text.trim().is_empty() || text.trim()!=text || text.chars().any(char::is_control) {
        return Err(Error::InvalidInput("bounded nonempty transcript text"));
    } Ok(())
}
fn lexical(text:&str)->String {text.trim_matches(|c:char|!c.is_alphanumeric()).to_lowercase()}
fn append_word(text:&mut String,word:&str) {
    crate::subtitles::append_caption_word(text,word);
}
