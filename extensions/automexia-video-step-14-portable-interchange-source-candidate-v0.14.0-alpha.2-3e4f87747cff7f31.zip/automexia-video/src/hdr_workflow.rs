//! HDR preservation on the existing job owner, decoder and output leases.
use crate::{Cancellation,Error,Rational,Result,VideoExtension};
use crate::hdr::{HdrEvidence,HdrPlan,HdrTask};
use crate::host::{InputFile,MediaHost,OutputPolicy,ProgressSink};
use crate::project::Project;
use crate::progress::Stage;
use crate::extension::emit;
use crate::voice_render::{AudioRenderReport,AudioTask};
use serde::Serialize;
use std::{path::PathBuf,time::{Duration,Instant}};

#[derive(Debug,Clone)]
pub struct HdrRequest{pub project_file:PathBuf,pub variant:String,pub output:PathBuf,pub output_policy:OutputPolicy,pub timeout:Duration}
impl HdrRequest{pub fn new(project_file:impl Into<PathBuf>,output:impl Into<PathBuf>)->Self{Self{project_file:project_file.into(),variant:"main".into(),output:output.into(),output_policy:OutputPolicy::CreateNew,timeout:Duration::from_secs(7200)}}}
#[derive(Debug,Clone,Serialize)]
pub struct HdrResult{pub output:PathBuf,pub source:InputFile,pub project_revision:u64,pub decision_sha256:String,pub variant:String,pub retained_range:crate::TimeRange,pub duration:Rational,pub verified_frames:usize,pub audio:Option<AudioRenderReport>,pub warnings:Vec<String>}
impl<H:MediaHost> VideoExtension<H>{
    pub fn preserve_hdr(&self,project:&Project,request:&HdrRequest,cancel:&Cancellation,progress:&mut ProgressSink<'_>)->Result<HdrResult>{
        crate::voice_render::validate_timeout(request.timeout)?;
        for path in [&request.project_file,&request.output]{if !path.is_absolute()||path.components().any(|c|matches!(c,std::path::Component::ParentDir|std::path::Component::CurDir))||path.as_os_str().as_encoded_bytes().contains(&0){return Err(Error::InvalidInput("absolute normalized HDR project/output paths"));}}
        crate::project::id_ok(&request.variant)?;
        if !request.project_file.is_absolute()||!request.project_file.extension().and_then(|x|x.to_str()).is_some_and(|x|x.eq_ignore_ascii_case("amxv"))||!request.output.extension().and_then(|x|x.to_str()).is_some_and(|x|x.eq_ignore_ascii_case("mp4")){return Err(Error::InvalidInput("HDR preservation requires an absolute .amxv project and .mp4 output"));}
        let plan=HdrPlan::from_project(project,&request.variant)?;
        let job=self.begin(cancel)?;let started=Instant::now();
        let remaining=||->Result<Duration>{let n=request.timeout.saturating_sub(started.elapsed());if n.is_zero(){Err(Error::Timeout)}else{Ok(n)}};
        let deadline=started.checked_add(request.timeout).ok_or(Error::InvalidInput("HDR deadline"))?;
        let operation_cancel=job.cancel.with_deadline(deadline);let cancel=&operation_cancel;
        crate::presentation::guard_destination(project,&request.project_file,&request.output,&request.output_policy)?;
        let decision_sha256=project.decision_digest()?;let source=&project.sources[0];emit(progress,Stage::Inspecting)?;
        let input=self.host().inspect_input(&source.resolve(&request.project_file)?,cancel)?;source.check_input(&input)?;
        let current=self.hdr_summary(&input,false,remaining()?,cancel,progress)?;source.check_media(&current)?;
        let runtime=self.host().runtime_capabilities(cancel)?;
        if !runtime.muxers.contains("mp4")||!runtime.muxers.contains("framehash")||!runtime.encoders.contains("rawvideo"){return Err(Error::MissingCapability("HDR MP4 preservation and decoded SHA256 evidence"));}
        emit(progress,Stage::VerifyingTimeline)?;remaining()?;
        let before=self.hdr_evidence(&input,plan.stream,&plan,false,deadline,cancel,progress)?;remaining()?;
        let mut audio_plan=if source.media.audio.is_some(){
            if !runtime.encoders.contains("aac")||!runtime.encoders.contains("pcm_s24le")||!runtime.muxers.contains("wav"){return Err(Error::MissingCapability("HDR reviewed PCM/AAC audio route"));}
            Some(crate::plan::build_audio_plan(project,&request.variant,&current,&runtime)?)
        }else{None};
        let enhancement=if let Some(enhancement)=&project.settings.voice_enhancement{
            enhancement.check_source(source)?;let path=enhancement.resolve(&request.project_file)?;if path==request.output{return Err(Error::SameFile);}
            let file=self.host().inspect_input(&path,cancel)?;enhancement.check_input(&file)?;
            let info=self.hdr_summary(&file,true,remaining()?,cancel,progress)?;
            crate::enhancement::validate_enhanced_media(&info,&enhancement.receipt,source.duration)?;
            self.host().run_audio(&AudioTask::ValidateStem{input:file.clone(),timeout:remaining()?},cancel,progress)?;
            audio_plan.as_mut().ok_or(Error::InvalidProject("enhancement requires selected HDR audio"))?.attach_enhanced_audio(&file.canonical_path)?;Some(file)
        }else{None};
        if let Some(audio)=&mut audio_plan{self.prepare_voice(audio,&input,remaining()?,cancel,progress)?;}
        // Both leases are private. The audio lease is never published and remains
        // alive through final AAC verification; only the final MP4 is committed.
        let pcm_lease=if audio_plan.is_some(){Some(self.host().stage_output(&input,&request.output,&request.output_policy,cancel)?)}else{None};
        let output_lease=self.host().stage_output(&input,&request.output,&request.output_policy,cancel)?;
        let audio_report=loop{
            cancel.check()?;remaining()?;self.host().revalidate_input(&input,cancel)?;if let Some(file)=&enhancement{self.host().revalidate_input(file,cancel)?;}
            let pcm=if let (Some(audio),Some(lease))=(&audio_plan,&pcm_lease){
                self.host().run_audio(&AudioTask::RenderStem{input:input.clone(),plan:audio.clone(),output:lease.path().to_owned(),timeout:remaining()?},cancel,progress)?;
                let file=self.host().inspect_input(lease.path(),cancel)?;let info=self.hdr_summary(&file,true,remaining()?,cancel,progress)?;let a=source.media.audio.as_ref().ok_or(Error::InvalidProject("HDR selected audio"))?;
                let rate=a.sample_rate.ok_or(Error::InvalidProject("HDR audio rate"))?;let channels=a.channels.ok_or(Error::InvalidProject("HDR audio channels"))?;let layout=crate::voice_render::qualified_layout(channels,a.channel_layout.as_deref())?;
                crate::voice_workflow::validate_stem(&info,plan.duration()?,rate,channels,&layout)?;
                self.host().run_audio(&AudioTask::ValidateStem{input:file.clone(),timeout:remaining()?},cancel,progress)?;Some(file)
            }else{None};
            emit(progress,Stage::Rendering)?;remaining()?;
            self.host().run_hdr(&HdrTask::Mux{input:input.clone(),audio:pcm.clone(),output:output_lease.path().to_owned(),plan:plan.clone(),timeout:remaining()?},cancel,progress)?;
            remaining()?;emit(progress,Stage::Validating)?;
            let output=self.host().inspect_input(output_lease.path(),cancel)?;
            let after=self.hdr_evidence(&output,0,&plan,true,deadline,cancel,progress)?;before.compare(&after,&plan,cancel)?;
            let info=self.hdr_summary(&output,false,remaining()?,cancel,progress)?;
            if info.streams.iter().filter(|s|s.kind=="video").count()!=1||info.streams.len()!=1+usize::from(audio_plan.is_some()){return Err(Error::InvalidOutput("HDR output stream selection"));}
            if let Some(a)=&source.media.audio{
                let b=info.streams.iter().find(|s|s.kind=="audio").ok_or(Error::InvalidOutput("HDR audio stream absent"))?;
                if b.codec.as_deref()!=Some("aac")||b.sample_rate!=a.sample_rate||b.channels!=a.channels||crate::voice_render::qualified_layout(b.channels.ok_or(Error::InvalidOutput("HDR audio channels"))?,b.channel_layout.as_deref())?!=crate::voice_render::qualified_layout(a.channels.ok_or(Error::InvalidProject("HDR audio channels"))?,a.channel_layout.as_deref())?{return Err(Error::InvalidOutput("HDR audio codec/rate/layout"));}
                let tolerance=Rational::new(1,i64::from(a.sample_rate.ok_or(Error::InvalidProject("HDR audio rate"))?))?;
                let duration=b.exact_duration().ok_or(Error::InvalidOutput("HDR audio duration"))?;
                if b.exact_start()!=Some(Rational::new(0,1)?)||duration.checked_sub(plan.duration()?)?.as_f64().abs()>tolerance.as_f64()+0.000001{return Err(Error::InvalidOutput("HDR audio clock"));}
            }
            self.host().run_hdr(&HdrTask::ValidateDecode{input:output.clone(),has_audio:audio_plan.is_some(),timeout:remaining()?},cancel,progress)?;
            let report=if let Some(audio)=&mut audio_plan{match self.check_voice_output(audio,output_lease.path(),&info,remaining()?,cancel,progress)?{crate::voice_workflow::AudioValidation::Retry=>continue,crate::voice_workflow::AudioValidation::Ready(report)=>report}}else{None};
            self.host().revalidate_input(&output,cancel)?;if let Some(pcm)=&pcm{self.host().revalidate_input(pcm,cancel)?;}break report;
        };
        self.host().revalidate_input(&input,cancel)?;if let Some(file)=&enhancement{self.host().revalidate_input(file,cancel)?;}
        crate::presentation::guard_destination(project,&request.project_file,&request.output,&request.output_policy)?;cancel.check()?;remaining()?;
        let duration=plan.duration()?;let verified_frames=plan.frames()?;emit(progress,Stage::Publishing)?;cancel.check()?;remaining()?;let output=output_lease.publish(cancel)?;
        Ok(HdrResult{output,source:input,project_revision:project.revision,decision_sha256,variant:request.variant.clone(),retained_range:plan.range,duration,verified_frames,audio:audio_report,warnings:vec!["This explicit preservation request copies HEVC video and encodes selected audio as AAC; saved delivery codec, quality and speed-preset options are not used.".into(),"Video preservation was checked using selected packet and codec-header SHA256, every decoded frame's pixels, timestamps and static HDR metadata.".into(),"Selected audio is rendered through the reviewed audio chain and encoded as AAC. Unselected streams, descriptive metadata and chapters are omitted.".into(),"No calibrated HDR display, Dolby Vision, HDR color transform, graphics or arbitrary GOP trim qualification is implied.".into()]})
    }
    fn hdr_summary(&self,input:&InputFile,audio_only:bool,timeout:Duration,cancel:&Cancellation,progress:&mut ProgressSink<'_>)->Result<crate::MediaInfo>{
        let bytes=self.host().run_hdr(&HdrTask::Summary{input:input.clone(),audio_only,timeout},cancel,progress)?;crate::media::parse_probe(&bytes.stdout)
    }
    fn hdr_evidence(&self,input:&InputFile,stream:u32,plan:&HdrPlan,output:bool,deadline:Instant,cancel:&Cancellation,progress:&mut ProgressSink<'_>)->Result<HdrEvidence>{
        let packets=self.host().run_hdr(&HdrTask::Packets{input:input.clone(),stream,timeout:deadline.saturating_duration_since(Instant::now())},cancel,progress)?;
        let frames=self.host().run_hdr(&HdrTask::Frames{input:input.clone(),stream,timeout:deadline.saturating_duration_since(Instant::now())},cancel,progress)?;
        let pixels=self.host().run_hdr(&HdrTask::Pixels{input:input.clone(),stream,time_base:HdrEvidence::packet_time_base(&packets.stdout)?,timeout:deadline.saturating_duration_since(Instant::now())},cancel,progress)?;
        HdrEvidence::parse(&packets.stdout,&frames.stdout,&pixels.stdout,plan,output,cancel)
    }
}
