//! Step 9: frozen output profiles. This module has no I/O or host authority.
//! A profile describes delivery encoding, never edit approvals or HDR support.
use crate::{Error, Result};
use crate::host::{words, RuntimeCapabilities};
use crate::plan::SpeedPreset;
use serde::{Deserialize, Serialize};
use std::{ffi::OsString, path::Path};

pub const PROFILE_REVISION: u32 = 1;

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum RenderIntent { Preview, Fast, Publish, Master }
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum DeliveryFormat { H264Mp4, HevcMp4, Vp9Webm, Av1Webm, #[serde(rename="prores_mov")] ProResMov }

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct DeliveryProfile {
    pub revision: u32,
    pub intent: RenderIntent,
    pub format: DeliveryFormat,
    /// CRF for inter-frame codecs; named ProRes profile 0..3 for ProRes.
    /// This is not a cross-codec visual-quality scale.
    pub quality: u8,
    pub speed: SpeedPreset,
    pub threads: u8,
    pub audio_bitrate_kbps: u16,
}
impl DeliveryFormat {
    pub fn extension(self) -> &'static str { match self {
        Self::H264Mp4 | Self::HevcMp4 => "mp4", Self::Vp9Webm | Self::Av1Webm => "webm", Self::ProResMov => "mov",
    }}
    pub fn muxer(self) -> &'static str { match self {
        Self::H264Mp4 | Self::HevcMp4 => "mp4", Self::Vp9Webm | Self::Av1Webm => "webm", Self::ProResMov => "mov",
    }}
    pub fn encoder(self) -> &'static str { match self {
        Self::H264Mp4 => "libx264", Self::HevcMp4 => "libx265", Self::Vp9Webm => "libvpx-vp9",
        Self::Av1Webm => "libaom-av1", Self::ProResMov => "prores_ks",
    }}
    pub fn codec(self) -> &'static str { match self {
        Self::H264Mp4 => "h264", Self::HevcMp4 => "hevc", Self::Vp9Webm => "vp9", Self::Av1Webm => "av1", Self::ProResMov => "prores",
    }}
    pub fn audio_encoder(self) -> &'static str { match self {
        Self::H264Mp4 | Self::HevcMp4 => "aac", Self::Vp9Webm | Self::Av1Webm => "libopus", Self::ProResMov => "pcm_s24le",
    }}
    pub fn audio_codec(self) -> &'static str { match self {
        Self::Vp9Webm | Self::Av1Webm => "opus", _ => self.audio_encoder(),
    }}
    pub fn pixel_format(self) -> &'static str { if self == Self::ProResMov { "yuv422p10le" } else { "yuv420p" } }
    pub fn is_webm(self) -> bool { matches!(self, Self::Vp9Webm | Self::Av1Webm) }
    pub fn audio_rate(self, source_rate: u32) -> u32 { if self.is_webm() { 48000 } else { source_rate } }
}
impl DeliveryProfile {
    pub fn preset(intent: RenderIntent, format: Option<DeliveryFormat>) -> Self {
        let format = format.unwrap_or(if intent == RenderIntent::Master { DeliveryFormat::ProResMov } else { DeliveryFormat::H264Mp4 });
        let quality = match format {
            DeliveryFormat::ProResMov => 3,
            DeliveryFormat::Vp9Webm | DeliveryFormat::Av1Webm => match intent { RenderIntent::Preview => 40, RenderIntent::Fast => 34, RenderIntent::Publish => 28, RenderIntent::Master => 18 },
            DeliveryFormat::HevcMp4 => match intent { RenderIntent::Preview => 32, RenderIntent::Fast => 28, RenderIntent::Publish => 23, RenderIntent::Master => 18 },
            DeliveryFormat::H264Mp4 => match intent { RenderIntent::Preview => 28, RenderIntent::Fast => 23, RenderIntent::Publish => 18, RenderIntent::Master => 14 },
        };
        Self { revision: PROFILE_REVISION, intent, format, quality,
            speed: match intent { RenderIntent::Preview | RenderIntent::Fast => SpeedPreset::Fast, RenderIntent::Publish => SpeedPreset::Medium, RenderIntent::Master => SpeedPreset::Slow },
            threads: 2, audio_bitrate_kbps: if intent == RenderIntent::Preview { 96 } else { 192 } }
    }
    pub fn validate(&self) -> Result<()> {
        if self.revision != PROFILE_REVISION { return Err(Error::InvalidProject("unsupported delivery profile revision")); }
        if !(1..=16).contains(&self.threads) || !(32..=320).contains(&self.audio_bitrate_kbps) {
            return Err(Error::InvalidInput("delivery thread or audio bitrate limit"));
        }
        let max = match self.format { DeliveryFormat::ProResMov => 3, DeliveryFormat::Vp9Webm | DeliveryFormat::Av1Webm => 63, _ => 51 };
        if self.quality > max { return Err(Error::InvalidInput("quality outside codec profile range")); }
        Ok(())
    }
    pub fn validate_destination(&self, path: &Path) -> Result<()> {
        self.validate()?;
        if !path.extension().and_then(|s|s.to_str()).is_some_and(|s|s.eq_ignore_ascii_case(self.format.extension())) {
            return Err(Error::InvalidInput("destination extension does not match frozen delivery profile"));
        }
        Ok(())
    }
    pub fn check_runtime(&self, runtime: &RuntimeCapabilities, audio: bool) -> Result<()> {
        self.validate()?;
        if !runtime.encoders.contains(self.format.encoder()) { return Err(Error::MissingCapability(self.format.encoder())); }
        if !runtime.muxers.contains(self.format.muxer()) { return Err(Error::MissingCapability(self.format.muxer())); }
        if audio && !runtime.encoders.contains(self.format.audio_encoder()) { return Err(Error::MissingCapability(self.format.audio_encoder())); }
        Ok(())
    }
    pub fn warnings(&self, audio_rate: Option<u32>) -> Vec<String> {
        let mut result = vec![format!("Explicit software delivery: {} / {}; no hardware fallback, model or edit re-analysis.", self.format.encoder(), self.format.muxer())];
        if self.format == DeliveryFormat::ProResMov {
            result.push("ProRes stores 10-bit 4:2:2 output from the existing 8-bit SDR pipeline; it does not recover source precision or enable HDR. Large output is explicit, not an intermediate.".into());
            result.push("The qualified ProRes MOV path uses limited-range pixels; some probes omit the range tag. This exception is specific to this codec/container, not a general metadata waiver.".into());
        }
        if self.format.is_webm() { result.push("WebM represents non-square pixels using integer display dimensions; up to one display-pixel aspect quantization is checked explicitly. Square-pixel framed outputs are exact.".into()); }
        if self.format.is_webm() && audio_rate.is_some_and(|r|r!=48000) {
            result.push("The requested WebM profile explicitly resamples final audio to 48000 Hz for Opus. Channels and edit timing are preserved.".into());
        }
        if self.intent == RenderIntent::Preview { result.push("Preview intent selects faster/lower-quality delivery encoding; target geometry is still the saved output variant. Use review proxies for automatic size bounds.".into()); }
        result
    }
    /// Rewrite only the generated OUTPUT section, never input demuxer flags or
    /// a private graphics input. This accepts no user-supplied argument strings.
    pub(crate) fn encode_arguments(&self, args: Vec<OsString>, channels: Option<u32>) -> Result<Vec<OsString>> {
        self.validate()?;
        let boundary = args.iter().rposition(|v| v == "-map_metadata").ok_or(Error::InvalidInput("missing generated output section"))?;
        let output = args.last().cloned().ok_or(Error::InvalidInput("missing generated output path"))?;
        let remove = ["-c:v", "-preset", "-crf", "-pix_fmt", "-threads:v", "-c:a", "-b:a", "-threads:a", "-x264-params", "-movflags", "-f"];
        let mut result = args[..boundary].to_vec();
        let mut i = boundary;
        while i + 1 < args.len() {
            if remove.iter().any(|key| args[i] == *key) {
                if i + 2 >= args.len() { return Err(Error::InvalidInput("malformed generated output option")); }
                i += 2;
            } else { result.push(args[i].clone()); i += 1; }
        }
        result.extend(self.encoding_options(channels)?);
        result.push(output);
        if result.iter().map(|s|s.as_encoded_bytes().len()+1).sum::<usize>() > 30*1024 { return Err(Error::LimitExceeded("delivery command arguments")); }
        Ok(result)
    }
    pub fn encoding_options(&self, channels: Option<u32>) -> Result<Vec<OsString>> {
        self.validate()?;
        if channels.is_some_and(|c|c==0 || c>8) { return Err(Error::Unsupported("delivery audio channel count")); }
        let mut args = words(&["-c:v", self.format.encoder(), "-pix_fmt", self.format.pixel_format(), "-threads:v", &self.threads.to_string()]);
        match self.format {
            DeliveryFormat::H264Mp4 => args.extend(words(&["-preset",self.speed.as_str(),"-crf",&self.quality.to_string(),"-x264-params","videoformat=component"])),
            DeliveryFormat::HevcMp4 => args.extend(words(&["-preset",self.speed.as_str(),"-crf",&self.quality.to_string(),"-x265-params",&format!("pools=none:frame-threads={}:log-level=error",self.threads),"-tag:v","hvc1"])),
            DeliveryFormat::Vp9Webm => args.extend(words(&["-crf",&self.quality.to_string(),"-b:v","0","-deadline","good","-cpu-used",match self.speed{SpeedPreset::Fast=>"4",SpeedPreset::Medium=>"2",SpeedPreset::Slow=>"0"},"-row-mt","1"])),
            DeliveryFormat::Av1Webm => args.extend(words(&["-crf",&self.quality.to_string(),"-b:v","0","-cpu-used",match self.speed{SpeedPreset::Fast=>"8",SpeedPreset::Medium=>"6",SpeedPreset::Slow=>"4"},"-row-mt","1"])),
            DeliveryFormat::ProResMov => args.extend(words(&["-profile:v",&self.quality.to_string(),"-vendor","apl0"])),
        }
        if let Some(channels) = channels {
            args.extend(words(&["-c:a",self.format.audio_encoder(),"-threads:a","1"]));
            if self.format != DeliveryFormat::ProResMov { args.extend(words(&["-b:a",&format!("{}k",self.audio_bitrate_kbps)])); }
            if self.format.is_webm() { args.extend(words(&["-ar","48000","-mapping_family",if channels>2{"1"}else{"0"}])); }
        }
        if !self.format.is_webm() { args.extend(words(&["-movflags",if self.format==DeliveryFormat::ProResMov{"+faststart+write_colr"}else{"+faststart"}])); }
        args.extend(words(&["-f",self.format.muxer()]));
        Ok(args)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn output_rewrite_preserves_private_graphics_input_and_typed_paths() {
        let original = words(&["-f", "concat", "-safe", "1", "-i", "/private/graphics.ffconcat",
            "-filter_complex", "[0:v][1:v]overlay[vout]", "-map", "[vout]", "-map_metadata", "-1",
            "-c:v", "libx264", "-preset", "medium", "-crf", "18", "-pix_fmt", "yuv420p",
            "-threads:v", "2", "-x264-params", "videoformat=component", "-movflags", "+faststart",
            "-f", "mp4", "/private/output ; literal.webm"]);
        let p = DeliveryProfile::preset(RenderIntent::Publish, Some(DeliveryFormat::Vp9Webm));
        let result = p.encode_arguments(original.clone(), None).unwrap();
        let boundary = original.iter().position(|a|a=="-map_metadata").unwrap();
        assert_eq!(&result[..boundary], &original[..boundary]);
        assert_eq!(result.last(), original.last());
        assert_eq!(result.iter().filter(|v|**v=="-f").count(), 2);
        assert!(!result.iter().any(|v|v=="libx264" || v=="-x264-params"));
    }
    #[test]
    fn output_rewrite_requires_its_internal_generated_boundary() {
        let p = DeliveryProfile::preset(RenderIntent::Publish, None);
        assert!(p.encode_arguments(words(&["-f", "concat", "-i", "input"]), None).is_err());
    }
}
