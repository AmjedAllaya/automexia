use std::fmt;

pub type Result<T> = std::result::Result<T, Error>;

/// Errors deliberately avoid embedding media paths or raw process diagnostics.
/// Display them through the host's existing error presentation. An adapter may
/// keep explicitly consented, redacted diagnostics in its own private job log.
#[derive(Debug, Clone, PartialEq, Eq)]
#[non_exhaustive]
pub enum Error {
    InvalidProject(&'static str),
    UnsupportedProjectVersion(u32),
    LockedEdit,
    StaleReview,
    ReviewClosed,
    UnresolvedEdits,
    EmptyTimeline,
    Disabled,
    Busy,
    Cancelled,
    Timeout,
    InvalidInput(&'static str),
    InvalidProbe(&'static str),
    LimitExceeded(&'static str),
    Unsupported(&'static str),
    MissingCapability(&'static str),
    AmbiguousStream(&'static str),
    MissingStream(u32),
    InputChanged,
    OutputExists,
    OutputChanged,
    SameFile,
    ToolFailed { tool: &'static str, exit_code: Option<i32> },
    ToolIdentityChanged,
    InvalidOutput(&'static str),
    Io(&'static str),
    CallbackPanicked,
    Poisoned,
}
impl fmt::Display for Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::InvalidProject(s) => write!(f,"Invalid video project: {s}"),
            Self::UnsupportedProjectVersion(v) => write!(f,"Unsupported video project schema: {v}"),
            Self::StaleReview => write!(f,"Review or preview is stale; refresh the current project before acting"),
            Self::ReviewClosed => write!(f,"The video review session is closed"),
            Self::LockedEdit => write!(f,"Unlock the edit before changing it"),
            Self::UnresolvedEdits => write!(f,"Resolve or disable pending edit proposals before rendering"),
            Self::EmptyTimeline => write!(f,"The edit removes all media; nothing can be rendered"),
            Self::Disabled => write!(f, "Video is disabled"),
            Self::Busy => write!(f, "Video's concurrent-job limit has been reached"),
            Self::Cancelled => write!(f, "Video operation cancelled"),
            Self::Timeout => write!(f, "Media tool exceeded the operation deadline"),
            Self::InvalidInput(s) => write!(f, "Invalid input: {s}"),
            Self::InvalidProbe(s) => write!(f, "Invalid media metadata: {s}"),
            Self::LimitExceeded(s) => write!(f, "Resource limit exceeded: {s}"),
            Self::Unsupported(s) => write!(f, "Not supported in this media foundation: {s}"),
            Self::MissingCapability(s) => write!(f, "Required media capability unavailable: {s}"),
            Self::AmbiguousStream(s) => write!(f, "Select an explicit {s} stream index"),
            Self::MissingStream(i) => write!(f, "Requested stream {i} is absent or has the wrong type"),
            Self::InputChanged => write!(f, "Input changed during the operation; output was not published"),
            Self::OutputExists => write!(f, "Output exists; choose another name or obtain explicit replacement approval"),
            Self::OutputChanged => write!(f, "Reviewed output changed; replacement approval is no longer applicable"),
            Self::SameFile => write!(f, "Output may not replace the source or an alias of it"),
            Self::ToolFailed { tool, exit_code } => write!(f, "{tool} failed (exit code {exit_code:?})"),
            Self::ToolIdentityChanged => write!(f, "Configured media executable changed; review it again"),
            Self::InvalidOutput(s) => write!(f, "Rendered output failed validation: {s}"),
            Self::Io(s) => write!(f, "File/process operation failed: {s}"),
            Self::CallbackPanicked => write!(f, "Host callback failed; the current video operation was stopped"),
            Self::Poisoned => write!(f, "Video job state is unavailable"),
        }
    }
}
impl std::error::Error for Error {}
