//! Bounded incremental parser for the fixed FFmpeg astats/ametadata profile.
//! No raw PCM or complete stdout capture. Integer PTS are authoritative; the
//! rounded `pts_time` display field is deliberately not used for edit timing.
use crate::{Error, Result};
use crate::pause::{ChannelEnergy, EnergyFrame, MAX_ENERGY_CHANNELS};

pub const MAX_METRIC_LINE: usize = 256;
pub const MAX_METRIC_BYTES: u64 = 1024 * 1024 * 1024;
const PREFIX: &str = "lavfi.astats.";
#[derive(Default)]
struct ChannelBuilder { rms: Option<Option<f64>>, peak: Option<Option<f64>>, nans: bool, infs: bool }
struct FrameBuilder { pts: i64, samples: Option<u32>, channels: Vec<ChannelBuilder> }

pub struct MetricParser {
    channels: usize, line: Vec<u8>, current: Option<FrameBuilder>, next_frame: u64,
    bytes: u64, failed: bool,
}
impl MetricParser {
    pub fn new(channels: usize) -> Result<Self> {
        if channels==0 || channels>MAX_ENERGY_CHANNELS {return Err(Error::InvalidInput("analysis channel count"));}
        Ok(Self{channels,line:Vec::with_capacity(MAX_METRIC_LINE),current:None,next_frame:0,bytes:0,failed:false})
    }
    pub fn feed(&mut self, bytes: &[u8], emit: &mut dyn FnMut(EnergyFrame)->Result<()>) -> Result<()> {
        if self.failed {return Err(Error::InvalidInput("metric parser already failed"));}
        let result=self.feed_inner(bytes,emit); if result.is_err(){self.failed=true;} result
    }
    fn feed_inner(&mut self, bytes: &[u8], emit:&mut dyn FnMut(EnergyFrame)->Result<()>) -> Result<()> {
        self.bytes=self.bytes.checked_add(bytes.len() as u64).ok_or(Error::LimitExceeded("audio metric bytes"))?;
        if self.bytes>MAX_METRIC_BYTES {return Err(Error::LimitExceeded("audio metric bytes"));}
        for &byte in bytes {
            if byte==b'\n' {
                let mut line=std::mem::take(&mut self.line);
                let text=std::str::from_utf8(&line).map_err(|_|Error::InvalidInput("non-ASCII audio metric"))?;
                let parsed=self.parse_line(text.trim_end_matches('\r'),emit);
                line.clear();self.line=line;
                parsed?;
            } else {
                if !(byte.is_ascii_graphic() || byte==b' ' || byte==b'\t' || byte==b'\r') {return Err(Error::InvalidInput("control character in audio metric"));}
                if self.line.len()>=MAX_METRIC_LINE {return Err(Error::LimitExceeded("audio metric line"));}
                self.line.push(byte);
            }
        }
        Ok(())
    }
    fn parse_line(&mut self, line:&str, emit:&mut dyn FnMut(EnergyFrame)->Result<()>) -> Result<()> {
        if line.is_empty() {return Ok(());}
        if line.starts_with("frame:") {
            self.flush(emit)?;
            let fields:Vec<_>=line.split_whitespace().collect();
            if fields.len()!=3 || !fields[1].starts_with("pts:") || !fields[2].starts_with("pts_time:") {
                return Err(Error::InvalidInput("audio metric frame header"));
            }
            let index=fields[0][6..].parse::<u64>().map_err(|_|Error::InvalidInput("audio metric index"))?;
            if index!=self.next_frame {return Err(Error::InvalidInput("audio metric sequence"));}
            self.next_frame=self.next_frame.checked_add(1).ok_or(Error::LimitExceeded("audio metric frames"))?;
            if self.next_frame>crate::pause::MAX_ANALYSIS_FRAMES {return Err(Error::LimitExceeded("audio metric frames"));}
            let pts=fields[1][4..].parse::<i64>().map_err(|_|Error::InvalidInput("audio metric integer PTS"))?;
            // pts_time is display-only, but still require a finite numeric value.
            let shown=fields[2][9..].parse::<f64>().map_err(|_|Error::InvalidInput("audio metric display time"))?;
            if !shown.is_finite(){return Err(Error::InvalidInput("audio metric display time"));}
            self.current=Some(FrameBuilder{pts,samples:None,channels:(0..self.channels).map(|_|ChannelBuilder::default()).collect()});
            return Ok(());
        }
        let body=line.strip_prefix(PREFIX).ok_or(Error::InvalidInput("unexpected audio metric key"))?;
        let (key,value)=body.split_once('=').ok_or(Error::InvalidInput("audio metric value"))?;
        let frame=self.current.as_mut().ok_or(Error::InvalidInput("audio metric before frame"))?;
        if key=="Overall.Number_of_samples" {
            if frame.samples.is_some(){return Err(Error::InvalidInput("duplicate sample count"));}
            let samples=value.parse::<f64>().map_err(|_|Error::InvalidInput("audio sample count"))?;
            if !samples.is_finite() || samples<1.0 || samples>192000.0 || samples.fract()!=0.0 {return Err(Error::InvalidInput("audio sample count"));}
            frame.samples=Some(samples as u32);return Ok(());
        }
        let (number,metric)=key.split_once('.').ok_or(Error::InvalidInput("audio channel metric"))?;
        let number=number.parse::<usize>().map_err(|_|Error::InvalidInput("audio metric channel"))?;
        if number==0 || number>self.channels {return Err(Error::InvalidInput("audio metric channel"));}
        let channel=&mut frame.channels[number-1];
        match metric {
            "RMS_level"=>{if channel.rms.is_some(){return Err(Error::InvalidInput("duplicate RMS metric"));}channel.rms=Some(parse_db(value)?);}
            "Peak_level"=>{if channel.peak.is_some(){return Err(Error::InvalidInput("duplicate peak metric"));}channel.peak=Some(parse_db(value)?);}
            "Number of NaNs"=>{if channel.nans || !zero(value){return Err(Error::InvalidInput("invalid or duplicate NaN metric"));}channel.nans=true;}
            "Number of Infs"=>{if channel.infs || !zero(value){return Err(Error::InvalidInput("invalid or duplicate infinity metric"));}channel.infs=true;}
            _=>return Err(Error::InvalidInput("unexpected audio channel metric")),
        }
        Ok(())
    }
    fn flush(&mut self, emit:&mut dyn FnMut(EnergyFrame)->Result<()>) -> Result<()> {
        if let Some(frame)=self.current.take() {
            let samples=frame.samples.ok_or(Error::InvalidInput("missing audio sample count"))?;
            let channels=frame.channels.into_iter().map(|c|{
                if !c.nans||!c.infs{return Err(Error::InvalidInput("missing audio finiteness metric"));}
                let energy=ChannelEnergy{rms_dbfs:c.rms.ok_or(Error::InvalidInput("missing RMS metric"))?,
                    peak_dbfs:c.peak.ok_or(Error::InvalidInput("missing peak metric"))?};
                energy.validate()?;Ok(energy)
            }).collect::<Result<Vec<_>>>()?;
            emit(EnergyFrame{pts:frame.pts,samples,channels})?;
        }
        Ok(())
    }
    pub fn finish(mut self, emit:&mut dyn FnMut(EnergyFrame)->Result<()>) -> Result<()> {
        if self.failed{return Err(Error::InvalidInput("failed audio metrics cannot be finalized"));}
        // This fixed FFmpeg protocol always terminates records with a newline.
        // A cut-off numeric value must not be accepted as a smaller sample count.
        if !self.line.is_empty() {return Err(Error::InvalidInput("unterminated audio metric record"));}
        self.flush(emit)?;
        if self.next_frame==0{return Err(Error::InvalidInput("empty audio metrics"));}
        Ok(())
    }
}
fn zero(s:&str)->bool{s.parse::<f64>().is_ok_and(|n|n==0.0)}
fn parse_db(s:&str)->Result<Option<f64>>{
    if s=="-inf"{return Ok(None);}
    let value=s.parse::<f64>().map_err(|_|Error::InvalidInput("audio decibel value"))?;
    if !value.is_finite()||!(-1000.0..=120.0).contains(&value){return Err(Error::InvalidInput("audio decibel range"));}
    Ok(Some(value))
}
