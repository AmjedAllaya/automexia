//! Explicit transcription on the existing extension job/lifetime owners.
use crate::extension::emit;
use crate::host::{MediaHost, ProgressSink};
use crate::model_pack::{ModelActivation, ModelIdentity};
use crate::progress::Stage;
use crate::project::Project;
use crate::speech::{SpeechAudioFrame, SpeechMediaRuntime};
use crate::speech_workflow::{SpeechAudioHost, SpeechScan};
use crate::transcript::{RecognizedWord, Transcript, TranscriptProvenance, TranscriptSettings, MAX_TRANSCRIPT_SECONDS};
use crate::{Cancellation, Error, Rational, Result, VideoExtension};
use std::{path::PathBuf,time::{Duration,Instant}};

pub const TRANSCRIPT_ACTIONS: &[crate::extension::ActionDescriptor] = &[
    crate::extension::ActionDescriptor { id:"video.transcript.analyze",label:"Transcribe with an explicitly selected local model",writes_output:false },
    crate::extension::ActionDescriptor { id:"video.transcript.apply",label:"Install editable transcript observations",writes_output:false },
    crate::extension::ActionDescriptor { id:"video.transcript.fillers",label:"Propose reviewed filler words for removal",writes_output:false },
];

#[derive(Debug,Clone)]
pub struct TranscriptRequest {
    pub project_file:PathBuf,
    pub settings:TranscriptSettings,
    pub timeout:Duration,
}
impl TranscriptRequest {
    pub fn new(project_file:impl Into<PathBuf>)->Self {
        Self { project_file:project_file.into(),settings:TranscriptSettings::default(),timeout:Duration::from_secs(1800) }
    }
}
#[derive(Debug,Clone)]
pub struct Recognition { pub language:String,pub words:Vec<RecognizedWord> }

/// Selected providers consume bounded, immutable 16 kHz mono PCM. They must return
/// source-audio-relative word estimates and explicitly fail unsupported contracts.
pub trait TranscriptProvider:Send+Sync {
    fn identity(&self)->&ModelIdentity;
    fn revalidate(&self,cancel:&Cancellation)->Result<()>;
    fn recognize(&self,samples:&[i16],language:&str,timeout:Duration,cancel:&Cancellation)->Result<Recognition>;
}
#[derive(Debug,Clone)]
pub struct TranscriptReport {
    transcript:Transcript,
    project_digest:String,
    activation:ModelActivation,
    owner:Cancellation,
}
impl TranscriptReport {
    pub fn transcript(&self)->&Transcript { &self.transcript }
    pub fn apply(&self,project:&mut Project)->Result<()> {
        self.owner.check()?; self.activation.check()?;
        if project.decision_digest()?!=self.project_digest {return Err(Error::StaleReview);}
        project.set_transcript(self.transcript.clone())
    }
}

impl<H:MediaHost+SpeechAudioHost> VideoExtension<H> {
    pub fn transcribe(&self,project:&Project,request:&TranscriptRequest,provider:&dyn TranscriptProvider,
        activation:&ModelActivation,cancel:&Cancellation,progress:&mut ProgressSink<'_>)->Result<TranscriptReport> {
        project.validate()?;request.settings.validate()?;crate::voice_render::validate_timeout(request.timeout)?;
        if project.sources.len()!=1 {return Err(Error::Unsupported("transcription currently requires one source"));}
        let source=&project.sources[0];
        if source.duration>Rational::new(MAX_TRANSCRIPT_SECONDS,1)? {return Err(Error::LimitExceeded("transcription is bounded to 30 minutes per source"));}
        activation.check()?;
        let provider_identity=checked_provider(||Ok(provider.identity().clone()))?;
        provider_identity.validate()?;
        if &provider_identity!=activation.identity(){return Err(Error::InputChanged);}
        if provider_identity.contract!=crate::model_pack::WHISPER_CONTRACT
            || provider_identity.preprocessing!=crate::model_pack::WHISPER_PROCESSING {
            return Err(Error::Unsupported("selected transcription contract"));
        }
        // An applied report outlives this request; it does not borrow the short job token.
        let scope=activation.scope(cancel)?;let owner=self.workflow_scope(&scope)?;
        let operation=self.workflow_operation(&owner)?;
        let job=self.begin(&operation.cancel)?;
        let started=Instant::now();let total=request.timeout;
        let cancel=job.cancel.with_deadline(started.checked_add(total).ok_or(Error::InvalidInput("transcript deadline"))?);
        let identity=project.decision_digest()?;
        checked_provider(||provider.revalidate(&cancel))?;
        let path=source.resolve(&request.project_file)?;
        let input=self.host().inspect_input(&path,&cancel)?;source.check_input(&input)?;
        let current=self.probe_path(&input.canonical_path,&cancel,progress)?;source.check_media(&current)?;
        let capabilities=self.host().runtime_capabilities(&cancel)?;
        let runtime=SpeechMediaRuntime::capture(&capabilities)?;
        let scan=SpeechScan::from_project(project,input.clone(),request.settings.analysis_channel,remaining(started,total)?)?;
        scan.check_runtime(&capabilities)?;
        let resolution=source.media.audio.as_ref().and_then(|a|a.time_base);
        let mut pcm=TranscriptPcm::new(source.timeline_origin,source.duration,resolution)?;
        emit(progress,Stage::AnalyzingSpeech)?;
        cancel.check()?;
        self.host().stream_speech_audio(&scan,&cancel,&mut |frame| {
            cancel.check()?;remaining(started,total)?;pcm.push(frame)
        })?;
        let pcm=pcm.finish()?;
        emit(progress,Stage::LoadingModel)?;
        cancel.check()?;
        checked_provider(||provider.revalidate(&cancel))?;
        emit(progress,Stage::Transcribing)?;
        cancel.check()?;
        let recognition=checked_provider(||provider.recognize(&pcm.samples,&request.settings.language,remaining(started,total)?,&cancel))?;
        cancel.check()?;remaining(started,total)?;activation.check()?;
        checked_provider(||provider.revalidate(&cancel))?;
        if checked_provider(||Ok(provider.identity().clone()))?!=provider_identity {return Err(Error::InputChanged);}
        self.host().revalidate_input(&input,&cancel)?;
        if SpeechMediaRuntime::capture(&self.host().runtime_capabilities(&cancel)?)?!=runtime {
            return Err(Error::ToolIdentityChanged);
        }
        let provenance=TranscriptProvenance {model:provider_identity,settings:request.settings.clone(),
            ffmpeg_sha256:runtime.ffmpeg_sha256,ffprobe_sha256:runtime.ffprobe_sha256,recognized_language:recognition.language,
            audio_start:pcm.start,audio_samples:pcm.samples.len() as u64,timestamp_repairs:pcm.repairs,clipped_samples:pcm.clipped};
        let transcript=Transcript::from_observations(project,&source.id,provenance,recognition.words)?;
        remaining(started,total)?;cancel.check()?;
        Ok(TranscriptReport {transcript,project_digest:identity,activation:activation.clone(),owner})
    }
}
fn checked_provider<T>(call:impl FnOnce()->Result<T>)->Result<T> {
    std::panic::catch_unwind(std::panic::AssertUnwindSafe(call)).map_err(|_|Error::CallbackPanicked)?
}
fn remaining(started:Instant,total:Duration)->Result<Duration> {
    let result=total.saturating_sub(started.elapsed());if result.is_zero(){Err(Error::Timeout)}else{Ok(result)}
}

/// A known coarse source clock can round packet PTS by at most one source tick.
/// Retain every PCM sample unchanged and compare to the cumulative sample clock;
/// this never accumulates drift or fills gaps. Repairs are persisted as uncertainty.
struct TranscriptPcm {
    origin:Rational,duration:Rational,tolerance:i64,first:Option<i64>,last_pts:Option<i64>,samples:Vec<i16>,repairs:u64,clipped:u64,failed:bool,
}
struct FinishedPcm {samples:Vec<i16>,start:Rational,repairs:u64,clipped:u64}
impl TranscriptPcm {
    fn new(origin:Rational,duration:Rational,resolution:Option<Rational>)->Result<Self> {
        let tolerance=match resolution {Some(t) if t.positive()&&t<=Rational::new(1,1000)?=>t.ceil_units(16000)?.checked_add(1).ok_or(Error::LimitExceeded("transcript timestamp tolerance"))?,_=>0};
        Ok(Self{origin,duration,tolerance,first:None,last_pts:None,samples:vec![],repairs:0,clipped:0,failed:false})
    }
    fn push(&mut self,frame:SpeechAudioFrame)->Result<()> {
        if self.failed {return Err(Error::InvalidOutput("failed transcript PCM"));}
        let result=self.push_inner(frame);if result.is_err(){self.failed=true;}result
    }
    fn push_inner(&mut self,frame:SpeechAudioFrame)->Result<()> {
        if frame.samples.is_empty()||frame.samples.len()>crate::speech_pipe::MAX_DECODE_SAMPLES {return Err(Error::LimitExceeded("transcript PCM frame size"));}
        let source_start=self.origin.ceil_units(16000)?;
        let source_end=self.origin.checked_add(self.duration)?.ceil_units(16000)?;
        if frame.pts<source_start||frame.pts>=source_end {return Err(Error::InvalidOutput("transcript PCM outside source"));}
        let first=*self.first.get_or_insert(frame.pts);
        let expected=first.checked_add(self.samples.len() as i64).ok_or(Error::LimitExceeded("transcript sample clock"))?;
        let delta=frame.pts.checked_sub(expected).ok_or(Error::LimitExceeded("transcript packet clock"))?;
        if self.last_pts.is_some_and(|old|frame.pts<=old)||(delta<0&&delta.unsigned_abs()>=frame.samples.len() as u64) {
            return Err(Error::InvalidOutput("duplicated or wholly overlapping transcript PCM packet"));
        }
        if delta.unsigned_abs()>self.tolerance as u64 {return Err(Error::Unsupported("transcription requires continuous selected audio; gaps/overlaps need explicit segmentation"));}
        if delta!=0 {self.repairs+=1;}
        let final_len=self.samples.len().checked_add(frame.samples.len()).ok_or(Error::LimitExceeded("transcript PCM count"))?;
        if final_len>MAX_TRANSCRIPT_SECONDS as usize*16000 {return Err(Error::LimitExceeded("transcript PCM samples"));}
        if first.checked_add(final_len as i64).ok_or(Error::LimitExceeded("transcript sample clock"))?>source_end {
            return Err(Error::InvalidOutput("transcript PCM exceeds source duration"));
        }
        for sample in frame.samples {
            if !sample.is_finite()||sample.abs()>8.0 {return Err(Error::InvalidOutput("transcript PCM nonfinite/out of range"));}
            if sample.abs()>1.0 {self.clipped+=1;}
            let pcm=(f64::from(sample)*32768.0).round().clamp(-32768.0,32767.0) as i16;
            self.samples.push(pcm);
        }
        self.last_pts=Some(frame.pts);
        Ok(())
    }
    fn finish(self)->Result<FinishedPcm> {
        if self.failed||self.samples.is_empty(){return Err(Error::InvalidOutput("transcription decoded no complete audio"));}
        let first=self.first.ok_or(Error::InvalidOutput("transcript first sample"))?;
        Ok(FinishedPcm{samples:self.samples,start:Rational::new(first,16000)?.checked_sub(self.origin)?,repairs:self.repairs,clipped:self.clipped})
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    fn pcm()->TranscriptPcm {TranscriptPcm::new(Rational::new(5,1).unwrap(),Rational::new(1,1).unwrap(),None).unwrap()}
    #[test] fn original_offset_is_retained(){let mut p=pcm();p.push(SpeechAudioFrame{pts:80800,samples:vec![0.5;32]}).unwrap();let p=p.finish().unwrap();assert_eq!(p.start,Rational::new(1,20).unwrap());assert_eq!(p.samples,vec![16384;32]);}
    #[test] fn gaps_are_never_silence_filled(){let mut p=pcm();p.push(SpeechAudioFrame{pts:80000,samples:vec![0.0;32]}).unwrap();assert!(p.push(SpeechAudioFrame{pts:80100,samples:vec![0.0;32]}).is_err());assert!(p.finish().is_err());}
    #[test] fn duplicate_samples_fail(){let mut p=pcm();p.push(SpeechAudioFrame{pts:80000,samples:vec![0.0;32]}).unwrap();assert!(p.push(SpeechAudioFrame{pts:80000,samples:vec![0.0;32]}).is_err());}
    #[test] fn nonfinite_pcm_fails(){let mut p=pcm();assert!(p.push(SpeechAudioFrame{pts:80000,samples:vec![f32::NAN]}).is_err());}
    #[test] fn known_tick_rounding_is_counted(){let mut p=TranscriptPcm::new(Rational::new(0,1).unwrap(),Rational::new(1,1).unwrap(),Some(Rational::new(1,1000).unwrap())).unwrap();p.push(SpeechAudioFrame{pts:0,samples:vec![0.0;31]}).unwrap();p.push(SpeechAudioFrame{pts:32,samples:vec![0.0;31]}).unwrap();assert_eq!(p.finish().unwrap().repairs,1);}
    #[test] fn coarse_unknown_timestamp_rounding_fails(){let mut p=TranscriptPcm::new(Rational::new(0,1).unwrap(),Rational::new(1,1).unwrap(),Some(Rational::new(1,100).unwrap())).unwrap();p.push(SpeechAudioFrame{pts:0,samples:vec![0.0;31]}).unwrap();assert!(p.push(SpeechAudioFrame{pts:32,samples:vec![0.0;31]}).is_err());}
    #[test] fn packet_clock_rounding_cannot_accumulate(){let mut p=TranscriptPcm::new(Rational::new(0,1).unwrap(),Rational::new(1,1).unwrap(),Some(Rational::new(1,1000).unwrap())).unwrap();p.push(SpeechAudioFrame{pts:0,samples:vec![0.0;31]}).unwrap();p.push(SpeechAudioFrame{pts:40,samples:vec![0.0;31]}).unwrap();assert!(p.push(SpeechAudioFrame{pts:90,samples:vec![0.0;31]}).is_err());}
    #[test] fn coarse_clock_does_not_accept_a_replayed_short_packet(){let mut p=TranscriptPcm::new(Rational::new(0,1).unwrap(),Rational::new(1,1).unwrap(),Some(Rational::new(1,1000).unwrap())).unwrap();p.push(SpeechAudioFrame{pts:0,samples:vec![0.0;10]}).unwrap();assert!(p.push(SpeechAudioFrame{pts:0,samples:vec![0.0;10]}).is_err());}
    #[test] fn clips_are_visible_in_provenance(){let mut p=pcm();p.push(SpeechAudioFrame{pts:80000,samples:vec![2.0,-2.0]}).unwrap();let p=p.finish().unwrap();assert_eq!(p.clipped,2);assert_eq!(p.samples,vec![32767,-32768]);}
}
