//! Step 6: saved, reversible shot-level color decisions. No I/O or model access.
//! Technical correction is deliberately constant within a shot: aggregate evidence
//! cannot create per-frame exposure pumping. New non-identity proposals need review.
use crate::{Error, Rational, Result};
use crate::media::StreamInfo;
use crate::project::{Disposition, Project, TimeRange};
use serde::{Deserialize, Serialize};
use std::collections::BTreeSet;

pub const COLOR_VERSION: u32 = 1;
pub const MAX_COLOR_SHOTS: usize = 128;
pub const MAX_VIDEO_FRAMES: u64 = 3_456_000;
pub const MAX_ANALYSIS_SECONDS: u32 = 14_400;

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all="snake_case")]
pub enum ColorMode { Off, Auto, Manual }
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all="snake_case")]
pub enum CreativeLook { None, Warm, Film, HighContrast }

/// A user-confirmed neutral patch in DISPLAY-oriented normalized coordinates.
/// This is not face/object tracking. It must remain a neutral patch in each shot;
/// heterogeneous, dark, clipped or strongly colored patches are not used by Auto.
#[derive(Debug, Clone, Copy, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct NeutralReference { pub x:f64, pub y:f64, pub width:f64, pub height:f64 }
impl NeutralReference {
    pub fn validate(&self)->Result<()> {
        for v in [self.x,self.y,self.width,self.height] { finite(v,0.0,1.0)?; }
        if self.width<0.05 || self.height<0.05 || self.x+self.width>1.0 || self.y+self.height>1.0 {
            return Err(Error::InvalidInput("neutral reference rectangle"));
        } Ok(())
    }
}
#[derive(Debug, Clone, Copy, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct ColorAdjustment {
    /// Linear-light exposure (stops), not brightness added to gamma-encoded Y.
    pub exposure_ev:f64, pub gamma:f64, pub contrast:f64, pub saturation:f64,
    /// Linear-light, diagonal RGB gains. No cross-channel mixing or gamut change.
    pub white_balance:[f64;3],
}
impl Default for ColorAdjustment {
    fn default()->Self {Self{exposure_ev:0.0,gamma:1.0,contrast:1.0,saturation:1.0,white_balance:[1.0;3]}}
}
impl ColorAdjustment {
    pub fn validate(&self)->Result<()> {
        finite(self.exposure_ev,-1.0,1.0)?;
        finite(self.gamma,0.85,1.15)?; finite(self.contrast,0.85,1.15)?;
        finite(self.saturation,0.8,1.15)?;
        for v in self.white_balance {finite(v,0.8,1.2)?;}
        Ok(())
    }
    pub fn is_identity(&self)->bool { *self==Self::default() }
}
/// Required serialized fields: a saved project never adopts newly changed defaults.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct ColorSettings {
    pub exposure:ColorMode, pub gamma:ColorMode, pub contrast:ColorMode,
    pub saturation:ColorMode, pub white_balance:ColorMode,
    pub manual:ColorAdjustment, pub neutral_reference:Option<NeutralReference>,
    pub look:CreativeLook,
    pub scene_histogram_threshold:f64, pub scene_pixel_threshold:f64,
    pub min_correction_seconds:f64, pub max_auto_exposure_ev:f64,
    pub max_auto_gamma_delta:f64, pub max_auto_contrast_delta:f64,
    pub max_auto_saturation_delta:f64, pub max_auto_white_balance_delta:f64,
    pub max_analysis_seconds:u32, pub max_frames:u64, pub max_shots:usize,
    pub analysis_width:u32, pub analysis_height:u32,
}
impl Default for ColorSettings {
    fn default()->Self {Self{
        exposure:ColorMode::Auto,gamma:ColorMode::Auto,contrast:ColorMode::Auto,
        saturation:ColorMode::Auto,white_balance:ColorMode::Auto,
        manual:ColorAdjustment::default(),neutral_reference:None,look:CreativeLook::None,
        scene_histogram_threshold:0.30,scene_pixel_threshold:0.12,
        min_correction_seconds:0.4,max_auto_exposure_ev:0.25,
        max_auto_gamma_delta:0.04,max_auto_contrast_delta:0.04,
        max_auto_saturation_delta:0.03,max_auto_white_balance_delta:0.04,
        max_analysis_seconds:14_400,max_frames:MAX_VIDEO_FRAMES,max_shots:MAX_COLOR_SHOTS,
        analysis_width:192,analysis_height:108,
    }}
}
impl ColorSettings {
    pub fn off()->Self {Self{exposure:ColorMode::Off,gamma:ColorMode::Off,contrast:ColorMode::Off,
        saturation:ColorMode::Off,white_balance:ColorMode::Off,..Self::default()}}
    pub fn validate(&self)->Result<()> {
        self.manual.validate()?;
        if let Some(r)=self.neutral_reference {r.validate()?;}
        finite(self.scene_histogram_threshold,0.05,1.0)?;
        finite(self.scene_pixel_threshold,0.02,1.0)?;
        finite(self.min_correction_seconds,0.1,10.0)?;
        finite(self.max_auto_exposure_ev,0.0,0.5)?;
        for v in [self.max_auto_gamma_delta,self.max_auto_contrast_delta,
            self.max_auto_saturation_delta,self.max_auto_white_balance_delta] {finite(v,0.0,0.1)?;}
        if self.max_analysis_seconds==0 || self.max_analysis_seconds>MAX_ANALYSIS_SECONDS ||
            self.max_frames==0 || self.max_frames>MAX_VIDEO_FRAMES || self.max_shots==0 ||
            self.max_shots>MAX_COLOR_SHOTS || !(32..=320).contains(&self.analysis_width) ||
            !(32..=320).contains(&self.analysis_height) || self.analysis_width*self.analysis_height>57_600 {
            return Err(Error::InvalidInput("color analysis resource bounds"));
        } Ok(())
    }
}
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all="snake_case")]
pub enum BoundaryKind { SourceStart, DetectedCut, DeclaredCut }
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct ShotEvidence {
    pub frames:u64, pub flash_frames:u64, pub mean_luma:f64,
    pub linear_luma:f64, pub low_luma:f64, pub high_luma:f64,
    pub mean_saturation:f64, pub mean_motion:f64,
    pub bright_fraction:f64, pub dark_fraction:f64,
    pub rgb_max:[f64;3], pub rgb_min:[f64;3], pub luma_variation:f64,
    pub neutral_mean:Option<[f64;3]>, pub neutral_spread:Option<f64>,
}
impl ShotEvidence {
    pub fn validate(&self)->Result<()> {
        if self.frames==0 || self.frames>MAX_VIDEO_FRAMES || self.flash_frames>self.frames {
            return Err(Error::InvalidProject("color evidence frame count"));
        }
        for v in [self.mean_luma,self.linear_luma,self.low_luma,self.high_luma,self.mean_saturation,
            self.mean_motion,self.bright_fraction,self.dark_fraction,self.luma_variation] {finite(v,0.0,1.0)?;}
        if self.low_luma>self.high_luma {return Err(Error::InvalidProject("color quantiles"));}
        for v in self.rgb_max.into_iter().chain(self.rgb_min) {finite(v,0.0,1.0)?;}
        if (0..3).any(|i|self.rgb_min[i]>self.rgb_max[i]){return Err(Error::InvalidProject("color channel bounds"));}
        if self.neutral_mean.is_some()!=self.neutral_spread.is_some() {return Err(Error::InvalidProject("neutral evidence pairing"));}
        if let Some(rgb)=self.neutral_mean {for v in rgb {finite(v,0.0,1.0)?;}}
        if let Some(v)=self.neutral_spread {finite(v,0.0,1.0)?;}
        Ok(())
    }
}
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct ColorShot {
    pub id:String, pub range:TimeRange, pub boundary:BoundaryKind,
    pub evidence:ShotEvidence, pub adjustment:ColorAdjustment,
    pub disposition:Disposition, pub enabled:bool, pub locked:bool,
    pub user_override:bool, pub reason:String,
}
impl ColorShot {
    pub fn active(&self)->bool {self.enabled && self.disposition==Disposition::AutoApply && !self.adjustment.is_identity()}
}
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct ColorProfile {
    pub version:u32, pub source_id:String, pub source_sha256:String,
    pub stream_index:u32, pub duration:Rational, pub enabled:bool,
    pub settings:ColorSettings, pub shots:Vec<ColorShot>,
}
impl ColorProfile {
    pub fn validate(&self)->Result<()> {
        if self.version!=COLOR_VERSION || self.source_sha256.len()!=64 ||
            !self.source_sha256.bytes().all(|b|b.is_ascii_hexdigit()) {
            return Err(Error::InvalidProject("color profile version or fingerprint"));
        }
        crate::project::id_ok(&self.source_id)?; self.settings.validate()?;
        if !self.duration.positive() || self.duration>Rational::new(i64::from(self.settings.max_analysis_seconds),1)? ||
            self.shots.is_empty() || self.shots.len()>self.settings.max_shots {
            return Err(Error::LimitExceeded("color profile duration or shots"));
        }
        let mut end=Rational::new(0,1)?; let mut ids=BTreeSet::new(); let mut frames=0u64;
        for (i,s) in self.shots.iter().enumerate() {
            crate::project::id_ok(&s.id)?; crate::project::text_ok(&s.reason,1024)?;
            s.range.validate()?; s.evidence.validate()?; s.adjustment.validate()?;
            if !ids.insert(&s.id) || s.range.start!=end ||
                (i==0)!=(s.boundary==BoundaryKind::SourceStart) {return Err(Error::InvalidProject("color shot order/coverage"));}
            end=s.range.end; frames=frames.checked_add(s.evidence.frames).ok_or(Error::LimitExceeded("color frame count"))?;
        }
        if end!=self.duration || frames>self.settings.max_frames {return Err(Error::InvalidProject("color coverage or frame count"));}
        Ok(())
    }
    pub fn check_source(&self,project:&Project)->Result<()> {
        self.validate()?;
        if project.sources.len()!=1 {return Err(Error::Unsupported("color correction is single-source"));}
        let source=&project.sources[0];
        if self.source_id!=source.id || self.source_sha256!=source.fingerprint.sha256 ||
            self.stream_index!=source.media.video.index || self.duration!=source.duration {
            return Err(Error::InvalidProject("color profile belongs to another source"));
        }
        qualify_sdr(&source.media.video)?;
        Ok(())
    }
    pub fn ensure_resolved(&self)->Result<()> {
        if self.enabled && self.shots.iter().any(|s|s.enabled && s.disposition==Disposition::NeedsReview) {
            return Err(Error::UnresolvedEdits);
        } Ok(())
    }
    pub fn active_count(&self)->usize {if self.enabled {self.shots.iter().filter(|s|s.active()).count()} else {0}}
}
#[derive(Debug, Clone, Serialize)]
pub struct ColorReport {
    binding:String, profile:ColorProfile,
    pub decoded_frames:u64, pub analysis_width:u32, pub analysis_height:u32,
    pub warnings:Vec<String>,
}
impl ColorReport {
    pub(crate) fn new(project:&Project,profile:ColorProfile,frames:u64,width:u32,height:u32)->Result<Self> {
        profile.check_source(project)?;
        Ok(Self{binding:project.decision_digest()?,profile,decoded_frames:frames,analysis_width:width,analysis_height:height,
            warnings:vec![
                "Scene boundaries are low-resolution signal observations, not semantic scene recognition.".into(),
                "Corrections are constant within each shot; lighting changes are not followed with per-frame gain.".into(),
                "All non-identity proposals require review. Saturated, clipped, unstable or uncertain shots are preserved by Auto.".into(),
                "Automatic white balance requires a user-confirmed neutral patch. No global gray-world or face inference is used.".into(),
                "Downsampled clipping statistics cannot certify that every full-resolution pixel has headroom.".into(),
            ]})
    }
    pub fn profile(&self)->&ColorProfile {&self.profile}
    pub fn apply(&self,project:&mut Project)->Result<()> {
        if project.decision_digest()?!=self.binding {return Err(Error::StaleReview);}
        let mut profile=self.profile.clone();
        if let Some(old)=&project.settings.color_correction {
            profile.enabled=old.enabled; // Rescanning must not undo an explicit bypass.
            // Reuse identities only for the same exact source interval. New
            // intervals must not steal an ordinal identity retained by a lock.
            for candidate in &mut profile.shots {
                if let Some(previous)=old.shots.iter().find(|s|s.range==candidate.range){candidate.id=previous.id.clone();}
                else {use sha2::Digest;let digest=format!("{:x}",sha2::Sha256::digest(format!("{}:{}",candidate.range.start,candidate.range.end).as_bytes()));candidate.id=format!("shot-{}",&digest[..32]);}
            }
            // Do not erase reviewed/locked decisions if a rescan repartitions a
            // shot. Require an explicit reset instead of guessing ownership.
            for previous in old.shots.iter().filter(|s|s.locked||s.user_override) {
                let candidate=profile.shots.iter_mut().find(|s|s.range==previous.range)
                    .ok_or(Error::InvalidProject("rescan changes a reviewed shot; explicitly reset or preserve its boundaries"))?;
                *candidate=previous.clone();
            }
        }
        project.edit(|p|{p.settings.color_correction=Some(profile);Ok(())})
    }
}
#[derive(Debug, Clone)]
pub enum ColorDecision { Approve, Reject, Enable(bool), Lock(bool), Adjust(ColorAdjustment) }
impl Project {
    pub fn decide_color(&mut self,id:&str,decision:ColorDecision)->Result<()> {
        self.edit(|p|{
            let profile=p.settings.color_correction.as_mut().ok_or(Error::InvalidProject("no color profile"))?;
            let shot=profile.shots.iter_mut().find(|s|s.id==id).ok_or(Error::InvalidProject("unknown color shot"))?;
            if shot.locked && !matches!(decision,ColorDecision::Lock(false)) {return Err(Error::LockedEdit);}
            match decision {
                ColorDecision::Approve=>{shot.disposition=Disposition::AutoApply;shot.enabled=true;},
                ColorDecision::Reject=>{shot.disposition=Disposition::Ignore;shot.enabled=false;},
                ColorDecision::Enable(v)=>shot.enabled=v,
                ColorDecision::Lock(v)=>shot.locked=v,
                ColorDecision::Adjust(v)=>{v.validate()?;shot.adjustment=v;shot.disposition=Disposition::NeedsReview;},
            }
            shot.user_override=true; Ok(())
        })
    }
    pub fn enable_color(&mut self,enabled:bool)->Result<()> {
        self.edit(|p|{p.settings.color_correction.as_mut().ok_or(Error::InvalidProject("no color profile"))?.enabled=enabled;Ok(())})
    }
    /// Explicitly forget color decisions, including locks. This is an intentional
    /// reset, never called by automatic recomputation. Media/cut decisions remain.
    pub fn clear_color(&mut self)->Result<()> {self.edit(|p|{p.settings.color_correction=None;Ok(())})}
}

/// The only qualified color-processing path in this edition is progressive,
/// explicitly tagged Rec.709, 8-bit SDR. Copying HDR metadata is not HDR support.
pub fn qualify_sdr(v:&StreamInfo)->Result<()> {
    if v.kind!="video" || v.is_attached_picture() ||
        !matches!(v.pixel_format.as_deref(),Some("yuv420p"|"yuv422p"|"yuv444p"|"yuvj420p"|"yuvj422p"|"yuvj444p"|"nv12")) ||
        v.bits_per_raw_sample.is_some_and(|b|b>8) {return Err(Error::Unsupported("color processing requires 8-bit YUV SDR without alpha"));}
    if v.color_space.as_deref()!=Some("bt709") || v.color_transfer.as_deref()!=Some("bt709") ||
        v.color_primaries.as_deref()!=Some("bt709") || !matches!(v.color_range.as_deref(),Some("tv"|"pc")) {
        return Err(Error::Unsupported("color correction requires explicit Rec.709 matrix/transfer/primaries and range"));
    }
    if v.field_order.as_deref()!=Some("progressive") {return Err(Error::Unsupported("color correction requires progressive footage; no implicit deinterlace"));}
    if v.side_data.iter().any(|s| s.get("side_data_type").and_then(serde_json::Value::as_str)
        .is_some_and(|t|t.contains("DOVI")||t.contains("Dolby")||t.contains("Mastering display")||t.contains("Content light")||t.contains("HDR"))) {
        return Err(Error::Unsupported("HDR or Dolby Vision color operations are not qualified"));
    }
    v.rotation_degrees()?; Ok(())
}
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize)]
#[serde(rename_all="snake_case")]
pub enum VideoOperation { AnalyzeColor, ColorCorrection, Trim, AudioOnly, Concatenate, Crop, Scale, Overlay }
#[derive(Debug, Clone, Serialize)]
pub struct OperationSupport {pub operation:VideoOperation,pub supported:bool,pub reason:&'static str}
/// Static operation hints, not permission or complete runtime qualification.
/// HDR preservation additionally requires a complete project/packet/frame proof;
/// audio-only planning validates its selected audio independently of pixels.
pub fn operation_support(v:&StreamInfo,operation:VideoOperation)->OperationSupport {
    if matches!(operation,VideoOperation::AudioOnly){return OperationSupport{operation,supported:v.kind=="video",reason:"Use the separate audio-only planner; selected audio, source identity and reviewed decisions are validated without requiring an SDR video transcode."};}
    let qualified=qualify_sdr(v).is_ok();
    OperationSupport{operation,supported:qualified,reason:if !qualified {
        "This stream has no qualified SDR transformation path. HEVC PQ/HLG preservation and bounded keyframe trims use the separate HDR workflow with packet, pixel and metadata verification; HDR transforms remain unsupported."
    }else{"Supported within the progressive Rec.709 8-bit profile, reviewed framing/presentation settings and existing one-source timeline; the operation still checks its runtime and geometry limits."}}
}

pub(crate) fn finite(v:f64,min:f64,max:f64)->Result<()> {
    if !v.is_finite() || v<min || v>max {Err(Error::InvalidInput("nonfinite or out-of-range color value"))} else {Ok(())}
}
