//! Optional typed native decoding on the existing host worker. One decode emits
//! display-oriented RGB plus exact PTS; the pure analyzer consumes it once.
use crate::observation_cache::{self,ObservationCache,Observation,AnalysisKind,CacheUse,CachedAnalysis};
use crate::{Cancellation,Error,Rational,Result,VideoExtension};
use crate::color::{ColorSettings,ColorReport,qualify_sdr};
use crate::color_analysis::SceneAnalyzer;
use crate::host::{InputFile,MediaHost,ProgressSink,RuntimeCapabilities,words};
use crate::extension::emit;
use crate::progress::{Progress,Stage};
use crate::project::Project;
use std::{ffi::OsString,path::PathBuf,time::Duration};

pub const VIDEO_SCAN_PREFIX:&[&str]=&["-hide_banner","-loglevel","info","-nostdin","-xerror","-max_alloc","268435456","-copyts","-threads","2","-protocol_whitelist","file","-format_whitelist","mov,matroska,webm","-i"];
pub const VIDEO_SCAN_FILTER:&str="showinfo@amx_source=checksum=0,scale=w={width}:h={height}:flags=area:in_color_matrix=bt709:in_range={range}:out_range=pc,format=rgb24,setsar=1,settb=expr={time_base},showinfo@amx_rgb=checksum=0";

#[derive(Debug,Clone)]
pub struct VideoScan {
    input:InputFile,stream:u32,width:u32,height:u32,time_base:Rational,
    full_range:bool,timeout:Duration,max_frames:u64,
}
impl VideoScan {
    pub fn new(project:&Project,input:InputFile,settings:&ColorSettings,timeout:Duration)->Result<Self> {
        project.validate()?;settings.validate()?;validate_timeout(timeout)?;
        if project.sources.len()!=1{return Err(Error::Unsupported("video analysis is single-source"));}
        let s=&project.sources[0];s.check_input(&input)?;let v=&s.media.video;qualify_sdr(v)?;
        if s.duration>Rational::new(i64::from(settings.max_analysis_seconds),1)?{return Err(Error::LimitExceeded("analysis duration"));}
        let w=v.width.ok_or(Error::InvalidProject("video width"))?;
        let h=v.height.ok_or(Error::InvalidProject("video height"))?;
        if w==0||h==0||w>16384||h>16384||u64::from(w)*u64::from(h)>67_108_864{return Err(Error::LimitExceeded("source dimensions"));}
        let sar=v.sample_aspect_ratio.unwrap_or(Rational::new(1,1)?);
        if !sar.positive()||sar.as_f64()<0.01||sar.as_f64()>100.0{return Err(Error::InvalidProject("sample aspect ratio"));}
        let display_aspect=if v.rotation_degrees()?%180==0 {f64::from(w)*sar.as_f64()/f64::from(h)}else{f64::from(h)/(f64::from(w)*sar.as_f64())};
        let (native_w,native_h)=if v.rotation_degrees()?%180==0{(w,h)}else{(h,w)};
        let width=f64::from(settings.analysis_width.min(native_w)).min(f64::from(settings.analysis_height.min(native_h))*display_aspect).floor().max(1.0) as u32;
        let height=(f64::from(width)/display_aspect).round().max(1.0).min(f64::from(settings.analysis_height.min(native_h))) as u32;
        // A full pass retains every input frame; there is no fps/thumbnail sampler.
        Ok(Self{input,stream:v.index,width,height,time_base:v.time_base.ok_or(Error::InvalidProject("source time base"))?,
            full_range:v.color_range.as_deref()==Some("pc"),timeout,max_frames:settings.max_frames})
    }
    pub fn input(&self)->&InputFile{&self.input}
    pub fn dimensions(&self)->(u32,u32){(self.width,self.height)}
    pub fn time_base(&self)->Rational{self.time_base}
    pub fn max_frames(&self)->u64{self.max_frames}
    pub fn full_range(&self)->bool{self.full_range}
    pub fn timeout(&self)->Duration{self.timeout}
    pub fn arguments(&self)->Result<Vec<OsString>> {
        let filter=VIDEO_SCAN_FILTER.replace("{width}",&self.width.to_string()).replace("{height}",&self.height.to_string())
            .replace("{time_base}",&self.time_base.to_string()).replace("{range}",if self.full_range{"pc"}else{"tv"});
        let mut a=words(VIDEO_SCAN_PREFIX);a.push(self.input.canonical_path.as_os_str().to_owned());
        a.extend(words(&["-map",&format!("0:{}",self.stream),"-an","-sn","-dn","-filter_threads","1","-vf",&filter,
            "-fps_mode:v","passthrough","-enc_time_base:v","demux","-c:v","rawvideo","-threads:v","1","-pix_fmt","rgb24","-flush_packets","1","-f","rawvideo","pipe:1"]));
        Ok(a)
    }
    pub fn check_runtime(&self,c:&RuntimeCapabilities)->Result<()> {
        for f in ["scale","format","setsar","settb","showinfo"] {
            if !c.filters.contains(f){return Err(Error::MissingCapability("RGB video analysis filters"));}
        }
        if !c.encoders.contains("rawvideo")||!c.muxers.contains("rawvideo")||!c.supports_demux_time_base {
            return Err(Error::MissingCapability("timestamp-preserving raw video analysis"));
        }Ok(())
    }
}
#[derive(Debug,Clone)]
pub struct ColorAnalysisRequest {
    pub project_file:PathBuf,pub settings:ColorSettings,pub timeout:Duration,
    /// Exact, ordered source-relative PTS already known to be hard cuts.
    pub known_boundaries:Vec<Rational>,
}
impl ColorAnalysisRequest {
    pub fn new(project_file:impl Into<PathBuf>)->Self{Self{project_file:project_file.into(),settings:ColorSettings::default(),timeout:Duration::from_secs(7200),known_boundaries:vec![]}}
    fn validate(&self)->Result<()> {
        self.settings.validate()?;validate_timeout(self.timeout)?;
        crate::preview::local_absolute(&self.project_file)?;
        if !self.project_file.extension().and_then(|s|s.to_str()).is_some_and(|s|s.eq_ignore_ascii_case("amxv")){
            return Err(Error::InvalidInput("video analysis requires an .amxv location"));
        }Ok(())
    }
}
impl<H:MediaHost> VideoExtension<H> {
    pub fn analyze_color(&self,project:&Project,request:&ColorAnalysisRequest,cancel:&Cancellation,progress:&mut ProgressSink<'_>)->Result<ColorReport> {
        self.analyze_color_inner(project,request,None,cancel,progress).map(|v|v.report)
    }
    pub fn analyze_color_cached(&self,project:&Project,request:&ColorAnalysisRequest,cache:&mut ObservationCache,cancel:&Cancellation,progress:&mut ProgressSink<'_>)->Result<CachedAnalysis<ColorReport>> {
        self.analyze_color_inner(project,request,Some(cache),cancel,progress)
    }
    fn analyze_color_inner(&self,project:&Project,request:&ColorAnalysisRequest,mut cache:Option<&mut ObservationCache>,cancel:&Cancellation,progress:&mut ProgressSink<'_>)->Result<CachedAnalysis<ColorReport>> {
        if let Some(c)=cache.as_mut(){c.live()?;}

        project.validate()?;request.validate()?;
        let job=self.begin(cancel)?;let deadline=std::time::Instant::now().checked_add(request.timeout).ok_or(Error::InvalidInput("analysis deadline"))?;let operation_cancel=job.cancel.with_deadline(deadline);let source=&project.sources[0];qualify_sdr(&source.media.video)?;
        emit(progress,Stage::Inspecting)?;
        let input=self.host().inspect_input(&source.resolve(&request.project_file)?,&operation_cancel)?;source.check_input(&input)?;
        emit(progress,Stage::RuntimeCheck)?;let runtime=self.host().runtime_capabilities(&operation_cancel)?;
        let current=self.probe_path(&input.canonical_path,&operation_cancel,progress)?;source.check_media(&current)?;
        qualify_sdr(current.stream(source.media.video.index)?)?;
        let scan=VideoScan::new(project,input.clone(),&request.settings,request.timeout)?;scan.check_runtime(&runtime)?;
        let key=if cache.is_some(){observation_cache::key(project,&input,&runtime,AnalysisKind::ColorV1,&request.settings,&request.known_boundaries)?}else{None};
        if let (Some(c),Some(k))=(cache.as_mut(),key.as_ref()) {
            if let Some(Observation::Color(observation))=c.get(k)? {
                self.host().revalidate_input(&input,&operation_cancel)?;operation_cancel.check()?;
                let report=observation.report(project,&request.settings)?;c.live()?;operation_cancel.check()?;
                return Ok(CachedAnalysis{report,cache:CacheUse::Hit});
            }
        }

        let (width,height)=scan.dimensions();
        let mut analyzer=SceneAnalyzer::new(project,request.settings.clone(),width,height,request.known_boundaries.clone())?;
        emit(progress,Stage::AnalyzingVideo)?;let mut last_second=-1i64;
        self.host().stream_video_frames(&scan,&operation_cancel,&mut |frame| {
            operation_cancel.check()?;
            let elapsed=frame.pts.checked_sub(source.timeline_origin)?;
            analyzer.push(frame,&operation_cancel)?;
            let second=elapsed.floor_units(1)?;
            if second>last_second {
                let mut event=Progress::stage(Stage::AnalyzingVideo);
                event.out_time_us=Some(u64::try_from(elapsed.max(Rational::new(0,1)?).ceil_units(1_000_000)?).map_err(|_|Error::LimitExceeded("video progress time"))?);
                std::panic::catch_unwind(std::panic::AssertUnwindSafe(||progress(event))).map_err(|_|Error::CallbackPanicked)?;
                last_second=second;
            }Ok(())
        })?;
        self.host().revalidate_input(&input,&operation_cancel)?;operation_cancel.check()?;
        let report=analyzer.finish(&operation_cancel)?;
        let cache_use=match (cache.as_mut(),key) {
            (Some(c),Some(k))=>c.put(k,&source.fingerprint.sha256,Observation::Color(observation_cache::ColorObservation::from_report(&report)))?,
            (Some(_),None)=>CacheUse::UnpinnedRuntime,(None,_)=>CacheUse::Disabled,
        };
        operation_cancel.check()?;Ok(CachedAnalysis{report,cache:cache_use})
    }
}
fn validate_timeout(t:Duration)->Result<()> {if t.is_zero()||t>Duration::from_secs(86400){Err(Error::InvalidInput("video analysis timeout"))}else{Ok(())}}
