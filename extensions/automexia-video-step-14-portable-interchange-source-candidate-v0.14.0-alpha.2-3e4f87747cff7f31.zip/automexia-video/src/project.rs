//! Editable `.amxv` decisions. No filesystem, process, UI or model authority.
//!
//! One chronological source is rendered in Step 2. The schema keeps source and
//! variant identities explicit so later multi-source/composition work need not
//! reinterpret timestamps. Every interval is half-open, [start, end), in exact
//! seconds relative to the first selected video presentation timestamp.
use crate::{Error, Result, Rational};
use crate::host::{FileStamp, InputFile, RuntimeCapabilities};
use crate::media::{AudioSelection, MediaInfo, SelectedStreams, StreamInfo, StreamSelection, VideoSelection};
use crate::plan::{FrameRateMode, RenderOptions, SpeedPreset};
use serde::{Deserialize, Serialize};
use serde_json::Value;
use sha2::{Digest, Sha256};
use std::{collections::BTreeSet, path::{Component, Path, PathBuf}};

pub const PROJECT_FORMAT: &str = "automexia-video";
pub const PROJECT_VERSION: u32 = 10;
pub const MAX_PROJECT_BYTES: usize = 4 * 1024 * 1024;
pub const MAX_CLIPS: usize = 512;
pub const MAX_OPERATIONS: usize = 1024;
pub const MAX_RENDER_SEGMENTS: usize = 128;
pub const MAX_SOURCES: usize = 16;
pub const MAX_VARIANTS: usize = 16;
pub const MAX_HISTORY: usize = 64;

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct TimeRange { pub start: Rational, pub end: Rational }
impl TimeRange {
    pub fn new(start: Rational, end: Rational) -> Result<Self> {
        let r = Self { start, end }; r.validate()?; Ok(r)
    }
    pub fn validate(&self) -> Result<()> {
        if self.start.numerator() < 0 || self.start >= self.end {
            return Err(Error::InvalidProject("range must be nonnegative and nonempty"));
        }
        Ok(())
    }
    pub fn duration(&self) -> Result<Rational> { self.end.checked_sub(self.start) }
    pub fn contains(&self, time: Rational) -> bool { time >= self.start && time < self.end }
    pub fn overlaps(&self, other: &Self) -> bool { self.start < other.end && other.start < self.end }
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct ContentFingerprint { pub size: u64, pub sha256: String }
impl ContentFingerprint {
    pub fn from_stamp(stamp: &FileStamp) -> Result<Self> {
        let result = Self { size: stamp.size, sha256: stamp.sha256.clone() }; result.validate()?; Ok(result)
    }
    fn validate(&self) -> Result<()> {
        if self.size == 0 || self.sha256.len() != 64 || !self.sha256.bytes().all(|b|b.is_ascii_digit() || (b'a'..=b'f').contains(&b)) {
            return Err(Error::InvalidProject("invalid content fingerprint"));
        }
        Ok(())
    }
    pub fn matches(&self, input: &InputFile) -> bool { self.size == input.stamp.size && self.sha256 == input.stamp.sha256 }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct SourceMedia {
    pub format_names: Vec<String>,
    pub container_start: Option<Rational>,
    pub container_duration: Option<Rational>,
    pub video: StreamInfo,
    pub audio: Option<StreamInfo>,
}
impl SourceMedia {
    pub fn as_media_info(&self) -> MediaInfo {
        let mut streams = vec![self.video.clone()];
        if let Some(audio) = &self.audio { streams.push(audio.clone()); }
        MediaInfo { format_names: self.format_names.clone(), start_time: self.container_start,
            duration: self.container_duration, streams, head_packets: vec![], tags: Default::default(), raw: Value::Null }
    }
    pub fn selected(&self) -> SelectedStreams { SelectedStreams {video:self.video.index, audio:self.audio.as_ref().map(|s|s.index)} }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct ProjectSource {
    pub id: String,
    /// Relative paths are resolved against the project directory, never CWD.
    /// These references are not file-access grants; the host validates access.
    pub path: PathBuf,
    pub fingerprint: ContentFingerprint,
    pub media: SourceMedia,
    pub timeline_origin: Rational,
    pub duration: Rational,
}
impl ProjectSource {
    pub fn from_probe(id: &str, input: &InputFile, info: &MediaInfo, selected: SelectedStreams, project_file: &Path) -> Result<Self> {
        id_ok(id)?;
        if !input.canonical_path.is_absolute() || !project_file.is_absolute() { return Err(Error::InvalidProject("absolute source and project location required")); }
        let mut video = info.stream(selected.video)?.clone();
        if video.kind != "video" || video.is_attached_picture() { return Err(Error::InvalidProject("selected video")); }
        let audio = selected.audio.map(|i|info.stream(i).cloned()).transpose()?;
        if audio.as_ref().is_some_and(|s|s.kind != "audio") { return Err(Error::InvalidProject("selected audio")); }
        let origin = video.exact_start().or(info.start_time).ok_or(Error::InvalidProject("source video start is unknown"))?;
        // A container duration can include a longer audio track. It must not be
        // substituted for an absent video duration without explicit qualification.
        let duration = video.exact_duration().ok_or(Error::Unsupported("editable projects require a known video duration"))?;
        let path = relative_reference(&input.canonical_path, project_file)?;
        // Descriptive/location tags and sampled packets are not edit decisions.
        // The legacy rotate tag is display geometry, not descriptive metadata.
        video.tags.retain(|key,_| key == "rotate");
        let audio = audio.map(|mut s| { s.tags.clear(); s });
        let source = Self { id:id.into(), path, fingerprint:ContentFingerprint::from_stamp(&input.stamp)?,
            media:SourceMedia {format_names:info.format_names.clone(), container_start:info.start_time, container_duration:info.duration,video,audio},
            timeline_origin:origin, duration };
        source.validate()?; Ok(source)
    }
    pub fn resolve(&self, project_file: &Path) -> Result<PathBuf> {
        path_ok(&self.path)?;
        if !project_file.is_absolute() { return Err(Error::InvalidProject("absolute project location required")); }
        Ok(if self.path.is_absolute() {self.path.clone()} else { project_file.parent().ok_or(Error::InvalidProject("project directory"))?.join(&self.path) })
    }
    pub fn check_input(&self, input: &InputFile) -> Result<()> {
        if !self.fingerprint.matches(input) { Err(Error::InputChanged) } else { Ok(()) }
    }
    pub fn check_media(&self, current: &MediaInfo) -> Result<()> {
        let v = current.stream(self.media.video.index)?;
        if v.kind != "video" || v.time_base != self.media.video.time_base || v.exact_start().or(current.start_time) != Some(self.timeline_origin)
            || v.exact_duration() != Some(self.duration) || v.width != self.media.video.width || v.height != self.media.video.height
            || v.rotation_degrees()? != self.media.video.rotation_degrees()? || v.sample_aspect_ratio != self.media.video.sample_aspect_ratio
            || v.codec != self.media.video.codec || v.pixel_format != self.media.video.pixel_format
            || v.nominal_frame_rate != self.media.video.nominal_frame_rate || v.average_frame_rate != self.media.video.average_frame_rate
            || v.bits_per_raw_sample != self.media.video.bits_per_raw_sample || v.field_order != self.media.video.field_order
            || v.color_range != self.media.video.color_range || v.color_space != self.media.video.color_space
            || v.color_transfer != self.media.video.color_transfer || v.color_primaries != self.media.video.color_primaries {
            return Err(Error::InvalidProject("source timing or geometry differs from the saved project"));
        }
        if let Some(old) = &self.media.audio {
            let new = current.stream(old.index)?;
            if new.kind != "audio" || new.time_base != old.time_base || new.sample_rate != old.sample_rate || new.channels != old.channels || new.channel_layout != old.channel_layout
                || new.exact_start() != old.exact_start() || new.exact_duration() != old.exact_duration() || new.codec != old.codec { return Err(Error::InvalidProject("selected audio differs from the saved project")); }
        }
        Ok(())
    }
    fn validate(&self) -> Result<()> {
        id_ok(&self.id)?; path_ok(&self.path)?; self.fingerprint.validate()?;
        if !self.duration.positive() || self.duration > Rational::new(604800,1)? { return Err(Error::InvalidProject("source duration")); }
        if self.media.video.kind != "video" || self.media.video.is_attached_picture() || self.media.video.exact_duration() != Some(self.duration)
            || self.media.video.exact_start().or(self.media.container_start) != Some(self.timeline_origin)
            || !self.media.video.time_base.is_some_and(|t|t.positive()) {return Err(Error::InvalidProject("source timing metadata"));}
        for stream in std::iter::once(&self.media.video).chain(self.media.audio.iter()) {
            if let Some(tb)=stream.time_base {
                if !tb.positive(){return Err(Error::InvalidProject("nonpositive stream time base"));}
                if let Some(pts)=stream.start_pts{tb.ticks(pts)?;}
                if let Some(ticks)=stream.duration_ts{if ticks<0{return Err(Error::InvalidProject("negative stream duration"));}tb.ticks(ticks)?;}
            }
        }
        if self.media.audio.as_ref().is_some_and(|s|s.kind != "audio" || s.index == self.media.video.index) {return Err(Error::InvalidProject("audio source metadata"));}
        Ok(())
    }
}

/// Required fields: no serde defaults may silently adopt a changed future preset.
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct FrozenRenderSettings {
    pub frame_rate: FrameRateMode, pub crf: u8, pub speed: SpeedPreset, pub threads: u8,
}
impl FrozenRenderSettings {
    pub fn from_options(options: &RenderOptions) -> Result<Self> {
        options.validate()?; Ok(Self {frame_rate:options.frame_rate,crf:options.crf,speed:options.speed,threads:options.threads})
    }
    pub fn options(&self, selected:SelectedStreams) -> RenderOptions {
        RenderOptions {streams:StreamSelection {video:VideoSelection::Index(selected.video),audio:selected.audio.map(AudioSelection::Index).unwrap_or(AudioSelection::None)},
            frame_rate:self.frame_rate,crf:self.crf,speed:self.speed,threads:self.threads}
    }
}
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct ResolvedSettings {
    #[serde(default,skip_serializing_if="Option::is_none")]
    pub workflow: Option<crate::presets::WorkflowSnapshot>,
    pub preset_name: Option<String>, pub preset_revision: Option<String>, pub render: FrozenRenderSettings,
    #[serde(default, skip_serializing_if="Option::is_none")]
    pub pause_cleanup: Option<crate::pause::PauseSettings>,
    #[serde(default, skip_serializing_if="Option::is_none")]
    pub voice_cleanup: Option<crate::voice::VoiceCleanup>,
    #[serde(default, skip_serializing_if="Option::is_none")]
    pub voice_enhancement: Option<crate::enhancement::VoiceEnhancement>,
    #[serde(default, skip_serializing_if="Option::is_none")]
    pub color_correction: Option<crate::color::ColorProfile>,
}
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct OutputVariant {
    #[serde(default,skip_serializing_if="Option::is_none")]
    pub assembly:Option<crate::assembly::AssemblySettings>,
    #[serde(default,skip_serializing_if="Option::is_none")]
    pub timing:Option<crate::timing::TimingSettings>,
    #[serde(default,skip_serializing_if="Option::is_none")]
    pub output_profile:Option<crate::delivery::DeliveryProfile>,
    pub id:String, pub render:FrozenRenderSettings,
    #[serde(default,skip_serializing_if="Option::is_none")]
    pub framing:Option<crate::reframe::FramingSettings>,
    #[serde(default,skip_serializing_if="Option::is_none")]
    pub presentation:Option<crate::presentation::PresentationSettings>,
}
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct KeepClip { pub id:String, pub source_id:String, pub range:TimeRange, pub locked:bool }
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all="snake_case")]
pub enum Disposition { AutoApply, NeedsReview, Ignore }
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(tag="kind",rename_all="snake_case",deny_unknown_fields)]
pub enum EditOrigin { Manual, Generator {id:String,version:String} }
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all="snake_case")]
pub enum EditKind { RemoveRange, ProtectRange }
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct EditOperation {
    pub id:String, pub source_id:String, pub kind:EditKind, pub range:TimeRange,
    pub reason:String, pub origin:EditOrigin, pub disposition:Disposition,
    pub enabled:bool, pub locked:bool, pub user_override:bool,
}
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct RenderHistory {
    #[serde(default,skip_serializing_if="Option::is_none")]
    pub delivery_profile:Option<crate::delivery::DeliveryProfile>,
    pub project_revision:u64, pub decision_sha256:String, pub variant_id:String,
    pub runtime:RuntimeCapabilities, pub output:PathBuf, pub fully_decoded:bool,
}
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Project {
    #[serde(default,skip_serializing_if="Option::is_none")]
    pub transcript:Option<crate::transcript::Transcript>,
    pub format:String, pub schema_version:u32, pub id:String, pub revision:u64,
    pub sources:Vec<ProjectSource>, pub assembly:Vec<KeepClip>, pub operations:Vec<EditOperation>,
    pub settings:ResolvedSettings, pub variants:Vec<OutputVariant>, pub renders:Vec<RenderHistory>,
    pub next_id:u64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct TimelineSegment {pub source_id:String,pub source_range:TimeRange,pub output_range:TimeRange}
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Timeline {pub segments:Vec<TimelineSegment>,pub duration:Rational}
impl Timeline {
    /// During a dissolve, every overlapping source contributes to the output.
    pub fn output_to_sources(&self,time:Rational)->Result<Vec<(String,Rational)>> {
        let mut values=Vec::new();
        for s in &self.segments {
            if s.output_range.contains(time) {
                let offset=time.checked_sub(s.output_range.start)?.checked_mul(s.source_range.duration()?)?.checked_div(s.output_range.duration()?)?;
                values.push((s.source_id.clone(),s.source_range.start.checked_add(offset)?));
            }
        }
        Ok(values)
    }
    /// Compatibility helper returns the first contributor in authored order.
    pub fn output_to_source(&self,time:Rational)->Result<Option<(String,Rational)>> {
        Ok(self.output_to_sources(time)?.into_iter().next())
    }
    /// Every authored occurrence of a source instant, in authored order. Repeated
    /// footage can map to more than one output instant.
    pub fn source_to_outputs(&self,source_id:&str,time:Rational)->Result<Vec<Rational>> {
        let mut values=Vec::new();
        for s in &self.segments {
            if s.source_id==source_id && s.source_range.contains(time) {
                let offset=time.checked_sub(s.source_range.start)?.checked_mul(s.output_range.duration()?)?.checked_div(s.source_range.duration()?)?;
                values.push(s.output_range.start.checked_add(offset)?);
            }
        }
        Ok(values)
    }
    /// Compatibility helper returns the first authored output occurrence.
    pub fn source_to_output(&self,source_id:&str,time:Rational)->Result<Option<Rational>> {
        Ok(self.source_to_outputs(source_id,time)?.into_iter().next())
    }
}

impl Project {
    pub fn new(id:&str,source:ProjectSource,settings:ResolvedSettings)->Result<Self>{
        let range=TimeRange::new(Rational::new(0,1)?,source.duration)?;
        let p=Self {transcript:None,format:PROJECT_FORMAT.into(),schema_version:PROJECT_VERSION,id:id.into(),revision:1,
            assembly:vec![KeepClip{id:"clip-1".into(),source_id:source.id.clone(),range,locked:false}],sources:vec![source],
            operations:vec![],variants:vec![OutputVariant{ assembly:None,timing:None,output_profile:None,presentation:None,id:"main".into(),render:settings.render.clone(),framing:None}],settings,renders:vec![],next_id:2};
        p.validate()?;Ok(p)
    }
    pub fn timeline_for_variant(&self,id:&str)->Result<Timeline> {
        let variant=self.variant(id)?;
        let timeline=self.timeline()?;
        let timeline=match &variant.assembly{Some(assembly)=>assembly.apply(&timeline,&self.sources[0])?,None=>timeline};
        match &variant.timing {Some(timing)=>timing.apply(&timeline),None=>Ok(timeline)}
    }
    /// Replacing assembly is a new proposal; incoming approval/lock flags cannot
    /// bypass review or a lock on the previous assembly.
    pub fn set_assembly(&mut self,id:&str,mut assembly:Option<crate::assembly::AssemblySettings>)->Result<()> {
        self.edit(|p|{
            let variant=p.variants.iter_mut().find(|v|v.id==id).ok_or(Error::InvalidProject("unknown variant"))?;
            if variant.assembly.as_ref().is_some_and(|a|a.locked){return Err(Error::LockedEdit);}
            if let Some(value)=&mut assembly{value.validate()?;value.disposition=Disposition::NeedsReview;value.locked=false;}
            variant.assembly=assembly;Ok(())
        })
    }
    pub fn review_assembly(&mut self,id:&str,disposition:Disposition,enabled:bool)->Result<()> {
        self.edit(|p|{let a=p.variants.iter_mut().find(|v|v.id==id).and_then(|v|v.assembly.as_mut()).ok_or(Error::InvalidProject("variant assembly"))?;
            if a.locked{return Err(Error::LockedEdit);}a.disposition=disposition;a.enabled=enabled;Ok(())})
    }
    pub fn set_assembly_locked(&mut self,id:&str,locked:bool)->Result<()> {
        self.edit(|p|{p.variants.iter_mut().find(|v|v.id==id).and_then(|v|v.assembly.as_mut()).ok_or(Error::InvalidProject("variant assembly"))?.locked=locked;Ok(())})
    }
    fn edit_assembly(&mut self,id:&str,change:impl FnOnce(&mut crate::assembly::AssemblySettings)->Result<()>)->Result<()> {
        self.edit(|p|change(p.variants.iter_mut().find(|v|v.id==id).and_then(|v|v.assembly.as_mut()).ok_or(Error::InvalidProject("variant assembly"))?))
    }
    pub fn insert_assembly_clip(&mut self,id:&str,index:usize,clip:crate::assembly::AssemblyClip)->Result<()> {
        if self.variant(id)?.assembly.is_none(){
            if index!=0{return Err(Error::InvalidInput("first assembly insertion index must be zero"));}
            return self.set_assembly(id,Some(crate::assembly::AssemblySettings{clips:vec![clip],..Default::default()}));
        }
        self.edit_assembly(id,|a|a.insert_clip(index,clip))
    }
    pub fn append_assembly_clip(&mut self,id:&str,clip:crate::assembly::AssemblyClip)->Result<()> {
        let index=self.variant(id)?.assembly.as_ref().map_or(0,|a|a.clips.len());self.insert_assembly_clip(id,index,clip)
    }
    pub fn move_assembly_clip(&mut self,id:&str,clip_id:&str,final_index:usize)->Result<()> {self.edit_assembly(id,|a|a.move_clip(clip_id,final_index))}
    pub fn remove_assembly_clip(&mut self,id:&str,clip_id:&str)->Result<()> {self.edit_assembly(id,|a|a.remove_clip(clip_id))}
    pub fn repeat_assembly_clip(&mut self,id:&str,clip_id:&str,new_id:&str,index:usize)->Result<()> {self.edit_assembly(id,|a|a.repeat_clip(clip_id,new_id,index))}
    pub fn trim_assembly_clip(&mut self,id:&str,clip_id:&str,range:TimeRange)->Result<()> {self.edit_assembly(id,|a|a.trim_clip(clip_id,range))}
    pub fn set_assembly_clip_speed(&mut self,id:&str,clip_id:&str,speed:crate::timing::PlaybackSpeed)->Result<()> {self.edit_assembly(id,|a|a.set_clip_speed(clip_id,speed))}
    pub fn set_timing(&mut self,id:&str,mut timing:Option<crate::timing::TimingSettings>)->Result<()> {
        self.edit(|p|{
            let variant=p.variants.iter_mut().find(|v|v.id==id).ok_or(Error::InvalidProject("unknown variant"))?;
            if variant.timing.as_ref().is_some_and(|v|v.locked){return Err(Error::LockedEdit);}
            if let Some(value)=&mut timing{value.validate()?;value.disposition=Disposition::NeedsReview;value.locked=false;}
            variant.timing=timing;Ok(())
        })
    }
    pub fn review_timing(&mut self,id:&str,disposition:Disposition,enabled:bool)->Result<()> {
        self.edit(|p|{
            let t=p.variants.iter_mut().find(|v|v.id==id).and_then(|v|v.timing.as_mut()).ok_or(Error::InvalidProject("variant timing"))?;
            if t.locked{return Err(Error::LockedEdit);}t.disposition=disposition;t.enabled=enabled;Ok(())
        })
    }
    pub fn set_timing_locked(&mut self,id:&str,locked:bool)->Result<()> {
        self.edit(|p|{p.variants.iter_mut().find(|v|v.id==id).and_then(|v|v.timing.as_mut()).ok_or(Error::InvalidProject("variant timing"))?.locked=locked;Ok(())})
    }
    pub fn source(&self,id:&str)->Result<&ProjectSource>{self.sources.iter().find(|s|s.id==id).ok_or(Error::InvalidProject("unknown source identity"))}
    pub fn variant(&self,id:&str)->Result<&OutputVariant>{self.variants.iter().find(|v|v.id==id).ok_or(Error::InvalidProject("unknown output variant"))}
    pub fn validate(&self)->Result<()> {
        if self.format!=PROJECT_FORMAT {return Err(Error::InvalidProject("format identity"));}
        if self.schema_version!=PROJECT_VERSION {return Err(Error::UnsupportedProjectVersion(self.schema_version));}
        id_ok(&self.id)?;
        if self.revision==0 || self.next_id<2 {return Err(Error::InvalidProject("revision or identifier counter"));}
        if self.sources.is_empty() || self.sources.len()>MAX_SOURCES || self.assembly.is_empty() || self.assembly.len()>MAX_CLIPS
            || self.operations.len()>MAX_OPERATIONS || self.variants.is_empty() || self.variants.len()>MAX_VARIANTS || self.renders.len()>MAX_HISTORY {
            return Err(Error::LimitExceeded("project collection sizes"));
        }
        let mut ids=BTreeSet::new();
        for s in &self.sources {s.validate()?;if !ids.insert(s.id.clone()){return Err(Error::InvalidProject("duplicate source identity"));}}
        if let Some(transcript)=&self.transcript{transcript.validate(self)?;}
        ids.clear();
        let mut previous:Option<&KeepClip>=None;
        for clip in &self.assembly {
            id_ok(&clip.id)?;if !ids.insert(clip.id.clone()){return Err(Error::InvalidProject("duplicate clip identity"));}
            clip.range.validate()?;if clip.range.end>self.source(&clip.source_id)?.duration{return Err(Error::InvalidProject("clip exceeds source duration"));}
            if let Some(prev)=previous {if prev.source_id==clip.source_id && prev.range.end>clip.range.start{return Err(Error::InvalidProject("assembly must be chronological and nonoverlapping"));}}
            previous=Some(clip);
        }
        ids.clear();
        for op in &self.operations {
            id_ok(&op.id)?;if !ids.insert(op.id.clone()){return Err(Error::InvalidProject("duplicate operation identity"));}
            op.range.validate()?;if op.range.end>self.source(&op.source_id)?.duration{return Err(Error::InvalidProject("operation exceeds source duration"));}
            text_ok(&op.reason,1024)?;
            if let EditOrigin::Generator{id,version}=&op.origin{id_ok(id)?;text_ok(version,128)?;if version.is_empty(){return Err(Error::InvalidProject("generator version"));}}
            if op.kind==EditKind::ProtectRange && !matches!(op.origin,EditOrigin::Manual){return Err(Error::InvalidProject("only manual decisions may protect a range"));}
        }
        if let Some(color)=&self.settings.color_correction {color.check_source(self)?;}
        if let Some(settings)=&self.settings.pause_cleanup {settings.validate()?;}
        if let Some(enhancement)=&self.settings.voice_enhancement {
            if self.sources.len()!=1{return Err(Error::Unsupported("voice enhancement is single-source"));}
            enhancement.check_source(&self.sources[0])?;
        }
        if let Some(voice)=&self.settings.voice_cleanup {
            voice.validate()?;
            if self.sources.len()!=1 {return Err(Error::Unsupported("voice cleanup is single-source"));}
            let source=&self.sources[0];
            let audio=source.media.audio.as_ref().ok_or(Error::InvalidProject("voice cleanup without selected audio"))?;
            if voice.source_sha256!=source.fingerprint.sha256||voice.stream_index!=audio.index {
                return Err(Error::InvalidProject("voice cleanup belongs to another source or stream"));
            }
            if let Some(p)=&voice.preflight {
                if audio.sample_rate!=Some(p.sample_rate)||audio.channels.map(|n|n as usize)!=Some(p.channels.len())
                    ||p.samples_per_channel>u64::try_from(source.duration.ceil_units(i64::from(p.sample_rate))?).map_err(|_|Error::InvalidProject("voice sample count"))?.saturating_add(1) {
                    return Err(Error::InvalidProject("voice preflight channel/rate mismatch"));
                }
            }
        }
        for op in &self.operations {
            if let EditOrigin::Generator{id,version}=&op.origin {
                if id==crate::pause::PAUSE_GENERATOR && (version!=crate::pause::PAUSE_GENERATOR_VERSION || self.settings.pause_cleanup.is_none()) {
                    return Err(Error::InvalidProject("pause generator version or saved settings"));
                }
            }
        }
        if let Some(s)=&self.settings.preset_name{text_ok(s,128)?;}if let Some(s)=&self.settings.preset_revision{text_ok(s,128)?;}
        if let Some(w)=&self.settings.workflow{w.validate()?;}
        let selected=self.sources[0].media.selected();self.settings.render.options(selected).validate()?;
        ids.clear();for v in &self.variants {id_ok(&v.id)?;if !ids.insert(v.id.clone()){return Err(Error::InvalidProject("duplicate variant identity"));}v.render.options(selected).validate()?;if let Some(timing)=&v.timing{timing.validate()?;}if let Some(profile)=&v.output_profile{profile.validate()?;}if let Some(f)=&v.framing{self.check_framing(f)?;}if let Some(p)=&v.presentation{p.validate(self.sources[0].duration)?;}}
        for v in &self.variants {if let Some(assembly)=&v.assembly{
            if self.sources.len()!=1{return Err(Error::Unsupported("variant clip assembly requires one source"));}
            assembly.validate_for_source(&self.sources[0])?;
        }}
        for r in &self.renders {
            if let Some(p)=&r.delivery_profile{p.validate()?;}
            id_ok(&r.variant_id)?;path_ok(&r.output)?;
            if r.project_revision==0 || r.project_revision>self.revision || r.decision_sha256.len()!=64 || !r.decision_sha256.bytes().all(|b|b.is_ascii_hexdigit()) {return Err(Error::InvalidProject("render history"));}
        }
        // Also bound programmatically constructed objects, not only parsed JSON.
        if serde_json::to_vec(self).map_err(|_|Error::InvalidProject("JSON serialization"))?.len()>MAX_PROJECT_BYTES {return Err(Error::LimitExceeded("project bytes"));}
        Ok(())
    }
    pub fn to_json(&self)->Result<Vec<u8>>{
        self.validate()?;let mut bytes=serde_json::to_vec_pretty(self).map_err(|_|Error::InvalidProject("JSON serialization"))?;bytes.push(b'\n');
        if bytes.len()>MAX_PROJECT_BYTES{return Err(Error::LimitExceeded("project bytes"));}Ok(bytes)
    }
    pub fn from_json(bytes:&[u8])->Result<Self>{Self::from_json_with_migrations(bytes,&[])}
    pub fn from_json_with_migrations(bytes:&[u8],migrations:&[ProjectMigration])->Result<Self>{
        if bytes.len()>MAX_PROJECT_BYTES{return Err(Error::LimitExceeded("project bytes"));}
        // Deserialize through a duplicate-key rejecting value visitor before any
        // migration. Hand-edited files must never silently accept two decisions.
        let mut value=crate::project_json::parse_unique(bytes)?;
        let format=value.get("format").and_then(Value::as_str).ok_or(Error::InvalidProject("format identity"))?;
        if format!=PROJECT_FORMAT{return Err(Error::InvalidProject("format identity"));}
        let mut version=version_of(&value)?;
        if version>PROJECT_VERSION{return Err(Error::UnsupportedProjectVersion(version));}
        if version<10 && value.get("variants").and_then(Value::as_array).is_some_and(|rows|rows.iter().any(|v|v.get("assembly").is_some())) {
            return Err(Error::InvalidProject("old schema cannot contain schema 10 variant assembly, including null"));
        }
        if version<9 && value.get("variants").and_then(Value::as_array).is_some_and(|rows|rows.iter().any(|v|
            v.get("presentation").and_then(|p|p.get("captions")).and_then(|c|c.get("document")).and_then(|d|d.get("generated_words")).is_some())) {
            return Err(Error::InvalidProject("old schema cannot contain schema 9 generated caption word timing"));
        }
        if version<9 && (value.get("transcript").is_some() || value.get("variants").and_then(Value::as_array).is_some_and(|rows|rows.iter().any(|v|v.get("timing").is_some()))) {
            return Err(Error::InvalidProject("old schema cannot contain schema 9 transcript or timing fields"));
        }
        if version<4 && value.get("settings").and_then(|v|v.get("color_correction")).is_some() {
            return Err(Error::InvalidProject("old schema cannot contain schema 4 color decisions"));
        }
        if version<5 && value.get("variants").and_then(Value::as_array).is_some_and(|rows| rows.iter().any(|v|v.get("framing").is_some())) {
            return Err(Error::InvalidProject("old schema cannot contain schema 5 framing decisions"));
        }
        if version<6 && value.get("variants").and_then(Value::as_array).is_some_and(|rows|rows.iter().any(|v|v.get("presentation").is_some())){return Err(Error::InvalidProject("old schema cannot contain schema 6 presentation"));}
        if version<8 && value.get("settings").and_then(|s|s.get("voice_enhancement")).is_some(){return Err(Error::InvalidProject("old schema cannot contain schema 8 voice enhancement"));}
        if version<7 && (value.get("settings").and_then(|s|s.get("workflow")).is_some() || value.get("variants").and_then(Value::as_array).is_some_and(|v|v.iter().any(|v|v.get("output_profile").is_some())) || value.get("renders").and_then(Value::as_array).is_some_and(|v|v.iter().any(|v|v.get("delivery_profile").is_some()))) {return Err(Error::InvalidProject("old schema cannot contain schema 7 workflow/delivery fields"));}
        let mut steps=0;
        while version<PROJECT_VERSION {
            if version==9 {
                if migrations.iter().any(|m|m.from==9){return Err(Error::InvalidProject("schema 9 migration is built in"));}
                value["schema_version"]=serde_json::json!(10);version=10;steps+=1;continue;
            }
            if version==8 {
                if migrations.iter().any(|m|m.from==8){return Err(Error::InvalidProject("schema 8 migration is built in"));}
                value["schema_version"]=serde_json::json!(9);version=9;steps+=1;continue;
            }
            if version==7 {
                if migrations.iter().any(|m|m.from==7){return Err(Error::InvalidProject("schema 7 migration is built in"));}
                value["schema_version"]=serde_json::json!(8);version=8;steps+=1;continue;
            }
            if version==6 {
                if migrations.iter().any(|m|m.from==6){return Err(Error::InvalidProject("schema 6 migration is built in"));}
                value["schema_version"]=serde_json::json!(7);version=7;steps+=1;continue;
            }
            if version==1 {
                // This repository supplied schema 1. Its exact migration is
                // known: no pause-cleanup state, no new audio fades. Unknown
                // earlier formats still require an explicit custom migration.
                if migrations.iter().any(|m|m.from==1) {return Err(Error::InvalidProject("schema 1 migration is built in"));}
                if value.get("settings").and_then(|s|s.get("pause_cleanup")).is_some() {
                    return Err(Error::InvalidProject("schema 1 cannot contain schema 2 pause settings"));
                }
                value["schema_version"]=serde_json::json!(2);
                version=2;steps+=1;continue;
            }
            if version==2 {
                if migrations.iter().any(|m|m.from==2){return Err(Error::InvalidProject("schema 2 migration is built in"));}
                if value.get("settings").and_then(|s|s.get("voice_cleanup")).is_some(){
                    return Err(Error::InvalidProject("schema 2 cannot contain schema 3 voice settings"));
                }
                value["schema_version"]=serde_json::json!(3);version=3;steps+=1;continue;
            }
            if version==3 {
                if migrations.iter().any(|m|m.from==3){return Err(Error::InvalidProject("schema 3 migration is built in"));}
                value["schema_version"]=serde_json::json!(4);version=4;steps+=1;continue;
            }
            if version==5 {
                if migrations.iter().any(|m|m.from==5){return Err(Error::InvalidProject("schema 5 migration is built in"));}
                value["schema_version"]=serde_json::json!(6);version=6;steps+=1;continue;
            }
            if version==4 {
                if migrations.iter().any(|m|m.from==4){return Err(Error::InvalidProject("schema 4 migration is built in"));}
                value["schema_version"]=serde_json::json!(5);version=5;steps+=1;continue;
            }
            let choices:Vec<_>=migrations.iter().filter(|m|m.from==version).collect();
            if choices.len()!=1 {return Err(Error::UnsupportedProjectVersion(version));}
            let m=choices[0];if m.to<=version || m.to>PROJECT_VERSION || steps>=PROJECT_VERSION{return Err(Error::InvalidProject("migration chain"));}
            value=(m.transform)(value)?;
            if version_of(&value)?!=m.to || value.get("format").and_then(Value::as_str)!=Some(PROJECT_FORMAT){return Err(Error::InvalidProject("migration changed format or version incorrectly"));}
            if serde_json::to_vec(&value).map_err(|_|Error::InvalidProject("migration JSON"))?.len()>MAX_PROJECT_BYTES{return Err(Error::LimitExceeded("migrated project bytes"));}
            version=m.to;steps+=1;
        }
        let project:Self=serde_json::from_value(value).map_err(|_|Error::InvalidProject("unknown, missing or invalid project fields"))?;
        project.validate()?;Ok(project)
    }
    /// A local integrity identifier, never a signature or host permission.
    /// Render records are excluded so recording a render doesn't change edit intent.
    pub fn decision_digest(&self)->Result<String>{
        self.validate()?;let mut copy=self.clone();copy.renders.clear();
        let bytes=serde_json::to_vec(&copy).map_err(|_|Error::InvalidProject("decision serialization"))?;
        Ok(format!("{:x}",Sha256::digest(bytes)))
    }
    /// Draft projects can be saved with unresolved proposals. Rendering cannot
    /// apply them. Disabled/ignored proposals do not affect the timeline.
    pub fn timeline(&self)->Result<Timeline>{
        self.validate()?;
        if self.sources.len()!=1 || self.assembly.iter().any(|c|c.source_id!=self.sources[0].id){return Err(Error::Unsupported("Step 2 rendering is single-source"));}
        if self.operations.iter().any(|o|o.enabled && o.disposition==Disposition::NeedsReview){return Err(Error::UnresolvedEdits);}
        let mut ranges=Vec::new();
        let active:Vec<_>=self.operations.iter().filter(|o|o.enabled && o.disposition==Disposition::AutoApply).collect();
        // Normalize removal intervals once, not once per clip/protection pair.
        // This keeps dense user projects out of an O(clips * edits^2) loop.
        let protections=union_ranges(active.iter().filter(|o|o.kind==EditKind::ProtectRange).map(|o|o.range).collect());
        let manual=union_ranges(active.iter().filter(|o|o.kind==EditKind::RemoveRange && (matches!(o.origin,EditOrigin::Manual)||o.user_override)).map(|o|o.range).collect());
        let generated=union_ranges(active.iter().filter(|o|o.kind==EditKind::RemoveRange && matches!(o.origin,EditOrigin::Generator{..}) && !o.user_override).map(|o|o.range).collect());
        let mut combined=manual.clone();for cut in generated {combined.extend(subtract_sorted(cut,&protections));}
        let all_cuts=union_ranges(combined);
        for clip in &self.assembly {
            let cuts=if clip.locked{&manual}else{&all_cuts};
            for part in subtract_sorted(clip.range,cuts) {ranges.push((clip.source_id.clone(),part));}
        }
        let mut merged:Vec<(String,TimeRange)>=Vec::new();
        for (id,range) in ranges {
            if let Some((last_id,last))=merged.last_mut(){if *last_id==id && last.end==range.start{last.end=range.end;continue;}}
            merged.push((id,range));
        }
        if merged.is_empty(){return Err(Error::EmptyTimeline);}
        if merged.len()>MAX_RENDER_SEGMENTS{return Err(Error::LimitExceeded("render segments"));}
        let mut cursor=Rational::new(0,1)?;let mut segments=Vec::new();
        for (source_id,source_range) in merged {
            let end=cursor.checked_add(source_range.duration()?)?;
            segments.push(TimelineSegment{source_id,source_range,output_range:TimeRange::new(cursor,end)?});cursor=end;
        }
        Ok(Timeline{segments,duration:cursor})
    }
    /// Replace manual keep ranges. It never sorts, clamps or deduplicates a
    /// caller's request. Out-of-order/overlapping input is a visible error.
    pub fn set_keep_ranges(&mut self,source_id:&str,ranges:&[TimeRange])->Result<()> {
        self.edit(|p|{
            p.source(source_id)?;
            if p.assembly.iter().any(|c|c.locked){return Err(Error::LockedEdit);}
            if ranges.is_empty()||ranges.len()>MAX_CLIPS{return Err(Error::InvalidProject("keep range count"));}
            let mut clips=Vec::new();for range in ranges{let id=p.fresh_id("clip")?;clips.push(KeepClip{id,source_id:source_id.into(),range:*range,locked:false});}p.assembly=clips;Ok(())
        })
    }
    pub fn trim_clip(&mut self,id:&str,range:TimeRange)->Result<()> {
        self.edit(|p|{let c=p.assembly.iter_mut().find(|c|c.id==id).ok_or(Error::InvalidProject("unknown clip"))?;if c.locked{return Err(Error::LockedEdit);}c.range=range;Ok(())})
    }
    pub fn split_clip(&mut self,id:&str,at:Rational)->Result<String>{
        let mut created=String::new();
        self.edit(|p|{
            let i=p.assembly.iter().position(|c|c.id==id).ok_or(Error::InvalidProject("unknown clip"))?;
            let original=p.assembly[i].clone();if original.locked{return Err(Error::LockedEdit);}
            if at<=original.range.start||at>=original.range.end{return Err(Error::InvalidProject("split must be strictly inside the clip"));}
            let new_id=p.fresh_id("clip")?;p.assembly[i].range.end=at;
            p.assembly.insert(i+1,KeepClip{id:new_id.clone(),source_id:original.source_id,range:TimeRange::new(at,original.range.end)?,locked:false});created=new_id;Ok(())
        })?;Ok(created)
    }
    pub fn set_clip_locked(&mut self,id:&str,locked:bool)->Result<()> {self.edit(|p|{p.assembly.iter_mut().find(|c|c.id==id).ok_or(Error::InvalidProject("unknown clip"))?.locked=locked;Ok(())})}
    pub fn add_operation(&mut self,operation:EditOperation)->Result<()> {self.edit(|p|{if p.operations.iter().any(|o|o.id==operation.id){return Err(Error::InvalidProject("duplicate operation identity"));}p.operations.push(operation);Ok(())})}
    pub fn remove_range(&mut self,source_id:&str,range:TimeRange,reason:&str)->Result<String>{self.manual_operation(source_id,range,reason,EditKind::RemoveRange)}
    pub fn protect_range(&mut self,source_id:&str,range:TimeRange,reason:&str)->Result<String>{self.manual_operation(source_id,range,reason,EditKind::ProtectRange)}
    fn manual_operation(&mut self,source_id:&str,range:TimeRange,reason:&str,kind:EditKind)->Result<String>{
        let mut created=String::new();self.edit(|p|{let id=p.fresh_id("edit")?;p.operations.push(EditOperation{id:id.clone(),source_id:source_id.into(),kind,range,reason:reason.into(),origin:EditOrigin::Manual,disposition:Disposition::AutoApply,enabled:true,locked:false,user_override:true});created=id;Ok(())})?;Ok(created)
    }
    /// One explicit review decision, committed transactionally in one revision.
    pub fn review_operation(&mut self,id:&str,disposition:Disposition,enabled:bool)->Result<()> {
        self.edit(|p|{let o=p.operation_mut(id)?;if o.locked{return Err(Error::LockedEdit);}o.disposition=disposition;o.enabled=enabled;o.user_override=true;Ok(())})
    }
    pub fn set_operation_enabled(&mut self,id:&str,enabled:bool)->Result<()> {self.edit(|p|{let o=p.operation_mut(id)?;if o.locked{return Err(Error::LockedEdit);}o.enabled=enabled;o.user_override=true;Ok(())})}
    pub fn set_operation_locked(&mut self,id:&str,locked:bool)->Result<()> {self.edit(|p|{p.operation_mut(id)?.locked=locked;Ok(())})}
    pub fn resolve_operation(&mut self,id:&str,disposition:Disposition)->Result<()> {self.edit(|p|{let o=p.operation_mut(id)?;if o.locked{return Err(Error::LockedEdit);}o.disposition=disposition;o.user_override=true;Ok(())})}
    pub fn change_operation_range(&mut self,id:&str,range:TimeRange)->Result<()> {self.edit(|p|{let o=p.operation_mut(id)?;if o.locked{return Err(Error::LockedEdit);}o.range=range;o.disposition=Disposition::NeedsReview;o.user_override=true;Ok(())})}
    fn operation_mut(&mut self,id:&str)->Result<&mut EditOperation>{self.operations.iter_mut().find(|o|o.id==id).ok_or(Error::InvalidProject("unknown edit identity"))}
    /// Recompute a single generator transactionally. Manual choices and locked
    /// operations survive even if the generator omits or changes their IDs.
    /// New generated proposals always start pending; callers cannot self-approve.
    pub fn replace_generated(&mut self,generator:&str,version:&str,mut proposals:Vec<EditOperation>)->Result<()> {
        id_ok(generator)?;text_ok(version,128)?;if version.is_empty(){return Err(Error::InvalidProject("generator version"));}
        let mut ids=BTreeSet::new();for o in &proposals {if !ids.insert(o.id.clone())||o.kind!=EditKind::RemoveRange{return Err(Error::InvalidProject("generator proposals"));}}
        self.edit(|p|{
            let mut retained:Vec<_>=p.operations.iter().filter(|o|o.locked||o.user_override||!matches!(&o.origin,EditOrigin::Generator{id,..} if id==generator)).cloned().collect();
            for mut o in proposals.drain(..) {
                // A manual or locked identity wins. A foreign generator collision
                // is an error, rather than a silent rewrite of another owner.
                if let Some(old)=retained.iter().find(|old|old.id==o.id){
                    if old.locked||old.user_override||matches!(old.origin,EditOrigin::Manual){continue;}
                    return Err(Error::InvalidProject("edit identity belongs to another generator"));
                }
                o.origin=EditOrigin::Generator{id:generator.into(),version:version.into()};o.disposition=Disposition::NeedsReview;o.enabled=true;o.locked=false;o.user_override=false;retained.push(o);
            }
            p.operations=retained;Ok(())
        })
    }
    /// Host has already inspected this explicitly chosen path. Equal bytes may
    /// be relinked despite a different inode, modification date or mount point.
    pub fn relink(&mut self,source_id:&str,input:&InputFile,project_file:&Path)->Result<()> {
        self.edit(|p|{let source=p.sources.iter_mut().find(|s|s.id==source_id).ok_or(Error::InvalidProject("unknown source"))?;source.check_input(input)?;source.path=relative_reference(&input.canonical_path,project_file)?;Ok(())})
    }
    pub fn rebase_paths(&mut self,old_project:&Path,new_project:&Path)->Result<()> {
        self.edit(|p|{for source in &mut p.sources{source.path=relative_reference(&source.resolve(old_project)?,new_project)?;}for v in &mut p.variants{if let Some(presentation)=&mut v.presentation{presentation.rebase_assets(old_project,new_project)?;}}if let Some(enhancement)=&mut p.settings.voice_enhancement{enhancement.rebase(old_project,new_project)?;}Ok(())})
    }
    pub fn set_variant_settings(&mut self,id:&str,settings:FrozenRenderSettings)->Result<()> {
        self.edit(|p|{p.variants.iter_mut().find(|v|v.id==id).ok_or(Error::InvalidProject("unknown variant"))?.render=settings;Ok(())})
    }
    pub fn record_render(&mut self,record:RenderHistory)->Result<()> {
        // History does not modify the edit revision or any decision.
        self.validate()?;let mut draft=self.clone();draft.renders.push(record);if draft.renders.len()>MAX_HISTORY{draft.renders.remove(0);}draft.validate()?;*self=draft;Ok(())
    }
    /// Explicit acceptance/change of audio treatment. None restores the previous
    /// no-treatment render path. Project revision and preview identity advance.
    pub fn set_voice_cleanup(&mut self,cleanup:Option<crate::voice::VoiceCleanup>)->Result<()> {
        self.edit(|p|{p.settings.voice_cleanup=cleanup;Ok(())})
    }
    pub fn set_voice_enhancement(&mut self,enhancement:Option<crate::enhancement::VoiceEnhancement>)->Result<()> {
        self.edit(|p|{p.settings.voice_enhancement=enhancement;Ok(())})
    }
    fn fresh_id(&mut self,prefix:&str)->Result<String>{
        loop {let n=self.next_id;self.next_id=n.checked_add(1).ok_or(Error::LimitExceeded("project identifiers"))?;let id=format!("{prefix}-{n}");
            if !self.assembly.iter().any(|c|c.id==id)&&!self.operations.iter().any(|c|c.id==id){return Ok(id);}}
    }
    pub(crate) fn edit(&mut self,apply:impl FnOnce(&mut Self)->Result<()>)->Result<()> {
        self.validate()?;let mut draft=self.clone();apply(&mut draft)?;draft.revision=draft.revision.checked_add(1).ok_or(Error::LimitExceeded("project revision"))?;draft.validate()?;*self=draft;Ok(())
    }
}

/// Schema 1 has a known built-in migration to schema 2. Other older formats
/// need explicit host-approved migrations; future versions are never guessed.
pub struct ProjectMigration {pub from:u32,pub to:u32,pub transform:fn(Value)->Result<Value>}
fn version_of(v:&Value)->Result<u32>{v.get("schema_version").and_then(Value::as_u64).and_then(|n|u32::try_from(n).ok()).ok_or(Error::InvalidProject("schema version"))}
fn union_ranges(mut ranges:Vec<TimeRange>)->Vec<TimeRange>{
    ranges.sort_by(|a,b|a.start.cmp(&b.start).then(a.end.cmp(&b.end)));
    let mut result:Vec<TimeRange>=Vec::new();
    for range in ranges {if let Some(last)=result.last_mut(){if range.start<=last.end{last.end=last.end.max(range.end);continue;}}result.push(range);}result
}
fn subtract_sorted(range:TimeRange,cuts:&[TimeRange])->Vec<TimeRange>{
    let mut result=Vec::new();let mut cursor=range.start;
    for cut in cuts {
        if cut.end<=cursor{continue;}if cut.start>=range.end{break;}
        if cut.start>cursor{result.push(TimeRange{start:cursor,end:cut.start.min(range.end)});}
        cursor=cursor.max(cut.end);if cursor>=range.end{break;}
    }
    if cursor<range.end{result.push(TimeRange{start:cursor,end:range.end});}result
}
pub(crate) fn id_ok(s:&str)->Result<()>{if s.is_empty()||s.len()>64||!s.bytes().all(|b|b.is_ascii_alphanumeric()||b"-_.".contains(&b)){Err(Error::InvalidProject("identity syntax"))}else{Ok(())}}
pub(crate) fn text_ok(s:&str,max:usize)->Result<()>{if s.len()>max||s.chars().any(|c|c.is_control()){Err(Error::InvalidProject("bounded display text"))}else{Ok(())}}
fn path_ok(p:&Path)->Result<()>{
    let s=p.to_str().ok_or(Error::InvalidProject("project paths must be UTF-8"))?;
    if s.is_empty()||s.len()>4096||s.contains("://")||s.chars().any(|c|c.is_control())||p.components().any(|c|matches!(c,Component::ParentDir)) {return Err(Error::InvalidProject("local project path"));}Ok(())
}
pub(crate) fn relative_reference(source:&Path,project_file:&Path)->Result<PathBuf>{
    if !source.is_absolute()||!project_file.is_absolute(){return Err(Error::InvalidProject("absolute source and project paths required"));}
    let parent=project_file.parent().ok_or(Error::InvalidProject("project directory"))?;
    let p=source.strip_prefix(parent).ok().filter(|p|!p.as_os_str().is_empty()).unwrap_or(source).to_owned();path_ok(&p)?;Ok(p)
}
