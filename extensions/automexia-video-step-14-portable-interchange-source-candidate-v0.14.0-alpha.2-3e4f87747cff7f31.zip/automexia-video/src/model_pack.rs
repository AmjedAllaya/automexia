//! Explicit, immutable local model identities. This module does not install,
//! download, discover or execute a model. The existing component owner supplies
//! the selected bytes and keeps the activation token alive.
use crate::{Cancellation, Error, Result};
use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};
use std::{fmt, sync::Arc};
mod onnx_guard;
mod rnnoise_guard;
mod whisper_guard;
pub use rnnoise_guard::check_rnnoise_model;
pub use whisper_guard::check_whisper_ggml;
pub use onnx_guard::check_embedded_onnx;

pub const MODEL_MANIFEST_LIMIT: usize = 32 * 1024;
pub const MODEL_BYTES_LIMIT: usize = 32 * 1024 * 1024;
pub const WHISPER_BYTES_LIMIT: usize = 160 * 1024 * 1024;
pub const MODEL_NOTICES_LIMIT: usize = 256 * 1024;
pub const RNNOISE_CONTRACT: &str = "rnnoise-48k-frame480-v1";
pub const RNNOISE_PROCESSING: &str = "selected-layout-resample48k-delay480-v1";
pub const WHISPER_CONTRACT: &str = "whisper-cpp-ggml-tiny-base-v1";
pub const WHISPER_PROCESSING: &str = "explicit-channel-pcm16-16k-source-clock-v1";
pub fn model_bytes_limit(contract: &str) -> usize {
    if contract == WHISPER_CONTRACT { WHISPER_BYTES_LIMIT } else { MODEL_BYTES_LIMIT }
}
pub const SILERO_CONTRACT: &str = "silero-16k-512-context64-state2x1x128-v1";
pub const SPEECH_PROCESSING: &str = "explicit-channel-ffmpeg-resample16k-no-normalization-v1";
pub const YUNET_CONTRACT: &str = "yunet-face-bbox-v1";
pub const YUNET_PROCESSING: &str = "display-rgb-lowres-letterbox-v1";
pub const ULTRAFACE_CONTRACT: &str = "ultraface-bbox-v1";
pub const ULTRAFACE_PROCESSING: &str = "display-rgb-lowres-letterbox-v1";

fn supported_contract(contract:&str,preprocessing:&str)->bool{matches!((contract,preprocessing),(SILERO_CONTRACT,SPEECH_PROCESSING)|(YUNET_CONTRACT,YUNET_PROCESSING)|(ULTRAFACE_CONTRACT,ULTRAFACE_PROCESSING)|(RNNOISE_CONTRACT,RNNOISE_PROCESSING)|(WHISPER_CONTRACT,WHISPER_PROCESSING))}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct ModelRuntime {
    /// The adapter, actual runtime build and host-verified deployment artifact
    /// are different identities. None of these strings grants native execution.
    pub adapter: String,
    pub build_info_sha256: String,
    pub artifact_sha256: String,
}
impl ModelRuntime {
    pub fn validate(&self) -> Result<()> {
        token(&self.adapter, 96)?;
        hash(&self.build_info_sha256)?;
        hash(&self.artifact_sha256)
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct ModelManifest {
    pub schema: u32,
    pub id: String,
    pub revision: String,
    pub source_revision: String,
    pub contract: String,
    pub preprocessing: String,
    pub weights_sha256: String,
    pub weights_bytes: u64,
    pub runtime: ModelRuntime,
    pub code_license: String,
    pub weights_license: String,
    pub notices_sha256: String,
}
impl ModelManifest {
    pub fn from_json(bytes: &[u8]) -> Result<Self> {
        if bytes.is_empty() || bytes.len() > MODEL_MANIFEST_LIMIT {
            return Err(Error::LimitExceeded("model manifest bytes"));
        }
        let value = crate::project_json::parse_unique(bytes)
            .map_err(|_| Error::InvalidInput("invalid or duplicate model manifest JSON"))?;
        let value: Self = serde_json::from_value(value)
            .map_err(|_| Error::InvalidInput("model manifest fields"))?;
        value.validate()?;
        Ok(value)
    }
    pub fn validate(&self) -> Result<()> {
        if self.schema != 1 { return Err(Error::Unsupported("model manifest schema")); }
        token(&self.id, 96)?;
        token(&self.revision, 96)?;
        token(&self.source_revision, 128)?;
        if !supported_contract(&self.contract,&self.preprocessing) {
            return Err(Error::Unsupported("model or preprocessing contract"));
        }
        if self.weights_bytes == 0 || self.weights_bytes > model_bytes_limit(&self.contract) as u64 {
            return Err(Error::LimitExceeded("embedded model size"));
        }
        hash(&self.weights_sha256)?;
        hash(&self.notices_sha256)?;
        self.runtime.validate()?;
        text(&self.code_license, 256)?;
        text(&self.weights_license, 256)
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct ModelIdentity {
    pub id: String,
    pub revision: String,
    pub source_revision: String,
    pub manifest_sha256: String,
    pub weights_sha256: String,
    pub contract: String,
    pub preprocessing: String,
    pub runtime: ModelRuntime,
    pub notices_sha256: String,
}
impl ModelIdentity {
    pub fn validate(&self) -> Result<()> {
        token(&self.id, 96)?; token(&self.revision, 96)?; token(&self.source_revision, 128)?;
        hash(&self.manifest_sha256)?; hash(&self.weights_sha256)?; hash(&self.notices_sha256)?;
        self.runtime.validate()?;
        if !supported_contract(&self.contract,&self.preprocessing) {
            return Err(Error::Unsupported("model identity contract"));
        }
        Ok(())
    }
}

/// Verified bytes, not a signature or proof of publisher trust/license rights.
/// It is intentionally non-serializable: a project cannot supply a verified pack.
#[derive(Clone)]
pub struct VerifiedModelPack {
    manifest: ModelManifest,
    identity: ModelIdentity,
    weights: Arc<[u8]>,
    manifest_bytes: Arc<[u8]>,
    notices: Arc<[u8]>,
}
impl fmt::Debug for VerifiedModelPack {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("VerifiedModelPack").field("identity", &self.identity)
            .field("weights_bytes", &self.weights.len()).finish()
    }
}
impl VerifiedModelPack {
    /// `expected_manifest` must originate in the host's explicit reviewed pack
    /// selection, not be read back from the untrusted manifest itself.
    pub fn verify(manifest_bytes: &[u8], weights: Vec<u8>, notices: &[u8],
                  expected_manifest: &str, cancel: &Cancellation) -> Result<Self> {
        cancel.check()?; hash(expected_manifest)?;
        let manifest = ModelManifest::from_json(manifest_bytes)?;
        let manifest_sha256 = digest(manifest_bytes, cancel)?;
        if manifest_sha256 != expected_manifest { return Err(Error::InputChanged); }
        if weights.len() != manifest.weights_bytes as usize || weights.len() > model_bytes_limit(&manifest.contract) {
            return Err(Error::InvalidInput("model length differs from selected manifest"));
        }
        if notices.len() > MODEL_NOTICES_LIMIT || notices.is_empty() {
            return Err(Error::LimitExceeded("model notice bytes"));
        }
        if digest(&weights, cancel)? != manifest.weights_sha256 ||
           digest(notices, cancel)? != manifest.notices_sha256 {
            return Err(Error::InputChanged);
        }
        // A bounded structural guard, not a complete ONNX verifier. Rejects
        // external tensors, custom domains and embedded local functions.
        match manifest.contract.as_str() {
            RNNOISE_CONTRACT => check_rnnoise_model(&weights, cancel)?,
            WHISPER_CONTRACT => check_whisper_ggml(&weights, cancel)?,
            _ => check_embedded_onnx(&weights, cancel)?,
        }
        let identity = ModelIdentity {
            id: manifest.id.clone(), revision: manifest.revision.clone(),
            source_revision: manifest.source_revision.clone(), manifest_sha256,
            weights_sha256: manifest.weights_sha256.clone(), contract: manifest.contract.clone(),
            preprocessing: manifest.preprocessing.clone(), runtime: manifest.runtime.clone(),
            notices_sha256: manifest.notices_sha256.clone(),
        };
        Ok(Self { manifest, identity, weights: Arc::from(weights), manifest_bytes: Arc::from(manifest_bytes), notices: Arc::from(notices) })
    }
    pub fn identity(&self) -> &ModelIdentity { &self.identity }
    pub fn manifest(&self) -> &ModelManifest { &self.manifest }
    pub fn weights(&self) -> &[u8] { &self.weights }
    /// Original verified bytes, preserving the host-pinned manifest digest.
    pub fn manifest_bytes(&self) -> &[u8] { &self.manifest_bytes }
    pub fn notices(&self) -> &[u8] { &self.notices }
}

/// Explicit operation-scoped activation, independent of project serialization.
/// Revocation is monotonic and affects every clone and outstanding report.
#[derive(Debug, Clone)]
pub struct ModelActivation { identity: ModelIdentity, cancelled: Cancellation }
impl ModelActivation {
    pub fn selected(identity: ModelIdentity) -> Result<Self> {
        identity.validate()?;
        Ok(Self { identity, cancelled: Cancellation::new() })
    }
    pub fn identity(&self) -> &ModelIdentity { &self.identity }
    pub fn revoke(&self) { self.cancelled.cancel(); }
    pub fn check(&self) -> Result<()> { self.cancelled.check() }
    pub(crate) fn scope(&self, parent: &Cancellation) -> Result<Cancellation> {
        self.check()?; parent.linked(&self.cancelled)
    }
}

pub(crate) fn digest(bytes: &[u8], cancel: &Cancellation) -> Result<String> {
    let mut state = Sha256::new();
    for chunk in bytes.chunks(64 * 1024) { cancel.check()?; state.update(chunk); }
    cancel.check()?; Ok(format!("{:x}", state.finalize()))
}
pub(crate) fn hash(s: &str) -> Result<()> {
    if s.len() != 64 || !s.bytes().all(|b| b.is_ascii_digit() || (b'a'..=b'f').contains(&b)) {
        return Err(Error::InvalidInput("expected lowercase SHA-256"));
    } Ok(())
}
fn token(s: &str, max: usize) -> Result<()> {
    if s.is_empty() || s.len() > max || !s.bytes().all(|b| b.is_ascii_alphanumeric() || b"._+-".contains(&b)) {
        return Err(Error::InvalidInput("bounded model identity token"));
    } Ok(())
}
fn text(s: &str, max: usize) -> Result<()> {
    if s.trim().is_empty() || s.len() > max || s.chars().any(|c| c.is_control()) {
        return Err(Error::InvalidInput("bounded model license metadata"));
    } Ok(())
}
