//! Step 5: classical, local audio cleanup. All settings are explicit project
//! data. Energy/spectral observations are not a speech/music classifier.
use crate::{Cancellation, Error, Result};
use crate::pause::AudioContent;
use crate::project::Project;
use serde::{Deserialize, Serialize};

pub const VOICE_VERSION: u32 = 1;
pub const MAX_SCAN_SECONDS: u32 = 86_400;
pub const MAX_CHANNELS: usize = 8;

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all="snake_case")]
pub enum TreatmentMode { Off, Auto, On }

/// No serde defaults: a saved project cannot adopt changed future preset values.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct VoiceSettings {
    pub mode: TreatmentMode,
    pub content: AudioContent,
    pub dc: TreatmentMode,
    pub rumble: TreatmentMode,
    pub highpass_hz: u16,
    pub hum: TreatmentMode,
    /// Explicit mains selection. None uses the measured candidate, never a guess.
    pub hum_hz: Option<u16>,
    pub hum_harmonics: u8,
    pub hum_q: u16,
    pub denoise: TreatmentMode,
    /// Auto noise treatment also requires this affirmative user observation.
    pub noise_confirmed: bool,
    pub noise_floor_dbfs: i16,
    pub noise_reduction_db: u8,
    pub equalizer: TreatmentMode,
    pub presence_db: f64,
    pub deesser: TreatmentMode,
    pub deess_intensity: f64,
    pub deess_amount: f64,
    pub compressor: TreatmentMode,
    pub compressor_threshold_dbfs: i16,
    pub compressor_ratio: f64,
    pub attack_ms: u16,
    pub release_ms: u16,
    pub loudness: TreatmentMode,
    pub target_lufs: f64,
    pub max_gain_db: f64,
    pub max_attenuation_db: f64,
    pub limiter: TreatmentMode,
    pub true_peak_dbtp: f64,
    /// Headroom before lossy encoding; the final decoded output is checked too.
    pub codec_headroom_db: f64,
    pub max_analysis_seconds: u32,
}
impl Default for VoiceSettings { fn default()->Self {Self::clean()} }
impl VoiceSettings {
    pub fn clean()->Self {
        Self {mode:TreatmentMode::Auto,content:AudioContent::Unknown,
            dc:TreatmentMode::Auto,rumble:TreatmentMode::Auto,highpass_hz:70,
            hum:TreatmentMode::Auto,hum_hz:None,hum_harmonics:2,hum_q:30,
            denoise:TreatmentMode::Auto,noise_confirmed:false,noise_floor_dbfs:-50,noise_reduction_db:6,
            equalizer:TreatmentMode::Off,presence_db:1.5,
            deesser:TreatmentMode::Off,deess_intensity:0.15,deess_amount:0.25,
            compressor:TreatmentMode::Auto,compressor_threshold_dbfs:-18,compressor_ratio:2.0,
            attack_ms:20,release_ms:200,loudness:TreatmentMode::Auto,target_lufs:-18.0,
            max_gain_db:12.0,max_attenuation_db:24.0,limiter:TreatmentMode::Auto,
            true_peak_dbtp:-1.5,codec_headroom_db:0.7,max_analysis_seconds:21600}
    }
    pub fn social()->Self {Self{target_lufs:-16.0,..Self::clean()}}
    pub fn podcast()->Self {Self{target_lufs:-19.0,compressor_ratio:1.8,..Self::clean()}}
    pub fn off()->Self {Self{mode:TreatmentMode::Off,..Self::clean()}}
    pub fn validate(&self)->Result<()> {
        if !(30..=150).contains(&self.highpass_hz)
            || self.hum_hz.is_some_and(|f|f!=50&&f!=60)
            || !(1..=3).contains(&self.hum_harmonics)||!(10..=60).contains(&self.hum_q)
            || !(-80..=-30).contains(&self.noise_floor_dbfs)||!(1..=12).contains(&self.noise_reduction_db)
            || !finite_range(self.presence_db,-3.0,3.0)
            || !finite_range(self.deess_intensity,0.0,0.5)||!finite_range(self.deess_amount,0.0,0.5)
            || !(-36..=-6).contains(&self.compressor_threshold_dbfs)
            || !finite_range(self.compressor_ratio,1.0,4.0)
            || !(5..=100).contains(&self.attack_ms)||!(50..=1000).contains(&self.release_ms)
            || !finite_range(self.target_lufs,-30.0,-12.0)
            || !finite_range(self.max_gain_db,0.0,18.0)||!finite_range(self.max_attenuation_db,0.0,48.0)
            || !finite_range(self.true_peak_dbtp,-6.0,-1.0)||!finite_range(self.codec_headroom_db,0.3,2.0)
            || self.max_analysis_seconds==0||self.max_analysis_seconds>MAX_SCAN_SECONDS {
            return Err(Error::InvalidInput("voice-cleanup setting outside supported bounds"));
        }
        Ok(())
    }
}
pub(crate) fn finite_range(v:f64,lo:f64,hi:f64)->bool {v.is_finite()&&(lo..=hi).contains(&v)}
pub(crate) fn db(amplitude:f64)->Option<f64> {if amplitude>0.0 {Some(20.0*amplitude.log10())} else {None}}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
#[serde(deny_unknown_fields)]
pub struct ChannelPreflight {
    pub rms_dbfs: Option<f64>,pub peak_dbfs:Option<f64>,pub dc_offset:f64,
    /// Near/full-scale samples are a warning, not proof of recoverable clipping.
    pub near_full_scale_samples:u64,pub longest_full_scale_run:u64,
    pub low_band_fraction:f64,pub quiet_window_floor_dbfs:Option<f64>,
    pub hum_50_fraction:f64,pub hum_60_fraction:f64,
}
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
#[serde(deny_unknown_fields)]
pub struct AudioPreflight {
    pub sample_rate:u32,pub samples_per_channel:u64,pub complete_windows:u64,
    pub channels:Vec<ChannelPreflight>,
    pub channel_imbalance_db:Option<f64>,pub warnings:Vec<String>,
}
impl AudioPreflight {
    pub fn validate(&self)->Result<()> {
        if !(7350..=96000).contains(&self.sample_rate)||self.samples_per_channel==0
            || self.samples_per_channel>u64::from(self.sample_rate)*u64::from(MAX_SCAN_SECONDS)
            || self.complete_windows!=self.samples_per_channel/u64::from(self.sample_rate/5)
            || self.channels.is_empty()||self.channels.len()>MAX_CHANNELS||self.warnings.len()>32 {
            return Err(Error::InvalidInput("invalid preflight dimensions"));
        }
        for c in &self.channels {
            if !finite_range(c.dc_offset,-8.0,8.0)||!finite_range(c.low_band_fraction,0.0,1.0)
                || !finite_range(c.hum_50_fraction,0.0,1.0)||!finite_range(c.hum_60_fraction,0.0,1.0)
                || c.near_full_scale_samples>self.samples_per_channel||c.longest_full_scale_run>c.near_full_scale_samples {
                return Err(Error::InvalidInput("invalid per-channel preflight"));
            }
            for v in [c.rms_dbfs,c.peak_dbfs,c.quiet_window_floor_dbfs].into_iter().flatten(){
                if !finite_range(v,-1000.0,20.0){return Err(Error::InvalidInput("invalid audio level"));}
            }
            let rms=c.rms_dbfs.map(|v|10f64.powf(v/20.0)).unwrap_or(0.0);
            if c.dc_offset.abs()>rms+1e-6 || (c.near_full_scale_samples>0&&!c.peak_dbfs.is_some_and(|v|v>=-0.02))
                || (self.complete_windows==0&&(c.hum_50_fraction!=0.0||c.hum_60_fraction!=0.0||c.quiet_window_floor_dbfs.is_some())) {
                return Err(Error::InvalidInput("inconsistent preflight evidence"));
            }
            if c.rms_dbfs.is_some()!=c.peak_dbfs.is_some()||c.rms_dbfs.zip(c.peak_dbfs).is_some_and(|(r,p)|r>p+1e-6){return Err(Error::InvalidInput("RMS/peak ordering"));}
        }
        if self.channel_imbalance_db.is_some_and(|v|!finite_range(v,0.0,1000.0)) {return Err(Error::InvalidInput("invalid channel imbalance"));}
        for w in &self.warnings {crate::project::text_ok(w,512)?;}
        Ok(())
    }
}

/// Concrete stage choices, retained in .amxv so subsequent renders do not
/// silently re-decide which cleanup was accepted. Loudness is remeasured after cuts.
#[derive(Debug, Clone, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct VoiceStages {
    pub dc:bool,pub rumble:bool,pub hum_hz:Option<u16>,pub denoise:bool,
    pub equalizer:bool,pub deesser:bool,pub compressor:bool,pub loudness:bool,pub limiter:bool,
}
impl VoiceStages {
    pub fn active(&self)->bool {self.dc||self.rumble||self.hum_hz.is_some()||self.denoise||self.equalizer||self.deesser||self.compressor||self.loudness||self.limiter}
}
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct VoiceCleanup {
    pub version:u32,pub source_sha256:String,pub stream_index:u32,
    pub settings:VoiceSettings,pub stages:VoiceStages,
    pub preflight:Option<AudioPreflight>,
}
impl VoiceCleanup {
    pub fn validate(&self)->Result<()> {
        self.settings.validate()?;
        if self.version!=VOICE_VERSION||self.source_sha256.len()!=64||!self.source_sha256.bytes().all(|b|b.is_ascii_hexdigit()) {
            return Err(Error::InvalidProject("voice profile version or source digest"));
        }
        if let Some(p)=&self.preflight {p.validate()?;}
        let expected=resolve_stages(&self.settings,self.preflight.as_ref())?;
        if self.stages!=expected {return Err(Error::InvalidProject("voice stages disagree with saved settings/evidence"));}
        Ok(())
    }
    pub fn active(&self)->bool {self.stages.active()}
    /// Reuse the source-bound preflight for an explicit settings adjustment.
    /// Setting the resulting profile on a project invalidates old previews.
    pub fn reconfigure(&self,settings:VoiceSettings)->Result<Self> {
        self.validate()?;let mut draft=self.clone();draft.stages=resolve_stages(&settings,draft.preflight.as_ref())?;
        draft.settings=settings;draft.validate()?;Ok(draft)
    }
}

fn choose(mode:TreatmentMode,evidence:bool,global:TreatmentMode)->bool {
    match mode {TreatmentMode::Off=>false,TreatmentMode::On=>true,TreatmentMode::Auto=>evidence||global==TreatmentMode::On}
}
pub fn resolve_stages(settings:&VoiceSettings,p:Option<&AudioPreflight>)->Result<VoiceStages> {
    settings.validate()?;
    if settings.mode==TreatmentMode::Off{return Ok(VoiceStages::default());}
    let p=p.ok_or(Error::InvalidInput("voice preflight required before processing"))?;p.validate()?;
    let audible=p.channels.iter().any(|c|c.peak_dbfs.is_some_and(|v|v> -80.0));
    if !audible {return Ok(VoiceStages::default());}
    let dialogue=settings.content==AudioContent::Dialogue;
    let probable_dc=p.channels.iter().any(|c|c.dc_offset.abs()>0.002);
    let rumble=dialogue&&p.channels.iter().any(|c|c.low_band_fraction>0.30);
    // A persistent fundamental and harmonic are required by the detector.
    // Still not a semantic classifier: Unknown/MixedMusic AUTO never notches.
    let h50=p.complete_windows>=10&&p.channels.iter().any(|c|c.hum_50_fraction>=0.70);
    let h60=p.complete_windows>=10&&p.channels.iter().any(|c|c.hum_60_fraction>=0.70);
    let measured_hum=if h50&&!h60 {Some(50)} else if h60&&!h50 {Some(60)} else {None};
    let hum_hz=match settings.hum {
        TreatmentMode::Off=>None,
        TreatmentMode::Auto=>if dialogue {settings.hum_hz.filter(|hz|Some(*hz)==measured_hum).or_else(||if settings.hum_hz.is_none(){measured_hum}else{None})} else {None},
        TreatmentMode::On=>settings.hum_hz.or(measured_hum),
    };
    if settings.hum==TreatmentMode::On&&hum_hz.is_none(){return Err(Error::InvalidInput("hum On needs an explicit 50/60 Hz selection or unambiguous measured evidence"));}
    let floor=p.channels.iter().filter_map(|c|c.quiet_window_floor_dbfs).reduce(f64::max);
    let noise=dialogue&&settings.noise_confirmed&&floor.is_some_and(|v|(-70.0..=-30.0).contains(&v));
    let dynamic=dialogue&&p.channels.iter().any(|c|c.peak_dbfs.zip(c.rms_dbfs).is_some_and(|(pk,rms)|pk-rms>18.0&&pk> -10.0));
    // AUTO loudness/peak choices are resolved against the edited signal later.
    let loudness=choose(settings.loudness,dialogue,settings.mode);
    let dc=choose(settings.dc,probable_dc,settings.mode);
    let rumble=choose(settings.rumble,rumble,settings.mode);
    let denoise=choose(settings.denoise,noise,settings.mode);
    let equalizer=choose(settings.equalizer,false,settings.mode);
    let deesser=choose(settings.deesser,false,settings.mode);
    let compressor=choose(settings.compressor,dynamic,settings.mode);
    let changed=dc||rumble||hum_hz.is_some()||denoise||equalizer||deesser||compressor||loudness;
    let limiter=choose(settings.limiter,changed,settings.mode);
    Ok(VoiceStages{dc,rumble,hum_hz,denoise,equalizer,deesser,compressor,loudness,limiter})
}

#[derive(Debug,Clone,Serialize)]
pub struct VoiceReport {
    binding:String,cleanup:VoiceCleanup,
    pub warnings:Vec<String>,
    pub source_loudness:Option<crate::voice_render::LoudnessMeasurement>,
}
impl VoiceReport {
    pub fn new(project:&Project,settings:VoiceSettings,preflight:Option<AudioPreflight>)->Result<Self>{
        project.validate()?;settings.validate()?;
        let source=project.sources.first().ok_or(Error::InvalidProject("voice source"))?;
        let audio=source.media.audio.as_ref().ok_or(Error::Unsupported("voice cleanup requires selected audio"))?;
        let stages=resolve_stages(&settings,preflight.as_ref())?;
        if let Some(p)=&preflight {if audio.sample_rate!=Some(p.sample_rate)||audio.channels.map(|n|n as usize)!=Some(p.channels.len()){return Err(Error::InvalidInput("preflight stream dimensions differ"));}}
        let mut warnings=preflight.as_ref().map(|p|p.warnings.clone()).unwrap_or_default();
        if settings.mode==TreatmentMode::Off {warnings.push("Audio cleanup is off; no analysis or treatment was performed.".into());}
        if settings.content!=AudioContent::Dialogue {warnings.push("The selected track is not declared dialogue. Automatic voice-specific treatment is conservative; explicit On choices can also alter music.".into());}
        if !stages.denoise&&settings.denoise==TreatmentMode::Auto&&!settings.noise_confirmed {warnings.push("Automatic denoising bypassed without a user-confirmed noise floor; quiet speech is not noise evidence.".into());}
        if stages.active()&&!stages.limiter {warnings.push("Peak protection is explicitly off; no output true-peak ceiling is enforced.".into());}
        let cleanup=VoiceCleanup{version:VOICE_VERSION,source_sha256:source.fingerprint.sha256.clone(),stream_index:audio.index,settings,stages,preflight};
        cleanup.validate()?;
        Ok(Self{binding:project.decision_digest()?,cleanup,warnings,source_loudness:None})
    }
    pub fn cleanup(&self)->&VoiceCleanup {&self.cleanup}
    pub fn apply(&self,project:&mut Project)->Result<()> {
        if project.decision_digest()?!=self.binding{return Err(Error::StaleReview);}
        project.set_voice_cleanup(Some(self.cleanup.clone()))
    }
}

// Bounded streaming PCM statistics: 200ms windows, a fixed histogram, and small
// per-channel Goertzel accumulators. No full-recording audio or model is retained.
const FREQS:[f64;12]=[40.0,45.0,50.0,55.0,60.0,65.0,70.0,90.0,100.0,110.0,120.0,130.0];
#[derive(Clone)]
struct ChannelStats {
    sum:f64,squares:f64,peak:f64,near:u64,run:u64,longest:u64,
    low:f64,low_energy:f64,block_sum:f64,block_squares:f64,
    g1:[f64;12],g2:[f64;12],hum50:u64,hum60:u64,hist:[u64;121],
}
impl Default for ChannelStats {
    fn default()->Self{Self{sum:0.0,squares:0.0,peak:0.0,near:0,run:0,longest:0,low:0.0,low_energy:0.0,
        block_sum:0.0,block_squares:0.0,g1:[0.0;12],g2:[0.0;12],hum50:0,hum60:0,hist:[0;121]}}
}
pub struct PcmPreflight {
    rate:u32,channels:Vec<ChannelStats>,max_samples:u64,count:u64,
    pending:Vec<u8>,window:usize,window_pos:usize,windows:u64,
    coefficients:[f64;12],hann:Vec<f64>,low_alpha:f64,failed:bool,
}
impl PcmPreflight {
    pub fn new(rate:u32,channels:usize,max_seconds:u32)->Result<Self>{
        if !(7350..=96000).contains(&rate)||channels==0||channels>MAX_CHANNELS||max_seconds==0||max_seconds>MAX_SCAN_SECONDS {
            return Err(Error::InvalidInput("PCM preflight dimensions"));
        }
        let window=(rate/5) as usize;
        let coefficients=FREQS.map(|f|2.0*(std::f64::consts::TAU*f/f64::from(rate)).cos());
        let hann=(0..window).map(|n|0.5-0.5*(std::f64::consts::TAU*n as f64/(window-1) as f64).cos()).collect();
        Ok(Self{rate,channels:vec![ChannelStats::default();channels],max_samples:u64::from(rate)*u64::from(max_seconds),count:0,
            pending:Vec::with_capacity(channels*4),window,window_pos:0,windows:0,coefficients,hann,
            low_alpha:1.0-(-std::f64::consts::TAU*80.0/f64::from(rate)).exp(),failed:false})
    }
    /// Accept little-endian interleaved f32 bytes. A failed instance is poisoned;
    /// its valid prefix cannot later be mistaken for a complete successful scan.
    pub fn feed(&mut self,bytes:&[u8],cancel:&Cancellation)->Result<()> {
        if self.failed{return Err(Error::InvalidInput("failed PCM scan"));}
        let result=self.feed_inner(bytes,cancel);
        if result.is_err(){self.failed=true;}result
    }
    fn feed_inner(&mut self,bytes:&[u8],cancel:&Cancellation)->Result<()> {
        cancel.check()?;
        if bytes.len()>1024*1024{return Err(Error::LimitExceeded("PCM chunk"));}
        let frame_bytes=self.channels.len()*4;
        for block in bytes.chunks(8192){
            cancel.check()?;
            for byte in block {
                self.pending.push(*byte);
                if self.pending.len()!=frame_bytes {continue;}
                if self.count>=self.max_samples{return Err(Error::LimitExceeded("audio analysis duration"));}
                for ch in 0..self.channels.len(){
                    let n=ch*4;let x=f32::from_le_bytes([self.pending[n],self.pending[n+1],self.pending[n+2],self.pending[n+3]]) as f64;
                    if !x.is_finite()||x.abs()>8.0{return Err(Error::InvalidInput("nonfinite or implausible PCM sample"));}
                    let s=&mut self.channels[ch];s.sum+=x;s.squares+=x*x;s.peak=s.peak.max(x.abs());
                    if x.abs()>=0.999 {s.near+=1;s.run+=1;s.longest=s.longest.max(s.run);}else{s.run=0;}
                    s.low+=self.low_alpha*(x-s.low);s.low_energy+=s.low*s.low;
                    s.block_sum+=x;s.block_squares+=x*x;
                    let y=x*self.hann[self.window_pos];
                    for i in 0..12 {let g=y+self.coefficients[i]*s.g1[i]-s.g2[i];s.g2[i]=s.g1[i];s.g1[i]=g;}
                }
                self.pending.clear();self.count+=1;self.window_pos+=1;
                if self.window_pos==self.window {self.finish_window();}
            }
        }Ok(())
    }
    fn finish_window(&mut self){
        for s in &mut self.channels {
            let rms=(s.block_squares/self.window as f64).sqrt();
            let bucket=db(rms).unwrap_or(-120.0).floor().clamp(-120.0,0.0) as i32+120;s.hist[bucket as usize]+=1;
            let powers:Vec<f64>=(0..12).map(|i|(s.g1[i]*s.g1[i]+s.g2[i]*s.g2[i]-self.coefficients[i]*s.g1[i]*s.g2[i]).max(0.0)).collect();
            let p50=powers[2];let p60=powers[4];
            // >=12dB above non-adjacent side bins, a harmonic, and >-60dBFS.
            let audible50=(8.0*p50/(self.window*self.window) as f64).sqrt()>0.001;
            let audible60=(8.0*p60/(self.window*self.window) as f64).sqrt()>0.001;
            if audible50&&p50>16.0*powers[0].max(powers[4]).max(1e-20)&&powers[8]>4.0*powers[7].max(powers[9]).max(1e-20){s.hum50+=1;}
            if audible60&&p60>16.0*powers[2].max(powers[6]).max(1e-20)&&powers[10]>4.0*powers[9].max(powers[11]).max(1e-20){s.hum60+=1;}
            s.g1=[0.0;12];s.g2=[0.0;12];s.block_squares=0.0;s.block_sum=0.0;
        }
        self.window_pos=0;self.windows+=1;
    }
    pub fn finish(self,cancel:&Cancellation)->Result<AudioPreflight>{
        cancel.check()?;
        if self.failed||!self.pending.is_empty()||self.count==0{return Err(Error::InvalidInput("empty, truncated or failed PCM scan"));}
        let mut channels=Vec::new();let mut warnings=Vec::new();
        for s in &self.channels {
            let floor=if self.windows==0 {None} else {let target=(self.windows/10).max(1);let mut n=0;let mut value=None;for (b,k) in s.hist.iter().enumerate(){n+=k;if n>=target{value=if b==0{None}else{Some(b as f64-120.0)};break;}}value};
            channels.push(ChannelPreflight{rms_dbfs:db((s.squares/self.count as f64).sqrt()),peak_dbfs:db(s.peak),
                dc_offset:s.sum/self.count as f64,near_full_scale_samples:s.near,longest_full_scale_run:s.longest,
                low_band_fraction:if s.squares>0.0{(s.low_energy/s.squares).clamp(0.0,1.0)}else{0.0},quiet_window_floor_dbfs:floor,
                hum_50_fraction:if self.windows>0{s.hum50 as f64/self.windows as f64}else{0.0},
                hum_60_fraction:if self.windows>0{s.hum60 as f64/self.windows as f64}else{0.0}});
        }
        if channels.iter().any(|c|c.near_full_scale_samples>0){warnings.push("Near/full-scale samples suggest possible input clipping; normalization cannot reconstruct missing peaks.".into());}
        let levels:Vec<f64>=channels.iter().filter_map(|c|c.rms_dbfs).collect();
        let imbalance=if levels.len()>1{Some(levels.iter().copied().fold(f64::NEG_INFINITY,f64::max)-levels.iter().copied().fold(f64::INFINITY,f64::min))}else{None};
        if channels.len()>1&&(levels.len()!=channels.len()||imbalance.is_some_and(|v|v>12.0)){warnings.push("Channel levels differ substantially. No automatic channel balancing or downmix will be performed.".into());}
        if self.windows<10{warnings.push("Short audio: persistent hum/noise evidence is limited.".into());}
        warnings.push("Low-band energy and persistent tones are signal measurements, not proof of rumble, hum, speech or music.".into());
        let result=AudioPreflight{sample_rate:self.rate,samples_per_channel:self.count,complete_windows:self.windows,channels,channel_imbalance_db:imbalance,warnings};
        result.validate()?;Ok(result)
    }
}
