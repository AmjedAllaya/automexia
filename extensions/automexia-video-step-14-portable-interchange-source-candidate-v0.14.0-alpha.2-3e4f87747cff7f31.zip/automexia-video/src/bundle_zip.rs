//! Bounded stored ZIP64 writer. This module performs no filesystem access.
//!
//! PKWARE APPNOTE 6.3.10, sections 4.3.7–4.3.16 and 4.5.3:
//! <https://pkware.cachefly.net/webdocs/casestudies/APPNOTE.TXT>.
//! Every member uses ZIP64 sizes, an explicit data descriptor, and a fixed
//! 1980-01-01 timestamp. No compression, encryption, paths from a filesystem,
//! or extraction functionality is exposed here.
use crate::{Cancellation, Error, Result};
use sha2::{Digest, Sha256};
use std::{collections::BTreeSet, io::{Read, Write}};

pub const MAX_ZIP_ENTRIES: usize = 16;
pub const MAX_ZIP_NAME_BYTES: usize = 240;
const END_BYTES: u64 = 98;
const ENTRY_OVERHEAD: u64 = 148;
const FLAGS: u16 = 0x0808; // UTF-8 names and a trailing data descriptor.
const DOS_DATE: u16 = 33; // 1980-01-01, midnight.

/// Portable regular-file names only; directory records are not needed.
pub fn validate_name(name: &str) -> Result<()> {
    if name.is_empty() || name.len() > MAX_ZIP_NAME_BYTES || !name.is_ascii()
        || name.bytes().any(|b| !(b.is_ascii_alphanumeric() || b"/_-.".contains(&b))) {
        return Err(Error::InvalidInput("portable ZIP member name"));
    }
    for part in name.split('/') {
        if part.is_empty() || part == "." || part == ".." || part.ends_with('.') {
            return Err(Error::InvalidInput("ZIP member path traversal or ambiguous component"));
        }
        let stem = part.split('.').next().unwrap_or("").to_ascii_uppercase();
        if matches!(stem.as_str(), "CON" | "PRN" | "AUX" | "NUL")
            || (stem.len() == 4 && (stem.starts_with("COM") || stem.starts_with("LPT"))
                && stem.as_bytes()[3].is_ascii_digit() && stem.as_bytes()[3] != b'0') {
            return Err(Error::InvalidInput("reserved ZIP member component"));
        }
    }
    Ok(())
}

/// Exact size including headers, data descriptors, directory, and ZIP64 footer.
pub fn archive_size(entries: &[(&str, u64)]) -> Result<u64> {
    if entries.is_empty() || entries.len() > MAX_ZIP_ENTRIES {
        return Err(Error::LimitExceeded("ZIP member count"));
    }
    let mut names = BTreeSet::new();
    let mut total = END_BYTES;
    for (name, size) in entries {
        validate_name(name)?;
        let folded = name.to_ascii_lowercase();
        if names.iter().any(|old: &String| old == &folded
            || folded.starts_with(&format!("{old}/")) || old.starts_with(&format!("{folded}/"))) {
            return Err(Error::InvalidInput("duplicate or conflicting ZIP member names"));
        }
        names.insert(folded);
        total = total.checked_add(ENTRY_OVERHEAD).and_then(|n| n.checked_add(2 * name.len() as u64))
            .and_then(|n| n.checked_add(*size)).ok_or(Error::LimitExceeded("ZIP archive size"))?;
    }
    Ok(total)
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ZipEntryDigest { pub size: u64, pub sha256: String, pub crc32: u32 }

struct Entry { name: String, digest: ZipEntryDigest, offset: u64 }

/// The writer retains only at most 16 short directory entries and a 64 KiB
/// copy buffer. A read/write/cancellation error poisons it: finish then fails.
pub struct StoredZip64<W: Write> {
    output: W, limit: u64, position: u64, entries: Vec<Entry>, failed: bool,
}
impl<W: Write> StoredZip64<W> {
    pub fn new(output: W, max_archive_bytes: u64) -> Result<Self> {
        if max_archive_bytes < END_BYTES { return Err(Error::LimitExceeded("ZIP archive size")); }
        Ok(Self { output, limit: max_archive_bytes, position: 0, entries: Vec::new(), failed: false })
    }
    pub fn bytes_written(&self) -> u64 { self.position }

    /// Reads exactly the declared content plus a one-byte EOF check. The digest
    /// describes the bytes actually copied, independently of any caller stamp.
    pub fn add_entry<R: Read + ?Sized>(&mut self, name: &str, reader: &mut R, size: u64,
        cancel: &Cancellation) -> Result<ZipEntryDigest> {
        if self.failed { return Err(Error::InvalidOutput("ZIP writer is incomplete")); }
        let mut sizes: Vec<(&str, u64)> = self.entries.iter().map(|e| (e.name.as_str(), e.digest.size)).collect();
        sizes.push((name, size));
        if archive_size(&sizes)? > self.limit { return Err(Error::LimitExceeded("ZIP archive size")); }
        self.failed = true;
        cancel.check()?;
        let offset = self.position;
        let mut header = Vec::with_capacity(50 + name.len());
        u32le(&mut header, 0x04034b50); u16le(&mut header, 45); u16le(&mut header, FLAGS);
        u16le(&mut header, 0); u16le(&mut header, 0); u16le(&mut header, DOS_DATE);
        u32le(&mut header, 0); u32le(&mut header, u32::MAX); u32le(&mut header, u32::MAX);
        u16le(&mut header, name.len() as u16); u16le(&mut header, 20);
        header.extend_from_slice(name.as_bytes());
        u16le(&mut header, 1); u16le(&mut header, 16); u64le(&mut header, 0); u64le(&mut header, 0);
        self.write(&header)?;
        let mut digest = Sha256::new(); let mut crc = u32::MAX; let mut copied = 0u64;
        let mut buffer = [0u8; 65_536];
        while copied < size {
            cancel.check()?;
            let capacity = usize::try_from((size - copied).min(buffer.len() as u64)).map_err(|_| Error::LimitExceeded("ZIP copy chunk"))?;
            let n = match reader.read(&mut buffer[..capacity]) {
                Ok(0) => return Err(Error::InputChanged),
                Ok(n) => n,
                Err(e) if e.kind() == std::io::ErrorKind::Interrupted => continue,
                Err(_) => return Err(Error::Io("read ZIP member")),
            };
            cancel.check()?;
            digest.update(&buffer[..n]);
            for byte in &buffer[..n] { crc = CRC_TABLE[((crc ^ u32::from(*byte)) & 255) as usize] ^ (crc >> 8); }
            self.write(&buffer[..n])?;
            copied = copied.checked_add(n as u64).ok_or(Error::LimitExceeded("ZIP member size"))?;
        }
        loop {
            cancel.check()?;
            match reader.read(&mut buffer[..1]) {
                Ok(0) => break,
                Ok(_) => return Err(Error::InputChanged),
                Err(e) if e.kind() == std::io::ErrorKind::Interrupted => continue,
                Err(_) => return Err(Error::Io("check ZIP member end")),
            }
        }
        cancel.check()?;
        let result = ZipEntryDigest { size: copied, sha256: format!("{:x}", digest.finalize()), crc32: !crc };
        let mut descriptor = Vec::with_capacity(24);
        u32le(&mut descriptor, 0x08074b50); u32le(&mut descriptor, result.crc32);
        u64le(&mut descriptor, size); u64le(&mut descriptor, size);
        self.write(&descriptor)?;
        self.entries.push(Entry { name: name.to_owned(), digest: result.clone(), offset });
        self.failed = false;
        Ok(result)
    }

    pub fn finish(mut self, cancel: &Cancellation) -> Result<W> {
        if self.failed || self.entries.is_empty() { return Err(Error::InvalidOutput("ZIP writer is incomplete")); }
        cancel.check()?;
        let central_offset = self.position;
        for index in 0..self.entries.len() {
            cancel.check()?;
            let entry = &self.entries[index];
            let mut header = Vec::with_capacity(74 + entry.name.len());
            u32le(&mut header, 0x02014b50); u16le(&mut header, (3 << 8) | 45); u16le(&mut header, 45);
            u16le(&mut header, FLAGS); u16le(&mut header, 0); u16le(&mut header, 0); u16le(&mut header, DOS_DATE);
            u32le(&mut header, entry.digest.crc32); u32le(&mut header, u32::MAX); u32le(&mut header, u32::MAX);
            u16le(&mut header, entry.name.len() as u16); u16le(&mut header, 28);
            u16le(&mut header, 0); u16le(&mut header, 0); u16le(&mut header, 0);
            u32le(&mut header, 0o100644 << 16); u32le(&mut header, u32::MAX);
            header.extend_from_slice(entry.name.as_bytes());
            u16le(&mut header, 1); u16le(&mut header, 24);
            u64le(&mut header, entry.digest.size); u64le(&mut header, entry.digest.size); u64le(&mut header, entry.offset);
            self.write(&header)?;
        }
        let central_size = self.position - central_offset;
        let zip64_offset = self.position;
        let mut footer = Vec::with_capacity(98);
        u32le(&mut footer, 0x06064b50); u64le(&mut footer, 44);
        u16le(&mut footer, (3 << 8) | 45); u16le(&mut footer, 45);
        u32le(&mut footer, 0); u32le(&mut footer, 0);
        u64le(&mut footer, self.entries.len() as u64); u64le(&mut footer, self.entries.len() as u64);
        u64le(&mut footer, central_size); u64le(&mut footer, central_offset);
        u32le(&mut footer, 0x07064b50); u32le(&mut footer, 0); u64le(&mut footer, zip64_offset); u32le(&mut footer, 1);
        u32le(&mut footer, 0x06054b50); u16le(&mut footer, 0); u16le(&mut footer, 0);
        u16le(&mut footer, u16::MAX); u16le(&mut footer, u16::MAX);
        u32le(&mut footer, u32::MAX); u32le(&mut footer, u32::MAX); u16le(&mut footer, 0);
        self.write(&footer)?;
        self.output.flush().map_err(|_| Error::Io("flush ZIP archive"))?;
        cancel.check()?;
        Ok(self.output)
    }
    fn write(&mut self, bytes: &[u8]) -> Result<()> {
        let next = self.position.checked_add(bytes.len() as u64).ok_or(Error::LimitExceeded("ZIP archive size"))?;
        if next > self.limit { return Err(Error::LimitExceeded("ZIP archive size")); }
        self.output.write_all(bytes).map_err(|_| Error::Io("write ZIP archive"))?;
        self.position = next;
        Ok(())
    }
}
fn u16le(out: &mut Vec<u8>, n: u16) { out.extend_from_slice(&n.to_le_bytes()); }
fn u32le(out: &mut Vec<u8>, n: u32) { out.extend_from_slice(&n.to_le_bytes()); }
fn u64le(out: &mut Vec<u8>, n: u64) { out.extend_from_slice(&n.to_le_bytes()); }
const fn crc_table() -> [u32; 256] {
    let mut table = [0u32; 256]; let mut i = 0;
    while i < 256 {
        let mut crc = i as u32; let mut bit = 0;
        while bit < 8 { crc = if crc & 1 != 0 { (crc >> 1) ^ 0xedb88320 } else { crc >> 1 }; bit += 1; }
        table[i] = crc; i += 1;
    }
    table
}
const CRC_TABLE: [u32; 256] = crc_table();
