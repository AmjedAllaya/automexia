//! Optional provider-side preparation of private PNG timelines. Not a sandbox.
//! NativeMediaHost users must grant every selected asset path themselves.
use crate::{Cancellation,Error,Result};
use crate::host::{MediaHost,InputFile};
use crate::graphics::{AssetBytes,RASTERIZER_ID};
use crate::presentation_render::{PresentationRender,PresentationLease,AssetReceipt};
use image::{RgbaImage,DynamicImage,ImageFormat};
use sha2::{Sha256,Digest};
use std::{collections::{BTreeMap,BTreeSet},fs::{self,File},io::{Write,Cursor},path::{Path,PathBuf},time::{Instant,Duration}};
const MAX_ASSET_TOTAL:u64=64*1024*1024;
const MAX_PATCH_CACHE:u64=64*1024*1024;
pub(crate) fn prepare(host:&crate::native::NativeMediaHost,plan:&PresentationRender,project_file:&Path,cancel:&Cancellation)->Result<Box<dyn PresentationLease>>{
    cancel.check()?;let started=Instant::now();let deadline=Duration::from_secs(u64::from(plan.settings.raster.max_prepare_seconds));
    let mut inputs=Vec::new();let mut assets=AssetBytes::new();let mut receipts=Vec::new();let mut seen_paths=BTreeSet::new();let mut used=0u64;
    for e in &plan.events {for reference in e.content.assets(){
        let path=reference.resolve(project_file)?;if !seen_paths.insert(path.clone()){continue;}
        let input=host.inspect_input(&path,cancel)?;
        if input.stamp.size!=reference.size||input.stamp.sha256!=reference.sha256{return Err(Error::InputChanged);}
        if !assets.contains_key(&reference.sha256){
            used=used.checked_add(reference.size).ok_or(Error::LimitExceeded("asset total"))?;if used>MAX_ASSET_TOTAL{return Err(Error::LimitExceeded("decoded input asset bytes"));}
            let bytes=crate::native::read_selected_bytes(&input.canonical_path,reference.size,cancel)?;
            if bytes.len() as u64!=reference.size||format!("{:x}",Sha256::digest(&bytes))!=reference.sha256{return Err(Error::InputChanged);}
            assets.insert(reference.sha256.clone(),bytes);
        }
        host.revalidate_input(&input,cancel)?;
        receipts.push(AssetReceipt{path:input.canonical_path.clone(),sha256:reference.sha256.clone(),size:reference.size,renderer:RASTERIZER_ID.into(),font_family:match &e.content{crate::presentation::GraphicContent::Text{style,..}=>Some(style.font.family.clone()),_=>None}});
        inputs.push(input);
    }}
    let directory=crate::native::private_tempdir("automexia-graphics-",None).map_err(|_|Error::Io("create private graphics directory"))?;
    let manifest=directory.path().join("overlay.ffconcat");let times=plan.sample_times()?;
    let mut script=String::from("ffconcat version 1.0\n");let mut written=BTreeSet::new();let mut disk_bytes=0u64;
    let mut cache:BTreeMap<String,RgbaImage>=BTreeMap::new();let mut cache_bytes=0u64;
    for (i,&clock) in times.iter().enumerate(){
        cancel.check()?;if started.elapsed()>deadline{return Err(Error::Timeout);}
        let at=crate::Rational::new(clock,1_000_000)?;let mut canvas=RgbaImage::new(plan.canvas.width,plan.canvas.height);
        for e in &plan.events {
            if clock<e.range.start.nearest_units(1_000_000)?||clock>=e.range.end.nearest_units(1_000_000)?{continue;}
            let (rect,opacity)=plan.rect(e,at)?;if opacity<=0.0{continue;}
            let key=format!("{:x}",Sha256::digest(serde_json::to_vec(&(&e.content,e.placement.width,e.placement.height)).map_err(|_|Error::InvalidProject("graphic raster key"))?));
            if !cache.contains_key(&key){
                let patch=crate::graphics::rasterize(&e.content,e.placement.width,e.placement.height,&assets,cancel)?;
                let bytes=u64::from(patch.width())*u64::from(patch.height())*4;
                if bytes>MAX_PATCH_CACHE{return Err(Error::LimitExceeded("graphic patch cache"));}
                if cache_bytes+bytes>MAX_PATCH_CACHE{cache.clear();cache_bytes=0;}cache_bytes+=bytes;cache.insert(key.clone(),patch);
            }
            let patch=cache.get(&key).ok_or(Error::InvalidOutput("raster cache entry"))?;
            let mut scaled=if patch.width()==rect.width&&patch.height()==rect.height{patch.clone()}else{crate::graphics::resize_rgba(patch,rect.width,rect.height)};
            for pixel in scaled.pixels_mut(){pixel[3]=(f64::from(pixel[3])*opacity).round().clamp(0.0,255.0) as u8;}
            image::imageops::overlay(&mut canvas,&scaled,i64::from(rect.x),i64::from(rect.y));
        }
        if plan.canvas!=plan.encoded{canvas=crate::graphics::resize_rgba(&canvas,plan.encoded.width,plan.encoded.height);}
        crate::graphics::srgb_to_bt709(&mut canvas);
        let digest=format!("{:x}",Sha256::digest(canvas.as_raw()));let name=format!("frame-{digest}.png");
        if written.insert(digest){
            let mut png=Vec::new();DynamicImage::ImageRgba8(canvas).write_to(&mut Cursor::new(&mut png),ImageFormat::Png).map_err(|_|Error::Io("encode private graphics PNG"))?;
            disk_bytes=disk_bytes.checked_add(png.len() as u64).ok_or(Error::LimitExceeded("graphics scratch bytes"))?;
            if disk_bytes>plan.settings.raster.max_scratch_bytes{return Err(Error::LimitExceeded("graphics scratch bytes"));}
            let mut file=File::create(directory.path().join(&name)).map_err(|_|Error::Io("create private graphics PNG"))?;
            file.write_all(&png).map_err(|_|Error::Io("write private graphics PNG"))?;
        }
        let duration=times.get(i+1).map(|n|n-clock).unwrap_or(1);
        // Only generated ASCII names enter this manifest. `option framerate`
        // requires concat safe=0; no selected filename is interpolated here.
        script.push_str(&format!("file '{name}'\noption framerate 1000000\nduration {}.{:06}\n",duration/1_000_000,duration%1_000_000));
        if disk_bytes+script.len() as u64>plan.settings.raster.max_scratch_bytes{return Err(Error::LimitExceeded("graphics manifest and pixels"));}
    }
    fs::write(&manifest,&script).map_err(|_|Error::Io("write private graphics manifest"))?;
    disk_bytes+=script.len() as u64;cancel.check()?;for input in &inputs{host.revalidate_input(input,cancel)?;}
    Ok(Box::new(NativePresentation{directory,manifest,inputs,receipts,bytes:disk_bytes}))
}
struct NativePresentation {directory:tempfile::TempDir,manifest:PathBuf,inputs:Vec<InputFile>,receipts:Vec<AssetReceipt>,bytes:u64}
impl PresentationLease for NativePresentation {
    fn sequence_path(&self)->&Path{&self.manifest}
    fn bytes(&self)->u64{self.bytes}
    fn receipts(&self)->&[AssetReceipt]{&self.receipts}
    fn revalidate(&self,destination:Option<&Path>,cancel:&Cancellation)->Result<()> {
        cancel.check()?;if !self.manifest.starts_with(self.directory.path()){return Err(Error::InvalidOutput("graphics lease path"));}
        for input in &self.inputs {
            if crate::native::fingerprint(&input.canonical_path,crate::presentation::MAX_ASSET_BYTES,cancel)?!=input.stamp{return Err(Error::InputChanged);}
            if let Some(path)=destination {
                if path==input.canonical_path{return Err(Error::SameFile);}
                if path.exists()&&same_file::is_same_file(path,&input.canonical_path).map_err(|_|Error::Io("compare graphic/output identity"))?{return Err(Error::SameFile);}
            }
        }cancel.check()
    }
}
