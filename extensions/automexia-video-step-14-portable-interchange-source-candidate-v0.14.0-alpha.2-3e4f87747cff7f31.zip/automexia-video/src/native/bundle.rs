//! Private staging and create-new publication for portable ZIP64 bundles.
use super::{NativeMediaHost, fingerprint, open_regular_file, private_tempdir};
use crate::{Cancellation, Error, Result};
use crate::bundle::{BundleEntry, BundlePlan};
use crate::bundle_workflow::{BundleHost, BundleLease, BundlePublication};
use crate::bundle_zip::{archive_size, StoredZip64};
use crate::host::{InputFile, MediaHost, OutputLease, OutputPolicy, ProgressSink};
use crate::progress::{Progress, Stage};
use sha2::{Digest, Sha256};
use std::{fs, io::{Cursor, Write}, path::{Component, Path, PathBuf}, time::UNIX_EPOCH};
use tempfile::TempDir;

impl BundleHost for NativeMediaHost {
    fn stage_bundle(&self, source: &InputFile, protected: &[PathBuf], destination: &Path,
        max_total_bytes: u64, cancel: &Cancellation) -> Result<Box<dyn BundleLease>> {
        cancel.check()?;
        if max_total_bytes == 0 { return Err(Error::InvalidInput("bundle byte limit")); }
        if protected.len() > 256 { return Err(Error::LimitExceeded("bundle protected paths")); }
        let destination = normalized_destination(destination)?;
        if !destination.extension().and_then(|s| s.to_str()).is_some_and(|s| s.eq_ignore_ascii_case("zip")) {
            return Err(Error::InvalidInput("bundle ZIP destination"));
        }
        self.revalidate_input(source, cancel)?;
        let mut guarded = Vec::with_capacity(protected.len());
        for path in protected { guarded.push(normalized_protected(path)?); }
        guard_paths(&guarded, &destination)?;
        let output = self.stage_output(source, &destination, &OutputPolicy::CreateNew, cancel)?;
        let directory = output.path().parent().ok_or(Error::InvalidOutput("bundle staging parent"))?;
        let workspace = private_tempdir("bundle-work-", Some(directory)).map_err(|_| Error::Io("create bundle workspace"))?;
        let workspace_path = fs::canonicalize(workspace.path()).map_err(|_| Error::Io("resolve bundle workspace"))?;
        fs::create_dir(workspace_path.join("Media")).map_err(|_| Error::Io("create bundle media workspace"))?;
        let workspace_id = directory_id(&workspace_path)?;
        let media_directory_id = directory_id(&workspace_path.join("Media"))?;
        cancel.check()?;
        Ok(Box::new(NativeBundleLease { workspace, workspace_path, workspace_id, media_directory_id, output: Some(output), source: source.clone(),
            protected: guarded, destination, request_limit: max_total_bytes,
            max_input_bytes: self.settings.max_input_bytes,
            max_archive_bytes: max_total_bytes.min(self.settings.max_output_bytes) }))
    }
}

struct NativeBundleLease {
    // Declared first so nested workspace cleanup precedes parent lease cleanup.
    workspace: TempDir,
    workspace_path: PathBuf,
    workspace_id: Option<String>, media_directory_id: Option<String>,
    output: Option<Box<dyn OutputLease>>,
    source: InputFile, protected: Vec<PathBuf>, destination: PathBuf,
    request_limit: u64, max_input_bytes: u64, max_archive_bytes: u64,
}
impl BundleLease for NativeBundleLease {
    fn workspace(&self) -> &Path { &self.workspace_path }
    fn publish(mut self: Box<Self>, plan: &BundlePlan, cancel: &Cancellation,
        progress: &mut ProgressSink<'_>) -> Result<BundlePublication> {
        cancel.check()?;
        if normalized_destination(plan.destination())? != self.destination || plan.max_total_bytes() != self.request_limit {
            return Err(Error::InvalidInput("bundle plan does not match staged request"));
        }
        plan.document().validate_destination(&self.workspace_path.join(format!("timeline.{}", plan.document().format().extension())))?;
        let members: Vec<(&str, u64)> = plan.entries().iter().map(|entry| match entry {
            BundleEntry::Bytes(value) => (value.name(), value.bytes().len() as u64),
            BundleEntry::Media(value) => (value.name(), value.input().stamp.size),
        }).collect();
        let expected_size = archive_size(&members)?;
        if expected_size > self.max_archive_bytes { return Err(Error::LimitExceeded("complete bundle archive size")); }
        let payload = members.iter().try_fold(0u64, |n, (_, size)| n.checked_add(*size).ok_or(Error::LimitExceeded("bundle payload size")))?;
        if payload != plan.total_bytes() || expected_size != plan.archive_bytes() { return Err(Error::InvalidInput("bundle payload accounting")); }
        let staged = self.output.as_ref().ok_or(Error::InvalidOutput("bundle output already consumed"))?.path().to_path_buf();
        let empty_stamp = fingerprint(&staged, self.max_archive_bytes, cancel)?;
        if empty_stamp.size != 0 { return Err(Error::OutputChanged); }
        emit(progress, Stage::Exporting)?;
        self.revalidate(plan, &staged, cancel)?;
        if fingerprint(&staged, self.max_archive_bytes, cancel)? != empty_stamp { return Err(Error::OutputChanged); }
        // Never truncate before checking the opened descriptor. A callback or
        // accidental alias must not turn an archive open into source damage.
        let mut options = fs::OpenOptions::new(); options.write(true);
        #[cfg(unix)] { use std::os::unix::fs::OpenOptionsExt;
            options.custom_flags(nix::libc::O_NOFOLLOW | nix::libc::O_NONBLOCK); }
        let archive = options.open(&staged).map_err(|_| Error::Io("open staged bundle archive"))?;
        let opened = archive.metadata().map_err(|_| Error::Io("bundle archive metadata"))?;
        if !opened.is_file() {
            return Err(Error::InvalidOutput("bundle archive must be regular"));
        }
        let modified = opened.modified().ok().and_then(|time| time.duration_since(UNIX_EPOCH).ok()).map(|duration| duration.as_nanos());
        if opened.len() != 0 || super::platform_id(&opened) != empty_stamp.file_id || modified != empty_stamp.modified_ns {
            return Err(Error::OutputChanged);
        }
        let mut writer = StoredZip64::new(HashingOutput { file: archive, sha256: Sha256::new(), bytes: 0 }, self.max_archive_bytes)?;
        for entry in plan.entries() {
            cancel.check()?;
            match entry {
                BundleEntry::Bytes(value) => {
                    writer.add_entry(value.name(), &mut Cursor::new(value.bytes()), value.bytes().len() as u64, cancel)?;
                }
                BundleEntry::Media(value) => {
                    let input = value.input();
                    let mut reader = open_regular_file(&input.canonical_path)?;
                    let digest = writer.add_entry(value.name(), &mut reader, input.stamp.size, cancel)?;
                    if digest.size != input.stamp.size || digest.sha256 != input.stamp.sha256 { return Err(Error::InputChanged); }
                }
            }
        }
        let archive = writer.finish(cancel)?;
        archive.file.sync_all().map_err(|_| Error::Io("synchronize bundle archive"))?;
        let copied_bytes = archive.bytes;
        let copied_sha256 = format!("{:x}", archive.sha256.finalize());
        drop(archive.file);
        emit(progress, Stage::Validating)?;
        let stamp = fingerprint(&staged, self.max_archive_bytes, cancel)?;
        if stamp.size != expected_size || stamp.size != copied_bytes || stamp.sha256 != copied_sha256 {
            return Err(Error::InvalidOutput("bundle archive does not match copied bytes"));
        }
        emit(progress, Stage::Publishing)?;
        // Callbacks can cancel or modify selected files, so all guards follow
        // the last callback and precede the only public commit.
        self.revalidate(plan, &staged, cancel)?;
        if fingerprint(&staged, self.max_archive_bytes, cancel)? != stamp { return Err(Error::OutputChanged); }
        cancel.check()?;
        let output = self.output.take().ok_or(Error::InvalidOutput("bundle output already consumed"))?;
        let path = output.publish(cancel)?;
        Ok(BundlePublication { path, sha256: stamp.sha256, size: stamp.size })
    }
}
struct HashingOutput { file: fs::File, sha256: Sha256, bytes: u64 }
impl Write for HashingOutput {
    fn write(&mut self, data: &[u8]) -> std::io::Result<usize> {
        let count = self.file.write(data)?;
        self.sha256.update(&data[..count]);
        self.bytes = self.bytes.checked_add(count as u64).ok_or_else(|| std::io::Error::other("archive byte overflow"))?;
        Ok(count)
    }
    fn flush(&mut self) -> std::io::Result<()> { self.file.flush() }
}
impl NativeBundleLease {
    fn revalidate(&self, plan: &BundlePlan, staged: &Path, cancel: &Cancellation) -> Result<()> {
        cancel.check()?;
        // Keep ownership observable to the compiler and reject a substituted
        // workspace before any externally supplied plan is streamed.
        if self.workspace.path() != self.workspace_path
            || directory_id(&self.workspace_path)? != self.workspace_id
            || directory_id(&self.workspace_path.join("Media"))? != self.media_directory_id {
            return Err(Error::InputChanged);
        }
        if fingerprint(&self.source.canonical_path, self.max_input_bytes, cancel)? != self.source.stamp {
            return Err(Error::InputChanged);
        }
        guard_paths(&self.protected, &self.destination)?;
        super::check_destination(&self.source, &self.destination, &OutputPolicy::CreateNew, self.max_input_bytes, cancel)?;
        for input in plan.all_inputs() {
            if !(input.canonical_path == self.source.canonical_path && input.stamp == self.source.stamp)
                && input.canonical_path != self.workspace_path.join("Media/video.mov")
                && input.canonical_path != self.workspace_path.join("Media/audio.wav") {
                return Err(Error::InvalidInput("bundle media is outside the leased source and bake paths"));
            }
            guard_paths(&[input.canonical_path.clone()], &self.destination)?;
            if input.canonical_path == staged || same_file::is_same_file(&input.canonical_path, staged)
                .map_err(|_| Error::Io("compare bundle staged input alias"))? { return Err(Error::SameFile); }
            if fingerprint(&input.canonical_path, self.max_input_bytes, cancel)? != input.stamp { return Err(Error::InputChanged); }
        }
        cancel.check()
    }
}
fn emit(progress: &mut ProgressSink<'_>, stage: Stage) -> Result<()> {
    std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| progress(Progress::stage(stage))))
        .map_err(|_| Error::CallbackPanicked)
}
fn normalized_destination(path: &Path) -> Result<PathBuf> {
    validate_local_path(path)?;
    let name = path.file_name().ok_or(Error::InvalidInput("bundle filename"))?;
    let parent = fs::canonicalize(path.parent().ok_or(Error::InvalidInput("bundle parent"))?)
        .map_err(|_| Error::Io("resolve bundle parent"))?;
    if !parent.is_dir() { return Err(Error::InvalidInput("bundle parent directory")); }
    Ok(parent.join(name))
}
fn validate_local_path(path: &Path) -> Result<()> {
    if !path.is_absolute() || path.as_os_str().as_encoded_bytes().contains(&0)
        || path.components().any(|part| matches!(part, Component::ParentDir | Component::CurDir)) {
        return Err(Error::InvalidInput("absolute bundle path without traversal"));
    }
    Ok(())
}
fn normalized_protected(path: &Path) -> Result<PathBuf> {
    validate_local_path(path)?;
    let name = path.file_name().ok_or(Error::InvalidInput("bundle filename"))?;
    // Unused/disabled assets may be offline. They remain protected by lexical
    // path and any currently live alias; an absent parent is not an input read.
    Ok(match path.parent().and_then(|parent| fs::canonicalize(parent).ok()) {
        Some(parent) => parent.join(name), None => path.to_path_buf(),
    })
}
fn guard_paths(paths: &[PathBuf], destination: &Path) -> Result<()> {
    for path in paths {
        if path == destination { return Err(Error::SameFile); }
        if fs::symlink_metadata(destination).is_ok() && fs::symlink_metadata(path).is_ok()
            && same_file::is_same_file(path, destination).map_err(|_| Error::Io("compare bundle protected paths"))? {
            return Err(Error::SameFile);
        }
    }
    Ok(())
}

// Unix metadata exposes a stable device/inode identity. On other platforms the
// existing host directory authorization applies; still reject symlinks and
// non-directories. This does not promise protection from hostile parent races.
fn directory_id(path: &Path) -> Result<Option<String>> {
    let metadata = fs::symlink_metadata(path).map_err(|_| Error::InputChanged)?;
    if metadata.file_type().is_symlink() || !metadata.is_dir() { return Err(Error::InputChanged); }
    Ok(super::platform_id(&metadata))
}
