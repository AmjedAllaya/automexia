//! One typed whisper.cpp request using the existing bounded native process owner.
use super::runner::{run_process,CaptureMode};
use crate::whisper_cpp::{WhisperTask,MAX_TRANSCRIPT_JSON_BYTES,MAX_RUNTIME_BYTES,MAX_BUILD_INFO_BYTES};
use crate::{Cancellation,Error,Result};
use std::{fs::{self,OpenOptions},io::Write,time::Instant};

pub(crate) fn run_whisper_task(task:&WhisperTask<'_>,cancel:&Cancellation)->Result<Vec<u8>> {
    cancel.check()?;let started=Instant::now();
    let check_runtime=||->Result<()> {
        if super::fingerprint(task.executable,MAX_RUNTIME_BYTES,cancel)?!=*task.artifact
            ||super::fingerprint(task.build_info,MAX_BUILD_INFO_BYTES,cancel)?!=*task.build {
            return Err(Error::ToolIdentityChanged);
        }Ok(())
    };
    check_runtime()?;
    let directory=super::private_tempdir(".automexia-transcript-",Some(task.temp_parent)).map_err(|_|Error::Io("create private transcript staging"))?;
    let model=directory.path().join("model.bin");let audio=directory.path().join("audio.wav");
    let prefix=directory.path().join("transcript");let json=directory.path().join("transcript.json");
    let write=|path:&std::path::Path,bytes:&[u8]|->Result<()> {
        let mut file=OpenOptions::new().write(true).create_new(true).open(path).map_err(|_|Error::Io("create private transcript input"))?;
        for chunk in bytes.chunks(64*1024){cancel.check()?;file.write_all(chunk).map_err(|_|Error::Io("write private transcript input"))?;}
        file.sync_all().map_err(|_|Error::Io("flush private transcript input"))?;Ok(())
    };
    write(&model,task.weights)?;
    let data_len=u32::try_from(task.samples.len().checked_mul(2).ok_or(Error::LimitExceeded("transcript WAV size"))?).map_err(|_|Error::LimitExceeded("transcript WAV size"))?;
    let mut wav=Vec::with_capacity(44+data_len as usize);wav.extend_from_slice(b"RIFF");wav.extend_from_slice(&(data_len+36).to_le_bytes());
    wav.extend_from_slice(b"WAVEfmt ");wav.extend_from_slice(&16u32.to_le_bytes());wav.extend_from_slice(&1u16.to_le_bytes());wav.extend_from_slice(&1u16.to_le_bytes());
    wav.extend_from_slice(&16000u32.to_le_bytes());wav.extend_from_slice(&32000u32.to_le_bytes());wav.extend_from_slice(&2u16.to_le_bytes());wav.extend_from_slice(&16u16.to_le_bytes());
    wav.extend_from_slice(b"data");wav.extend_from_slice(&data_len.to_le_bytes());
    for chunk in task.samples.chunks(32768){cancel.check()?;for sample in chunk{wav.extend_from_slice(&sample.to_le_bytes());}}
    write(&audio,&wav)?;drop(wav);
    // Precreate the watched file: runner rejects nonregular/symlink output and
    // checks its size both during execution and after process completion.
    write(&json,&[])?;
    check_runtime()?;
    let mut args=crate::host::words(&["--threads","2","--processors","1","--no-gpu","--no-prints",
        "--output-json-full","--max-len","1","--split-on-word","--language",task.language,"--model"]);
    args.push(model.as_os_str().to_owned());args.push("--file".into());args.push(audio.as_os_str().to_owned());
    args.push("--output-file".into());args.push(prefix.as_os_str().to_owned());
    let remaining=task.timeout.saturating_sub(started.elapsed());if remaining.is_zero(){return Err(Error::Timeout);}
    run_process(task.executable,"whisper.cpp",&args,remaining,CaptureMode::Text,Some((json.clone(),MAX_TRANSCRIPT_JSON_BYTES as u64)),cancel,&mut |_|{})?;
    check_runtime()?;
    let result=super::read_selected_bytes(&json,MAX_TRANSCRIPT_JSON_BYTES as u64,cancel)?;
    cancel.check()?;
    if started.elapsed()>=task.timeout{return Err(Error::Timeout);}
    // Ensure predictable cleanup before reporting success; these are exclusively
    // owned private files and no publication occurs in this inference operation.
    for path in [&model,&audio,&json] {fs::remove_file(path).map_err(|_|Error::Io("remove private transcription material"))?;}
    directory.close().map_err(|_|Error::Io("remove private transcription staging"))?;
    Ok(result)
}

#[cfg(all(test,unix))]
mod tests {
    use super::*;
    use std::{path::Path,os::unix::fs::PermissionsExt,time::Duration};
    fn executable(root:&Path,body:&str)->std::path::PathBuf {
        let path=root.join("fake-whisper.sh");fs::write(&path,format!("#!/bin/sh\n{body}\n")).unwrap();
        fs::set_permissions(&path,fs::Permissions::from_mode(0o700)).unwrap();path
    }
    fn execute(body:&str,timeout:Duration)->Result<Vec<u8>> {
        let root=tempfile::tempdir().unwrap();let exe=executable(root.path(),body);
        let info=root.path().join("build.txt");fs::write(&info,b"synthetic native transport fixture").unwrap();
        let cancel=Cancellation::new();let artifact=super::super::fingerprint(&exe,MAX_RUNTIME_BYTES,&cancel).unwrap();
        let build=super::super::fingerprint(&info,MAX_BUILD_INFO_BYTES,&cancel).unwrap();
        let task=WhisperTask{executable:&exe,artifact:&artifact,build_info:&info,build:&build,temp_parent:root.path(),weights:b"FAKE TEST MODEL",samples:&[0;160],language:"en",timeout};
        let result=run_whisper_task(&task,&cancel);
        assert!(fs::read_dir(root.path()).unwrap().all(|e|!e.unwrap().file_name().to_string_lossy().starts_with(".automexia-transcript-")),"owned inference directory leaked");
        result
    }
    #[test]fn native_transport_uses_owned_files_and_cleans_success(){
        let result=execute("while [ $# -gt 0 ]; do if [ \"$1\" = --output-file ]; then shift; output=$1; fi; shift; done\nprintf '{\"synthetic\":true}' > \"$output.json\"",Duration::from_secs(5)).unwrap();
        assert_eq!(result,b"{\"synthetic\":true}");
    }
    #[test]fn nonzero_child_exit_is_not_a_transcript(){assert!(matches!(execute("exit 7",Duration::from_secs(5)),Err(Error::ToolFailed{tool:"whisper.cpp",exit_code:Some(7)})));}
    #[test]fn child_timeout_cleans_private_weights_and_audio(){assert!(matches!(execute("sleep 3",Duration::from_millis(50)),Err(Error::Timeout)));}
    #[test]fn executable_mutation_is_rejected_before_execution(){
        let root=tempfile::tempdir().unwrap();let exe=executable(root.path(),"exit 0");let info=root.path().join("build.txt");fs::write(&info,b"fixture").unwrap();
        let cancel=Cancellation::new();let artifact=super::super::fingerprint(&exe,MAX_RUNTIME_BYTES,&cancel).unwrap();let build=super::super::fingerprint(&info,MAX_BUILD_INFO_BYTES,&cancel).unwrap();
        fs::write(&exe,b"changed").unwrap();let task=WhisperTask{executable:&exe,artifact:&artifact,build_info:&info,build:&build,temp_parent:root.path(),weights:b"fake",samples:&[0;16],language:"en",timeout:Duration::from_secs(5)};
        assert_eq!(run_whisper_task(&task,&cancel),Err(Error::ToolIdentityChanged));
    }
    #[test]fn cancelled_request_does_not_create_staging(){
        let cancel=Cancellation::new();cancel.cancel();let stamp=crate::host::FileStamp{size:1,modified_ns:None,sha256:"a".repeat(64),file_id:None};
        let task=WhisperTask{executable:Path::new("/does-not-exist"),artifact:&stamp,build_info:Path::new("/does-not-exist"),build:&stamp,temp_parent:Path::new("/does-not-exist"),weights:b"fake",samples:&[0],language:"en",timeout:Duration::from_secs(1)};
        assert_eq!(run_whisper_task(&task,&cancel),Err(Error::Cancelled));
    }
}
