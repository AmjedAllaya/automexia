//! Reuse the native adapter's pinned tools, bounded capture and cancellation.
use super::*;
pub(super) fn run(host:&NativeMediaHost,task:&crate::hdr::HdrTask,cancel:&Cancellation,progress:&mut ProgressSink<'_>)->Result<ToolOutput>{
    cancel.check()?;host.revalidate_input(task.input(),cancel)?;if let Some(input)=task.additional_input(){host.revalidate_input(input,cancel)?;}
    let (ffmpeg,ffprobe)=host.pinned(cancel)?;let tool=if task.tool_name()=="ffprobe"{&ffprobe}else{&ffmpeg};
    if let Some(output)=task.output(){super::guard_task_output(output,std::iter::once(task.input().canonical_path.as_path()).chain(task.additional_input().map(|input|input.canonical_path.as_path())))?;}
    let args=task.arguments()?;let mode=if task.output().is_some(){CaptureMode::Progress}else{CaptureMode::Probe};
    let watch=task.output().map(|path|(path.to_owned(),host.settings.max_output_bytes));
    let stdout=host.execute(tool,task.tool_name(),&args,task.timeout().min(host.settings.render_timeout),mode,watch,cancel,progress)?;
    host.revalidate_input(task.input(),cancel)?;if let Some(input)=task.additional_input(){host.revalidate_input(input,cancel)?;}cancel.check()?;
    Ok(ToolOutput{stdout})
}
