//! The only native subprocess transport. All operations use bounded byte pipes;
//! frames/PCM are consumed directly, never carried in JSON control events.
use crate::{Cancellation,Error,Result};
use crate::host::ProgressSink;
use crate::media::MAX_PROBE_BYTES;
use crate::progress::ProgressParser;
use std::{ffi::OsString,fs,io::Read,path::{Path,PathBuf},process::{Child,Command,Stdio},
    sync::mpsc,thread,time::{Duration,Instant}};

pub(super) const PIPE_QUEUE_SLOTS:usize=16;
pub(super) const PIPE_CHUNK_BYTES:usize=8192;
const MAX_ARGUMENTS:usize=4096;
const MAX_ARGUMENT_BYTES:usize=4*1024*1024;
fn validate_arguments(args:&[OsString])->Result<()> {
    if args.len()>MAX_ARGUMENTS{return Err(Error::LimitExceeded("media argument count"));}
    let mut total=0usize;
    for arg in args {
        let bytes=arg.as_encoded_bytes();
        if bytes.contains(&0){return Err(Error::InvalidInput("NUL in media argument"));}
        total=total.checked_add(bytes.len()).and_then(|n|n.checked_add(1)).ok_or(Error::LimitExceeded("media arguments"))?;
        if total>MAX_ARGUMENT_BYTES{return Err(Error::LimitExceeded("media arguments"));}
    } Ok(())
}
#[derive(Clone,Copy)]pub(super) enum CaptureMode{Probe,Text,Progress,Metrics,Loudness}
enum Chunk{Data(bool,Vec<u8>),Eof,Failed}
struct ChildGuard{child:Child,stopped:bool}
impl ChildGuard {
    fn stop(&mut self){
        if self.stopped{return;}self.stopped=true;
        #[cfg(unix)] {use nix::{sys::signal::{killpg,Signal},unistd::Pid};let _=killpg(Pid::from_raw(self.child.id() as i32),Signal::SIGKILL);}
        let _=self.child.kill();let _=self.child.wait();
    }
}
impl Drop for ChildGuard{fn drop(&mut self){self.stop();}}
pub(super) fn run_process(path:&Path,name:&'static str,args:&[OsString],timeout:Duration,mode:CaptureMode,watch:Option<(PathBuf,u64)>,cancel:&Cancellation,progress:&mut ProgressSink<'_>)->Result<Vec<u8>>{
    run_process_stream(path,name,args,timeout,mode,watch,cancel,progress,None)
}
pub(super) fn run_process_stream(path:&Path,name:&'static str,args:&[OsString],timeout:Duration,mode:CaptureMode,watch:Option<(PathBuf,u64)>,cancel:&Cancellation,progress:&mut ProgressSink<'_>,stream:Option<&mut dyn FnMut(&[u8])->Result<()>>)->Result<Vec<u8>>{
    run_process_dual_stream(path,name,args,timeout,mode,watch,cancel,progress,stream,None)
}
pub(super) fn run_process_dual_stream(path:&Path,name:&'static str,args:&[OsString],timeout:Duration,mode:CaptureMode,watch:Option<(PathBuf,u64)>,cancel:&Cancellation,progress:&mut ProgressSink<'_>,mut stream:Option<&mut dyn FnMut(&[u8])->Result<()>>,mut diagnostics:Option<&mut dyn FnMut(&[u8])->Result<()>>)->Result<Vec<u8>>{ 
    cancel.check()?;
    if timeout.is_zero(){return Err(Error::InvalidInput("media deadline must be positive"));}
    validate_arguments(args)?;
    check_output_limit(&watch)?;
    let started=Instant::now();
    let mut command=Command::new(path);command.args(args).stdin(Stdio::null()).stdout(Stdio::piped()).stderr(Stdio::piped()).env_clear().env("LC_ALL","C").env("LANG","C");
    #[cfg(windows)] if let Some(root)=std::env::var_os("SystemRoot"){command.env("SystemRoot",root);}
    #[cfg(unix)] {use std::os::unix::process::CommandExt;command.process_group(0);}
    let child=command.spawn().map_err(|_|Error::Io("launch approved media executable"))?;
    let mut guard=ChildGuard{child,stopped:false};
    let stdout=guard.child.stdout.take().ok_or(Error::Io("capture stdout"))?;
    let stderr=guard.child.stderr.take().ok_or(Error::Io("capture stderr"))?;
    let (tx,rx)=mpsc::sync_channel::<Chunk>(PIPE_QUEUE_SLOTS);
    let result=thread::scope(|scope|{
        // Move cleanup ownership INSIDE the scope body. On unwind it must kill
        // the child before thread::scope waits for blocked pipe readers.
        let mut guard=guard;
        // These handles must also unwind inside the body, before implicit joins.
        let rx=rx; let tx=tx;
        for (is_out,mut reader) in [(true,Box::new(stdout) as Box<dyn Read+Send>),(false,Box::new(stderr) as Box<dyn Read+Send>)] {
            let tx=tx.clone();let spawned=thread::Builder::new().name("video-pipe".into()).spawn_scoped(scope,move||{
                let mut buffer=[0u8;PIPE_CHUNK_BYTES];
                loop {match reader.read(&mut buffer){Ok(0)=>{let _=tx.send(Chunk::Eof);break;},Ok(n)=>{if tx.send(Chunk::Data(is_out,buffer[..n].to_vec())).is_err(){break;}},Err(e) if e.kind()==std::io::ErrorKind::Interrupted=>continue,Err(_)=>{let _=tx.send(Chunk::Failed);break;}}}
            });
            if spawned.is_err() {guard.stop();drop(rx);return Err(Error::Io("start bounded pipe reader"));}
        }
        drop(tx);
        let mut ends=0;let mut stdout=Vec::new();let mut captured_stderr=Vec::new();let mut stderr_bytes=0usize;let mut progress_bytes=0usize;let mut parser=ProgressParser::default();
        let body=std::panic::catch_unwind(std::panic::AssertUnwindSafe(||->Result<Vec<u8>>{
            while ends<2 {
                cancel.check()?;check_output_limit(&watch)?;if started.elapsed()>timeout{return Err(Error::Timeout);}
                match rx.recv_timeout(Duration::from_millis(10)) {
                    Ok(Chunk::Eof)=>ends+=1,
                    Ok(Chunk::Failed)=>return Err(Error::Io("read tool output")),
                    Ok(Chunk::Data(false,b))=>{
                        stderr_bytes=stderr_bytes.saturating_add(b.len());
                        if let Some(sink)=diagnostics.as_mut() {
                            std::panic::catch_unwind(std::panic::AssertUnwindSafe(||sink(&b))).map_err(|_|Error::CallbackPanicked)??;
                        } else if stderr_bytes>8*1024*1024{return Err(Error::LimitExceeded("tool diagnostics"));}
                        if matches!(mode,CaptureMode::Loudness){
                            if captured_stderr.len().saturating_add(b.len())>crate::voice_render::MAX_LOUDNESS_BYTES{return Err(Error::LimitExceeded("loudness diagnostics"));}
                            captured_stderr.extend_from_slice(&b);
                        }
                    },
                    Ok(Chunk::Data(true,b))=>match mode {
                        CaptureMode::Metrics=>{
                            let sink=stream.as_mut().ok_or(Error::InvalidInput("missing audio metrics consumer"))?;
                            std::panic::catch_unwind(std::panic::AssertUnwindSafe(||sink(&b))).map_err(|_|Error::CallbackPanicked)??;
                        },
                        CaptureMode::Progress=>{
                            progress_bytes=progress_bytes.saturating_add(b.len());if progress_bytes>32*1024*1024{return Err(Error::LimitExceeded("total progress bytes"));}
                            for event in parser.feed(&b)? {std::panic::catch_unwind(std::panic::AssertUnwindSafe(||progress(event))).map_err(|_|Error::CallbackPanicked)?;}
                        },
                        _=>{if stdout.len().saturating_add(b.len())>MAX_PROBE_BYTES{return Err(Error::LimitExceeded("tool stdout"));}stdout.extend_from_slice(&b);},
                    },
                    Err(mpsc::RecvTimeoutError::Timeout)=>{},
                    Err(mpsc::RecvTimeoutError::Disconnected)=>return Err(Error::Io("tool output channel closed")),
                }
            }
            // EOF can occur before process termination: never wait without a deadline.
            loop {cancel.check()?;check_output_limit(&watch)?;if started.elapsed()>timeout{return Err(Error::Timeout);}
                if let Some(status)=guard.child.try_wait().map_err(|_|Error::Io("wait for media tool"))?{
                    // try_wait reaped the child. Do not signal its numeric PID /
                    // process group again after it becomes eligible for reuse.
                    guard.stopped=true;
                    if !status.success(){return Err(Error::ToolFailed{tool:name,exit_code:status.code()});}return Ok(if matches!(mode,CaptureMode::Loudness){captured_stderr}else{stdout});
                }thread::sleep(Duration::from_millis(10));
            }
        })).unwrap_or(Err(Error::CallbackPanicked));
        guard.stop();drop(rx);body
    });
    result
}

pub(super) fn check_output_limit(watch:&Option<(PathBuf,u64)>)->Result<()>{
    if let Some((path,limit))=watch {
        let m=fs::symlink_metadata(path).map_err(|_|Error::Io("inspect staged output size"))?;
        if m.file_type().is_symlink() || !m.is_file(){return Err(Error::InvalidOutput("staged output is not regular"));}
        if m.len()>*limit{return Err(Error::LimitExceeded("output file size"));}
    }Ok(())
}


#[cfg(test)]
mod tests {
    use super::*;
    #[test] fn queue_is_byte_bounded(){assert_eq!(PIPE_QUEUE_SLOTS*PIPE_CHUNK_BYTES,131072);}
    #[test] fn argument_count_is_bounded(){assert!(validate_arguments(&vec![OsString::from("x");4097]).is_err());}
    #[test] fn argument_bytes_are_bounded(){assert!(validate_arguments(&[OsString::from("x".repeat(MAX_ARGUMENT_BYTES))]).is_err());}
    #[test] fn nul_is_rejected(){assert!(validate_arguments(&[OsString::from("x\0y")]).is_err());}
    #[cfg(unix)]
    #[test] fn readers_unblock_when_consumer_fails(){
        let args=[OsString::from("-c"),OsString::from("while :; do printf 'data\\n'; done")];
        let result=run_process_stream(Path::new("/bin/sh"),"test-only-shell",&args,Duration::from_secs(2),CaptureMode::Metrics,None,&Cancellation::new(),&mut |_|{},Some(&mut |_|Err(Error::InvalidInput("intentional sink rejection"))));
        assert!(matches!(result,Err(Error::InvalidInput(_))));
    }
    #[cfg(unix)]
    #[test] fn callback_panic_stops_child(){
        let args=[OsString::from("-c"),OsString::from("while :; do printf 'data\\n'; done")];
        let result=run_process_stream(Path::new("/bin/sh"),"test-only-shell",&args,Duration::from_secs(2),CaptureMode::Metrics,None,&Cancellation::new(),&mut |_|{},Some(&mut |_|panic!("test sink")));
        assert!(matches!(result,Err(Error::CallbackPanicked)));
    }
    #[cfg(unix)]
    #[test] fn child_with_closed_pipes_still_times_out(){
        let args=[OsString::from("-c"),OsString::from("exec 1>&- 2>&-; sleep 10")];
        let t=Instant::now();let result=run_process(Path::new("/bin/sh"),"test-only-shell",&args,Duration::from_millis(50),CaptureMode::Text,None,&Cancellation::new(),&mut |_|{});
        assert!(matches!(result,Err(Error::Timeout)));assert!(t.elapsed()<Duration::from_secs(3));
    }
}
