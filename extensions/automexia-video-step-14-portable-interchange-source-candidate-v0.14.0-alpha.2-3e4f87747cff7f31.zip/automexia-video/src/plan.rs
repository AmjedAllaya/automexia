use crate::{Error,Result,Rational};
use crate::media::{MediaInfo,SelectedStreams,StreamSelection};
use crate::host::{RuntimeCapabilities,InputFile,OutputPolicy,words};
use serde::{Serialize,Deserialize};
use std::{ffi::OsString,path::{Path,PathBuf}};

#[derive(Debug,Clone,Copy,Default,Serialize,Deserialize,PartialEq,Eq)]
#[serde(tag="mode",content="rate",rename_all="snake_case",deny_unknown_fields)]
pub enum FrameRateMode {#[default] PreserveTimestamps, Constant(Rational)}
#[derive(Debug,Clone,Copy,Default,Serialize,Deserialize)]
#[serde(rename_all="snake_case")]
pub enum SpeedPreset {Fast,#[default] Medium,Slow}
impl SpeedPreset {pub fn as_str(self)->&'static str{match self{Self::Fast=>"fast",Self::Medium=>"medium",Self::Slow=>"slow"}}}
#[derive(Debug,Clone,Serialize,Deserialize)]
#[serde(default,deny_unknown_fields)]
pub struct RenderOptions {
    pub streams:StreamSelection,
    pub frame_rate:FrameRateMode,
    pub crf:u8,
    pub speed:SpeedPreset,
    pub threads:u8,
}
impl Default for RenderOptions {fn default()->Self{Self{streams:StreamSelection::default(),frame_rate:FrameRateMode::PreserveTimestamps,crf:18,speed:SpeedPreset::Medium,threads:2}}}
impl RenderOptions {
    pub fn validate(&self)->Result<()> {
        if self.crf>40{return Err(Error::InvalidInput("CRF must be 0..40"));}
        if self.threads==0||self.threads>16{return Err(Error::InvalidInput("threads must be 1..16"));}
        if let FrameRateMode::Constant(r)=self.frame_rate {
            if !r.positive()||r.as_f64()<1.0||r.as_f64()>240.0||r.denominator()>1_000_000 {
                return Err(Error::InvalidInput("constant frame rate must be 1..240 with a bounded rational denominator"));
            }
        } Ok(())
    }
}
#[derive(Debug,Clone)]
pub struct RenderRequest {pub input:PathBuf,pub output:PathBuf,pub options:RenderOptions,pub output_policy:OutputPolicy}
impl RenderRequest {
    pub fn new(input:impl Into<PathBuf>,output:impl Into<PathBuf>)->Self{
        Self{input:input.into(),output:output.into(),options:RenderOptions::default(),output_policy:OutputPolicy::CreateNew}
    }
}
#[derive(Debug,Clone,Serialize)]
pub struct RenderPlan {
    audio_only:bool,
    delivery:Option<crate::delivery::DeliveryProfile>,
    audio_channels:Option<u32>,
    selected:SelectedStreams,
    options:RenderOptions,
    expected_width:u32,
    expected_height:u32,
    expected_sar:Rational,
    colors:Vec<(String,String)>,
    full_range:bool,
    edited:Option<crate::edit_render::EditRender>,
    proxy:Option<ProxyGeometry>,
    voice:Option<crate::voice_render::VoiceRender>,
    color:Option<crate::color_render::ColorRender>,
    framing:Option<crate::reframe_render::ReframeRender>,
    presentation:Option<crate::presentation_render::PresentationRender>,
    #[serde(skip)]
    presentation_sequence:Option<PathBuf>,
    #[serde(skip)]
    enhanced_audio:Option<PathBuf>,
    pub warnings:Vec<String>,
}
#[derive(Debug,Clone,Serialize)]
pub struct RenderResult {
    pub delivery_profile:Option<crate::delivery::DeliveryProfile>,
    pub output:PathBuf,
    pub input:InputFile,
    pub selected:SelectedStreams,
    pub runtime:RuntimeCapabilities,
    pub output_media:MediaInfo,
    pub warnings:Vec<String>,
    pub full_decode_validated:bool,
}
pub const RENDER_PREFIX:&[&str]=&[
    "-hide_banner","-loglevel","error","-nostdin","-xerror","-max_alloc","268435456",
    "-y","-copyts","-start_at_zero"
];
pub const INPUT_POLICY:&[&str]=&["-protocol_whitelist","file","-format_whitelist","mov,matroska,webm"];
impl RenderPlan {
    pub fn selected(&self)->SelectedStreams{self.selected}
    pub fn dimensions(&self)->(u32,u32){(self.expected_width,self.expected_height)}
    pub fn sample_aspect_ratio(&self)->Rational{self.expected_sar}
    pub fn output_profile(&self)->Option<&crate::delivery::DeliveryProfile>{self.delivery.as_ref()}
    pub fn arguments(&self,input:&Path,staged_output:&Path)->Result<Vec<OsString>>{
        let args=self.base_arguments(input,staged_output)?;
        match &self.delivery{Some(profile)=>profile.encode_arguments(args,self.audio_channels),None=>Ok(args)}
    }
    fn base_arguments(&self,input:&Path,staged_output:&Path)->Result<Vec<OsString>>{
        self.options.validate()?;
        if self.audio_only{return Err(Error::InvalidInput("audio-only plans require a typed audio task"));}
        if input==staged_output{return Err(Error::SameFile);}
        if let Some(edit)=&self.edited{return self.edited_arguments(input,staged_output,edit);}
        let mut a=words(RENDER_PREFIX);
        a.extend(words(&["-threads",&self.options.threads.to_string()]));
        a.extend(words(INPUT_POLICY));a.push("-i".into());a.push(input.as_os_str().to_owned());
        a.extend(words(&["-map",&format!("0:{}",self.selected.video)]));
        if let Some(i)=self.selected.audio{a.extend(words(&["-map",&format!("0:{i}")]));}else{a.push("-an".into());}
        a.extend(words(&["-map_metadata","-1","-map_chapters","-1","-sn","-dn","-c:v","libx264",
            "-preset",self.options.speed.as_str(),"-crf",&self.options.crf.to_string(),"-pix_fmt","yuv420p",
            "-threads:v",&self.options.threads.to_string(),"-filter_threads","1"]));
        if self.full_range{a.extend(words(&["-vf","scale=in_range=pc:out_range=pc"]));}
        match self.options.frame_rate {
            FrameRateMode::PreserveTimestamps=>a.extend(words(&["-fps_mode:v","passthrough","-enc_time_base:v","demux"])),
            FrameRateMode::Constant(rate)=>a.extend(words(&["-fps_mode:v","cfr","-r:v",&rate.to_string(),"-enc_time_base:v",&rate.inverse()?.to_string()])),
        }
        if !self.colors.is_empty(){a.extend(words(&["-x264-params","videoformat=component"]));}
        for (k,v) in &self.colors {a.push(OsString::from(k.as_str()));a.push(OsString::from(v.as_str()));}
        if self.selected.audio.is_some(){a.extend(words(&["-c:a","aac","-b:a","192k","-threads:a","1"]));}
        a.extend(words(&["-metadata:s:v:0","rotate=0","-avoid_negative_ts","disabled","-movflags","+faststart",
            "-progress","pipe:1","-nostats","-f","mp4"]));
        a.push(staged_output.as_os_str().to_owned());Ok(a)
    }
}

pub fn build_plan(media:&MediaInfo,options:&RenderOptions,runtime:&RuntimeCapabilities)->Result<RenderPlan>{
    build_profile_plan(media,options,runtime,None)
}
pub fn build_profile_plan(media:&MediaInfo,options:&RenderOptions,runtime:&RuntimeCapabilities,delivery:Option<&crate::delivery::DeliveryProfile>)->Result<RenderPlan>{
    options.validate()?;
    if !media.format_names.iter().any(|n|matches!(n.as_str(),"mov"|"matroska"|"webm")){
        return Err(Error::Unsupported("input container; this profile admits MP4/MOV/MKV/WebM"));
    }
    if matches!(options.frame_rate,FrameRateMode::PreserveTimestamps)&&!runtime.supports_demux_time_base {return Err(Error::MissingCapability("demux time-base preservation"));}
    let selected=media.select(options.streams)?;
    let v=media.stream(selected.video)?;
    let (w,h)=(v.width.ok_or(Error::InvalidProbe("video width"))?,v.height.ok_or(Error::InvalidProbe("video height"))?);
    if w==0||h==0||w>16384||h>16384||w as u64*h as u64>67_108_864{return Err(Error::LimitExceeded("video dimensions"));}
    if w%2!=0||h%2!=0{return Err(Error::Unsupported("odd dimensions for H.264 4:2:0; no implicit crop or resize"));}
    let pixel=v.pixel_format.as_deref().ok_or(Error::InvalidProbe("pixel format"))?;
    if !["yuv420p","yuv422p","yuv444p","yuvj420p","yuvj422p","yuvj444p","nv12","gray"].contains(&pixel)
        || v.bits_per_raw_sample.is_some_and(|n|n>8) {
        return Err(Error::Unsupported("this MP4 profile only accepts 8-bit SDR without alpha"));
    }
    if v.color_transfer.as_deref().is_some_and(|s|matches!(s,"smpte2084"|"arib-std-b67"))
        || v.side_data.iter().any(|s|s.get("side_data_type").and_then(serde_json::Value::as_str).is_some_and(|t|t.contains("DOVI")||t.contains("Mastering display")||t.contains("Content light"))) {
        return Err(Error::Unsupported("HDR/Dolby Vision rendering is not qualified for this SDR profile"));
    }
    if v.field_order.as_deref().is_some_and(|s| !matches!(s,"progressive"|"unknown")) {
        return Err(Error::Unsupported("interlaced rendering requires an explicit later deinterlace policy"));
    }
    if let Some(profile)=delivery {profile.check_runtime(runtime,selected.audio.is_some())?;} else {
    if !runtime.encoders.contains("libx264"){return Err(Error::MissingCapability("libx264"));}
    if !runtime.muxers.contains("mp4"){return Err(Error::MissingCapability("mp4 muxer"));}
    if selected.audio.is_some()&&!runtime.encoders.contains("aac"){return Err(Error::MissingCapability("AAC encoder"));}
    }
    if v.time_base.is_none(){return Err(Error::InvalidProbe("video time base"));}
    if let Some(i)=selected.audio {
        let a=media.stream(i)?;
        if a.channels.is_none()||a.channels==Some(0)||a.channels.is_some_and(|n|n>8){return Err(Error::Unsupported("audio channel count for AAC"));}
        if !a.sample_rate.is_some_and(|r|[7350,8000,11025,12000,16000,22050,24000,32000,44100,48000,64000,88200,96000].contains(&r)) {
            return Err(Error::Unsupported("audio sample rate would require explicit resampling"));
        }
    }
    if media.duration.is_some_and(|r|r.as_f64()<=0.0||r.as_f64()>604800.0){return Err(Error::LimitExceeded("media duration"));}
    let angle=v.rotation_degrees()?;
    let sar=v.sample_aspect_ratio.unwrap_or(Rational::new(1,1)?);
    if !sar.positive()||sar.as_f64()<0.01||sar.as_f64()>100.0{return Err(Error::InvalidProbe("sample aspect ratio"));}
    let (expected_width,expected_height,expected_sar)=if angle%180!=0{(h,w,sar.inverse()?)}else{(w,h,sar)};
    let full_range=v.color_range.as_deref()==Some("pc")||pixel.starts_with("yuvj");
    let mut colors=Vec::new();
    for (key,value) in [("-colorspace",&v.color_space),("-color_trc",&v.color_transfer),("-color_primaries",&v.color_primaries)] {
        if let Some(value)=value {
            if value!="unknown"&&value!="unspecified" {
                if value.len()>32||!value.bytes().all(|b|b.is_ascii_alphanumeric()||b==b'-'||b==b'_') {
                    return Err(Error::InvalidProbe("color metadata"));
                }
                colors.push((key.to_owned(),value.clone()));
            }
        }
    }
    if full_range {colors.push(("-color_range".into(),"pc".into()));}
    else if v.color_range.as_deref()==Some("tv"){colors.push(("-color_range".into(),"tv".into()));}
    if delivery.is_some_and(|p|p.format==crate::delivery::DeliveryFormat::ProResMov)&&full_range{return Err(Error::Unsupported("full-range ProRes conversion requires an explicit later range policy"));}
    let mut warnings=vec!["Output is an H.264/AAC MP4 transcode, not a bit-identical copy.".into(),
        "Unselected streams, source chapters and descriptive/location tags are intentionally omitted.".into()];
    if selected.audio.is_none(){warnings.push("No audio stream selected; output is video-only.".into());}
    if pixel!="yuv420p"&&pixel!="yuvj420p"&&!delivery.is_some_and(|p|p.format==crate::delivery::DeliveryFormat::ProResMov){warnings.push("The selected publishing profile converts chroma to 4:2:0.".into());}
    if v.color_space.is_none()||v.color_transfer.is_none(){warnings.push("Some source color metadata is unspecified; no color-space inference is performed.".into());}
    if v.exact_duration().is_none(){warnings.push("Source video duration metadata is absent; duration comparison is unavailable.".into());}
    if let Some(profile)=delivery {
        warnings.remove(0);
        warnings.extend(profile.warnings(selected.audio.and_then(|i|media.stream(i).ok()).and_then(|s|s.sample_rate)));
    }
    Ok(RenderPlan{audio_only:false,delivery:delivery.cloned(),audio_channels:selected.audio.and_then(|i|media.stream(i).ok()).and_then(|s|s.channels),selected,options:options.clone(),expected_width,expected_height,expected_sar,colors,full_range,edited:None,proxy:None,voice:None,color:None,framing:None,presentation:None,presentation_sequence:None,enhanced_audio:None,warnings})
}

/// Check properties before publication. Full decoding is additionally performed
/// by VideoExtension. These checks are not a claim of content-level lip-sync QA.
pub fn validate_output(source:&MediaInfo,output:&MediaInfo,plan:&RenderPlan)->Result<()> {
    let out=output.select(StreamSelection::default())?;
    let v=output.stream(out.video)?;
    let format=plan.delivery.as_ref().map(|p|p.format).unwrap_or(crate::delivery::DeliveryFormat::H264Mp4);
    if !output.format_names.iter().any(|n|if format.is_webm(){n=="webm"||n=="matroska"}else{n=="mov"||n=="mp4"}){return Err(Error::InvalidOutput("container"));}
    if v.pixel_format.as_deref()!=Some(format.pixel_format()) && !(format!=crate::delivery::DeliveryFormat::ProResMov&&v.pixel_format.as_deref()==Some("yuvj420p")){return Err(Error::InvalidOutput("output pixel format"));}
    if !plan.full_range&&v.pixel_format.as_deref()==Some("yuvj420p"){return Err(Error::InvalidOutput("unexpected full-range output"));}
    if v.codec.as_deref()!=Some(format.codec()){return Err(Error::InvalidOutput("video codec"));}
    if (v.width,v.height)!=(Some(plan.expected_width),Some(plan.expected_height)){return Err(Error::InvalidOutput("display dimensions"));}
    if v.rotation_degrees()?!=0{return Err(Error::InvalidOutput("rotation not normalized"));}
    let sar=v.sample_aspect_ratio.unwrap_or(Rational::new(1,1)?);
    let sar_tolerance=if format.is_webm()&&plan.expected_sar.denominator()!=1{1.0/plan.expected_width as f64+0.00001}else{0.00001};
    if (sar.as_f64()-plan.expected_sar.as_f64()).abs()>sar_tolerance{return Err(Error::InvalidOutput("sample aspect ratio"));}
    if out.audio.is_some()!=plan.selected.audio.is_some(){return Err(Error::InvalidOutput("audio stream selection"));}
    let video_count=output.streams.iter().filter(|s|s.kind=="video").count();
    let audio_count=output.streams.iter().filter(|s|s.kind=="audio").count();
    if video_count!=1||audio_count!=(if plan.selected.audio.is_some(){1}else{0})||output.streams.len()!=video_count+audio_count {
        return Err(Error::InvalidOutput("unexpected streams"));
    }
    let input_v=source.stream(plan.selected.video)?;
    // One common input origin; never independently zero video and audio.
    let origin=source.start_time.unwrap_or(Rational::new(0,1)?);
    let tolerance=match plan.options.frame_rate {
        FrameRateMode::Constant(r)=>(2.0/r.as_f64()).max(0.1),
        FrameRateMode::PreserveTimestamps=>0.1,
    };
    let fallback_timing=|stream:&crate::media::StreamInfo|->Result<crate::media::StreamInfo>{
        let mut stream=stream.clone();
        if format.is_webm() && stream.exact_duration().is_none(){stream.duration=output.duration;}
        Ok(stream)
    };
    if let Some(edit)=&plan.edited { check_edited_timing(&fallback_timing(v)?,edit.duration,tolerance)?; } else { check_timing(input_v,v,origin,tolerance)?; }
    if let FrameRateMode::Constant(r)=plan.options.frame_rate {
        let actual=v.average_frame_rate.ok_or(Error::InvalidOutput("CFR metadata"))?;
        if (actual.as_f64()-r.as_f64()).abs()>0.01{return Err(Error::InvalidOutput("constant frame rate"));}
    }
    if let Some(input_index)=plan.selected.audio {
        let a=output.stream(out.audio.ok_or(Error::InvalidOutput("audio missing"))?)?;
        let input_a=source.stream(input_index)?;
        if a.codec.as_deref()!=Some(format.audio_codec())||a.channels!=input_a.channels||a.sample_rate!=input_a.sample_rate.map(|r|format.audio_rate(r)) {
            return Err(Error::InvalidOutput("audio codec, channel count or sample rate"));
        }
        if let (Some(x),Some(y))=(&input_a.channel_layout,&a.channel_layout) {
            if x!=y{return Err(Error::InvalidOutput("audio channel layout changed"));}
        }
        if let Some(edit)=&plan.edited { check_edited_timing(&fallback_timing(a)?,edit.duration,tolerance)?; } else { check_timing(input_a,a,origin,tolerance)?; }
        if plan.edited.is_none() { if let (Some(iv),Some(ia),Some(ov),Some(oa))=(input_v.exact_start(),input_a.exact_start(),v.exact_start(),a.exact_start()) {
            if (ia.checked_sub(iv)?.as_f64()-oa.checked_sub(ov)?.as_f64()).abs()>tolerance {
                return Err(Error::InvalidOutput("relative audio/video start offset"));
            }
        } }
    }
    for (option,expected) in &plan.colors {
        let actual=match option.as_str(){"-colorspace"=>&v.color_space,"-color_trc"=>&v.color_transfer,"-color_primaries"=>&v.color_primaries,"-color_range"=>&v.color_range,_=>continue};
        if actual.as_deref()!=Some(expected.as_str()){
            let prores_missing_range=format==crate::delivery::DeliveryFormat::ProResMov&&option=="-color_range"&&expected=="tv"&&actual.is_none();
            if !prores_missing_range{return Err(Error::InvalidOutput("color metadata changed"));}
        }
    }
    Ok(())
}
fn check_timing(input:&crate::media::StreamInfo,output:&crate::media::StreamInfo,origin:Rational,tolerance:f64)->Result<()> {
    if let Some(d)=input.exact_duration() {
        let actual=output.exact_duration().ok_or(Error::InvalidOutput("stream duration absent"))?;
        if (actual.as_f64()-d.as_f64()).abs()>tolerance{return Err(Error::InvalidOutput("stream duration"));}
    }
    if let Some(s)=input.exact_start() {
        let actual=output.exact_start().ok_or(Error::InvalidOutput("stream start absent"))?;
        if (actual.as_f64()-s.checked_sub(origin)?.as_f64()).abs()>tolerance{return Err(Error::InvalidOutput("stream start offset"));}
    } Ok(())
}

/// Single-source edit/assembly plan from saved, resolved variant intent.
pub fn build_edited_plan(project:&crate::project::Project,variant:&str,current:&MediaInfo,runtime:&RuntimeCapabilities)->Result<RenderPlan>{
    project.validate()?;
    let edit=crate::edit_render::EditRender::from_variant(project,variant)?;
    let source=&project.sources[0];source.check_media(current)?;
    let options=project.variant(variant)?.render.options(source.media.selected());
    let mut plan=build_profile_plan(current,&options,runtime,project.variant(variant)?.output_profile.as_ref())?;
    if matches!(options.frame_rate,FrameRateMode::PreserveTimestamps)&&!runtime.bitstream_filters.contains("setts"){return Err(Error::MissingCapability("setts packet-duration preservation"));}
    let mut required=vec!["settb","setpts","select"];
    if source.media.audio.is_some(){required.extend(["asetpts","aresample","apad","atrim","anull"]);if edit.segments.len()>1{required.extend(["asplit","concat"]);}}
    if plan.full_range {required.push("scale");}
    if edit.join_fades_samples.iter().any(|(a,b)|*a>0||*b>0){required.push("afade");}
    required.extend(edit.required_filters());
    if required.iter().any(|name|!runtime.filters.contains(*name)){return Err(Error::MissingCapability("required edit filters"));}
    // Construct once at planning time too: no oversized graph reaches staging.
    edit.filter_graph(plan.selected.video,plan.selected.audio,plan.full_range)?;
    plan.warnings.push("Saved cuts use one common video-origin timeline. Audio before that origin is discarded; leading/trailing absence is padded with silence.".into());
    plan.warnings.push("Saved times remain exact rationals. Rendering rounds boundaries upward to an audio sample (or microsecond for video-only); video frames remain discrete.".into());
    if edit.requires_branching(){plan.warnings.push("Reviewed speed, dissolve, repeated or reordered entries use verified constant-frame-rate trim branches. Effective entry/global speeds compose multiplicatively; source-time processing is applied before the branches.".into());}
    if edit.sample_rate.is_some()&&edit.segments.iter().any(|s|s.speed!=Rational::new(1,1).unwrap()){plan.warnings.push(crate::edit_render::TEMPO_WARNING.into());}
    if edit.join_fades_samples.iter().any(|(a,b)|*a>0||*b>0) {
        plan.warnings.push("Approved pause-cut joins use the project's short sample-based fades; durations are unchanged. This does not repair music continuity.".into());
    }
    plan.edited=Some(edit);
    plan.voice=crate::voice_render::VoiceRender::from_project(project,runtime)?;
    plan.color=crate::color_render::ColorRender::from_project(project,runtime)?;
    plan.framing=crate::reframe_render::ReframeRender::from_project(project,variant,runtime)?;
    if let Some(framing)=&plan.framing {
        plan.expected_width=framing.settings().target.width;plan.expected_height=framing.settings().target.height;
        plan.expected_sar=Rational::new(1,1)?;
        plan.warnings.push("Variant-local framing uses original source-time keys, square output pixels, and bounded integer raster rounding. Safe zones are editable guides, not burned pixels or platform guarantees.".into());
    }
    plan.presentation=crate::presentation_render::PresentationRender::from_project(project,variant,plan.edited.as_ref().ok_or(Error::InvalidProject("edit plan"))?,crate::reframe::OutputSize::new(plan.expected_width,plan.expected_height)?,plan.expected_sar,runtime)?;
    if plan.presentation.is_some(){plan.warnings.push("Reviewed presentation is source-time editable; generated transparent overlays use an explicit sampled animation clock. No object/face understanding or hidden asset lookup.".into());}
    if plan.color.is_some(){plan.warnings.push("Reviewed constant-per-shot Rec.709 corrections are applied in original source time before cutting; no tone mapping or HDR claim.".into());}
    if plan.voice.is_some(){plan.warnings.push("Classical audio treatment uses a measured constant gain and optional oversampled peak limiter, with the selected channel layout preserved. Separately accepted speech enhancement remains explicit.".into());}
    Ok(plan)
}
impl RenderPlan {
    pub fn framing(&self)->Option<&crate::reframe_render::ReframeRender>{self.framing.as_ref()}
    pub fn edited_timeline(&self)->Option<&crate::edit_render::EditRender>{self.edited.as_ref()}
    fn edited_arguments(&self,input:&Path,output:&Path,edit:&crate::edit_render::EditRender)->Result<Vec<OsString>>{
        let mut source_filters=Vec::new();
        if let Some(color)=&self.color {source_filters.push(color.filter_chain()?);}
        if let Some(framing)=&self.framing {source_filters.push(framing.filter_chain()?);}
        if let Some(p)=&self.presentation {let fades=p.video_filter()?;if !fades.is_empty(){source_filters.push(fades);}}
        let mut graph=if let Some(p)=self.presentation.as_ref().filter(|p|p.source_composition&&p.has_pixels()) {
            if self.presentation_sequence.is_none(){return Err(Error::MissingCapability("prepared private graphics sequence"));}
            let graphics_input=if self.enhanced_audio.is_some(){2}else{1};
            let composite=p.source_composite_graph(self.selected.video,graphics_input,&source_filters.join(","),self.full_range)?;
            let edited=edit.video_filter_graph(self.selected.video,self.full_range,"")?.replacen(&format!("[0:{}]",self.selected.video),"[pres_source]",1);
            format!("{composite};{edited}")
        }else{edit.video_filter_graph(self.selected.video,self.full_range,&source_filters.join(","))?};
        if self.selected.audio.is_some() {graph.push(';');graph.push_str(&self.voice_audio_graph(true)?);}
        if let Some(p)=&self.presentation {
            if p.has_pixels()&&!p.source_composition{
                if self.presentation_sequence.is_none(){return Err(Error::MissingCapability("prepared private graphics sequence"));}
                graph=graph.replacen("[vout]","[pres_base]",1);graph.push(';');
                let mut composite=crate::presentation_render::COMPOSITE_GRAPH.replace("{range}",if self.full_range{"pc"}else{"tv"}).replace("{sar}",&p.sar.to_string());
                if self.enhanced_audio.is_some(){composite=composite.replace("[1:v]","[2:v]");}
                graph.push_str(&composite);
            }
        }
        if graph.len()>48*1024 {return Err(Error::LimitExceeded("combined edit/color filter graph"));}
        if let Some(proxy)=&self.proxy {
            graph=graph.replacen("[vout]","[vproxy]",1);
            graph.push(';');
            graph.push_str(&PROXY_FILTER.replace("{width}",&proxy.width.to_string()).replace("{height}",&proxy.height.to_string())
                .replace("{sar}",&proxy.sar.to_string()));
        }
        let mut a=words(crate::edit_render::EDITED_PREFIX);
        a.extend(words(&["-threads",&self.options.threads.to_string()]));a.extend(words(INPUT_POLICY));
        a.push("-i".into());a.push(input.as_os_str().to_owned());
        if let Some(enhanced)=&self.enhanced_audio {a.extend(words(&["-protocol_whitelist","file","-format_whitelist","wav","-i"]));a.push(enhanced.as_os_str().to_owned());}
        if let Some(sequence)=&self.presentation_sequence {a.extend(words(crate::presentation_render::GRAPHICS_INPUT));a.push(sequence.as_os_str().to_owned());}
        a.extend(words(&["-filter_complex_threads","1","-filter_complex",&graph,"-map","[vout]"]));
        if self.selected.audio.is_some(){a.extend(words(&["-map","[aout]"]));}else{a.push("-an".into());}
        a.extend(words(&["-map_metadata","-1","-map_chapters","-1","-sn","-dn","-c:v","libx264",
            "-preset",self.options.speed.as_str(),"-crf",&self.options.crf.to_string(),"-pix_fmt","yuv420p","-threads:v",&self.options.threads.to_string()]));
        match self.options.frame_rate {
            FrameRateMode::PreserveTimestamps=>a.extend(words(&["-fps_mode:v","passthrough","-enc_time_base:v","1/1000000","-bsf:v",&edit.duration_bitstream_filter()])),
            FrameRateMode::Constant(rate)=>a.extend(words(&["-fps_mode:v","cfr","-r:v",&rate.to_string(),"-enc_time_base:v",&rate.inverse()?.to_string()])),
        }
        if !self.colors.is_empty(){a.extend(words(&["-x264-params","videoformat=component"]));}
        for (k,v) in &self.colors{a.push(k.as_str().into());a.push(v.as_str().into());}
        if self.selected.audio.is_some(){a.extend(words(&["-c:a","aac","-b:a","192k","-threads:a","1"]));}
        a.extend(words(&["-t",&edit.duration_argument()?,"-metadata:s:v:0","rotate=0","-avoid_negative_ts","disabled","-movflags","+faststart","-progress","pipe:1","-nostats","-f","mp4"]));
        a.push(output.as_os_str().to_owned());
        if a.iter().map(|x|x.as_encoded_bytes().len()+1).sum::<usize>()>30*1024{return Err(Error::LimitExceeded("edit command arguments"));}Ok(a)
    }
}
fn check_edited_timing(stream:&crate::media::StreamInfo,duration:Rational,tolerance:f64)->Result<()> {
    let actual=stream.exact_duration().ok_or(Error::InvalidOutput("edited duration missing"))?;
    if !actual.positive() || (actual.as_f64()-duration.as_f64()).abs()>tolerance{return Err(Error::InvalidOutput("edited duration"));}
    let start=stream.exact_start().ok_or(Error::InvalidOutput("edited start missing"))?;
    if start.as_f64().abs()>tolerance{return Err(Error::InvalidOutput("edited start offset"));}Ok(())
}

/// Geometry only for disposable low-resolution review output; normal publishing
/// remains unchanged. Integer calculations preserve display aspect, including SAR.
#[derive(Debug,Clone,Serialize)]
struct ProxyGeometry {width:u32,height:u32,sar:Rational,max_bytes:u64}
pub const PROXY_FILTER:&str="[vproxy]scale=w={width}:h={height}:flags=bilinear,setsar=sar={sar}:max=1000000[vout]";
impl RenderPlan {
    pub fn output_byte_limit(&self)->Option<u64>{self.proxy.as_ref().map(|p|p.max_bytes)}
    pub(crate) fn for_review_proxy(mut self,max_width:u32,max_height:u32,max_bytes:u64,runtime:&RuntimeCapabilities)->Result<Self>{
        if self.edited.is_none(){return Err(Error::InvalidInput("review requires an edited plan"));}
        if !runtime.supports_mp4(self.selected.audio.is_some()){return Err(Error::MissingCapability("H.264/AAC review proxy"));}
        self.delivery=None;
        if !runtime.filters.contains("scale")||!runtime.filters.contains("setsar"){return Err(Error::MissingCapability("review scale/setsar filters"));}
        if max_width<2||max_width>1280||max_height<2||max_height>720||max_bytes<1024||max_bytes>crate::preview::MAX_PROXY_BYTES {
            return Err(Error::InvalidInput("preview geometry or size budget"));
        }
        let (w,h)=(self.expected_width,self.expected_height);
        let factor=Rational::new(i64::from(max_width),i64::from(w))?
            .min(Rational::new(i64::from(max_height),i64::from(h))?).min(Rational::new(1,1)?);
        let width=u32::try_from(i64::from(w)*factor.numerator()/factor.denominator()/2*2).map_err(|_|Error::LimitExceeded("proxy width"))?;
        let height=u32::try_from(i64::from(h)*factor.numerator()/factor.denominator()/2*2).map_err(|_|Error::LimitExceeded("proxy height"))?;
        if width<2||height<2{return Err(Error::Unsupported("source is too narrow for the requested proxy bounds"));}
        let dar=Rational::new(i64::from(w),i64::from(h))?.checked_div(self.expected_sar.inverse()?)?;
        let sar=dar.checked_div(Rational::new(i64::from(width),i64::from(height))?)?;
        if sar.denominator()>1_000_000||sar.numerator()>1_000_000{return Err(Error::Unsupported("proxy pixel aspect exceeds qualified precision"));}
        self.expected_width=width;self.expected_height=height;self.expected_sar=sar;
        self.proxy=Some(ProxyGeometry{width,height,sar,max_bytes});
        self.warnings.push("Disposable low-resolution review proxy; not a final render or an approval.".into());
        Ok(self)
    }
}

impl RenderPlan {
    pub fn voice_processing(&self)->Option<&crate::voice_render::VoiceRender>{self.voice.as_ref()}
    pub(crate) fn voice_processing_mut(&mut self)->Option<&mut crate::voice_render::VoiceRender>{self.voice.as_mut()}
    pub fn voice_audio_graph(&self,final_pass:bool)->Result<String>{
        let edit=self.edited.as_ref().ok_or(Error::InvalidInput("audio operations require an editable project"))?;
        let audio=self.selected.audio.ok_or(Error::Unsupported("no selected audio"))?;
        let (mut pre,mut post)=if let Some(voice)=&self.voice{(voice.pre_filters()?,voice.post_filters()?)}else{(String::new(),String::new())};
        if let Some(p)=&self.presentation{
            if p.source_composition {
                let origin=if self.enhanced_audio.is_some(){Rational::new(0,1)?}else{edit.origin};
                let volume=p.source_volume_filter(origin)?;
                if !volume.is_empty(){pre.push_str(&volume);pre.push(',');}
            }
            post.push_str(&p.volume_filter()?);
        }
        if final_pass {if let Some(voice)=&self.voice{post.push_str(&voice.final_filters(edit.duration)?);}}
        // Enhancement stems are already normalized to project time zero. Keep
        // source-time trim coordinates, but never subtract the media origin twice.
        let mut audio_edit=edit.clone();
        if self.enhanced_audio.is_some(){audio_edit.origin=Rational::new(0,1)?;}
        let mut graph=audio_edit.audio_filter_graph(audio,&pre,&post)?;
        if self.enhanced_audio.is_some(){graph=graph.replace(&format!("[0:{audio}]"),"[1:a:0]");}
        Ok(graph)
    }
    pub(crate) fn inherit_voice_gain(&mut self,reference:&RenderPlan)->Result<()> {
        match (&mut self.voice,&reference.voice) {
            (Some(voice),Some(full)) if voice.profile==full.profile&&voice.rate==full.rate&&voice.layout==full.layout=>{
                voice.gain=Some(full.gain.clone().ok_or(Error::InvalidInput("unmeasured reference audio"))?);Ok(())
            },(None,None)=>Ok(()),_=>Err(Error::InvalidInput("preview audio profile differs from its full-project measurement")),
        }
    }
}

impl RenderPlan {
    pub fn color_processing(&self)->Option<&crate::color_render::ColorRender>{self.color.as_ref()}
}

impl RenderPlan {
    pub fn presentation(&self)->Option<&crate::presentation_render::PresentationRender>{self.presentation.as_ref()}
    pub(crate) fn attach_presentation(&mut self,lease:&dyn crate::presentation_render::PresentationLease)->Result<()> {
        if !lease.sequence_path().is_absolute(){return Err(Error::InvalidInput("canonical graphics sequence path"));}
        self.presentation_sequence=Some(lease.sequence_path().to_owned());Ok(())
    }
}

impl RenderPlan {
    pub fn enhanced_audio_path(&self)->Option<&Path>{self.enhanced_audio.as_deref()}
    pub(crate) fn attach_enhanced_audio(&mut self,path:&Path)->Result<()> {
        if self.selected.audio.is_none(){return Err(Error::Unsupported("enhanced audio requires selected source audio"));}
        if !path.is_absolute()||!path.extension().and_then(|s|s.to_str()).is_some_and(|s|s.eq_ignore_ascii_case("wav")){return Err(Error::InvalidInput("validated enhanced audio path"));}
        self.enhanced_audio=Some(path.to_owned());
        self.warnings.push("Explicit reviewed speech-enhancement stem is used as the source-time audio input; accepted cuts, loudness validation and output authorization remain unchanged.".into());
        Ok(())
    }
}

/// Plan only the accepted audio timeline. Video pixel formats, HDR tags,
/// graphics approval, video encoders, and MP4 timing capabilities do not limit
/// an explicit PCM stem or an audio measurement.
pub fn build_audio_plan(project:&crate::project::Project,variant:&str,current:&MediaInfo,runtime:&RuntimeCapabilities)->Result<RenderPlan>{
    project.validate()?;
    let source=&project.sources[0];source.check_media(current)?;
    let audio=source.media.audio.as_ref().ok_or(Error::Unsupported("no selected audio"))?;
    let channels=audio.channels.ok_or(Error::InvalidProject("audio channels"))?;
    let rate=audio.sample_rate.ok_or(Error::InvalidProject("audio sample rate"))?;
    if !(7350..=96000).contains(&rate){return Err(Error::Unsupported("audio-only sample rate"));}
    crate::voice_render::qualified_layout(channels,audio.channel_layout.as_deref())?;
    let mut audio_project=project.clone();audio_project.settings.color_correction=None;
    for output in &mut audio_project.variants {
        output.output_profile=None;output.framing=None;
        if output.presentation.as_ref().is_some_and(|p|p.volume.is_none()){output.presentation=None;}
        if let Some(p)=&mut output.presentation {p.overlays.clear();p.captions=None;p.fades=None;}
    }
    let edit=crate::edit_render::EditRender::from_audio_variant(&audio_project,variant)?;
    let mut required=vec!["asetpts","aresample","apad","atrim","anull"];
    if edit.segments.len()>1 {required.extend(["asplit","concat"]);}
    if edit.join_fades_samples.iter().any(|(a,b)|*a>0||*b>0){required.push("afade");}
    required.extend(edit.required_filters().into_iter().filter(|name|matches!(*name,"atempo"|"acrossfade"|"asetnsamples"|"asplit"|"atrim"|"asetpts"|"apad"|"concat")));
    if required.iter().any(|name|!runtime.filters.contains(*name)){return Err(Error::MissingCapability("required audio edit filters"));}
    edit.audio_filter_graph(audio.index,"","")?;
    let voice=crate::voice_render::VoiceRender::from_project(&audio_project,runtime)?;
    // Geometry has no effect on the volume-only presentation retained above.
    let presentation=crate::presentation_render::PresentationRender::from_project(&audio_project,variant,&edit,crate::reframe::OutputSize::new(1920,1080)?,Rational::new(1,1)?,runtime)?;
    let mut warnings=vec!["Audio-only plan preserves the selected rate, channel layout and accepted project audio timeline.".into()];
    if edit.segments.iter().any(|s|s.speed!=Rational::new(1,1).unwrap()){warnings.push(crate::edit_render::TEMPO_WARNING.into());}
    Ok(RenderPlan{audio_only:true,delivery:None,audio_channels:Some(channels),selected:source.media.selected(),options:project.variant(variant)?.render.options(source.media.selected()),expected_width:0,expected_height:0,expected_sar:Rational::new(1,1)?,colors:Vec::new(),full_range:false,edited:Some(edit),proxy:None,voice,color:None,framing:None,presentation,presentation_sequence:None,enhanced_audio:None,warnings})
}
