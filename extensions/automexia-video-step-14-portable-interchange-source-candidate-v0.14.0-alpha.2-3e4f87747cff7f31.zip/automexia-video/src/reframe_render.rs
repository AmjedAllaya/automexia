//! Compile trusted typed framing into bounded FFmpeg filters. No user text enters
//! expressions. This chain runs AFTER orientation/shot color and source selection
//! but BEFORE setpts remaps the video to the edited output clock.
use crate::{Error,Rational,Result};
use crate::host::RuntimeCapabilities;
use crate::project::Project;
use crate::reframe::{CropTrack,FramingMode,FramingSettings,SourceGeometry};
use serde::Serialize;

pub const MAX_FRAMING_FILTER_BYTES:usize=20*1024;
// Shared literal templates let independent media checks exercise the recipe;
// they are not substitutes for compiling/executing the Rust adapter.
pub const FIT_FILTER:&str="scale=w={sw}:h={sh}:flags=lanczos:in_range={range}:out_range={range},setsar=1,pad=w={tw}:h={th}:x={x}:y={y}:color={background},setsar=1";
pub const CROP_FILTER:&str="scale=w='ceil(({base_w})*({zoom})/2-0.0000000001)*2':h='ceil(({base_h})*({zoom})/2-0.0000000001)*2':eval=frame:flags=lanczos:in_range={range}:out_range={range},setsar=1,format=pix_fmts={format},crop=w={tw}:h={th}:x='clip(round(({cx})*iw-ow/2),0,iw-ow)':y='clip(round(({cy})*ih-oh/2),0,ih-oh)':exact=1,setsar=1";

// Variable-size scale -> crop is not reliable: crop retains its configured
// input bounds. Animated zoom instead samples an unchanging 4:4:4 source raster
// at the desired normalized viewport and then scales to a fixed square-pixel
// canvas. T is the GEQ timestamp; half-pixel terms align source pixel centers.
pub const ZOOM_FRAME_INIT:&str="0*if(eq(N+1,ld(9)),0,st(1,{cx})+st(2,{cy})+st(3,{zoom})+st(9,N+1))";
pub const ZOOM_SAMPLE_X:&str="clip(ld(1)*W+(X+0.5-W/2)*({norm_w})/ld(3)-0.5,0,W-1)";
pub const ZOOM_SAMPLE_Y:&str="clip(ld(2)*H+(Y+0.5-H/2)*({norm_h})/ld(3)-0.5,0,H-1)";
pub const ZOOM_FILTER:&str="format=pix_fmts={format},geq=lum='{init}+lum({sx},{sy})':cb='{init}+cb({sx},{sy})':cr='{init}+cr({sx},{sy})':interpolation=bilinear,scale=w={tw}:h={th}:flags=lanczos:in_range={range}:out_range={range},setsar=1";

// u is source-tick time, not an inferred frame counter or output time. st/ld is
// local to one evaluated expression. The zero multiplication initializes u.
pub const EASE_EXPRESSION:&str="(0*st(0,clip(({clock}-({start}))/{span},0,1))+{a}+({delta})*ld(0)*ld(0)*ld(0)*(ld(0)*(6*ld(0)-15)+10))";

#[derive(Debug,Clone,Copy,PartialEq,Eq,Serialize)]
#[serde(rename_all="snake_case")]
pub enum FramingBackend { Fit, ConstantZoomCrop, AnimatedViewport }

#[derive(Debug,Clone,Serialize)]
pub struct ReframeRender {
    settings:FramingSettings,source:SourceGeometry,origin:Rational,time_base:Rational,duration:Rational,full_range:bool,
}
impl ReframeRender {
    pub fn from_project(project:&Project,variant:&str,runtime:&RuntimeCapabilities)->Result<Option<Self>>{
        let Some(settings)=project.variant(variant)?.framing.as_ref() else{return Ok(None)};
        settings.ensure_resolved()?;if !settings.active(){return Ok(None);}
        project.check_framing(settings)?;
        let required:&[&str]=match &settings.mode{FramingMode::Fit{..}=>&["scale","setsar","pad"],FramingMode::Crop{track} if track.has_varying_zoom()=>&["scale","setsar","format","geq"],FramingMode::Crop{..}=>&["scale","setsar","format","crop"]};
        if required.iter().any(|n|!runtime.filters.contains(*n)){return Err(Error::MissingCapability("required framing filters"));}
        let source=&project.sources[0];let v=&source.media.video;
        let value=Self{settings:settings.clone(),source:SourceGeometry::from_source(source)?,origin:source.timeline_origin,
            time_base:v.time_base.ok_or(Error::InvalidProject("framing source time base"))?,duration:source.duration,
            full_range:v.color_range.as_deref()==Some("pc")||v.pixel_format.as_deref().is_some_and(|s|s.starts_with("yuvj"))};
        value.filter_chain()?;Ok(Some(value))
    }
    pub fn settings(&self)->&FramingSettings{&self.settings}
    pub fn source_geometry(&self)->SourceGeometry{self.source}
    pub fn backend(&self)->FramingBackend{match &self.settings.mode{
        FramingMode::Fit{..}=>FramingBackend::Fit,
        FramingMode::Crop{track} if track.has_varying_zoom()=>FramingBackend::AnimatedViewport,
        FramingMode::Crop{..}=>FramingBackend::ConstantZoomCrop,
    }}
    pub fn filter_chain(&self)->Result<String>{
        self.settings.target.validate()?;self.settings.limits.validate()?;
        let size=self.settings.target;let range=if self.full_range{"pc"}else{"tv"};
        let result=match &self.settings.mode{
            FramingMode::Fit{anchor,background}=>{
                let g=self.source.fit(size,*anchor,self.settings.limits)?;
                FIT_FILTER.replace("{sw}",&g.scaled_width.to_string()).replace("{sh}",&g.scaled_height.to_string())
                    .replace("{tw}",&size.width.to_string()).replace("{th}",&size.height.to_string())
                    .replace("{x}",&g.content.x.to_string()).replace("{y}",&g.content.y.to_string())
                    .replace("{range}",range).replace("{background}",&background.ffmpeg())
            },
            FramingMode::Crop{track}=>{
                track.validate(self.source,size,self.duration)?;
                let animated=track.has_varying_zoom();let symbol=if animated{"T"}else{"t"};
                let zoom=self.expression(track,|p|p.zoom,symbol)?;let cx=self.expression(track,|p|p.center.x,symbol)?;let cy=self.expression(track,|p|p.center.y,symbol)?;
                let filter=if animated {
                    let(nw,nh)=self.source.base_crop(size)?;
                    // Each GEQ plane/slice has its own expression state. N+1
                    // guarantees initialization on frame zero; registers 1..3
                    // cache only this frame's pose, 9 records its identity. The
                    // interpolation itself uses register 0 exclusively.
                    let init=ZOOM_FRAME_INIT.replace("{cx}",&cx).replace("{cy}",&cy).replace("{zoom}",&zoom);
                    let sx=ZOOM_SAMPLE_X.replace("{cx}",&cx).replace("{norm_w}",&number(nw)).replace("{zoom}",&zoom);
                    let sy=ZOOM_SAMPLE_Y.replace("{cy}",&cy).replace("{norm_h}",&number(nh)).replace("{zoom}",&zoom);
                    ZOOM_FILTER.replace("{init}",&init).replace("{sx}",&sx).replace("{sy}",&sy)
                }else{
                    let(bw,bh)=self.source.cover_size(size)?;
                    CROP_FILTER.replace("{base_w}",&number(bw)).replace("{base_h}",&number(bh))
                        .replace("{zoom}",&zoom).replace("{cx}",&cx).replace("{cy}",&cy)
                };
                filter.replace("{tw}",&size.width.to_string()).replace("{th}",&size.height.to_string())
                    .replace("{range}",range).replace("{format}",if self.full_range{"yuvj444p"}else{"yuv444p"})
            },
        };
        if result.len()>MAX_FRAMING_FILTER_BYTES{return Err(Error::LimitExceeded("framing expression bytes"));}Ok(result)
    }
    fn tick(&self,at:Rational)->Result<i64>{
        let value=self.origin.checked_add(at)?.checked_div(self.time_base)?;
        if value.denominator()!=1{return Err(Error::InvalidProject("crop times must be representable in the source time base"));}
        let tick=value.numerator();if tick.unsigned_abs()>9_007_199_254_740_991{return Err(Error::Unsupported("crop timestamp exceeds exact expression range"));}Ok(tick)
    }
    fn expression(&self,track:&CropTrack,field:fn(crate::reframe::CropPose)->f64,symbol:&str)->Result<String>{
        let clock=format!("round({symbol}*{}/{})",self.time_base.denominator(),self.time_base.numerator());
        let mut result:Option<String>=None;
        // Reverse construction: first matching half-open source shot wins. The
        // last endpoint is held for the rest of each shot. Static fields fold to
        // constants, avoiding unnecessary time expressions or graph growth.
        for shot in track.shots.iter().rev(){
            self.tick(shot.range.start)?;let end=self.tick(shot.range.end)?;
            let last=shot.keyframes.last().ok_or(Error::InvalidProject("empty crop shot"))?;
            let mut local=number(field(last.pose));
            for keys in shot.keyframes.windows(2).rev(){
                let start=self.tick(keys[0].at)?;let stop=self.tick(keys[1].at)?;
                let span=stop.checked_sub(start).ok_or(Error::LimitExceeded("crop interval ticks"))?;
                if span<=0{return Err(Error::InvalidProject("collapsed crop keyframe interval"));}
                let a=field(keys[0].pose);let b=field(keys[1].pose);
                let change=if a==b{number(a)}else{EASE_EXPRESSION.replace("{clock}",&clock).replace("{start}",&start.to_string())
                    .replace("{span}",&span.to_string()).replace("{a}",&number(a)).replace("{delta}",&number(b-a))};
                if change!=local{local=format!("if(lt({clock},{stop}),{change},{local})");}
            }
            // Also check singleton times: a constant field must not conceal an
            // invalid shot time/key time merely because no expression is needed.
            for key in &shot.keyframes{self.tick(key.at)?;}
            result=Some(match result{None=>local,Some(tail) if tail==local=>local,Some(tail)=>format!("if(lt({clock},{end}),{local},{tail})")});
            if result.as_ref().is_some_and(|r|r.len()>MAX_FRAMING_FILTER_BYTES){return Err(Error::LimitExceeded("framing expression bytes"));}
        }
        result.ok_or(Error::InvalidProject("empty crop track"))
    }
}
fn number(v:f64)->String{format!("{v:.12}")}
