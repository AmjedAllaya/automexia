//! Project storage remains with the host. The default library never opens files.
use crate::{Cancellation, Result};
use crate::host::{FileStamp,OutputPolicy};
use crate::project::Project;
use std::path::{Path,PathBuf};
#[derive(Debug,Clone)]
pub struct LoadedProject {pub path:PathBuf,pub stamp:FileStamp,pub project:Project}
#[derive(Debug,Clone)]
pub struct SavedProject {pub path:PathBuf,pub stamp:FileStamp}
pub trait ProjectStore:Send+Sync {
    /// Load bounded JSON from an explicitly selected project. Reading a project
    /// doesn't itself authorize reading any referenced media path.
    fn load_project(&self,path:&Path,cancel:&Cancellation)->Result<LoadedProject>;
    /// Atomic save in the destination filesystem. No partial final JSON, silent
    /// overwrite, source replacement or automatic directory creation.
    fn save_project(&self,project:&Project,path:&Path,policy:&OutputPolicy,cancel:&Cancellation)->Result<SavedProject>;
}
