//! Pause analysis through one optional, typed, streaming host operation.
//! Call on the existing job executor; no private scheduler or model is created.
use crate::observation_cache::{self,ObservationCache,Observation,AnalysisKind,CacheUse,CachedAnalysis};
use crate::{Cancellation, Error, Rational, Result, VideoExtension};
use crate::extension::emit;
use crate::host::{InputFile, MediaHost, ProgressSink, RuntimeCapabilities, words};
use crate::pause::{EnergyAnalyzer, EnergyFrame, PauseReport, PauseSettings, propose_pauses};
use crate::progress::{Progress, Stage};
use crate::project::Project;
use std::{ffi::OsString, path::PathBuf, time::Duration};

pub const ENERGY_FILTER: &str = "aformat=sample_fmts=dblp,asettb=expr=1/{rate},atrim=start_pts={start}:end_pts={end},ametadata=mode=delete,astats=metadata=1:reset=1:measure_perchannel=RMS_level+Peak_level+Number_of_NaNs+Number_of_Infs:measure_overall=Number_of_samples,ametadata=mode=print:file=-:direct=1";
pub const ENERGY_PREFIX: &[&str] = &[
    "-hide_banner","-loglevel","error","-nostdin","-xerror","-max_alloc","268435456",
    "-copyts","-threads","2","-protocol_whitelist","file","-format_whitelist","mov,matroska,webm","-i"
];

/// The host must authorize this inspected input and restrict execution to the
/// generated operation. It must never treat a serialized path as a grant.
#[derive(Debug,Clone)]
pub struct AnalysisDecode {
    input: InputFile, stream: u32, rate: u32, channels: usize,
    origin: Rational, duration: Rational, timeout: Duration,
}
impl AnalysisDecode {
    pub fn from_project(project:&Project,input:InputFile,timeout:Duration)->Result<Self>{
        project.validate()?;
        if project.sources.len()!=1 {return Err(Error::Unsupported("pause cleanup is single-source"));}
        if timeout.is_zero()||timeout>Duration::from_secs(86400){return Err(Error::InvalidInput("analysis deadline"));}
        let s=&project.sources[0];s.check_input(&input)?;
        let a=s.media.audio.as_ref().ok_or(Error::Unsupported("pause cleanup requires selected audio"))?;
        let rate=a.sample_rate.ok_or(Error::InvalidProject("selected audio rate"))?;
        let channels=a.channels.ok_or(Error::InvalidProject("selected audio channel count"))? as usize;
        if !(7350..=192000).contains(&rate)||channels==0||channels>crate::pause::MAX_ENERGY_CHANNELS {
            return Err(Error::Unsupported("analysis rate or channel count"));
        }
        Ok(Self{input,stream:a.index,rate,channels,origin:s.timeline_origin,duration:s.duration,timeout})
    }
    pub fn input(&self)->&InputFile{&self.input}
    pub fn channels(&self)->usize{self.channels}
    pub fn sample_rate(&self)->u32{self.rate}
    pub fn timeout(&self)->Duration{self.timeout}
    pub fn arguments(&self)->Result<Vec<OsString>> {
        let start=self.origin.ceil_units(i64::from(self.rate))?;
        let end=self.origin.checked_add(self.duration)?.ceil_units(i64::from(self.rate))?;
        let filter=ENERGY_FILTER.replace("{rate}",&self.rate.to_string()).replace("{start}",&start.to_string()).replace("{end}",&end.to_string());
        let mut args=words(ENERGY_PREFIX);args.push(self.input.canonical_path.as_os_str().to_owned());
        args.extend(words(&["-map",&format!("0:{}",self.stream),"-vn","-sn","-dn","-filter_threads","1",
            "-af",&filter,"-c:a","pcm_s16le","-threads:a","1","-map_metadata","-1","-f","null","-"]));
        Ok(args)
    }
    pub fn check_runtime(&self,runtime:&RuntimeCapabilities)->Result<()> {
        for filter in ["aformat","asettb","atrim","astats","ametadata"] {
            if !runtime.filters.contains(filter){return Err(Error::MissingCapability("audio analysis filters"));}
        }
        if !runtime.muxers.contains("null")||!runtime.encoders.contains("pcm_s16le") {
            return Err(Error::MissingCapability("null audio analysis sink"));
        }
        Ok(())
    }
}
pub type EnergySink<'a> = dyn FnMut(EnergyFrame)->Result<()> + 'a;
pub trait AudioAnalysisHost: MediaHost {
    /// Ordered native-rate, per-channel frames. No downmix, normalization,
    /// padded gaps or timestamp resets. On any error/cancellation stop the child
    /// and return Err; never return a success containing truncated observations.
    fn stream_energy(&self,request:&AnalysisDecode,cancel:&Cancellation,sink:&mut EnergySink<'_>)->Result<()>;
}
#[derive(Debug,Clone)]
pub struct PauseAnalysisRequest {pub project_file:PathBuf,pub settings:PauseSettings,pub timeout:Duration}
impl PauseAnalysisRequest {
    pub fn new(project_file:impl Into<PathBuf>)->Self{Self{project_file:project_file.into(),settings:PauseSettings::default(),timeout:Duration::from_secs(7200)}}
    fn validate(&self)->Result<()> {
        self.settings.validate()?;
        if !self.project_file.is_absolute()||self.project_file.components().any(|c|matches!(c,std::path::Component::ParentDir))
            || !self.project_file.extension().and_then(|x|x.to_str()).is_some_and(|x|x.eq_ignore_ascii_case("amxv")) {
            return Err(Error::InvalidInput("absolute project location required for pause analysis"));
        }
        if self.timeout.is_zero()||self.timeout>Duration::from_secs(86400){return Err(Error::InvalidInput("analysis deadline"));}
        Ok(())
    }
}
impl<H:MediaHost+AudioAnalysisHost> VideoExtension<H> {
    pub fn analyze_pauses(&self,project:&Project,request:&PauseAnalysisRequest,cancel:&Cancellation,progress:&mut ProgressSink<'_>)->Result<PauseReport>{
        self.analyze_pauses_inner(project,request,None,cancel,progress).map(|v|v.report)
    }
    /// Reuse source observations only; decisions are regenerated against this project.
    pub fn analyze_pauses_cached(&self,project:&Project,request:&PauseAnalysisRequest,cache:&mut ObservationCache,cancel:&Cancellation,progress:&mut ProgressSink<'_>)->Result<CachedAnalysis<PauseReport>>{
        self.analyze_pauses_inner(project,request,Some(cache),cancel,progress)
    }
    fn analyze_pauses_inner(&self,project:&Project,request:&PauseAnalysisRequest,mut cache:Option<&mut ObservationCache>,cancel:&Cancellation,progress:&mut ProgressSink<'_>)->Result<CachedAnalysis<PauseReport>>{
        if let Some(c)=cache.as_mut(){c.live()?;}

        request.validate()?;project.validate()?;crate::pause::check_preserved_fade(project,&request.settings)?;
        if project.sources.len()!=1{return Err(Error::Unsupported("pause cleanup is single-source"));}
        let source=&project.sources[0];
        let audio=source.media.audio.as_ref().ok_or(Error::Unsupported("no audio selected for pause cleanup"))?;
        let rate=audio.sample_rate.ok_or(Error::InvalidProject("audio rate"))?;
        let channels=audio.channels.ok_or(Error::InvalidProject("audio channels"))? as usize;
        let mut analyzer=EnergyAnalyzer::with_timestamp_resolution(rate,channels,source.timeline_origin,source.duration,request.settings.clone(),
            audio.time_base.ok_or(Error::InvalidProject("audio time base"))?)?;
        let path=source.resolve(&request.project_file)?;
        let job=self.begin(cancel)?;let deadline=std::time::Instant::now().checked_add(request.timeout).ok_or(Error::InvalidInput("analysis deadline"))?;let operation_cancel=job.cancel.with_deadline(deadline);emit(progress,Stage::Inspecting)?;
        let input=self.host().inspect_input(&path,&operation_cancel)?;source.check_input(&input)?;
        emit(progress,Stage::RuntimeCheck)?;
        let runtime=self.host().runtime_capabilities(&operation_cancel)?;
        let current=self.probe_path(&input.canonical_path,&operation_cancel,progress)?;source.check_media(&current)?;
        let decode=AnalysisDecode::from_project(project,input.clone(),request.timeout)?;decode.check_runtime(&runtime)?;
        let key=if cache.is_some(){observation_cache::key(project,&input,&runtime,AnalysisKind::PauseV1,&request.settings,&())?}else{None};
        if let (Some(c),Some(k))=(cache.as_mut(),key.as_ref()) {
            if let Some(Observation::Pause(observation))=c.get(k)? {
                self.host().revalidate_input(&input,&operation_cancel)?;operation_cancel.check()?;
                let report=propose_pauses(project,observation,&operation_cancel)?;
                c.live()?;operation_cancel.check()?;
                return Ok(CachedAnalysis{report,cache:CacheUse::Hit});
            }
        }

        self.host().revalidate_input(&input,&operation_cancel)?;emit(progress,Stage::Analyzing)?;
        let mut last_update=Rational::new(-1,1)?;
        self.host().stream_energy(&decode,&operation_cancel,&mut |frame|{
            operation_cancel.check()?;
            let timestamp=Rational::new(frame.pts,i64::from(rate))?.checked_sub(source.timeline_origin)?;
            analyzer.push(frame,&operation_cancel)?;
            if timestamp.checked_sub(last_update)?>=Rational::new(1,1)? {
                let mut event=Progress::stage(Stage::Analyzing);
                event.out_time_us=Some(u64::try_from(timestamp.max(Rational::new(0,1)?).ceil_units(1_000_000)?).map_err(|_|Error::LimitExceeded("analysis progress time"))?);
                std::panic::catch_unwind(std::panic::AssertUnwindSafe(||progress(event))).map_err(|_|Error::CallbackPanicked)?;
                last_update=timestamp;
            }
            Ok(())
        })?;
        operation_cancel.check()?;self.host().revalidate_input(&input,&operation_cancel)?;
        let observations=analyzer.finish(&operation_cancel)?;
        let report=propose_pauses(project,observations.clone(),&operation_cancel)?;operation_cancel.check()?;
        let cache_use=match (cache.as_mut(),key) {
            (Some(c),Some(k))=>c.put(k,&source.fingerprint.sha256,Observation::Pause(observations))?,
            (Some(_),None)=>CacheUse::UnpinnedRuntime,(None,_)=>CacheUse::Disabled,
        };
        operation_cancel.check()?;Ok(CachedAnalysis{report,cache:cache_use})
    }
}
// Keep analysis artifacts in caller-owned memory. No project save, cache write,
// rendering, authorization, or automatic approval happens in analyze_pauses.
