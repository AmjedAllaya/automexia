//! Explicit enhancement publication; all validation precedes the commit point.
use crate::{Cancellation,Error,Result,VideoExtension};
use crate::enhancement::{EnhancementRequest,EnhancementSettings,SpeechEnhancer,VoiceEnhancement,ENHANCEMENT_VERSION,validate_enhanced_media};
use crate::extension::emit;
use crate::host::{MediaHost,OutputPolicy,ProgressSink};
use crate::project::{Project,relative_reference};
use crate::progress::Stage;
use crate::voice_render::{AudioTask,qualified_layout};
use serde::Serialize;
use std::{panic::{catch_unwind,AssertUnwindSafe},path::PathBuf,time::{Duration,Instant}};

#[derive(Debug,Clone)]
pub struct EnhancementRunRequest {
    pub project_file:PathBuf,
    pub output:PathBuf,
    pub output_policy:OutputPolicy,
    pub settings:EnhancementSettings,
    pub timeout:Duration,
}
impl EnhancementRunRequest {
    pub fn new(project_file:impl Into<PathBuf>,output:impl Into<PathBuf>)->Self {
        Self{project_file:project_file.into(),output:output.into(),output_policy:OutputPolicy::CreateNew,settings:EnhancementSettings::default(),timeout:Duration::from_secs(7200)}
    }
}
#[derive(Debug,Clone,Serialize)]
pub struct EnhancementRunResult {pub path:PathBuf,pub enhancement:VoiceEnhancement}

impl<H:MediaHost> VideoExtension<H> {
    /// Produce an explicitly selected enhanced PCM24 stem. The returned project
    /// setting is not applied or saved automatically. A successful publication
    /// always returns its validated receipt, even if cancellation arrives during
    /// the host's atomic commit.
    pub fn enhance_voice(&self,project:&Project,request:&EnhancementRunRequest,provider:&dyn SpeechEnhancer,cancel:&Cancellation,progress:&mut ProgressSink<'_>)->Result<EnhancementRunResult>{
        let job=self.begin(cancel)?;
        crate::voice_render::validate_timeout(request.timeout)?;
        let started=Instant::now();
        let deadline=started.checked_add(request.timeout).ok_or(Error::InvalidInput("enhancer deadline overflow"))?;
        let scoped_cancel=job.cancel.with_deadline(deadline);let cancel=&scoped_cancel;
        let remaining=||->Result<Duration>{let duration=request.timeout.saturating_sub(started.elapsed());if duration.is_zero(){Err(Error::Timeout)}else{Ok(duration)}};
        project.validate()?;request.settings.validate()?;
        if request.settings.mode==crate::enhancement::EnhancementMode::Preserve{return Err(Error::InvalidInput("preserve mode does not run an enhancer"));}
        crate::voice_render::validate_timeout(request.timeout)?;
        if project.sources.len()!=1{return Err(Error::Unsupported("enhancement requires a single selected source"));}
        for path in [&request.project_file,&request.output] {
            if !path.is_absolute()||path.components().any(|part|matches!(part,std::path::Component::ParentDir)) {
                return Err(Error::InvalidInput("absolute project/output paths without traversal required"));
            }
        }
        if !request.project_file.extension().and_then(|s|s.to_str()).is_some_and(|s|s.eq_ignore_ascii_case("amxv")) {
            return Err(Error::InvalidInput("enhancement requires an .amxv project location"));
        }
        if !request.output.extension().and_then(|s|s.to_str()).is_some_and(|s|s.eq_ignore_ascii_case("wav")){return Err(Error::InvalidInput("enhanced stem must be .wav"));}
        crate::presentation::guard_destination(project,&request.project_file,&request.output,&request.output_policy)?;
        let source=&project.sources[0];let source_path=source.resolve(&request.project_file)?;
        emit(progress,Stage::Inspecting)?;cancel.check()?;
        let input=self.host().inspect_input(&source_path,cancel)?;source.check_input(&input)?;
        let current=self.probe_path(&input.canonical_path,cancel,progress)?;source.check_media(&current)?;
        let a=source.media.audio.as_ref().ok_or(Error::Unsupported("speech enhancement requires selected audio"))?;
        let rate=a.sample_rate.ok_or(Error::InvalidProject("audio rate"))?;let channels=a.channels.ok_or(Error::InvalidProject("audio channels"))?;
        let layout=qualified_layout(channels,a.channel_layout.as_deref())?;
        let source_samples=u64::try_from(source.duration.ceil_units(i64::from(rate))?).map_err(|_|Error::LimitExceeded("enhancer source samples"))?;
        let identity=catch_unwind(AssertUnwindSafe(||{provider.revalidate(cancel)?;provider.identity()})).map_err(|_|Error::Io("speech enhancer provider panic"))??;identity.validate()?;
        let lease=self.host().stage_output(&input,&request.output,&request.output_policy,cancel)?;
        let call=EnhancementRequest{source:input.clone(),stream_index:a.index,sample_rate:rate,channels,channel_layout:layout,source_samples,settings:request.settings.clone(),staged_output:lease.path().to_owned(),source_origin:source.timeline_origin,timeout:remaining()?};call.validate()?;
        emit(progress,Stage::EnhancingAudio)?;cancel.check()?;
        let mut callback_error=None;
        let receipt={
            let mut guarded=|event|{if callback_error.is_none()&&catch_unwind(AssertUnwindSafe(||progress(event))).is_err(){callback_error=Some(Error::CallbackPanicked);cancel.cancel();}};
            catch_unwind(AssertUnwindSafe(||provider.enhance(&call,cancel,&mut guarded))).map_err(|_|Error::Io("speech enhancer provider panic"))?
        };
        if let Some(error)=callback_error{return Err(error);}
        let receipt=receipt?;cancel.check()?;remaining()?;
        receipt.validate(&request.settings)?;
        if receipt.identity!=identity{return Err(Error::InvalidOutput("enhancer identity changed during request"));}
        if receipt.sample_rate!=rate||receipt.channels!=channels||receipt.channel_layout!=call.channel_layout||receipt.source_samples!=source_samples{return Err(Error::InvalidOutput("enhancer changed accepted source format"));}
        if receipt.delay_samples!=0{return Err(Error::Unsupported("enhancer must compensate delay before publication"));}
        self.host().revalidate_input(&input,cancel)?;
        let staged_input=self.host().inspect_input(lease.path(),cancel)?;
        let probe=self.host().run_audio(&AudioTask::ProbeStem{input:staged_input.clone()},cancel,&mut |_|{})?;
        let media=crate::media::parse_probe(&probe.stdout)?;validate_enhanced_media(&media,&receipt,source.duration)?;
        self.host().run_audio(&AudioTask::ValidateStem{input:staged_input.clone(),timeout:remaining()?},cancel,&mut |_|{})?;
        // Publication may rename/copy the staged inode. Persist the immutable
        // content identity; staging mtime/inode are not destination authority.
        let mut stamp=staged_input.stamp.clone();stamp.modified_ns=None;stamp.file_id=None;
        let enhancement=VoiceEnhancement{version:ENHANCEMENT_VERSION,source_sha256:source.fingerprint.sha256.clone(),source_stream:a.index,settings:request.settings.clone(),receipt,source_origin:Some(source.timeline_origin),stem_path:relative_reference(&request.output,&request.project_file)?,stem_stamp:stamp};
        enhancement.check_source(source)?;
        self.host().revalidate_input(&staged_input,cancel)?;self.host().revalidate_input(&input,cancel)?;
        catch_unwind(AssertUnwindSafe(||provider.revalidate(cancel))).map_err(|_|Error::Io("speech enhancer provider panic"))??;
        remaining()?;emit(progress,Stage::Publishing)?;cancel.check()?;
        let path=lease.publish(cancel)?;
        // The host's OutputLease contract guarantees the approved destination
        // contains the validated staged bytes. No cancellable/fallible work may
        // turn a successful commit into a reported failure.
        Ok(EnhancementRunResult{path,enhancement})
    }
}
