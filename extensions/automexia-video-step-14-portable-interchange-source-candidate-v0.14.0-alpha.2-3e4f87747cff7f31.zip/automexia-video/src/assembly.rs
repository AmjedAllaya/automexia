//! Reviewed, variant-local assembly of retained intervals from one source.
//!
//! The input is the authoritative chronological timeline produced by
//! `Project::timeline`: manual and generated removals, protections, and locked
//! keep clips have already been resolved. An assembly intersects that timeline;
//! it cannot restore material which the shared source edit removed. Entry order
//! is meaningful, and distinct entries may repeat the same source interval.
use crate::project::{id_ok, ProjectSource, TimeRange, Timeline, TimelineSegment, MAX_RENDER_SEGMENTS};
use crate::timing::PlaybackSpeed;
use crate::{Disposition, Error, Rational, Result};
use serde::{Deserialize, Serialize};
use std::collections::BTreeSet;

/// Bound both saved intent and the expansion performed during assembly.
pub const MAX_ASSEMBLY_CLIPS: usize = 64;

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct AssemblyClip {
    /// Stable within this variant's assembly, including repeated source ranges.
    pub id: String,
    /// Half-open source-time bounds, relative to the selected video origin.
    pub range: TimeRange,
    pub speed: PlaybackSpeed,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct AssemblySettings {
    pub enabled: bool,
    pub disposition: Disposition,
    pub locked: bool,
    /// Authored order. Adjacent or identical entries remain separate joins.
    pub clips: Vec<AssemblyClip>,
}

impl Default for AssemblySettings {
    /// A pending draft. Add at least one explicit clip before saving/applying it.
    fn default() -> Self {
        Self { enabled: true, disposition: Disposition::NeedsReview, locked: false, clips: Vec::new() }
    }
}

impl AssemblySettings {
    pub fn validate(&self) -> Result<()> {
        if self.clips.is_empty() {
            return Err(Error::InvalidProject("assembly requires at least one clip"));
        }
        if self.clips.len() > MAX_ASSEMBLY_CLIPS {
            return Err(Error::LimitExceeded("assembly clips"));
        }
        let mut identities = BTreeSet::new();
        for clip in &self.clips {
            id_ok(&clip.id)?;
            if !identities.insert(clip.id.as_str()) {
                return Err(Error::InvalidProject("duplicate assembly clip identity"));
            }
            clip.range.validate()?;
        }
        Ok(())
    }

    /// Validate saved source bounds even while a proposal is disabled or pending.
    pub fn validate_for_source(&self, source: &ProjectSource) -> Result<()> {
        self.validate()?;
        id_ok(&source.id)?;
        if !source.duration.positive() {
            return Err(Error::InvalidProject("assembly source duration"));
        }
        if self.clips.iter().any(|clip| clip.range.end > source.duration) {
            return Err(Error::InvalidProject("assembly clip exceeds source duration"));
        }
        Ok(())
    }

    pub fn active(&self) -> bool {
        self.enabled && self.disposition == Disposition::AutoApply
    }

    pub fn ensure_resolved(&self) -> Result<()> {
        self.validate()?;
        if self.enabled && self.disposition == Disposition::NeedsReview {
            Err(Error::UnresolvedEdits)
        } else {
            Ok(())
        }
    }

    /// Insert at `index` in authored order. An index equal to the length appends.
    /// The proposed result is validated before replacing the existing settings.
    pub fn insert_clip(&mut self, index: usize, clip: AssemblyClip) -> Result<()> {
        self.edit(|settings| {
            if index > settings.clips.len() {
                return Err(Error::InvalidProject("assembly insert index"));
            }
            if settings.clips.len() >= MAX_ASSEMBLY_CLIPS {
                return Err(Error::LimitExceeded("assembly clips"));
            }
            settings.clips.insert(index, clip);
            Ok(())
        })
    }

    /// Move an existing identity to its final zero-based position. Positions are
    /// measured in the completed list, so moving forward needs no adjustment.
    pub fn move_clip(&mut self, id: &str, final_index: usize) -> Result<()> {
        self.edit(|settings| {
            if final_index >= settings.clips.len() {
                return Err(Error::InvalidProject("assembly move index"));
            }
            let index = settings.clip_index(id)?;
            let clip = settings.clips.remove(index);
            settings.clips.insert(final_index, clip);
            Ok(())
        })
    }

    /// Remove an entry. Removing the last entry is invalid; clear the optional
    /// assembly at the project level to return a variant to its shared timeline.
    pub fn remove_clip(&mut self, id: &str) -> Result<()> {
        self.edit(|settings| {
            let index = settings.clip_index(id)?;
            settings.clips.remove(index);
            Ok(())
        })
    }

    /// Repeat one entry with a distinct stable identity at the insertion index.
    pub fn repeat_clip(&mut self, id: &str, new_id: &str, index: usize) -> Result<()> {
        self.edit(|settings| {
            id_ok(new_id)?;
            if index > settings.clips.len() {
                return Err(Error::InvalidProject("assembly repeat index"));
            }
            if settings.clips.len() >= MAX_ASSEMBLY_CLIPS {
                return Err(Error::LimitExceeded("assembly clips"));
            }
            let mut clip = settings.clips[settings.clip_index(id)?].clone();
            clip.id = new_id.into();
            settings.clips.insert(index, clip);
            Ok(())
        })
    }

    pub fn trim_clip(&mut self, id: &str, range: TimeRange) -> Result<()> {
        self.edit(|settings| {
            let index = settings.clip_index(id)?;
            settings.clips[index].range = range;
            Ok(())
        })
    }

    pub fn set_clip_speed(&mut self, id: &str, speed: PlaybackSpeed) -> Result<()> {
        self.edit(|settings| {
            let index = settings.clip_index(id)?;
            settings.clips[index].speed = speed;
            Ok(())
        })
    }

    fn clip_index(&self, id: &str) -> Result<usize> {
        self.clips.iter().position(|clip| clip.id == id)
            .ok_or(Error::InvalidProject("unknown assembly clip"))
    }

    fn edit(&mut self, apply: impl FnOnce(&mut Self) -> Result<()>) -> Result<()> {
        if self.locked {
            return Err(Error::LockedEdit);
        }
        // A fresh default draft can receive its first clip. Other inputs must
        // already be bounded before cloning their owned strings and entries.
        if !self.clips.is_empty() {
            self.validate()?;
        }
        let mut proposed = self.clone();
        apply(&mut proposed)?;
        proposed.validate()?;
        proposed.disposition = Disposition::NeedsReview;
        *self = proposed;
        Ok(())
    }

    /// Apply before variant-wide timing. The supplied timeline must be the
    /// normal-speed chronological source edit, with no output gaps or overlaps.
    /// Every entry must retain some material after intersecting shared edits.
    /// Fully removed entries fail visibly rather than silently changing intent.
    pub fn apply(&self, timeline: &Timeline, source: &ProjectSource) -> Result<Timeline> {
        self.validate_for_source(source)?;
        self.ensure_resolved()?;
        // Identity also requires a bounded authoritative input; otherwise an
        // inactive proposal could clone an arbitrarily large public Timeline.
        validate_authoritative_timeline(timeline, source)?;
        if !self.active() {
            return Ok(timeline.clone());
        }
        let mut segments = Vec::new();
        let mut cursor = Rational::new(0, 1)?;
        for clip in &self.clips {
            let before = segments.len();
            for retained in &timeline.segments {
                let start = clip.range.start.max(retained.source_range.start);
                let end = clip.range.end.min(retained.source_range.end);
                if start >= end {
                    continue;
                }
                if segments.len() >= MAX_RENDER_SEGMENTS {
                    return Err(Error::LimitExceeded("assembly render segments"));
                }
                let source_range = TimeRange::new(start, end)?;
                let duration = source_range.duration()?.checked_div(clip.speed.ratio())?;
                let output_end = cursor.checked_add(duration)?;
                segments.push(TimelineSegment {
                    source_id: source.id.clone(),
                    source_range,
                    output_range: TimeRange::new(cursor, output_end)?,
                });
                cursor = output_end;
            }
            if segments.len() == before {
                return Err(Error::Unsupported("assembly clip has no material retained by the shared source edit"));
            }
        }
        Ok(Timeline { segments, duration: cursor })
    }
}

fn validate_authoritative_timeline(timeline: &Timeline, source: &ProjectSource) -> Result<()> {
    if timeline.segments.is_empty() {
        return Err(Error::EmptyTimeline);
    }
    if timeline.segments.len() > MAX_RENDER_SEGMENTS {
        return Err(Error::LimitExceeded("assembly input segments"));
    }
    let mut output_cursor = Rational::new(0, 1)?;
    let mut source_end = Rational::new(0, 1)?;
    for segment in &timeline.segments {
        segment.source_range.validate()?;
        segment.output_range.validate()?;
        if segment.source_id != source.id {
            return Err(Error::Unsupported("assembly requires one matching source"));
        }
        if segment.source_range.end > source.duration || segment.source_range.start < source_end {
            return Err(Error::InvalidProject("assembly input must contain chronological retained source ranges"));
        }
        if segment.output_range.start != output_cursor
            || segment.output_range.duration()? != segment.source_range.duration()?
        {
            return Err(Error::InvalidProject("assembly input must have contiguous normal-speed output"));
        }
        source_end = segment.source_range.end;
        output_cursor = segment.output_range.end;
    }
    if timeline.duration != output_cursor {
        return Err(Error::InvalidProject("assembly input duration differs from its segments"));
    }
    Ok(())
}
