//! Portable interchange handoffs. Plans contain actual, inspected media
//! identities and rebuilt relative references; planning never reads or copies a
//! file. A bundle is a stored ZIP64, not a complete `.amxv` project backup.
use crate::{Error, Result};
use crate::host::{InputFile, OutputPolicy};
use crate::interchange::{self, AudioExport, EditRate, ExportDocument, ExportMarker, ExportRequest,
    InterchangeFormat, PathMode, TargetEditor, VisualExport};
use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};
use std::collections::{BTreeMap, BTreeSet};
use std::path::{Path, PathBuf};

pub const DEFAULT_BUNDLE_BYTES: u64 = 64 * 1024 * 1024 * 1024;
pub const MAX_BUNDLE_BYTES: u64 = 512 * 1024 * 1024 * 1024;
pub const MAX_BUNDLE_ENTRIES: usize = 16;
pub const MAX_BUNDLE_METADATA_BYTES: usize = 16 * 1024 * 1024;
pub const MAX_BUNDLE_PATH_BYTES: usize = 240;
fn default_bytes() -> u64 { DEFAULT_BUNDLE_BYTES }

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum BundleVideo { Source, Bake }
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum BundleAudio { Source, BakeStem, Omit }

/// Every generated bake stays in the host's private workspace until the single
/// archive is committed. Replacement is deliberately absent from this request.
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct BundleRequest {
    pub project_file: PathBuf,
    pub destination: PathBuf,
    pub format: InterchangeFormat,
    pub target: TargetEditor,
    pub intended_editor_version: Option<String>,
    pub variant: String,
    pub name: String,
    pub rate: EditRate,
    pub source_start_frames: i64,
    pub record_start_frames: i64,
    pub markers: Vec<ExportMarker>,
    pub video: BundleVideo,
    pub audio: BundleAudio,
    /// Complete stored ZIP64 byte limit, including all metadata and headers.
    #[serde(default = "default_bytes")]
    pub max_total_bytes: u64,
}
impl BundleRequest {
    pub fn new(project_file: impl Into<PathBuf>, destination: impl Into<PathBuf>,
        format: InterchangeFormat, rate: EditRate) -> Self {
        Self { project_file: project_file.into(), destination: destination.into(), format,
            target: TargetEditor::Generic, intended_editor_version: None, variant: "main".into(),
            name: "Automexia edit".into(), rate, source_start_frames: 0, record_start_frames: 0,
            markers: vec![], video: BundleVideo::Source, audio: BundleAudio::Source,
            max_total_bytes: DEFAULT_BUNDLE_BYTES }
    }
    pub fn validate(&self) -> Result<()> {
        interchange::paths::local_path(&self.destination)?;
        if !self.destination.extension().and_then(|s| s.to_str()).is_some_and(|s| s.eq_ignore_ascii_case("zip")) {
            return Err(Error::InvalidInput("portable bundle requires a .zip destination"));
        }
        if !matches!(self.format, InterchangeFormat::Otio | InterchangeFormat::FcpXml) {
            return Err(Error::Unsupported("portable bundles support OTIO and modern FCPXML"));
        }
        if self.max_total_bytes == 0 || self.max_total_bytes > MAX_BUNDLE_BYTES {
            return Err(Error::LimitExceeded("portable bundle byte budget"));
        }
        self.export_request(self.destination.parent().ok_or(Error::InvalidInput("bundle directory"))?).validate()
    }
    pub fn from_json(bytes: &[u8]) -> Result<Self> {
        if bytes.len() > 256 * 1024 { return Err(Error::LimitExceeded("bundle request bytes")); }
        let value = crate::project_json::parse_unique(bytes)?;
        let request: Self = serde_json::from_value(value).map_err(|_| Error::InvalidInput("bundle request schema"))?;
        request.validate()?;
        Ok(request)
    }
    /// Converts reviewed modes into deterministic private destinations. The
    /// caller must retain an exclusive host workspace lease for this root.
    pub fn to_export_request(&self, workspace: &Path) -> Result<ExportRequest> {
        self.validate()?;
        interchange::paths::local_path(workspace)?;
        let request = self.export_request(workspace);
        request.validate()?;
        Ok(request)
    }
    fn export_request(&self, workspace: &Path) -> ExportRequest {
        ExportRequest { project_file: self.project_file.clone(),
            destination: workspace.join(format!("timeline.{}", self.format.extension())),
            output_policy: OutputPolicy::CreateNew, format: self.format, target: self.target,
            intended_editor_version: self.intended_editor_version.clone(), variant: self.variant.clone(),
            name: self.name.clone(), rate: self.rate, source_start_frames: self.source_start_frames,
            record_start_frames: self.record_start_frames, paths: PathMode::RelativeToExport,
            video: match self.video { BundleVideo::Source => VisualExport::Source,
                BundleVideo::Bake => VisualExport::Bake { destination: workspace.join("Media/video.mov") } },
            audio: match self.audio { BundleAudio::Source => AudioExport::Source,
                BundleAudio::BakeStem => AudioExport::BakeStem { destination: workspace.join("Media/audio.wav") },
                BundleAudio::Omit => AudioExport::Omit }, markers: self.markers.clone() }
    }
}

#[derive(Debug, Clone)]
pub struct BundleBytesEntry { name: String, bytes: Vec<u8> }
impl BundleBytesEntry {
    pub fn name(&self) -> &str { &self.name }
    pub fn bytes(&self) -> &[u8] { &self.bytes }
}
#[derive(Debug, Clone)]
pub struct BundleMediaEntry { name: String, inputs: Vec<InputFile> }
impl BundleMediaEntry {
    pub fn name(&self) -> &str { &self.name }
    /// Copy this inspected object; revalidate every alias in `inputs` too.
    pub fn input(&self) -> &InputFile { &self.inputs[0] }
    pub fn inputs(&self) -> &[InputFile] { &self.inputs }
}
#[derive(Debug, Clone)]
pub enum BundleEntry { Bytes(BundleBytesEntry), Media(BundleMediaEntry) }
impl BundleEntry {
    pub fn name(&self) -> &str { match self { Self::Bytes(e) => e.name(), Self::Media(e) => e.name() } }
    pub fn size(&self) -> u64 { match self { Self::Bytes(e) => e.bytes.len() as u64, Self::Media(e) => e.input().stamp.size } }
    pub fn sha256(&self) -> String { match self { Self::Bytes(e) => digest(e.bytes()), Self::Media(e) => e.input().stamp.sha256.clone() } }
}

/// Immutable bounded copy/publication plan. No public constructor accepts
/// arbitrary ZIP entries, replacement policy, or unbound serialized XML.
#[derive(Debug, Clone)]
pub struct BundlePlan {
    destination: PathBuf,
    entries: Vec<BundleEntry>,
    all_inputs: Vec<InputFile>,
    document: ExportDocument,
    total_bytes: u64,
    archive_bytes: u64,
    max_total_bytes: u64,
    manifest_sha256: String,
}
impl BundlePlan {
    pub fn from_document(document: &ExportDocument, request: &BundleRequest) -> Result<Self> {
        request.validate()?;
        let original: ExportRequest = serde_json::from_value(document.report().export_request.clone())
            .map_err(|_| Error::InvalidInput("bundle document request provenance"))?;
        original.validate()?;
        document.validate_destination(&original.destination)?;
        let workspace = original.destination.parent().ok_or(Error::InvalidInput("bundle workspace"))?;
        let expected = request.to_export_request(workspace)?;
        if json_value(&original)? != json_value(&expected)? || document.format() != request.format ||
            document.report().format != request.format || document.report().target != request.target ||
            document.report().intended_editor_version != request.intended_editor_version {
            return Err(Error::InvalidInput("bundle document does not match the reviewed request"));
        }
        if document.report().blocked() { return Err(Error::Unsupported("bundle contains blocking compatibility items")); }
        // Check the independently retained project provenance rather than
        // trusting a detached digest string in copied metadata.
        let project: crate::Project = serde_json::from_value(document.report().source_project.clone())
            .map_err(|_| Error::InvalidProject("bundle project provenance"))?;
        project.validate()?;
        if project.id != document.report().project_id || project.revision != document.report().project_revision ||
            project.decision_digest()? != document.report().decision_sha256 {
            return Err(Error::InvalidProject("bundle decision provenance mismatch"));
        }
        let mut timeline = document.timeline().clone();
        let source = project.sources.first().ok_or(Error::InvalidProject("bundle source provenance"))?;
        match request.video {
            BundleVideo::Source => source.check_input(&timeline.video.file)?,
            BundleVideo::Bake => if timeline.video.file.canonical_path != workspace.join("Media/video.mov") {
                return Err(Error::InvalidInput("bundle visual bake is outside the leased destination"));
            },
        }
        match (request.audio, timeline.audio.as_ref()) {
            (BundleAudio::Omit, Some(_)) => return Err(Error::InvalidInput("omitted bundle audio is still referenced")),
            (BundleAudio::BakeStem, None) => return Err(Error::InvalidInput("bundle audio stem is missing")),
            (BundleAudio::BakeStem, Some(audio)) => if audio.file.canonical_path != workspace.join("Media/audio.wav") {
                return Err(Error::InvalidInput("bundle audio stem is outside the leased destination"));
            },
            (BundleAudio::Source, Some(audio)) if request.video == BundleVideo::Bake => {
                if audio.file.canonical_path != timeline.video.file.canonical_path || audio.file.stamp != timeline.video.file.stamp {
                    return Err(Error::InvalidInput("bundle rendered audio identity differs from visual bake"));
                }
            },
            (BundleAudio::Source, Some(audio)) => source.check_input(&audio.file)?,
            (BundleAudio::Source, None) if source.media.audio.is_some() => return Err(Error::InvalidInput("selected bundle audio is missing")),
            _ => {},
        }
        let mut inputs = vec![timeline.video.file.clone()];
        if let Some(audio) = &timeline.audio { inputs.push(audio.file.clone()); }
        let (media_entries, all_inputs, names) = media_entries(inputs)?;
        if all_inputs.iter().any(|input| input.canonical_path == request.destination || input.canonical_path == request.project_file) {
            return Err(Error::SameFile);
        }
        timeline.video.url = names.get(&timeline.video.file.canonical_path)
            .ok_or(Error::InvalidInput("bundle video identity"))?.clone();
        if let Some(audio) = &mut timeline.audio {
            audio.url = names.get(&audio.file.canonical_path).ok_or(Error::InvalidInput("bundle audio identity"))?.clone();
        }
        timeline.report.warnings.push("This portable archive contains the timeline's referenced media, not a complete .amxv backup. Extract the whole archive together before importing its timeline. Media URLs are relative to that timeline; original paths and private bake paths remain in provenance metadata.".into());
        let rebuilt = ExportDocument::new(timeline, request.format, original.destination.clone())?;
        let timeline_name = format!("timeline.{}", request.format.extension());
        let compatibility = interchange::bounded_json(&serde_json::json!({
            "schema": "automexia-interchange-bundle-compatibility", "version": 1,
            "bundle_request": request, "interchange": rebuilt.report(),
            "application_import_tested": false,
        }))?;
        let mut entries: Vec<BundleEntry> = media_entries.into_iter().map(BundleEntry::Media).collect();
        entries.push(BundleEntry::Bytes(BundleBytesEntry { name: timeline_name.clone(), bytes: rebuilt.bytes().to_vec() }));
        entries.push(BundleEntry::Bytes(BundleBytesEntry { name: "compatibility.json".into(), bytes: compatibility }));
        entries.sort_by(|a, b| a.name().cmp(b.name()));
        let manifest_entries: Vec<_> = entries.iter().map(|entry| {
            let aliases = match entry { BundleEntry::Media(media) => json_value(media.inputs()),
                BundleEntry::Bytes(_) => Ok(serde_json::Value::Null) }?;
            Ok(serde_json::json!({ "path": entry.name(), "size": entry.size(), "sha256": entry.sha256(),
                "kind": match entry { BundleEntry::Media(_) => "media", BundleEntry::Bytes(_) => "metadata" },
                "original_inputs": aliases }))
        }).collect::<Result<Vec<_>>>()?;
        let manifest = interchange::bounded_json(&serde_json::json!({
            "schema": "automexia-interchange-bundle-manifest", "version": 1,
            "archive": "stored_zip64", "timeline": timeline_name,
            "project_id": rebuilt.report().project_id, "project_revision": rebuilt.report().project_revision,
            "decision_sha256": rebuilt.report().decision_sha256, "format": request.format,
            "hash_algorithm": "sha256", "manifest_self_included": false, "entries": manifest_entries,
        }))?;
        let manifest_sha256 = digest(&manifest);
        entries.push(BundleEntry::Bytes(BundleBytesEntry { name: "manifest.json".into(), bytes: manifest }));
        entries.sort_by(|a, b| a.name().cmp(b.name()));
        let (total_bytes, archive_bytes) = validate_entries(&entries, request.max_total_bytes)?;
        Ok(Self { destination: request.destination.clone(), entries, all_inputs, document: rebuilt,
            total_bytes, archive_bytes, max_total_bytes: request.max_total_bytes, manifest_sha256 })
    }
    pub fn destination(&self) -> &Path { &self.destination }
    pub fn entries(&self) -> &[BundleEntry] { &self.entries }
    pub fn all_inputs(&self) -> &[InputFile] { &self.all_inputs }
    pub fn document(&self) -> &ExportDocument { &self.document }
    /// Sum of uncompressed entry bytes; `archive_bytes` includes ZIP overhead.
    pub fn total_bytes(&self) -> u64 { self.total_bytes }
    pub fn archive_bytes(&self) -> u64 { self.archive_bytes }
    pub fn max_total_bytes(&self) -> u64 { self.max_total_bytes }
    pub fn manifest_sha256(&self) -> &str { &self.manifest_sha256 }
}
fn digest(bytes: &[u8]) -> String { format!("{:x}", Sha256::digest(bytes)) }
fn json_value<T: Serialize + ?Sized>(value: &T) -> Result<serde_json::Value> {
    serde_json::to_value(value).map_err(|_| Error::InvalidInput("bundle provenance serialization"))
}
fn safe_extension(path: &Path) -> Result<String> {
    let extension = path.extension().and_then(|s| s.to_str()).ok_or(Error::Unsupported("bundle media requires a known extension"))?.to_ascii_lowercase();
    // Keep a deliberately narrow media handoff profile. Do not give arbitrary
    // input bytes a guessed extension or embed an executable filename.
    if !matches!(extension.as_str(), "mov" | "mp4" | "m4v" | "mkv" | "webm" | "wav") {
        return Err(Error::Unsupported("bundle media extension is outside the local media profile"));
    }
    Ok(extension)
}
fn media_entries(inputs: Vec<InputFile>) -> Result<(Vec<BundleMediaEntry>, Vec<InputFile>, BTreeMap<PathBuf, String>)> {
    if inputs.is_empty() || inputs.len() > MAX_BUNDLE_ENTRIES - 3 { return Err(Error::LimitExceeded("bundle media references")); }
    let mut paths: BTreeMap<PathBuf, InputFile> = BTreeMap::new();
    let mut file_ids: BTreeMap<String, crate::host::FileStamp> = BTreeMap::new();
    let mut sizes: BTreeMap<String, u64> = BTreeMap::new();
    for input in inputs {
        interchange::paths::local_path(&input.canonical_path)?;
        crate::project::ContentFingerprint::from_stamp(&input.stamp)?;
        safe_extension(&input.canonical_path)?;
        if input.stamp.size > MAX_BUNDLE_BYTES { return Err(Error::LimitExceeded("bundle media bytes")); }
        if let Some(existing) = paths.get(&input.canonical_path) {
            if existing.stamp != input.stamp { return Err(Error::InputChanged); }
            continue;
        }
        if let Some(id) = &input.stamp.file_id {
            if id.is_empty() || id.len() > 4096 || id.chars().any(char::is_control) { return Err(Error::InvalidInput("bundle file identity")); }
            if let Some(stamp) = file_ids.get(id) {
                if stamp != &input.stamp { return Err(Error::InputChanged); }
            } else { file_ids.insert(id.clone(), input.stamp.clone()); }
        }
        if let Some(size) = sizes.insert(input.stamp.sha256.clone(), input.stamp.size) {
            if size != input.stamp.size { return Err(Error::InvalidInput("one bundle digest has inconsistent sizes")); }
        }
        paths.insert(input.canonical_path.clone(), input);
    }
    let all_inputs: Vec<InputFile> = paths.into_values().collect();
    let mut groups: BTreeMap<String, Vec<InputFile>> = BTreeMap::new();
    for input in &all_inputs { groups.entry(input.stamp.sha256.clone()).or_default().push(input.clone()); }
    let mut names = BTreeMap::new();
    let mut entries = vec![];
    for (hash, aliases) in groups {
        // Same bytes with different allowed suffixes use the lexically first
        // suffix, deterministically. Full content identity proves deduplication;
        // different stream selections remain in the typed timeline references.
        let extension = aliases.iter().map(|input| safe_extension(&input.canonical_path)).collect::<Result<BTreeSet<_>>>()?
            .into_iter().next().ok_or(Error::InvalidInput("bundle media aliases"))?;
        let name = format!("Media/{hash}.{extension}");
        for input in &aliases { names.insert(input.canonical_path.clone(), name.clone()); }
        entries.push(BundleMediaEntry { name, inputs: aliases });
    }
    Ok((entries, all_inputs, names))
}
fn validate_entries(entries: &[BundleEntry], maximum: u64) -> Result<(u64, u64)> {
    if entries.is_empty() || entries.len() > MAX_BUNDLE_ENTRIES { return Err(Error::LimitExceeded("bundle entry count")); }
    let mut names = BTreeSet::new();
    let mut payload = 0u64;
    let mut metadata = 0usize;
    // Stored ZIP64: each entry has fixed local/central headers and ZIP64 extra
    // fields (148 bytes), two names, plus 98 bytes of archive end structures.
    let mut archive = 98u64;
    for entry in entries {
        validate_member_name(entry.name())?;
        if !names.insert(entry.name().to_ascii_lowercase()) { return Err(Error::InvalidInput("duplicate portable bundle path")); }
        payload = payload.checked_add(entry.size()).ok_or(Error::LimitExceeded("bundle payload bytes"))?;
        archive = archive.checked_add(entry.size()).and_then(|v| v.checked_add(148 + 2 * entry.name().len() as u64))
            .ok_or(Error::LimitExceeded("bundle archive bytes"))?;
        if let BundleEntry::Bytes(bytes) = entry {
            metadata = metadata.checked_add(bytes.bytes.len()).ok_or(Error::LimitExceeded("bundle metadata bytes"))?;
        }
    }
    if metadata > MAX_BUNDLE_METADATA_BYTES { return Err(Error::LimitExceeded("bundle metadata bytes")); }
    if archive > maximum || archive > MAX_BUNDLE_BYTES { return Err(Error::LimitExceeded("complete bundle archive byte budget")); }
    Ok((payload, archive))
}
/// Conservative portable archive paths: no absolute paths, traversal,
/// backslashes, control bytes, URI escapes, Windows drive names or dotfiles.
pub fn validate_member_name(name: &str) -> Result<()> {
    if name.is_empty() || name.len() > MAX_BUNDLE_PATH_BYTES || !name.is_ascii() ||
        name.starts_with('/') || name.ends_with('/') || name.split('/').any(|part|
            part.is_empty() || part.starts_with('.') || part.ends_with('.') ||
            !part.bytes().all(|b| b.is_ascii_alphanumeric() || b"-_.".contains(&b)) ||
            matches!(part.split('.').next().unwrap_or("").to_ascii_uppercase().as_str(),
                "CON" | "PRN" | "AUX" | "NUL" | "COM1" | "COM2" | "COM3" | "COM4" | "COM5" | "COM6" | "COM7" | "COM8" | "COM9" |
                "LPT1" | "LPT2" | "LPT3" | "LPT4" | "LPT5" | "LPT6" | "LPT7" | "LPT8" | "LPT9")) {
        return Err(Error::InvalidInput("unsafe portable bundle member path"));
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    fn input(name: &str, hash: char) -> InputFile {
        InputFile { canonical_path: std::env::temp_dir().join("bundle-domain").join(name),
            stamp: crate::host::FileStamp { size: 100, modified_ns: Some(1), sha256: hash.to_string().repeat(64), file_id: None } }
    }
    #[test] fn identical_references_have_one_copy_and_one_identity() {
        let file = input("one.mov", 'a');
        let (entries, inputs, names) = media_entries(vec![file.clone(), file.clone()]).unwrap();
        assert_eq!(entries.len(), 1); assert_eq!(inputs.len(), 1); assert_eq!(names.len(), 1);
        assert_eq!(entries[0].input().canonical_path, file.canonical_path);
    }
    #[test] fn content_aliases_keep_every_identity_and_deduplicate_bytes() {
        let one = input("one.MOV", 'a'); let two = input("two.mp4", 'a');
        let (entries, inputs, names) = media_entries(vec![two.clone(), one.clone()]).unwrap();
        assert_eq!(entries.len(), 1); assert_eq!(inputs.len(), 2); assert_eq!(entries[0].inputs().len(), 2);
        assert_eq!(names[&one.canonical_path], names[&two.canonical_path]); assert!(entries[0].name().ends_with(".mov"));
    }
    #[test] fn alias_order_does_not_change_paths_or_primary_identity() {
        let one = input("one.mov", 'a'); let two = input("two.mov", 'a');
        let (a, _, _) = media_entries(vec![one.clone(), two.clone()]).unwrap();
        let (b, _, _) = media_entries(vec![two, one]).unwrap();
        assert_eq!(a[0].name(), b[0].name()); assert_eq!(a[0].input().canonical_path, b[0].input().canonical_path);
    }
    #[test] fn changed_stamp_for_one_path_is_rejected() {
        let a = input("one.mov", 'a'); let mut b = a.clone(); b.stamp.modified_ns = Some(2);
        assert!(matches!(media_entries(vec![a, b]), Err(Error::InputChanged)));
    }
    #[test] fn inconsistent_hardlink_identity_is_rejected() {
        let mut a = input("one.mov", 'a'); let mut b = input("two.mov", 'b');
        a.stamp.file_id = Some("device:42".into()); b.stamp.file_id = a.stamp.file_id.clone();
        assert!(matches!(media_entries(vec![a, b]), Err(Error::InputChanged)));
    }
    #[test] fn same_digest_with_inconsistent_sizes_is_rejected() {
        let a = input("one.mov", 'a'); let mut b = input("two.mov", 'a'); b.stamp.size += 1;
        assert!(media_entries(vec![a, b]).is_err());
    }
    #[test] fn invalid_fingerprint_and_executable_suffix_are_rejected() {
        let mut a = input("one.mov", 'a'); a.stamp.sha256 = "A".repeat(64);
        assert!(media_entries(vec![a]).is_err()); assert!(media_entries(vec![input("evil.exe", 'a')]).is_err());
    }
    #[test] fn zip_headers_are_included_in_budget() {
        let entries = vec![BundleEntry::Bytes(BundleBytesEntry { name: "timeline.otio".into(), bytes: vec![0; 10] })];
        let exact = 98 + 148 + 2 * "timeline.otio".len() as u64 + 10;
        assert_eq!(validate_entries(&entries, exact).unwrap(), (10, exact));
        assert!(validate_entries(&entries, exact - 1).is_err());
    }
    #[test] fn archive_rejects_case_collisions_and_excessive_entries() {
        let one = BundleEntry::Bytes(BundleBytesEntry { name: "timeline.otio".into(), bytes: vec![0] });
        let two = BundleEntry::Bytes(BundleBytesEntry { name: "TIMELINE.otio".into(), bytes: vec![0] });
        assert!(validate_entries(&[one.clone(), two], MAX_BUNDLE_BYTES).is_err());
        assert!(validate_entries(&vec![one; MAX_BUNDLE_ENTRIES + 1], MAX_BUNDLE_BYTES).is_err());
    }
}
