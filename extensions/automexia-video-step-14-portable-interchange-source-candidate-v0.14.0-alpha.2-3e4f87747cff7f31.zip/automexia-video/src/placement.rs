//! Bounded placement proposals tied to a project revision and owner lifetime.
//! Public diagnostics are descriptive; adoption uses private measured candidates.
use crate::{Cancellation,Error,Result,Rational};
use crate::presentation::{Anchor,Animation,Placement,PresentationSettings,VisualState};
use crate::project::{Project,TimeRange,Disposition};
use crate::reframe::{OutputSize,PixelRect};
use serde::Serialize;
use std::collections::{BTreeMap,BTreeSet};
pub use crate::placement_workflow::PlacementRequest;

#[derive(Debug,Clone,PartialEq,Eq,PartialOrd,Ord,Serialize)]
#[serde(tag="kind",content="id",rename_all="snake_case")]
pub enum PlacementTarget{Overlay(String),Captions}
#[derive(Debug,Clone,Serialize)]
pub struct PlacementChoice{pub target:PlacementTarget,pub anchor:Anchor}
#[derive(Debug,Clone,Serialize)]
pub struct PlacementCandidate{pub anchor:Anchor,pub score:f64,pub use_light_text:bool}
#[derive(Debug,Clone,Serialize)]
pub struct PlacementSuggestion{pub target:PlacementTarget,pub candidates:Vec<PlacementCandidate>,pub sampled_frames:u64}
#[derive(Debug,Clone,Serialize)]
pub struct PlacementReport{
    pub variant_id:String,pub suggestions:Vec<PlacementSuggestion>,pub sampled_frames:u64,
    #[serde(skip)] pub(crate) binding:String,#[serde(skip)] pub(crate) owner:Cancellation,
    #[serde(skip)] pub(crate) accepted:BTreeMap<PlacementTarget,Vec<Anchor>>,
    #[serde(skip)] pub(crate) original_variant:String,
}
impl PlacementReport{
    pub fn apply(&self,project:&mut Project,choices:&[PlacementChoice])->Result<()>{
        self.owner.check()?;if project.decision_digest()?!=self.binding{return Err(Error::InputChanged);}
        if choices.is_empty()||choices.len()>65{return Err(Error::InvalidInput("placement selection count"));}
        let mut seen=BTreeSet::new();for choice in choices{
            if !seen.insert(&choice.target)||!self.accepted.get(&choice.target).is_some_and(|a|a.contains(&choice.anchor)){return Err(Error::InvalidInput("unmeasured placement selection"));}
        }
        let before=project.variant(&self.original_variant)?.presentation.as_ref().ok_or(Error::InvalidProject("placement settings"))?;
        if before.locked{return Err(Error::LockedEdit);}let mut after=before.clone();
        for choice in choices{set_anchor(&mut after,&choice.target,choice.anchor)?;}
        let canvas=canvas(project,&self.original_variant)?;let safe=effective_safe_zone(project,&self.original_variant)?;
        let mut before_layout=before.clone();before_layout.safe_zone=safe;let mut after_layout=after.clone();after_layout.safe_zone=safe;
        after_layout.validate_layout(canvas)?;reject_new_collisions(&before_layout,&after_layout,canvas)?;
        after.disposition=Disposition::NeedsReview;
        self.owner.check()?;project.set_presentation(&self.original_variant,Some(after))
    }
}

#[derive(Clone)]
pub(crate) struct Layer{pub target:PlacementTarget,pub placement:Placement,pub animation:Animation,pub ranges:Vec<TimeRange>}
pub(crate) fn layers(s:&PresentationSettings)->Vec<Layer>{
    let mut out=s.overlays.iter().filter(|o|o.enabled).map(|o|Layer{target:PlacementTarget::Overlay(o.id.clone()),placement:o.placement.clone(),animation:o.animation.clone(),ranges:vec![o.range]}).collect::<Vec<_>>();
    if let Some(c)=&s.captions{if c.burn_in{if let Some(p)=&c.placement{if !c.document.cues.is_empty(){out.push(Layer{target:PlacementTarget::Captions,placement:p.clone(),animation:Animation::default(),ranges:c.document.cues.iter().map(|c|c.range).collect()});}}}}
    out
}
pub(crate) fn canvas(project:&Project,variant:&str)->Result<OutputSize>{
    if let Some(f)=&project.variant(variant)?.framing{if f.enabled&&f.disposition!=Disposition::Ignore{return Ok(f.target);}}
    let source=crate::reframe::SourceGeometry::from_source(&project.sources[0])?;
    // PresentationRender draws on a square-pixel display canvas, then resamples
    // that canvas back to the retained encoded raster and sample aspect ratio.
    let dw=Rational::new(i64::from(source.width),1)?.checked_mul(source.sar)?.nearest_units(1)?;
    let width=u32::try_from(dw.checked_add(1).ok_or(Error::LimitExceeded("placement display width"))?/2*2).map_err(|_|Error::LimitExceeded("placement display width"))?;
    OutputSize::new(width,source.height)
}
pub(crate) fn merged_safe_zone(mut safe:crate::reframe::SafeZone,framing:crate::reframe::SafeZone)->crate::reframe::SafeZone{
    safe.left=safe.left.max(framing.left);safe.right=safe.right.max(framing.right);safe.top=safe.top.max(framing.top);safe.bottom=safe.bottom.max(framing.bottom);safe
}
pub(crate) fn effective_safe_zone(project:&Project,variant:&str)->Result<crate::reframe::SafeZone>{
    let v=project.variant(variant)?;let safe=v.presentation.as_ref().ok_or(Error::InvalidProject("placement presentation"))?.safe_zone;
    Ok(if let Some(f)=v.framing.as_ref().filter(|f|f.enabled&&f.disposition!=Disposition::Ignore){merged_safe_zone(safe,f.safe_zone)}else{safe})
}
pub(crate) fn set_anchor(s:&mut PresentationSettings,target:&PlacementTarget,anchor:Anchor)->Result<()>{
    match target{PlacementTarget::Overlay(id)=>{let o=s.overlays.iter_mut().find(|o|o.enabled&&o.id==*id).ok_or(Error::InvalidInput("unknown placement overlay"))?;o.placement.anchor=anchor;},PlacementTarget::Captions=>{let c=s.captions.as_mut().filter(|c|c.burn_in).ok_or(Error::InvalidInput("unknown placement captions"))?;c.placement.as_mut().ok_or(Error::InvalidProject("caption placement"))?.anchor=anchor;}}Ok(())
}
pub(crate) fn overlap(a:PixelRect,b:PixelRect)->bool{a.x<b.x+b.width&&b.x<a.x+a.width&&a.y<b.y+b.height&&b.y<a.y+a.height}
pub(crate) fn visible_together(a:&Layer,b:&Layer)->bool{a.ranges.iter().any(|a|b.ranges.iter().any(|b|a.start<b.end&&b.start<a.end))}
pub(crate) fn envelope(layer:&Layer,anchor:Anchor,canvas:OutputSize,safe:crate::reframe::SafeZone)->Result<PixelRect>{
    let mut p=layer.placement.clone();p.anchor=anchor;let base=p.rect(canvas,safe)?;layer.animation.check_bounds(base,safe.pixels(canvas)?)?;
    let mut x0=f64::from(base.x);let mut y0=f64::from(base.y);let mut x1=f64::from(base.x+base.width);let mut y1=f64::from(base.y+base.height);
    for k in &layer.animation.keys{let w=f64::from(base.width)*k.scale;let h=f64::from(base.height)*k.scale;let x=f64::from(base.x)+(f64::from(base.width)-w)/2.0+f64::from(k.dx);let y=f64::from(base.y)+(f64::from(base.height)-h)/2.0+f64::from(k.dy);x0=x0.min(x);y0=y0.min(y);x1=x1.max(x+w);y1=y1.max(y+h);}
    Ok(PixelRect{x:x0.floor() as u32,y:y0.floor() as u32,width:x1.ceil() as u32-x0.floor() as u32,height:y1.ceil() as u32-y0.floor() as u32})
}
pub(crate) fn pose_rect(layer:&Layer,anchor:Anchor,at:Rational,canvas:OutputSize,safe:crate::reframe::SafeZone)->Result<PixelRect>{
    let mut p=layer.placement.clone();p.anchor=anchor;let base=p.rect(canvas,safe)?;
    let state=if let Some(range)=layer.ranges.iter().find(|r|r.contains(at)){layer.animation.state(at.checked_sub(range.start)?,range.duration()?)?}else{VisualState{dx:0.0,dy:0.0,scale:1.0,opacity:1.0}};
    let w=f64::from(base.width)*state.scale;let h=f64::from(base.height)*state.scale;
    let x=f64::from(base.x)+(f64::from(base.width)-w)/2.0+state.dx;let y=f64::from(base.y)+(f64::from(base.height)-h)/2.0+state.dy;
    if x<0.0||y<0.0||x+w>f64::from(canvas.width)+1e-8||y+h>f64::from(canvas.height)+1e-8{return Err(Error::InvalidProject("placement animated bounds"));}
    Ok(PixelRect{x:x.floor() as u32,y:y.floor() as u32,width:(x+w).ceil() as u32-x.floor() as u32,height:(y+h).ceil() as u32-y.floor() as u32})
}
pub(crate) fn reject_new_collisions(before:&PresentationSettings,after:&PresentationSettings,canvas:OutputSize)->Result<()>{
    let old=collision_pairs(before,canvas)?;let new=collision_pairs(after,canvas)?;
    if new.difference(&old).next().is_some(){return Err(Error::InvalidProject("placement introduces a visible layer collision"));}Ok(())
}
fn collision_pairs(s:&PresentationSettings,canvas:OutputSize)->Result<BTreeSet<(PlacementTarget,PlacementTarget)>>{
    let layers=layers(s);let mut pairs=BTreeSet::new();for (i,a) in layers.iter().enumerate(){for b in layers.iter().skip(i+1){if visible_together(a,b)&&overlap(envelope(a,a.placement.anchor,canvas,s.safe_zone)?,envelope(b,b.placement.anchor,canvas,s.safe_zone)?){pairs.insert((a.target.clone(),b.target.clone()));}}}Ok(pairs)
}

pub const PLACEMENT_ACTIONS:&[crate::extension::ActionDescriptor]=&[
    crate::extension::ActionDescriptor{id:"video.placement.analyze",label:"Analyze stable graphic and caption placement",writes_output:false},
    crate::extension::ActionDescriptor{id:"video.placement.apply",label:"Adopt selected placement anchors for review",writes_output:false},
];
