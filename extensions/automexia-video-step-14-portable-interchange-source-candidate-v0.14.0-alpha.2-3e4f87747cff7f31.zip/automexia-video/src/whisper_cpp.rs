//! Explicit local whisper.cpp CPU adapter. No model search, downloader, shell,
//! server, Python dependency or automatic executable selection.
use crate::host::FileStamp;
use crate::model_pack::{VerifiedModelPack,ModelIdentity,WHISPER_CONTRACT,WHISPER_PROCESSING};
use crate::transcript::{RecognizedWord,MAX_TRANSCRIPT_SECONDS,MAX_TRANSCRIPT_WORDS};
use crate::transcript_workflow::{Recognition,TranscriptProvider};
use crate::{Cancellation,Error,Rational,Result};
use serde_json::Value;
use std::{path::{Path,PathBuf},sync::atomic::{AtomicBool,Ordering},time::{Duration,Instant}};

pub const WHISPER_ADAPTER:&str="whisper-cpp-1.7.6-cli-cpu-v1";
pub const MAX_TRANSCRIPT_JSON_BYTES:usize=8*1024*1024;
pub const MAX_RUNTIME_BYTES:u64=512*1024*1024;
pub const MAX_BUILD_INFO_BYTES:u64=64*1024;

pub struct WhisperCppProvider {
    pack:VerifiedModelPack,executable:PathBuf,build_info:PathBuf,temp_parent:PathBuf,active:AtomicBool,
}
impl WhisperCppProvider {
    /// All paths are explicit, canonical host-granted local paths. The caller's
    /// selected manifest pins the executable artifact and independently supplied
    /// build-information file. Construction does not execute or load the runtime.
    pub fn new(pack:VerifiedModelPack,executable:PathBuf,build_info:PathBuf,temp_parent:PathBuf)->Result<Self> {
        pack.identity().validate()?;
        if pack.identity().contract!=WHISPER_CONTRACT||pack.identity().preprocessing!=WHISPER_PROCESSING
            || pack.identity().runtime.adapter!=WHISPER_ADAPTER {return Err(Error::Unsupported("whisper.cpp selected adapter contract"));}
        for path in [&executable,&build_info,&temp_parent] {validate_absolute(path)?;}
        Ok(Self{pack,executable,build_info,temp_parent,active:AtomicBool::new(false)})
    }
    fn selected_runtime(&self,cancel:&Cancellation)->Result<(FileStamp,FileStamp)> {
        cancel.check()?;
        for path in [&self.executable,&self.build_info,&self.temp_parent] {
            if std::fs::canonicalize(path).map_err(|_|Error::Io("resolve selected transcription path"))?!=*path {
                return Err(Error::InvalidInput("canonical non-symlink transcription paths required"));
            }
        }
        if !self.temp_parent.is_dir(){return Err(Error::InvalidInput("selected transcription temporary directory"));}
        let artifact=crate::native::fingerprint(&self.executable,MAX_RUNTIME_BYTES,cancel)?;
        let build=crate::native::fingerprint(&self.build_info,MAX_BUILD_INFO_BYTES,cancel)?;
        if artifact.sha256!=self.identity().runtime.artifact_sha256||build.sha256!=self.identity().runtime.build_info_sha256 {
            return Err(Error::ToolIdentityChanged);
        }
        let bytes=crate::native::read_selected_bytes(&self.build_info,MAX_BUILD_INFO_BYTES,cancel)?;
        let text=std::str::from_utf8(&bytes).map_err(|_|Error::InvalidInput("selected whisper build information UTF-8"))?;
        if text.trim().is_empty()||text.contains('\0'){return Err(Error::InvalidInput("selected whisper build information"));}
        if crate::model_pack::digest(&bytes,cancel)?!=build.sha256{return Err(Error::ToolIdentityChanged);}
        Ok((artifact,build))
    }
}
impl TranscriptProvider for WhisperCppProvider {
    fn identity(&self)->&ModelIdentity {self.pack.identity()}
    fn revalidate(&self,cancel:&Cancellation)->Result<()> {self.selected_runtime(cancel).map(|_|())}
    fn recognize(&self,samples:&[i16],language:&str,timeout:Duration,cancel:&Cancellation)->Result<Recognition> {
        crate::transcript::language(language)?;crate::voice_render::validate_timeout(timeout)?;
        if samples.is_empty()||samples.len()>MAX_TRANSCRIPT_SECONDS as usize*16000 {return Err(Error::LimitExceeded("whisper PCM sample count"));}
        cancel.check()?;
        if self.active.compare_exchange(false,true,Ordering::AcqRel,Ordering::Acquire).is_err(){return Err(Error::Busy);}
        let _permit=ProviderPermit(&self.active);
        let started=Instant::now();
        let (artifact,build)=self.selected_runtime(cancel)?;
        let task=WhisperTask{executable:&self.executable,artifact:&artifact,build_info:&self.build_info,build:&build,
            temp_parent:&self.temp_parent,weights:self.pack.weights(),samples,language,timeout};
        let bytes=crate::native::run_whisper_task(&task,cancel)?;
        let result=parse_whisper_json(&bytes,Rational::new(samples.len() as i64,16000)?,language)?;
        self.revalidate(cancel)?;cancel.check()?;
        if started.elapsed()>=timeout{return Err(Error::Timeout);}
        Ok(result)
    }
}
struct ProviderPermit<'a>(&'a AtomicBool);
impl Drop for ProviderPermit<'_>{fn drop(&mut self){self.0.store(false,Ordering::Release);}}
pub(crate) struct WhisperTask<'a> {
    pub executable:&'a Path,pub artifact:&'a FileStamp,pub build_info:&'a Path,pub build:&'a FileStamp,
    pub temp_parent:&'a Path,pub weights:&'a[u8],pub samples:&'a[i16],pub language:&'a str,pub timeout:Duration,
}
fn validate_absolute(path:&Path)->Result<()> {
    if !path.is_absolute()||path.components().any(|c|matches!(c,std::path::Component::ParentDir))
        ||path.as_os_str().as_encoded_bytes().contains(&0){return Err(Error::InvalidInput("absolute selected transcription path"));}Ok(())
}

/// Strict whisper.cpp 1.7.6 full-JSON word-segment contract, generated with
/// --max-len 1 --split-on-word. Offsets are integer milliseconds; timestamps must
/// agree. Probabilities and tokens are retained as word-level minimum confidence.
pub fn parse_whisper_json(bytes:&[u8],audio_duration:Rational,requested_language:&str)->Result<Recognition> {
    if bytes.is_empty()||bytes.len()>MAX_TRANSCRIPT_JSON_BYTES {return Err(Error::LimitExceeded("whisper JSON bytes"));}
    crate::transcript::language(requested_language)?;
    if !audio_duration.positive()||audio_duration>Rational::new(MAX_TRANSCRIPT_SECONDS,1)? {return Err(Error::InvalidInput("whisper audio duration"));}
    let value=crate::project_json::parse_unique(bytes).map_err(|_|Error::InvalidOutput("whisper JSON malformed or duplicate key"))?;
    allowed(&value,&["systeminfo","model","params","result","transcription"])?;
    let model=value.get("model").ok_or(Error::InvalidOutput("whisper model metadata"))?;
    let model_type=model.get("type").and_then(Value::as_str).ok_or(Error::InvalidOutput("whisper model type"))?;
    if !matches!(model_type,"tiny"|"base") {return Err(Error::Unsupported("whisper output model is not tiny/base"));}
    let multilingual=model.get("multilingual").and_then(Value::as_bool).ok_or(Error::InvalidOutput("whisper multilingual model metadata"))?;
    let eot=if multilingual{50257}else{50256};
    let params=value.get("params").ok_or(Error::InvalidOutput("whisper parameter metadata"))?;
    if params.get("translate").and_then(Value::as_bool)!=Some(false) {return Err(Error::Unsupported("whisper translation is not source transcription"));}
    if params.get("language").and_then(Value::as_str)!=Some(requested_language) {return Err(Error::InvalidOutput("whisper requested language changed"));}
    let result=value.get("result").ok_or(Error::InvalidOutput("whisper result metadata"))?;
    allowed(result,&["language"])?;
    let language=result.get("language").and_then(Value::as_str).ok_or(Error::InvalidOutput("whisper result language"))?;
    crate::transcript::language(language)?;
    if language=="auto"||(requested_language!="auto"&&language!=requested_language)||(!multilingual&&language!="en") {
        return Err(Error::InvalidOutput("whisper result language differs from selection"));
    }
    let segments=value.get("transcription").and_then(Value::as_array).ok_or(Error::InvalidOutput("whisper transcription array"))?;
    if segments.len()>MAX_TRANSCRIPT_WORDS {return Err(Error::LimitExceeded("whisper segment count"));}
    let mut words=Vec::new();let mut token_count=0usize;
    for segment in segments {
        allowed(segment,&["timestamps","offsets","text","tokens","speaker"])?;
        if segment.get("speaker").is_some(){return Err(Error::Unsupported("whisper speaker inference is outside the selected contract"));}
        let text=segment.get("text").and_then(Value::as_str).ok_or(Error::InvalidOutput("whisper segment text"))?.trim();
        if text.is_empty(){return Err(Error::InvalidOutput("empty whisper word segment"));}
        if text.split_whitespace().count()!=1 {return Err(Error::InvalidOutput("whisper output did not honor word segmentation"));}
        crate::transcript::word_text(text)?;
        let range=offset_range(segment,false)?.ok_or(Error::InvalidOutput("whisper nonempty word timing"))?;
        let tokens=segment.get("tokens").and_then(Value::as_array).ok_or(Error::InvalidOutput("whisper full token evidence missing"))?;
        if tokens.is_empty()||tokens.len()>256 {return Err(Error::LimitExceeded("whisper word token count"));}
        token_count=token_count.checked_add(tokens.len()).ok_or(Error::LimitExceeded("whisper token count"))?;
        if token_count>65536 {return Err(Error::LimitExceeded("whisper token count"));}
        let mut joined=String::new();let mut probability=1.0f64;let mut lexical_count=0;let mut uncertain=false;
        for token in tokens {
            allowed(token,&["text","timestamps","offsets","id","p","t_dtw"])?;
            let id=token.get("id").and_then(Value::as_u64).filter(|id|*id<51865).ok_or(Error::InvalidOutput("whisper token identity"))?;
            let text=token.get("text").and_then(Value::as_str).ok_or(Error::InvalidOutput("whisper token text"))?;
            if text.len()>crate::transcript::MAX_WORD_BYTES {return Err(Error::LimitExceeded("whisper token text bytes"));}
            let p=token.get("p").and_then(Value::as_f64).filter(|p|p.is_finite()&&(0.0..=1.0).contains(p)).ok_or(Error::InvalidOutput("whisper token confidence"))?;
            if id>=eot {
                if !(text.starts_with("[_")&&text.ends_with(']')&&text.len()<=64
                    &&text[2..text.len()-1].bytes().all(|b|b.is_ascii_alphanumeric()||b==b'_')) {
                    return Err(Error::InvalidOutput("whisper special token text"));
                }
                continue;
            }
            lexical_count+=1;joined.push_str(text);probability=probability.min(p);
            if joined.len()>crate::transcript::MAX_WORD_BYTES {return Err(Error::LimitExceeded("whisper assembled word bytes"));}
            let token_range=offset_range(token,true)?;
            if let Some(token_range)=token_range {
                if token_range.start<range.start||token_range.end>range.end {return Err(Error::InvalidOutput("whisper token lies outside word segment"));}
            }else{uncertain=true;}
        }
        if lexical_count==0||joined.trim()!=text {return Err(Error::InvalidOutput("whisper token text differs from word evidence"));}
        words.push(RecognizedWord{text:text.into(),range,confidence:if uncertain{None}else{Some(probability)}});
    }
    crate::transcript::validate_observations(&words,audio_duration)?;
    Ok(Recognition{language:language.into(),words})
}
fn allowed(value:&Value,keys:&[&str])->Result<()> {
    let object=value.as_object().ok_or(Error::InvalidOutput("whisper JSON object"))?;
    if object.keys().any(|k|!keys.contains(&k.as_str())){return Err(Error::InvalidOutput("unknown whisper output field"));}Ok(())
}
fn offset_range(value:&Value,allow_empty:bool)->Result<Option<crate::project::TimeRange>> {
    let offsets=value.get("offsets").ok_or(Error::InvalidOutput("whisper offset object"))?;allowed(offsets,&["from","to"])?;
    let start=offsets.get("from").and_then(Value::as_i64).filter(|n|*n>=0).ok_or(Error::InvalidOutput("whisper start milliseconds"))?;
    let end=offsets.get("to").and_then(Value::as_i64).filter(|n|*n>=start).ok_or(Error::InvalidOutput("whisper end milliseconds"))?;
    if end>MAX_TRANSCRIPT_SECONDS*1000 {return Err(Error::LimitExceeded("whisper timestamp"));}
    let timestamps=value.get("timestamps").ok_or(Error::InvalidOutput("whisper timestamp object"))?;allowed(timestamps,&["from","to"])?;
    for (key,millis) in [("from",start),("to",end)] {
        let text=timestamps.get(key).and_then(Value::as_str).ok_or(Error::InvalidOutput("whisper display timestamp"))?;
        if crate::subtitles::parse_timestamp(text,crate::subtitles::SubtitleFormat::Srt)?!=Rational::new(millis,1000)? {
            return Err(Error::InvalidOutput("whisper timestamp and offset disagree"));
        }
    }
    if start==end {if allow_empty{return Ok(None);}return Err(Error::InvalidOutput("whisper zero-duration word"));}
    Ok(Some(crate::project::TimeRange::new(Rational::new(start,1000)?,Rational::new(end,1000)?)?))
}

/// Explicit pack loading without a runtime dependency or model discovery.
pub fn read_selected_pack(manifest:&Path,weights:&Path,notices:&Path,expected_manifest:&str,cancel:&Cancellation)->Result<VerifiedModelPack> {
    for path in [manifest,weights,notices]{validate_absolute(path)?;}
    crate::model_pack::hash(expected_manifest)?;
    let metadata=crate::native::read_selected_bytes(manifest,crate::model_pack::MODEL_MANIFEST_LIMIT as u64,cancel)?;
    if crate::model_pack::digest(&metadata,cancel)?!=expected_manifest{return Err(Error::InputChanged);}
    let parsed=crate::model_pack::ModelManifest::from_json(&metadata)?;
    if parsed.contract!=WHISPER_CONTRACT {return Err(Error::Unsupported("selected transcription pack"));}
    let data=crate::native::read_selected_bytes(weights,parsed.weights_bytes,cancel)?;
    let notices=crate::native::read_selected_bytes(notices,256*1024,cancel)?;
    VerifiedModelPack::verify(&metadata,data,&notices,expected_manifest,cancel)
}
