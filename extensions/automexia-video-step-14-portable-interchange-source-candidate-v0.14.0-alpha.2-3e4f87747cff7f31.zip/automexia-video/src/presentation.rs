//! Editable Step-8 presentation data. These values grant no file/network access.
use crate::{Error,Result,Rational};
use crate::project::{Disposition,Project,TimeRange};
use crate::reframe::{OutputSize,SafeZone,PixelRect};
use crate::subtitles::{SubtitleDocument,valid_text};
use serde::{Serialize,Deserialize};
use std::{path::{Path,PathBuf,Component},collections::BTreeSet};
pub const MAX_OVERLAYS:usize=64;
pub const MAX_VISUAL_KEYS:usize=32;
pub const MAX_ASSET_BYTES:u64=16*1024*1024;
pub const MAX_CANVAS_PIXELS:u64=16_777_216;
#[derive(Debug,Clone,PartialEq,Eq,Serialize,Deserialize)]
#[serde(deny_unknown_fields)]
pub struct AssetRef {pub path:PathBuf,pub size:u64,pub sha256:String}
impl AssetRef {
    pub fn validate(&self)->Result<()> {
        let s=self.path.to_str().ok_or(Error::InvalidProject("UTF-8 presentation asset path"))?;
        if s.is_empty()||s.len()>4096||s.contains("://")||s.chars().any(char::is_control)||self.path.components().any(|c|matches!(c,Component::ParentDir)){
            return Err(Error::InvalidProject("selected local presentation asset path"));
        }
        if self.size==0||self.size>MAX_ASSET_BYTES||self.sha256.len()!=64||!self.sha256.bytes().all(|b|b.is_ascii_digit()||(b'a'..=b'f').contains(&b)){
            return Err(Error::InvalidProject("presentation asset fingerprint"));
        }Ok(())
    }
    pub fn resolve(&self,project_file:&Path)->Result<PathBuf>{
        self.validate()?;
        if !project_file.is_absolute(){return Err(Error::InvalidInput("absolute project path for presentation assets"));}
        Ok(if self.path.is_absolute(){self.path.clone()}else{project_file.parent().ok_or(Error::InvalidProject("project parent"))?.join(&self.path)})
    }
}
#[derive(Debug,Clone,PartialEq,Eq,Serialize,Deserialize)]
#[serde(deny_unknown_fields)]
pub struct FontRef {pub asset:AssetRef,pub family:String}
impl FontRef {pub fn validate(&self)->Result<()>{self.asset.validate()?;crate::project::text_ok(&self.family,128)?;
    if self.family.trim().is_empty(){return Err(Error::InvalidProject("explicit font family required"));}Ok(())}}
#[derive(Debug,Clone,Copy,PartialEq,Eq,Serialize,Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Rgba {pub red:u8,pub green:u8,pub blue:u8,pub alpha:u8}
impl Rgba {pub const WHITE:Self=Self{red:255,green:255,blue:255,alpha:255};pub const BLACK:Self=Self{red:0,green:0,blue:0,alpha:255};
    pub fn hex(self)->String{format!("#{:02x}{:02x}{:02x}",self.red,self.green,self.blue)}}
#[derive(Debug,Clone,Copy,PartialEq,Eq,Serialize,Deserialize)]
#[serde(rename_all="snake_case")]
pub enum TextAlign {Left,Center,Right}
#[derive(Debug,Clone,PartialEq,Serialize,Deserialize)]
#[serde(deny_unknown_fields)]
pub struct TextStyle {
    pub font:FontRef,pub font_size:u32,pub line_height:f64,pub foreground:Rgba,
    pub background:Option<Rgba>,pub padding:u32,pub shadow:Option<Rgba>,pub shadow_offset:i32,pub align:TextAlign,
}
impl TextStyle {
    pub fn light(font:FontRef,font_size:u32)->Self{Self{font,font_size,line_height:1.25,foreground:Rgba::WHITE,background:Some(Rgba{alpha:190,..Rgba::BLACK}),padding:12,shadow:None,shadow_offset:2,align:TextAlign::Center}}
    pub fn dark(font:FontRef,font_size:u32)->Self{Self{foreground:Rgba::BLACK,background:Some(Rgba{alpha:220,..Rgba::WHITE}),..Self::light(font,font_size)}}
    pub fn validate(&self)->Result<()>{self.font.validate()?;bounded(self.line_height,1.0,2.0,"text line height")?;
        if !(6..=256).contains(&self.font_size)||self.padding>128||self.shadow_offset.unsigned_abs()>32{return Err(Error::InvalidProject("text dimensions"));}Ok(())}
}
#[derive(Debug,Clone,PartialEq,Serialize,Deserialize)]
#[serde(tag="kind",rename_all="snake_case",deny_unknown_fields)]
pub enum GraphicContent {Text{text:String,style:TextStyle},Image{asset:AssetRef},Svg{asset:AssetRef}}
impl GraphicContent {
    pub fn assets(&self)->Vec<&AssetRef>{match self{Self::Text{style,..}=>vec![&style.font.asset],Self::Image{asset}|Self::Svg{asset}=>vec![asset]}}
    pub fn validate(&self)->Result<()>{match self{
        Self::Text{text,style}=>{valid_text(text,8192,false)?;if text.trim().is_empty()||text.lines().count()>8{return Err(Error::InvalidProject("title text"));}style.validate()},
        Self::Image{asset}|Self::Svg{asset}=>asset.validate(),
    }}
}
#[derive(Debug,Clone,Copy,PartialEq,Eq,PartialOrd,Ord,Serialize,Deserialize)]
#[serde(rename_all="snake_case")]
pub enum Anchor {TopLeft,TopCenter,TopRight,CenterLeft,Center,CenterRight,BottomLeft,BottomCenter,BottomRight}
impl Anchor {pub fn all()->[Self;9]{[Self::TopLeft,Self::TopCenter,Self::TopRight,Self::CenterLeft,Self::Center,Self::CenterRight,Self::BottomLeft,Self::BottomCenter,Self::BottomRight]}}
#[derive(Debug,Clone,PartialEq,Serialize,Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Placement {pub anchor:Anchor,pub width:u32,pub height:u32,pub margin:u32}
impl Placement {
    pub fn rect(&self,canvas:OutputSize,safe:SafeZone)->Result<PixelRect>{
        let r=safe.pixels(canvas)?;
        if self.width==0||self.height==0||self.margin>256||self.width.checked_add(self.margin*2).is_none_or(|v|v>r.width)||self.height.checked_add(self.margin*2).is_none_or(|v|v>r.height){
            return Err(Error::InvalidProject("graphic box does not fit its safe zone"));
        }
        let left=r.x+self.margin;let right=r.x+r.width-self.margin-self.width;let center=r.x+(r.width-self.width)/2;
        let top=r.y+self.margin;let bottom=r.y+r.height-self.margin-self.height;let middle=r.y+(r.height-self.height)/2;
        let x=match self.anchor{Anchor::TopLeft|Anchor::CenterLeft|Anchor::BottomLeft=>left,Anchor::TopRight|Anchor::CenterRight|Anchor::BottomRight=>right,_=>center};
        let y=match self.anchor{Anchor::TopLeft|Anchor::TopCenter|Anchor::TopRight=>top,Anchor::BottomLeft|Anchor::BottomCenter|Anchor::BottomRight=>bottom,_=>middle};
        Ok(PixelRect{x,y,width:self.width,height:self.height})
    }
}
#[derive(Debug,Clone,Copy,PartialEq,Eq,Serialize,Deserialize)]
#[serde(rename_all="snake_case")]
pub enum Easing {Linear,EaseIn,EaseOut,EaseInOut}
impl Easing {
    pub fn value(self,t:f64)->f64{let x=t.clamp(0.0,1.0);match self{Self::Linear=>x,Self::EaseIn=>x*x,Self::EaseOut=>1.0-(1.0-x)*(1.0-x),Self::EaseInOut=>x*x*(3.0-2.0*x)}}
    pub(crate) fn expr(self,x:&str)->String{match self{Self::Linear=>format!("({x})"),Self::EaseIn=>format!("pow({x},2)"),Self::EaseOut=>format!("(1-pow(1-({x}),2))"),Self::EaseInOut=>format!("(pow({x},2)*(3-2*({x})))")}}
}
#[derive(Debug,Clone,PartialEq,Serialize,Deserialize)]
#[serde(deny_unknown_fields)]
pub struct VisualKey {pub at:Rational,pub dx:i32,pub dy:i32,pub scale:f64,pub opacity:f64,pub easing:Easing}
#[derive(Debug,Clone,PartialEq,Serialize,Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Animation {pub keys:Vec<VisualKey>,pub fade_in:Rational,pub fade_out:Rational}
impl Default for Animation {fn default()->Self{Self{keys:vec![],fade_in:Rational::new(0,1).unwrap(),fade_out:Rational::new(0,1).unwrap()}}}
#[derive(Debug,Clone,Copy)]
pub struct VisualState {pub dx:f64,pub dy:f64,pub scale:f64,pub opacity:f64}
impl Animation {
    pub fn validate(&self,duration:Rational)->Result<()> {
        if self.keys.len()>MAX_VISUAL_KEYS||self.fade_in.numerator()<0||self.fade_out.numerator()<0||self.fade_in.checked_add(self.fade_out)?>duration{return Err(Error::InvalidProject("graphic animation duration"));}
        let mut previous=None;for k in &self.keys{
            if k.at.numerator()<0||k.at>duration||previous.is_some_and(|p|p>=k.at)||k.dx.unsigned_abs()>8192||k.dy.unsigned_abs()>8192{return Err(Error::InvalidProject("graphic keyframe position or order"));}
            bounded(k.scale,0.1,2.0,"graphic scale")?;bounded(k.opacity,0.0,1.0,"graphic opacity")?;previous=Some(k.at);
        }
        if self.keys.first().is_some_and(|k|k.at.numerator()!=0){return Err(Error::InvalidProject("first graphic keyframe must be at zero"));}Ok(())
    }
    pub fn state(&self,elapsed:Rational,duration:Rational)->Result<VisualState>{
        self.validate(duration)?;
        let mut s=VisualState{dx:0.0,dy:0.0,scale:1.0,opacity:1.0};
        if let Some(k)=self.keys.first(){s=VisualState{dx:k.dx as f64,dy:k.dy as f64,scale:k.scale,opacity:k.opacity};
            for pair in self.keys.windows(2){let(a,b)=(&pair[0],&pair[1]);if elapsed>=b.at{s=VisualState{dx:b.dx as f64,dy:b.dy as f64,scale:b.scale,opacity:b.opacity};continue;}
                if elapsed>=a.at {let t=a.easing.value(elapsed.checked_sub(a.at)?.checked_div(b.at.checked_sub(a.at)?)?.as_f64());let mix=|x:f64,y:f64|x+(y-x)*t;
                    s=VisualState{dx:mix(a.dx as f64,b.dx as f64),dy:mix(a.dy as f64,b.dy as f64),scale:mix(a.scale,b.scale),opacity:mix(a.opacity,b.opacity)};}break;
            }
        }
        if self.fade_in.positive(){s.opacity*=elapsed.checked_div(self.fade_in)?.as_f64().clamp(0.0,1.0);}
        if self.fade_out.positive(){s.opacity*=duration.checked_sub(elapsed)?.checked_div(self.fade_out)?.as_f64().clamp(0.0,1.0);}
        Ok(s)
    }
    pub fn moving(&self)->bool{self.fade_in.positive()||self.fade_out.positive()||self.keys.len()>1}
    pub fn check_bounds(&self,base:PixelRect,safe:PixelRect)->Result<()> {
        // Monotone easing is a convex interpolation of each endpoint. Checking
        // every affine edge at every key covers the WHOLE animation envelope.
        for k in self.keys.iter().map(|k|VisualState{dx:k.dx as f64,dy:k.dy as f64,scale:k.scale,opacity:k.opacity}).chain(std::iter::once(VisualState{dx:0.0,dy:0.0,scale:1.0,opacity:1.0})) {
            let w=f64::from(base.width)*k.scale;let h=f64::from(base.height)*k.scale;
            let x=f64::from(base.x)+(f64::from(base.width)-w)/2.0+k.dx;let y=f64::from(base.y)+(f64::from(base.height)-h)/2.0+k.dy;
            if x<f64::from(safe.x)-1e-9||y<f64::from(safe.y)-1e-9||x+w>f64::from(safe.x+safe.width)+1e-9||y+h>f64::from(safe.y+safe.height)+1e-9{return Err(Error::InvalidProject("animated graphic leaves its safe zone"));}
        }Ok(())
    }
}
#[derive(Debug,Clone,PartialEq,Serialize,Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Overlay {pub id:String,pub range:TimeRange,pub content:GraphicContent,pub placement:Placement,pub animation:Animation,pub enabled:bool}
#[derive(Debug,Clone,Serialize,Deserialize)]
#[serde(deny_unknown_fields)]
pub struct CaptionLayer {pub document:SubtitleDocument,pub style:Option<TextStyle>,pub placement:Option<Placement>,pub burn_in:bool}
#[derive(Debug,Clone,PartialEq,Serialize,Deserialize)]
#[serde(deny_unknown_fields)]
pub struct VolumeKey {pub at:Rational,pub gain:f64,pub easing:Easing}
#[derive(Debug,Clone,PartialEq,Serialize,Deserialize)]
#[serde(deny_unknown_fields)]
pub struct VolumeTrack {pub keys:Vec<VolumeKey>}
impl VolumeTrack {
    pub fn validate(&self,duration:Rational)->Result<()>{
        if self.keys.is_empty()||self.keys.len()>32||self.keys[0].at.numerator()!=0{return Err(Error::InvalidProject("volume track count/start"));}
        let mut previous=None;for k in &self.keys{if k.at.numerator()<0||k.at>duration||previous.is_some_and(|p|p>=k.at){return Err(Error::InvalidProject("volume key order"));}bounded(k.gain,0.0,1.0,"volume gain (attenuation only)")?;previous=Some(k.at);}Ok(())
    }
    pub(crate) fn expression(&self,clock:&str)->String{
        let last=self.keys.last().expect("validated nonempty keys");let mut expr=format!("{:.9}",last.gain);
        for pair in self.keys.windows(2).rev(){let(a,b)=(&pair[0],&pair[1]);let duration=b.at.as_f64()-a.at.as_f64();let t=format!("clip((({clock})-({:.9}))/{duration:.9},0,1)",a.at.as_f64());
            expr=format!("if(lt({clock},{:.9}),{:.9}+({:.9})*{},({expr}))",b.at.as_f64(),a.gain,b.gain-a.gain,a.easing.expr(&t));}
        expr
    }
}
#[derive(Debug,Clone,PartialEq,Serialize,Deserialize)]
#[serde(deny_unknown_fields)]
pub struct VideoFades {pub fade_in:Rational,pub fade_out:Rational}
#[derive(Debug,Clone,PartialEq,Serialize,Deserialize)]
#[serde(deny_unknown_fields)]
pub struct RasterPolicy {pub animation_fps:u16,pub max_states:usize,pub max_scratch_bytes:u64,pub max_prepare_seconds:u32}
impl Default for RasterPolicy{fn default()->Self{Self{animation_fps:60,max_states:8192,max_scratch_bytes:512*1024*1024,max_prepare_seconds:120}}}
/// Intentional layering is an explicit project choice, not silent collision repair.
#[derive(Debug,Clone,Copy,PartialEq,Eq,Serialize,Deserialize,Default)]
#[serde(rename_all="snake_case")]
pub enum CollisionPolicy {#[default] Reject,AllowReviewed}
#[derive(Debug,Clone,Serialize,Deserialize)]
#[serde(deny_unknown_fields)]
pub struct PresentationSettings {
    pub enabled:bool,pub disposition:Disposition,pub locked:bool,
    pub safe_zone:SafeZone,#[serde(default)] pub collisions:CollisionPolicy,pub overlays:Vec<Overlay>,pub captions:Option<CaptionLayer>,
    pub volume:Option<VolumeTrack>,pub fades:Option<VideoFades>,pub raster:RasterPolicy,
}
impl Default for PresentationSettings {fn default()->Self{Self{enabled:true,disposition:Disposition::NeedsReview,locked:false,safe_zone:SafeZone{left:300,right:300,top:300,bottom:300},collisions:CollisionPolicy::Reject,overlays:vec![],captions:None,volume:None,fades:None,raster:RasterPolicy::default()}}}
impl PresentationSettings {
    pub fn active(&self)->bool{self.enabled&&self.disposition==Disposition::AutoApply}
    pub fn has_pixels(&self)->bool{self.overlays.iter().any(|o|o.enabled)||self.captions.as_ref().is_some_and(|c|c.burn_in&&!c.document.cues.is_empty())}
    pub fn ensure_resolved(&self)->Result<()>{if self.enabled&&self.disposition==Disposition::NeedsReview{Err(Error::UnresolvedEdits)}else{Ok(())}}
    pub fn validate(&self,duration:Rational)->Result<()> {
        self.safe_zone.validate()?;
        if self.raster.max_prepare_seconds==0||self.raster.max_prepare_seconds>600||self.overlays.len()>MAX_OVERLAYS||!(1..=240).contains(&self.raster.animation_fps)||self.raster.max_states<2||self.raster.max_states>16384||self.raster.max_scratch_bytes<1024*1024||self.raster.max_scratch_bytes>2*1024*1024*1024{return Err(Error::LimitExceeded("presentation resource policy"));}
        let mut ids=BTreeSet::new();for o in &self.overlays{crate::project::id_ok(&o.id)?;if !ids.insert(&o.id){return Err(Error::InvalidProject("duplicate graphic identity"));}o.range.validate()?;
            if o.range.end>duration{return Err(Error::InvalidProject("graphic exceeds source"));}o.content.validate()?;o.animation.validate(o.range.duration()?)?;}
        if let Some(c)=&self.captions{c.document.validate()?;if let Some(style)=&c.style{style.validate()?;}if c.burn_in&&(c.style.is_none()||c.placement.is_none()){return Err(Error::InvalidProject("burn-in requires an explicit font/style and placement"));}for cue in &c.document.cues{if cue.range.end>duration{return Err(Error::InvalidProject("caption exceeds source duration"));}}}
        if let Some(v)=&self.volume{v.validate(duration)?;}
        if let Some(f)=&self.fades{if f.fade_in.numerator()<0||f.fade_out.numerator()<0||f.fade_in>Rational::new(2,1)?||f.fade_out>Rational::new(2,1)?||f.fade_in.checked_add(f.fade_out)?>duration{return Err(Error::InvalidProject("short video fade duration"));}}Ok(())
    }
    pub fn validate_layout(&self,canvas:OutputSize)->Result<()> {
        canvas.validate()?;if u64::from(canvas.width)*u64::from(canvas.height)>MAX_CANVAS_PIXELS{return Err(Error::LimitExceeded("presentation canvas pixels"));}
        let safe=self.safe_zone.pixels(canvas)?;
        for o in &self.overlays{if o.enabled{let r=o.placement.rect(canvas,self.safe_zone)?;o.animation.check_bounds(r,safe)?;}}
        if let Some(c)=&self.captions {if c.burn_in{c.placement.as_ref().ok_or(Error::InvalidProject("caption placement"))?.rect(canvas,self.safe_zone)?;}}
        Ok(())
    }
    pub(crate) fn rebase_assets(&mut self,old_project:&Path,new_project:&Path)->Result<()> {
        let rebase=|asset:&mut AssetRef|->Result<()>{let absolute=asset.resolve(old_project)?;asset.path=crate::project::relative_reference(&absolute,new_project)?;Ok(())};
        for o in &mut self.overlays{match &mut o.content{GraphicContent::Text{style,..}=>rebase(&mut style.font.asset)?,GraphicContent::Image{asset}|GraphicContent::Svg{asset}=>rebase(asset)?,}}
        if let Some(c)=&mut self.captions{if let Some(style)=&mut c.style{rebase(&mut style.font.asset)?;}}Ok(())
    }
    pub fn all_asset_refs(&self)->Vec<&AssetRef>{let mut a=Vec::new();for o in &self.overlays{a.extend(o.content.assets());}if let Some(c)=&self.captions{if let Some(style)=&c.style{a.push(&style.font.asset);}}a}
    pub fn asset_refs(&self)->Vec<&AssetRef>{let mut a=Vec::new();for o in &self.overlays{if o.enabled{a.extend(o.content.assets());}}
        if let Some(c)=&self.captions{if c.burn_in{if let Some(style)=&c.style{a.push(&style.font.asset);}}}a}
}
impl Project {
    pub fn set_presentation(&mut self,variant:&str,settings:Option<PresentationSettings>)->Result<()> {
        self.edit(|p|{let v=p.variants.iter_mut().find(|v|v.id==variant).ok_or(Error::InvalidProject("presentation variant"))?;
            if v.presentation.as_ref().is_some_and(|s|s.locked){return Err(Error::LockedEdit);}
            v.presentation=settings.map(|mut s|{s.disposition=Disposition::NeedsReview;s.locked=false;s});Ok(())})
    }
    pub fn review_presentation(&mut self,variant:&str,disposition:Disposition,enabled:bool)->Result<()> {
        self.edit(|p|{let s=p.presentation_mut(variant)?;if s.locked{return Err(Error::LockedEdit);}s.disposition=disposition;s.enabled=enabled;Ok(())})
    }
    pub fn change_caption(&mut self,variant:&str,cue:&str,range:TimeRange,text:String)->Result<()> {
        self.edit(|p|{let s=p.presentation_mut(variant)?;if s.locked{return Err(Error::LockedEdit);}
            let c=s.captions.as_mut().ok_or(Error::InvalidProject("no supplied captions"))?;
            c.document.replace_cue(cue,range,text)?;s.disposition=Disposition::NeedsReview;Ok(())})
    }
    pub fn update_overlay(&mut self,variant:&str,overlay:Overlay)->Result<()> {
        self.edit(|p|{let s=p.presentation_mut(variant)?;if s.locked{return Err(Error::LockedEdit);}
            if let Some(old)=s.overlays.iter_mut().find(|o|o.id==overlay.id){*old=overlay;}else{s.overlays.push(overlay);}
            s.disposition=Disposition::NeedsReview;Ok(())})
    }
    pub fn remove_overlay(&mut self,variant:&str,id:&str)->Result<()> {
        self.edit(|p|{let s=p.presentation_mut(variant)?;if s.locked{return Err(Error::LockedEdit);}
            let index=s.overlays.iter().position(|o|o.id==id).ok_or(Error::InvalidProject("unknown graphic"))?;s.overlays.remove(index);s.disposition=Disposition::NeedsReview;Ok(())})
    }
    pub fn set_presentation_locked(&mut self,variant:&str,locked:bool)->Result<()>{self.edit(|p|{p.presentation_mut(variant)?.locked=locked;Ok(())})}
    fn presentation_mut(&mut self,variant:&str)->Result<&mut PresentationSettings>{self.variants.iter_mut().find(|v|v.id==variant).and_then(|v|v.presentation.as_mut()).ok_or(Error::InvalidProject("presentation variant"))}
}
fn bounded(x:f64,a:f64,b:f64,reason:&'static str)->Result<()>{if !x.is_finite()||x<a||x>b{Err(Error::InvalidProject(reason))}else{Ok(())}}

/// Optional, bounded observations from an already decoded target-composition
/// thumbnail. Caller supplies output-space pixels, not a semantic object map.
#[derive(Debug,Clone,Copy)]
pub struct AnchorSample {pub anchor:Anchor,pub luminance:f64,pub edges:f64,pub activity:f64}
#[derive(Debug,Clone,Copy)]
pub struct AnchorSuggestion {pub anchor:Anchor,pub score:f64,pub use_light_text:bool}
pub fn suggest_anchor(canvas:OutputSize,box_size:(u32,u32),safe:SafeZone,obstacles:&[PixelRect],samples:&[AnchorSample],previous:Option<Anchor>)->Result<Vec<AnchorSuggestion>>{
    if samples.len()>9||obstacles.len()>128{return Err(Error::LimitExceeded("placement observations"));}
    let mut seen=BTreeSet::new();for s in samples{if !seen.insert(s.anchor){return Err(Error::InvalidInput("duplicate placement sample"));}for x in [s.luminance,s.edges,s.activity]{bounded(x,0.0,1.0,"placement measurement")?;}}
    let mut result=Vec::new();for a in Anchor::all(){let p=Placement{anchor:a,width:box_size.0,height:box_size.1,margin:0};let rect=p.rect(canvas,safe)?;
        if obstacles.iter().any(|b|rect.x<b.x.saturating_add(b.width)&&b.x<rect.x+rect.width&&rect.y<b.y.saturating_add(b.height)&&b.y<rect.y+rect.height){continue;}
        let sample=samples.iter().find(|s|s.anchor==a);let(score,light)=sample.map(|s|(s.edges*2.0+s.activity*2.0+(0.5-s.luminance).abs()*-0.5,s.luminance<0.5)).unwrap_or((1.0,true));
        result.push(AnchorSuggestion{anchor:a,score:score+if previous.is_some_and(|p|p!=a){0.3}else{0.0},use_light_text:light});
    }result.sort_by(|a,b|a.score.total_cmp(&b.score).then(a.anchor.cmp(&b.anchor)));Ok(result)
}

/// Measure a fixed nine-anchor candidate set on explicitly supplied, already
/// display-oriented RGB pixels. At most 64x64 samples per box. This never decodes
/// or fetches source media. Call once per proposed shot/segment, not every frame.
pub fn measure_anchors(canvas:OutputSize,box_size:(u32,u32),safe:SafeZone,rgb:&[u8],previous:Option<&[u8]>)->Result<Vec<AnchorSample>> {
    canvas.validate()?;let size=u64::from(canvas.width)*u64::from(canvas.height)*3;
    if size>MAX_CANVAS_PIXELS*3||rgb.len() as u64!=size||previous.is_some_and(|p|p.len()!=rgb.len()){return Err(Error::InvalidInput("placement thumbnail dimensions"));}
    let luma=|data:&[u8],x:u32,y:u32|{let i=(u64::from(y)*u64::from(canvas.width)+u64::from(x)) as usize*3;(0.2126*f64::from(data[i])+0.7152*f64::from(data[i+1])+0.0722*f64::from(data[i+2]))/255.0};
    let mut result=Vec::new();for anchor in Anchor::all(){let rect=Placement{anchor,width:box_size.0,height:box_size.1,margin:0}.rect(canvas,safe)?;
        let nx=rect.width.min(64);let ny=rect.height.min(64);let mut lum=0.0;let mut edges=0.0;let mut activity=0.0;
        for yy in 0..ny{for xx in 0..nx{let x=rect.x+xx*rect.width/nx;let y=rect.y+yy*rect.height/ny;let z=luma(rgb,x,y);lum+=z;
            edges+=(z-luma(rgb,(x+1).min(rect.x+rect.width-1),y)).abs();
            edges+=(z-luma(rgb,x,(y+1).min(rect.y+rect.height-1))).abs();
            if let Some(p)=previous{activity+=(z-luma(p,x,y)).abs();}
        }}let count=f64::from(nx*ny);result.push(AnchorSample{anchor,luminance:lum/count,edges:edges/(count*2.0),activity:activity/count});
    }Ok(result)
}

/// Produce restrained, explicitly selected punch-ins using the EXISTING crop
/// track. This function does not infer faces, speech emphasis or suitable cuts.
/// Intervals are source-time; known cuts inside an interval prohibit generation.
/// The caller must review/approve the returned framing settings normally.
pub fn explicit_punch_ins(source:&crate::project::ProjectSource,target:OutputSize,intervals:&[TimeRange],known_cuts:&[Rational],zoom:f64,min_spacing:Rational)->Result<crate::reframe::FramingSettings>{
    use crate::reframe::{FramingSettings,FramingMode,CropTrack,CropShot,CropKeyframe,CropPose,MotionLimits};
    bounded(zoom,1.0,1.08,"restrained punch-in zoom")?;
    if intervals.len()>16||known_cuts.len()>64||min_spacing<Rational::new(1,1)?{return Err(Error::LimitExceeded("punch-in count or spacing"));}
    let mut edges=BTreeSet::new();edges.insert(Rational::new(0,1)?);edges.insert(source.duration);let mut last_end=None;
    let mut last_cut=None;for cut in known_cuts{if cut.numerator()<=0||*cut>=source.duration||last_cut.is_some_and(|c|c>=*cut){return Err(Error::InvalidInput("source cut ordering"));}last_cut=Some(*cut);edges.insert(*cut);}
    for range in intervals{range.validate()?;if range.end>source.duration||range.duration()?<Rational::new(1,2)?||last_end.is_some_and(|end|range.start.checked_sub(end).map(|d|d<min_spacing).unwrap_or(true)){return Err(Error::InvalidProject("punch-in interval length/order/spacing"));}
        if known_cuts.iter().any(|c|*c>range.start&&*c<range.end){return Err(Error::InvalidProject("punch-in cannot bridge a known source cut"));}
        edges.insert(range.start);edges.insert(range.end);last_end=Some(range.end);
    }
    let points:Vec<_>=edges.into_iter().collect();let mut shots=Vec::new();for pair in points.windows(2){let start=pair[0];let end=pair[1];let selected=intervals.iter().any(|r|r.start<=start&&r.end>=end);
        shots.push(CropShot{range:TimeRange::new(start,end)?,keyframes:vec![CropKeyframe{at:start,pose:CropPose{zoom:if selected{zoom}else{1.0},..CropPose::centered()}}]});}
    let mut settings=FramingSettings::center_crop(target,source.duration)?;settings.mode=FramingMode::Crop{track:CropTrack{shots,motion:MotionLimits::default()}};settings.validate(source)?;Ok(settings)
}

/// Pure preflight: refuse a destination named by the project or any graphic/font
/// reference, including disabled layers. A reviewed byte-identical asset copy is
/// conservatively protected too; the native lease separately rechecks live aliases.
pub(crate) fn guard_destination(project:&Project,project_file:&Path,destination:&Path,policy:&crate::host::OutputPolicy)->Result<()> {
    if destination==project_file{return Err(Error::SameFile);}
    for variant in &project.variants{if let Some(s)=&variant.presentation{for a in s.all_asset_refs(){
        if a.resolve(project_file)?==destination{return Err(Error::SameFile);}
        if let crate::host::OutputPolicy::ReplaceReviewed(stamp)=policy{if stamp.size==a.size&&stamp.sha256==a.sha256{return Err(Error::SameFile);}}
    }}}
    if let Some(enhancement)=&project.settings.voice_enhancement{
        if enhancement.resolve(project_file)?==destination{return Err(Error::SameFile);}
        if let crate::host::OutputPolicy::ReplaceReviewed(stamp)=policy{
            if stamp.file_id.is_some()&&stamp.file_id==enhancement.stem_stamp.file_id{return Err(Error::SameFile);}
        }
    }
    Ok(())
}
