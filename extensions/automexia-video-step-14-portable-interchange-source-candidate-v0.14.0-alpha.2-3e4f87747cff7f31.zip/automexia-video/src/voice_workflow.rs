//! Classical-audio operations on the existing host-owned job executor.
//! Analysis returns observations; only explicit apply/save changes edit intent.
use crate::observation_cache::{self,ObservationCache,Observation,AnalysisKind,CacheUse,CachedAnalysis};
use crate::{Cancellation,Error,Rational,Result,VideoExtension};
use crate::extension::emit;
use crate::host::{InputFile,MediaHost,OutputPolicy,ProgressSink,RuntimeCapabilities};
use crate::media::{MediaInfo,parse_probe};
use crate::plan::{RenderPlan,build_audio_plan};
use crate::progress::{Progress,Stage};
use crate::project::{Project,KeepClip,TimeRange};
use crate::voice::{PcmPreflight,VoiceReport,VoiceSettings,TreatmentMode};
use crate::voice_render::{AudioTask,AudioRenderReport,LoudnessMeasurement,VoiceScan,validate_timeout,qualified_layout};
use serde::Serialize;
use std::{path::{Path,PathBuf},time::{Duration,Instant}};

#[derive(Debug,Clone)]
pub struct VoiceAnalysisRequest {pub project_file:PathBuf,pub settings:VoiceSettings,pub timeout:Duration}
impl VoiceAnalysisRequest {
    pub fn new(project_file:impl Into<PathBuf>)->Self {Self{project_file:project_file.into(),settings:VoiceSettings::default(),timeout:Duration::from_secs(7200)}}
    fn validate(&self)->Result<()> {project_path(&self.project_file)?;self.settings.validate()?;validate_timeout(self.timeout)}
}
#[derive(Debug,Clone)]
pub struct AudioStemRequest {
    pub project_file:PathBuf,pub output:PathBuf,pub variant:String,pub output_policy:OutputPolicy,pub timeout:Duration,
}
impl AudioStemRequest {
    pub fn new(project_file:impl Into<PathBuf>,output:impl Into<PathBuf>)->Self{Self{project_file:project_file.into(),output:output.into(),variant:"main".into(),output_policy:OutputPolicy::CreateNew,timeout:Duration::from_secs(7200)}}
}
#[derive(Debug,Clone,Serialize)]
pub struct AudioStemResult {
    pub output:PathBuf,pub source:InputFile,pub project_revision:u64,pub decision_sha256:String,
    pub duration:Rational,pub sample_rate:u32,pub channels:u32,pub channel_layout:String,
    pub audio:Option<AudioRenderReport>,pub runtime:RuntimeCapabilities,pub fully_decoded:bool,
}
impl<H:MediaHost> VideoExtension<H> {
    /// Full bounded scan of only the selected stream; no model, cache, project
    /// mutation, downmix, normalization or output file is created here.
    pub fn analyze_voice(&self,project:&Project,request:&VoiceAnalysisRequest,cancel:&Cancellation,progress:&mut ProgressSink<'_>)->Result<VoiceReport>{
        self.analyze_voice_inner(project,request,None,cancel,progress).map(|v|v.report)
    }
    pub fn analyze_voice_cached(&self,project:&Project,request:&VoiceAnalysisRequest,cache:&mut ObservationCache,cancel:&Cancellation,progress:&mut ProgressSink<'_>)->Result<CachedAnalysis<VoiceReport>>{
        self.analyze_voice_inner(project,request,Some(cache),cancel,progress)
    }
    fn analyze_voice_inner(&self,project:&Project,request:&VoiceAnalysisRequest,mut cache:Option<&mut ObservationCache>,cancel:&Cancellation,progress:&mut ProgressSink<'_>)->Result<CachedAnalysis<VoiceReport>>{
        if let Some(c)=cache.as_mut(){c.live()?;}

        project.validate()?;request.validate()?;
        if project.sources.len()!=1{return Err(Error::Unsupported("voice analysis is single-source"));}
        let job=self.begin(cancel)?;
        let started=Instant::now();
        let deadline=started.checked_add(request.timeout).ok_or(Error::InvalidInput("voice analysis deadline overflow"))?;
        let scoped_cancel=job.cancel.with_deadline(deadline);
        let remaining=||->Result<Duration>{let d=request.timeout.saturating_sub(started.elapsed());if d.is_zero(){Err(Error::Timeout)}else{Ok(d)}};
        if request.settings.mode==TreatmentMode::Off {return Ok(CachedAnalysis{report:VoiceReport::new(project,request.settings.clone(),None)?,cache:CacheUse::Disabled});}
        let source=&project.sources[0];
        if source.duration>Rational::new(i64::from(request.settings.max_analysis_seconds),1)?{return Err(Error::LimitExceeded("voice analysis duration"));}
        source.media.audio.as_ref().ok_or(Error::Unsupported("no selected audio to clean"))?;
        let path=source.resolve(&request.project_file)?;emit(progress,Stage::Inspecting)?;
        let input=self.host().inspect_input(&path,&scoped_cancel)?;source.check_input(&input)?;
        emit(progress,Stage::RuntimeCheck)?;let runtime=self.host().runtime_capabilities(&scoped_cancel)?;
        require_meter(&runtime)?;
        let current=self.probe_path(&input.canonical_path,&scoped_cancel,progress)?;source.check_media(&current)?;
        let scan=VoiceScan::new(project,input.clone(),request.settings.max_analysis_seconds,remaining()?)?;scan.check_runtime(&runtime)?;
        let key=if cache.is_some(){observation_cache::key(project,&input,&runtime,AnalysisKind::VoiceV1,&request.settings,&())?}else{None};
        if let (Some(c),Some(k))=(cache.as_mut(),key.as_ref()) {
            if let Some(Observation::Voice{preflight,loudness})=c.get(k)? {
                preflight.validate()?;loudness.validate()?;
                self.host().revalidate_input(&input,&scoped_cancel)?;scoped_cancel.check()?;
                let mut report=VoiceReport::new(project,request.settings.clone(),Some(preflight.clone()))?;
                report.source_loudness=Some(loudness);c.live()?;scoped_cancel.check()?;
                return Ok(CachedAnalysis{report,cache:CacheUse::Hit});
            }
        }

        let mut analyzer=PcmPreflight::new(scan.sample_rate(),scan.channels(),request.settings.max_analysis_seconds)?;
        self.host().revalidate_input(&input,&scoped_cancel)?;emit(progress,Stage::Analyzing)?;
        let mut bytes_seen=0u64;let mut last_second=0u64;
        self.host().stream_voice_pcm(&scan,&scoped_cancel,&mut |bytes|{
            scoped_cancel.check()?;remaining()?;analyzer.feed(bytes,&scoped_cancel)?;
            bytes_seen=bytes_seen.checked_add(bytes.len() as u64).ok_or(Error::LimitExceeded("PCM byte counter"))?;
            let second=bytes_seen/(u64::from(scan.sample_rate())*scan.channels() as u64*4);
            if second>last_second {let mut event=Progress::stage(Stage::Analyzing);event.out_time_us=Some(second*1_000_000);
                std::panic::catch_unwind(std::panic::AssertUnwindSafe(||progress(event))).map_err(|_|Error::CallbackPanicked)?;last_second=second;}
            Ok(())
        })?;
        scoped_cancel.check()?;let preflight=analyzer.finish(&scoped_cancel)?;
        let mut report=VoiceReport::new(project,request.settings.clone(),Some(preflight.clone()))?;
        // Raw project-time audio, no previous cleanup and no accepted/proposed
        // cuts. A private copy does not change locks or approval in the original.
        let mut raw=project.clone();raw.settings.voice_cleanup=None;raw.settings.voice_enhancement=None;raw.settings.color_correction=None;for v in &mut raw.variants{v.framing=None;v.presentation=None;v.timing=None;}raw.operations.clear();
        raw.assembly=vec![KeepClip{id:"voice-source".into(),source_id:source.id.clone(),range:TimeRange::new(Rational::new(0,1)?,source.duration)?,locked:false}];
        let raw_plan=build_audio_plan(&raw,&raw.variants[0].id,&current,&runtime)?;
        require_meter(&runtime)?;emit(progress,Stage::MeasuringAudio)?;
        let output=self.host().run_audio(&AudioTask::MeasurePlan{input:input.clone(),plan:raw_plan,timeout:remaining()?},&scoped_cancel,progress)?;
        let measurement=LoudnessMeasurement::parse(&output.stdout)?;
        report.source_loudness=Some(measurement.clone());
        self.host().revalidate_input(&input,&scoped_cancel)?;scoped_cancel.check()?;remaining()?;
        let cache_use=match (cache.as_mut(),key) {
            (Some(c),Some(k))=>c.put(k,&source.fingerprint.sha256,Observation::Voice{preflight,loudness:measurement})?,
            (Some(_),None)=>CacheUse::UnpinnedRuntime,(None,_)=>CacheUse::Disabled,
        };
        scoped_cancel.check()?;Ok(CachedAnalysis{report,cache:cache_use})
    }

    /// Internal first pass: the exact cleaned, assembled signal used by this
    /// render, not a cached full-source measurement from before trimming.
    pub(crate) fn prepare_voice(&self,plan:&mut RenderPlan,input:&InputFile,timeout:Duration,cancel:&Cancellation,progress:&mut ProgressSink<'_>)->Result<()> {
        if plan.voice_processing().is_none(){return Ok(());}
        self.host().revalidate_input(input,cancel)?;emit(progress,Stage::MeasuringAudio)?;
        let task=AudioTask::MeasurePlan{input:input.clone(),plan:plan.clone(),timeout};
        let result=self.host().run_audio(&task,cancel,progress)?;cancel.check()?;
        let measured=LoudnessMeasurement::parse(&result.stdout)?;
        let voice=plan.voice_processing_mut().ok_or(Error::InvalidInput("missing voice processing plan"))?;
        voice.resolve_gain(measured)?;
        let warnings=voice.gain.as_ref().ok_or(Error::InvalidInput("missing gain decision"))?.warnings.clone();
        plan.warnings.extend(warnings);self.host().revalidate_input(input,cancel)?;cancel.check()
    }
    /// Check decoded output before publication; a lossy encoder may introduce
    /// peaks absent from the floating-point render. A Retry result requires the
    /// caller to rerender and validate, not publish the previous bytes.
    pub(crate) fn check_voice_output(&self,plan:&mut RenderPlan,path:&Path,media:&MediaInfo,timeout:Duration,cancel:&Cancellation,progress:&mut ProgressSink<'_>)->Result<AudioValidation> {
        if plan.voice_processing().is_none(){return Ok(AudioValidation::Ready(None));}
        let audio=media.streams.iter().find(|s|s.kind=="audio").ok_or(Error::InvalidOutput("processed audio missing"))?;
        let input=self.host().inspect_input(path,cancel)?;emit(progress,Stage::MeasuringAudio)?;
        let result=self.host().run_audio(&AudioTask::MeasureFile{input:input.clone(),stream:audio.index,timeout},cancel,progress)?;
        let measured=LoudnessMeasurement::parse(&result.stdout)?;
        self.host().revalidate_input(&input,cancel)?;cancel.check()?;
        let voice=plan.voice_processing_mut().ok_or(Error::InvalidInput("voice plan disappeared"))?;
        if voice.correct_encoded_peak(&measured)? {return Ok(AudioValidation::Retry);}
        Ok(AudioValidation::Ready(Some(voice.finish_report(measured)?)))
    }

    /// Optional PCM24 WAV stem using exactly the accepted project audio chain.
    /// It is a separate requested output, never an implicit large intermediate.
    pub fn export_audio_stem(&self,project:&Project,request:&AudioStemRequest,cancel:&Cancellation,progress:&mut ProgressSink<'_>)->Result<AudioStemResult>{
        let job=self.begin(cancel)?;
        self.export_audio_stem_job(project,request,&job.cancel,progress)
    }
    pub(crate) fn export_audio_stem_job(&self,project:&Project,request:&AudioStemRequest,cancel:&Cancellation,progress:&mut ProgressSink<'_>)->Result<AudioStemResult>{
        project_path(&request.project_file)?;validate_timeout(request.timeout)?;project.validate()?;
        let started=Instant::now();
        let deadline=started.checked_add(request.timeout).ok_or(Error::InvalidInput("audio stem deadline overflow"))?;
        let scoped_cancel=cancel.with_deadline(deadline);let cancel=&scoped_cancel;
        let remaining=||->Result<Duration>{let d=request.timeout.saturating_sub(started.elapsed());if d.is_zero(){Err(Error::Timeout)}else{Ok(d)}};
        if !request.output.extension().and_then(|x|x.to_str()).is_some_and(|x|x.eq_ignore_ascii_case("wav")) {return Err(Error::InvalidInput("audio stem requires .wav destination"));}
        project.variant(&request.variant)?;
        crate::presentation::guard_destination(project,&request.project_file,&request.output,&request.output_policy)?;
        let source=&project.sources[0];let audio=source.media.audio.as_ref().ok_or(Error::Unsupported("no selected audio for stem"))?;
        let rate=audio.sample_rate.ok_or(Error::InvalidProject("stem sample rate"))?;
        let channels=audio.channels.ok_or(Error::InvalidProject("stem channel count"))?;
        let layout=qualified_layout(channels,audio.channel_layout.as_deref())?;
        let decision_sha256=project.decision_digest()?;emit(progress,Stage::Inspecting)?;
        let input=self.host().inspect_input(&source.resolve(&request.project_file)?,cancel)?;source.check_input(&input)?;
        emit(progress,Stage::RuntimeCheck)?;let runtime=self.host().runtime_capabilities(cancel)?;
        if !runtime.encoders.contains("pcm_s24le")||!runtime.muxers.contains("wav"){return Err(Error::MissingCapability("PCM24 WAV stem"));}
        let current=self.probe_path(&input.canonical_path,cancel,progress)?;
        let mut plan=build_audio_plan(project,&request.variant,&current,&runtime)?;
        let enhanced_input=if let Some(enhancement)=&project.settings.voice_enhancement {
            enhancement.check_source(source)?;let path=enhancement.resolve(&request.project_file)?;
            if path==request.output{return Err(Error::SameFile);}
            let stem=self.host().inspect_input(&path,cancel)?;enhancement.check_input(&stem)?;
            let probed=self.host().run_audio(&AudioTask::ProbeStem{input:stem.clone()},cancel,&mut |_|{})?;
            let media=parse_probe(&probed.stdout)?;crate::enhancement::validate_enhanced_media(&media,&enhancement.receipt,source.duration)?;
            self.host().run_audio(&AudioTask::ValidateStem{input:stem.clone(),timeout:remaining()?},cancel,&mut |_|{})?;
            plan.attach_enhanced_audio(&stem.canonical_path)?;Some(stem)
        }else{None};
        if let Some(stem)=&enhanced_input{self.host().revalidate_input(stem,cancel)?;}
        self.prepare_voice(&mut plan,&input,remaining()?,cancel,progress)?;
        let lease=self.host().stage_output(&input,&request.output,&request.output_policy,cancel)?;
        let duration=plan.edited_timeline().ok_or(Error::InvalidProject("missing stem timeline"))?.duration;
        let (staged,report)=loop {
        let render=AudioTask::RenderStem{input:input.clone(),plan:plan.clone(),output:lease.path().to_owned(),timeout:remaining()?};
        render.arguments()?;emit(progress,Stage::Rendering)?;self.host().run_audio(&render,cancel,progress)?;
        cancel.check()?;let staged=self.host().inspect_input(lease.path(),cancel)?;
        emit(progress,Stage::Validating)?;
        let probed=self.host().run_audio(&AudioTask::ProbeStem{input:staged.clone()},cancel,progress)?;
        let media=parse_probe(&probed.stdout)?;
        validate_stem(&media,duration,rate,channels,&layout)?;
        self.host().run_audio(&AudioTask::ValidateStem{input:staged.clone(),timeout:remaining()?},cancel,progress)?;
        match self.check_voice_output(&mut plan,lease.path(),&media,remaining()?,cancel,progress)? {
            AudioValidation::Retry=>continue,
            AudioValidation::Ready(report)=>break (staged,report),
        }
        };
        self.host().revalidate_input(&staged,cancel)?;self.host().revalidate_input(&input,cancel)?;if let Some(stem)=&enhanced_input{self.host().revalidate_input(stem,cancel)?;}
        cancel.check()?;emit(progress,Stage::Publishing)?;remaining()?;let output=lease.publish(cancel)?;
        Ok(AudioStemResult{output,source:input,project_revision:project.revision,decision_sha256,duration,
            sample_rate:rate,channels,channel_layout:layout,audio:report,runtime,fully_decoded:true})
    }
}
pub(crate) enum AudioValidation {Ready(Option<AudioRenderReport>),Retry}

fn project_path(p:&Path)->Result<()> {
    if !p.is_absolute()||p.components().any(|c|matches!(c,std::path::Component::ParentDir))||!p.extension().and_then(|s|s.to_str()).is_some_and(|s|s.eq_ignore_ascii_case("amxv")) {return Err(Error::InvalidInput("absolute .amxv location required"));}Ok(())
}
fn require_meter(c:&RuntimeCapabilities)->Result<()> {
    if !c.filters.contains("loudnorm")||!c.encoders.contains("pcm_s16le")||!c.muxers.contains("null") {return Err(Error::MissingCapability("loudness/true-peak meter"));}Ok(())
}
pub fn validate_stem(media:&MediaInfo,duration:Rational,rate:u32,channels:u32,layout:&str)->Result<()> {
    if !media.format_names.iter().any(|n|n=="wav")||media.streams.len()!=1{return Err(Error::InvalidOutput("stem container/stream count"));}
    let a=&media.streams[0];
    if a.kind!="audio"||a.codec.as_deref()!=Some("pcm_s24le")||a.sample_rate!=Some(rate)||a.channels!=Some(channels){return Err(Error::InvalidOutput("stem codec/rate/channels"));}
    if qualified_layout(channels,a.channel_layout.as_deref())?!=layout{return Err(Error::InvalidOutput("stem channel layout"));}
    let actual=a.exact_duration().or(media.duration).ok_or(Error::InvalidOutput("stem duration absent"))?;
    if (actual.checked_sub(duration)?.as_f64()).abs()>1.0/f64::from(rate)+0.000_001 {return Err(Error::InvalidOutput("stem duration/sample alignment"));}
    Ok(())
}
