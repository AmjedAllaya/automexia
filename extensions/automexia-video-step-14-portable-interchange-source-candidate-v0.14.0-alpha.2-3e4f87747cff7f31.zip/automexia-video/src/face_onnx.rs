//! Opt-in UltraFace RFB-320 CPU detector. Uses only a verified monolithic ONNX
//! pack and an explicitly selected, fingerprinted ORT library. No downloads.
use crate::{Cancellation,Error,Result};
use crate::face::{FaceDetector,FaceDetection,FaceInput,MAX_FACE_DETECTIONS};
use crate::model_pack::{ModelIdentity,VerifiedModelPack,ULTRAFACE_CONTRACT,ULTRAFACE_PROCESSING};
use crate::reframe::DisplayRect;
use crate::silero_onnx::{initialize_selected_runtime,InferenceWatch,ORT_ADAPTER};
use ort::{session::{Session,builder::GraphOptimizationLevel},value::{Tensor,ValueType},tensor::TensorElementType};
use std::{path::PathBuf,sync::{Mutex,atomic::{AtomicUsize,Ordering}},time::Duration};
const WIDTH:usize=320;const HEIGHT:usize=240;const BOXES:usize=4420;
static SESSIONS:AtomicUsize=AtomicUsize::new(0);
struct Permit;
impl Permit{fn take()->Result<Self>{SESSIONS.fetch_update(Ordering::AcqRel,Ordering::Acquire,|n|(n<2).then_some(n+1)).map_err(|_|Error::Busy)?;Ok(Self)}}
impl Drop for Permit{fn drop(&mut self){SESSIONS.fetch_sub(1,Ordering::AcqRel);}}
struct Loaded{session:Session,watch:InferenceWatch,_permit:Permit,failed:bool}
pub struct UltraFaceCpuDetector{pack:VerifiedModelPack,runtime:PathBuf,timeout:Duration,session:Mutex<Option<Loaded>>}
impl UltraFaceCpuDetector{
    pub fn new(pack:VerifiedModelPack,runtime:PathBuf,timeout:Duration)->Result<Self>{
        pack.identity().validate()?;let id=pack.identity();
        if id.contract!=ULTRAFACE_CONTRACT||id.preprocessing!=ULTRAFACE_PROCESSING||id.runtime.adapter!=ORT_ADAPTER{return Err(Error::Unsupported("UltraFace RFB-320 CPU contract"));}
        if !runtime.is_absolute()||timeout<Duration::from_millis(10)||timeout>Duration::from_secs(30){return Err(Error::InvalidInput("face runtime path or inference timeout"));}
        Ok(Self{pack,runtime,timeout,session:Mutex::new(None)})
    }
    fn load(&self,cancel:&Cancellation)->Result<Loaded>{
        let permit=Permit::take()?;let id=self.identity();let build=initialize_selected_runtime(&self.runtime,&id.runtime.artifact_sha256,cancel)?;
        if build!=id.runtime.build_info_sha256{return Err(Error::ToolIdentityChanged);}
        let make=||->ort::Result<Session>{Session::builder()?.with_no_environment_execution_providers()?.with_intra_threads(1)?.with_inter_threads(1)?.with_parallel_execution(false)?.with_memory_pattern(false)?.with_intra_op_spinning(false)?.with_inter_op_spinning(false)?.with_optimization_level(GraphOptimizationLevel::Level1)?.commit_from_memory(self.pack.weights())};
        let session=std::panic::catch_unwind(std::panic::AssertUnwindSafe(make)).map_err(|_|Error::InvalidOutput("face model loading panic"))?.map_err(|_|Error::InvalidOutput("load selected face model"))?;
        let mut inputs=session.inputs.iter().map(|i|i.name.as_str()).collect::<Vec<_>>();inputs.sort_unstable();let mut outputs=session.outputs.iter().map(|i|i.name.as_str()).collect::<Vec<_>>();outputs.sort_unstable();
        if inputs!=["input"]||outputs!=["boxes","scores"]{return Err(Error::Unsupported("UltraFace tensor names"));}
        if !tensor_contract(&session.inputs[0].input_type,&[1,3,HEIGHT as i64,WIDTH as i64])||session.outputs.iter().any(|o|!tensor_contract(&o.output_type,if o.name=="scores"{&[1,BOXES as i64,2]}else{&[1,BOXES as i64,4]})){return Err(Error::Unsupported("UltraFace static tensor contract"));}
        cancel.check()?;self.revalidate(cancel)?;
        Ok(Loaded{session,watch:InferenceWatch::new()?,_permit:permit,failed:false})
    }
}
impl FaceDetector for UltraFaceCpuDetector{
    fn identity(&self)->&ModelIdentity{self.pack.identity()}
    fn revalidate(&self,cancel:&Cancellation)->Result<()>{cancel.check()?;if crate::native::fingerprint(&self.runtime,512*1024*1024,cancel)?.sha256!=self.identity().runtime.artifact_sha256{return Err(Error::ToolIdentityChanged);}Ok(())}
    fn detect(&self,input:FaceInput<'_>,cancel:&Cancellation)->Result<Vec<FaceDetection>>{
        cancel.check()?;let (pixels,transform)=preprocess(&input,cancel)?;self.revalidate(cancel)?;
        let mut guard=self.session.try_lock().map_err(|_|Error::Busy)?;if guard.is_none(){*guard=Some(self.load(cancel)?);}let loaded=guard.as_mut().unwrap();
        if loaded.failed{return Err(Error::InvalidOutput("face session requires reconstruction after failure"));}
        let result=std::panic::catch_unwind(std::panic::AssertUnwindSafe(||{
            let tensor=Tensor::from_array(([1usize,3,HEIGHT,WIDTH],pixels)).map_err(|_|Error::InvalidOutput("face input tensor"))?;
            loaded.watch.begin(cancel.clone(),self.timeout)?;
            let outputs=loaded.session.run_with_options(ort::inputs!{"input"=>tensor},&*loaded.watch.options);
            loaded.watch.end()?;let outputs=outputs.map_err(|_|Error::InvalidOutput("face inference"))?;
            let (score_shape,scores)=outputs.get("scores").ok_or(Error::InvalidOutput("face scores missing"))?.try_extract_tensor::<f32>().map_err(|_|Error::InvalidOutput("face scores type"))?;
            let (box_shape,boxes)=outputs.get("boxes").ok_or(Error::InvalidOutput("face boxes missing"))?.try_extract_tensor::<f32>().map_err(|_|Error::InvalidOutput("face boxes type"))?;
            if &score_shape[..]!=[1,BOXES as i64,2]||&box_shape[..]!=[1,BOXES as i64,4]{return Err(Error::InvalidOutput("UltraFace RFB-320 tensor dimensions"));}
            let result=decode(scores,boxes,transform,cancel)?;cancel.check()?;Ok(result)
        })).unwrap_or_else(|_|Err(Error::InvalidOutput("face inference panic")));
        let result=result.and_then(|detections|{self.revalidate(cancel)?;Ok(detections)});if result.is_err(){loaded.failed=true;}result
    }
}
fn tensor_contract(value:&ValueType,expected:&[i64])->bool{matches!(value,ValueType::Tensor{ty,shape,..} if *ty==TensorElementType::Float32 && &shape[..]==expected)}
#[derive(Debug,Clone,Copy)]struct Letterbox{width:f64,height:f64,left:f64,top:f64}
fn preprocess(input:&FaceInput<'_>,cancel:&Cancellation)->Result<(Vec<f32>,Letterbox)>{
    let w=input.width as usize;let h=input.height as usize;
    if w==0||h==0||w>4096||h>4096||w*h>4_194_304||input.rgb.len()!=w*h*3||input.source_time.numerator()<0{return Err(Error::InvalidInput("bounded face RGB input"));}
    let scale=(WIDTH as f64/w as f64).min(HEIGHT as f64/h as f64);let rw=(w as f64*scale).round().max(1.0) as usize;let rh=(h as f64*scale).round().max(1.0) as usize;let left=(WIDTH-rw)/2;let top=(HEIGHT-rh)/2;
    let mut out=vec![0.0;3*WIDTH*HEIGHT];
    for y in 0..rh{cancel.check()?;let sy=((y as f64+0.5)*h as f64/rh as f64-0.5).clamp(0.0,(h-1) as f64);let y0=sy.floor() as usize;let y1=(y0+1).min(h-1);let fy=sy-y0 as f64;
        for x in 0..rw{let sx=((x as f64+0.5)*w as f64/rw as f64-0.5).clamp(0.0,(w-1) as f64);let x0=sx.floor() as usize;let x1=(x0+1).min(w-1);let fx=sx-x0 as f64;
            for c in 0..3{let p=|x,y|f64::from(input.rgb[(y*w+x)*3+c]);let a=p(x0,y0)*(1.0-fx)+p(x1,y0)*fx;let b=p(x0,y1)*(1.0-fx)+p(x1,y1)*fx;out[c*WIDTH*HEIGHT+(y+top)*WIDTH+x+left]=((a*(1.0-fy)+b*fy-127.0)/128.0) as f32;}
        }
    }Ok((out,Letterbox{width:rw as f64,height:rh as f64,left:left as f64,top:top as f64}))
}
fn decode(scores:&[f32],boxes:&[f32],t:Letterbox,cancel:&Cancellation)->Result<Vec<FaceDetection>>{
    if scores.len()!=BOXES*2||boxes.len()!=BOXES*4||scores.iter().any(|s|!s.is_finite()||!(0.0..=1.0).contains(s))||boxes.iter().any(|v|!v.is_finite()||v.abs()>4.0){return Err(Error::InvalidOutput("face output tensor values"));}
    let mut candidates=vec![];for i in 0..BOXES{if i%128==0{cancel.check()?;}let confidence=scores[i*2+1];if confidence<0.5{continue;}let b=&boxes[i*4..i*4+4];if b[2]<=b[0]||b[3]<=b[1]{return Err(Error::InvalidOutput("face output rectangle ordering"));}
        let x0=((f64::from(b[0])*WIDTH as f64-t.left)/t.width).clamp(0.0,1.0);let y0=((f64::from(b[1])*HEIGHT as f64-t.top)/t.height).clamp(0.0,1.0);let x1=((f64::from(b[2])*WIDTH as f64-t.left)/t.width).clamp(0.0,1.0);let y1=((f64::from(b[3])*HEIGHT as f64-t.top)/t.height).clamp(0.0,1.0);
        if x1<=x0||y1<=y0{continue;}candidates.push(FaceDetection{rect:DisplayRect{x:x0,y:y0,width:x1-x0,height:y1-y0},confidence});
    }
    candidates.sort_by(|a,b|b.confidence.total_cmp(&a.confidence).then(a.rect.x.total_cmp(&b.rect.x)).then(a.rect.y.total_cmp(&b.rect.y)));let mut result:Vec<FaceDetection>=vec![];
    for face in candidates{cancel.check()?;if result.iter().any(|d|iou(d.rect,face.rect)>0.3){continue;}if result.len()==MAX_FACE_DETECTIONS{return Err(Error::LimitExceeded("face post-NMS count"));}face.validate()?;result.push(face);}Ok(result)
}
fn iou(a:DisplayRect,b:DisplayRect)->f64{let inter=((a.x+a.width).min(b.x+b.width)-a.x.max(b.x)).max(0.0)*((a.y+a.height).min(b.y+b.height)-a.y.max(b.y)).max(0.0);inter/(a.width*a.height+b.width*b.height-inter).max(1e-12)}
#[cfg(test)]mod tests{use super::*;
#[test]fn portrait_letterbox_maps_back_to_source(){let rgb=vec![127;100*200*3];let (_,t)=preprocess(&FaceInput{width:100,height:200,source_time:crate::Rational::new(0,1).unwrap(),rgb:&rgb},&Cancellation::new()).unwrap();assert_eq!((t.width,t.height,t.left,t.top),(120.0,240.0,100.0,0.0));}
#[test]fn rgb_channel_order_and_mean_are_explicit(){let (_,t)=preprocess(&FaceInput{width:1,height:1,source_time:crate::Rational::new(0,1).unwrap(),rgb:&[255,127,0]},&Cancellation::new()).unwrap();assert_eq!(t.height,240.0);let (v,_)=preprocess(&FaceInput{width:1,height:1,source_time:crate::Rational::new(0,1).unwrap(),rgb:&[255,127,0]},&Cancellation::new()).unwrap();let n=120*320+160;assert_eq!(v[n],1.0);assert_eq!(v[WIDTH*HEIGHT+n],0.0);assert_eq!(v[2*WIDTH*HEIGHT+n],-127.0/128.0);}
#[test]fn invalid_tensor_values_rejected(){assert!(decode(&[f32::NAN],&[],Letterbox{width:320.0,height:240.0,left:0.0,top:0.0},&Cancellation::new()).is_err());}
#[test]fn padding_boxes_are_discarded_and_duplicates_suppressed(){let mut scores=vec![0.0;BOXES*2];let mut boxes=vec![0.0;BOXES*4];for i in 0..3{scores[i*2+1]=0.95;boxes[i*4..i*4+4].copy_from_slice(if i==2{&[0.0,0.0,0.1,0.1]}else{&[0.4,0.2,0.6,0.8]});}let r=decode(&scores,&boxes,Letterbox{width:120.0,height:240.0,left:100.0,top:0.0},&Cancellation::new()).unwrap();assert_eq!(r.len(),1);}
}
