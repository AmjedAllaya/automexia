//! Bounded, plain-text SRT/WebVTT import and reversible source-time captions.
//! No filesystem or process authority. Unsupported markup/settings fail explicitly.
use crate::{Error,Result,Rational};
use crate::project::{TimeRange,Timeline};
use serde::{Serialize,Deserialize};
use sha2::{Digest,Sha256};
use std::collections::{BTreeMap,BTreeSet};
pub const MAX_SUBTITLE_BYTES:usize=1024*1024;
pub const MAX_CUES:usize=2048;
pub const MAX_CUE_BYTES:usize=4096;
#[derive(Debug,Clone,Copy,PartialEq,Eq,Serialize,Deserialize)]
#[serde(rename_all="snake_case")]
pub enum SubtitleFormat {Srt,WebVtt}
#[derive(Debug,Clone,PartialEq,Eq,Serialize,Deserialize)]
#[serde(deny_unknown_fields)]
pub struct CaptionCue {pub id:String,pub range:TimeRange,pub text:String}
/// Optional generated word timing. Imported/manual cues have no fabricated word
/// alignment; a manual cue replacement removes only that cue's generated timing.
#[derive(Debug,Clone,PartialEq,Eq,Serialize,Deserialize)]
#[serde(deny_unknown_fields)]
pub struct CaptionWord {pub cue_id:String,pub range:TimeRange,pub text:String}
#[derive(Debug,Clone,Serialize,Deserialize)]
#[serde(deny_unknown_fields)]
pub struct SubtitleDocument {
    pub format:SubtitleFormat,
    /// Exact UTF-8 original, including BOM/newlines. Edited cues do not rewrite it.
    pub original:String,pub original_sha256:String,pub cues:Vec<CaptionCue>,
    #[serde(default,skip_serializing_if="Vec::is_empty")]
    pub generated_words:Vec<CaptionWord>,
}
#[derive(Debug,Clone,Serialize,Deserialize)]
#[serde(deny_unknown_fields)]
pub struct MappedCue {pub source_id:String,pub part:u32,pub range:TimeRange,pub text:String}
impl SubtitleDocument {
    pub fn parse(bytes:&[u8],format:SubtitleFormat)->Result<Self>{
        if bytes.len()>MAX_SUBTITLE_BYTES{return Err(Error::LimitExceeded("subtitle source bytes"));}
        let original=std::str::from_utf8(bytes).map_err(|_|Error::InvalidInput("subtitles require UTF-8"))?.to_owned();
        valid_text(&original,MAX_SUBTITLE_BYTES,true)?;
        let normalized=original.strip_prefix('\u{feff}').unwrap_or(&original).replace("\r\n","\n");
        if normalized.contains('\r'){return Err(Error::InvalidInput("bare CR in subtitle source"));}
        let mut blocks:Vec<Vec<&str>>=Vec::new();let mut block=Vec::new();
        for line in normalized.lines(){
            if line.trim().is_empty(){if !block.is_empty(){blocks.push(std::mem::take(&mut block));}}
            else {block.push(line);}
        }
        if !block.is_empty(){blocks.push(block);}
        let mut start=0;
        if format==SubtitleFormat::WebVtt {
            let header=blocks.first().ok_or(Error::InvalidInput("missing WEBVTT header"))?;
            if header.len()!=1 || !(header[0]=="WEBVTT" || header[0].starts_with("WEBVTT ") || header[0].starts_with("WEBVTT\t")) || header[0].contains("-->") {
                return Err(Error::Unsupported("WebVTT header metadata; use a plain WEBVTT header"));
            }start=1;
        }
        let mut cues=Vec::new();let mut seen=BTreeSet::new();
        for block in blocks.into_iter().skip(start){
            if format==SubtitleFormat::WebVtt&&(block[0]=="NOTE"||block[0].starts_with("NOTE ")||block[0].starts_with("NOTE\t")){continue;}
            if format==SubtitleFormat::WebVtt&&matches!(block[0],"STYLE"|"REGION"){return Err(Error::Unsupported("WebVTT STYLE/REGION is not silently discarded"));}
            let (external,timing,body)=if block[0].contains("-->"){("",block[0],&block[1..])}
                else {if block.len()<2{return Err(Error::InvalidInput("subtitle cue has no timing"));}(block[0],block[1],&block[2..])};
            if format==SubtitleFormat::Srt&&(external.is_empty()||!external.bytes().all(|b|b.is_ascii_digit())) {return Err(Error::InvalidInput("SRT cue requires a numeric identifier"));}
            if external.len()>128||(!external.is_empty()&&!seen.insert(external.to_owned())){return Err(Error::InvalidInput("subtitle identifier duplicate or too long"));}
            let (left,right)=timing.split_once("-->").ok_or(Error::InvalidInput("subtitle timing separator"))?;
            let right=right.trim();if right.split_whitespace().count()!=1{return Err(Error::Unsupported("WebVTT cue positioning/settings require explicit conversion"));}
            let range=TimeRange::new(parse_timestamp(left.trim(),format)?,parse_timestamp(right,format)?)?;
            let text=decode_caption(&body.join("\n"))?;valid_caption(&text)?;
            if cues.last().is_some_and(|c:&CaptionCue|c.range.start>range.start){return Err(Error::InvalidInput("subtitle cues must be ordered"));}
            // Native cue identifiers can contain spaces. Stable local IDs deliberately
            // use ordinal identity; the complete original remains available above.
            cues.push(CaptionCue{id:format!("cue-{}",cues.len()+1),range,text});
            if cues.len()>MAX_CUES{return Err(Error::LimitExceeded("subtitle cue count"));}
        }
        let d=Self{format,original_sha256:format!("{:x}",Sha256::digest(bytes)),original,cues,generated_words:vec![]};d.validate()?;Ok(d)
    }
    pub fn validate(&self)->Result<()> {
        valid_text(&self.original,MAX_SUBTITLE_BYTES,true)?;
        if format!("{:x}",Sha256::digest(self.original.as_bytes()))!=self.original_sha256{return Err(Error::InvalidProject("subtitle original digest"));}
        if self.cues.len()>MAX_CUES{return Err(Error::LimitExceeded("subtitle cue count"));}
        let mut ids=BTreeSet::new();let mut previous=None;
        for c in &self.cues{crate::project::id_ok(&c.id)?;if !ids.insert(&c.id){return Err(Error::InvalidProject("duplicate caption identity"));}
            c.range.validate()?;if c.range.end>Rational::new(604800,1)?{return Err(Error::LimitExceeded("caption duration"));}valid_caption(&c.text)?;
            if previous.is_some_and(|s|s>c.range.start){return Err(Error::InvalidProject("caption order"));}previous=Some(c.range.start);
        }
        if self.generated_words.len()>8192{return Err(Error::LimitExceeded("generated caption word count"));}
        let groups=self.word_groups();
        for (id,words) in groups {
            let cue=self.cues.iter().find(|c|c.id==id).ok_or(Error::InvalidProject("generated caption references unknown cue"))?;
            let mut text=String::new();let mut previous=cue.range.start;
            for word in words {
                word.range.validate()?;valid_caption(&word.text)?;
                if word.text.len()>256||word.text.chars().any(char::is_control)||word.text.trim()!=word.text
                    ||word.range.start<previous||word.range.end>cue.range.end {
                    return Err(Error::InvalidProject("generated caption word timing/text"));
                }
                append_caption_word(&mut text,&word.text);previous=word.range.end;
            }
            if text!=cue.text{return Err(Error::InvalidProject("generated caption words differ from cue text"));}
        }
        Ok(())
    }
    /// Caller may edit text/timing, but validation happens before committing.
    pub fn replace_cue(&mut self,id:&str,range:TimeRange,text:String)->Result<()> {
        let mut draft=self.clone();let c=draft.cues.iter_mut().find(|c|c.id==id).ok_or(Error::InvalidInput("unknown caption"))?;
        c.range=range;c.text=text;draft.generated_words.retain(|w|w.cue_id!=id);draft.cues.sort_by(|a,b|a.range.start.cmp(&b.range.start).then(a.id.cmp(&b.id)));draft.validate()?;*self=draft;Ok(())
    }
    /// Splits a cue at removed ranges. No cut portion leaks its original timestamps
    /// into output. Overlapping cues are retained, never silently dropped.
    pub fn remap(&self,timeline:&Timeline,source_id:&str)->Result<Vec<MappedCue>>{
        self.validate()?;validate_timeline(timeline)?;let mut result=Vec::new();let groups=self.word_groups();
        for cue in &self.cues {let mut part=0u32;
            for s in &timeline.segments {if s.source_id!=source_id{continue;}
                let start=cue.range.start.max(s.source_range.start);let end=cue.range.end.min(s.source_range.end);
                if start>=end{continue;}
                let Some((range,text))=visible_cue(cue,groups.get(cue.id.as_str()),TimeRange::new(start,end)?)? else {continue;};part+=1;
                result.push(MappedCue{source_id:cue.id.clone(),part,range:TimeRange::new(s.output_range.start.checked_add(range.start.checked_sub(s.source_range.start)?.checked_mul(s.output_range.duration()?)?.checked_div(s.source_range.duration()?)?)?,s.output_range.start.checked_add(range.end.checked_sub(s.source_range.start)?.checked_mul(s.output_range.duration()?)?.checked_div(s.source_range.duration()?)?)?)?,text});
                if result.len()>MAX_CUES*4{return Err(Error::LimitExceeded("mapped caption parts"));}
            }
        }result.sort_by(|a,b|a.range.start.cmp(&b.range.start).then(a.source_id.cmp(&b.source_id)).then(a.part.cmp(&b.part)));Ok(result)
    }
    /// Build one source-time caption document for all retained occurrences.
    /// Repeated/overlapping assembly entries must not duplicate source cue IDs
    /// or rasterize the same source caption twice. Partition the union at every
    /// retained entry boundary so words excluded by one occurrence cannot leak
    /// from a longer occurrence's sentence into its source-time image. The same
    /// prepared document is remapped for sidecars and preserves word annotations.
    /// Original source bytes and the caller's editable document remain unchanged.
    pub fn for_timeline(&self,timeline:&Timeline,source_id:&str)->Result<Self> {
        self.validate()?;validate_timeline(timeline)?;
        let coverage=source_partitions(timeline,source_id)?;
        let groups=self.word_groups();let mut result=self.clone();result.cues.clear();result.generated_words.clear();
        for cue in &self.cues {
            for retained in &coverage {
                let start=cue.range.start.max(retained.start);let end=cue.range.end.min(retained.end);
                if start>=end{continue;}
                let words=groups.get(cue.id.as_str());
                if let Some((range,text))=visible_cue(cue,words,TimeRange::new(start,end)?)? {
                    let id=if range==cue.range&&text==cue.text{cue.id.clone()}else{
                        let identity=serde_json::to_vec(&(&cue.id,range,&text)).map_err(|_|Error::InvalidProject("caption part identity"))?;
                        format!("caption-part-{}",&format!("{:x}",Sha256::digest(identity))[..24])
                    };
                    if result.cues.len()>=MAX_CUES{return Err(Error::LimitExceeded("burned caption part count"));}
                    if let Some(words)=words {for word in words.iter().filter(|word|word.range.overlaps(&range)) {
                        if result.generated_words.len()>=8192{return Err(Error::LimitExceeded("generated caption word count"));}
                        result.generated_words.push(CaptionWord{cue_id:id.clone(),range:TimeRange::new(word.range.start.max(range.start),word.range.end.min(range.end))?,text:word.text.clone()});
                    }}
                    result.cues.push(CaptionCue{id,range,text});
                }
            }
        }
        result.cues.sort_by(|a,b|a.range.start.cmp(&b.range.start).then(a.id.cmp(&b.id)));
        result.generated_words.sort_by(|a,b|a.range.start.cmp(&b.range.start).then(a.range.end.cmp(&b.range.end)).then(a.cue_id.cmp(&b.cue_id)));
        result.validate()?;Ok(result)
    }
    fn word_groups(&self)->BTreeMap<&str,Vec<&CaptionWord>> {
        let mut result:BTreeMap<&str,Vec<&CaptionWord>>=BTreeMap::new();
        for word in &self.generated_words{result.entry(&word.cue_id).or_default().push(word);}result
    }
}
fn visible_cue(cue:&CaptionCue,words:Option<&Vec<&CaptionWord>>,range:TimeRange)->Result<Option<(TimeRange,String)>> {
    let Some(words)=words else{return Ok(Some((range,cue.text.clone())));};
    let mut text=String::new();let mut first=None;let mut last=range.start;
    for word in words.iter().filter(|w|w.range.overlaps(&range)) {
        first.get_or_insert(word.range.start.max(range.start));last=word.range.end.min(range.end);
        append_caption_word(&mut text,&word.text);
    }
    match first {Some(first)=>Ok(Some((TimeRange::new(first,last)?,text))),None=>Ok(None)}
}
pub(crate) fn append_caption_word(text:&mut String,word:&str) {
    if !text.is_empty()&&!word.starts_with([',','.',':',';','!','?','。','！','？']) {text.push(' ');}
    text.push_str(word.trim());
}
pub fn sidecar(cues:&[MappedCue],format:SubtitleFormat)->Result<Vec<u8>>{
    if cues.len()>MAX_CUES*4{return Err(Error::LimitExceeded("caption sidecar cue count"));}
    let mut out=if format==SubtitleFormat::WebVtt{"WEBVTT\n\n".to_owned()}else{String::new()};
    for (i,c) in cues.iter().enumerate(){c.range.validate()?;if c.range.end>Rational::new(604800,1)?{return Err(Error::LimitExceeded("caption duration"));}valid_caption(&c.text)?;
        if i>0&&cues[i-1].range.start>c.range.start{return Err(Error::InvalidInput("sidecar cue order"));}
        // Millisecond formats necessarily quantize; keep coverage outward, and
        // report this policy to callers rather than claiming sample precision.
        let start=c.range.start.floor_units(1000)?;let end=c.range.end.ceil_units(1000)?;
        out.push_str(&format!("{}\n{} --> {}\n{}\n\n",i+1,format_ms(start,format),format_ms(end,format),escape_caption(&c.text)));
        if out.len()>4*MAX_SUBTITLE_BYTES{return Err(Error::LimitExceeded("caption sidecar bytes"));}
    }Ok(out.into_bytes())
}
pub fn parse_timestamp(s:&str,format:SubtitleFormat)->Result<Rational>{
    let decimal=if format==SubtitleFormat::Srt{','}else{'.'};
    let (whole,ms)=s.split_once(decimal).ok_or(Error::InvalidInput("subtitle decimal separator"))?;
    if ms.len()!=3||!ms.bytes().all(|b|b.is_ascii_digit()){return Err(Error::InvalidInput("subtitle milliseconds"));}
    let p:Vec<_>=whole.split(':').collect();
    if !(p.len()==3||(format==SubtitleFormat::WebVtt&&p.len()==2)){return Err(Error::InvalidInput("subtitle timestamp components"));}
    if p.iter().any(|v|v.is_empty()||!v.bytes().all(|b|b.is_ascii_digit())){return Err(Error::InvalidInput("subtitle timestamp digits"));}
    let offset=usize::from(p.len()==3);let hours=if offset==1{if p[0].len()<2||p[0].len()>6{return Err(Error::InvalidInput("subtitle hours"));}p[0].parse::<i64>().map_err(|_|Error::InvalidInput("subtitle hours"))?}else{0};
    let minutes=p[offset].parse::<i64>().map_err(|_|Error::InvalidInput("subtitle minutes"))?;
    let seconds=p[offset+1].parse::<i64>().map_err(|_|Error::InvalidInput("subtitle seconds"))?;
    if p[offset].len()!=2||p[offset+1].len()!=2||minutes>59||seconds>59{return Err(Error::InvalidInput("subtitle minutes/seconds"));}
    let millis=hours.checked_mul(3_600_000).and_then(|n|n.checked_add(minutes*60_000+seconds*1000)).and_then(|n|n.checked_add(ms.parse::<i64>().ok()?)).ok_or(Error::LimitExceeded("subtitle time"))?;
    if millis>604800000{return Err(Error::LimitExceeded("subtitle duration"));}Rational::new(millis,1000)
}
fn format_ms(ms:i64,format:SubtitleFormat)->String{format!("{:02}:{:02}:{:02}{}{:03}",ms/3600000,ms/60000%60,ms/1000%60,if format==SubtitleFormat::Srt{','}else{'.'},ms%1000)}
/// Supported character references become plain Unicode. Formatting tags are
/// rejected explicitly rather than dropped. Literal ampersands remain text.
fn decode_caption(s:&str)->Result<String>{
    if s.contains('<')||s.contains('>'){return Err(Error::Unsupported("caption formatting tags are not plain text; escape literal brackets"));}
    let mut out=String::new();let mut rest=s;
    while let Some(i)=rest.find('&'){
        out.push_str(&rest[..i]);rest=&rest[i..];
        if let Some(end)=rest.find(';').filter(|e|*e<=12){
            let entity=&rest[1..end];let decoded=match entity{
                "amp"=>Some('&'),"lt"=>Some('<'),"gt"=>Some('>'),"quot"=>Some('"'),"apos"=>Some('\''),"nbsp"=>Some('\u{a0}'),
                _ if entity.starts_with("#x")=>u32::from_str_radix(&entity[2..],16).ok().and_then(char::from_u32),
                _ if entity.starts_with('#')=>entity[1..].parse::<u32>().ok().and_then(char::from_u32),_=>None,
            };
            if let Some(c)=decoded{out.push(c);rest=&rest[end+1..];continue;}
            if entity.bytes().all(|c|c.is_ascii_alphanumeric()||c==b'#'){return Err(Error::Unsupported("unsupported caption character reference"));}
        }
        out.push('&');rest=&rest[1..];
    }
    out.push_str(rest);valid_caption(&out)?;Ok(out)
}
fn escape_caption(s:&str)->String{s.replace('&',"&amp;").replace('<',"&lt;").replace('>',"&gt;")}
pub(crate) fn valid_caption(text:&str)->Result<()> {
    valid_text(text,MAX_CUE_BYTES,false)?;
    if text.trim().is_empty()||text.lines().count()>8||text.split('\n').any(|line|line.trim().is_empty()){return Err(Error::InvalidInput("empty caption or too many lines"));}
    Ok(())
}
pub(crate) fn valid_text(text:&str,max:usize,source:bool)->Result<()> {
    if text.len()>max{return Err(Error::LimitExceeded("text bytes"));}
    if text.chars().any(|c| (c.is_control()&&!matches!(c,'\n'|'\r'|'\t')) || matches!(c,'\u{202a}'..='\u{202e}'|'\u{2066}'..='\u{2069}') || (!source&&(c=='\u{feff}'||c=='\r'))) {
        return Err(Error::InvalidInput("text contains unsafe control or bidi override"));
    }Ok(())
}

/// Source coverage, partitioned at all occurrence boundaries. Intersections
/// occur once even when the assembly selects the same source range repeatedly.
fn source_partitions(timeline:&Timeline,source_id:&str)->Result<Vec<TimeRange>> {
    let ranges:Vec<_>=timeline.segments.iter().filter(|s|s.source_id==source_id).map(|s|s.source_range).collect();
    let mut edges=BTreeSet::new();for range in &ranges{edges.insert(range.start);edges.insert(range.end);}
    let edges:Vec<_>=edges.into_iter().collect();let mut result=Vec::new();
    for pair in edges.windows(2){
        let range=TimeRange::new(pair[0],pair[1])?;
        if ranges.iter().any(|retained|retained.overlaps(&range)){result.push(range);}
    }
    Ok(result)
}

/// Union used for source-clock graphics. Internal caption boundaries are already
/// represented by the prepared document; other graphics retain animation phase.
pub(crate) fn retained_source_ranges(timeline:&Timeline,source_id:&str)->Result<Vec<TimeRange>> {
    validate_timeline(timeline)?;let mut result:Vec<TimeRange>=Vec::new();
    for range in source_partitions(timeline,source_id)? {
        if let Some(previous)=result.last_mut(){if previous.end==range.start{previous.end=range.end;continue;}}
        result.push(range);
    }
    Ok(result)
}

fn validate_timeline(timeline:&Timeline)->Result<()> {
    if timeline.segments.len()>crate::project::MAX_RENDER_SEGMENTS||timeline.duration.numerator()<0{return Err(Error::LimitExceeded("caption timeline"));}
    let mut output=Rational::new(0,1)?;let mut previous_start=Rational::new(0,1)?;
    for s in &timeline.segments{s.source_range.validate()?;s.output_range.validate()?;crate::project::id_ok(&s.source_id)?;
        if s.output_range.start<previous_start||s.output_range.start>output||s.output_range.end<=output||s.output_range.end>timeline.duration{return Err(Error::InvalidProject("caption timeline mapping"));}
        // Source order is deliberately independent of output order: assembly may
        // reorder, repeat or overlap retained ranges. Output overlap is a dissolve.
        output=s.output_range.end;previous_start=s.output_range.start;
    }
    if output!=timeline.duration{return Err(Error::InvalidProject("caption timeline duration"));}Ok(())
}
