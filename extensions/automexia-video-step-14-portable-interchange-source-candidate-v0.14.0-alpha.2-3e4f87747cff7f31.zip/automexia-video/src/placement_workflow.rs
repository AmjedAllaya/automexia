//! Streams the existing bounded RGB decoder once and measures actual output
//! compositions. No source, graphic, or caption is changed during analysis.
use crate::{Cancellation,Error,Rational,Result,VideoExtension};
use crate::color::{ColorSettings,ColorMode,CreativeLook};
use crate::color_workflow::VideoScan;
use crate::host::{MediaHost,ProgressSink};
use crate::placement::*;
use crate::presentation::{Anchor,AnchorSample,suggest_anchor};
use crate::project::Project;
use crate::reframe::{DisplayRect,FramingMode,OutputSize,PixelRect};
use crate::extension::emit;
use crate::progress::Stage;
use std::{collections::BTreeMap,path::PathBuf,time::{Duration,Instant}};
#[derive(Debug,Clone)]pub struct PlacementRequest{pub project_file:PathBuf,pub variant_id:String,pub sample_interval_ms:u32,pub max_samples:usize,pub timeout:Duration}
impl PlacementRequest{
    pub fn new(project_file:impl Into<PathBuf>,variant:impl Into<String>)->Self{Self{project_file:project_file.into(),variant_id:variant.into(),sample_interval_ms:500,max_samples:2048,timeout:Duration::from_secs(7200)}}
    fn validate(&self)->Result<()>{crate::preview::local_absolute(&self.project_file)?;crate::project::id_ok(&self.variant_id)?;if !(80..=2000).contains(&self.sample_interval_ms)||!(1..=2048).contains(&self.max_samples)||self.timeout.is_zero()||self.timeout>Duration::from_secs(86400){return Err(Error::InvalidInput("placement resource policy"));}Ok(())}
}
impl<H:MediaHost> VideoExtension<H>{
    pub fn analyze_placement(&self,project:&Project,request:&PlacementRequest,cancel:&Cancellation,progress:&mut ProgressSink<'_>)->Result<PlacementReport>{
        project.validate()?;request.validate()?;let started=Instant::now();let owner=self.workflow_scope(cancel)?;let job=self.begin(&owner)?;let deadline=started.checked_add(request.timeout).ok_or(Error::LimitExceeded("placement analysis deadline"))?;let operation_cancel=job.cancel.with_deadline(deadline);let cancel=&operation_cancel;let source=&project.sources[0];let variant=project.variant(&request.variant_id)?;
        let settings=variant.presentation.as_ref().ok_or(Error::InvalidProject("placement needs presentation settings"))?;
        let canvas=canvas(project,&request.variant_id)?;let mut layout=settings.clone();layout.safe_zone=effective_safe_zone(project,&request.variant_id)?;layout.validate_layout(canvas)?;
        let mut analyzer=PlacementAnalyzer::new(project,&request.variant_id,request.max_samples,&owner)?;
        emit(progress,Stage::Inspecting)?;let input=self.host().inspect_input(&source.resolve(&request.project_file)?,cancel)?;source.check_input(&input)?;
        emit(progress,Stage::RuntimeCheck)?;let runtime=self.host().runtime_capabilities(cancel)?;let media=self.probe_path(&input.canonical_path,cancel,progress)?;source.check_media(&media)?;
        let mut color=ColorSettings::off();color.exposure=ColorMode::Off;color.gamma=ColorMode::Off;color.contrast=ColorMode::Off;color.saturation=ColorMode::Off;color.white_balance=ColorMode::Off;color.look=CreativeLook::None;color.analysis_width=192;color.analysis_height=192;color.max_analysis_seconds=u32::try_from(source.duration.ceil_units(1)?).unwrap_or(u32::MAX).min(14400);color.max_frames=crate::color::MAX_VIDEO_FRAMES;
        let scan=VideoScan::new(project,input.clone(),&color,request.timeout)?;scan.check_runtime(&runtime)?;let (width,height)=scan.dimensions();
        let interval=Rational::new(i64::from(request.sample_interval_ms),1000)?;let mut next=Rational::new(0,1)?;let mut last=None;let mut segment=None;
        let mut edges=crate::face::shot_ranges(project)?.into_iter().flat_map(|r|[r.start,r.end]).collect::<Vec<_>>();for layer in layers(settings){for range in layer.ranges{edges.push(range.start);edges.push(range.end);}}edges.sort();edges.dedup();
        emit(progress,Stage::AnalyzingVideo)?;
        self.host().stream_video_frames(&scan,cancel,&mut |frame|{
            cancel.check()?;if started.elapsed()>=request.timeout{return Err(Error::Timeout);}let at=frame.pts.checked_sub(source.timeline_origin)?;
            if frame.width!=width||frame.height!=height||frame.rgb.len()!=width as usize*height as usize*3||at.numerator()<0||at>=source.duration||last.is_some_and(|p|at<=p){return Err(Error::InvalidOutput("placement frame shape or time"));}last=Some(at);
            let current=edges.partition_point(|e|*e<=at);if at<next&&segment==Some(current){return Ok(());}let reset=segment!=Some(current);segment=Some(current);next=at.checked_add(interval)?;
            analyzer.push(at,width,height,frame.rgb,reset,cancel)
        })?;
        self.host().revalidate_input(&input,cancel)?;cancel.check()?;if started.elapsed()>=request.timeout{return Err(Error::Timeout);}let report=analyzer.finish()?;cancel.check()?;Ok(report)
    }
}
struct PlacementAnalyzer<'a>{project:&'a Project,variant:String,canvas:OutputSize,thumbnail:OutputSize,safe:crate::reframe::SafeZone,layers:Vec<Layer>,sums:BTreeMap<(PlacementTarget,Anchor),(f64,f64,u64)>,count:u64,max:usize,previous:Option<Vec<u8>>,owner:Cancellation}
impl<'a> PlacementAnalyzer<'a>{
    fn new(project:&'a Project,variant:&str,max:usize,owner:&Cancellation)->Result<Self>{
        let canvas=canvas(project,variant)?;let ratio=(192.0/f64::from(canvas.width)).min(192.0/f64::from(canvas.height)).min(1.0);let thumbnail=OutputSize::new(((f64::from(canvas.width)*ratio/2.0).floor() as u32*2).max(2),((f64::from(canvas.height)*ratio/2.0).floor() as u32*2).max(2))?;
        let layers=layers(project.variant(variant)?.presentation.as_ref().ok_or(Error::InvalidProject("placement presentation"))?);if layers.is_empty(){return Err(Error::InvalidInput("no visible placement layers"));}
        Ok(Self{project,variant:variant.into(),canvas,thumbnail,safe:effective_safe_zone(project,variant)?,layers,sums:BTreeMap::new(),count:0,max,previous:None,owner:owner.clone()})
    }
    fn push(&mut self,at:Rational,width:u32,height:u32,rgb:&[u8],reset:bool,cancel:&Cancellation)->Result<()>{
        cancel.check()?;if self.count>=self.max as u64{return Err(Error::LimitExceeded("placement sample count"));}
        let output=compose(self.project,&self.variant,self.canvas,self.thumbnail,at,width,height,rgb)?;
        if reset{self.previous=None;}
        for layer in &self.layers{if !layer.ranges.iter().any(|r|r.contains(at)){continue;}
            for anchor in Anchor::all(){let Ok(rect)=pose_rect(layer,anchor,at,self.canvas,self.safe)else{continue;};let rect=thumbnail_rect(rect,self.canvas,self.thumbnail);let sample=measure_rect(anchor,rect,self.thumbnail,&output,self.previous.as_deref())?;
                let v=self.sums.entry((layer.target.clone(),anchor)).or_insert((0.0,0.0,0));v.0+=sample.edges*2.0+sample.activity*2.0-(0.5-sample.luminance).abs()*0.5;v.1+=sample.luminance;v.2+=1;
            }
        }self.previous=Some(output);self.count+=1;Ok(())
    }
    fn finish(self)->Result<PlacementReport>{
        self.owner.check()?;let mut suggestions=vec![];let mut accepted=BTreeMap::new();
        for layer in &self.layers{let mut candidates=vec![];let mut count=0;
            for anchor in Anchor::all(){let Some((score,luma,n))=self.sums.get(&(layer.target.clone(),anchor))else{continue;};let Ok(rect)=envelope(layer,anchor,self.canvas,self.safe)else{continue;};
                if self.layers.iter().filter(|other|other.target!=layer.target&&visible_together(layer,other)).any(|other|envelope(other,other.placement.anchor,self.canvas,self.safe).is_ok_and(|r|overlap(rect,r))){continue;}
                let samples=[AnchorSample{anchor,luminance:luma/ *n as f64,edges:0.0,activity:0.0}];
                let ranked=suggest_anchor(self.canvas,(layer.placement.width,layer.placement.height),self.safe,&[],&samples,Some(layer.placement.anchor))?;
                let text=ranked.iter().find(|r|r.anchor==anchor).ok_or(Error::InvalidOutput("placement anchor rank"))?.use_light_text;
                candidates.push(PlacementCandidate{anchor,score:score/ *n as f64+if anchor!=layer.placement.anchor{0.3}else{0.0},use_light_text:text});count=count.max(*n);
            }
            candidates.sort_by(|a,b|a.score.total_cmp(&b.score).then(a.anchor.cmp(&b.anchor)));accepted.insert(layer.target.clone(),candidates.iter().map(|c|c.anchor).collect());suggestions.push(PlacementSuggestion{target:layer.target.clone(),candidates,sampled_frames:count});
        }
        Ok(PlacementReport{variant_id:self.variant.clone(),original_variant:self.variant,binding:self.project.decision_digest()?,owner:self.owner,suggestions,sampled_frames:self.count,accepted})
    }
}
fn thumbnail_rect(r:PixelRect,canvas:OutputSize,thumb:OutputSize)->PixelRect{let x=(u64::from(r.x)*u64::from(thumb.width)/u64::from(canvas.width)) as u32;let y=(u64::from(r.y)*u64::from(thumb.height)/u64::from(canvas.height)) as u32;let right=((u64::from(r.x+r.width)*u64::from(thumb.width)).div_ceil(u64::from(canvas.width)) as u32).min(thumb.width);let bottom=((u64::from(r.y+r.height)*u64::from(thumb.height)).div_ceil(u64::from(canvas.height)) as u32).min(thumb.height);PixelRect{x:x.min(thumb.width-1),y:y.min(thumb.height-1),width:(right-x).max(1),height:(bottom-y).max(1)}}
fn measure_rect(anchor:Anchor,rect:PixelRect,size:OutputSize,rgb:&[u8],previous:Option<&[u8]>)->Result<AnchorSample>{
    if rgb.len()!=size.width as usize*size.height as usize*3||previous.is_some_and(|p|p.len()!=rgb.len()){return Err(Error::InvalidInput("placement RGB buffer"));}
    let luma=|data:&[u8],x:u32,y:u32|{let i=(y as usize*size.width as usize+x as usize)*3;(0.2126*f64::from(data[i])+0.7152*f64::from(data[i+1])+0.0722*f64::from(data[i+2]))/255.0};
    let nx=rect.width.min(64);let ny=rect.height.min(64);let (mut luminance,mut edges,mut activity)=(0.0,0.0,0.0);
    for iy in 0..ny{for ix in 0..nx{let x=rect.x+ix*rect.width/nx;let y=rect.y+iy*rect.height/ny;let v=luma(rgb,x,y);luminance+=v;edges+=(v-luma(rgb,(x+1).min(rect.x+rect.width-1),y)).abs();edges+=(v-luma(rgb,x,(y+1).min(rect.y+rect.height-1))).abs();if let Some(p)=previous{activity+=(v-luma(p,x,y)).abs();}}}let n=f64::from(nx*ny);Ok(AnchorSample{anchor,luminance:luminance/n,edges:edges/(2.0*n),activity:activity/n})
}
fn compose(project:&Project,variant:&str,canvas:OutputSize,thumb:OutputSize,at:Rational,width:u32,height:u32,rgb:&[u8])->Result<Vec<u8>>{
    if width==0||height==0||width>192||height>192||rgb.len()!=width as usize*height as usize*3{return Err(Error::InvalidInput("placement decoded thumbnail"));}
    let framing=project.variant(variant)?.framing.as_ref().filter(|f|f.enabled&&f.disposition!=crate::Disposition::Ignore);
    let geometry=framing.map(|f|f.geometry_at(&project.sources[0],at)).transpose()?;
    let crop=match (&framing,&geometry){(Some(f),Some(g))=>if matches!(&f.mode,FramingMode::Crop{track}if track.has_varying_zoom()){g.desired_crop}else{g.crop.map(|c|DisplayRect{x:f64::from(c.x)/f64::from(g.scaled_width),y:f64::from(c.y)/f64::from(g.scaled_height),width:f64::from(c.width)/f64::from(g.scaled_width),height:f64::from(c.height)/f64::from(g.scaled_height)})},_=>None};
    let mut output=vec![0u8;thumb.width as usize*thumb.height as usize*3];let background=match framing.map(|f|&f.mode){Some(FramingMode::Fit{background,..})=>[background.red,background.green,background.blue],_=>[0,0,0]};
    for y in 0..thumb.height{for x in 0..thumb.width{let tx=(f64::from(x)+0.5)*f64::from(canvas.width)/f64::from(thumb.width);let ty=(f64::from(y)+0.5)*f64::from(canvas.height)/f64::from(thumb.height);
        let source=if let Some(c)=crop{Some((c.x+tx/f64::from(canvas.width)*c.width,c.y+ty/f64::from(canvas.height)*c.height))}else if let Some(g)=&geometry{let r=g.content;if tx<f64::from(r.x)||ty<f64::from(r.y)||tx>=f64::from(r.x+r.width)||ty>=f64::from(r.y+r.height){None}else{Some(((tx-f64::from(r.x))/f64::from(r.width),(ty-f64::from(r.y))/f64::from(r.height)))}}else{Some((tx/f64::from(canvas.width),ty/f64::from(canvas.height)))};
        let dst=(y as usize*thumb.width as usize+x as usize)*3;if let Some((sx,sy))=source{let px=(sx*f64::from(width)).floor().clamp(0.0,f64::from(width-1)) as usize;let py=(sy*f64::from(height)).floor().clamp(0.0,f64::from(height-1)) as usize;let src=(py*width as usize+px)*3;output[dst..dst+3].copy_from_slice(&rgb[src..src+3]);}else{output[dst..dst+3].copy_from_slice(&background);}
    }}Ok(output)
}
#[cfg(test)]mod tests{
use super::*;use crate::presentation::*;use crate::project::{ProjectSource,FrozenRenderSettings,ResolvedSettings,TimeRange};use crate::host::{InputFile,FileStamp};use crate::reframe::{FramingSettings,SafeZone,CropPose,CropKeyframe};
fn r(s:&str)->Rational{s.parse().unwrap()}
fn project()->Project{let media=crate::media::parse_probe(include_bytes!("../tests/fixtures/probe-base.json")).unwrap();let location=std::env::temp_dir().join("placement-test/project.amxv");let input=InputFile{canonical_path:location.parent().unwrap().join("source.mp4"),stamp:FileStamp{size:100,modified_ns:None,sha256:"a".repeat(64),file_id:None}};let source=ProjectSource::from_probe("source-1",&input,&media,media.select(crate::media::StreamSelection::default()).unwrap(),&location).unwrap();let mut p=Project::new("placement-test",source,ResolvedSettings{workflow:None,voice_cleanup:None,voice_enhancement:None,color_correction:None,pause_cleanup:None,preset_name:None,preset_revision:None,render:FrozenRenderSettings::from_options(&crate::plan::RenderOptions::default()).unwrap()}).unwrap();p.set_variant_framing("main",Some(FramingSettings::center_crop(OutputSize::new(90,160).unwrap(),p.sources[0].duration).unwrap())).unwrap();let overlay=layer("logo",TimeRange::new(r("0"),p.sources[0].duration).unwrap(),Anchor::TopLeft);p.set_presentation("main",Some(PresentationSettings{safe_zone:SafeZone::none(),overlays:vec![overlay],..Default::default()})).unwrap();p}
fn layer(id:&str,range:TimeRange,anchor:Anchor)->Overlay{Overlay{id:id.into(),range,content:GraphicContent::Svg{asset:AssetRef{path:"logo.svg".into(),size:100,sha256:"b".repeat(64)}},placement:Placement{anchor,width:16,height:16,margin:0},animation:Animation::default(),enabled:true}}
fn report(p:&Project,c:&Cancellation)->PlacementReport{let mut a=PlacementAnalyzer::new(p,"main",4,c).unwrap();a.push(r("0"),160,96,&vec![127;160*96*3],true,c).unwrap();a.push(r("1"),160,96,&vec![127;160*96*3],false,c).unwrap();a.finish().unwrap()}
#[test]fn analysis_does_not_modify_project_and_favors_stable_anchor(){let p=project();let original=p.to_json().unwrap();let out=report(&p,&Cancellation::new());assert_eq!(out.suggestions[0].candidates[0].anchor,Anchor::TopLeft);assert_eq!(p.to_json().unwrap(),original);}
#[test]fn adoption_changes_only_selected_anchor_and_stays_pending(){let mut p=project();let c=Cancellation::new();let out=report(&p,&c);let revision=p.revision;out.apply(&mut p,&[PlacementChoice{target:PlacementTarget::Overlay("logo".into()),anchor:Anchor::BottomRight}]).unwrap();assert_eq!(p.revision,revision+1);let s=p.variants[0].presentation.as_ref().unwrap();assert_eq!(s.overlays[0].placement.anchor,Anchor::BottomRight);assert_eq!(s.disposition,crate::Disposition::NeedsReview);}
#[test]fn changed_project_invalidates_report(){let mut p=project();let out=report(&p,&Cancellation::new());p.id="changed".into();assert!(matches!(out.apply(&mut p,&[PlacementChoice{target:PlacementTarget::Overlay("logo".into()),anchor:Anchor::BottomRight}]),Err(Error::InputChanged)));}
#[test]fn cancelled_owner_invalidates_report(){let mut p=project();let c=Cancellation::new();let out=report(&p,&c);c.cancel();assert!(matches!(out.apply(&mut p,&[PlacementChoice{target:PlacementTarget::Overlay("logo".into()),anchor:Anchor::BottomRight}]),Err(Error::Cancelled)));}
#[test]fn locked_presentation_cannot_adopt(){let mut p=project();p.set_presentation_locked("main",true).unwrap();let out=report(&p,&Cancellation::new());assert!(matches!(out.apply(&mut p,&[PlacementChoice{target:PlacementTarget::Overlay("logo".into()),anchor:Anchor::BottomRight}]),Err(Error::LockedEdit)));}
#[test]fn simultaneous_layers_exclude_colliding_anchor(){let mut p=project();let range=TimeRange::new(r("0"),p.sources[0].duration).unwrap();p.variants[0].presentation.as_mut().unwrap().overlays.push(layer("other",range,Anchor::BottomRight));let out=report(&p,&Cancellation::new());let own=out.suggestions.iter().find(|s|s.target==PlacementTarget::Overlay("logo".into())).unwrap();assert!(!own.candidates.iter().any(|a|a.anchor==Anchor::BottomRight));}
#[test]fn non_overlapping_layer_lifetimes_can_reuse_anchor(){let mut p=project();let s=p.variants[0].presentation.as_mut().unwrap();s.overlays[0].range=TimeRange::new(r("0"),r("1")).unwrap();s.overlays.push(layer("other",TimeRange::new(r("1"),r("2")).unwrap(),Anchor::BottomRight));let out=report(&p,&Cancellation::new());let own=out.suggestions.iter().find(|s|s.target==PlacementTarget::Overlay("logo".into())).unwrap();assert!(own.candidates.iter().any(|a|a.anchor==Anchor::BottomRight));}
#[test]fn forged_candidate_diagnostics_cannot_authorize_collision(){let mut p=project();let range=TimeRange::new(r("0"),p.sources[0].duration).unwrap();p.variants[0].presentation.as_mut().unwrap().overlays.push(layer("other",range,Anchor::BottomRight));let mut out=report(&p,&Cancellation::new());out.suggestions[0].candidates.push(PlacementCandidate{anchor:Anchor::BottomRight,score:-100.0,use_light_text:true});assert!(out.apply(&mut p,&[PlacementChoice{target:PlacementTarget::Overlay("logo".into()),anchor:Anchor::BottomRight}]).is_err());}
#[test]fn two_individually_safe_choices_cannot_introduce_combined_collision(){let mut p=project();let range=TimeRange::new(r("0"),p.sources[0].duration).unwrap();p.variants[0].presentation.as_mut().unwrap().overlays.push(layer("other",range,Anchor::BottomRight));let out=report(&p,&Cancellation::new());let before=p.to_json().unwrap();assert!(out.apply(&mut p,&[PlacementChoice{target:PlacementTarget::Overlay("logo".into()),anchor:Anchor::Center},PlacementChoice{target:PlacementTarget::Overlay("other".into()),anchor:Anchor::Center}]).is_err());assert_eq!(p.to_json().unwrap(),before);}
#[test]fn animation_envelope_filters_anchors_that_leave_safe_zone(){let mut p=project();p.variants[0].presentation.as_mut().unwrap().overlays[0].animation.keys=vec![VisualKey{at:r("0"),dx:10,dy:0,scale:1.0,opacity:1.0,easing:Easing::Linear}];let out=report(&p,&Cancellation::new());assert!(!out.suggestions[0].candidates.iter().any(|c|c.anchor==Anchor::TopRight));}
#[test]fn sample_limit_is_enforced(){let p=project();let c=Cancellation::new();let mut a=PlacementAnalyzer::new(&p,"main",1,&c).unwrap();a.push(r("0"),160,96,&vec![0;160*96*3],true,&c).unwrap();assert!(matches!(a.push(r("1"),160,96,&vec![0;160*96*3],false,&c),Err(Error::LimitExceeded(_))));}
#[test]fn invalid_rgb_size_is_rejected(){let p=project();assert!(compose(&p,"main",OutputSize::new(90,160).unwrap(),OutputSize::new(90,160).unwrap(),r("0"),160,96,&[0]).is_err());}
#[test]fn fit_composition_includes_saved_background(){let mut p=project();let mut framing=FramingSettings::fit(OutputSize::new(90,160).unwrap()).unwrap();if let FramingMode::Fit{background,..}=&mut framing.mode{*background=crate::reframe::RgbColor{red:19,green:23,blue:31};}p.set_variant_framing("main",Some(framing)).unwrap();let rgb=compose(&p,"main",OutputSize::new(90,160).unwrap(),OutputSize::new(90,160).unwrap(),r("0"),160,96,&vec![127;160*96*3]).unwrap();assert_eq!(&rgb[0..3],&[19,23,31]);let center=(80*90+45)*3;assert_eq!(&rgb[center..center+3],&[127,127,127]);}
#[test]fn static_crop_uses_quantized_render_viewport(){let mut p=project();let f=p.variants[0].framing.as_mut().unwrap();if let FramingMode::Crop{track}=&mut f.mode{track.shots[0].keyframes[0].pose.center.x=0.601;}let g=f.geometry_at(&p.sources[0],r("0")).unwrap();let mut input=vec![0;160*96*3];for y in 0..96{for x in 0..160{input[(y*160+x)*3]=x as u8;}}let out=compose(&p,"main",OutputSize::new(90,160).unwrap(),OutputSize::new(90,160).unwrap(),r("0"),160,96,&input).unwrap();let crop=g.crop.unwrap();let expected=((f64::from(crop.x)+0.5)/f64::from(g.scaled_width)*160.0).floor() as u8;assert_eq!(out[0],expected);}
#[test]fn animated_zoom_uses_the_fixed_raster_viewport(){let mut p=project();if let FramingMode::Crop{track}=&mut p.variants[0].framing.as_mut().unwrap().mode{track.shots[0].keyframes.push(CropKeyframe{at:r("1"),pose:CropPose{center:crate::reframe::UnitPoint{x:0.55,y:0.5},zoom:1.1}});}let f=p.variants[0].framing.as_ref().unwrap();let g=f.geometry_at(&p.sources[0],r("1/2")).unwrap();let mut input=vec![0;160*96*3];for y in 0..96{for x in 0..160{input[(y*160+x)*3]=x as u8;}}let out=compose(&p,"main",OutputSize::new(90,160).unwrap(),OutputSize::new(90,160).unwrap(),r("1/2"),160,96,&input).unwrap();let crop=g.desired_crop.unwrap();assert_eq!(out[0],((crop.x+0.5/90.0*crop.width)*160.0).floor() as u8);}
#[test]fn absent_visible_samples_produces_no_adoptable_candidates(){let mut p=project();p.variants[0].presentation.as_mut().unwrap().overlays[0].range=TimeRange::new(r("3/2"),r("2")).unwrap();let out=report(&p,&Cancellation::new());assert!(out.suggestions[0].candidates.is_empty());}

#[test]fn unframed_anamorphic_placement_uses_display_canvas(){let mut p=project();p.variants[0].framing=None;p.sources[0].media.video.sample_aspect_ratio=Some(r("2"));assert_eq!(canvas(&p,"main").unwrap(),OutputSize::new(320,96).unwrap());}
#[test]fn placement_combines_framing_and_presentation_guides(){let mut p=project();p.variants[0].framing.as_mut().unwrap().safe_zone=SafeZone{left:1000,right:500,top:1000,bottom:500};let safe=effective_safe_zone(&p,"main").unwrap();assert_eq!(safe.left,1000);assert_eq!(safe.top,1000);let a=PlacementAnalyzer::new(&p,"main",4,&Cancellation::new()).unwrap();assert_eq!(a.safe,safe);}
#[test]fn captions_occupy_only_their_actual_cue_ranges(){let mut p=project();let settings=p.variants[0].presentation.as_mut().unwrap();settings.overlays[0].range=TimeRange::new(r("1"),r("2")).unwrap();settings.captions=Some(CaptionLayer{document:crate::SubtitleDocument::parse(b"1\n00:00:00,000 --> 00:00:01,000\nCaption\n",crate::SubtitleFormat::Srt).unwrap(),style:Some(TextStyle::light(FontRef{asset:AssetRef{path:"font.ttf".into(),size:100,sha256:"c".repeat(64)},family:"Test".into()},12)),placement:Some(Placement{anchor:Anchor::BottomRight,width:16,height:16,margin:0}),burn_in:true});let out=report(&p,&Cancellation::new());let logo=out.suggestions.iter().find(|s|s.target==PlacementTarget::Overlay("logo".into())).unwrap();assert!(logo.candidates.iter().any(|c|c.anchor==Anchor::BottomRight));}
}
