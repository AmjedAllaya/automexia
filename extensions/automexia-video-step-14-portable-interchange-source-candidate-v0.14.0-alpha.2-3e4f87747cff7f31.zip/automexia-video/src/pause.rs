//! Conservative, non-AI quiet-interval proposals. No file, process or UI authority.
//!
//! Analysis is per-channel: polarity cancellation or a silent second channel
//! must not conceal sound. Energy is NOT a speech/music classifier. Every new
//! operation remains `NeedsReview`, including numerically very quiet intervals.
use crate::{Cancellation, Error, Rational, Result};
use crate::project::{Disposition, EditKind, EditOperation, EditOrigin, Project, TimeRange};
use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};

pub const PAUSE_GENERATOR: &str = "video-energy-pauses";
pub const PAUSE_GENERATOR_VERSION: &str = "1";
pub const MAX_ENERGY_CHANNELS: usize = 8;
pub const MAX_ANALYSIS_FRAMES: u64 = 4_500_000;
pub const MAX_QUIET_INTERVALS: usize = 4096;
pub const MAX_ANALYSIS_SECONDS: u32 = 86_400;
pub const MAX_METRIC_FRAME_MS: u32 = 250;

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum AudioContent { Unknown, Dialogue, MixedMusic }

/// Resolved, versioned project data, not a hidden preset lookup during rendering.
/// Integer dBFS limits avoid NaN/infinity and serialization ambiguities in config.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct PauseSettings {
    pub quiet_rms_dbfs: i16,
    pub quiet_peak_dbfs: i16,
    pub active_margin_db: u16,
    pub min_quiet_ms: u32,
    pub padding_before_ms: u32,
    pub padding_after_ms: u32,
    pub min_retained_pause_ms: u32,
    pub min_removal_ms: u32,
    pub min_segment_ms: u32,
    pub min_cut_spacing_ms: u32,
    pub flank_activity_ms: u32,
    pub join_fade_ms: u16,
    pub max_cuts: u16,
    pub max_removed_per_mille: u16,
    pub max_analysis_seconds: u32,
    pub content: AudioContent,
    /// Explicit permission to propose time edits in a declared music mix.
    /// This is not permission to execute a render or to auto-approve proposals.
    pub allow_mixed_music_proposals: bool,
}
impl Default for PauseSettings { fn default() -> Self { Self::clean() } }
impl PauseSettings {
    pub fn clean() -> Self {
        Self { quiet_rms_dbfs: -50, quiet_peak_dbfs: -40, active_margin_db: 8,
            min_quiet_ms: 1200, padding_before_ms: 200, padding_after_ms: 250,
            min_retained_pause_ms: 500, min_removal_ms: 250, min_segment_ms: 700,
            min_cut_spacing_ms: 2000, flank_activity_ms: 180, join_fade_ms: 5,
            max_cuts: 64, max_removed_per_mille: 500, max_analysis_seconds: 21600,
            content: AudioContent::Unknown, allow_mixed_music_proposals: false }
    }
    pub fn social() -> Self {
        Self { min_quiet_ms: 1000, padding_before_ms: 150, padding_after_ms: 200,
            min_retained_pause_ms: 400, min_cut_spacing_ms: 1500, ..Self::clean() }
    }
    pub fn podcast() -> Self {
        Self { min_quiet_ms: 1800, padding_before_ms: 300, padding_after_ms: 350,
            min_retained_pause_ms: 800, min_cut_spacing_ms: 3000, ..Self::clean() }
    }
    pub fn validate(&self) -> Result<()> {
        if !(-96..=-30).contains(&self.quiet_rms_dbfs)
            || self.quiet_peak_dbfs < self.quiet_rms_dbfs || self.quiet_peak_dbfs > -20
            || self.active_margin_db > 24
            || !(1000..=120000).contains(&self.min_quiet_ms)
            || !(100..=5000).contains(&self.padding_before_ms)
            || !(100..=5000).contains(&self.padding_after_ms)
            || !(250..=10000).contains(&self.min_retained_pause_ms)
            || !(200..=60000).contains(&self.min_removal_ms)
            || !(500..=10000).contains(&self.min_segment_ms)
            || self.min_cut_spacing_ms < self.min_segment_ms || self.min_cut_spacing_ms > 60000
            || !(50..=2000).contains(&self.flank_activity_ms)
            || self.join_fade_ms > 10 || self.max_cuts == 0 || self.max_cuts > 64
            || self.max_removed_per_mille == 0 || self.max_removed_per_mille > 600
            || self.max_analysis_seconds == 0 || self.max_analysis_seconds > MAX_ANALYSIS_SECONDS {
            return Err(Error::InvalidInput("pause-cleanup settings are outside conservative bounds"));
        }
        Ok(())
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Serialize)]
pub struct ChannelEnergy {
    /// None means exact digital zero (`-inf` dBFS), not unavailable data.
    pub rms_dbfs: Option<f64>,
    pub peak_dbfs: Option<f64>,
}
impl ChannelEnergy {
    pub fn validate(&self) -> Result<()> {
        for v in [self.rms_dbfs, self.peak_dbfs].into_iter().flatten() {
            if !v.is_finite() || !(-1000.0..=120.0).contains(&v) {
                return Err(Error::InvalidInput("nonfinite or implausible audio measurement"));
            }
        }
        match (self.rms_dbfs, self.peak_dbfs) {
            (None, None) => Ok(()),
            (Some(rms), Some(peak)) if rms <= peak + 0.001 => Ok(()),
            _ => Err(Error::InvalidInput("inconsistent RMS and peak measurements")),
        }
    }
    fn below(&self, rms: i16, peak: i16) -> bool {
        self.rms_dbfs.map_or(true, |v| v <= f64::from(rms))
            && self.peak_dbfs.map_or(true, |v| v <= f64::from(peak))
    }
    fn active(&self, threshold: f64) -> bool { self.rms_dbfs.is_some_and(|v| v >= threshold) }
}

#[derive(Debug, Clone, Serialize)]
pub struct EnergyFrame {
    /// Original timestamp in 1/sample_rate units (not rounded pts_time text).
    pub pts: i64,
    pub samples: u32,
    pub channels: Vec<ChannelEnergy>,
}

#[derive(Debug, Clone, Serialize)]
pub struct QuietInterval {
    pub range: TimeRange,
    pub maximum_rms_dbfs: Option<f64>,
    pub maximum_peak_dbfs: Option<f64>,
    pub bounded_by_activity: bool,
}
#[derive(Debug, Clone, Serialize)]
pub struct EnergySummary {
    pub decoded_frames: u64,
    pub contributing_frames: u64,
    pub observed_duration: Rational,
    pub measured_quiet_duration: Rational,
    pub uncovered_duration: Rational,
    pub discontinuities: u64,
    pub timestamp_tolerance_samples: u32,
    pub timestamp_rounding_events: u64,
    /// Energy-domain mean across channel samples; not EBU integrated loudness.
    pub rms_dbfs: Option<f64>,
    pub peak_dbfs: Option<f64>,
    pub peak_at_or_above_full_scale: bool,
}
#[derive(Debug, Clone)]
pub struct EnergyObservation {
    pub(crate) sample_rate: u32,
    pub(crate) channel_count: usize,
    pub(crate) origin: Rational,
    pub(crate) duration: Rational,
    pub(crate) settings: PauseSettings,
    pub(crate) summary: EnergySummary,
    pub(crate) quiet: Vec<QuietInterval>,
}
impl EnergyObservation {
    pub fn summary(&self) -> &EnergySummary { &self.summary }
    pub fn quiet_intervals(&self) -> &[QuietInterval] { &self.quiet }
}

#[derive(Debug, Clone)]
struct OpenQuiet { interval: QuietInterval, left_active: bool }
/// Single-owner streaming accumulator. Retains no PCM and no per-frame history.
/// Gaps break candidate continuity; overlaps are rejected rather than interpreted.
/// Coarse decoder frames (>250ms) are unsupported instead of approximated away.
pub struct EnergyAnalyzer {
    settings: PauseSettings, rate: u32, channels: usize, origin: Rational, duration: Rational,
    last_end: Option<i64>, last_start: Option<i64>, tolerance: u32, rounding_events: u64, frames: u64, contributing: u64,
    observed: Rational, quiet_duration: Rational, discontinuities: u64,
    sum_squares: f64, weighted_samples: f64, peak: Option<f64>, clipped: bool,
    active_duration: Rational, open: Option<OpenQuiet>, waiting: Option<OpenQuiet>,
    quiet: Vec<QuietInterval>, failed: bool,
}
impl EnergyAnalyzer {
    pub fn new(rate: u32, channels: usize, origin: Rational, duration: Rational, settings: PauseSettings) -> Result<Self> {
        Self::with_timestamp_resolution(rate, channels, origin, duration, settings, Rational::new(1,i64::from(rate))?)
    }
    /// Containers such as Matroska may quantize packet timestamps to 1ms.
    /// Admit at most that documented quantization, never arbitrary drift.
    /// The duration statistics count only non-overlapping measured time.
    pub fn with_timestamp_resolution(rate:u32, channels:usize, origin:Rational, duration:Rational,
        settings:PauseSettings, timestamp_resolution:Rational)->Result<Self> {
        settings.validate()?;
        if !timestamp_resolution.positive() || timestamp_resolution>Rational::new(1,1000)? {
            return Err(Error::Unsupported("audio timestamp resolution exceeds 1ms"));
        }
        let tolerance = if timestamp_resolution<=Rational::new(1,i64::from(rate))? {1} else {
            u32::try_from(timestamp_resolution.ceil_units(i64::from(rate))?).map_err(|_|Error::LimitExceeded("audio timestamp resolution"))?
                .checked_add(1).ok_or(Error::LimitExceeded("audio timestamp resolution"))?
        };
        if !(7350..=192000).contains(&rate) || channels == 0 || channels > MAX_ENERGY_CHANNELS
            || !duration.positive() || duration > Rational::new(i64::from(settings.max_analysis_seconds), 1)? {
            return Err(Error::InvalidInput("analysis rate, channels or duration"));
        }
        // Make all later absolute sample additions provably representable.
        origin.ceil_units(i64::from(rate))?;
        origin.checked_add(duration)?.ceil_units(i64::from(rate))?;
        let zero = Rational::new(0, 1)?;
        Ok(Self {settings, rate, channels, origin, duration, last_end:None, last_start:None, tolerance, rounding_events:0, frames:0, contributing:0,
            observed:zero, quiet_duration:zero, discontinuities:0, sum_squares:0.0, weighted_samples:0.0,
            peak:None, clipped:false, active_duration:zero, open:None, waiting:None, quiet:vec![], failed:false})
    }
    pub fn push(&mut self, frame: EnergyFrame, cancel: &Cancellation) -> Result<()> {
        if self.failed { return Err(Error::InvalidInput("analysis already failed")); }
        let result = self.push_inner(frame, cancel);
        if result.is_err() { self.failed = true; }
        result
    }
    fn push_inner(&mut self, frame: EnergyFrame, cancel: &Cancellation) -> Result<()> {
        cancel.check()?;
        if self.frames >= MAX_ANALYSIS_FRAMES { return Err(Error::LimitExceeded("analysis frames")); }
        if frame.samples == 0 || u64::from(frame.samples) * 1000 > u64::from(self.rate) * u64::from(MAX_METRIC_FRAME_MS)
            || frame.channels.len() != self.channels {
            return Err(Error::InvalidInput("audio metric frame size or channel count"));
        }
        for channel in &frame.channels { channel.validate()?; }
        let end = frame.pts.checked_add(i64::from(frame.samples)).ok_or(Error::LimitExceeded("audio timestamps"))?;
        let mut start = frame.pts;
        if self.last_start.is_some_and(|previous|frame.pts<=previous) {
            return Err(Error::InvalidInput("non-increasing audio timestamps"));
        }
        if let Some(previous) = self.last_end {
            let difference = i128::from(start) - i128::from(previous);
            if difference < -i128::from(self.tolerance) || end<=previous { return Err(Error::InvalidInput("overlapping audio timestamps")); }
            if difference > i128::from(self.tolerance) {
                self.discontinuities += 1;
                self.break_continuity()?;
            } else {
                // Bounded container timestamp quantization. Never count an
                // overlap twice, fill a positive gap, or reset source time.
                if difference!=0 {self.rounding_events+=1;}
                start = start.max(previous);
            }
        }
        self.frames += 1; self.last_end = Some(end); self.last_start=Some(frame.pts);
        let zero = Rational::new(0, 1)?;
        let start_time = Rational::new(start, i64::from(self.rate))?.checked_sub(self.origin)?.max(zero);
        let end_time = Rational::new(end, i64::from(self.rate))?.checked_sub(self.origin)?.min(self.duration);
        if start_time >= end_time { return Ok(()); }
        self.contributing += 1;
        let span = TimeRange::new(start_time, end_time)?;
        let dt = span.duration()?;
        self.observed = self.observed.checked_add(dt)?;
        let weight = dt.as_f64() * f64::from(self.rate);
        for ch in &frame.channels {
            if let Some(rms) = ch.rms_dbfs { self.sum_squares += 10f64.powf(rms / 10.0) * weight; }
            self.weighted_samples += weight;
            self.peak = max_level(self.peak, ch.peak_dbfs);
            self.clipped |= ch.peak_dbfs.is_some_and(|v| v >= 0.0);
        }
        let quiet = frame.channels.iter().all(|c| c.below(self.settings.quiet_rms_dbfs, self.settings.quiet_peak_dbfs));
        let active = frame.channels.iter().any(|c| c.active(f64::from(self.settings.quiet_rms_dbfs) + f64::from(self.settings.active_margin_db)));
        let required_flank = milliseconds(self.settings.flank_activity_ms)?;
        if quiet {
            // A short non-quiet burst did not prove the right-hand flank. Keep
            // both intervals independent; do not merge through the burst.
            if let Some(waiting) = self.waiting.take() { self.record(waiting, false)?; }
            if self.open.is_none() {
                self.open = Some(OpenQuiet { interval:QuietInterval {range:span, maximum_rms_dbfs:None,
                    maximum_peak_dbfs:None, bounded_by_activity:false}, left_active:self.active_duration >= required_flank });
            }
            let open = self.open.as_mut().expect("quiet state just created");
            open.interval.range.end = span.end;
            for ch in &frame.channels {
                open.interval.maximum_rms_dbfs = max_level(open.interval.maximum_rms_dbfs, ch.rms_dbfs);
                open.interval.maximum_peak_dbfs = max_level(open.interval.maximum_peak_dbfs, ch.peak_dbfs);
            }
            self.quiet_duration = self.quiet_duration.checked_add(dt)?;
            self.active_duration = zero;
        } else {
            if let Some(open) = self.open.take() { self.waiting = Some(open); self.active_duration = zero; }
            if active { self.active_duration = self.active_duration.checked_add(dt)?.min(required_flank); }
            else {
                self.active_duration = zero;
                if let Some(waiting) = self.waiting.take() { self.record(waiting, false)?; }
            }
            if self.active_duration >= required_flank {
                if let Some(waiting) = self.waiting.take() { self.record(waiting, true)?; }
            }
        }
        Ok(())
    }
    fn record(&mut self, mut value: OpenQuiet, right_active: bool) -> Result<()> {
        if value.interval.range.duration()? < milliseconds(self.settings.min_quiet_ms)? { return Ok(()); }
        if self.quiet.len() >= MAX_QUIET_INTERVALS { return Err(Error::LimitExceeded("quiet intervals")); }
        value.interval.bounded_by_activity = value.left_active && right_active;
        self.quiet.push(value.interval); Ok(())
    }
    fn break_continuity(&mut self) -> Result<()> {
        if let Some(open) = self.open.take() { self.record(open, false)?; }
        if let Some(waiting) = self.waiting.take() { self.record(waiting, false)?; }
        self.active_duration = Rational::new(0, 1)?; Ok(())
    }
    pub fn finish(mut self, cancel: &Cancellation) -> Result<EnergyObservation> {
        cancel.check()?;
        if self.failed { return Err(Error::InvalidInput("failed audio analysis cannot be finalized")); }
        self.break_continuity()?;
        if self.contributing == 0 { return Err(Error::InvalidInput("no decoded audio in the selected video timeline")); }
        let uncovered = self.duration.checked_sub(self.observed)?.max(Rational::new(0,1)?);
        let rms = if self.sum_squares == 0.0 {None} else {Some(10.0 * (self.sum_squares/self.weighted_samples).log10())};
        Ok(EnergyObservation {sample_rate:self.rate, channel_count:self.channels, origin:self.origin, duration:self.duration,
            settings:self.settings, quiet:self.quiet, summary:EnergySummary {decoded_frames:self.frames,
                contributing_frames:self.contributing, observed_duration:self.observed, measured_quiet_duration:self.quiet_duration,
                uncovered_duration:uncovered, discontinuities:self.discontinuities, timestamp_tolerance_samples:self.tolerance,
                timestamp_rounding_events:self.rounding_events, rms_dbfs:rms, peak_dbfs:self.peak,
                peak_at_or_above_full_scale:self.clipped}})
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize)]
#[serde(rename_all="snake_case")]
pub enum PauseSkip { UnboundedActivity, MixedMusic, InsufficientSaving, ProtectedOrReviewed,
    OutsideEditableAssembly, ShortRetainedSegment, CloselySpaced, RemovalBudget, CutCountLimit }
#[derive(Debug, Clone, Serialize)]
pub struct SkippedQuiet { pub range: TimeRange, pub reason: PauseSkip }
#[derive(Debug, Clone, Serialize)]
pub struct PauseCandidate {
    pub operation: EditOperation,
    pub measured_quiet: TimeRange,
    pub retained_pause: Rational,
    pub peak_dbfs: Option<f64>,
    pub rms_dbfs: Option<f64>,
}
#[derive(Debug, Clone, Serialize)]
pub struct PauseReport {
    project_id: String, project_revision: u64, decision_sha256: String,
    source_sha256: String,
    settings: PauseSettings,
    energy: EnergySummary,
    warnings: Vec<String>,
    candidates: Vec<PauseCandidate>,
    skipped: Vec<SkippedQuiet>,
    accepted_duration: Rational,
    proposed_duration: Rational,
    proposed_removed_duration: Rational,
    retained_reviewed_decisions: usize,
}
impl PauseReport {
    /// Model-assisted analysis may only remove energy candidates. Provenance
    /// remains ordinary saved edit metadata; it grants no runtime authority.
    pub(crate) fn speech_filtered(mut self, keep:&[bool], provenance:&str)->Result<Self> {
        if keep.len()!=self.candidates.len(){return Err(Error::InvalidInput("speech candidate mask"));}
        let mut retained=Vec::new();
        for (mut candidate, keep) in self.candidates.into_iter().zip(keep.iter().copied()) {
            if keep {
                candidate.operation.reason.push_str(provenance);
                crate::project::text_ok(&candidate.operation.reason,1024)?;
                retained.push(candidate);
            }
        }
        let mut removed=Rational::new(0,1)?;
        for c in &retained {removed=removed.checked_add(c.operation.range.duration()?)?;}
        self.candidates=retained;self.proposed_removed_duration=removed;
        self.proposed_duration=self.accepted_duration.checked_sub(removed)?;
        self.warnings.push("Speech-aware filtering retained only energy candidates with complete low-probability coverage and confident speech flanks; all still require review.".into());
        Ok(self)
    }
    pub fn settings(&self)->&PauseSettings{&self.settings}
    pub fn energy(&self)->&EnergySummary{&self.energy}
    pub fn warnings(&self)->&[String]{&self.warnings}
    pub fn candidates(&self)->&[PauseCandidate]{&self.candidates}
    pub fn skipped(&self)->&[SkippedQuiet]{&self.skipped}
    pub fn accepted_duration(&self)->Rational{self.accepted_duration}
    pub fn proposed_duration(&self)->Rational{self.proposed_duration}
    pub fn proposed_removed_duration(&self)->Rational{self.proposed_removed_duration}
    pub fn retained_reviewed_decisions(&self)->usize{self.retained_reviewed_decisions}

    /// Analysis is a proposal, never authority. This checks the complete current
    /// edit digest before producing a new draft with all NEW operations pending.
    pub fn apply(&self, project: &mut Project) -> Result<()> {
        self.settings.validate()?;
        if project.id != self.project_id || project.revision != self.project_revision
            || project.decision_digest()? != self.decision_sha256
            || project.sources[0].fingerprint.sha256 != self.source_sha256 { return Err(Error::StaleReview); }
        check_preserved_fade(project, &self.settings)?;
        let mut draft = project.clone();
        draft.settings.pause_cleanup = Some(self.settings.clone());
        draft.replace_generated(PAUSE_GENERATOR, PAUSE_GENERATOR_VERSION,
            self.candidates.iter().map(|c|c.operation.clone()).collect())?;
        draft.validate()?;
        *project = draft; Ok(())
    }
}

/// Convert observations into source-bound, inspectable remove-range proposals.
/// The caller must supply observations obtained under the current source grant.
pub fn propose_pauses(project: &Project, observation: EnergyObservation, cancel: &Cancellation) -> Result<PauseReport> {
    project.validate()?; cancel.check()?;
    if project.sources.len()!=1 { return Err(Error::Unsupported("pause cleanup is single-source")); }
    let source=&project.sources[0];
    let audio=source.media.audio.as_ref().ok_or(Error::Unsupported("pause cleanup requires selected audio"))?;
    if audio.sample_rate!=Some(observation.sample_rate) || audio.channels.map(|v|v as usize)!=Some(observation.channel_count)
        || source.timeline_origin!=observation.origin || source.duration!=observation.duration {
        return Err(Error::InvalidProject("audio observations do not match selected source timing"));
    }
    let settings=observation.settings.clone(); check_preserved_fade(project,&settings)?;
    let digest=project.decision_digest()?;
    let mut base=project.clone();
    // Ignore unresolved proposals for duration/eligibility, not in the actual
    // project. Unreviewed output from this generator will be replaced on apply.
    base.operations.retain(|o| o.locked || o.user_override || !ours(o));
    for o in &mut base.operations { if o.disposition==Disposition::NeedsReview {o.enabled=false;} }
    let accepted=base.timeline()?;
    let retained_reviewed_decisions=base.operations.iter().filter(|o|ours(o)).count();
    let mut barriers=Vec::new();
    for clip in &project.assembly { if clip.locked {barriers.push(clip.range);} }
    for op in &project.operations {
        // Rejected/disabled manual decisions are deliberate vetoes during this
        // generator pass; reanalysis may not silently recreate their removal.
        if op.locked || op.user_override || matches!(op.origin,EditOrigin::Manual)
            || (op.kind==EditKind::ProtectRange && op.enabled && op.disposition!=Disposition::Ignore) {
            barriers.push(op.range);
        }
    }
    let mut candidates=Vec::new(); let mut skipped=Vec::new(); let zero=Rational::new(0,1)?;
    let mut removed=zero; let mut last_cut_end:Option<Rational>=None;
    let guard=milliseconds(settings.min_segment_ms)?;
    let spacing=milliseconds(settings.min_cut_spacing_ms)?;
    let before=milliseconds(settings.padding_before_ms)?;
    let after=milliseconds(settings.padding_after_ms)?;
    let keep=milliseconds(settings.min_retained_pause_ms)?.max(before.checked_add(after)?);
    let extra=keep.checked_sub(before.checked_add(after)?)?.checked_div(Rational::new(2,1)?)?;
    for q in observation.quiet {
        cancel.check()?;
        let skip=if !q.bounded_by_activity {Some(PauseSkip::UnboundedActivity)}
            else if settings.content==AudioContent::MixedMusic && !settings.allow_mixed_music_proposals {Some(PauseSkip::MixedMusic)}
            else {None};
        if let Some(reason)=skip {skipped.push(SkippedQuiet{range:q.range,reason});continue;}
        let start=q.range.start.checked_add(before)?.checked_add(extra)?;
        let end=q.range.end.checked_sub(after)?.checked_sub(extra)?;
        // Round removal INWARD to native audio samples so padding and the
        // minimum retained pause cannot be shortened by output rounding.
        let start=Rational::new(start.ceil_units(i64::from(observation.sample_rate))?,i64::from(observation.sample_rate))?;
        let end=Rational::new(end.floor_units(i64::from(observation.sample_rate))?,i64::from(observation.sample_rate))?;
        if end<=start || end.checked_sub(start)?<milliseconds(settings.min_removal_ms)? {
            skipped.push(SkippedQuiet{range:q.range,reason:PauseSkip::InsufficientSaving});continue;
        }
        let cut=TimeRange::new(start,end)?;
        // Do not split one quiet interval around a protected region: that would
        // manufacture extra cuts and small retained islands.
        if barriers.iter().any(|r|r.overlaps(&q.range)) {
            skipped.push(SkippedQuiet{range:q.range,reason:PauseSkip::ProtectedOrReviewed});continue;
        }
        let segment=accepted.segments.iter().find(|s|s.source_range.start<=cut.start && s.source_range.end>=cut.end);
        let Some(segment)=segment else {skipped.push(SkippedQuiet{range:q.range,reason:PauseSkip::OutsideEditableAssembly});continue;};
        if cut.start.checked_sub(segment.source_range.start)?<guard || segment.source_range.end.checked_sub(cut.end)?<guard {
            skipped.push(SkippedQuiet{range:q.range,reason:PauseSkip::ShortRetainedSegment});continue;
        }
        if last_cut_end.is_some_and(|last|cut.start.checked_sub(last).map_or(true,|dt|dt<spacing)) {
            skipped.push(SkippedQuiet{range:q.range,reason:PauseSkip::CloselySpaced});continue;
        }
        if candidates.len()>=usize::from(settings.max_cuts) || candidates.len()+accepted.segments.len()>=crate::project::MAX_RENDER_SEGMENTS {
            skipped.push(SkippedQuiet{range:q.range,reason:PauseSkip::CutCountLimit});continue;
        }
        let total=removed.checked_add(cut.duration()?)?;
        if total.checked_div(accepted.duration)?>Rational::new(i64::from(settings.max_removed_per_mille),1000)? {
            skipped.push(SkippedQuiet{range:q.range,reason:PauseSkip::RemovalBudget});continue;
        }
        // Source and quiet-run identity (not thresholds/padding) keeps the same
        // measured pause recognizable on a parameter-only recomputation.
        let identity=format!("{}|{}|{}|{}",source.fingerprint.sha256,source.id,q.range.start,q.range.end);
        let id=format!("pause-{:x}",Sha256::digest(identity.as_bytes()));
        let id=id[..54].to_owned();
        let reason=format!("Quiet interval measured on every selected channel, not verified speech absence. RMS <= {} dBFS; peak <= {} dBFS; retain {} seconds. Review words, breaths and music before approving.",settings.quiet_rms_dbfs,settings.quiet_peak_dbfs,keep);
        let operation=EditOperation{id,source_id:source.id.clone(),kind:EditKind::RemoveRange,range:cut,reason,
            origin:EditOrigin::Generator{id:PAUSE_GENERATOR.into(),version:PAUSE_GENERATOR_VERSION.into()},
            disposition:Disposition::NeedsReview,enabled:true,locked:false,user_override:false};
        candidates.push(PauseCandidate{operation,measured_quiet:q.range,retained_pause:q.range.duration()?.checked_sub(cut.duration()?)?,
            peak_dbfs:q.maximum_peak_dbfs,rms_dbfs:q.maximum_rms_dbfs});
        removed=total; last_cut_end=Some(end);
    }
    let mut warnings=vec!["Energy thresholds do not establish speech absence; every new cut requires review.".into()];
    match settings.content {
        AudioContent::Unknown=>warnings.push("Audio content is unknown. Check quiet speech, breathing and any music before approving.".into()),
        AudioContent::MixedMusic=>warnings.push("Removing time also jumps a mixed music bed; no seamless music reconstruction is provided.".into()),
        AudioContent::Dialogue=>warnings.push("Dialogue is a caller declaration, not a detected or verified property.".into()),
    }
    if observation.summary.uncovered_duration.positive() || observation.summary.discontinuities>0 {
        warnings.push("Missing or discontinuous audio was not treated as measured silence.".into());
    }
    if project.operations.iter().any(|o|o.enabled&&o.disposition==Disposition::NeedsReview&&!ours(o)) {
        warnings.push("Other pending decisions were excluded from this duration estimate and still block final rendering.".into());
    }
    if observation.summary.timestamp_rounding_events>0 {warnings.push("Audio timestamp quantization was bounded to the saved stream time base (at most 1ms plus one sample); preview cut boundaries before approval.".into());}
    if observation.summary.peak_at_or_above_full_scale {warnings.push("Full-scale audio peaks observed; no clipping repair is performed.".into());}
    let report=PauseReport {project_id:project.id.clone(),project_revision:project.revision,decision_sha256:digest,
        source_sha256:source.fingerprint.sha256.clone(),settings,energy:observation.summary,warnings,candidates,skipped,
        accepted_duration:accepted.duration,proposed_duration:accepted.duration.checked_sub(removed)?,
        proposed_removed_duration:removed,retained_reviewed_decisions};
    // Validate the actual candidate transaction and its hypothetical timeline,
    // so a later render cannot unexpectedly exceed segment/graph limits.
    let mut trial=project.clone(); report.apply(&mut trial)?;
    for o in &mut trial.operations {
        if o.disposition==Disposition::NeedsReview {
            if report.candidates.iter().any(|c|c.operation.id==o.id) {o.disposition=Disposition::AutoApply;}
            else {o.enabled=false;}
        }
    }
    let t=trial.timeline()?;
    if t.duration!=report.proposed_duration {return Err(Error::InvalidProject("pause proposal duration mismatch"));}
    let render=crate::edit_render::EditRender::from_project(&trial)?;
    render.filter_graph(source.media.video.index,source.media.audio.as_ref().map(|a|a.index),false)?;
    Ok(report)
}
pub(crate) fn ours(op:&EditOperation)->bool {matches!(&op.origin,EditOrigin::Generator{id,..} if id==PAUSE_GENERATOR)}
pub(crate) fn check_preserved_fade(project:&Project,settings:&PauseSettings)->Result<()> {
    if let Some(old)=&project.settings.pause_cleanup {
        if old.join_fade_ms!=settings.join_fade_ms && project.operations.iter().any(|o|ours(o)&&(o.locked||o.user_override)) {
            return Err(Error::InvalidProject("changing join fades would alter reviewed pause edits; preserve the saved fade setting"));
        }
    }
    Ok(())
}
fn max_level(a:Option<f64>,b:Option<f64>)->Option<f64>{match (a,b){(Some(a),Some(b))=>Some(a.max(b)),(Some(v),None)|(None,Some(v))=>Some(v),(None,None)=>None}}
pub(crate) fn milliseconds(n:u32)->Result<Rational>{Rational::new(i64::from(n),1000)}
