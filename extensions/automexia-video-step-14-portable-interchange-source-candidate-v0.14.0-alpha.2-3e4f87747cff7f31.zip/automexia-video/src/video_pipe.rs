//! Correlates FFmpeg's raw RGB output with its named showinfo PTS stream.
//! Both pipes are drained by the existing bounded process runner. Ordering across
//! pipes is NOT assumed. Mismatch, overflow, or a truncated final frame fails.
use crate::{Error,Rational,Result};
use crate::color_analysis::{VideoFrame,VideoFrameSink};
use std::collections::VecDeque;

pub const MAX_PENDING_FRAMES:usize=64;
pub const MAX_VIDEO_DIAGNOSTIC_BYTES:u64=512*1024*1024;
const MAX_LINE:usize=16*1024;
#[derive(Debug)]
struct Header {pts:Rational,duration:Option<Rational>}
pub struct VideoPipe {
    width:u32,height:u32,time_base:Rational,frame_bytes:usize,max_frames:u64,expected_range:&'static str,
    line:Vec<u8>,partial:Vec<u8>,frames:VecDeque<Vec<u8>>,headers:VecDeque<Header>,
    seen:u64,emitted:u64,source_seen:u64,source_tags:u64,diagnostic_bytes:u64,failed:bool,
}
impl VideoPipe {
    pub fn new(width:u32,height:u32,time_base:Rational,max_frames:u64,full_range:bool)->Result<Self> {
        if width==0||height==0||width>320||height>320||width*height>57_600||!time_base.positive()||
            max_frames==0||max_frames>crate::color::MAX_VIDEO_FRAMES {return Err(Error::InvalidInput("video pipe dimensions"));}
        let frame_bytes=width as usize*height as usize*3;
        Ok(Self{width,height,time_base,frame_bytes,max_frames,expected_range:if full_range{"pc"}else{"tv"},line:vec![],partial:Vec::with_capacity(frame_bytes),
            frames:VecDeque::new(),headers:VecDeque::new(),seen:0,emitted:0,source_seen:0,source_tags:0,diagnostic_bytes:0,failed:false})
    }
    pub fn pixels(&mut self,bytes:&[u8],sink:&mut VideoFrameSink<'_>)->Result<()> {
        if self.failed{return Err(Error::InvalidInput("failed video pipe"));}
        let result=self.pixels_inner(bytes,sink);if result.is_err(){self.failed=true;}result
    }
    fn pixels_inner(&mut self,mut bytes:&[u8],sink:&mut VideoFrameSink<'_>)->Result<()> {
        if bytes.len()>1024*1024{return Err(Error::LimitExceeded("RGB chunk"));}
        while !bytes.is_empty() {
            let n=(self.frame_bytes-self.partial.len()).min(bytes.len());
            self.partial.extend_from_slice(&bytes[..n]);bytes=&bytes[n..];
            if self.partial.len()==self.frame_bytes {
                if self.frames.len()>=MAX_PENDING_FRAMES || self.emitted+self.frames.len() as u64>=self.max_frames {
                    return Err(Error::LimitExceeded("unmatched RGB frames"));
                }
                let frame=std::mem::replace(&mut self.partial,Vec::with_capacity(self.frame_bytes));
                self.frames.push_back(frame);self.drain(sink)?;
            }
        }Ok(())
    }
    pub fn diagnostics(&mut self,bytes:&[u8],sink:&mut VideoFrameSink<'_>)->Result<()> {
        if self.failed{return Err(Error::InvalidInput("failed video pipe"));}
        let result=self.diagnostics_inner(bytes,sink);if result.is_err(){self.failed=true;}result
    }
    fn diagnostics_inner(&mut self,bytes:&[u8],sink:&mut VideoFrameSink<'_>)->Result<()> {
        if bytes.len()>1024*1024{return Err(Error::LimitExceeded("video diagnostic chunk"));}
        self.diagnostic_bytes=self.diagnostic_bytes.checked_add(bytes.len() as u64).ok_or(Error::LimitExceeded("video diagnostics"))?;
        if self.diagnostic_bytes>MAX_VIDEO_DIAGNOSTIC_BYTES{return Err(Error::LimitExceeded("video diagnostics"));}
        for byte in bytes {
            if *byte==b'\n' {
                let bytes=std::mem::take(&mut self.line);
                let line=std::str::from_utf8(&bytes).map_err(|_|Error::InvalidInput("video diagnostic UTF-8"))?;
                self.parse_line(line,sink)?;
            }else{
                if self.line.len()>=MAX_LINE{return Err(Error::LimitExceeded("video diagnostic line"));}
                self.line.push(*byte);
            }
        }Ok(())
    }
    fn parse_line(&mut self,line:&str,sink:&mut VideoFrameSink<'_>)->Result<()> {
        if line.starts_with("[showinfo@amx_source @ ") {
            if line.contains("color_trc:") {
                if self.source_seen!=self.source_tags+1{return Err(Error::InvalidInput("duplicate or missing source color tags"));}
                if field(line,"color_trc:")!=Some("bt709") || field(line,"color_primaries:")!=Some("bt709") ||
                    field(line,"color_space:")!=Some("bt709") || field(line,"color_range:")!=Some(self.expected_range) {
                    return Err(Error::Unsupported("decoded frame changed SDR color interpretation"));
                }
                self.source_tags+=1;
            }
            if line.contains("Mastering display")||line.contains("DOVI")||line.contains("Dolby")||line.contains("HDR")||line.contains("Content light") {
                return Err(Error::Unsupported("decoded frame contains unqualified HDR side data"));
            }
            if let Some(n)=field(line,"n:") {
                if n.parse::<u64>().ok()!=Some(self.source_seen) || self.source_seen!=self.source_tags || self.source_seen>=self.max_frames {
                    return Err(Error::InvalidInput("source frame sequence or color tags"));
                }
                if field(line,"i:")!=Some("P") || !matches!(field(line,"fmt:"),Some("yuv420p"|"yuv422p"|"yuv444p"|"yuvj420p"|"yuvj422p"|"yuvj444p"|"nv12")) {
                    return Err(Error::Unsupported("decoded frame is not qualified progressive 8-bit SDR"));
                }
                self.source_seen+=1;
            }
            return Ok(());
        }
        if !line.starts_with("[showinfo@amx_rgb @ "){return Ok(());}
        let Some(n)=field(line,"n:") else{return Ok(())};
        let n=n.parse::<u64>().map_err(|_|Error::InvalidInput("frame sequence"))?;
        if n!=self.seen||n>=self.max_frames||self.headers.len()>=MAX_PENDING_FRAMES || self.source_tags<=n {
            return Err(Error::InvalidInput("duplicate, missing, reset or excessive frame headers"));
        }
        let size=format!("{}x{}",self.width,self.height);
        if field(line,"s:")!=Some(size.as_str())||field(line,"fmt:")!=Some("rgb24") {
            return Err(Error::InvalidInput("analysis frame geometry changed"));
        }
        let pts=field(line,"pts:").ok_or(Error::InvalidInput("frame PTS missing"))?.parse::<i64>().map_err(|_|Error::InvalidInput("frame PTS"))?;
        let duration=field(line,"duration:").map(|s|s.parse::<i64>().map_err(|_|Error::InvalidInput("frame duration"))).transpose()?;
        let duration=match duration{Some(n) if n>0=>Some(self.time_base.ticks(n)?),Some(n) if n<0=>return Err(Error::InvalidInput("negative frame duration")),_=>None};
        self.headers.push_back(Header{pts:self.time_base.ticks(pts)?,duration});self.seen+=1;
        self.drain(sink)
    }
    fn drain(&mut self,sink:&mut VideoFrameSink<'_>)->Result<()> {
        while !self.headers.is_empty()&&!self.frames.is_empty() {
            let header=self.headers.pop_front().ok_or(Error::InvalidInput("frame header queue"))?;
            let rgb=self.frames.pop_front().ok_or(Error::InvalidInput("frame pixel queue"))?;
            sink(VideoFrame{pts:header.pts,duration:header.duration,width:self.width,height:self.height,rgb:&rgb})?;
            self.emitted+=1;
        }Ok(())
    }
    pub fn finish(self)->Result<u64> {
        if self.failed||self.emitted==0||!self.partial.is_empty()||!self.line.is_empty()||
            !self.frames.is_empty()||!self.headers.is_empty()||self.emitted!=self.seen || self.source_seen!=self.seen || self.source_tags!=self.seen {
            return Err(Error::InvalidInput("incomplete RGB/timestamp stream"));
        }Ok(self.emitted)
    }
}
fn field<'a>(line:&'a str,key:&str)->Option<&'a str> {
    // Require a token boundary: pts: must not accidentally match duration/other
    // fields. FFmpeg puts either zero or several spaces after the colon.
    let mut from=0;
    while let Some(i)=line[from..].find(key) {
        let i=from+i;
        if i==0||line.as_bytes()[i-1].is_ascii_whitespace() {
            return line[i+key.len()..].trim_start().split_whitespace().next();
        }
        from=i+key.len();
    }None
}
