//! Review/proxy entry points on the same VideoExtension and existing MediaHost.
//! Execute media calls on the host job executor, never the input/render thread.
use crate::extension::emit;
use crate::host::{InputFile, MediaHost, MediaTask, OutputPolicy, ProgressSink};
use crate::plan::{validate_output, RenderPlan};
use crate::preview::{PreviewOpener, PreviewPlan, PreviewRequest, PreviewSet, PreviewSide,
    ProxyClip, ProxyMetadata, VerifiedPreview};
use crate::progress::Stage;
use crate::project::Project;
use crate::review::ReviewSession;
use crate::{Cancellation, Error, Result, VideoExtension};

impl<H: MediaHost> VideoExtension<H> {
    /// Core behind `video review PROJECT`: the host loads through ProjectStore,
    /// displays the returned view and routes existing inputs to ReviewSession.
    /// No file access, codec startup or background work is needed to create it.
    pub fn review_project(&self, project: &Project) -> Result<ReviewSession> {
        let _job = self.begin(&Cancellation::new())?;
        ReviewSession::with_owner(project.clone(), self.workflow_scope(&Cancellation::new())?)
    }

    /// Render short original/proposed media using the same tested edit planner.
    /// Both files remain unpublished private leases. Any error drops ALL acquired
    /// leases, including a completed A file when B subsequently fails.
    pub fn preview_edit(&self, project: &Project, request: &PreviewRequest, cancel: &Cancellation,
        progress: &mut ProgressSink<'_>) -> Result<PreviewSet> {
        let prepared = PreviewPlan::build(project, request)?;
        let job = self.begin(cancel)?;
        emit(progress, Stage::Inspecting)?;
        let source = &project.sources[0];
        let source_path = source.resolve(&request.project_file)?;
        let input = self.host().inspect_input(&source_path, &job.cancel)?;
        source.check_input(&input)?;
        emit(progress, Stage::RuntimeCheck)?;
        let runtime = self.host().runtime_capabilities(&job.cancel)?;
        let current = self.probe_path(&input.canonical_path, &job.cancel, progress)?;
        source.check_media(&current)?;
        // Validate both branches before allocating either output file.
        let before_plan = prepared.render_plan(PreviewSide::Before, &current, &runtime)?
            .ok_or(Error::InvalidProject("original preview plan"))?;
        let mut proposed_plan = prepared.render_plan(PreviewSide::Proposed, &current, &runtime)?;
        if let Some(plan)=&proposed_plan {self.verify_plan_timing(plan,&input,&current,&job.cancel,progress)?;}
        let enhancement=project.settings.voice_enhancement.as_ref().filter(|_|proposed_plan.is_some());
        let enhanced_input=if let Some(enhancement)=enhancement {
            enhancement.validate()?;let path=enhancement.resolve(&request.project_file)?;
            let stem=self.host().inspect_input(&path,&job.cancel)?;enhancement.check_input(&stem)?;
            let probe=self.host().run_audio(&crate::voice_render::AudioTask::ProbeStem{input:stem.clone()},&job.cancel,&mut |_|{})?;
            let media=crate::media::parse_probe(&probe.stdout)?;crate::enhancement::validate_enhanced_media(&media,&enhancement.receipt,source.duration)?;
            if let Some(plan)=&mut proposed_plan{plan.attach_enhanced_audio(&stem.canonical_path)?;}Some(stem)
        }else{None};
        if let Some(mut reference)=prepared.voice_reference_plan(&current,&runtime)? {
            if let Some(stem)=&enhanced_input{reference.attach_enhanced_audio(&stem.canonical_path)?;self.host().revalidate_input(stem,&job.cancel)?;}
            self.prepare_voice(&mut reference,&input,std::time::Duration::from_secs(7200),&job.cancel,progress)?;
            if let Some(stem)=&enhanced_input{self.host().revalidate_input(stem,&job.cancel)?;}
            if let Some(plan)=&mut proposed_plan {plan.inherit_voice_gain(&reference)?;}
        }
        job.cancel.check()?;
        let before = self.render_proxy(&input, &current, &before_plan, None, request,
            &prepared.description().request_key, PreviewSide::Before, &job.cancel, progress)?;
        let proposed = proposed_plan.as_ref().map(|plan| self.render_proxy(&input, &current, plan, enhanced_input.as_ref(), request,
            &prepared.description().request_key, PreviewSide::Proposed, &job.cancel, progress)).transpose()?;
        self.host().revalidate_input(&input, &job.cancel)?;
        job.cancel.check()?;
        Ok(PreviewSet { source: input, description: prepared.description().clone(), runtime, before, proposed })
    }

    /// Hand off only a current, revalidated file to the host's existing approved
    /// opener. The borrowing contract keeps the leases alive during this call;
    /// asynchronous host playback must also retain PreviewSet until playback ends.
    pub fn open_preview(&self, previews: &PreviewSet, project: &Project, side: PreviewSide,
        opener: &mut dyn PreviewOpener, cancel: &Cancellation) -> Result<()> {
        previews.check_current(project)?;
        let clip = previews.clip(side).ok_or(Error::EmptyTimeline)?;
        let job = self.begin(cancel)?;
        self.host().revalidate_input(&previews.source, &job.cancel)?;
        self.host().revalidate_input(&clip.identity, &job.cancel)?;
        if let Some(p)=&clip.presentation{p.revalidate(None,&job.cancel)?;}
        // A lease changing its reported path is not the artifact we validated.
        if clip.lease.path() != clip.identity.canonical_path {
            return Err(Error::InvalidOutput("preview lease path changed"));
        }
        job.cancel.check()?;
        let verified = VerifiedPreview { file: &clip.identity, metadata: &clip.metadata,
            description: &previews.description };
        std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| opener.open(&verified)))
            .map_err(|_|Error::CallbackPanicked)?
    }

    fn render_proxy(&self, input: &InputFile, current: &crate::media::MediaInfo, plan: &RenderPlan, secondary_audio:Option<&InputFile>,
        request: &PreviewRequest, key: &str, side: PreviewSide, cancel: &Cancellation,
        progress: &mut ProgressSink<'_>) -> Result<ProxyClip> {
        let name = match side { PreviewSide::Before => "before", PreviewSide::Proposed => "proposed" };
        let destination = request.scratch_directory.join(format!("video-review-{key}-{name}.mp4"));
        cancel.check()?;
        let lease = self.host().stage_output(input, &destination, &OutputPolicy::CreateNew, cancel)?;
        let mut plan=plan.clone();
        let presentation=match plan.presentation(){Some(p) if p.has_pixels()=>{emit(progress,Stage::PreparingGraphics)?;Some(self.host().prepare_presentation(p,&request.project_file,cancel)?)},_=>None};
        if let Some(p)=&presentation{p.revalidate(Some(&destination),cancel)?;plan.attach_presentation(&**p)?;}

        let (identity,output,audio)=loop {
        plan.arguments(&input.canonical_path, lease.path())?;
        self.host().revalidate_input(input, cancel)?;if let Some(stem)=secondary_audio{self.host().revalidate_input(stem,cancel)?;}
        emit(progress, Stage::Rendering)?;
        self.host().run(&MediaTask::Render { input: input.canonical_path.clone(),
            staged_output: lease.path().to_owned(), plan: plan.clone() }, cancel, progress)?;
        cancel.check()?;
        // Check compressed size before the full decode-validation pass too.
        let identity = self.host().inspect_input(lease.path(), cancel)?;
        if identity.stamp.size > request.options.max_bytes { return Err(Error::LimitExceeded("preview file bytes")); }
        if identity.canonical_path != lease.path() { return Err(Error::InvalidOutput("preview lease must expose its canonical path")); }
        emit(progress, Stage::Validating)?;
        let output = self.probe_path(lease.path(), cancel, progress)?;
        validate_output(current, &output, &plan)?;
        self.host().run(&MediaTask::ValidateDecode { input: lease.path().to_owned(),
            has_audio: plan.selected().audio.is_some() }, cancel, progress)?;
        let result=self.check_voice_output(&mut plan,lease.path(),&output,std::time::Duration::from_secs(7200),cancel,progress)?;
        self.host().revalidate_input(&identity,cancel)?;
        match result {
            crate::voice_workflow::AudioValidation::Retry=>continue,
            crate::voice_workflow::AudioValidation::Ready(audio)=>break (identity,output,audio),
        }
        };
        self.host().revalidate_input(&identity, cancel)?;
        self.host().revalidate_input(input, cancel)?;if let Some(stem)=secondary_audio{self.host().revalidate_input(stem,cancel)?;}
        cancel.check()?;
        let video = output.streams.iter().find(|s| s.kind == "video")
            .ok_or(Error::InvalidOutput("preview video absent"))?;
        let duration = video.exact_duration().ok_or(Error::InvalidOutput("preview duration absent"))?;
        // A frame may extend slightly beyond the exact planned duration. The
        // plan already bounded both complete proxy timelines before staging;
        // normal edit validation also bounds their frame-clock rounding.
        if duration > request.options.max_window.checked_add(crate::Rational::new(1,1)?)? {
            return Err(Error::LimitExceeded("preview duration"));
        }
        let (width,height) = plan.dimensions();
        let metadata = ProxyMetadata { side, duration, width, height,
            sample_aspect_ratio: plan.sample_aspect_ratio(), byte_length: identity.stamp.size,
            sha256: identity.stamp.sha256.clone(), full_decode_validated: true,
            audio_available: plan.selected().audio.is_some(), audio };
        if let Some(p)=&presentation{p.revalidate(None,cancel)?;}
        Ok(ProxyClip { lease, identity, metadata, presentation })
    }
}
