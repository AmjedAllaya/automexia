//! Reviewed variant-local playback speed and pairwise cross-dissolves.
//! Source edits stay in source time; overlap is represented explicitly.
use crate::{Disposition, Error, Rational, Result};
use crate::project::{TimeRange, Timeline, TimelineSegment};
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all="snake_case")]
pub enum PlaybackSpeed { Half, Normal, Double }
impl PlaybackSpeed {
    pub fn ratio(self) -> Rational { match self { Self::Half => Rational::new(1,2).unwrap(), Self::Normal => Rational::new(1,1).unwrap(), Self::Double => Rational::new(2,1).unwrap() } }
}
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct TimingSettings {
    pub enabled: bool,
    pub disposition: Disposition,
    pub locked: bool,
    pub speed: PlaybackSpeed,
    /// Output-time duration used at every retained-segment join. Zero means cuts.
    pub dissolve: Rational,
}
impl Default for TimingSettings {
    fn default() -> Self { Self { enabled:true, disposition:Disposition::NeedsReview, locked:false, speed:PlaybackSpeed::Normal, dissolve:Rational::new(0,1).unwrap() } }
}
impl TimingSettings {
    pub fn validate(&self)->Result<()> {
        if self.dissolve.numerator()<0 || self.dissolve>Rational::new(5,1)? { return Err(Error::InvalidProject("dissolve duration must be between zero and five seconds")); } Ok(())
    }
    pub fn active(&self)->bool { self.enabled && self.disposition==Disposition::AutoApply }
    pub fn ensure_resolved(&self)->Result<()> { self.validate()?; if self.enabled && self.disposition==Disposition::NeedsReview { Err(Error::UnresolvedEdits) } else { Ok(()) } }
    pub fn apply(&self,timeline:&Timeline)->Result<Timeline> {
        self.ensure_resolved()?; if !self.active() { return Ok(timeline.clone()); }
        let mut segments=Vec::with_capacity(timeline.segments.len()); let mut cursor=Rational::new(0,1)?;
        for (i,s) in timeline.segments.iter().enumerate() {
            // Assembly may already assign a speed to each occurrence. Scale
            // its established output length; deriving from source length here
            // would silently discard the reviewed entry speed.
            let length=s.output_range.duration()?.checked_div(self.speed.ratio())?;
            if timeline.segments.len()>1 && self.dissolve.ticks(2)?>length { return Err(Error::Unsupported("dissolve exceeds half a participating segment; triple overlap is unsupported")); }
            if i>0 { cursor=cursor.checked_sub(self.dissolve)?; }
            let end=cursor.checked_add(length)?;
            segments.push(TimelineSegment{source_id:s.source_id.clone(),source_range:s.source_range,output_range:TimeRange::new(cursor,end)?}); cursor=end;
        }
        Ok(Timeline{segments,duration:cursor})
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    fn timeline()->Timeline { Timeline{segments:vec![TimelineSegment{source_id:"source".into(),source_range:TimeRange::new(Rational::new(0,1).unwrap(),Rational::new(4,1).unwrap()).unwrap(),output_range:TimeRange::new(Rational::new(0,1).unwrap(),Rational::new(4,1).unwrap()).unwrap()},TimelineSegment{source_id:"source".into(),source_range:TimeRange::new(Rational::new(6,1).unwrap(),Rational::new(10,1).unwrap()).unwrap(),output_range:TimeRange::new(Rational::new(4,1).unwrap(),Rational::new(8,1).unwrap()).unwrap()}],duration:Rational::new(8,1).unwrap()} }
    #[test] fn reviewed_rate_and_overlap_are_exact() { let mut s=TimingSettings::default(); assert!(s.apply(&timeline()).is_err());s.disposition=Disposition::AutoApply;s.speed=PlaybackSpeed::Double;s.dissolve=Rational::new(1,2).unwrap(); let t=s.apply(&timeline()).unwrap();assert_eq!(t.duration,Rational::new(7,2).unwrap());assert_eq!(t.segments[1].output_range.start,Rational::new(3,2).unwrap()); }
    #[test] fn pending_disabled_is_identity() { let mut s=TimingSettings::default();s.enabled=false;assert_eq!(s.apply(&timeline()).unwrap().duration,timeline().duration); }
    #[test] fn triple_overlap_fails() { let s=TimingSettings{disposition:Disposition::AutoApply,dissolve:Rational::new(3,1).unwrap(),..Default::default()};assert!(s.apply(&timeline()).is_err()); }
    #[test] fn global_speed_preserves_existing_per_entry_rates() {
        let mut t=timeline();t.segments[0].output_range=TimeRange::new(Rational::new(0,1).unwrap(),Rational::new(8,1).unwrap()).unwrap();
        t.segments[1].output_range=TimeRange::new(Rational::new(8,1).unwrap(),Rational::new(10,1).unwrap()).unwrap();t.duration=Rational::new(10,1).unwrap();
        let settings=TimingSettings{disposition:Disposition::AutoApply,speed:PlaybackSpeed::Double,..Default::default()};
        let applied=settings.apply(&t).unwrap();assert_eq!(applied.duration,Rational::new(5,1).unwrap());
        assert_eq!(applied.segments[0].output_range.duration().unwrap(),Rational::new(4,1).unwrap());
        assert_eq!(applied.segments[1].output_range.duration().unwrap(),Rational::new(1,1).unwrap());
    }
}
