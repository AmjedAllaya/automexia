//! Step 13D: face observations are advisory. The detector reports normalized
//! rectangles; deterministic Rust associates tracks, chooses conservative groups,
//! and proposes editable source-time crop keys. Nothing here infers speech.
use crate::{Cancellation, Error, Rational, Result};
use crate::model_pack::{ModelActivation, ModelIdentity, YUNET_CONTRACT, ULTRAFACE_CONTRACT};
use crate::project::{Disposition, Project, TimeRange};
use crate::reframe::{CropKeyframe,CropPose,CropShot,CropTrack,DisplayRect,FramingMode,FramingSettings,MotionLimits,SourceGeometry,UnitPoint};
use crate::presentation::Anchor;
use serde::{Deserialize,Serialize};
use std::collections::{BTreeMap,BTreeSet};

mod choices;
pub use choices::{FaceApplyChoices,FaceAnchorChoice,FaceAnchorTarget,FacePunchInChoice};

pub const FACE_PIPELINE_VERSION:u32=2;
pub const MAX_FACE_DETECTIONS:usize=64;
pub const MAX_FACE_SAMPLES:usize=2048;
pub const MAX_FACE_TRACKS:usize=128;

#[derive(Debug,Clone,Copy,PartialEq,Serialize,Deserialize)]
#[serde(deny_unknown_fields)]
pub struct FaceDetection {pub rect:DisplayRect,pub confidence:f32}
impl FaceDetection {pub fn validate(self)->Result<()>{self.rect.validate()?;if !self.confidence.is_finite()||!(0.0..=1.0).contains(&self.confidence){return Err(Error::InvalidOutput("face confidence"));}Ok(())}}

pub struct FaceInput<'a>{pub width:u32,pub height:u32,pub source_time:Rational,pub rgb:&'a [u8]}
pub trait FaceDetector:Send+Sync {
    fn identity(&self)->&ModelIdentity;
    fn revalidate(&self,cancel:&Cancellation)->Result<()>;
    fn detect(&self,input:FaceInput<'_>,cancel:&Cancellation)->Result<Vec<FaceDetection>>;
}

#[derive(Debug,Clone,Serialize,Deserialize)]
#[serde(deny_unknown_fields)]
pub struct FaceSettings {
    pub version:u32,
    pub sample_interval_ms:u32,
    pub min_confidence:f32,
    pub association_iou:f64,
    pub association_center:f64,
    pub max_size_ratio:f64,
    pub max_missed_samples:u8,
    pub group_center_distance:f64,
    pub face_margin:f64,
    pub headroom:f64,
    pub max_zoom:f64,
    pub smoothing:f64,
    pub min_track_samples:u32,
}
impl Default for FaceSettings {fn default()->Self{Self{version:FACE_PIPELINE_VERSION,sample_interval_ms:250,min_confidence:0.70,association_iou:0.15,association_center:0.18,max_size_ratio:2.5,max_missed_samples:2,group_center_distance:0.22,face_margin:0.35,headroom:0.20,max_zoom:1.8,smoothing:0.35,min_track_samples:3}}}
impl FaceSettings {pub fn validate(&self)->Result<()>{
    if self.version!=FACE_PIPELINE_VERSION||!(80..=2000).contains(&self.sample_interval_ms)||!(0.1..=0.999).contains(&self.min_confidence)
        ||!finite(self.association_iou,0.0,1.0)||!finite(self.association_center,0.01,1.0)||!finite(self.max_size_ratio,1.0,10.0)
        ||self.max_missed_samples>12||!finite(self.group_center_distance,0.01,1.0)||!finite(self.face_margin,0.0,2.0)
        ||!finite(self.headroom,0.0,1.0)||!finite(self.max_zoom,1.0,4.0)||!finite(self.smoothing,0.0,1.0)
        ||!(2..=64).contains(&self.min_track_samples){return Err(Error::InvalidInput("face-analysis settings"));}Ok(())}}
fn finite(v:f64,a:f64,b:f64)->bool{v.is_finite()&&v>=a&&v<=b}

#[derive(Debug,Clone,Serialize)]
pub struct FaceTrackSummary {pub id:u32,pub samples:u32,pub first:Rational,pub last:Rational,pub mean_confidence:f64,pub mean_area:f64}
#[derive(Debug,Clone,Serialize)]
pub struct FaceMetrics {pub sampled_frames:u64,pub detected_faces:u64,pub reliable_tracks:u32,pub no_face_samples:u64,pub face_clipping_events:u64,pub mean_center_jitter:f64,pub avoidance_layers:u64,pub avoidance_layers_with_safe_anchor:u64,pub manual_corrections:Option<u32>}
#[derive(Debug,Clone,Serialize)]
pub struct FaceAvoidanceSuggestion {pub shot:TimeRange,pub layer_id:String,pub target:FaceAnchorTarget,pub anchors:Vec<Anchor>}
#[derive(Debug,Clone,Serialize)]
pub struct FaceFramingReport {
    pub model:ModelIdentity,pub settings:FaceSettings,pub variant_id:String,
    pub tracks:Vec<FaceTrackSummary>,pub proposed:FramingSettings,pub avoidance:Vec<FaceAvoidanceSuggestion>,pub safe_punch_in_ranges:Vec<TimeRange>,pub metrics:FaceMetrics,
    #[serde(skip)] activation:ModelActivation,
    #[serde(skip)] owner:Cancellation,
    #[serde(skip)] binding:String,
    #[serde(skip)] original_samples:Vec<FaceSample>,
    #[serde(skip)] original_settings:FaceSettings,
    #[serde(skip)] original_variant:String,
}
impl FaceFramingReport {
    /// Adopts an editable proposal only. Approval remains a separate review action.
    pub fn apply(&self,project:&mut Project,activation:&ModelActivation)->Result<()> {
        self.apply_choices(project,activation,&FaceApplyChoices::default())
    }
    pub(crate) fn bind_owner(&mut self,owner:&Cancellation){self.owner=owner.clone();}
}

#[derive(Debug,Clone)]
pub(crate) struct FaceSample {pub at:Rational,pub detections:Vec<FaceDetection>}
#[derive(Debug,Clone)]struct Obs{at:Rational,rect:DisplayRect,confidence:f32}
#[derive(Debug,Clone)]struct Track{id:u32,obs:Vec<Obs>,missed:u8,last:DisplayRect,velocity:(f64,f64)}

pub(crate) fn build_report(project:&Project,variant_id:&str,samples:Vec<FaceSample>,settings:FaceSettings,activation:&ModelActivation)->Result<FaceFramingReport>{
    project.validate()?;settings.validate()?;activation.check()?;activation.identity().validate()?;
    if !matches!(activation.identity().contract.as_str(),YUNET_CONTRACT|ULTRAFACE_CONTRACT){return Err(Error::Unsupported("face detector model contract"));}
    if project.sources.len()!=1{return Err(Error::Unsupported("face framing is single-source"));}
    if samples.len()>MAX_FACE_SAMPLES{return Err(Error::LimitExceeded("face sample count"));}
    let variant=project.variant(variant_id)?;let base=variant.framing.as_ref().ok_or(Error::InvalidProject("face framing requires an explicit output framing target"))?;
    let source=&project.sources[0];base.validate(source)?;
    let original_samples=samples.clone();let original_settings=settings.clone();let shots=shot_ranges(project)?;
    let sample_count=samples.len() as u64;let mut tracks:Vec<Track>=Vec::new();let mut next_id=1u32;let mut detected=0u64;let mut no_face=0u64;
    let mut previous_time=None;let mut previous_shot=None;
    for sample in samples{
        if sample.at.numerator()<0||sample.at>=source.duration||previous_time.is_some_and(|p|sample.at<=p){return Err(Error::InvalidInput("face sample time ordering"));}
        let tick=source.media.video.time_base.ok_or(Error::InvalidProject("face source clock"))?;
        if sample.at.checked_div(tick)?.denominator()!=1{return Err(Error::InvalidInput("face sample is not on source clock"));}
        previous_time=Some(sample.at);
        let shot=shots.iter().position(|r|r.contains(sample.at)).ok_or(Error::InvalidInput("face sample outside shot partition"))?;
        if previous_shot!=Some(shot){for track in &mut tracks{track.missed=u8::MAX;}previous_shot=Some(shot);}
        if sample.detections.len()>MAX_FACE_DETECTIONS{return Err(Error::LimitExceeded("face detections per frame"));}
        let mut detections=Vec::new();for d in sample.detections{d.validate()?;if d.confidence>=settings.min_confidence{detections.push(d);}}
        detected+=detections.len() as u64;if detections.is_empty(){no_face+=1;}
        associate(&mut tracks,&detections,sample.at,&settings,&mut next_id)?;
        if tracks.len()>MAX_FACE_TRACKS{return Err(Error::LimitExceeded("face track count"));}
    }
    let reliable:Vec<_>=tracks.iter().filter(|t|t.obs.len()>=settings.min_track_samples as usize).collect();
    let geometry=SourceGeometry::from_source(source)?;
    let mut crop_shots=Vec::new();let mut selected_by_shot:Vec<(TimeRange,Vec<Obs>,usize)>=Vec::new();
    for shot in &shots{
        let (observations,subjects)=choose_subjects(&reliable,*shot,&settings)?;
        let motion=match &base.mode{FramingMode::Crop{track}=>track.motion,_=>MotionLimits::default()};
        let mut keys=keys_for_shot(&observations,*shot,geometry,base.target,&settings,motion)?;
        if keys.is_empty(){match &base.mode{
            FramingMode::Crop{track}=>{keys.push(CropKeyframe{at:shot.start,pose:track.pose_at(shot.start)?});for old in &track.shots{for key in &old.keyframes{if key.at>shot.start&&key.at<=shot.end{keys.push(key.clone());}}}keys.sort_by_key(|k|k.at);keys.dedup_by_key(|k|k.at);},
            FramingMode::Fit{..}=>keys.push(CropKeyframe{at:shot.start,pose:CropPose::centered()})}}
        crop_shots.push(CropShot{range:*shot,keyframes:keys});selected_by_shot.push((*shot,observations,subjects));
    }
    let preserve_fit=matches!(base.mode,FramingMode::Fit{..})&&selected_by_shot.iter().any(|(_,obs,_)|obs.is_empty());
    let mut proposed=base.clone();
    if !preserve_fit{let motion=match &base.mode{FramingMode::Crop{track}=>track.motion,_=>MotionLimits::default()};let mut track=CropTrack{shots:crop_shots,motion}.suppress_small_moves()?;
        if track.validate(geometry,base.target,source.duration).is_err(){for shot in &mut track.shots{let pose=shot.keyframes.first().map(|k|k.pose).unwrap_or(CropPose::centered());shot.keyframes=vec![CropKeyframe{at:shot.range.start,pose}];}track.validate(geometry,base.target,source.duration)?;}
        proposed.mode=FramingMode::Crop{track};}
    // Respect the saved upscale/intermediate budget. A detector proposal is
    // optional; if its framing cannot fit that budget, retain the saved track.
    if proposed.validate(source).is_err(){proposed=base.clone();}
    proposed.enabled=true;proposed.disposition=Disposition::NeedsReview;proposed.locked=false;proposed.validate(source)?;
    let mut clipping=0u64;let mut jitter=0.0;let mut jitter_n=0u64;
    for (_,obs,_) in &selected_by_shot{let mut last=None;for o in obs{if let Some(p)=last{jitter+=dist(center(p),center(o.rect));jitter_n+=1;}last=Some(o.rect);let g=proposed.geometry_at(source,o.at)?;if let Some(crop)=choices::actual_crop(&proposed,&g){if !contains(expand(o.rect,settings.face_margin,settings.headroom),crop){clipping+=1;}}}}
    let avoidance=avoidance(project,variant_id,&proposed,&choices::all_observations(project,&original_samples,&settings)?)?;let avoidance_layers=avoidance.len() as u64;let avoidance_layers_with_safe_anchor=avoidance.iter().filter(|a|!a.anchors.is_empty()).count() as u64;
    let safe_punch_in_ranges=choices::safe_punch_ranges(project,&proposed,&selected_by_shot,&original_samples,&settings)?;
    let summaries=tracks.iter().filter(|t|t.obs.len()>=settings.min_track_samples as usize).map(|t|FaceTrackSummary{id:t.id,samples:t.obs.len() as u32,first:t.obs.first().unwrap().at,last:t.obs.last().unwrap().at,mean_confidence:t.obs.iter().map(|o|f64::from(o.confidence)).sum::<f64>()/t.obs.len() as f64,mean_area:t.obs.iter().map(|o|o.rect.width*o.rect.height).sum::<f64>()/t.obs.len() as f64}).collect::<Vec<_>>();
    Ok(FaceFramingReport{model:activation.identity().clone(),settings,variant_id:variant_id.into(),tracks:summaries,proposed,avoidance,safe_punch_in_ranges,
        metrics:FaceMetrics{sampled_frames:sample_count,detected_faces:detected,reliable_tracks:reliable.len() as u32,no_face_samples:no_face,face_clipping_events:clipping,mean_center_jitter:if jitter_n==0{0.0}else{jitter/jitter_n as f64},avoidance_layers,avoidance_layers_with_safe_anchor,manual_corrections:None},activation:activation.clone(),owner:Cancellation::new(),binding:project.decision_digest()?,original_samples,original_settings,original_variant:variant_id.into()})
}

fn associate(tracks:&mut Vec<Track>,detections:&[FaceDetection],at:Rational,s:&FaceSettings,next:&mut u32)->Result<()> {
    let mut used=BTreeSet::new();
    for d in detections{
        let dc=center(d.rect);let mut best:Option<(usize,f64)>=None;
        for (i,t) in tracks.iter().enumerate(){if used.contains(&i)||t.missed>s.max_missed_samples{continue;}let predicted=predicted(t);let pc=center(predicted);let ratio=(area(predicted)/area(d.rect)).max(area(d.rect)/area(predicted));let overlap=iou(predicted,d.rect);let distance=dist(pc,dc);if ratio<=s.max_size_ratio&&(overlap>=s.association_iou||distance<=s.association_center){let cost=distance+(1.0-overlap)*0.25+(ratio-1.0)*0.05;if best.is_none_or(|(_,b)|cost<b){best=Some((i,cost));}}}
        if let Some((i,_))=best{let t=&mut tracks[i];let old=center(t.last);let new=center(d.rect);t.velocity=(new.0-old.0,new.1-old.1);t.last=d.rect;t.missed=0;t.obs.push(Obs{at,rect:d.rect,confidence:d.confidence});used.insert(i);}else{tracks.push(Track{id:*next,obs:vec![Obs{at,rect:d.rect,confidence:d.confidence}],missed:0,last:d.rect,velocity:(0.0,0.0)});*next=next.checked_add(1).ok_or(Error::LimitExceeded("face track identity"))?;used.insert(tracks.len()-1);}
    }
    for (i,t) in tracks.iter_mut().enumerate(){if !used.contains(&i){t.missed=t.missed.saturating_add(1);}}
    Ok(())
}
fn predicted(t:&Track)->DisplayRect{let mut r=t.last;r.x=(r.x+t.velocity.0).clamp(0.0,(1.0-r.width).max(0.0));r.y=(r.y+t.velocity.1).clamp(0.0,(1.0-r.height).max(0.0));r}
pub(crate) fn shot_ranges(project:&Project)->Result<Vec<TimeRange>>{
    let duration=project.sources[0].duration;let mut edges=BTreeSet::from([Rational::new(0,1)?,duration]);
    if let Some(color)=&project.settings.color_correction{for shot in &color.shots{edges.insert(shot.range.start);edges.insert(shot.range.end);}}
    for variant in &project.variants{if let Some(FramingSettings{mode:FramingMode::Crop{track},..})=&variant.framing{for shot in &track.shots{edges.insert(shot.range.start);edges.insert(shot.range.end);}}}
    let edges=edges.into_iter().collect::<Vec<_>>();edges.windows(2).map(|p|TimeRange::new(p[0],p[1])).collect()
}

fn choose_subjects(tracks:&[&Track],shot:TimeRange,s:&FaceSettings)->Result<(Vec<Obs>,usize)>{
    let mut scored:Vec<(&Track,usize,f64)>=tracks.iter().filter_map(|t|{let obs=t.obs.iter().filter(|o|shot.contains(o.at)).cloned().collect::<Vec<_>>();if obs.len()<s.min_track_samples as usize{return None;}let score=obs.len() as f64*(0.5+obs.iter().map(|o|f64::from(o.confidence)).sum::<f64>()/obs.len() as f64)*(0.5+obs.iter().map(|o|o.rect.width*o.rect.height).sum::<f64>()/obs.len() as f64);Some((*t,obs.len(),score))}).collect();
    scored.sort_by(|a,b|b.2.total_cmp(&a.2).then(a.0.id.cmp(&b.0.id)));let Some((primary,_,_))=scored.first().copied() else{return Ok((Vec::new(),0))};
    let mut ids=vec![primary.id];let p=median_rect(primary,shot)?;
    for (other,_,score) in scored.iter().skip(1){if ids.len()>=4||*score<scored[0].2*0.35{continue;}let o=median_rect(other,shot)?;if dist(center(p),center(o))<=s.group_center_distance{ids.push(other.id);}}
    let mut by_time:BTreeMap<Rational,Vec<DisplayRect>>=BTreeMap::new();for t in tracks.iter().filter(|t|ids.contains(&t.id)){for o in t.obs.iter().filter(|o|shot.contains(o.at)){by_time.entry(o.at).or_default().push(o.rect);}}
    let mut out=Vec::new();for (at,rects) in by_time{let rect=union(&rects)?;let confidence=ids.iter().filter_map(|id|tracks.iter().find(|t|t.id==*id)).flat_map(|t|t.obs.iter().filter(move |o|o.at==at)).map(|o|o.confidence).fold(1.0f32,f32::min);out.push(Obs{at,rect,confidence});}Ok((out,ids.len()))
}
fn median_rect(track:&Track,shot:TimeRange)->Result<DisplayRect>{let mut rects=track.obs.iter().filter(|o|shot.contains(o.at)).map(|o|o.rect).collect::<Vec<_>>();if rects.is_empty(){return Err(Error::InvalidInput("empty face track shot"));}rects.sort_by(|a,b|center(*a).0.total_cmp(&center(*b).0));Ok(rects[rects.len()/2])}
fn keys_for_shot(obs:&[Obs],shot:TimeRange,source:SourceGeometry,target:crate::reframe::OutputSize,s:&FaceSettings,motion:MotionLimits)->Result<Vec<CropKeyframe>>{
    if obs.is_empty(){return Ok(Vec::new());}
    let half=shot.duration()?.checked_div(Rational::new(2,1)?)?;
    let midpoint=shot.start.checked_add(half)?;
    let first_half=obs.iter().filter(|o|o.at<midpoint).cloned().collect::<Vec<_>>();
    let second_half=obs.iter().filter(|o|o.at>=midpoint).cloned().collect::<Vec<_>>();
    let p0=pose_for(if first_half.is_empty(){obs}else{&first_half},source,target,s).unwrap_or(CropPose::centered());
    let mut keys=vec![CropKeyframe{at:shot.start,pose:p0}];
    if shot.duration()? >= Rational::new(1,1)? && !second_half.is_empty(){let p1=pose_for(&second_half,source,target,s).unwrap_or(p0);if dist(center_pose(p0),center_pose(p1))>motion.dead_zone|| (p0.zoom-p1.zoom).abs()>0.01{let at=second_half[0].at;if at>shot.start{keys.push(CropKeyframe{at,pose:p1});}}}
    Ok(keys)
}
fn center_pose(p:CropPose)->(f64,f64){(p.center.x,p.center.y)}
fn pose_for(obs:&[Obs],source:SourceGeometry,target:crate::reframe::OutputSize,s:&FaceSettings)->Option<CropPose>{
    if obs.is_empty(){return None;}let desired=expand(union(&obs.iter().map(|o|o.rect).collect::<Vec<_>>()).ok()?,s.face_margin,s.headroom);
    let(bw,bh)=source.base_crop(target).ok()?;let available=(bw/desired.width).min(bh/desired.height).min(s.max_zoom);
    // Reserve eight percent of available headroom for an explicitly reviewed punch-in.
    let zoom=(available/1.08).max(1.0);let w=bw/zoom;let h=bh/zoom;
    let cx=desired.x+desired.width/2.0;let cy=desired.y+desired.height/2.0;
    let mut c=UnitPoint{x:0.5+(cx-0.5)*(1.0-s.smoothing),y:0.5+(cy-0.5)*(1.0-s.smoothing)};
    if desired.width<=w{c.x=c.x.clamp((desired.x+desired.width-w/2.0).max(w/2.0),(desired.x+w/2.0).min(1.0-w/2.0));}
    if desired.height<=h{c.y=c.y.clamp((desired.y+desired.height-h/2.0).max(h/2.0),(desired.y+h/2.0).min(1.0-h/2.0));}
    let pose=CropPose{center:c,zoom};pose.rectangle(source,target).ok()?;Some(pose)
}

fn avoidance(project:&Project,variant_id:&str,framing:&FramingSettings,selected:&[(TimeRange,Vec<Obs>,usize)])->Result<Vec<FaceAvoidanceSuggestion>>{
    choices::avoidance(project,variant_id,framing,selected)
}


fn map_fit_to_output(face:DisplayRect,content:crate::reframe::PixelRect,target:crate::reframe::OutputSize)->Result<crate::reframe::PixelRect>{face.validate()?;target.validate()?;let xf=(f64::from(content.x)+face.x*f64::from(content.width)).floor().clamp(0.0,f64::from(target.width-1));let yf=(f64::from(content.y)+face.y*f64::from(content.height)).floor().clamp(0.0,f64::from(target.height-1));let x=xf as u32;let y=yf as u32;let w=(face.width*f64::from(content.width)).ceil().max(1.0) as u32;let h=(face.height*f64::from(content.height)).ceil().max(1.0) as u32;Ok(crate::reframe::PixelRect{x,y,width:w.min(target.width-x),height:h.min(target.height-y)})}
fn map_to_output(face:DisplayRect,crop:DisplayRect,target:crate::reframe::OutputSize)->Result<crate::reframe::PixelRect>{let xn=((face.x-crop.x)/crop.width).clamp(0.0,1.0);let yn=((face.y-crop.y)/crop.height).clamp(0.0,1.0);let r=((face.x+face.width-crop.x)/crop.width).clamp(0.0,1.0);let b=((face.y+face.height-crop.y)/crop.height).clamp(0.0,1.0);let x=((xn*f64::from(target.width)).floor() as u32).min(target.width-1);let y=((yn*f64::from(target.height)).floor() as u32).min(target.height-1);let w=((r-xn)*f64::from(target.width)).ceil().max(1.0) as u32;let h=((b-yn)*f64::from(target.height)).ceil().max(1.0) as u32;Ok(crate::reframe::PixelRect{x,y,width:w.min(target.width-x),height:h.min(target.height-y)})}
fn union(rects:&[DisplayRect])->Result<DisplayRect>{let first=*rects.first().ok_or(Error::InvalidInput("empty face rectangle set"))?;let(mut x0,mut y0,mut x1,mut y1)=(first.x,first.y,first.x+first.width,first.y+first.height);for r in rects.iter().skip(1){r.validate()?;x0=x0.min(r.x);y0=y0.min(r.y);x1=x1.max(r.x+r.width);y1=y1.max(r.y+r.height);}let r=DisplayRect{x:x0,y:y0,width:x1-x0,height:y1-y0};r.validate()?;Ok(r)}
fn expand(r:DisplayRect,margin:f64,headroom:f64)->DisplayRect{let mx=r.width*margin;let top=r.height*(margin+headroom);let bottom=r.height*margin;let x=(r.x-mx).max(0.0);let y=(r.y-top).max(0.0);let x1=(r.x+r.width+mx).min(1.0);let y1=(r.y+r.height+bottom).min(1.0);DisplayRect{x,y,width:(x1-x).max(0.000001),height:(y1-y).max(0.000001)}}
fn contains(inner:DisplayRect,outer:DisplayRect)->bool{inner.x>=outer.x-1e-8&&inner.y>=outer.y-1e-8&&inner.x+inner.width<=outer.x+outer.width+1e-8&&inner.y+inner.height<=outer.y+outer.height+1e-8}
fn area(r:DisplayRect)->f64{(r.width*r.height).max(1e-12)}
fn center(r:DisplayRect)->(f64,f64){(r.x+r.width/2.0,r.y+r.height/2.0)}
fn dist(a:(f64,f64),b:(f64,f64))->f64{(a.0-b.0).hypot(a.1-b.1)}
fn iou(a:DisplayRect,b:DisplayRect)->f64{let x0=a.x.max(b.x);let y0=a.y.max(b.y);let x1=(a.x+a.width).min(b.x+b.width);let y1=(a.y+a.height).min(b.y+b.height);let inter=(x1-x0).max(0.0)*(y1-y0).max(0.0);inter/(area(a)+area(b)-inter).max(1e-12)}

#[cfg(test)]mod tests{
use super::*;use crate::reframe::OutputSize;
#[test]fn iou_identity(){let r=DisplayRect{x:0.2,y:0.2,width:0.2,height:0.2};assert!((iou(r,r)-1.0).abs()<1e-9);}
#[test]fn separated_boxes_do_not_overlap(){let a=DisplayRect{x:0.0,y:0.0,width:0.1,height:0.1};let b=DisplayRect{x:0.8,y:0.8,width:0.1,height:0.1};assert_eq!(iou(a,b),0.0);}
#[test]fn mapped_obstacle_stays_on_canvas(){let p=map_to_output(DisplayRect{x:0.25,y:0.25,width:0.25,height:0.25},DisplayRect{x:0.0,y:0.0,width:1.0,height:1.0},OutputSize::new(1080,1920).unwrap()).unwrap();assert!(p.x+p.width<=1080&&p.y+p.height<=1920);}
}

#[cfg(test)]mod project_tests{
use super::*;use crate::{host::{FileStamp,InputFile},media::{parse_probe,StreamSelection},model_pack::{ModelRuntime,YUNET_PROCESSING},plan::{RenderOptions},project::{FrozenRenderSettings,ProjectSource,ResolvedSettings},reframe::{FramingSettings,OutputSize}};use std::path::PathBuf;
fn r(s:&str)->Rational{s.parse().unwrap()}
fn loc()->PathBuf{std::env::temp_dir().join("face-unit").join("project.amxv")}
fn project()->Project{let m=parse_probe(include_bytes!("../tests/fixtures/probe-base.json")).unwrap();let f=InputFile{canonical_path:loc().parent().unwrap().join("input.mp4"),stamp:FileStamp{size:100,modified_ns:None,sha256:"a".repeat(64),file_id:None}};let source=ProjectSource::from_probe("source-1",&f,&m,m.select(StreamSelection::default()).unwrap(),&loc()).unwrap();let mut p=Project::new("face-unit",source,ResolvedSettings{workflow:None,voice_cleanup:None,voice_enhancement:None,color_correction:None,pause_cleanup:None,preset_name:None,preset_revision:None,render:FrozenRenderSettings::from_options(&RenderOptions::default()).unwrap()}).unwrap();p.set_variant_framing("main",Some(FramingSettings::center_crop(OutputSize::new(90,160).unwrap(),p.sources[0].duration).unwrap())).unwrap();p}
fn activation()->ModelActivation{ModelActivation::selected(ModelIdentity{id:"yunet-fixture".into(),revision:"1".into(),source_revision:"test".into(),manifest_sha256:"a".repeat(64),weights_sha256:"b".repeat(64),contract:YUNET_CONTRACT.into(),preprocessing:YUNET_PROCESSING.into(),runtime:ModelRuntime{adapter:"fake".into(),build_info_sha256:"c".repeat(64),artifact_sha256:"d".repeat(64)},notices_sha256:"e".repeat(64)}).unwrap()}
fn d(x:f64)->FaceDetection{FaceDetection{rect:DisplayRect{x,y:0.25,width:0.16,height:0.22},confidence:0.95}}
#[test]fn no_face_fallback_is_pending_center_crop(){let p=project();let a=activation();let report=build_report(&p,"main",vec![FaceSample{at:r("0"),detections:vec![]}],FaceSettings{min_track_samples:2,..Default::default()},&a).unwrap();assert_eq!(report.proposed.disposition,Disposition::NeedsReview);assert_eq!(report.metrics.no_face_samples,1);}
#[test]fn partial_single_face_coverage_does_not_certify_a_whole_shot(){let p=project();let a=activation();let samples=vec![FaceSample{at:r("0"),detections:vec![d(0.22)]},FaceSample{at:r("1/4"),detections:vec![d(0.23)]},FaceSample{at:r("1/2"),detections:vec![d(0.24)]}];let report=build_report(&p,"main",samples,FaceSettings{min_track_samples:2,..Default::default()},&a).unwrap();assert_eq!(report.tracks.len(),1);assert!(report.safe_punch_in_ranges.is_empty()); // A partial first-second observation cannot certify the full source.
}
#[test]fn fit_variant_with_missing_face_scene_stays_fit(){let mut p=project();p.set_variant_framing("main",Some(FramingSettings::fit(OutputSize::new(90,160).unwrap()).unwrap())).unwrap();let a=activation();let report=build_report(&p,"main",vec![FaceSample{at:r("0"),detections:vec![]}],FaceSettings{min_track_samples:2,..Default::default()},&a).unwrap();assert!(matches!(report.proposed.mode,FramingMode::Fit{..}));}
#[test]fn revoked_activation_cannot_apply(){let mut p=project();let a=activation();let report=build_report(&p,"main",vec![FaceSample{at:r("0"),detections:vec![]}],FaceSettings{min_track_samples:2,..Default::default()},&a).unwrap();a.revoke();assert!(matches!(report.apply(&mut p,&a),Err(Error::Cancelled)));}
#[test]fn speech_contract_cannot_drive_face_pipeline(){let p=project();let mut id=activation().identity().clone();id.contract=crate::model_pack::SILERO_CONTRACT.into();id.preprocessing=crate::model_pack::SPEECH_PROCESSING.into();let a=ModelActivation::selected(id).unwrap();assert!(build_report(&p,"main",vec![FaceSample{at:r("0"),detections:vec![]}],FaceSettings::default(),&a).is_err());}

fn stable_samples(p:&Project)->Vec<FaceSample>{let mut out=vec![];let mut at=r("0");while at<p.sources[0].duration{out.push(FaceSample{at,detections:vec![FaceDetection{rect:DisplayRect{x:0.45,y:0.35,width:0.06,height:0.10},confidence:0.98}]});at=at.checked_add(r("1/4")).unwrap();}out}
fn report(p:&Project,a:&ModelActivation)->FaceFramingReport{build_report(p,"main",stable_samples(p),FaceSettings::default(),a).unwrap()}
fn add_overlay(p:&mut Project,id:&str){use crate::presentation::*;p.set_presentation("main",Some(PresentationSettings{safe_zone:crate::reframe::SafeZone::none(),overlays:vec![Overlay{id:id.into(),range:TimeRange::new(r("0"),p.sources[0].duration).unwrap(),content:GraphicContent::Svg{asset:AssetRef{path:"logo.svg".into(),size:10,sha256:"a".repeat(64)}},placement:Placement{anchor:Anchor::BottomRight,width:16,height:16,margin:0},animation:Animation::default(),enabled:true}],..Default::default()})).unwrap();}
#[test]fn report_is_bound_to_project_revision_and_content(){let mut p=project();let a=activation();let out=report(&p,&a);p.id="different-project".into();assert!(matches!(out.apply(&mut p,&a),Err(Error::InputChanged)));}
#[test]fn report_cannot_be_reapplied_after_adoption(){let mut p=project();let a=activation();let out=report(&p,&a);out.apply(&mut p,&a).unwrap();assert!(matches!(out.apply(&mut p,&a),Err(Error::InputChanged)));}
#[test]fn mutable_diagnostics_cannot_approve_or_replace_framing(){let mut p=project();let a=activation();let mut out=report(&p,&a);let expected=out.proposed.target;out.proposed.target=OutputSize::new(80,80).unwrap();out.proposed.disposition=Disposition::AutoApply;out.variant_id="missing".into();out.model.weights_sha256="f".repeat(64);out.apply(&mut p,&a).unwrap();let f=p.variant("main").unwrap().framing.as_ref().unwrap();assert_eq!(f.target,expected);assert_eq!(f.disposition,Disposition::NeedsReview);}
#[test]fn report_owner_cancellation_blocks_adoption(){let mut p=project();let a=activation();let mut out=report(&p,&a);let owner=Cancellation::new();out.bind_owner(&owner);owner.cancel();assert!(matches!(out.apply(&mut p,&a),Err(Error::Cancelled)));}
#[test]fn face_keys_use_actual_source_clock(){let p=project();let a=activation();let out=report(&p,&a);let FramingMode::Crop{track}=out.proposed.mode else{panic!()};for s in track.shots{for key in s.keyframes{assert_eq!(key.at.checked_div(p.sources[0].media.video.time_base.unwrap()).unwrap().denominator(),1);}}}
#[test]fn off_clock_input_observation_is_rejected(){let p=project();let a=activation();assert!(build_report(&p,"main",vec![FaceSample{at:r("1/7"),detections:vec![]}],FaceSettings::default(),&a).is_err());}
#[test]fn known_scene_cut_resets_association(){let mut p=project();let a=activation();let duration=p.sources[0].duration;let FramingMode::Crop{track}=&mut p.variants[0].framing.as_mut().unwrap().mode else{panic!()};track.shots=vec![CropShot{range:TimeRange::new(r("0"),r("1")).unwrap(),keyframes:vec![CropKeyframe{at:r("0"),pose:CropPose::centered()}]},CropShot{range:TimeRange::new(r("1"),duration).unwrap(),keyframes:vec![CropKeyframe{at:r("1"),pose:CropPose::centered()}]}];let out=report(&p,&a);assert_eq!(out.tracks.len(),2);}
#[test]fn saved_motion_limits_and_safe_zone_are_preserved(){let mut p=project();let a=activation();let framing=p.variants[0].framing.as_mut().unwrap();framing.safe_zone=crate::reframe::SafeZone{left:100,right:100,top:200,bottom:300};let FramingMode::Crop{track}=&mut framing.mode else{panic!()};track.motion.dead_zone=0.04;track.motion.max_center_speed=0.1;let motion=track.motion;let safe=framing.safe_zone;let out=report(&p,&a);let FramingMode::Crop{track}=out.proposed.mode else{panic!()};assert_eq!(track.motion,motion);assert_eq!(out.proposed.safe_zone,safe);}
#[test]fn no_face_keeps_saved_motion_keys(){let mut p=project();let a=activation();let framing=p.variants[0].framing.as_mut().unwrap();let FramingMode::Crop{track}=&mut framing.mode else{panic!()};track.shots[0].keyframes.push(CropKeyframe{at:r("1"),pose:CropPose{center:UnitPoint{x:0.55,y:0.5},zoom:1.0}});let old=track.clone();let out=build_report(&p,"main",vec![FaceSample{at:r("0"),detections:vec![]}],FaceSettings::default(),&a).unwrap();let FramingMode::Crop{track}=out.proposed.mode else{panic!()};assert_eq!(track,old);}
#[test]fn full_coverage_can_propose_a_safe_punch_in(){let p=project();let a=activation();let out=report(&p,&a);assert!(!out.safe_punch_in_ranges.is_empty());}
#[test]fn missing_middle_faces_disable_safe_punch_in(){let p=project();let a=activation();let mut samples=stable_samples(&p);samples[3].detections.clear();let out=build_report(&p,"main",samples,FaceSettings::default(),&a).unwrap();assert!(out.safe_punch_in_ranges.is_empty());}
#[test]fn explicit_punch_and_framing_apply_in_one_pending_revision(){let mut p=project();let a=activation();let out=report(&p,&a);let range=out.safe_punch_in_ranges[0];let revision=p.revision;out.apply_choices(&mut p,&a,&FaceApplyChoices{punch_ins:vec![FacePunchInChoice{range,zoom:1.04}],..Default::default()}).unwrap();assert_eq!(p.revision,revision+1);assert_eq!(p.variants[0].framing.as_ref().unwrap().disposition,Disposition::NeedsReview);}
#[test]fn invented_punch_interval_is_rejected(){let mut p=project();let a=activation();let out=report(&p,&a);let old=p.to_json().unwrap();assert!(out.apply_choices(&mut p,&a,&FaceApplyChoices{punch_ins:vec![FacePunchInChoice{range:TimeRange::new(r("0"),r("1")).unwrap(),zoom:1.04}],..Default::default()}).is_err());assert_eq!(old,p.to_json().unwrap());}
#[test]fn explicit_anchor_is_pending_and_atomic_with_framing(){let mut p=project();add_overlay(&mut p,"logo");let a=activation();let out=report(&p,&a);let suggestion=out.avoidance.iter().find(|s|!s.anchors.is_empty()).unwrap();let revision=p.revision;out.apply_choices(&mut p,&a,&FaceApplyChoices{anchors:vec![FaceAnchorChoice{target:suggestion.target.clone(),anchor:suggestion.anchors[0]}],..Default::default()}).unwrap();assert_eq!(p.revision,revision+1);assert_eq!(p.variants[0].presentation.as_ref().unwrap().disposition,Disposition::NeedsReview);}
#[test]fn public_avoidance_tampering_does_not_authorize_center_overlay(){let mut p=project();add_overlay(&mut p,"logo");let a=activation();let mut out=report(&p,&a);for s in &mut out.avoidance{s.anchors=Anchor::all().to_vec();}assert!(out.apply_choices(&mut p,&a,&FaceApplyChoices{anchors:vec![FaceAnchorChoice{target:FaceAnchorTarget::Overlay("logo".into()),anchor:Anchor::Center}],..Default::default()}).is_err());}
#[test]fn overlay_named_captions_has_an_unambiguous_target(){let mut p=project();add_overlay(&mut p,"captions");let a=activation();let out=report(&p,&a);assert!(out.avoidance.iter().all(|s|s.target==FaceAnchorTarget::Overlay("captions".into())));}
#[test]fn locked_presentation_cannot_be_changed_by_face_choices(){let mut p=project();add_overlay(&mut p,"logo");p.set_presentation_locked("main",true).unwrap();let a=activation();let out=report(&p,&a);let suggestion=out.avoidance.iter().find(|s|!s.anchors.is_empty()).unwrap();assert!(matches!(out.apply_choices(&mut p,&a,&FaceApplyChoices{anchors:vec![FaceAnchorChoice{target:suggestion.target.clone(),anchor:suggestion.anchors[0]}],..Default::default()}),Err(Error::LockedEdit)));}
}
