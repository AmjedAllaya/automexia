//! Optional single-slot control-plane bridge for the host's existing UI loop.
//! Only replaceable Progress travels here. Success/approval/publication receipts
//! are returned by the operation and MUST NOT be coalesced into this mailbox.
use crate::{Cancellation,Error,Result};
use crate::progress::Progress;
use std::sync::{Arc,Mutex};
struct Slot { latest:Option<Progress>, closed:bool, replaced:u64 }
#[derive(Clone)]
pub struct ProgressSender {slot:Arc<Mutex<Slot>>,cancel:Cancellation}
pub struct ProgressReceiver {slot:Arc<Mutex<Slot>>,cancel:Cancellation}
/// A fresh pair per current host request; old senders cannot reach a new pair.
/// No queue growth, worker, timer, filesystem or implicit callback registration.
pub fn progress_mailbox(cancel:Cancellation)->Result<(ProgressSender,ProgressReceiver)>{
    cancel.check()?;
    let slot=Arc::new(Mutex::new(Slot{latest:None,closed:false,replaced:0}));
    Ok((ProgressSender{slot:slot.clone(),cancel:cancel.clone()},ProgressReceiver{slot,cancel}))
}
impl ProgressSender {
    pub fn publish(&self,event:Progress)->Result<()> {
        let mut slot=self.slot.lock().map_err(|_|Error::Poisoned)?;
        if self.cancel.is_cancelled()||slot.closed{slot.latest=None;return Err(Error::Cancelled);}
        if slot.latest.is_some(){slot.replaced=slot.replaced.saturating_add(1);}
        slot.latest=Some(event);Ok(())
    }
}
impl ProgressReceiver {
    pub fn take(&self)->Result<Option<Progress>>{
        let mut slot=self.slot.lock().map_err(|_|Error::Poisoned)?;
        if self.cancel.is_cancelled()||slot.closed{slot.latest=None;return Err(Error::Cancelled);}
        Ok(slot.latest.take())
    }
    pub fn replaced_updates(&self)->Result<u64>{Ok(self.slot.lock().map_err(|_|Error::Poisoned)?.replaced)}
    pub fn close(&self){let mut slot=self.slot.lock().unwrap_or_else(|e|e.into_inner());slot.closed=true;slot.latest=None;}
}
impl Drop for ProgressReceiver {fn drop(&mut self){self.close();}}
#[cfg(test)]
mod tests {
    use super::*;use crate::progress::Stage;
    #[test]fn slot_coalesces_without_growth(){let(s,r)=progress_mailbox(Cancellation::new()).unwrap();for i in 0..10000{let mut p=Progress::stage(Stage::Rendering);p.frame=Some(i);s.publish(p).unwrap();}assert_eq!(r.take().unwrap().unwrap().frame,Some(9999));assert_eq!(r.replaced_updates().unwrap(),9999);assert!(r.take().unwrap().is_none());}
    #[test]fn cancel_bypasses_progress_slot(){let c=Cancellation::new();let(s,r)=progress_mailbox(c.clone()).unwrap();s.publish(Progress::stage(Stage::Rendering)).unwrap();c.cancel();assert!(matches!(r.take(),Err(Error::Cancelled)));assert!(s.publish(Progress::stage(Stage::Publishing)).is_err());}
    #[test]fn dropping_receiver_invalidates_all_senders(){let(s,r)=progress_mailbox(Cancellation::new()).unwrap();let other=s.clone();drop(r);assert!(s.publish(Progress::stage(Stage::Probing)).is_err());assert!(other.publish(Progress::stage(Stage::Probing)).is_err());}
    #[test]fn old_sender_cannot_publish_to_new_request(){let(s,r)=progress_mailbox(Cancellation::new()).unwrap();drop(r);let(n,r)=progress_mailbox(Cancellation::new()).unwrap();assert!(s.publish(Progress::stage(Stage::Publishing)).is_err());n.publish(Progress::stage(Stage::Probing)).unwrap();assert_eq!(r.take().unwrap().unwrap().stage,Stage::Probing);}
    #[test]fn encoding_end_is_not_publication(){let(s,r)=progress_mailbox(Cancellation::new()).unwrap();let mut p=Progress::stage(Stage::Rendering);p.encoding_finished=true;s.publish(p).unwrap();assert_eq!(r.take().unwrap().unwrap().stage,Stage::Rendering);}
}
