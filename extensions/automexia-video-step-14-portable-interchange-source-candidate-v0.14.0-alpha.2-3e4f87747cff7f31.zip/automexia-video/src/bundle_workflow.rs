//! Explicit portable interchange handoff on the existing admitted Video job.
//! A lease owns all private bakes and one final create-new archive transaction.
use crate::{BundlePlan,BundleRequest,Cancellation,CompatibilityReport,Error,ExportStatus,InputFile,InterchangeHost,OutputPolicy,Project,Result,VideoExtension};
use crate::host::ProgressSink;
use crate::extension::emit;
use crate::progress::Stage;
use serde::Serialize;
use std::path::{Path,PathBuf};

pub trait BundleHost:InterchangeHost {
    /// Authorize only this selected archive and its private workspace. The
    /// workspace must contain an existing canonical Media directory for bakes.
    /// Dropping an unpublished lease removes only its own staged files.
    fn stage_bundle(&self,source:&InputFile,protected:&[PathBuf],destination:&Path,max_total_bytes:u64,cancel:&Cancellation)->Result<Box<dyn BundleLease>>;
}
pub trait BundleLease:Send {
    fn workspace(&self)->&Path;
    /// Revalidate every selected media identity, copy and hash bounded bytes,
    /// then publish the complete archive without replacing any existing path.
    /// Return success after commit even if later cleanup/durability work fails.
    fn publish(self:Box<Self>,plan:&BundlePlan,cancel:&Cancellation,progress:&mut ProgressSink<'_>)->Result<BundlePublication>;
}
#[derive(Debug,Clone,Serialize)]
pub struct BundlePublication {pub path:PathBuf,pub sha256:String,pub size:u64}
#[derive(Debug,Clone,Serialize)]
pub struct BundleOutcome {
    pub status:ExportStatus,pub destination:Option<PathBuf>,pub sha256:Option<String>,pub size:Option<u64>,
    pub compatibility:CompatibilityReport,pub request:BundleRequest,pub error:Option<String>,
}
impl BundleOutcome {
    pub fn exit_code(&self)->i32{if self.status==ExportStatus::Published{0}else{2}}
    pub fn to_json(&self)->Result<Vec<u8>>{crate::interchange::bounded_json(self)}
}
/// Pure assessment: the synthetic workspace is a path binding, never created.
/// No source is opened and no bake is performed by this operation.
pub fn assess_bundle(project:&Project,request:&BundleRequest)->Result<CompatibilityReport>{
    request.validate()?;
    let logical_workspace=request.destination.with_extension("bundle-workspace");
    let export=request.to_export_request(&logical_workspace)?;
    let mut report=crate::interchange::assess_export(project,&export)?;
    if request.video==crate::BundleVideo::Source&&project.sources.first().is_some_and(|s|s.fingerprint.size>=request.max_total_bytes){
        report.items.push(crate::interchange::CompatibilityItem{id:"bundle-byte-budget".into(),representation:crate::Representation::Unsupported,detail:"The complete referenced source file already fills the archive byte budget; increase the explicit budget or choose a smaller source.".into(),blocking:true});
    }
    report.warnings.push("The requested ZIP64 handoff copies the complete referenced media files and a portable interchange document. It does not package every asset needed to reopen the original .amxv project. Explicit bakes are private until the complete archive is published.".into());
    Ok(report)
}
impl<H:BundleHost> VideoExtension<H> {
    pub fn export_bundle(&self,project:&Project,request:&BundleRequest,cancel:&Cancellation,progress:&mut ProgressSink<'_>)->Result<BundleOutcome>{
        cancel.check()?;
        let report=assess_bundle(project,request)?;
        let mut out=BundleOutcome{status:ExportStatus::Blocked,destination:None,sha256:None,size:None,compatibility:report,request:request.clone(),error:None};
        if out.compatibility.blocked(){return Ok(out);}
        let job=self.begin(cancel)?;
        let result=(||->Result<BundlePublication>{
            crate::presentation::guard_destination(project,&request.project_file,&request.destination,&OutputPolicy::CreateNew)?;
            let mut protected=vec![request.project_file.clone()];
            for source in &project.sources {protected.push(source.resolve(&request.project_file)?);}
            for variant in &project.variants {if let Some(p)=&variant.presentation {for asset in p.all_asset_refs(){protected.push(asset.resolve(&request.project_file)?);}}}
            if let Some(enhancement)=&project.settings.voice_enhancement {protected.push(enhancement.resolve(&request.project_file)?);}
            if protected.contains(&request.destination){return Err(Error::SameFile);}
            emit(progress,Stage::Inspecting)?;
            let source=&project.sources[0];
            let input=self.host().inspect_input(&source.resolve(&request.project_file)?,&job.cancel)?;
            source.check_input(&input)?;
            let lease=self.host().stage_bundle(&input,&protected,&request.destination,request.max_total_bytes,&job.cancel)?;
            crate::interchange::paths::local_path(lease.workspace())?;
            let export=request.to_export_request(lease.workspace())?;
            // This helper stays in the current job. Bakes remain beneath the
            // lease, and a later error drops the lease instead of exposing them.
            let mut private_media=Vec::new();
            let prepared=self.prepare_interchange_job(project,&export,&job.cancel,progress,&mut private_media)?;
            let plan=BundlePlan::from_document(&prepared.document,request)?;
            out.compatibility=plan.document().report().clone();
            self.host().revalidate_input(&input,&job.cancel)?;
            job.cancel.check()?;emit(progress,Stage::Publishing)?;
            lease.publish(&plan,&job.cancel,progress)
        })();
        match result {
            Ok(published)=>{
                out.status=ExportStatus::PublishedUnverified;
                out.destination=Some(published.path.clone());out.sha256=Some(published.sha256.clone());out.size=Some(published.size);
                // Never turn a post-commit cancellation/readback failure into
                // an ordinary failure that could encourage a blind retry.
                match self.host().inspect_input(&request.destination,&job.cancel){
                    Ok(file) if (published.path==request.destination||published.path==file.canonical_path)&&file.stamp.sha256==published.sha256&&file.stamp.size==published.size=>out.status=ExportStatus::Published,
                    _=>out.error=Some("Bundle published; post-publication identity could not be verified. Inspect it before retrying.".into()),
                }
            },
            Err(error)=>{
                out.status=if matches!(error,Error::Unsupported(_)|Error::MissingCapability(_)|Error::UnresolvedEdits|Error::EmptyTimeline){ExportStatus::Blocked}else{ExportStatus::Failed};
                out.compatibility.items.push(crate::interchange::CompatibilityItem{id:"bundle-publication".into(),representation:crate::Representation::Unsupported,detail:error.to_string(),blocking:true});
                out.error=Some(error.to_string());
            },
        }
        Ok(out)
    }
}
