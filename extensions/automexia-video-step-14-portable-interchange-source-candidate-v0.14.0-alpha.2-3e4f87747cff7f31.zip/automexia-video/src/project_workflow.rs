//! Step-2 entry methods. These run on the same host-owned blocking job executor
//! as probing/rendering. There is no independent scheduler or detector pass.
use crate::{Cancellation,Error,Result,VideoExtension};
use crate::extension::emit;
use crate::host::{MediaHost,MediaTask,OutputPolicy,ProgressSink};
use crate::plan::{build_edited_plan,validate_output,RenderOptions,RenderResult};
use crate::progress::Stage;
use crate::project::{Project,ProjectSource,ResolvedSettings,FrozenRenderSettings,Timeline,RenderHistory};
use crate::project_store::{ProjectStore,LoadedProject,SavedProject};
use serde::Serialize;
use std::path::{Path,PathBuf};

#[derive(Debug,Clone)]
pub struct NewProjectRequest {
    pub id:String,pub input:PathBuf,pub project_file:PathBuf,pub options:RenderOptions,
    pub preset_name:Option<String>,pub preset_revision:Option<String>,
}
impl NewProjectRequest {
    pub fn new(id:impl Into<String>,input:impl Into<PathBuf>,project_file:impl Into<PathBuf>)->Self{
        Self{id:id.into(),input:input.into(),project_file:project_file.into(),options:RenderOptions::default(),preset_name:None,preset_revision:None}
    }
}
#[derive(Debug,Clone)]
pub struct ProjectRenderRequest {
    pub project_file:PathBuf,pub variant:String,pub output:PathBuf,pub output_policy:OutputPolicy,
}
impl ProjectRenderRequest {
    pub fn new(project_file:impl Into<PathBuf>,output:impl Into<PathBuf>)->Self {
        Self{project_file:project_file.into(),variant:"main".into(),output:output.into(),output_policy:OutputPolicy::CreateNew}
    }
}
#[derive(Debug,Clone,Serialize)]
pub struct ProjectRenderResult {pub media:RenderResult,pub timeline:Timeline,pub project_revision:u64,pub decision_sha256:String,pub variant:String,pub audio:Option<crate::voice_render::AudioRenderReport>,pub presentation_assets:Vec<crate::presentation_render::AssetReceipt>}
impl ProjectRenderResult {
    pub fn history(&self)->RenderHistory {
        RenderHistory{delivery_profile:self.media.delivery_profile.clone(),project_revision:self.project_revision,decision_sha256:self.decision_sha256.clone(),variant_id:self.variant.clone(),runtime:self.media.runtime.clone(),output:self.media.output.clone(),fully_decoded:self.media.full_decode_validated}
    }
}
#[derive(Debug,Clone,Serialize)]
pub struct DryRunResult {
    pub project_revision:u64,pub decision_sha256:String,pub timeline:Option<Timeline>,
    pub pending_or_empty:Option<String>,pub project_written:Option<PathBuf>,
    pub cache_written:bool,pub final_media_written:bool,
}
impl<H:MediaHost> VideoExtension<H> {
    /// Probe once and capture explicit stream selection + effective render
    /// settings. Does not render or save. Relative media references are generated
    /// only when the selected source is under the requested project directory.
    pub fn create_project(&self,request:&NewProjectRequest,cancel:&Cancellation,progress:&mut ProgressSink<'_>)->Result<Project>{
        request.options.validate()?;project_location(&request.project_file)?;
        crate::project::id_ok(&request.id)?;
        if let Some(s)=&request.preset_name{crate::project::text_ok(s,128)?;}
        if let Some(s)=&request.preset_revision{crate::project::text_ok(s,128)?;}
        let probed=self.probe(&request.input,cancel,progress)?;
        let selected=probed.media.select(request.options.streams)?;
        let source=ProjectSource::from_probe("source-1",&probed.input,&probed.media,selected,&request.project_file)?;
        Project::new(&request.id,source,ResolvedSettings{ workflow:None,voice_cleanup:None,voice_enhancement:None,color_correction:None,pause_cleanup:None,preset_name:request.preset_name.clone(),preset_revision:request.preset_revision.clone(),render:FrozenRenderSettings::from_options(&request.options)?})
    }
    /// No file/process activity. Pending drafts remain inspectable but can't be
    /// mistaken for a rendered result. No detector, preset lookup or cache write.
    pub fn dry_run(&self,project:&Project)->Result<DryRunResult>{
        let variant=project.variants.first().ok_or(Error::InvalidProject("missing output variant"))?;
        self.dry_run_variant(project,&variant.id)
    }
    /// Readiness belongs to the selected output variant. Unresolved decisions in
    /// another variant do not prevent a resolved variant from being delivered.
    pub fn dry_run_variant(&self,project:&Project,variant_id:&str)->Result<DryRunResult>{
        let _job=self.begin(&Cancellation::new())?;
        project.validate()?;let variant=project.variant(variant_id)?;
        let (timeline,mut pending_or_empty)=match project.timeline_for_variant(variant_id){
            Ok(t)=>(Some(t),None),Err(Error::UnresolvedEdits)=>(None,Some("pending edit, assembly or timing decisions".into())),
            Err(Error::EmptyTimeline)=>(None,Some("empty edit timeline".into())),
            Err(Error::Unsupported(reason))|Err(Error::LimitExceeded(reason))=>(None,Some(reason.into())),Err(e)=>return Err(e),
        };
        if project.settings.color_correction.as_ref().is_some_and(|p|p.ensure_resolved().is_err()) {
            pending_or_empty=Some("pending color decisions".into());
        }
        if pending_or_empty.is_none()&&variant.framing.as_ref().is_some_and(|f|f.ensure_resolved().is_err()){
            pending_or_empty=Some("pending selected-variant framing decisions".into());
        }
        if pending_or_empty.is_none()&&variant.presentation.as_ref().is_some_and(|p|p.ensure_resolved().is_err()){
            pending_or_empty=Some("pending selected-variant presentation decisions".into());
        }
        Ok(DryRunResult{project_revision:project.revision,decision_sha256:project.decision_digest()?,timeline,pending_or_empty,project_written:None,cache_written:false,final_media_written:false})
    }
    pub(crate) fn verify_plan_timing(&self,plan:&crate::RenderPlan,input:&crate::InputFile,current:&crate::MediaInfo,cancel:&Cancellation,progress:&mut ProgressSink<'_>)->Result<()> {
        if let Some(edit)=plan.edited_timeline().filter(|edit|edit.changes_timing()) {
            emit(progress,Stage::VerifyingTimeline)?;
            let stream=plan.selected().video;
            let video=current.stream(stream)?;
            let rate=crate::interchange::EditRate::new(edit.nominal_frame_rate,false)?;
            let evidence=self.host().verify_timing(input,current,stream,rate,cancel)?;
            evidence.validate_for(input,stream,rate,video.exact_start().or(current.start_time).ok_or(Error::InvalidProbe("timing source origin"))?,video.exact_duration().ok_or(Error::InvalidProbe("timing source duration"))?)?;
        }
        cancel.check()
    }
    /// Re-probe only to validate source compatibility. No edit generator or global
    /// preset is consulted: output is derived exclusively from saved decisions.
    pub fn render_project(&self,project:&Project,request:&ProjectRenderRequest,cancel:&Cancellation,progress:&mut ProgressSink<'_>)->Result<ProjectRenderResult>{
        let job=self.begin(cancel)?;
        self.render_project_job(project,request,&job.cancel,progress)
    }
    pub(crate) fn render_project_job(&self,project:&Project,request:&ProjectRenderRequest,cancel:&Cancellation,progress:&mut ProgressSink<'_>)->Result<ProjectRenderResult>{
        project_location(&request.project_file)?;project.validate()?;
        let variant=project.variant(&request.variant)?;
        if let Some(f)=&variant.framing{f.ensure_resolved()?;}
        if let Some(p)=&variant.presentation{p.ensure_resolved()?;}
        let timeline=project.timeline_for_variant(&request.variant)?;
        if let Some(profile)=&project.variant(&request.variant)?.output_profile {profile.validate_destination(&request.output)?;}
        else if !request.output.extension().and_then(|s|s.to_str()).is_some_and(|s|s.eq_ignore_ascii_case("mp4")){return Err(Error::InvalidInput("legacy output profile requires an .mp4 destination"));}
        crate::presentation::guard_destination(project,&request.project_file,&request.output,&request.output_policy)?;
        let decision_sha256=project.decision_digest()?;
        let source=&project.sources[0];let source_path=source.resolve(&request.project_file)?;
        emit(progress,Stage::Inspecting)?;
        let input=self.host().inspect_input(&source_path,cancel)?;source.check_input(&input)?;
        emit(progress,Stage::RuntimeCheck)?;let runtime=self.host().runtime_capabilities(cancel)?;
        let current=self.probe_path(&input.canonical_path,cancel,progress)?;
        let mut plan=build_edited_plan(project,&request.variant,&current,&runtime)?;
        self.verify_plan_timing(&plan,&input,&current,cancel,progress)?;
        let enhanced_input=if let Some(enhancement)=&project.settings.voice_enhancement {
            enhancement.validate()?;let path=enhancement.resolve(&request.project_file)?;
            if path==request.output{return Err(Error::SameFile);}
            let stem=self.host().inspect_input(&path,cancel)?;enhancement.check_input(&stem)?;
            let probe=self.host().run_audio(&crate::voice_render::AudioTask::ProbeStem{input:stem.clone()},cancel,&mut |_|{})?;
            let stem_media=crate::media::parse_probe(&probe.stdout)?;crate::enhancement::validate_enhanced_media(&stem_media,&enhancement.receipt,source.duration)?;
            self.host().run_audio(&crate::voice_render::AudioTask::ValidateStem{input:stem.clone(),timeout:std::time::Duration::from_secs(7200)},cancel,&mut |_|{})?;
            plan.attach_enhanced_audio(&stem.canonical_path)?;Some(stem)
        }else{None};

        let presentation_lease=match plan.presentation(){Some(p) if p.has_pixels()=>{emit(progress,Stage::PreparingGraphics)?;Some(self.host().prepare_presentation(p,&request.project_file,cancel)?)},_=>None};
        if let Some(lease)=&presentation_lease{lease.revalidate(Some(&request.output),cancel)?;plan.attach_presentation(&**lease)?;}
        self.prepare_voice(&mut plan,&input,std::time::Duration::from_secs(7200),cancel,progress)?;
        // Bounds, compatibility and unresolved edits are checked before creating output.
        plan.arguments(&input.canonical_path,&request.output)?;
        cancel.check()?;let staged=self.host().stage_output(&input,&request.output,&request.output_policy,cancel)?;
        let (output,audio)=loop {
        plan.arguments(&input.canonical_path,staged.path())?;
        self.host().revalidate_input(&input,cancel)?;if let Some(stem)=&enhanced_input{self.host().revalidate_input(stem,cancel)?;}emit(progress,Stage::Rendering)?;
        self.host().run(&MediaTask::Render{input:input.canonical_path.clone(),staged_output:staged.path().to_owned(),plan:plan.clone()},cancel,progress)?;
        cancel.check()?;emit(progress,Stage::Validating)?;
        let output=self.probe_path(staged.path(),cancel,progress)?;validate_output(&current,&output,&plan)?;
        self.host().run(&MediaTask::ValidateDecode{input:staged.path().to_owned(),has_audio:plan.selected().audio.is_some()},cancel,progress)?;
        match self.check_voice_output(&mut plan,staged.path(),&output,std::time::Duration::from_secs(7200),cancel,progress)? {
            crate::voice_workflow::AudioValidation::Retry=>continue,
            crate::voice_workflow::AudioValidation::Ready(audio)=>break (output,audio),
        }
        };
        self.host().revalidate_input(&input,cancel)?;if let Some(stem)=&enhanced_input{self.host().revalidate_input(stem,cancel)?;}cancel.check()?;emit(progress,Stage::Publishing)?;
        if let Some(lease)=&presentation_lease{lease.revalidate(Some(&request.output),cancel)?;}
        let destination=staged.publish(cancel)?;
        let media=RenderResult{delivery_profile:plan.output_profile().cloned(),output:destination,input,selected:plan.selected(),runtime,output_media:output,warnings:plan.warnings,full_decode_validated:true};
        Ok(ProjectRenderResult{media,timeline,project_revision:project.revision,decision_sha256,variant:request.variant.clone(),audio,presentation_assets:presentation_lease.as_ref().map(|l|l.receipts().to_vec()).unwrap_or_default()})
    }
}
impl<H:MediaHost+ProjectStore> VideoExtension<H> {
    pub fn load_project(&self,path:&Path,cancel:&Cancellation)->Result<LoadedProject>{
        project_location(path)?;let job=self.begin(cancel)?;self.host().load_project(path,&job.cancel)
    }
    pub fn save_project(&self,project:&Project,path:&Path,policy:&OutputPolicy,cancel:&Cancellation)->Result<SavedProject>{
        project_location(path)?;project.validate()?;let job=self.begin(cancel)?;self.host().save_project(project,path,policy,&job.cancel)
    }
    /// Implements the core behind `--no-render`: save decisions, never media.
    /// For a new input, call create_project first, then pass the returned project.
    pub fn no_render(&self,project:&Project,path:&Path,policy:&OutputPolicy,cancel:&Cancellation)->Result<DryRunResult>{
        let mut result=self.dry_run(project)?;
        result.project_written=Some(self.save_project(project,path,policy,cancel)?.path);Ok(result)
    }
    /// A dry run can opt into project saving, but reports the write explicitly.
    pub fn dry_run_and_save(&self,project:&Project,path:&Path,policy:&OutputPolicy,cancel:&Cancellation)->Result<DryRunResult>{self.no_render(project,path,policy,cancel)}
}
fn project_location(path:&Path)->Result<()> {
    if path.components().any(|c|matches!(c,std::path::Component::ParentDir)){return Err(Error::InvalidProject("parent traversal in project location"));}
    if !path.is_absolute() || !path.extension().and_then(|s|s.to_str()).is_some_and(|s|s.eq_ignore_ascii_case("amxv")){return Err(Error::InvalidProject("absolute .amxv project location required"));}Ok(())
}
