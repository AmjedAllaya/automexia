//! Adjustable source-level entry for the existing host registry and executor.
//! No terminal ABI, installer manifest, scheduler or privilege mechanism is assumed.
use crate::extension::{ActionDescriptor, ProbedInput, VideoStatus, ACTIONS};
use crate::host::{MediaHost, OutputPolicy, ProgressSink};
use crate::{Cancellation, DrainStatus, Error, Project, Result, VideoExtension, VideoSettings};
use std::collections::BTreeSet;
use std::path::Path;
use std::sync::{atomic::{AtomicBool, Ordering}, Mutex};
use std::time::Duration;

/// Explicit editor handoff commands, scheduled by the existing host worker.
pub enum InterchangeCommand<'a> {
    Assess {project:&'a Project,request:&'a crate::ExportRequest},
    Export {project:&'a Project,request:&'a crate::ExportRequest},
}
#[derive(Debug,Clone)]
pub enum InterchangeCommandResult {Assessment(crate::CompatibilityReport),Exported(crate::ExportOutcome)}
pub enum BundleCommand<'a> {
    Assess {project:&'a Project,request:&'a crate::BundleRequest},
    Export {project:&'a Project,request:&'a crate::BundleRequest},
}
#[derive(Debug,Clone)]
pub enum BundleCommandResult {Assessment(crate::CompatibilityReport),Exported(crate::BundleOutcome)}
impl<H:crate::InterchangeHost> RegisteredVideo<H> {
    pub fn dispatch_interchange(&self,command:InterchangeCommand<'_>,cancel:&Cancellation,progress:&mut ProgressSink<'_>)->Result<InterchangeCommandResult>{
        self.check_active()?;cancel.check()?;
        caught(||match command {
            InterchangeCommand::Assess{project,request}=>crate::interchange::assess_export(project,request).map(InterchangeCommandResult::Assessment),
            InterchangeCommand::Export{project,request}=>self.extension.export_interchange(project,request,cancel,progress).map(InterchangeCommandResult::Exported),
        })
    }
}
impl<H:crate::BundleHost> RegisteredVideo<H> {
    pub fn dispatch_bundle(&self,command:BundleCommand<'_>,cancel:&Cancellation,progress:&mut ProgressSink<'_>)->Result<BundleCommandResult>{
        self.check_active()?;cancel.check()?;
        caught(||match command {
            BundleCommand::Assess{project,request}=>crate::assess_bundle(project,request).map(BundleCommandResult::Assessment),
            BundleCommand::Export{project,request}=>self.extension.export_bundle(project,request,cancel,progress).map(BundleCommandResult::Exported),
        })
    }
}

/// Host confirms that the explicit provider/selection and execution capability
/// exist before exposing each optional family. These flags grant no authority.
#[derive(Debug, Clone, Copy, Default, PartialEq, Eq)]
pub struct OptionalActions {
    pub speech_protection: bool,
    pub voice_enhancement: bool,
    pub face_framing: bool,
    pub transcription: bool,
    /// Existing host implements the restricted HDR preservation workflow.
    pub hdr_preservation: bool,
    /// Existing host implements the explicit create-new portable archive lease.
    pub portable_bundles: bool,
}

/// The host rolls back partial registration if this call fails or unwinds.
/// It routes the supplied action identifiers to this crate's typed operations on
/// its existing worker. There is no shell parser or automatic keybinding install.
pub trait ActionRegistry {
    fn register_video(&mut self, actions: &[ActionDescriptor]) -> Result<Box<dyn RegistrationLease>>;
}
/// Owns host registrations and any preview playback associated with this owner.
/// Both methods must be bounded and nonblocking: signal/close existing handles,
/// do not wait for Video jobs or call back into a lifecycle wait. Each is invoked
/// at most once by RegisteredVideo, including when another method fails/panics.
/// Drop should be a nonpanicking fallback for host-owned resources.
pub trait RegistrationLease: Send {
    fn stop_playback(&mut self) -> Result<()>;
    fn unregister(&mut self) -> Result<()>;
}

#[derive(Debug, Clone)]
pub struct DeactivationStatus {
    pub drain: Option<DrainStatus>,
    /// All cleanup phases are attempted; no later error hides an earlier one.
    pub errors: Vec<Error>,
}
impl DeactivationStatus {
    pub fn complete(&self) -> bool { self.errors.is_empty() && self.drain.is_some_and(|d| d.complete) }
}

pub struct RegisteredVideo<H: MediaHost> {
    extension: VideoExtension<H>,
    registration: Mutex<Option<Box<dyn RegistrationLease>>>,
    active: AtomicBool,
    deactivating: AtomicBool,
    actions: Vec<ActionDescriptor>,
}
impl<H: MediaHost> RegisteredVideo<H> {
    /// Explicit registration. Constructing VideoExtension alone remains inert.
    pub fn register(host: H, settings: VideoSettings, registry: &mut dyn ActionRegistry, optional: OptionalActions) -> Result<Self> {
        let extension = VideoExtension::new(host, settings)?;
        let actions = registration_actions(optional)?;
        let registration = caught(|| registry.register_video(&actions))?;
        Ok(Self { extension, registration: Mutex::new(Some(registration)), active: AtomicBool::new(true), deactivating: AtomicBool::new(false), actions })
    }
    /// Specialized typed workflows can be called through this reference. They
    /// retain their own provider checks and normal extension lifetime admission.
    pub fn extension(&self) -> Result<&VideoExtension<H>> {
        self.check_active()?;
        Ok(&self.extension)
    }
    pub fn actions(&self) -> &[ActionDescriptor] { &self.actions }
    pub fn is_registered(&self) -> bool { self.active.load(Ordering::Acquire) }
    fn check_active(&self) -> Result<()> {
        if self.is_registered() { Ok(()) } else { Err(Error::Disabled) }
    }
    /// Call on a lifecycle worker, never from an active Video callback. Zero
    /// disables, cleans host handles and polls without waiting. An incomplete
    /// drain permits a later drain attempt; registrations are never resurrected.
    pub fn deactivate(&self, timeout: Duration) -> Result<DeactivationStatus> {
        if timeout > Duration::from_secs(86_400) { return Err(Error::InvalidInput("deactivation timeout exceeds one day")); }
        if self.deactivating.compare_exchange(false, true, Ordering::AcqRel, Ordering::Acquire).is_err() { return Err(Error::Busy); }
        let _lifecycle = DeactivationGuard(&self.deactivating);
        self.active.store(false, Ordering::Release);
        let mut errors = vec![];
        if let Err(error) = self.extension.disable() { errors.push(error); }
        let registration = self.registration.lock().unwrap_or_else(|p| p.into_inner()).take();
        cleanup_registration(registration, &mut errors);
        let drain = match self.extension.disable_and_drain(timeout) {
            Ok(status) => Some(status), Err(error) => { errors.push(error); None }
        };
        Ok(DeactivationStatus { drain, errors })
    }
    /// Typed baseline command dispatch, scheduled by the existing host worker.
    /// Imported bytes and selected paths remain the host's authorization decision.
    pub fn dispatch(&self, command: VideoCommand<'_>, cancel: &Cancellation, progress: &mut ProgressSink<'_>) -> Result<VideoCommandResult> {
        self.check_active()?;
        cancel.check()?;
        caught(|| match command {
            VideoCommand::Status => self.extension.status().map(VideoCommandResult::Status),
            VideoCommand::CheckRuntime => self.extension.check_runtime(cancel).map(VideoCommandResult::Status),
            VideoCommand::Probe(path) => self.extension.probe(path, cancel, progress).map(VideoCommandResult::Probed),
            VideoCommand::RenderUnedited(request) => self.extension.render_unedited(request, cancel, progress).map(VideoCommandResult::Rendered),
            VideoCommand::CreateProject(request) => self.extension.create_project(request, cancel, progress).map(VideoCommandResult::Project),
            VideoCommand::DryRun(project) => self.extension.dry_run(project).map(VideoCommandResult::DryRun),
            VideoCommand::DryRunVariant { project, variant } => self.extension.dry_run_variant(project, variant).map(VideoCommandResult::DryRun),
            VideoCommand::SetAssembly { project, variant, settings } => {project.validate()?;let mut changed=project.clone();changed.set_assembly(variant,settings)?;Ok(VideoCommandResult::Project(changed))},
            VideoCommand::ReviewAssembly { project, variant, disposition, enabled } => {project.validate()?;let mut changed=project.clone();changed.review_assembly(variant,disposition,enabled)?;Ok(VideoCommandResult::Project(changed))},
            VideoCommand::LockAssembly { project, variant, locked } => {project.validate()?;let mut changed=project.clone();changed.set_assembly_locked(variant,locked)?;Ok(VideoCommandResult::Project(changed))},
            VideoCommand::RenderProject { project, request } => self.extension.render_project(project, request, cancel, progress).map(VideoCommandResult::ProjectRendered),
            VideoCommand::Review(project) => self.extension.review_project(project).map(VideoCommandResult::Review),
            VideoCommand::Preview { project, request } => self.extension.preview_edit(project, request, cancel, progress).map(VideoCommandResult::Preview),
            VideoCommand::ImportSubtitles { bytes, format } => self.extension.import_subtitles(bytes, format).map(VideoCommandResult::Subtitles),
            VideoCommand::ExportSubtitles { project, variant, project_file, destination, format, policy } => self.extension.export_subtitles(project, variant, project_file, destination, format, policy, cancel).map(VideoCommandResult::SubtitlesExported),
            VideoCommand::AnalyzeVoice { project, request } => self.extension.analyze_voice(project, request, cancel, progress).map(VideoCommandResult::Voice),
            VideoCommand::AnalyzeColor { project, request } => self.extension.analyze_color(project, request, cancel, progress).map(VideoCommandResult::Color),
            VideoCommand::ExportAudio { project, request } => self.extension.export_audio_stem(project, request, cancel, progress).map(VideoCommandResult::AudioExported),
        })
    }
}
impl<H: MediaHost + crate::ProjectStore> RegisteredVideo<H> {
    pub fn dispatch_project(&self, command: ProjectCommand<'_>, cancel: &Cancellation) -> Result<ProjectCommandResult> {
        self.check_active()?; cancel.check()?;
        caught(|| match command {
            ProjectCommand::Load(path) => self.extension.load_project(path, cancel).map(ProjectCommandResult::Loaded),
            ProjectCommand::Save { project, path, policy } => self.extension.save_project(project, path, policy, cancel).map(ProjectCommandResult::Saved),
            ProjectCommand::SaveWithoutRender { project, path, policy } => self.extension.no_render(project, path, policy, cancel).map(ProjectCommandResult::DryRun),
        })
    }
}
impl<H: MediaHost> Drop for RegisteredVideo<H> {
    fn drop(&mut self) {
        self.active.store(false, Ordering::Release);
        let _ = self.extension.disable();
        let registration = self.registration.get_mut().unwrap_or_else(|p| p.into_inner()).take();
        cleanup_registration(registration, &mut vec![]);
        // No join/drain wait in Drop. Host code may unload only after an explicit
        // successful drain; the shared extension registry signals all scopes.
    }
}
struct DeactivationGuard<'a>(&'a AtomicBool);
impl Drop for DeactivationGuard<'_> { fn drop(&mut self) { self.0.store(false, Ordering::Release); } }
fn caught<T>(operation: impl FnOnce() -> Result<T>) -> Result<T> {
    std::panic::catch_unwind(std::panic::AssertUnwindSafe(operation)).map_err(|_| Error::CallbackPanicked)?
}
fn cleanup_registration(registration: Option<Box<dyn RegistrationLease>>, errors: &mut Vec<Error>) {
    if let Some(mut registration) = registration {
        if let Err(error) = caught(|| registration.stop_playback()) { errors.push(error); }
        if let Err(error) = caught(|| registration.unregister()) { errors.push(error); }
        if let Err(error) = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| drop(registration))) { let _ = error; errors.push(Error::CallbackPanicked); }
    }
}
fn registration_actions(optional: OptionalActions) -> Result<Vec<ActionDescriptor>> {
    let mut actions: Vec<_> = ACTIONS.iter().copied().filter(|action| {
        !action.id.starts_with("video.faces.") && !action.id.starts_with("video.speech.")
            && !action.id.starts_with("video.enhancement.") && !action.id.starts_with("video.transcript.") && !action.id.starts_with("video.hdr.") && action.id!="video.export.bundle"
    }).collect();
    if optional.speech_protection { actions.extend_from_slice(crate::speech_workflow::SPEECH_ACTIONS); }
    if optional.face_framing {
        actions.extend_from_slice(crate::face_workflow::FACE_ACTIONS);
    }
    if optional.voice_enhancement {
        actions.push(ActionDescriptor { id: "video.enhancement.render", label: "Produce explicitly selected voice enhancement for review", writes_output: true });
    }
    if optional.transcription { actions.extend_from_slice(crate::transcript_workflow::TRANSCRIPT_ACTIONS); }
    if optional.hdr_preservation {
        actions.push(ActionDescriptor { id: "video.hdr.render", label: "Preserve explicitly supported HDR video with verified packet, pixel and metadata evidence", writes_output: true });
    }
    if optional.portable_bundles {
        actions.push(ActionDescriptor{id:"video.export.bundle",label:"Export a portable ZIP64 interchange and media bundle",writes_output:true});
    }
    let mut ids = BTreeSet::new();
    if actions.iter().any(|a| !ids.insert(a.id)) { return Err(Error::InvalidInput("duplicate Video registration action")); }
    Ok(actions)
}

pub enum VideoCommand<'a> {
    Status,
    CheckRuntime,
    Probe(&'a Path),
    RenderUnedited(&'a crate::RenderRequest),
    CreateProject(&'a crate::NewProjectRequest),
    DryRun(&'a Project),
    DryRunVariant { project: &'a Project, variant: &'a str },
    SetAssembly { project: &'a Project, variant: &'a str, settings: Option<crate::AssemblySettings> },
    ReviewAssembly { project: &'a Project, variant: &'a str, disposition: crate::Disposition, enabled: bool },
    LockAssembly { project: &'a Project, variant: &'a str, locked: bool },
    RenderProject { project: &'a Project, request: &'a crate::ProjectRenderRequest },
    Review(&'a Project),
    Preview { project: &'a Project, request: &'a crate::PreviewRequest },
    ImportSubtitles { bytes: &'a [u8], format: crate::SubtitleFormat },
    ExportSubtitles { project: &'a Project, variant: &'a str, project_file: &'a Path, destination: &'a Path, format: crate::SubtitleFormat, policy: &'a OutputPolicy },
    AnalyzeVoice { project: &'a Project, request: &'a crate::VoiceAnalysisRequest },
    AnalyzeColor { project: &'a Project, request: &'a crate::ColorAnalysisRequest },
    ExportAudio { project: &'a Project, request: &'a crate::AudioStemRequest },
}
pub enum VideoCommandResult {
    Status(VideoStatus), Probed(ProbedInput), Rendered(crate::RenderResult), Project(Project),
    DryRun(crate::DryRunResult), ProjectRendered(crate::ProjectRenderResult), Review(crate::ReviewSession),
    Preview(crate::PreviewSet), Subtitles(crate::SubtitleDocument),
    SubtitlesExported(crate::presentation_workflow::SubtitleExport), Voice(crate::VoiceReport),
    Color(crate::ColorReport), AudioExported(crate::AudioStemResult),
}
pub enum ProjectCommand<'a> {
    Load(&'a Path),
    Save { project: &'a Project, path: &'a Path, policy: &'a OutputPolicy },
    SaveWithoutRender { project: &'a Project, path: &'a Path, policy: &'a OutputPolicy },
}
pub enum ProjectCommandResult { Loaded(crate::LoadedProject), Saved(crate::SavedProject), DryRun(crate::DryRunResult) }
