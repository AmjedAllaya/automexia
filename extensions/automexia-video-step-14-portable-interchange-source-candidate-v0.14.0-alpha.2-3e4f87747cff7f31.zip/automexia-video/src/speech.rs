//! Speech-aware pause protection. Learned probabilities can VETO existing
//! energy proposals; they never add cuts, grant authority or auto-approve edits.
use crate::{Cancellation, Error, Rational, Result};
use crate::model_pack::{ModelActivation, ModelIdentity};
use crate::project::{Project, TimeRange};
use crate::pause::{PauseReport, PauseCandidate};
use serde::{Deserialize, Serialize};
use std::time::{Duration, Instant};

pub const SPEECH_RATE:u32=16000;
pub const SPEECH_WINDOW:usize=512;
pub const SPEECH_CONTEXT:usize=64;
pub const SPEECH_STATE:usize=256;
pub const SPEECH_INPUT:usize=SPEECH_CONTEXT+SPEECH_WINDOW;
pub const MAX_SPEECH_SPANS:usize=32_768;
pub const MAX_SPEECH_FRAMES:u64=2_700_000;
pub const SPEECH_GUARD_REVISION:&str="energy-veto-silero-v1";

#[derive(Debug,Clone,PartialEq,Serialize,Deserialize)]
#[serde(deny_unknown_fields)]
pub struct SpeechSettings {
    /// Values in the interval between these thresholds are UNCERTAIN, not silence.
    pub no_speech_at_most:f32,
    pub speech_at_least:f32,
    pub protect_before_ms:u32,
    pub protect_after_ms:u32,
    pub flank_search_ms:u32,
    pub confident_flank_ms:u32,
    /// Explicit selected-stream channel. Never average stereo silently.
    pub analysis_channel:u16,
}
impl Default for SpeechSettings {
    fn default()->Self {Self{no_speech_at_most:0.2,speech_at_least:0.6,
        protect_before_ms:200,protect_after_ms:250,flank_search_ms:2500,
        confident_flank_ms:160,analysis_channel:0}}
}
impl SpeechSettings {
    pub fn validate(&self)->Result<()> {
        if !self.no_speech_at_most.is_finite()||!self.speech_at_least.is_finite()
            ||!(0.01..=0.3).contains(&self.no_speech_at_most)
            ||!(0.5..=0.95).contains(&self.speech_at_least)
            ||self.no_speech_at_most>=self.speech_at_least
            ||!(100..=2000).contains(&self.protect_before_ms)
            ||!(100..=2000).contains(&self.protect_after_ms)
            ||!(500..=10000).contains(&self.flank_search_ms)
            ||!(32..=1000).contains(&self.confident_flank_ms)
            ||self.confident_flank_ms>self.flank_search_ms||self.analysis_channel>7 {
            return Err(Error::InvalidInput("speech guard settings"));
        }Ok(())
    }
}

/// A typed provider boundary. Implementations must be pinned, CPU-only in this
/// profile, and release model state on drop. No raw PCM is serialized as JSON.
pub struct SpeechTensorOutput {pub probability:f32,pub state:[f32;SPEECH_STATE]}
pub trait SpeechSession:Send {
    fn identity(&self)->&ModelIdentity;
    fn infer(&mut self,input:&[f32;SPEECH_INPUT],state:&[f32;SPEECH_STATE],
             cancel:&Cancellation)->Result<SpeechTensorOutput>;
}
pub trait SpeechModelProvider:Send+Sync {
    fn identity(&self)->&ModelIdentity;
    /// The component/privilege owner rechecks permission and pinned runtime.
    fn revalidate(&self,cancel:&Cancellation)->Result<()>;
    fn open(&self,cancel:&Cancellation)->Result<Box<dyn SpeechSession>>;
}

#[derive(Debug,Clone)]
pub struct SpeechAudioFrame {
    /// Original presentation timestamp in 1/16000 seconds after resampling.
    pub pts:i64,
    /// At most 512 samples; the final partial frame is never used as silence.
    pub samples:Vec<f32>,
}
#[derive(Debug,Clone,Copy,PartialEq,Eq,Serialize)]
#[serde(rename_all="snake_case")]
pub enum SpeechClass {NoSpeech,Uncertain,Speech}
#[derive(Debug,Clone,Serialize)]
pub struct SpeechSpan {pub range:TimeRange,pub class:SpeechClass,pub maximum_probability:f32}
#[derive(Debug,Clone,Serialize)]
pub struct SpeechObservation {
    pub model:ModelIdentity,
    pub settings:SpeechSettings,
    pub decoded_frames:u64,
    pub reset_count:u64,
    /// Small decoder-PTS overlaps clipped from analysis only; affected windows are uncertain.
    pub timestamp_repairs:u64,
    pub observed_duration:Rational,
    pub spans:Vec<SpeechSpan>,
}

/// One source/channel, one recurrent state, one existing host job. No thread pool.
/// Protocol errors poison the analyzer. A new object is required for another file.
pub struct SpeechAnalyzer {
    session:Box<dyn SpeechSession>, model:ModelIdentity, settings:SpeechSettings, activation:ModelActivation,
    origin:Rational,duration:Rational,last_end:Option<i64>,state:[f32;SPEECH_STATE],
    context:[f32;SPEECH_CONTEXT],spans:Vec<SpeechSpan>,frames:u64,resets:u64,
    observed:Rational,failed:bool,saw_partial:bool,force_reset:bool,repairs:u64,start:Instant,timeout:Duration,
}
impl SpeechAnalyzer {
    pub fn new(session:Box<dyn SpeechSession>,activation:&ModelActivation,settings:SpeechSettings,
               origin:Rational,duration:Rational,timeout:Duration)->Result<Self> {
        settings.validate()?;activation.check()?;
        let identity=std::panic::catch_unwind(std::panic::AssertUnwindSafe(||session.identity().clone())).map_err(|_|Error::CallbackPanicked)?;
        identity.validate()?;
        if identity.contract!=crate::model_pack::SILERO_CONTRACT||identity.preprocessing!=crate::model_pack::SPEECH_PROCESSING{return Err(Error::Unsupported("speech model identity contract"));}
        if &identity!=activation.identity(){return Err(Error::InputChanged);}
        if !duration.positive()||duration>Rational::new(86400,1)?||timeout.is_zero()
            ||timeout>Duration::from_secs(86400){return Err(Error::InvalidInput("speech analysis limits"));}
        origin.ceil_units(i64::from(SPEECH_RATE))?;
        origin.checked_add(duration)?.ceil_units(i64::from(SPEECH_RATE))?;
        Ok(Self{model:identity,session,settings,activation:activation.clone(),origin,duration,last_end:None,
            state:[0.0;SPEECH_STATE],context:[0.0;SPEECH_CONTEXT],spans:vec![],frames:0,resets:0,
            observed:Rational::new(0,1)?,failed:false,saw_partial:false,force_reset:false,repairs:0,start:Instant::now(),timeout})
    }
    pub fn push(&mut self,frame:SpeechAudioFrame,cancel:&Cancellation)->Result<()> {
        if self.failed{return Err(Error::InvalidInput("speech analyzer already failed"));}
        let result=self.push_inner(frame,cancel);if result.is_err(){self.failed=true;}result
    }
    fn push_inner(&mut self,frame:SpeechAudioFrame,cancel:&Cancellation)->Result<()> {
        self.activation.check()?;cancel.check()?;if self.start.elapsed()>=self.timeout{return Err(Error::Timeout);}
        if frame.samples.is_empty()||frame.samples.len()>SPEECH_WINDOW||self.frames>=MAX_SPEECH_FRAMES
            ||frame.samples.iter().any(|s|!s.is_finite()||s.abs()>8.0){return Err(Error::InvalidInput("speech PCM frame"));}
        // A short decoder frame can occur before a discontinuity. It may not be
        // followed by a contiguous frame: use fixed 512-sample framing upstream.
        let discontinuity=self.force_reset||self.last_end.is_some_and(|last|last!=frame.pts);
        if self.saw_partial&&!discontinuity{return Err(Error::InvalidInput("partial speech frame before end"));}
        if self.last_end.is_some_and(|last|frame.pts<last){return Err(Error::InvalidInput("overlapping speech audio timestamps"));}
        let end=frame.pts.checked_add(frame.samples.len() as i64).ok_or(Error::LimitExceeded("speech timestamp overflow"))?;
        if discontinuity {self.state.fill(0.0);self.context.fill(0.0);self.resets+=1;}
        self.saw_partial=frame.samples.len()<SPEECH_WINDOW;
        let mut input=[0.0;SPEECH_INPUT];input[..SPEECH_CONTEXT].copy_from_slice(&self.context);
        input[SPEECH_CONTEXT..SPEECH_CONTEXT+frame.samples.len()].copy_from_slice(&frame.samples);
        // Never feed clipped floats outside the documented normalized signal
        // interval into a model. Clipping is not repaired or used as quiet evidence.
        let clipped=frame.samples.iter().any(|s|s.abs()>1.0);
        for sample in &mut input[SPEECH_CONTEXT..]{*sample=sample.clamp(-1.0,1.0);}
        let deadline=self.start.checked_add(self.timeout).ok_or(Error::InvalidInput("speech analyzer deadline"))?;
        let scope = self.activation.scope(cancel)?.with_deadline(deadline);
        let output=std::panic::catch_unwind(std::panic::AssertUnwindSafe(||self.session.infer(&input,&self.state,&scope)))
            .map_err(|_|Error::CallbackPanicked)??;
        self.activation.check()?;cancel.check()?;if self.start.elapsed()>=self.timeout{return Err(Error::Timeout);}
        if !output.probability.is_finite()||!(0.0..=1.0).contains(&output.probability)
            ||output.state.iter().any(|s|!s.is_finite()||s.abs()>1e6){return Err(Error::InvalidOutput("invalid speech-model tensor"));}
        self.state=output.state;self.context.copy_from_slice(&input[SPEECH_INPUT-SPEECH_CONTEXT..]);
        let start=Rational::new(frame.pts,i64::from(SPEECH_RATE))?.checked_sub(self.origin)?.max(Rational::new(0,1)?);
        let stop=Rational::new(end,i64::from(SPEECH_RATE))?.checked_sub(self.origin)?.min(self.duration);
        if stop>start {
            // Startup/reset and partial tails remain uncertain, even if a padded
            // neural frame reports zero. Missing coverage is never called silence.
            let class=if clipped||self.saw_partial||self.frames==0||discontinuity {SpeechClass::Uncertain}
                else if output.probability<=self.settings.no_speech_at_most{SpeechClass::NoSpeech}
                else if output.probability>=self.settings.speech_at_least{SpeechClass::Speech}
                else{SpeechClass::Uncertain};
            let range=TimeRange::new(start,stop)?;
            self.observed=self.observed.checked_add(range.duration()?)?;
            if let Some(last)=self.spans.last_mut().filter(|v|v.class==class&&v.range.end==range.start) {
                last.range.end=range.end;last.maximum_probability=last.maximum_probability.max(output.probability);
            }else{
                if self.spans.len()>=MAX_SPEECH_SPANS{return Err(Error::LimitExceeded("speech observation spans"));}
                self.spans.push(SpeechSpan{range,class,maximum_probability:output.probability});
            }
        }
        self.last_end=Some(end);self.force_reset=false;self.frames+=1;Ok(())
    }
    fn uncertain_boundary(&mut self)->Result<()> {
        self.force_reset=true;self.repairs=self.repairs.checked_add(1).ok_or(Error::LimitExceeded("speech timestamp repairs"))?;Ok(())
    }
    pub fn finish(self,cancel:&Cancellation)->Result<SpeechObservation> {
        self.activation.check()?;cancel.check()?;if self.failed{return Err(Error::InvalidInput("failed speech analysis"));}
        if self.start.elapsed()>=self.timeout{return Err(Error::Timeout);}
        if self.frames==0||self.spans.is_empty(){return Err(Error::InvalidInput("no speech audio observations"));}
        Ok(SpeechObservation{model:self.model,settings:self.settings,decoded_frames:self.frames,reset_count:self.resets,
            timestamp_repairs:self.repairs,observed_duration:self.observed,spans:self.spans})
    }
}

#[derive(Debug,Clone,Copy,PartialEq,Eq,Serialize)]
#[serde(rename_all="snake_case")]
pub enum SpeechVeto {SpeechOrUncertain,MissingCoverage,NoConfidentFlanks}
#[derive(Debug,Clone,Serialize)]
pub struct RejectedSpeechCut {pub operation_id:String,pub range:TimeRange,pub reason:SpeechVeto}
#[derive(Debug,Clone,PartialEq,Eq,Serialize)]
pub struct SpeechMediaRuntime {
    pub ffmpeg_sha256:String,pub ffprobe_sha256:String,
    pub ffmpeg_version:String,pub ffprobe_version:String,
}
impl SpeechMediaRuntime {
    pub fn capture(v:&crate::host::RuntimeCapabilities)->Result<Self>{
        let ffmpeg=v.ffmpeg_identity.as_ref().ok_or(Error::MissingCapability("pinned FFmpeg identity for speech preprocessing"))?;
        let ffprobe=v.ffprobe_identity.as_ref().ok_or(Error::MissingCapability("pinned ffprobe identity for speech preprocessing"))?;
        crate::model_pack::hash(ffmpeg)?;crate::model_pack::hash(ffprobe)?;
        for text in [&v.ffmpeg_version,&v.ffprobe_version]{
            if text.is_empty()||text.len()>4096||text.contains('\0'){return Err(Error::InvalidInput("bounded media runtime version"));}
        }
        Ok(Self{ffmpeg_sha256:ffmpeg.clone(),ffprobe_sha256:ffprobe.clone(),
            ffmpeg_version:v.ffmpeg_version.clone(),ffprobe_version:v.ffprobe_version.clone()})
    }
}
#[derive(Debug,Clone,Serialize)]
pub struct SpeechPauseReport {
    pub model:ModelIdentity,
    pub settings:SpeechSettings,
    pub baseline_candidates:usize,
    pub media_runtime:SpeechMediaRuntime,
    pub rejected:Vec<RejectedSpeechCut>,
    pub observed_frames:u64,
    pub discontinuity_resets:u64,
    pub timestamp_repairs:u64,
    pub warnings:Vec<String>,
    inner:PauseReport,
    #[serde(skip)] activation:ModelActivation,
    #[serde(skip)] owner:Cancellation,
}
impl SpeechPauseReport {
    pub fn candidates(&self)->&[PauseCandidate]{self.inner.candidates()}
    pub fn accepted_duration(&self)->Rational{self.inner.accepted_duration()}
    pub fn proposed_duration(&self)->Rational{self.inner.proposed_duration()}
    pub fn proposed_removed_duration(&self)->Rational{self.inner.proposed_removed_duration()}
    pub fn apply(&self,project:&mut Project)->Result<()> {
        self.activation.check()?;self.owner.check()?;self.inner.apply(project)
    }
    pub(crate) fn checked_report(&self)->Result<&PauseReport>{self.activation.check()?;self.owner.check()?;Ok(&self.inner)}
}

/// A monotonic safety filter: no newly selected range can exceed an energy-only
/// candidate, and all output remains NeedsReview. Short/uncertain speech is kept.
pub(crate) fn guard_pause_candidates(baseline:PauseReport,observation:SpeechObservation,activation:&ModelActivation,
                              owner:&Cancellation,media_runtime:SpeechMediaRuntime)->Result<SpeechPauseReport> {
    activation.check()?;owner.check()?;observation.model.validate()?;observation.settings.validate()?;
    if &observation.model!=activation.identity(){return Err(Error::InputChanged);}
    validate_observation(&observation)?;
    let mut keep=Vec::with_capacity(baseline.candidates().len());let mut rejected=Vec::new();
    for candidate in baseline.candidates() {
        owner.check()?;
        let reason=veto(candidate.operation.range,&observation)?;
        keep.push(reason.is_none());
        if let Some(reason)=reason {rejected.push(RejectedSpeechCut{operation_id:candidate.operation.id.clone(),range:candidate.operation.range,reason});}
    }
    let baseline_candidates=keep.len();
    let settings_bytes=serde_json::to_vec(&observation.settings).map_err(|_|Error::InvalidInput("speech settings encoding"))?;
    let settings_hash=crate::model_pack::digest(&settings_bytes,owner)?;
    let runtime_bytes=serde_json::to_vec(&media_runtime).map_err(|_|Error::InvalidInput("speech runtime encoding"))?;
    let runtime_hash=crate::model_pack::digest(&runtime_bytes,owner)?;
    let provenance=format!(" Speech guard={SPEECH_GUARD_REVISION}; model={}; manifest={}; runtime={}; settings={}; media={}. Model probabilities are not proof of speech absence.",
        observation.model.weights_sha256,observation.model.manifest_sha256,observation.model.runtime.artifact_sha256,settings_hash,runtime_hash);
    let inner=baseline.speech_filtered(&keep,&provenance)?;
    Ok(SpeechPauseReport{model:observation.model,settings:observation.settings,baseline_candidates,media_runtime,rejected,
        observed_frames:observation.decoded_frames,discontinuity_resets:observation.reset_count,timestamp_repairs:observation.timestamp_repairs,
        warnings:vec!["Only existing quiet-energy proposals were considered; the model may veto but cannot add or approve cuts.".into(),
            "A selected analysis channel does not establish speech absence in other channels; energy limits still inspect all channels.".into(),
            "Human listening and exact-model corpus qualification remain required, especially for breaths, accents, noise and mixed music.".into()],
        inner,activation:activation.clone(),owner:owner.clone()})
}
fn validate_observation(v:&SpeechObservation)->Result<()> {
    if v.decoded_frames==0||v.decoded_frames>MAX_SPEECH_FRAMES||v.spans.len()>MAX_SPEECH_SPANS||v.spans.is_empty(){return Err(Error::InvalidInput("speech observation size"));}
    let mut end=Rational::new(0,1)?;
    let mut observed=Rational::new(0,1)?;
    for span in &v.spans {
        span.range.validate()?;
        if span.range.start<end||!span.maximum_probability.is_finite()||!(0.0..=1.0).contains(&span.maximum_probability){return Err(Error::InvalidInput("speech observation ordering/probability"));}
        if (span.class==SpeechClass::NoSpeech && span.maximum_probability>v.settings.no_speech_at_most)
            ||(span.class==SpeechClass::Speech && span.maximum_probability<v.settings.speech_at_least) {
            return Err(Error::InvalidInput("speech class contradicts probability"));
        }
        observed=observed.checked_add(span.range.duration()?)?;
        end=span.range.end;
    }
    if observed!=v.observed_duration||v.reset_count>=v.decoded_frames||v.timestamp_repairs>v.reset_count{return Err(Error::InvalidInput("speech observation accounting"));}
    Ok(())
}
fn veto(cut:TimeRange,v:&SpeechObservation)->Result<Option<SpeechVeto>> {
    let zero=Rational::new(0,1)?;
    let before=Rational::new(i64::from(v.settings.protect_before_ms),1000)?;
    let after=Rational::new(i64::from(v.settings.protect_after_ms),1000)?;
    let wanted=TimeRange::new(cut.start.checked_sub(before)?.max(zero),cut.end.checked_add(after)?)?;
    let mut covered=wanted.start;
    for span in &v.spans {
        if span.range.end<=wanted.start {continue;}if span.range.start>=wanted.end{break;}
        if span.range.start>covered{return Ok(Some(SpeechVeto::MissingCoverage));}
        if span.class!=SpeechClass::NoSpeech{return Ok(Some(SpeechVeto::SpeechOrUncertain));}
        covered=covered.max(span.range.end.min(wanted.end));
    }
    if covered<wanted.end{return Ok(Some(SpeechVeto::MissingCoverage));}
    let flank=Rational::new(i64::from(v.settings.flank_search_ms),1000)?;
    let minimum=Rational::new(i64::from(v.settings.confident_flank_ms),1000)?;
    let left=TimeRange::new(cut.start.checked_sub(flank)?.max(zero),cut.start)?;
    let right=TimeRange::new(cut.end,cut.end.checked_add(flank)?)?;
    if speech_duration(&v.spans,left)?<minimum||speech_duration(&v.spans,right)?<minimum {
        return Ok(Some(SpeechVeto::NoConfidentFlanks));
    }Ok(None)
}
fn speech_duration(spans:&[SpeechSpan],window:TimeRange)->Result<Rational>{
    let mut total=Rational::new(0,1)?;
    for s in spans {if s.class==SpeechClass::Speech&&s.range.overlaps(&window){total=total.checked_add(s.range.end.min(window.end).checked_sub(s.range.start.max(window.start))?)?;}}
    Ok(total)
}

/// Reblocks decoder packets without normalizing away timestamp gaps. The pending
/// payload is at most 511 samples between calls. A gap flushes the partial tail
/// as uncertain and the next full inference starts with a fresh recurrent state.
pub struct SpeechWindowBuffer {
    analyzer:SpeechAnalyzer,pending:Vec<f32>,pending_pts:Option<i64>,last_raw_end:Option<i64>,overlap_tolerance:i64,failed:bool,
}
impl SpeechWindowBuffer {
    pub fn new(analyzer:SpeechAnalyzer)->Self{Self{analyzer,pending:Vec::with_capacity(SPEECH_WINDOW),pending_pts:None,last_raw_end:None,overlap_tolerance:0,failed:false}}
    /// Only declared source timestamps no coarser than 1ms get a bounded
    /// resampler-quantization allowance. Unknown/coarser timing stays strict.
    pub fn with_timestamp_resolution(analyzer:SpeechAnalyzer,time_base:Option<Rational>)->Result<Self>{
        let mut out=Self::new(analyzer);
        if let Some(tb)=time_base {
            if !tb.positive(){return Err(Error::InvalidInput("speech timestamp resolution"));}
            if tb<=Rational::new(1,1000)? {
                out.overlap_tolerance=tb.ceil_units(i64::from(SPEECH_RATE))?.checked_add(1)
                    .ok_or(Error::LimitExceeded("speech timestamp resolution"))?;
            }
        }Ok(out)
    }
    pub fn push(&mut self,frame:SpeechAudioFrame,cancel:&Cancellation)->Result<()> {
        if self.failed{return Err(Error::InvalidInput("failed speech window buffer"));}
        let result=self.push_inner(frame,cancel);if result.is_err(){self.failed=true;}result
    }
    fn flush(&mut self,cancel:&Cancellation)->Result<()> {
        if self.pending.is_empty(){return Ok(());}
        let samples=std::mem::take(&mut self.pending);
        let pts=self.pending_pts.take().ok_or(Error::InvalidInput("speech window origin"))?;
        self.analyzer.push(SpeechAudioFrame{pts,samples},cancel)
    }
    fn push_inner(&mut self,mut frame:SpeechAudioFrame,cancel:&Cancellation)->Result<()> {
        cancel.check()?;
        if frame.samples.is_empty()||frame.samples.len()>crate::speech_pipe::MAX_DECODE_SAMPLES
            ||frame.samples.iter().any(|v|!v.is_finite()||v.abs()>8.0){return Err(Error::InvalidInput("decoded speech packet size"));}
        if let Some(end)=self.last_raw_end {
            if frame.pts<end {
                let overlap=end.checked_sub(frame.pts).ok_or(Error::LimitExceeded("speech packet overlap"))?;
                if overlap>self.overlap_tolerance||overlap>=frame.samples.len() as i64 {
                    return Err(Error::InvalidInput("decoded speech packet overlap"));
                }
                self.flush(cancel)?;
                self.analyzer.uncertain_boundary()?;
                // Never adjust the output/edit timeline or invent silence. Only
                // redundant analysis coverage is clipped; reset window is unknown.
                frame.samples.drain(..overlap as usize);frame.pts=end;
            }
            if frame.pts>end{self.flush(cancel)?;}
        }
        let end=frame.pts.checked_add(frame.samples.len() as i64).ok_or(Error::LimitExceeded("speech decode timestamps"))?;
        let mut offset=0usize;
        while offset<frame.samples.len() {
            cancel.check()?;
            if self.pending.is_empty(){self.pending_pts=Some(frame.pts.checked_add(offset as i64).ok_or(Error::LimitExceeded("speech frame timestamp"))?);}
            let take=(SPEECH_WINDOW-self.pending.len()).min(frame.samples.len()-offset);
            self.pending.extend_from_slice(&frame.samples[offset..offset+take]);offset+=take;
            if self.pending.len()==SPEECH_WINDOW{self.flush(cancel)?;}
        }
        self.last_raw_end=Some(end);Ok(())
    }
    pub fn finish(mut self,cancel:&Cancellation)->Result<SpeechObservation>{
        if self.failed{return Err(Error::InvalidInput("failed speech window buffer"));}
        self.flush(cancel)?;self.analyzer.finish(cancel)
    }
}

#[cfg(test)]
mod tests;
