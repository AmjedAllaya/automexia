//! Typed classical filter compilation and loudness measurements. Filter strings
//! are generated only from validated settings; no shell snippets or user filters.
use crate::{Cancellation, Error, Rational, Result};
use crate::host::{InputFile, RuntimeCapabilities, words};
use crate::project::Project;
use crate::voice::{TreatmentMode, VoiceCleanup, finite_range};
use serde::{Deserialize, Serialize};
use std::{ffi::OsString, path::{Path,PathBuf}, time::Duration};

pub const MAX_LOUDNESS_BYTES:usize=64*1024;
pub const MAX_PEAK_RETRIES:u8=2;
pub const PCM_PREFIX:&[&str]=&["-hide_banner","-loglevel","error","-nostdin","-xerror","-max_alloc","268435456","-copyts","-threads","2","-protocol_whitelist","file","-format_whitelist","mov,matroska,webm","-i"];
pub const MEASURE_FILTER:&str="loudnorm=I=-18:TP=-1.5:LRA=11:print_format=json";
pub const DC_FILTER:&str="highpass=f=10:p=1";
pub const RUMBLE_FILTER:&str="highpass=f={frequency}:p=2";
pub const HUM_FILTER:&str="bandreject=f={frequency}:t=q:w={q}";
pub const DENOISE_FILTER:&str="apad=pad_len={delay},afftdn=nr={reduction}:nf={floor}:tn=0:tr=0,atrim=start_sample={delay},asetpts=PTS-{delay}/({rate}*TB)";
pub const EQ_FILTER:&str="equalizer=f=3000:t=q:w=1:g={gain}";
pub const DEESS_FILTER:&str="deesser=i={intensity}:m={amount}:f=0.5:s=o";
pub const COMPRESS_FILTER:&str="acompressor=threshold={threshold}:ratio={ratio}:attack={attack}:release={release}:makeup=1:knee=2:link=maximum:detection=rms";
pub const LIMITER_FILTER:&str="aresample=192000,alimiter=limit={limit}:attack=5:release=50:level=0:latency=1,aresample={rate}";

#[derive(Debug,Clone,PartialEq,Serialize,Deserialize)]
#[serde(deny_unknown_fields)]
pub struct LoudnessMeasurement {
    /// None means below the gated meter or digital silence, not a numeric zero.
    pub integrated_lufs:Option<f64>,pub true_peak_dbtp:Option<f64>,
    pub range_lu:f64,pub threshold_lufs:f64,
}
impl LoudnessMeasurement {
    pub fn validate(&self)->Result<()> {
        if self.integrated_lufs.is_some_and(|v|!finite_range(v,-1000.0,30.0))
            ||self.true_peak_dbtp.is_some_and(|v|!finite_range(v,-1000.0,30.0))
            ||!finite_range(self.range_lu,0.0,100.0)||!finite_range(self.threshold_lufs,-1000.0,30.0){
            return Err(Error::InvalidOutput("invalid loudness measurement"));
        }Ok(())
    }
    /// FFmpeg emits one JSON object on stderr. Bound it, reject duplicate keys,
    /// and accept -inf only for level fields. NaN and malformed partial data fail.
    pub fn parse(bytes:&[u8])->Result<Self>{
        if bytes.len()>MAX_LOUDNESS_BYTES{return Err(Error::LimitExceeded("loudness JSON"));}
        let start=bytes.iter().rposition(|b|*b==b'{').ok_or(Error::InvalidOutput("missing loudness JSON"))?;
        let end=bytes.iter().rposition(|b|*b==b'}').ok_or(Error::InvalidOutput("incomplete loudness JSON"))?;
        if start>=end{return Err(Error::InvalidOutput("incomplete loudness JSON"));}
        let value=crate::project_json::parse_unique(&bytes[start..=end]).map_err(|_|Error::InvalidOutput("invalid/duplicate loudness JSON"))?;
        let obj=value.as_object().ok_or(Error::InvalidOutput("loudness object"))?;
        for key in obj.keys(){if !["input_i","input_tp","input_lra","input_thresh","output_i","output_tp","output_lra","output_thresh","normalization_type","target_offset"].contains(&key.as_str()){return Err(Error::InvalidOutput("unknown loudness field"));}}
        let level=|key:&str,negative_infinity:bool|->Result<Option<f64>>{
            let s=obj.get(key).and_then(serde_json::Value::as_str).ok_or(Error::InvalidOutput("missing loudness field"))?;
            if negative_infinity&&s=="-inf" {return Ok(None);}
            let v=s.parse::<f64>().map_err(|_|Error::InvalidOutput("loudness number"))?;
            if !v.is_finite(){return Err(Error::InvalidOutput("nonfinite loudness number"));}Ok(Some(v))
        };
        let result=Self{integrated_lufs:level("input_i",true)?,true_peak_dbtp:level("input_tp",true)?,
            range_lu:level("input_lra",false)?.ok_or(Error::InvalidOutput("loudness range"))?,
            threshold_lufs:level("input_thresh",false)?.ok_or(Error::InvalidOutput("loudness threshold"))?};
        result.validate()?;Ok(result)
    }
}
#[derive(Debug,Clone,Serialize)]
pub struct GainDecision {
    pub measured:LoudnessMeasurement,pub gain_db:f64,pub gain_limited:bool,
    pub limiter_applied:bool,pub correction_passes:u8,pub warnings:Vec<String>,
}
#[derive(Debug,Clone,Serialize)]
pub struct AudioRenderReport {
    pub before_gain:LoudnessMeasurement,pub output:LoudnessMeasurement,
    pub applied_gain_db:f64,pub limiter_applied:bool,pub correction_passes:u8,pub warnings:Vec<String>,
}
#[derive(Debug,Clone,Serialize)]
pub struct VoiceRender {
    pub(crate) profile:VoiceCleanup,pub(crate) rate:u32,pub(crate) channels:u32,
    pub(crate) layout:String,pub(crate) gain:Option<GainDecision>,
}
impl VoiceRender {
    pub fn from_project(project:&Project,runtime:&RuntimeCapabilities)->Result<Option<Self>>{
        project.validate()?;
        let Some(profile)=&project.settings.voice_cleanup else{return Ok(None)};
        if !profile.active(){return Ok(None);}
        let audio=project.sources[0].media.audio.as_ref().ok_or(Error::InvalidProject("voice requires selected audio"))?;
        let rate=audio.sample_rate.ok_or(Error::InvalidProject("voice sample rate"))?;
        let channels=audio.channels.ok_or(Error::InvalidProject("voice channel count"))?;
        let layout=qualified_layout(channels,audio.channel_layout.as_deref())?;
        let v=Self{profile:profile.clone(),rate,channels,layout,gain:None};v.check_runtime(runtime)?;Ok(Some(v))
    }
    pub fn check_runtime(&self,runtime:&RuntimeCapabilities)->Result<()> {
        self.profile.validate()?;
        if !(7350..=96000).contains(&self.rate){return Err(Error::Unsupported("voice sample rate"));}
        qualified_layout(self.channels,Some(&self.layout))?;
        let t=&self.profile.stages;
        if t.denoise&&!afftdn_timing_qualified(&runtime.ffmpeg_version) {return Err(Error::Unsupported("afftdn timing contract is qualified for FFmpeg 7.1 releases; bypass denoise on unqualified versions"));}
        let mut required=vec!["loudnorm","aresample","aformat"];
        if t.dc||t.rumble{required.push("highpass");}if t.hum_hz.is_some(){required.push("bandreject");}
        if t.denoise{required.push("afftdn");}if t.equalizer{required.push("equalizer");}
        if t.deesser{required.push("deesser");}if t.compressor{required.push("acompressor");}
        if t.loudness||t.limiter{required.push("volume");}if t.limiter{required.push("alimiter");}
        if required.iter().any(|s|!runtime.filters.contains(*s))||!runtime.muxers.contains("null")||!runtime.encoders.contains("pcm_s16le"){
            return Err(Error::MissingCapability("selected classical audio processing/meter filters"));
        }Ok(())
    }
    pub fn pre_filters(&self)->Result<String>{
        self.profile.validate()?;let s=&self.profile.settings;let t=&self.profile.stages;let mut filters=Vec::new();
        if t.dc{filters.push(DC_FILTER.to_owned());}
        if t.rumble{filters.push(RUMBLE_FILTER.replace("{frequency}",&s.highpass_hz.to_string()));}
        if let Some(hz)=t.hum_hz {for harmonic in 1..=s.hum_harmonics{filters.push(HUM_FILTER.replace("{frequency}",&(hz*u16::from(harmonic)).to_string()).replace("{q}",&s.hum_q.to_string()));}}
        if t.denoise {filters.push(DENOISE_FILTER.replace("{reduction}",&s.noise_reduction_db.to_string()).replace("{floor}",&s.noise_floor_dbfs.to_string()).replace("{delay}",&afftdn_delay(self.rate)?.to_string()).replace("{rate}",&self.rate.to_string()));}
        Ok(if filters.is_empty(){String::new()}else{format!("{},",filters.join(","))})
    }
    pub fn post_filters(&self)->Result<String>{
        self.profile.validate()?;let s=&self.profile.settings;let t=&self.profile.stages;let mut filters=Vec::new();
        if t.equalizer{filters.push(EQ_FILTER.replace("{gain}",&number(s.presence_db)?));}
        if t.deesser{filters.push(DEESS_FILTER.replace("{intensity}",&number(s.deess_intensity)?).replace("{amount}",&number(s.deess_amount)?));}
        if t.compressor {filters.push(COMPRESS_FILTER.replace("{threshold}",&number(10f64.powf(f64::from(s.compressor_threshold_dbfs)/20.0))?)
            .replace("{ratio}",&number(s.compressor_ratio)?).replace("{attack}",&s.attack_ms.to_string()).replace("{release}",&s.release_ms.to_string()));}
        Ok(if filters.is_empty(){String::new()}else{format!(",{}",filters.join(","))})
    }
    pub fn gain_decision(&self)->Option<&GainDecision>{self.gain.as_ref()}
    pub fn resolve_gain(&mut self,measurement:LoudnessMeasurement)->Result<()> {
        measurement.validate()?;let s=&self.profile.settings;let t=&self.profile.stages;let mut warnings=Vec::new();
        let mut desired=0.0;
        if t.loudness {
            if let Some(i)=measurement.integrated_lufs {desired=s.target_lufs-i;
                if s.loudness==TreatmentMode::Auto&&desired.abs()<=0.5 {desired=0.0;}
            }else{warnings.push("Integrated loudness is below the gate or unavailable for this short/silent signal; no normalization boost was applied.".into());}
        }
        let mut gain=desired.clamp(-s.max_attenuation_db,s.max_gain_db);
        // A constant gain, not hidden dynamic loudnorm. Preserve dynamics rather
        // than force the LUFS target through heavy unreviewed limiting.
        let ceiling=s.true_peak_dbtp-s.codec_headroom_db;
        if t.limiter {if let Some(tp)=measurement.true_peak_dbtp {gain=desired.clamp(-s.max_attenuation_db,s.max_gain_db).min(ceiling-tp).max(-s.max_attenuation_db);}}
        let gain_limited=(desired-gain).abs()>0.05;
        if gain_limited {warnings.push("Requested loudness was limited by gain/peak headroom; the actual output measurement is authoritative.".into());}
        let limiter_applied=t.limiter&&(s.limiter==TreatmentMode::On||measurement.true_peak_dbtp.is_some_and(|tp|tp+gain>ceiling-0.05));
        if t.limiter&&!limiter_applied {warnings.push("Peak limiter bypassed because measured peak plus gain has sufficient headroom.".into());}
        self.gain=Some(GainDecision{measured:measurement,gain_db:gain,gain_limited,limiter_applied,correction_passes:0,warnings});Ok(())
    }
    /// Bounded encode feedback: lossy reconstruction may exceed the pre-encode
    /// ceiling. Lower constant gain, never compress harder or publish the failed
    /// file. The caller rerenders the same private lease and revalidates it.
    pub fn correct_encoded_peak(&mut self,output:&LoudnessMeasurement)->Result<bool>{
        output.validate()?;
        if !self.profile.stages.limiter {return Ok(false);}
        let Some(peak)=output.true_peak_dbtp else{return Ok(false)};
        if peak<=self.profile.settings.true_peak_dbtp+0.05 {return Ok(false);}
        let g=self.gain.as_mut().ok_or(Error::InvalidInput("missing voice gain decision"))?;
        if g.correction_passes>=MAX_PEAK_RETRIES {return Err(Error::InvalidOutput("decoded peak still exceeds ceiling after bounded retries"));}
        let corrected=g.gain_db-(peak-self.profile.settings.true_peak_dbtp+0.3);
        if corrected < -self.profile.settings.max_attenuation_db {return Err(Error::InvalidOutput("peak correction exceeds the accepted attenuation limit"));}
        g.gain_db=corrected;g.gain_limited=true;g.correction_passes+=1;
        g.warnings.push(format!("Encoded peak required correction pass {}; constant gain was lowered before rerendering. No failed output was published.",g.correction_passes));
        Ok(true)
    }
    pub fn final_filters(&self,duration:Rational)->Result<String>{
        let g=self.gain.as_ref().ok_or(Error::InvalidInput("voice render requires its edited-signal measurement pass"))?;
        if !finite_range(g.gain_db,-48.0,18.0){return Err(Error::InvalidInput("invalid resolved gain"));}
        let mut filters=Vec::new();
        if g.gain_db.abs()>0.000_001 {filters.push(format!("volume={}dB",number(g.gain_db)?));}
        if g.limiter_applied {
            let limit=10f64.powf((self.profile.settings.true_peak_dbtp-self.profile.settings.codec_headroom_db)/20.0);
            filters.push(LIMITER_FILTER.replace("{limit}",&number(limit)?).replace("{rate}",&self.rate.to_string()));
        }
        // An exact rate/layout is asserted, never an implicit mono analysis downmix.
        filters.push(format!("aformat=sample_rates={}:channel_layouts={}",self.rate,self.layout));
        let samples=duration.ceil_units(i64::from(self.rate))?;
        filters.push(format!("apad=whole_len={samples},atrim=end_sample={samples}"));
        Ok(format!(",{}",filters.join(",")))
    }
    pub fn finish_report(&self,output:LoudnessMeasurement)->Result<AudioRenderReport>{
        output.validate()?;let g=self.gain.as_ref().ok_or(Error::InvalidInput("missing voice gain decision"))?;
        if self.profile.stages.limiter&&output.true_peak_dbtp.is_some_and(|p|p>self.profile.settings.true_peak_dbtp+0.05){
            return Err(Error::InvalidOutput("decoded output exceeds the requested true-peak ceiling"));
        }
        let mut warnings=g.warnings.clone();
        if self.profile.stages.loudness&&output.integrated_lufs.is_some_and(|i|(i-self.profile.settings.target_lufs).abs()>1.0){warnings.push("Output is outside 1 LU of the target; bounded linear gain/peak protection took precedence. No hidden dynamic normalization was substituted.".into());}
        Ok(AudioRenderReport{before_gain:g.measured.clone(),output,applied_gain_db:g.gain_db,limiter_applied:g.limiter_applied,correction_passes:g.correction_passes,warnings})
    }
}
/// FFmpeg 7.1 af_afftdn.c: hop=floor(rate/80), window=3*hop.
/// Two-hop algorithmic delay is flushed with padding, then removed from both
/// samples and timestamps. No source origin is reset. Other versions must be
/// separately qualified rather than silently assume identical filter latency.
pub fn afftdn_delay(rate:u32)->Result<u32>{
    if !(7350..=96000).contains(&rate){return Err(Error::Unsupported("denoise sample rate"));}Ok(2*(rate/80))
}
pub fn afftdn_timing_qualified(version:&str)->bool {
    if !version.starts_with("ffmpeg version "){return false;}
    version.split_whitespace().nth(2).is_some_and(|v|v=="7.1"||v.starts_with("7.1.")||v.starts_with("7.1-"))
}
pub(crate) fn number(n:f64)->Result<String>{if !n.is_finite()||n.abs()>1e6{return Err(Error::InvalidInput("nonfinite filter parameter"));}Ok(format!("{n:.9}"))}
pub fn qualified_layout(channels:u32,layout:Option<&str>)->Result<String>{
    let name=match (channels,layout) {(1,None)=>"mono",(2,None)=>"stereo",(_,Some(s))=>s,_=>return Err(Error::Unsupported("explicit multichannel layout required"))};
    let n=match name{"mono"=>1,"stereo"=>2,"2.1"|"3.0"|"3.0(back)"=>3,"4.0"|"quad"|"quad(side)"=>4,"5.0"|"5.0(side)"=>5,"5.1"|"5.1(side)"=>6,"6.1"|"6.1(back)"=>7,"7.1"|"7.1(wide)"|"7.1(wide-side)"=>8,_=>return Err(Error::Unsupported("audio layout not qualified for this profile"))};
    if channels!=n{return Err(Error::InvalidInput("channel count/layout mismatch"));}Ok(name.to_owned())
}

#[derive(Debug,Clone)]
pub struct VoiceScan {
    input:InputFile,stream:u32,rate:u32,channels:u32,origin:Rational,duration:Rational,timeout:Duration,
}
impl VoiceScan {
    pub fn new(project:&Project,input:InputFile,max_seconds:u32,timeout:Duration)->Result<Self>{
        project.validate()?;validate_timeout(timeout)?;
        if max_seconds==0||max_seconds>crate::voice::MAX_SCAN_SECONDS{return Err(Error::InvalidInput("voice scan time limit"));}
        let s=&project.sources[0];s.check_input(&input)?;
        if s.duration>Rational::new(i64::from(max_seconds),1)?{return Err(Error::LimitExceeded("voice scan duration"));}
        let a=s.media.audio.as_ref().ok_or(Error::Unsupported("voice requires selected audio"))?;
        let rate=a.sample_rate.ok_or(Error::InvalidProject("audio rate"))?;let channels=a.channels.ok_or(Error::InvalidProject("audio channels"))?;
        if !(7350..=96000).contains(&rate){return Err(Error::Unsupported("voice sample rate"));}qualified_layout(channels,a.channel_layout.as_deref())?;
        Ok(Self{input,stream:a.index,rate,channels,origin:s.timeline_origin,duration:s.duration,timeout})
    }
    pub fn input(&self)->&InputFile{&self.input}
    pub fn sample_rate(&self)->u32{self.rate}
    pub fn channels(&self)->usize{self.channels as usize}
    pub fn timeout(&self)->Duration{self.timeout}
    pub fn check_runtime(&self,c:&RuntimeCapabilities)->Result<()>{
        if ["asettb","atrim","aformat"].iter().any(|f|!c.filters.contains(*f))||!c.encoders.contains("pcm_f32le")||!c.muxers.contains("f32le") {return Err(Error::MissingCapability("bounded float PCM decode"));}Ok(())
    }
    pub fn arguments(&self)->Result<Vec<OsString>>{
        let start=self.origin.ceil_units(i64::from(self.rate))?;let end=self.origin.checked_add(self.duration)?.ceil_units(i64::from(self.rate))?;
        let filter=format!("asettb=expr=1/{},atrim=start_pts={start}:end_pts={end},aformat=sample_fmts=flt",self.rate);
        let mut a=words(PCM_PREFIX);a.push(self.input.canonical_path.as_os_str().to_owned());
        a.extend(words(&["-map",&format!("0:{}",self.stream),"-vn","-sn","-dn","-filter_threads","1","-af",&filter,"-c:a","pcm_f32le","-threads:a","1","-map_metadata","-1","-f","f32le","pipe:1"]));Ok(a)
    }
}
pub type PcmSink<'a> = dyn FnMut(&[u8])->Result<()>+'a;

/// Extra typed media operations, not arbitrary argv supplied by an extension.
#[derive(Debug,Clone)]
pub enum AudioTask {
    #[cfg(feature="native")]
    EnhanceRnnoise{task:crate::enhancement_native::RnnoiseTask},
    MeasurePlan{input:InputFile,plan:crate::plan::RenderPlan,timeout:Duration},
    MeasureFile{input:InputFile,stream:u32,timeout:Duration},
    RenderStem{input:InputFile,plan:crate::plan::RenderPlan,output:PathBuf,timeout:Duration},
    ProbeStem{input:InputFile},
    ValidateStem{input:InputFile,timeout:Duration},
}
impl AudioTask {
    pub fn additional_input(&self)->Option<&InputFile>{match self{
        #[cfg(feature="native")]
        Self::EnhanceRnnoise{task}=>Some(task.model()),_=>None,
    }}
    pub fn input(&self)->&InputFile{match self{
        #[cfg(feature="native")]
        Self::EnhanceRnnoise{task}=>task.input(),Self::MeasurePlan{input,..}|Self::MeasureFile{input,..}|Self::RenderStem{input,..}|Self::ProbeStem{input}|Self::ValidateStem{input,..}=>input}}
    pub fn timeout(&self)->Duration{match self{
        #[cfg(feature="native")]
        Self::EnhanceRnnoise{task}=>task.timeout(),Self::MeasurePlan{timeout,..}|Self::MeasureFile{timeout,..}|Self::RenderStem{timeout,..}|Self::ValidateStem{timeout,..}=>*timeout,Self::ProbeStem{..}=>Duration::from_secs(30)}}
    pub fn maximum_output_bytes(&self)->Result<Option<u64>>{match self{
        #[cfg(feature="native")]
        Self::EnhanceRnnoise{task}=>Ok(Some(task.maximum_bytes()?)),_=>Ok(None),
    }}
    pub fn measurement(&self)->bool{matches!(self,Self::MeasurePlan{..}|Self::MeasureFile{..})}
    pub fn tool_name(&self)->&'static str{if matches!(self,Self::ProbeStem{..}){"ffprobe"}else{"ffmpeg"}}
    pub fn output(&self)->Option<&Path>{match self{
        Self::RenderStem{output,..}=>Some(output),
        #[cfg(feature="native")]
        Self::EnhanceRnnoise{task}=>Some(task.output()),_=>None,
    }}
    pub fn arguments(&self)->Result<Vec<OsString>>{
        validate_timeout(self.timeout())?;
        #[cfg(feature="native")]
        if let Self::EnhanceRnnoise{task}=self{return task.arguments();}
        if let Self::ProbeStem{input}=self {
            let mut a=words(&["-v","error","-max_alloc","268435456","-protocol_whitelist","file","-format_whitelist","wav","-show_streams","-show_format","-of","json","-i"]);a.push(input.canonical_path.as_os_str().to_owned());return Ok(a);
        }
        let log=if self.measurement(){"info"}else{"error"};
        let mut a=words(&["-hide_banner","-loglevel",log,"-nostdin","-xerror","-max_alloc","268435456","-y","-copyts","-nostats","-threads","2","-protocol_whitelist","file","-format_whitelist","mov,matroska,webm,wav","-i"]);
        a.push(self.input().canonical_path.as_os_str().to_owned());
        let plan_ref=match self{Self::MeasurePlan{plan,..}|Self::RenderStem{plan,..}=>Some(plan),_=>None};
        if let Some(enhanced)=plan_ref.and_then(|p|p.enhanced_audio_path()){a.extend(words(&["-protocol_whitelist","file","-format_whitelist","wav","-i"]));a.push(enhanced.as_os_str().to_owned());}
        match self {
            Self::MeasurePlan{plan,..}=>{
                let graph=plan.voice_audio_graph(false)?.replace("[aout]",&format!(",{MEASURE_FILTER}[ameter]"));
                a.extend(words(&["-filter_complex_threads","1","-filter_complex",&graph,"-map","[ameter]"]));
            },
            Self::MeasureFile{stream,..}=>{a.extend(words(&["-map",&format!("0:{stream}"),"-filter_threads","1","-af",MEASURE_FILTER]));},
            Self::RenderStem{plan,output,..}=>{
                if output==&self.input().canonical_path{return Err(Error::SameFile);}
                let graph=plan.voice_audio_graph(true)?;
                a.extend(words(&["-filter_complex_threads","1","-filter_complex",&graph,"-map","[aout]","-vn","-sn","-dn","-map_metadata","-1","-c:a","pcm_s24le","-threads:a","1","-rf64","auto","-progress","pipe:1","-nostats","-f","wav"]));
                a.push(output.as_os_str().to_owned());check_args(&a)?;return Ok(a);
            },
            Self::ValidateStem{..}=>{a.extend(words(&["-map","0:a:0"]));},Self::ProbeStem{..}=>unreachable!(),
            #[cfg(feature="native")]
            Self::EnhanceRnnoise{..}=>unreachable!(),
        }
        a.extend(words(&["-vn","-sn","-dn","-map_metadata","-1","-c:a","pcm_s16le","-threads:a","1","-f","null","-"]));check_args(&a)?;Ok(a)
    }
}
fn check_args(args:&[OsString])->Result<()>{if args.iter().map(|s|s.as_encoded_bytes().len()+1).sum::<usize>()>30*1024{return Err(Error::LimitExceeded("audio arguments"));}Ok(())}
pub(crate) fn validate_timeout(t:Duration)->Result<()>{if t.is_zero()||t>Duration::from_secs(86400){Err(Error::InvalidInput("audio task deadline"))}else{Ok(())}}
