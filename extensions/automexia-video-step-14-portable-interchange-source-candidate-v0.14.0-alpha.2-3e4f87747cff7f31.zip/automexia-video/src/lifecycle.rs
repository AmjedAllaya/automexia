//! Single ownership point for admission, lifetime cancellation and drain.
//! Private to Video: no scheduler, thread pool, permissions or host globals.
use crate::{Cancellation, Error, Result};
use std::{collections::BTreeMap, sync::{Condvar, Mutex}, time::{Duration, Instant}};

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct DrainStatus {
    /// All admitted core operations returned. Player/host handles are separate.
    pub complete: bool,
    pub remaining_jobs: usize,
    pub remaining_workflows: usize,
}
struct State {
    enabled: bool,
    draining: bool,
    next: u64,
    lifetime: Cancellation,
    active: BTreeMap<u64, Cancellation>,
    workflows: BTreeMap<u64, Cancellation>,
}
pub(crate) struct JobRegistry {
    limit: usize,
    state: Mutex<State>,
    changed: Condvar,
}
pub(crate) struct WorkflowPermit<'a> {
    owner: &'a JobRegistry, id: u64, pub(crate) cancel: Cancellation,
}
pub(crate) struct Permit<'a> {
    owner: &'a JobRegistry,
    id: u64,
    pub(crate) cancel: Cancellation,
}
impl JobRegistry {
    pub(crate) fn new(limit: usize) -> Self {
        Self { limit, state: Mutex::new(State { enabled: true, draining: false,
            next: 1, lifetime: Cancellation::new(), active: BTreeMap::new(), workflows: BTreeMap::new() }),
            changed: Condvar::new() }
    }
    pub(crate) fn begin(&self, parent: &Cancellation) -> Result<Permit<'_>> {
        parent.check()?;
        let mut s = self.state.lock().map_err(|_| Error::Poisoned)?;
        if !s.enabled { return Err(Error::Disabled); }
        if s.draining || s.active.len() >= self.limit { return Err(Error::Busy); }
        let next = s.next.checked_add(1).ok_or(Error::LimitExceeded("job identifiers"))?;
        let cancel = parent.linked(&s.lifetime)?;
        cancel.check()?;
        let id = s.next;
        s.active.insert(id, cancel.clone());
        s.next = next;
        Ok(Permit { owner: self, id, cancel })
    }
    pub(crate) fn workflow(&self, parent:&Cancellation)->Result<WorkflowPermit<'_>> {
        parent.check()?;
        let mut s=self.state.lock().map_err(|_|Error::Poisoned)?;
        if !s.enabled {return Err(Error::Disabled);}
        if s.draining || s.workflows.len()>=self.limit {return Err(Error::Busy);}
        let next=s.next.checked_add(1).ok_or(Error::LimitExceeded("job identifiers"))?;
        let cancel=parent.linked(&s.lifetime)?;cancel.check()?;
        let id=s.next;s.next=next;s.workflows.insert(id,cancel.clone());
        Ok(WorkflowPermit{owner:self,id,cancel})
    }
    pub(crate) fn scope(&self, parent: &Cancellation) -> Result<Cancellation> {
        let s = self.state.lock().map_err(|_| Error::Poisoned)?;
        if !s.enabled { return Err(Error::Disabled); }
        if s.draining { return Err(Error::Busy); }
        parent.check()?;
        parent.linked(&s.lifetime)
    }
    pub(crate) fn snapshot(&self) -> Result<(bool, usize)> {
        let s = self.state.lock().map_err(|_| Error::Poisoned)?;
        Ok((s.enabled, s.active.len()))
    }
    pub(crate) fn enable(&self) -> Result<()> {
        let mut s = self.state.lock().map_err(|_| Error::Poisoned)?;
        if s.draining || (!s.enabled && (!s.active.is_empty() || !s.workflows.is_empty())) { return Err(Error::Busy); }
        if !s.enabled { s.lifetime = Cancellation::new(); }
        s.enabled = true;
        Ok(())
    }
    pub(crate) fn disable(&self) -> Result<()> {
        let mut s = self.state.lock().map_err(|_| Error::Poisoned)?;
        s.enabled = false;
        cancel_state(&s);
        self.changed.notify_all();
        Ok(())
    }
    pub(crate) fn cancel_all(&self) -> Result<()> {
        let mut s = self.state.lock().map_err(|_| Error::Poisoned)?;
        cancel_state(&s);
        // Old scopes retain the cancelled signal; replacement never revives them.
        s.lifetime = Cancellation::new();
        self.changed.notify_all();
        Ok(())
    }
    /// Call from a host lifecycle worker, never from an active Video callback.
    /// A zero duration disables and polls once. Timeout leaves Video disabled.
    pub(crate) fn drain(&self, timeout: Duration) -> Result<DrainStatus> {
        if timeout > Duration::from_secs(86_400) {
            return Err(Error::InvalidInput("drain timeout exceeds one day"));
        }
        let start = Instant::now();
        let mut s = self.state.lock().map_err(|_| Error::Poisoned)?;
        if s.draining { return Err(Error::Busy); }
        s.enabled = false;
        s.draining = true;
        cancel_state(&s);
        while !s.active.is_empty() || !s.workflows.is_empty() {
            let remaining = timeout.saturating_sub(start.elapsed());
            if remaining.is_zero() { break; }
            match self.changed.wait_timeout(s, remaining) {
                Ok((next, _)) => s = next,
                Err(poisoned) => {
                    let (mut state, _) = poisoned.into_inner();
                    state.draining = false;
                    return Err(Error::Poisoned);
                }
            }
        }
        let remaining_jobs = s.active.len();
        let remaining_workflows=s.workflows.len();
        s.draining = false;
        self.changed.notify_all();
        Ok(DrainStatus { complete: remaining_jobs == 0 && remaining_workflows == 0, remaining_jobs, remaining_workflows })
    }
}
fn cancel_state(s: &State) {
    s.lifetime.cancel();
    for token in s.active.values().chain(s.workflows.values()) { token.cancel(); }
}
impl Drop for Permit<'_> {
    fn drop(&mut self) {
        // Poison must not strand admission slots during exception unwinding.
        let mut s = self.owner.state.lock().unwrap_or_else(|p| p.into_inner());
        self.cancel.cancel();
        s.active.remove(&self.id);
        self.owner.changed.notify_all();
    }
}
impl Drop for WorkflowPermit<'_> {
    fn drop(&mut self) {
        let mut s=self.owner.state.lock().unwrap_or_else(|p|p.into_inner());
        self.cancel.cancel();s.workflows.remove(&self.id);self.owner.changed.notify_all();
    }
}
impl Drop for JobRegistry {
    fn drop(&mut self) {
        let s = self.state.get_mut().unwrap_or_else(|p| p.into_inner());
        s.enabled = false;
        cancel_state(s);
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test] fn limit_is_released_by_raii() { let r=JobRegistry::new(1); let p=r.begin(&Cancellation::new()).unwrap(); assert!(matches!(r.begin(&Cancellation::new()),Err(Error::Busy))); drop(p); assert!(r.begin(&Cancellation::new()).is_ok()); }
    #[test] fn disabled_scope_cannot_revive() {let r=JobRegistry::new(1);let s=r.scope(&Cancellation::new()).unwrap();r.disable().unwrap();r.enable().unwrap();assert!(s.is_cancelled());}
    #[test] fn drain_poll_does_not_claim_worker_completion() {let r=JobRegistry::new(1);let p=r.begin(&Cancellation::new()).unwrap();let d=r.drain(Duration::ZERO).unwrap();assert!(!d.complete);assert_eq!(d.remaining_jobs,1);assert!(p.cancel.is_cancelled());assert!(matches!(r.enable(),Err(Error::Busy)));drop(p);assert!(r.drain(Duration::ZERO).unwrap().complete);r.enable().unwrap();}
    #[test] fn cancel_all_leaves_new_generation_enabled() {let r=JobRegistry::new(2);let p=r.begin(&Cancellation::new()).unwrap();r.cancel_all().unwrap();assert!(p.cancel.is_cancelled());let q=r.begin(&Cancellation::new()).unwrap();assert!(!q.cancel.is_cancelled());}
    #[test] fn dropping_permit_cancels_linked_work() {let r=JobRegistry::new(1);let p=r.begin(&Cancellation::new()).unwrap();let child=p.cancel.child().unwrap();drop(p);assert!(child.is_cancelled());}
    #[test] fn drain_waits_for_admitted_work() {let r=JobRegistry::new(1);std::thread::scope(|s| {let p=r.begin(&Cancellation::new()).unwrap();s.spawn(move||{while !p.cancel.is_cancelled(){std::thread::yield_now();}drop(p);});let d=r.drain(Duration::from_secs(2)).unwrap();assert!(d.complete);});}
    #[test] fn cancelled_parent_cannot_consume_slot() {let r=JobRegistry::new(1);let c=Cancellation::new();c.cancel();assert!(matches!(r.begin(&c),Err(Error::Cancelled)));assert_eq!(r.snapshot().unwrap().1,0);}
    #[test] fn id_exhaustion_is_atomic() {let r=JobRegistry::new(1);r.state.lock().unwrap().next=u64::MAX;assert!(matches!(r.begin(&Cancellation::new()),Err(Error::LimitExceeded(_))));assert_eq!(r.snapshot().unwrap().1,0);}
    #[test] fn invalid_drain_does_not_disable() {let r=JobRegistry::new(1);assert!(r.drain(Duration::from_secs(86_401)).is_err());assert!(r.snapshot().unwrap().0);}
    #[test] fn workflow_between_stages_prevents_false_drain() {let r=JobRegistry::new(1);let p=r.workflow(&Cancellation::new()).unwrap();let d=r.drain(Duration::ZERO).unwrap();assert!(!d.complete);assert_eq!(d.remaining_jobs,0);assert_eq!(d.remaining_workflows,1);assert!(p.cancel.is_cancelled());assert!(r.enable().is_err());drop(p);assert!(r.drain(Duration::ZERO).unwrap().complete);}
    #[test] fn workflow_can_admit_its_child_stage() {let r=JobRegistry::new(1);let w=r.workflow(&Cancellation::new()).unwrap();let child=r.begin(&w.cancel).unwrap();assert!(!child.cancel.is_cancelled());assert!(matches!(r.workflow(&Cancellation::new()),Err(Error::Busy)));}
    #[test] fn registry_drop_cancels_unadmitted_scopes() {let token={let r=JobRegistry::new(1);r.scope(&Cancellation::new()).unwrap()};assert!(token.is_cancelled());}
}
