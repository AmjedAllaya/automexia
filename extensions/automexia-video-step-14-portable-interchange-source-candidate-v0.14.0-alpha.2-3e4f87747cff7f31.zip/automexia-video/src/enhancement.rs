//! Step 13C: optional local speech enhancement.
//! Models/providers process audio; project decisions remain explicit and portable.

use crate::{Cancellation, Error, Result, Rational};
use crate::host::{FileStamp, InputFile, ProgressSink};
use crate::project::relative_reference;
use serde::{Deserialize, Serialize};
use std::path::{Path, PathBuf};

pub const ENHANCEMENT_VERSION:u32=1;
pub const MAX_WARNINGS:usize=32;

#[derive(Debug,Clone,Copy,PartialEq,Eq,Serialize,Deserialize)]
#[serde(rename_all="snake_case")]
pub enum EnhancementMode { Preserve, Traditional, Learned }

#[derive(Debug,Clone,Copy,PartialEq,Eq,Serialize,Deserialize)]
#[serde(rename_all="snake_case")]
pub enum EnhancementStrength { Gentle, Balanced, Strong }

#[derive(Debug,Clone,PartialEq,Serialize,Deserialize)]
#[serde(deny_unknown_fields)]
pub struct EnhancementSettings {
    pub mode:EnhancementMode,
    pub strength:EnhancementStrength,
    pub speech_only_confirmed:bool,
    pub max_delay_samples:u32,
}
impl Default for EnhancementSettings {
    fn default()->Self { Self{mode:EnhancementMode::Preserve,strength:EnhancementStrength::Balanced,speech_only_confirmed:false,max_delay_samples:0} }
}
impl EnhancementSettings {
    pub fn validate(&self)->Result<()> {
        if self.max_delay_samples>48_000{return Err(Error::InvalidInput("enhancer delay bound"));}
        if self.mode==EnhancementMode::Learned&&!self.speech_only_confirmed{return Err(Error::InvalidInput("learned speech enhancement requires explicit speech-only confirmation"));}
        Ok(())
    }
}

#[derive(Debug,Clone,PartialEq,Eq,Serialize,Deserialize)]
#[serde(deny_unknown_fields)]
pub struct EnhancementIdentity {
    pub engine:String,pub engine_version:String,pub runtime:String,
    pub model_id:Option<String>,pub model_sha256:Option<String>,
}
impl EnhancementIdentity {
    pub fn validate(&self)->Result<()> {
        for s in [&self.engine,&self.engine_version,&self.runtime]{crate::project::text_ok(s,128)?;if s.is_empty(){return Err(Error::InvalidInput("enhancer identity"));}}
        if let Some(id)=&self.model_id{crate::project::text_ok(id,128)?;if id.is_empty(){return Err(Error::InvalidInput("enhancer model id"));}}
        if let Some(h)=&self.model_sha256{if h.len()!=64||!h.bytes().all(|b|b.is_ascii_hexdigit()){return Err(Error::InvalidInput("enhancer model digest"));}}
        if self.model_id.is_some()!=self.model_sha256.is_some(){return Err(Error::InvalidInput("enhancer model identity incomplete"));}
        Ok(())
    }
}

#[derive(Debug,Clone,PartialEq,Serialize,Deserialize)]
#[serde(deny_unknown_fields)]
pub struct EnhancementReceipt {
    pub identity:EnhancementIdentity,pub sample_rate:u32,pub channels:u32,pub channel_layout:String,
    pub source_samples:u64,pub output_samples:u64,pub delay_samples:i64,pub peak_dbfs:Option<f64>,pub warnings:Vec<String>,
}
impl EnhancementReceipt {
    pub fn validate(&self,settings:&EnhancementSettings)->Result<()> {
        settings.validate()?;self.identity.validate()?;
        if settings.mode==EnhancementMode::Learned&&self.identity.model_id.is_none(){return Err(Error::InvalidOutput("learned enhancement requires pinned model identity"));}
        if !(8_000..=96_000).contains(&self.sample_rate)||self.channels==0||self.channels>8||self.source_samples==0||self.output_samples==0||self.warnings.len()>MAX_WARNINGS{return Err(Error::InvalidOutput("enhancer receipt dimensions"));}
        crate::voice_render::qualified_layout(self.channels,Some(&self.channel_layout))?;
        for w in &self.warnings{crate::project::text_ok(w,512)?;}
        if self.delay_samples.unsigned_abs()>u64::from(settings.max_delay_samples){return Err(Error::InvalidOutput("enhancer delay exceeds accepted bound"));}
        let expected=i128::from(self.source_samples)+i128::from(self.delay_samples);
        if expected<1||i128::from(self.output_samples)!=expected{return Err(Error::InvalidOutput("enhancer sample count does not match declared delay"));}
        if self.peak_dbfs.is_some_and(|v|!v.is_finite()||!(-1000.0..=6.0).contains(&v)){return Err(Error::InvalidOutput("enhancer peak"));}
        Ok(())
    }
}

#[derive(Debug,Clone,Serialize,Deserialize)]
#[serde(deny_unknown_fields)]
pub struct VoiceEnhancement {
    pub version:u32,pub source_sha256:String,pub source_stream:u32,pub settings:EnhancementSettings,pub receipt:EnhancementReceipt,
    /// Original selected-video origin. Schema-8 receipts omitted this field;
    /// they remain readable, but new stems always record the explicit origin.
    #[serde(default,skip_serializing_if="Option::is_none")]
    pub source_origin:Option<Rational>,
    pub stem_path:PathBuf,pub stem_stamp:FileStamp,
}
impl VoiceEnhancement {
    pub fn validate(&self)->Result<()> {
        if self.version!=ENHANCEMENT_VERSION||self.source_sha256.len()!=64||!self.source_sha256.bytes().all(|b|b.is_ascii_hexdigit()){return Err(Error::InvalidProject("enhancement source/version"));}
        self.settings.validate()?;self.receipt.validate(&self.settings)?;
        if self.stem_stamp.sha256.len()!=64||!self.stem_stamp.sha256.bytes().all(|b|b.is_ascii_hexdigit())||self.stem_stamp.size==0{return Err(Error::InvalidProject("enhanced stem fingerprint"));}
        if self.stem_path.as_os_str().is_empty()||self.stem_path.components().any(|c|matches!(c,std::path::Component::ParentDir)){return Err(Error::InvalidProject("enhanced stem path"));}
        if self.settings.mode==EnhancementMode::Preserve{return Err(Error::InvalidProject("preserve mode must not persist an enhanced stem"));}
        Ok(())
    }
    pub fn check_source(&self,source:&crate::project::ProjectSource)->Result<()> {
        self.validate()?;
        let audio=source.media.audio.as_ref().ok_or(Error::InvalidProject("enhancement without selected audio"))?;
        let rate=audio.sample_rate.ok_or(Error::InvalidProject("enhancement sample rate"))?;
        let channels=audio.channels.ok_or(Error::InvalidProject("enhancement channels"))?;
        let layout=crate::voice_render::qualified_layout(channels,audio.channel_layout.as_deref())?;
        let samples=u64::try_from(source.duration.ceil_units(i64::from(rate))?).map_err(|_|Error::InvalidProject("enhancement source sample count"))?;
        if self.source_sha256!=source.fingerprint.sha256 || self.source_stream!=audio.index
            || self.receipt.sample_rate!=rate || self.receipt.channels!=channels
            || self.receipt.channel_layout!=layout || self.receipt.source_samples!=samples
            || self.receipt.output_samples!=samples || self.receipt.delay_samples!=0
            || self.source_origin.is_some_and(|origin|origin!=source.timeline_origin) {
            return Err(Error::InvalidProject("enhancement source clock, identity, or format differs"));
        }
        Ok(())
    }
    pub fn resolve(&self,project_file:&Path)->Result<PathBuf>{self.validate()?;if self.stem_path.is_absolute(){Ok(self.stem_path.clone())}else{Ok(project_file.parent().ok_or(Error::InvalidProject("project parent"))?.join(&self.stem_path))}}
    pub fn check_input(&self,input:&InputFile)->Result<()> {
        if input.stamp.size!=self.stem_stamp.size||input.stamp.sha256!=self.stem_stamp.sha256{return Err(Error::InputChanged);}
        Ok(())
    }
    pub fn rebase(&mut self,old_project:&Path,new_project:&Path)->Result<()>{let resolved=self.resolve(old_project)?;self.stem_path=relative_reference(&resolved,new_project)?;self.validate()}
}

#[derive(Debug,Clone)]
pub struct EnhancementRequest {
    pub source:InputFile,pub stream_index:u32,pub sample_rate:u32,pub channels:u32,pub channel_layout:String,pub source_samples:u64,
    pub settings:EnhancementSettings,pub staged_output:PathBuf,pub source_origin:Rational,pub timeout:std::time::Duration,
}
impl EnhancementRequest {
    pub fn validate(&self)->Result<()> {
        self.settings.validate()?;crate::voice_render::validate_timeout(self.timeout)?;
        if self.source_samples>u64::from(self.sample_rate)*86_400{return Err(Error::LimitExceeded("enhancer source duration"));}
        if self.staged_output==self.source.canonical_path{return Err(Error::SameFile);}
        if self.settings.mode==EnhancementMode::Preserve{return Err(Error::InvalidInput("preserve does not invoke enhancement"));}
        if !self.staged_output.is_absolute()||!self.staged_output.extension().and_then(|s|s.to_str()).is_some_and(|s|s.eq_ignore_ascii_case("wav")){return Err(Error::InvalidInput("enhancer requires an absolute staged .wav"));}
        if !(8_000..=96_000).contains(&self.sample_rate)||self.channels==0||self.channels>8||self.source_samples==0{return Err(Error::InvalidInput("enhancer source dimensions"));}
        crate::voice_render::qualified_layout(self.channels,Some(&self.channel_layout))?;Ok(())
    }
}

pub trait SpeechEnhancer:Send+Sync {
    fn identity(&self)->Result<EnhancementIdentity>;
    /// Recheck the provider's activation and immutable selected model/runtime.
    /// Implementations must cooperate with cancellation and the request deadline.
    fn revalidate(&self,cancel:&Cancellation)->Result<()> {cancel.check()?;self.identity()?.validate()}
    fn enhance(&self,request:&EnhancementRequest,cancel:&Cancellation,progress:&mut ProgressSink<'_>)->Result<EnhancementReceipt>;
}

pub fn validate_enhanced_media(media:&crate::media::MediaInfo,receipt:&EnhancementReceipt,source_duration:Rational)->Result<()> {
    if media.streams.len()!=1||!media.format_names.iter().any(|name|name=="wav") {
        return Err(Error::InvalidOutput("enhanced stem must contain exactly one audio stream in WAV"));
    }
    let a=&media.streams[0];
    if a.kind!="audio"||a.codec.as_deref()!=Some("pcm_s24le") {
        return Err(Error::InvalidOutput("enhanced stem must be PCM24 WAV"));
    }
    if a.sample_rate!=Some(receipt.sample_rate)||a.channels!=Some(receipt.channels)
        ||crate::voice_render::qualified_layout(receipt.channels,a.channel_layout.as_deref())?!=receipt.channel_layout {
        return Err(Error::InvalidOutput("enhanced stem audio properties"));
    }
    let duration=a.exact_duration().or(media.duration).ok_or(Error::InvalidOutput("enhanced stem duration"))?;
    let expected=Rational::new(i64::try_from(receipt.output_samples).map_err(|_|Error::LimitExceeded("enhanced samples"))?,i64::from(receipt.sample_rate))?;
    if duration!=expected||a.exact_start().or(media.start_time).is_some_and(|start|start!=Rational::new(0,1).expect("zero")) {
        return Err(Error::InvalidOutput("enhanced stem must have exact sample count and zero origin"));
    }
    if receipt.delay_samples!=0||receipt.source_samples!=receipt.output_samples
        ||expected.checked_sub(source_duration)?<Rational::new(0,1)?
        ||expected.checked_sub(source_duration)? >= Rational::new(1,i64::from(receipt.sample_rate))? {
        return Err(Error::InvalidOutput("enhanced stem duration differs from source sample clock"));
    }
    Ok(())
}
