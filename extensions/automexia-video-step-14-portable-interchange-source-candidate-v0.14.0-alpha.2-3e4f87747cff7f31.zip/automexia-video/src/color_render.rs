//! Compile reviewed shot corrections before timeline selection/time remapping.
//! FFmpeg does the pixel work; paths never appear in a filter expression.
use crate::{Error, Rational, Result};
use crate::color::{ColorProfile,ColorAdjustment,qualify_sdr};
use crate::host::RuntimeCapabilities;
use crate::project::Project;
use serde::Serialize;

// Literal templates are also read by the independent media harness. That harness
// tests media math/FFmpeg, not execution of this Rust module.
pub const COLOR_LINEAR_IN:&str="zscale=pin=bt709:tin=bt709:min=bt709:rin={range}:p=bt709:t=linear:m=gbr:r=full,format=gbrpf32le";
pub const COLOR_LINEAR_OUT:&str="zscale=pin=bt709:tin=linear:min=gbr:rin=full:p=bt709:t=bt709:m=bt709:r=full,format=yuv444p";
pub const COLOR_ENCODED_IN:&str="scale=in_range={range}:out_range=pc,format=yuv444p";
pub const COLOR_RANGE_OUT:&str="scale=in_range=pc:out_range={range},format=yuv420p";
pub const COLOR_EXPOSURE:&str="exposure=exposure={ev}:black=0:enable='{when}'";
pub const COLOR_BALANCE:&str="colorchannelmixer=rr={r}:gg={g}:bb={b}:enable='{when}'";
pub const COLOR_TONE:&str="eq=gamma={gamma}:gamma_weight=0.5:contrast={contrast}:saturation={saturation}:enable='{when}'";
pub const MAX_COLOR_FILTER_BYTES:usize=24*1024;
// Leave ample floating-point headroom for FFmpeg's t -> source-tick conversion.
pub const MAX_COLOR_ENABLE_TICKS:u64=1u64<<46;

#[derive(Debug,Clone,Serialize)]
pub struct ColorRender {pub(crate) profile:ColorProfile,origin:Rational,time_base:Rational,full_range:bool}
impl ColorRender {
    pub fn from_project(project:&Project,runtime:&RuntimeCapabilities)->Result<Option<Self>> {
        let Some(profile)=project.settings.color_correction.as_ref() else{return Ok(None)};
        profile.check_source(project)?;profile.ensure_resolved()?;
        if profile.active_count()==0 {return Ok(None);}
        let v=&project.sources[0].media.video;qualify_sdr(v)?;
        for name in ["scale","format","eq"] {
            if !runtime.filters.contains(name){return Err(Error::MissingCapability("color tone/range filters"));}
        }
        if profile.shots.iter().filter(|s|s.active()).any(|s|needs_linear(s.adjustment)) {
            for name in ["zscale","exposure","colorchannelmixer"] {
                if !runtime.filters.contains(name){return Err(Error::MissingCapability("linear-light exposure/white-balance filters"));}
            }
        }
        let render=Self{profile:profile.clone(),origin:project.sources[0].timeline_origin,
            time_base:v.time_base.ok_or(Error::InvalidProject("color time base"))?,full_range:v.color_range.as_deref()==Some("pc")};
        render.filter_chain()?;Ok(Some(render))
    }
    pub fn profile(&self)->&ColorProfile{&self.profile}
    pub fn filter_chain(&self)->Result<String> {
        self.profile.validate()?;self.profile.ensure_resolved()?;
        let shots:Vec<_>=self.profile.shots.iter().filter(|s|s.active()).collect();
        if shots.is_empty(){return Ok(String::new());}
        let linear=shots.iter().any(|s|needs_linear(s.adjustment));
        let range=if self.full_range{"full"}else{"limited"};
        let mut filters=vec![if linear {COLOR_LINEAR_IN.replace("{range}",range)}else{COLOR_ENCODED_IN.replace("{range}",if self.full_range{"pc"}else{"tv"})}];
        if linear {
            for shot in &shots {
                let a=shot.adjustment;let when=self.predicate(shot.range.start,shot.range.end)?;
                if a.exposure_ev!=0.0 {filters.push(COLOR_EXPOSURE.replace("{ev}",&number(a.exposure_ev)).replace("{when}",&when));}
                if a.white_balance!=[1.0;3] {filters.push(COLOR_BALANCE.replace("{r}",&number(a.white_balance[0]))
                    .replace("{g}",&number(a.white_balance[1])).replace("{b}",&number(a.white_balance[2])).replace("{when}",&when));}
            }
            filters.push(COLOR_LINEAR_OUT.into());
        }
        for shot in &shots {
            let a=shot.adjustment;
            if a.gamma!=1.0||a.contrast!=1.0||a.saturation!=1.0 {
                filters.push(COLOR_TONE.replace("{gamma}",&number(a.gamma)).replace("{contrast}",&number(a.contrast))
                    .replace("{saturation}",&number(a.saturation)).replace("{when}",&self.predicate(shot.range.start,shot.range.end)?));
            }
        }
        filters.push(COLOR_RANGE_OUT.replace("{range}",if self.full_range{"pc"}else{"tv"}));
        let chain=filters.join(",");
        if chain.len()>MAX_COLOR_FILTER_BYTES {return Err(Error::LimitExceeded("shot color filter graph; reduce active shot count"));}Ok(chain)
    }
    fn predicate(&self,start:Rational,end:Rational)->Result<String> {
        let start=self.origin.checked_add(start)?.checked_div(self.time_base)?.ceil_units(1)?;
        let end=self.origin.checked_add(end)?.checked_div(self.time_base)?.ceil_units(1)?;
        if [start,end].iter().any(|x|x.unsigned_abs()>MAX_COLOR_ENABLE_TICKS){return Err(Error::Unsupported("color timestamp exceeds exact filter range"));}
        // Timeline enable exposes seconds, not PTS. Round back to the original
        // tick domain to preserve half-open frame boundaries at fractional rates.
        let t=format!("round(t*{}/{})",self.time_base.denominator(),self.time_base.numerator());
        Ok(format!("gte({t},{start})*lt({t},{end})"))
    }
}
fn needs_linear(a:ColorAdjustment)->bool{a.exposure_ev!=0.0||a.white_balance!=[1.0;3]}
fn number(v:f64)->String{format!("{v:.6}")}
