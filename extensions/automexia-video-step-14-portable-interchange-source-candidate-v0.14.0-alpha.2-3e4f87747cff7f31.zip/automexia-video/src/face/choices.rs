use super::*;
use crate::placement::{self,PlacementTarget};
pub type FaceAnchorTarget=PlacementTarget;
#[derive(Debug,Clone,Serialize)]pub struct FaceAnchorChoice{pub target:FaceAnchorTarget,pub anchor:Anchor}
#[derive(Debug,Clone,Serialize)]pub struct FacePunchInChoice{pub range:TimeRange,pub zoom:f64}
#[derive(Debug,Clone,Serialize)]pub struct FaceApplyChoices{pub adopt_framing:bool,pub anchors:Vec<FaceAnchorChoice>,pub punch_ins:Vec<FacePunchInChoice>}
impl Default for FaceApplyChoices{fn default()->Self{Self{adopt_framing:true,anchors:vec![],punch_ins:vec![]}}}
impl FaceFramingReport{
    pub fn apply_choices(&self,project:&mut Project,activation:&ModelActivation,choices:&FaceApplyChoices)->Result<()>{
        self.owner.check()?;self.activation.check()?;activation.check()?;
        if activation.identity()!=self.activation.identity()||project.decision_digest()?!=self.binding{return Err(Error::InputChanged);}
        if choices.anchors.len()>65||choices.punch_ins.len()>16||(!choices.adopt_framing&&!choices.punch_ins.is_empty())||(!choices.adopt_framing&&choices.anchors.is_empty()){return Err(Error::InvalidInput("face choice count or framing selection"));}
        // Never treat mutable UI diagnostics as authority. Rebuild from immutable
        // sampled observations and the complete original project fingerprint.
        let trusted=build_report(project,&self.original_variant,self.original_samples.clone(),self.original_settings.clone(),&self.activation)?;
        let variant=project.variant(&self.original_variant)?;let source=&project.sources[0];
        let mut framing=if choices.adopt_framing{trusted.proposed.clone()}else{variant.framing.clone().ok_or(Error::InvalidProject("face target framing"))?};
        if !choices.adopt_framing&&(!framing.enabled||framing.disposition==Disposition::Ignore){return Err(Error::InvalidInput("face anchors require the displayed framing to be enabled"));}
        if choices.adopt_framing&&variant.framing.as_ref().is_some_and(|f|f.locked){return Err(Error::LockedEdit);}
        let mut selected=BTreeSet::new();for punch in &choices.punch_ins{
            if !finite(punch.zoom,1.0,1.08)||punch.zoom<=1.0||!trusted.safe_punch_in_ranges.contains(&punch.range)||!selected.insert(punch.range.start){return Err(Error::InvalidInput("unqualified face punch-in"));}
            let FramingMode::Crop{track}=&mut framing.mode else{return Err(Error::InvalidInput("punch-in needs crop framing"))};
            let shot=track.shots.iter_mut().find(|s|s.range==punch.range).ok_or(Error::InvalidInput("face punch-in shot"))?;
            for k in &mut shot.keyframes{k.pose.zoom*=punch.zoom;}
        }
        framing.validate(source)?;
        let all=all_observations(project,&self.original_samples,&self.original_settings)?;
        let suggestions=avoidance(project,&self.original_variant,&framing,&all)?;
        let mut presentation=variant.presentation.clone();let mut targets=BTreeSet::new();
        for choice in &choices.anchors{
            if !targets.insert(&choice.target){return Err(Error::InvalidInput("duplicate face anchor choice"));}
            let relevant=suggestions.iter().filter(|s|s.target==choice.target).collect::<Vec<_>>();
            if relevant.is_empty()||relevant.iter().any(|s|!s.anchors.contains(&choice.anchor)){return Err(Error::InvalidInput("anchor is not safe throughout its visible shots"));}
            let p=presentation.as_mut().ok_or(Error::InvalidProject("face placement settings"))?;if p.locked{return Err(Error::LockedEdit);}placement::set_anchor(p,&choice.target,choice.anchor)?;
        }
        if !choices.anchors.is_empty(){let after=presentation.as_mut().unwrap();let safe=placement::merged_safe_zone(after.safe_zone,framing.safe_zone);let mut after_layout=after.clone();after_layout.safe_zone=safe;let mut before_layout=variant.presentation.as_ref().unwrap().clone();before_layout.safe_zone=safe;after_layout.validate_layout(framing.target)?;placement::reject_new_collisions(&before_layout,&after_layout,framing.target)?;after.disposition=Disposition::NeedsReview;}
        self.owner.check()?;self.activation.check()?;activation.check()?;
        project.edit(|p|{let v=p.variants.iter_mut().find(|v|v.id==self.original_variant).ok_or(Error::InputChanged)?;if choices.adopt_framing{framing.disposition=Disposition::NeedsReview;v.framing=Some(framing);}if !choices.anchors.is_empty(){v.presentation=presentation;}Ok(())})
    }
}
pub(super) fn all_observations(project:&Project,samples:&[FaceSample],settings:&FaceSettings)->Result<Vec<(TimeRange,Vec<Obs>,usize)>>{
    Ok(shot_ranges(project)?.into_iter().map(|shot|{let obs=samples.iter().filter(|s|shot.contains(s.at)).flat_map(|s|s.detections.iter().filter(|d|d.confidence>=settings.min_confidence).map(move |d|Obs{at:s.at,rect:d.rect,confidence:d.confidence})).collect();(shot,obs,0)}).collect())
}
pub(super) fn avoidance(project:&Project,variant:&str,framing:&FramingSettings,selected:&[(TimeRange,Vec<Obs>,usize)])->Result<Vec<FaceAvoidanceSuggestion>>{
    let Some(s)=&project.variant(variant)?.presentation else{return Ok(vec![])};
    let layers=placement::layers(s);let safe_zone=placement::merged_safe_zone(s.safe_zone,framing.safe_zone);let source=&project.sources[0];let mut out=vec![];
    for (shot,obs,_) in selected{for layer in &layers{
        if !layer.ranges.iter().any(|r|r.start<shot.end&&shot.start<r.end){continue;}
        let observations=obs.iter().filter(|o|layer.ranges.iter().any(|r|r.contains(o.at))).collect::<Vec<_>>();let mut anchors=vec![];
        if !observations.is_empty(){for anchor in Anchor::all(){let Ok(envelope)=placement::envelope(layer,anchor,framing.target,safe_zone)else{continue;};let mut safe=true;
            for o in &observations{let geometry=framing.geometry_at(source,o.at)?;let obstacle=if let Some(crop)=actual_crop(framing,&geometry){map_to_output(o.rect,crop,framing.target)?}else{map_fit_to_output(o.rect,geometry.content,framing.target)?};if placement::overlap(envelope,obstacle){safe=false;break;}}
            if safe{anchors.push(anchor);}
        }}
        let layer_id=match &layer.target{PlacementTarget::Overlay(id)=>id.clone(),PlacementTarget::Captions=>"captions".into()};
        out.push(FaceAvoidanceSuggestion{shot:*shot,layer_id,target:layer.target.clone(),anchors});
    }}Ok(out)
}
pub(crate) fn actual_crop(framing:&FramingSettings,g:&crate::reframe::FrameGeometry)->Option<DisplayRect>{
    if matches!(&framing.mode,FramingMode::Crop{track} if track.has_varying_zoom()){return g.desired_crop;}
    g.crop.map(|c|DisplayRect{x:f64::from(c.x)/f64::from(g.scaled_width),y:f64::from(c.y)/f64::from(g.scaled_height),width:f64::from(c.width)/f64::from(g.scaled_width),height:f64::from(c.height)/f64::from(g.scaled_height)})
}
pub(super) fn safe_punch_ranges(project:&Project,framing:&FramingSettings,selected:&[(TimeRange,Vec<Obs>,usize)],samples:&[FaceSample],settings:&FaceSettings)->Result<Vec<TimeRange>>{
    let source=&project.sources[0];let interval=Rational::new(i64::from(settings.sample_interval_ms),1000)?;let mut result=vec![];
    for (shot,obs,n) in selected{
        if *n!=1||obs.len()<settings.min_track_samples as usize||shot.duration()?<Rational::new(1,1)?{continue;}
        let sampled=samples.iter().filter(|s|shot.contains(s.at)).collect::<Vec<_>>();
        if sampled.is_empty()||sampled[0].at>shot.start.checked_add(interval)?||sampled.last().unwrap().at.checked_add(interval)?<shot.end||sampled.iter().any(|s|s.detections.iter().filter(|d|d.confidence>=settings.min_confidence).count()!=1)||sampled.windows(2).any(|w|w[1].at.checked_sub(w[0].at).is_ok_and(|d|d>interval.checked_mul(Rational::new(2,1).unwrap()).unwrap())){continue;}
        let mut candidate=framing.clone();let FramingMode::Crop{track}=&mut candidate.mode else{continue};let Some(target)=track.shots.iter_mut().find(|s|s.range==*shot)else{continue};for k in &mut target.keyframes{k.pose.zoom*=1.08;}
        if candidate.validate(source).is_err(){continue;}
        let mut safe=true;for o in obs{let g=candidate.geometry_at(source,o.at)?;let Some(crop)=actual_crop(&candidate,&g)else{safe=false;break};let inner=expand(o.rect,settings.face_margin,settings.headroom);let safezone=candidate.safe_zone.pixels(candidate.target)?;let allowed=DisplayRect{x:crop.x+crop.width*f64::from(safezone.x)/f64::from(candidate.target.width),y:crop.y+crop.height*f64::from(safezone.y)/f64::from(candidate.target.height),width:crop.width*f64::from(safezone.width)/f64::from(candidate.target.width),height:crop.height*f64::from(safezone.height)/f64::from(candidate.target.height)};if !contains(inner,allowed){safe=false;break;}}
        if safe{result.push(*shot);}
    }Ok(result)
}
