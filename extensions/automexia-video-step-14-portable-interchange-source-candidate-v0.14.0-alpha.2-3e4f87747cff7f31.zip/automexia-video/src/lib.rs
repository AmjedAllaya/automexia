//! Video extension core, independent of terminal implementation details.
//!
//! `VideoExtension` owns the video workflow. Implement `MediaHost` to use your
//! existing process broker, file permissions and output publication mechanism.
//! The optional `native` adapter runs real FFmpeg processes for provider-side use
//! and integration tests. Nothing is installed or activated by constructing it.
//!
//! Calls are blocking and must be scheduled on the host's existing job executor,
//! never a terminal input/render callback. This crate starts no scheduler.
#![forbid(unsafe_code)]

pub mod cancel;
pub mod error;
pub mod extension;
pub mod host;
pub mod media;
pub mod plan;
pub mod progress;
pub mod project;
pub mod edit_render;
pub mod project_store;
pub mod project_workflow;
mod project_json;
pub mod time;
pub mod review;
pub mod preview;
pub mod review_workflow;
#[cfg(feature = "native")]
pub mod native;

pub use cancel::Cancellation;
pub use error::{Error, Result};
pub use extension::{ActionDescriptor, VideoExtension, VideoSettings, ACTIONS, HELP};
pub use host::{InputFile, MediaHost, OutputLease, OutputPolicy, ProgressSink, RuntimeCapabilities};
pub use media::{AudioSelection, MediaInfo, StreamSelection, VideoSelection};
pub use plan::{FrameRateMode, RenderOptions, RenderPlan, RenderRequest, RenderResult};
pub use time::Rational;

pub use project::{Project, TimeRange, EditOperation, EditKind, EditOrigin, Disposition};
pub use project_workflow::{NewProjectRequest, ProjectRenderRequest, ProjectRenderResult, DryRunResult};
pub use project_store::{ProjectStore, LoadedProject, SavedProject};

pub use review::{ReviewSession, ReviewTarget, ReviewBinding, ReviewCommand, ReviewToken, ReviewPreviewTicket, ReviewView};
pub use preview::{PreviewOptions, PreviewFocus, PreviewIntent, PreviewRequest, PreviewSide, PreviewSet};

// Step 4: conservative energy-based pause proposals (no learned models).
pub mod pause;
pub mod pause_metrics;
pub mod pause_workflow;
pub use pause::{PauseSettings, AudioContent, PauseReport, PauseCandidate, EnergyAnalyzer, EnergyFrame, ChannelEnergy};
pub use pause_workflow::{AudioAnalysisHost, PauseAnalysisRequest, AnalysisDecode};

// Step 5: conventional audio treatment; no learned models.
pub mod voice;
pub mod voice_render;
pub mod voice_workflow;
pub use voice::{VoiceSettings,VoiceCleanup,VoiceReport,TreatmentMode,AudioPreflight};
pub use voice_workflow::{VoiceAnalysisRequest,AudioStemRequest,AudioStemResult};

// Step 6: shot-aware technical SDR correction, no learned models.
pub mod color;
pub mod color_analysis;
pub mod color_render;
pub mod color_workflow;
pub mod video_pipe;
pub use color::{ColorSettings,ColorProfile,ColorReport,ColorMode,ColorAdjustment,ColorDecision,CreativeLook,NeutralReference};
pub use color_workflow::{ColorAnalysisRequest,VideoScan};

// Step 7: variant-local aspect conversion, framing and source-time crop tracks.
pub mod reframe;
pub mod reframe_render;
pub use reframe::{FramingSettings,FramingMode,FramingDecision,OutputSize,TargetPreset,SafeZone,ScaleLimits,CropTrack,CropShot,CropKeyframe,CropPose,UnitPoint,DisplayRect,MotionLimits,FrameGeometry};

pub use reframe::{SourceGeometry,PixelRect,RgbColor,PresetStamp};
pub use reframe_render::{ReframeRender,FramingBackend};

// Step 8: supplied captions, safe graphics and small presentation effects.
pub mod subtitles;
pub mod presentation;
pub mod presentation_render;
pub mod presentation_workflow;
#[cfg(feature="graphics")]
pub mod graphics;
#[cfg(feature="native")]
mod graphics_native;
pub use presentation::{PresentationSettings,CollisionPolicy,RasterPolicy,Rgba,TextAlign,Overlay,GraphicContent,AssetRef,FontRef,TextStyle,Placement,Anchor,Animation,VisualKey,Easing,VolumeTrack,VolumeKey,VideoFades};
pub use subtitles::{SubtitleDocument,SubtitleFormat,CaptionCue,CaptionWord};
pub use presentation_render::{PresentationRender,PresentationLease};

pub use presentation::{measure_anchors,suggest_anchor,explicit_punch_ins};

// Step 9: frozen delivery profiles and sequential host workflows with verified output reuse.
pub mod delivery;
pub mod presets;
pub mod delivery_workflow;
pub use delivery::{DeliveryProfile, DeliveryFormat, RenderIntent};
pub use presets::{EditPreset, WorkflowPatch, WorkflowSettings, WorkflowSnapshot, resolve_workflow};
pub use delivery_workflow::{DeliveryRequest, DeliveryTarget, DeliveryReport, OutputSummary, TargetStatus, RunRequest, RunResult};

// Step 10: editor interchange stays separate from finished-media rendering.
pub mod interchange;
pub use interchange::{InterchangeFormat,TargetEditor,PathMode,VisualExport,AudioExport,ExportMarker,ExportRequest,EditRate,CompatibilityReport,Representation,ExportDocument,ExportOutcome,ExportStatus,InterchangeHost};

// Step 14B: portable, explicitly requested interchange handoff archives.
pub mod bundle;
pub mod bundle_zip;
pub mod bundle_workflow;
pub use bundle::{BundleRequest,BundleVideo,BundleAudio,BundlePlan,BundleEntry};
pub use bundle_workflow::{BundleHost,BundleLease,BundlePublication,BundleOutcome,assess_bundle};

// Step 12: private ownership and explicit opt-in observation reuse. No models.
mod lifecycle;
pub use lifecycle::DrainStatus;

pub mod observation_cache;
pub use observation_cache::{ObservationCache,CacheLimits,CacheUse,CacheStats,CachedAnalysis};
pub mod progress_mailbox;
pub use progress_mailbox::{progress_mailbox,ProgressSender,ProgressReceiver};

// Step 13A-D: explicit local packs, speech-aware protection, optional speech enhancement,
// face-aware framing/placement, and explicit reviewed transcription.
pub mod model_pack;
pub mod speech;
pub mod speech_pipe;
pub mod speech_workflow;
pub mod enhancement;
pub mod enhancement_workflow;
pub mod face;
pub mod face_workflow;
#[cfg(feature="silero-onnx")]
pub mod silero_onnx;
pub use model_pack::{ModelManifest,ModelIdentity,ModelRuntime,VerifiedModelPack,ModelActivation};
pub use speech::{SpeechSettings,SpeechSession,SpeechModelProvider,SpeechPauseReport};
pub use speech_workflow::{SpeechAudioHost,SpeechPauseRequest,SpeechScan};
pub use enhancement::{EnhancementMode,EnhancementStrength,EnhancementSettings,EnhancementIdentity,EnhancementReceipt,VoiceEnhancement,EnhancementRequest,SpeechEnhancer};
pub use enhancement_workflow::{EnhancementRunRequest,EnhancementRunResult};
pub use face::{FaceDetector,FaceDetection,FaceInput,FaceSettings,FaceTrackSummary,FaceMetrics,FaceAvoidanceSuggestion,FaceFramingReport};
pub use face_workflow::FaceFramingRequest;

// Explicit source-time transcription and reviewed output timing.
pub mod transcript;
pub mod transcript_workflow;
#[cfg(feature="native")]
pub mod whisper_cpp;
pub mod timing;
pub use timing::{TimingSettings,PlaybackSpeed};
pub mod assembly;
pub use assembly::{AssemblyClip,AssemblySettings};
pub mod placement;
mod placement_workflow;
#[cfg(feature="face-onnx")]
pub mod face_onnx;
#[cfg(feature="native")]
pub mod enhancement_native;
pub mod model_store;
#[cfg(feature="native")]
pub mod native_model_store;

pub use transcript::{Transcript,TranscriptSettings,TranscriptWord,TranscriptProvenance,RecognizedWord,TranscriptSentence,TranscriptMatch,ChapterSuggestion,SentencePunchIn};
pub use transcript_workflow::{TranscriptProvider,TranscriptRequest,TranscriptReport,Recognition};
pub use placement::{PlacementRequest,PlacementReport,PlacementChoice,PlacementTarget,PlacementCandidate,PlacementSuggestion};
pub use face::{FaceApplyChoices,FaceAnchorChoice,FaceAnchorTarget,FacePunchInChoice};
pub use model_store::{ModelInventory,ModelStorage,ModelStore,ModelSelection,ModelRemoval};
#[cfg(feature="native")]
pub use native_model_store::{NativeModelStorage,NativeModelStore};

pub mod hdr;
mod hdr_workflow;
pub use hdr::{HdrRequest,HdrResult,HdrPlan};

pub mod integration;
pub use integration::{ActionRegistry,RegistrationLease,OptionalActions,RegisteredVideo,DeactivationStatus,VideoCommand,VideoCommandResult,ProjectCommand,ProjectCommandResult,InterchangeCommand,InterchangeCommandResult,BundleCommand,BundleCommandResult};
#[cfg(feature="native")]
pub use enhancement_native::{NativeRnnoiseEnhancer,RnnoiseTask};
