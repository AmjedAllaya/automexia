use super::*;
use crate::model_pack::{ModelRuntime,SILERO_CONTRACT,SPEECH_PROCESSING};
use crate::pause::{EnergyAnalyzer,EnergyFrame,ChannelEnergy,PauseSettings,propose_pauses};
use crate::project::{ProjectSource,ResolvedSettings,FrozenRenderSettings,Disposition};
use crate::host::{InputFile,FileStamp};
fn r(s:&str)->Rational{s.parse().unwrap()}
fn range(a:&str,b:&str)->TimeRange{TimeRange::new(r(a),r(b)).unwrap()}
fn identity()->ModelIdentity{ModelIdentity{id:"fake-only".into(),revision:"1".into(),source_revision:"fixture-only".into(),manifest_sha256:"a".repeat(64),weights_sha256:"b".repeat(64),contract:SILERO_CONTRACT.into(),preprocessing:SPEECH_PROCESSING.into(),runtime:ModelRuntime{adapter:"fake-only".into(),build_info_sha256:"c".repeat(64),artifact_sha256:"d".repeat(64)},notices_sha256:"e".repeat(64)}}
fn project()->Project{
    let mut media=crate::media::parse_probe(include_bytes!("../../tests/fixtures/probe-base.json")).unwrap();
    media.duration=Some(r("10"));media.start_time=Some(r("0"));
    for s in &mut media.streams{s.start_pts=Some(0);s.start_time=Some(r("0"));s.duration=Some(r("10"));s.duration_ts=Some(s.time_base.unwrap().inverse().unwrap().ticks(10).unwrap().numerator());if s.kind=="video"{s.nominal_frame_rate=Some(r("30"));s.average_frame_rate=Some(r("30"));}}
    let path=std::env::temp_dir().join("speech-guard-test").join("draft.amxv");
    let input=InputFile{canonical_path:path.parent().unwrap().join("input.mp4"),stamp:FileStamp{size:123,modified_ns:None,sha256:"f".repeat(64),file_id:None}};
    let source=ProjectSource::from_probe("source-1",&input,&media,media.select(crate::StreamSelection::default()).unwrap(),&path).unwrap();
    Project::new("speech-test",source,ResolvedSettings{workflow:None,voice_cleanup:None,voice_enhancement:None,color_correction:None,preset_name:None,preset_revision:None,render:FrozenRenderSettings::from_options(&crate::RenderOptions::default()).unwrap(),pause_cleanup:None}).unwrap()
}
fn baseline(p:&Project)->PauseReport{
    let mut a=EnergyAnalyzer::new(48000,1,r("0"),r("10"),PauseSettings::clean()).unwrap();
    for i in 0..500{a.push(EnergyFrame{pts:i*960,samples:960,channels:vec![if (100..300).contains(&i){ChannelEnergy{rms_dbfs:None,peak_dbfs:None}}else{ChannelEnergy{rms_dbfs:Some(-20.),peak_dbfs:Some(-14.)}}]},&Cancellation::new()).unwrap();}
    propose_pauses(p,a.finish(&Cancellation::new()).unwrap(),&Cancellation::new()).unwrap()
}
fn observation()->SpeechObservation {SpeechObservation{model:identity(),settings:SpeechSettings::default(),decoded_frames:313,reset_count:0,timestamp_repairs:0,observed_duration:r("10"),spans:vec![
    SpeechSpan{range:range("0","2"),class:SpeechClass::Speech,maximum_probability:0.9},
    SpeechSpan{range:range("2","6"),class:SpeechClass::NoSpeech,maximum_probability:0.01},
    SpeechSpan{range:range("6","10"),class:SpeechClass::Speech,maximum_probability:0.9}]}}
fn runtime()->SpeechMediaRuntime{SpeechMediaRuntime{ffmpeg_sha256:"a".repeat(64),ffprobe_sha256:"b".repeat(64),ffmpeg_version:"fake-test".into(),ffprobe_version:"fake-test".into()}}
fn guard(p:&Project,o:SpeechObservation)->SpeechPauseReport{guard_pause_candidates(baseline(p),o,&ModelActivation::selected(identity()).unwrap(),&Cancellation::new(),runtime()).unwrap()}
#[test]fn speech_guard_never_adds_candidates(){let p=project();let n=baseline(&p).candidates().len();assert!(n>0);let out=guard(&p,observation());assert_eq!(out.candidates().len(),n);}
#[test]fn uncertain_quiet_region_vetoes_cut(){let p=project();let mut o=observation();o.spans[1].class=SpeechClass::Uncertain;o.spans[1].maximum_probability=0.4;let out=guard(&p,o);assert!(out.candidates().is_empty());assert_eq!(out.rejected[0].reason,SpeechVeto::SpeechOrUncertain);}
#[test]fn no_confident_speech_flanks_vetoes_cut(){let p=project();let mut o=observation();o.spans[0].class=SpeechClass::Uncertain;o.spans[2].class=SpeechClass::Uncertain;let out=guard(&p,o);assert!(out.candidates().is_empty());assert_eq!(out.rejected[0].reason,SpeechVeto::NoConfidentFlanks);}
#[test]fn uncovered_gap_is_not_model_silence(){let p=project();let mut o=observation();o.spans[1].range.end=r("3");o.observed_duration=r("7");let out=guard(&p,o);assert!(out.candidates().is_empty());}
#[test]fn contradictory_probabilities_are_rejected(){let p=project();let mut o=observation();o.spans[1].maximum_probability=0.9;assert!(guard_pause_candidates(baseline(&p),o,&ModelActivation::selected(identity()).unwrap(),&Cancellation::new(),runtime()).is_err());}
#[test]fn observed_duration_accounting_is_checked(){let p=project();let mut o=observation();o.observed_duration=r("1");assert!(guard_pause_candidates(baseline(&p),o,&ModelActivation::selected(identity()).unwrap(),&Cancellation::new(),runtime()).is_err());}
#[test]fn applied_cuts_are_pending_and_pin_model_provenance(){let mut p=project();let out=guard(&p,observation());let before=p.clone();out.apply(&mut p).unwrap();assert!(p.operations.iter().all(|o|o.disposition==Disposition::NeedsReview));assert!(p.operations[0].reason.contains(&identity().weights_sha256));assert!(p.operations[0].reason.contains(&identity().manifest_sha256));assert_eq!(serde_json::to_value(&p.sources).unwrap(),serde_json::to_value(&before.sources).unwrap());}
#[test]fn changed_project_cannot_accept_report(){let mut p=project();let out=guard(&p,observation());p.revision+=1;assert!(matches!(out.apply(&mut p),Err(Error::StaleReview)));}
#[test]fn revoked_activation_cannot_apply_a_saved_report(){let mut p=project();let a=ModelActivation::selected(identity()).unwrap();let out=guard_pause_candidates(baseline(&p),observation(),&a,&Cancellation::new(),runtime()).unwrap();a.revoke();assert!(matches!(out.apply(&mut p),Err(Error::Cancelled)));}
#[test]fn cancelled_owner_cannot_apply(){let mut p=project();let c=Cancellation::new();let out=guard_pause_candidates(baseline(&p),observation(),&ModelActivation::selected(identity()).unwrap(),&c,runtime()).unwrap();c.cancel();assert!(matches!(out.apply(&mut p),Err(Error::Cancelled)));}
#[test]fn another_model_is_rejected(){let p=project();let mut id=identity();id.weights_sha256="f".repeat(64);assert!(guard_pause_candidates(baseline(&p),observation(),&ModelActivation::selected(id).unwrap(),&Cancellation::new(),runtime()).is_err());}
#[test]fn protection_keeps_cut_absent(){let mut p=project();p.protect_range("source-1",range("3","4"),"keep").unwrap();assert!(guard(&p,observation()).candidates().is_empty());}

#[test]fn operation_deadline_does_not_expire_a_successful_report_owner(){
 let mut p=project();let owner=Cancellation::new();
 let expired_operation=owner.with_deadline(Instant::now());
 assert!(matches!(expired_operation.check(),Err(Error::Timeout)));
 let out=guard_pause_candidates(baseline(&p),observation(),&ModelActivation::selected(identity()).unwrap(),&owner,runtime()).unwrap();
 out.apply(&mut p).unwrap();assert!(owner.check().is_ok());
}
