//! Sequential delivery on the host's existing executor. No thread pool, daemon,
//! automatic downloads, analysis cache, shell parser or hidden approvals.
use crate::{Cancellation,Error,Result,VideoExtension};
use crate::host::{InputFile,MediaHost,MediaTask,OutputPolicy,ProgressSink,RuntimeCapabilities};
use crate::project::{Project,OutputVariant,MAX_VARIANTS};
use crate::project_store::ProjectStore;
use crate::project_workflow::{NewProjectRequest,ProjectRenderRequest};
use crate::delivery::DeliveryProfile;
use crate::presets::WorkflowSnapshot;
use serde::{Deserialize,Serialize};
use sha2::{Digest,Sha256};
use std::{collections::BTreeSet,path::{Path,PathBuf,Component}};

const MAX_REPORT_BYTES:usize=2*1024*1024;
#[derive(Debug,Clone,Serialize,Deserialize)]
#[serde(deny_unknown_fields)]
pub struct DeliveryTarget {pub id:String,pub variant:String,pub output:PathBuf,pub policy:OutputPolicy}
impl DeliveryTarget {
    pub fn new(id:impl Into<String>,variant:impl Into<String>,output:impl Into<PathBuf>)->Self {
        Self{id:id.into(),variant:variant.into(),output:output.into(),policy:OutputPolicy::CreateNew}
    }
}
#[derive(Debug,Clone,Serialize,Deserialize)]
#[serde(deny_unknown_fields)]
pub struct DeliveryRequest {pub project_file:PathBuf,pub targets:Vec<DeliveryTarget>,pub fail_fast:bool}
impl DeliveryRequest {
    pub fn validate(&self,project:&Project)->Result<()> {
        project.validate()?;absolute(&self.project_file)?;
        if !self.project_file.extension().and_then(|s|s.to_str()).is_some_and(|s|s.eq_ignore_ascii_case("amxv")) {return Err(Error::InvalidInput("absolute .amxv project path"));}
        if self.targets.is_empty()||self.targets.len()>MAX_VARIANTS{return Err(Error::LimitExceeded("delivery targets"));}
        let mut ids=BTreeSet::new();let mut paths=BTreeSet::new();
        for target in &self.targets {
            crate::project::id_ok(&target.id)?;crate::project::id_ok(&target.variant)?;absolute(&target.output)?;
            if !ids.insert(&target.id)||!paths.insert(target.output.to_string_lossy().to_lowercase()) {return Err(Error::InvalidInput("duplicate delivery target or portable destination"));}
            let variant=project.variant(&target.variant)?;
            if let Some(profile)=&variant.output_profile{profile.validate_destination(&target.output)?;}
            else if !target.output.extension().and_then(|s|s.to_str()).is_some_and(|s|s.eq_ignore_ascii_case("mp4")){return Err(Error::InvalidInput("legacy target requires MP4"));}
            crate::presentation::guard_destination(project,&self.project_file,&target.output,&target.policy)?;
        }
        Ok(())
    }
    pub fn digest(&self,project:&Project)->Result<String>{
        self.validate(project)?;
        let bytes=serde_json::to_vec(&(1u32,project.decision_digest()?,self)).map_err(|_|Error::InvalidInput("delivery request serialization"))?;
        Ok(format!("{:x}",Sha256::digest(bytes)))
    }
}
#[derive(Debug,Clone,Copy,PartialEq,Eq,Serialize,Deserialize)]
#[serde(rename_all="snake_case")]
pub enum TargetStatus {Succeeded,Reused,Failed,Cancelled,NotStarted,Invalidated,PublishedUnverified}
impl TargetStatus {pub fn successful(self)->bool{matches!(self,Self::Succeeded|Self::Reused)}}
/// Compact observed output properties, not a second copy of ffprobe packet JSON.
#[derive(Debug,Clone,Serialize,Deserialize)]
#[serde(deny_unknown_fields)]
pub struct OutputSummary {
    pub video_codec:String,pub pixel_format:String,pub width:u32,pub height:u32,
    pub sample_aspect_ratio:Option<crate::Rational>,pub average_frame_rate:Option<crate::Rational>,
    pub duration:Option<crate::Rational>,pub color_space:Option<String>,pub color_transfer:Option<String>,pub color_range:Option<String>,
    pub audio_codec:Option<String>,pub sample_rate:Option<u32>,pub channels:Option<u32>,pub channel_layout:Option<String>,
}
impl OutputSummary {
    fn from_media(media:&crate::MediaInfo)->Result<Self>{
        let selected=media.select(crate::StreamSelection::default())?;let v=media.stream(selected.video)?;
        let a=selected.audio.map(|id|media.stream(id)).transpose()?;
        Ok(Self{video_codec:v.codec.clone().ok_or(Error::InvalidOutput("video codec"))?,pixel_format:v.pixel_format.clone().ok_or(Error::InvalidOutput("pixel format"))?,
            width:v.width.ok_or(Error::InvalidOutput("width"))?,height:v.height.ok_or(Error::InvalidOutput("height"))?,sample_aspect_ratio:v.sample_aspect_ratio,average_frame_rate:v.average_frame_rate,
            duration:v.exact_duration().or(media.duration),color_space:v.color_space.clone(),color_transfer:v.color_transfer.clone(),color_range:v.color_range.clone(),
            audio_codec:a.and_then(|a|a.codec.clone()),sample_rate:a.and_then(|a|a.sample_rate),channels:a.and_then(|a|a.channels),channel_layout:a.and_then(|a|a.channel_layout.clone())})
    }
    fn validate(&self)->Result<()>{
        if self.width==0||self.height==0||self.width>16384||self.height>16384{return Err(Error::InvalidInput("delivery output geometry"));}
        for text in [&self.video_codec,&self.pixel_format]{crate::project::text_ok(text,64)?;}
        for text in [&self.color_space,&self.color_transfer,&self.color_range,&self.audio_codec,&self.channel_layout].into_iter().flatten(){crate::project::text_ok(text,64)?;}
        if self.duration.is_some_and(|v|!v.positive())||self.sample_aspect_ratio.is_some_and(|v|!v.positive())||self.channels.is_some_and(|v|v==0||v>8){return Err(Error::InvalidInput("delivery output properties"));}
        Ok(())
    }
}
#[derive(Debug,Clone,Serialize,Deserialize)]
#[serde(deny_unknown_fields)]
pub struct TargetResult {
    pub id:String,pub variant:String,pub destination:PathBuf,pub status:TargetStatus,pub attempts:u32,
    pub output:Option<InputFile>,pub output_media:Option<OutputSummary>,pub profile:Option<DeliveryProfile>,pub runtime:Option<RuntimeCapabilities>,
    pub error:Option<String>,pub warnings:Vec<String>,
}
#[derive(Debug,Clone,Serialize,Deserialize)]
#[serde(deny_unknown_fields)]
pub struct DeliveryReport {
    pub revision:u32,pub request_sha256:String,pub decision_sha256:String,pub project_revision:u64,
    pub execution:String,pub targets:Vec<TargetResult>,pub observer_error:bool,
}
impl DeliveryReport {
    pub fn complete(&self)->bool{self.validate().is_ok()&&!self.observer_error&&self.targets.iter().all(|t|t.status.successful())}
    pub fn exit_code(&self)->i32{if self.complete(){0}else if self.targets.iter().any(|t|t.status==TargetStatus::Cancelled){3}else{2}}
    pub fn to_json(&self)->Result<Vec<u8>>{
        self.validate()?;let mut bytes=serde_json::to_vec_pretty(self).map_err(|_|Error::InvalidInput("delivery result encoding"))?;bytes.push(b'\n');
        if bytes.len()>MAX_REPORT_BYTES{return Err(Error::LimitExceeded("delivery result bytes"));}Ok(bytes)
    }
    pub fn from_json(bytes:&[u8])->Result<Self>{
        if bytes.len()>MAX_REPORT_BYTES{return Err(Error::LimitExceeded("delivery result bytes"));}
        let value=crate::project_json::parse_unique(bytes)?;
        let result:Self=serde_json::from_value(value).map_err(|_|Error::InvalidInput("invalid delivery report"))?;result.validate()?;Ok(result)
    }
    fn validate(&self)->Result<()> {
        if self.revision!=1||self.execution!="sequential"||self.project_revision==0||self.targets.is_empty()||self.targets.len()>MAX_VARIANTS{return Err(Error::InvalidInput("delivery report identity"));}
        digest_ok(&self.request_sha256)?;digest_ok(&self.decision_sha256)?;
        let mut ids=BTreeSet::new();
        for item in &self.targets {
            crate::project::id_ok(&item.id)?;crate::project::id_ok(&item.variant)?;absolute(&item.destination)?;
            if !ids.insert(&item.id)||item.attempts>1_000_000||item.warnings.len()>128{return Err(Error::LimitExceeded("delivery report entries"));}
            if item.status.successful()&&(item.output.is_none()||item.output_media.is_none()||item.runtime.is_none()||item.error.is_some()||item.attempts==0){return Err(Error::InvalidInput("incomplete successful output receipt"));}
            if let Some(out)=&item.output{absolute(&out.canonical_path)?;digest_ok(&out.stamp.sha256)?;if out.stamp.size==0{return Err(Error::InvalidInput("empty completed output"));}}
            if let Some(profile)=&item.profile{profile.validate()?;}
            if let Some(media)=&item.output_media{media.validate()?;}
            for text in item.warnings.iter().chain(item.error.iter()){crate::project::text_ok(text,4096)?;}
            if let Some(runtime)=&item.runtime{
                for s in [&runtime.ffmpeg_version,&runtime.ffprobe_version]{crate::project::text_ok(s,4096)?;}
                if runtime.encoders.len()>2048||runtime.muxers.len()>2048||runtime.filters.len()>4096||runtime.bitstream_filters.len()>1024{return Err(Error::LimitExceeded("runtime receipt size"));}
            }
        }
        Ok(())
    }
}
#[derive(Debug,Clone,Serialize)]
#[serde(tag="event",rename_all="snake_case")]
pub enum DeliveryEvent {
    Started{targets:usize},
    TargetStarted{id:String},
    Progress{id:String,progress:crate::progress::Progress},
    TargetFinished{id:String,status:TargetStatus},
    Finished{exit_code:i32},
}
impl DeliveryEvent {
    pub fn json_line(&self)->Result<Vec<u8>>{
        let mut bytes=serde_json::to_vec(self).map_err(|_|Error::InvalidInput("delivery event"))?;bytes.push(b'\n');
        if bytes.len()>8192{return Err(Error::LimitExceeded("delivery event"));}Ok(bytes)
    }
}
pub type DeliverySink<'a>=dyn FnMut(DeliveryEvent)+'a;
fn notify(sink:&mut DeliverySink<'_>,event:DeliveryEvent)->bool{std::panic::catch_unwind(std::panic::AssertUnwindSafe(||sink(event))).is_ok()}

impl<H:MediaHost> VideoExtension<H> {
    pub fn render_targets(&self,project:&Project,request:&DeliveryRequest,cancel:&Cancellation,sink:&mut DeliverySink<'_>)->Result<DeliveryReport>{
        self.deliver(project,request,None,cancel,sink)
    }
    /// A previous report is an integrity aid, not a signed authorization. Reuse
    /// reopens the REQUESTED destination, compares its fingerprint, probes it and
    /// fully decodes it. Changed/missing successful outputs are not overwritten.
    pub fn retry_targets(&self,project:&Project,request:&DeliveryRequest,previous:&DeliveryReport,cancel:&Cancellation,sink:&mut DeliverySink<'_>)->Result<DeliveryReport>{
        self.deliver(project,request,Some(previous),cancel,sink)
    }
    fn deliver(&self,project:&Project,request:&DeliveryRequest,previous:Option<&DeliveryReport>,cancel:&Cancellation,sink:&mut DeliverySink<'_>)->Result<DeliveryReport>{
        request.validate(project)?;
        // Validate every requested variant before the first output is staged.
        // A pending sibling which was not requested does not block this batch.
        let mut pending=false;for target in &request.targets {pending|=self.dry_run_variant(project,&target.variant)?.pending_or_empty.is_some();}
        let request_sha256=request.digest(project)?;let decision_sha256=project.decision_digest()?;
        if let Some(old)=previous {
            old.validate()?;
            if old.request_sha256!=request_sha256||old.decision_sha256!=decision_sha256||old.project_revision!=project.revision||old.targets.len()!=request.targets.len(){return Err(Error::StaleReview);}
            if old.targets.iter().any(|t|t.attempts>=1_000_000&&!t.status.successful()){return Err(Error::LimitExceeded("delivery attempts"));}
            for (old,target) in old.targets.iter().zip(&request.targets){if old.id!=target.id||old.variant!=target.variant||old.destination!=target.output{return Err(Error::StaleReview);}}
        }
        let job=self.begin(cancel)?;
        // One job slot covers the complete delivery. Disabling/re-enabling may
        // not revive this monotonic cancellation token between two targets.
        let mut report=DeliveryReport{revision:1,request_sha256,decision_sha256,project_revision:project.revision,execution:"sequential".into(),observer_error:false,
            targets:request.targets.iter().enumerate().map(|(i,t)|{
                // Unvisited targets are not newly qualified. Retain old receipts
                // so interruption/fail-fast cannot turn a committed file into a
                // fresh render on the next retry.
                if let Some(old)=previous.map(|p|&p.targets[i]) {let mut row=old.clone();if row.status!=TargetStatus::PublishedUnverified{row.status=TargetStatus::NotStarted;row.error=None;}row}
                else {TargetResult{id:t.id.clone(),variant:t.variant.clone(),destination:t.output.clone(),status:TargetStatus::NotStarted,
                    attempts:0,output:None,output_media:None,profile:project.variant(&t.variant).ok().and_then(|v|v.output_profile.clone()),runtime:None,error:None,warnings:vec![]}}
            }).collect()};
        report.observer_error=!notify(sink,DeliveryEvent::Started{targets:request.targets.len()});
        if pending {
            for row in &mut report.targets {if row.status!=TargetStatus::PublishedUnverified{row.status=TargetStatus::Failed;row.error=Some("A requested variant has unresolved decisions or an empty timeline; no delivery target was staged.".into());}if !notify(sink,DeliveryEvent::TargetFinished{id:row.id.clone(),status:row.status}){report.observer_error=true;}}
            if !notify(sink,DeliveryEvent::Finished{exit_code:report.exit_code()}){report.observer_error=true;}return Ok(report);
        }
        let mut stopped=report.observer_error;
        for (i,target) in request.targets.iter().enumerate(){
            if stopped {
                if previous.is_some_and(|p|p.targets[i].status==TargetStatus::PublishedUnverified){report.targets[i]=previous.unwrap().targets[i].clone();}
                continue;
            }
            if job.cancel.is_cancelled(){if report.targets[i].status!=TargetStatus::PublishedUnverified{report.targets[i].status=TargetStatus::Cancelled;report.targets[i].error=Some(Error::Cancelled.to_string());}stopped=true;continue;}
            if !notify(sink,DeliveryEvent::TargetStarted{id:target.id.clone()}){report.observer_error=true;stopped=true;continue;}
            let mut observer_failed=false;
            let mut progress=|progress|{if !notify(sink,DeliveryEvent::Progress{id:target.id.clone(),progress}){observer_failed=true;job.cancel.cancel();}};
            if let Some(old)=previous.map(|p|&p.targets[i]).filter(|r|r.output.is_some()){
                let outcome=self.revalidate_target(project,request,target,old,&job.cancel,&mut progress);
                match outcome {
                    Ok((output,summary))=>{let row=&mut report.targets[i];*row=old.clone();row.output=Some(output);row.output_media=Some(summary);row.status=TargetStatus::Reused;row.error=None;},
                    Err(e)=>{let row=&mut report.targets[i];*row=old.clone();row.status=if e==Error::Cancelled{TargetStatus::Cancelled}else{TargetStatus::Invalidated};row.error=Some(e.to_string());stopped=request.fail_fast||e==Error::Cancelled;},
                }
            }else if previous.is_some_and(|p|p.targets[i].status==TargetStatus::PublishedUnverified){
                report.targets[i]=previous.unwrap().targets[i].clone();stopped=request.fail_fast;
            }else{
                report.targets[i].attempts=report.targets[i].attempts.checked_add(1).filter(|n|*n<=1_000_000).ok_or(Error::LimitExceeded("delivery attempts"))?;
                let render=ProjectRenderRequest{project_file:request.project_file.clone(),variant:target.variant.clone(),output:target.output.clone(),output_policy:target.policy.clone()};
                match self.render_project_job(project,&render,&job.cancel,&mut progress){
                    Ok(result)=>{
                        // The file has committed. A subsequent receipt failure is
                        // never relabeled as 'nothing happened' or auto-overwritten.
                        let row=&mut report.targets[i];row.runtime=Some(result.media.runtime);row.warnings=result.media.warnings;row.profile=result.media.delivery_profile;
                        row.output_media=OutputSummary::from_media(&result.media.output_media).ok();
                        match self.host().inspect_input(&result.media.output,&job.cancel){
                            Ok(file)=>{row.output=Some(file);if row.output_media.is_some(){row.status=TargetStatus::Succeeded;}else{row.status=TargetStatus::PublishedUnverified;row.error=Some("Output committed; summary unavailable".into());stopped=request.fail_fast;}},
                            Err(e)=>{row.status=TargetStatus::PublishedUnverified;row.error=Some(format!("Output committed; receipt capture failed: {e}"));stopped=request.fail_fast;},
                        }
                    },
                    Err(e)=>{report.targets[i].status=if e==Error::Cancelled{TargetStatus::Cancelled}else{TargetStatus::Failed};report.targets[i].error=Some(e.to_string());stopped=request.fail_fast||e==Error::Cancelled;},
                }
            }
            drop(progress);
            report.observer_error|=observer_failed;
            if !notify(sink,DeliveryEvent::TargetFinished{id:target.id.clone(),status:report.targets[i].status}){report.observer_error=true;}
            stopped|=report.observer_error;
        }
        if !notify(sink,DeliveryEvent::Finished{exit_code:report.exit_code()}){report.observer_error=true;}
        Ok(report)
    }
    fn revalidate_target(&self,project:&Project,request:&DeliveryRequest,target:&DeliveryTarget,old:&TargetResult,cancel:&Cancellation,progress:&mut ProgressSink<'_>)->Result<(InputFile,OutputSummary)>{
        let expected=old.output.as_ref().ok_or(Error::OutputChanged)?;
        let current=self.host().inspect_input(&target.output,cancel)?;
        if current.canonical_path!=expected.canonical_path||current.stamp!=expected.stamp{return Err(Error::OutputChanged);}
        let source=&project.sources[0];let input=self.host().inspect_input(&source.resolve(&request.project_file)?,cancel)?;source.check_input(&input)?;
        let source_media=self.probe_path(&input.canonical_path,cancel,progress)?;
        let runtime=self.host().runtime_capabilities(cancel)?;
        let plan=crate::plan::build_edited_plan(project,&target.variant,&source_media,&runtime)?;
        let output=self.probe_path(&current.canonical_path,cancel,progress)?;crate::plan::validate_output(&source_media,&output,&plan)?;
        self.host().run(&MediaTask::ValidateDecode{input:current.canonical_path.clone(),has_audio:plan.selected().audio.is_some()},cancel,progress)?;
        self.host().revalidate_input(&current,cancel)?;self.host().revalidate_input(&input,cancel)?;Ok((current,OutputSummary::from_media(&output)?))
    }
}

#[derive(Debug,Clone)]
pub struct RunRequest {
    pub create:NewProjectRequest,
    pub settings:WorkflowSnapshot,
    /// Optional complete, explicit variants. Nothing here is auto-approved.
    pub variants:Vec<OutputVariant>,
    pub delivery:Option<DeliveryRequest>,
    pub save_policy:Option<OutputPolicy>,
    /// Dry-run creates inspectable decisions but never final delivery media.
    pub dry_run:bool,
}
#[derive(Debug,Clone,Serialize)]
pub struct RunResult {pub project:Project,pub saved_project:Option<PathBuf>,pub delivery:Option<DeliveryReport>,pub needs_review:bool,pub error:Option<String>,pub cancelled:bool,pub cache_written:bool}
impl RunResult {
    /// 0 completed/prepared, 2 failed, 3 cancelled, 4 requires review.
    pub fn exit_code(&self)->i32 {if self.cancelled{3}else if self.error.is_some(){2}else if self.needs_review{4}else{self.delivery.as_ref().map_or(0,DeliveryReport::exit_code)}}
}
impl<H:MediaHost+ProjectStore+crate::pause_workflow::AudioAnalysisHost> VideoExtension<H>{
    /// Core behind `video run`. A first error returns the latest in-memory draft;
    /// it never deletes an earlier project or completed delivery. Persistence is
    /// explicit. Rendering a saved project calls render_targets, not this method.
    pub fn run_workflow(&self,request:&RunRequest,cancel:&Cancellation,progress:&mut ProgressSink<'_>,events:&mut DeliverySink<'_>)->Result<RunResult>{
        request.settings.validate()?;
        if request.variants.len()>MAX_VARIANTS{return Err(Error::LimitExceeded("run variants"));}
        let workflow=self.workflow_operation(cancel)?;
        let scope=workflow.cancel.clone();
        let mut create=request.create.clone();create.options.frame_rate=request.settings.settings.frame_rate;
        let mut project=self.create_project(&create,&scope,progress)?;
        if !request.variants.is_empty(){project.edit(|p|{p.variants=request.variants.clone();Ok(())})?;}
        let first_variant=project.variants[0].id.clone();
        let explicit_first_profile=project.variants[0].output_profile.clone();
        request.settings.apply(&mut project,&first_variant)?;
        project.edit(|p|{
            if let Some(explicit)=explicit_first_profile{p.variants[0].output_profile=Some(explicit);}
            for variant in &mut p.variants{if variant.output_profile.is_none(){variant.output_profile=Some(request.settings.settings.output.clone());}}
            Ok(())
        })?;
        if let Some(delivery)=&request.delivery{
            if delivery.project_file!=create.project_file{return Err(Error::InvalidInput("run/delivery project location mismatch"));}
            delivery.validate(&project)?;
        }
        let mut result=RunResult{project,saved_project:None,delivery:None,needs_review:false,error:None,cancelled:false,cache_written:false};
        let run=(||->Result<()>{
            let settings=&request.settings.settings;
            if settings.analyze_pauses{
                let mut r=crate::pause_workflow::PauseAnalysisRequest::new(&create.project_file);r.settings=settings.pause_settings.clone();
                scope.check()?;self.analyze_pauses(&result.project,&r,&scope,progress)?.apply(&mut result.project)?;
            }
            if settings.analyze_voice{
                let mut r=crate::voice_workflow::VoiceAnalysisRequest::new(&create.project_file);r.settings=settings.voice_settings.clone();
                scope.check()?;self.analyze_voice(&result.project,&r,&scope,progress)?.apply(&mut result.project)?;
            }
            if settings.analyze_color{
                let mut r=crate::color_workflow::ColorAnalysisRequest::new(&create.project_file);r.settings=settings.color_settings.clone();
                scope.check()?;self.analyze_color(&result.project,&r,&scope,progress)?.apply(&mut result.project)?;
            }
            scope.check()?;
            result.needs_review=requested_review(self,&result.project,request.delivery.as_ref())?;
            if let Some(policy)=&request.save_policy {result.saved_project=Some(self.save_project(&result.project,&create.project_file,policy,&scope)?.path);}
            if !request.dry_run&&!result.needs_review{
                if let Some(delivery)=&request.delivery{scope.check()?;result.delivery=Some(self.render_targets(&result.project,delivery,&scope,events)?);}
            }
            Ok(())
        })();
        if let Err(e)=run{result.cancelled=e==Error::Cancelled;result.error=Some(e.to_string());}
        if let Ok(pending)=requested_review(self,&result.project,request.delivery.as_ref()){result.needs_review=pending;}
        Ok(result)
    }
}
fn requested_review<H:MediaHost>(extension:&VideoExtension<H>,project:&Project,delivery:Option<&DeliveryRequest>)->Result<bool>{
    if let Some(delivery)=delivery {
        for target in &delivery.targets {if extension.dry_run_variant(project,&target.variant)?.pending_or_empty.is_some(){return Ok(true);}}
        Ok(false)
    }else{Ok(extension.dry_run(project)?.pending_or_empty.is_some())}
}
fn absolute(path:&Path)->Result<()>{
    if !path.is_absolute()||path.components().any(|c|matches!(c,Component::ParentDir|Component::CurDir))||path.as_os_str().as_encoded_bytes().contains(&0){return Err(Error::InvalidInput("absolute normalized local delivery path"));}
    Ok(())
}
fn digest_ok(value:&str)->Result<()>{if value.len()!=64||!value.bytes().all(|c|c.is_ascii_digit()||(b'a'..=b'f').contains(&c)){Err(Error::InvalidInput("invalid delivery digest"))}else{Ok(())}}
