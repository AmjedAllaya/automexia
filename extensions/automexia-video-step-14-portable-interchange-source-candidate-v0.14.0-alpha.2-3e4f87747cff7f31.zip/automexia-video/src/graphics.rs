//! Optional Rust-native image/SVG/text rasterization. Inputs are explicit bytes;
//! no directory scanning, system fonts, image hrefs, network or file operations.
use crate::{Error,Result,Cancellation};
use crate::presentation::{GraphicContent,AssetRef,TextStyle,TextAlign,Rgba,MAX_ASSET_BYTES};
use image::{RgbaImage,ImageFormat,ImageReader,GenericImageView};
use std::{io::Cursor,collections::{BTreeMap,BTreeSet}};
use sha2::{Digest,Sha256};
pub const RASTERIZER_ID:&str="resvg-0.45.1-image-0.25.5/automexia-static-v1";
pub const MAX_RASTER_PIXELS:u64=16_777_216;
pub type AssetBytes=BTreeMap<String,Vec<u8>>;
/// Pixels are straight-alpha sRGB. The composer converts the final overlay to
/// Rec.709 code values before FFmpeg combines it with qualified SDR video.
pub fn rasterize(content:&GraphicContent,width:u32,height:u32,assets:&AssetBytes,cancel:&Cancellation)->Result<RgbaImage>{
    cancel.check()?;dimensions(width,height)?;content.validate()?;
    let image=match content {
        GraphicContent::Image{asset}=>{
            let bytes=verified(asset,assets)?;let format=image::guess_format(bytes).map_err(|_|Error::InvalidInput("image signature"))?;
            if !matches!(format,ImageFormat::Png|ImageFormat::Jpeg){return Err(Error::Unsupported("graphics image must be static PNG or JPEG"));}
            // Refuse animated PNG rather than silently select a frame.
            if format==ImageFormat::Png {check_png(bytes)?;}
            let mut reader=ImageReader::with_format(Cursor::new(bytes),format);
            let mut limits=image::Limits::default();limits.max_image_width=Some(8192);limits.max_image_height=Some(8192);limits.max_alloc=Some(128*1024*1024);reader.limits(limits);
            let mut decoded=reader.decode().map_err(|_|Error::InvalidInput("invalid or over-budget image"))?;
            if format==ImageFormat::Jpeg {decoded=orient_jpeg(decoded,jpeg_orientation(bytes)?)?;}
            let(w,h)=decoded.dimensions();dimensions(w,h)?;
            // Aspect is preserved inside the explicit box. Transparent letterbox
            // padding avoids silent distortion of a supplied logo/image.
            let factor=(f64::from(width)/f64::from(w)).min(f64::from(height)/f64::from(h));
            let rw=(f64::from(w)*factor).round().max(1.0) as u32;let rh=(f64::from(h)*factor).round().max(1.0) as u32;
            let resized=resize_rgba(&decoded.to_rgba8(),rw,rh);
            let mut canvas=RgbaImage::new(width,height);image::imageops::overlay(&mut canvas,&resized,i64::from((width-rw)/2),i64::from((height-rh)/2));canvas
        },
        GraphicContent::Svg{asset}=>{
            let bytes=verified(asset,assets)?;validate_svg(bytes)?;
            let source=std::str::from_utf8(bytes).map_err(|_|Error::InvalidInput("SVG must be UTF-8"))?;
            svg_pixels(source,width,height,None,false)?
        },
        GraphicContent::Text{text,style}=>{
            let bytes=verified(&style.font.asset,assets)?;validate_font(bytes,text,&style.font.family)?;
            let svg=text_svg(text,style,width,height)?;
            svg_pixels(&svg,width,height,Some((bytes,&style.font.family)),true)?
        },
    };cancel.check()?;Ok(image)
}
fn verified<'a>(asset:&AssetRef,assets:&'a AssetBytes)->Result<&'a [u8]>{
    asset.validate()?;let bytes=assets.get(&asset.sha256).ok_or(Error::InvalidInput("required selected asset bytes absent"))?;
    if bytes.len() as u64!=asset.size||bytes.len() as u64>MAX_ASSET_BYTES||format!("{:x}",Sha256::digest(bytes))!=asset.sha256{return Err(Error::InputChanged);}Ok(bytes)
}
fn dimensions(w:u32,h:u32)->Result<()> {if w==0||h==0||w>8192||h>8192||u64::from(w)*u64::from(h)>MAX_RASTER_PIXELS{return Err(Error::LimitExceeded("graphics raster pixels"));}Ok(())}
fn validate_font(bytes:&[u8],text:&str,family:&str)->Result<()> {
    if bytes.starts_with(b"ttcf"){return Err(Error::Unsupported("font collections require an explicit face contract; supply one TTF/OTF"));}
    let face=ttf_parser::Face::parse(bytes,0).map_err(|_|Error::InvalidInput("invalid supplied font"))?;
    for c in text.chars(){if matches!(c,'\n'|'\r'|'\t'|'\u{200c}'|'\u{200d}'|'\u{fe0e}'|'\u{fe0f}'){continue;}
        if face.glyph_index(c).is_none(){return Err(Error::Unsupported("selected font lacks a required glyph; no silent fallback"));}}
    let mut db=resvg::usvg::fontdb::Database::new();db.load_font_data(bytes.to_vec());
    if !db.faces().any(|face|face.families.iter().any(|(name,_)|name==family)){return Err(Error::InvalidInput("font family differs from selected font bytes"));}Ok(())
}
fn svg_pixels(svg:&str,width:u32,height:u32,font:Option<(&[u8],&str)>,text:bool)->Result<RgbaImage>{
    let mut options=resvg::usvg::Options::default();
    options.resources_dir=None;
    options.image_href_resolver=resvg::usvg::ImageHrefResolver {
        resolve_data:Box::new(|_,_,_|None),resolve_string:Box::new(|_,_|None),
    };
    if let Some((bytes,family))=font{options.font_family=family.to_owned();options.fontdb_mut().load_font_data(bytes.to_vec());}
    let tree=resvg::usvg::Tree::from_str(svg,&options).map_err(|_|Error::InvalidInput("SVG/text parsing failed"))?;
    let size=tree.size();dimensions(size.width().ceil() as u32,size.height().ceil() as u32)?;
    if text {
        let rect=tree.root().abs_bounding_box();
        if rect.left()< -0.1||rect.top()< -0.1||rect.right()>width as f32+0.1||rect.bottom()>height as f32+0.1{return Err(Error::InvalidInput("text exceeds its box; change layout/font size explicitly"));}
    }
    let sx=width as f32/size.width();let sy=height as f32/size.height();let scale=sx.min(sy);
    let mut pixmap=resvg::tiny_skia::Pixmap::new(width,height).ok_or(Error::LimitExceeded("SVG pixmap allocation"))?;
    let transform=resvg::tiny_skia::Transform::from_scale(scale,scale).post_translate((width as f32-size.width()*scale)/2.0,(height as f32-size.height()*scale)/2.0);
    resvg::render(&tree,transform,&mut pixmap.as_mut());
    let mut bytes=pixmap.data().to_vec();
    // tiny-skia uses premultiplied alpha; FFmpeg's compositing input is straight.
    for p in bytes.chunks_exact_mut(4){let a=u32::from(p[3]);if a==0{p[0]=0;p[1]=0;p[2]=0;}else{for k in 0..3{p[k]=((u32::from(p[k])*255+a/2)/a).min(255) as u8;}}}
    RgbaImage::from_raw(width,height,bytes).ok_or(Error::InvalidOutput("SVG raster size"))
}
/// Strict static SVG subset. No script, CSS, filters, image/use/font references,
/// entities, DTD or foreign content. Local gradient references are bounded.
pub fn validate_svg(bytes:&[u8])->Result<()> {
    if bytes.len()>1024*1024{return Err(Error::LimitExceeded("SVG source bytes"));}
    let text=std::str::from_utf8(bytes).map_err(|_|Error::InvalidInput("SVG UTF-8"))?;
    if text.contains("<!DOCTYPE")||text.contains("<!ENTITY")||text.contains("<?xml-stylesheet"){return Err(Error::InvalidInput("SVG external declarations"));}
    let doc=roxmltree::Document::parse(text).map_err(|_|Error::InvalidInput("malformed SVG XML"))?;
    let root=doc.root_element();if root.tag_name().name()!="svg"||root.tag_name().namespace()!=Some("http://www.w3.org/2000/svg"){return Err(Error::InvalidInput("SVG root namespace"));}
    let mut ids=BTreeSet::new();let mut refs=Vec::new();let mut count=0;
    for n in doc.descendants(){if !n.is_element(){continue;}count+=1;if count>10000{return Err(Error::LimitExceeded("SVG node count"));}
        if n.ancestors().count()>64{return Err(Error::LimitExceeded("SVG depth"));}
        if n.tag_name().namespace()!=Some("http://www.w3.org/2000/svg")||!matches!(n.tag_name().name(),"svg"|"g"|"defs"|"path"|"rect"|"circle"|"ellipse"|"line"|"polyline"|"polygon"|"linearGradient"|"radialGradient"|"stop"|"title"|"desc"){
            return Err(Error::Unsupported("unsupported or active SVG element"));}
        for a in n.attributes(){
            if a.namespace().is_some()||!matches!(a.name(),"id"|"version"|"width"|"height"|"viewBox"|"preserveAspectRatio"|"x"|"y"|"x1"|"y1"|"x2"|"y2"|"rx"|"ry"|"r"|"cx"|"cy"|"fx"|"fy"|"d"|"points"|"transform"|"fill"|"fill-opacity"|"fill-rule"|"stroke"|"stroke-width"|"stroke-opacity"|"stroke-linecap"|"stroke-linejoin"|"stroke-miterlimit"|"stroke-dasharray"|"stroke-dashoffset"|"opacity"|"offset"|"stop-color"|"stop-opacity"|"gradientUnits"|"gradientTransform"|"spreadMethod"){
                return Err(Error::Unsupported("unsupported SVG attribute; CSS and href are not admitted"));}
            if a.value().len()>262144{return Err(Error::LimitExceeded("SVG attribute bytes"));}
            if a.name()=="id"{crate::project::id_ok(a.value())?;if !ids.insert(a.value()){return Err(Error::InvalidInput("duplicate SVG ID"));}}
            let v=a.value().trim();if v.to_ascii_lowercase().contains("url") {let local=v.strip_prefix("url(#").and_then(|v|v.strip_suffix(')')).ok_or(Error::InvalidInput("external SVG reference"))?;crate::project::id_ok(local)?;refs.push(local);}
            if v.contains('\\')||v.contains("://")||v.contains("data:"){return Err(Error::InvalidInput("SVG escaping or external reference"));}
        }
    }
    if refs.iter().any(|r|!ids.contains(r)){return Err(Error::InvalidInput("missing SVG local gradient reference"));}Ok(())
}
fn check_png(bytes:&[u8])->Result<()> {
    if !bytes.starts_with(b"\x89PNG\r\n\x1a\n"){return Err(Error::InvalidInput("PNG signature"));}
    let mut pos=8usize;let mut ended=false;
    while pos<bytes.len(){if bytes.len()-pos<12{return Err(Error::InvalidInput("truncated PNG chunk"));}
        let len=u32::from_be_bytes(bytes[pos..pos+4].try_into().map_err(|_|Error::InvalidInput("PNG length"))?) as usize;
        let end=pos.checked_add(12).and_then(|p|p.checked_add(len)).ok_or(Error::LimitExceeded("PNG chunk"))?;if end>bytes.len(){return Err(Error::InvalidInput("truncated PNG"));}
        let kind=&bytes[pos+4..pos+8];
        if kind==b"IHDR"&&(len!=13||bytes[pos+16]==16){return Err(Error::Unsupported("graphics require a qualified 8-bit SDR PNG"));}
        if matches!(kind,b"iCCP"|b"eXIf"|b"cICP"|b"mDCV"|b"cLLI"){return Err(Error::Unsupported("PNG ICC/HDR/EXIF needs explicit sRGB/orientation normalization"));}
        if kind==b"cHRM" {let expected:[u32;8]=[31270,32900,64000,33000,30000,60000,15000,6000];
            if len!=32||bytes[pos+8..pos+40].chunks_exact(4).zip(expected).any(|(b,v)|u32::from_be_bytes([b[0],b[1],b[2],b[3]])!=v){return Err(Error::Unsupported("non-sRGB PNG primaries"));}}
        if kind==b"gAMA"&&(len!=4||u32::from_be_bytes(bytes[pos+8..pos+12].try_into().map_err(|_|Error::InvalidInput("PNG gamma"))?)!=45455){return Err(Error::Unsupported("non-sRGB PNG gamma"));}
        if matches!(kind,b"acTL"|b"fcTL"|b"fdAT"){return Err(Error::Unsupported("animated PNG is not a static graphic"));}
        if kind==b"IEND"{ended=true;if end!=bytes.len(){return Err(Error::InvalidInput("trailing PNG payload"));}break;}pos=end;
    }if !ended{return Err(Error::InvalidInput("PNG has no IEND"));}Ok(())
}
fn text_svg(text:&str,style:&TextStyle,width:u32,height:u32)->Result<String>{
    style.validate()?;let mut out=format!("<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"{width}\" height=\"{height}\" viewBox=\"0 0 {width} {height}\">");
    if let Some(c)=style.background{out.push_str(&format!("<rect width=\"{width}\" height=\"{height}\" fill=\"{}\" fill-opacity=\"{:.6}\"/>",c.hex(),f64::from(c.alpha)/255.0));}
    let lineheight=f64::from(style.font_size)*style.line_height;let lines:Vec<_>=text.lines().collect();
    if f64::from(style.padding)*2.0+lineheight*(lines.len() as f64)>f64::from(height){return Err(Error::InvalidInput("text needs a taller box or explicit line wrapping"));}
    let (anchor,x)=match style.align{TextAlign::Left=>("start",style.padding),TextAlign::Center=>("middle",width/2),TextAlign::Right=>("end",width.saturating_sub(style.padding))};
    let mut draw=|color:Rgba,dx:i32,dy:i32|{for (i,line) in lines.iter().enumerate(){let y=f64::from(style.padding)+f64::from(style.font_size)+(i as f64)*lineheight+f64::from(dy);
        out.push_str(&format!("<text x=\"{}\" y=\"{y:.6}\" font-family=\"{}\" font-size=\"{}\" text-anchor=\"{anchor}\" fill=\"{}\" fill-opacity=\"{:.6}\" xml:space=\"preserve\">{}</text>",i64::from(x)+i64::from(dx),xml(&style.font.family),style.font_size,color.hex(),f64::from(color.alpha)/255.0,xml(&line.replace('\t',"    "))));}};
    if let Some(c)=style.shadow{draw(c,style.shadow_offset,style.shadow_offset);}draw(style.foreground,0,0);
    out.push_str("</svg>");Ok(out)
}
pub fn xml(s:&str)->String{s.replace('&',"&amp;").replace('<',"&lt;").replace('>',"&gt;").replace('"',"&quot;").replace('\'',"&apos;")}
pub fn srgb_to_bt709(image:&mut RgbaImage){
    let mut table=[0u8;256];for(i,v)in table.iter_mut().enumerate(){let s=i as f64/255.0;let l=if s<=0.04045{s/12.92}else{((s+0.055)/1.055).powf(2.4)};let b=if l<0.018{4.5*l}else{1.099*l.powf(0.45)-0.099};*v=(b.clamp(0.0,1.0)*255.0).round() as u8;}
    for p in image.pixels_mut(){for i in 0..3{p[i]=table[p[i] as usize];}}
}

/// Resize premultiplied channels, then return straight alpha. This avoids dark
/// fringes or hidden-RGB bleed around a transparent logo during resampling.
pub fn resize_rgba(source:&RgbaImage,width:u32,height:u32)->RgbaImage{
    let mut premult=source.clone();for p in premult.pixels_mut(){let a=u16::from(p[3]);for k in 0..3{p[k]=((u16::from(p[k])*a+127)/255) as u8;}}
    let mut result=image::imageops::resize(&premult,width,height,image::imageops::FilterType::Lanczos3);
    for p in result.pixels_mut(){let a=u32::from(p[3]);if a==0{p[0]=0;p[1]=0;p[2]=0;}else{for k in 0..3{p[k]=((u32::from(p[k])*255+a/2)/a).min(255) as u8;}}}result
}
fn jpeg_orientation(bytes:&[u8])->Result<u16>{
    if !bytes.starts_with(b"\xff\xd8"){return Err(Error::InvalidInput("JPEG signature"));}
    let mut pos=2usize;let mut orientation=1;let mut seen=false;
    while pos<bytes.len(){
        if bytes[pos]!=0xff{return Err(Error::InvalidInput("JPEG segment marker"));}
        while pos<bytes.len()&&bytes[pos]==0xff{pos+=1;}let marker=*bytes.get(pos).ok_or(Error::InvalidInput("JPEG marker"))?;pos+=1;
        if marker==0xda||marker==0xd9{break;}if marker==0x01||(0xd0..=0xd7).contains(&marker){continue;}
        let raw=bytes.get(pos..pos+2).ok_or(Error::InvalidInput("JPEG segment length"))?;let len=u16::from_be_bytes([raw[0],raw[1]]) as usize;
        if len<2||pos.checked_add(len).is_none_or(|end|end>bytes.len()){return Err(Error::InvalidInput("truncated JPEG segment"));}
        let segment=&bytes[pos+2..pos+len];pos+=len;
        if matches!(marker,0xc0|0xc1|0xc2|0xc3|0xc5|0xc6|0xc7|0xc9|0xca|0xcb|0xcd|0xce|0xcf) {
            if segment.len()<6||segment[0]!=8||!matches!(segment[5],1|3){return Err(Error::Unsupported("graphics require 8-bit grayscale/RGB JPEG, not CMYK"));}}
        if marker==0xe2&&segment.starts_with(b"ICC_PROFILE\0"){return Err(Error::Unsupported("JPEG ICC profile requires explicit sRGB conversion"));}
        if marker==0xe1&&segment.starts_with(b"Exif\0\0"){
            if seen{return Err(Error::InvalidInput("duplicate JPEG EXIF orientation authority"));}seen=true;orientation=exif_orientation(&segment[6..])?;
        }
    }Ok(orientation)
}
fn exif_orientation(t:&[u8])->Result<u16>{
    let little=match t.get(..2){Some(b"II")=>true,Some(b"MM")=>false,_=>return Err(Error::InvalidInput("EXIF byte order"))};
    let u16at=|p:usize|->Result<u16>{let b=t.get(p..p.checked_add(2).ok_or(Error::LimitExceeded("EXIF offset"))?).ok_or(Error::InvalidInput("EXIF bounds"))?;Ok(if little{u16::from_le_bytes([b[0],b[1]])}else{u16::from_be_bytes([b[0],b[1]])})};
    let u32at=|p:usize|->Result<u32>{let b=t.get(p..p.checked_add(4).ok_or(Error::LimitExceeded("EXIF offset"))?).ok_or(Error::InvalidInput("EXIF bounds"))?;Ok(if little{u32::from_le_bytes([b[0],b[1],b[2],b[3]])}else{u32::from_be_bytes([b[0],b[1],b[2],b[3]])})};
    if u16at(2)?!=42{return Err(Error::InvalidInput("EXIF TIFF header"));}
    let base=u32at(4)? as usize;let n=u16at(base)? as usize;if n>512{return Err(Error::LimitExceeded("EXIF entries"));}let mut value=None;
    for i in 0..n{let p=base.checked_add(2+12*i).ok_or(Error::LimitExceeded("EXIF entries"))?;
        // Validate every IFD entry's structural extent; never follow its pointers.
        t.get(p..p+12).ok_or(Error::InvalidInput("EXIF entry bounds"))?;
        if u16at(p)?==0x112{if value.is_some()||u16at(p+2)?!=3||u32at(p+4)?!=1{return Err(Error::InvalidInput("EXIF orientation shape"));}let o=u16at(p+8)?;if !(1..=8).contains(&o){return Err(Error::InvalidInput("EXIF orientation value"));}value=Some(o);}
    }Ok(value.unwrap_or(1))
}
fn orient_jpeg(image:image::DynamicImage,orientation:u16)->Result<image::DynamicImage>{Ok(match orientation{
    1=>image,2=>image.fliph(),3=>image.rotate180(),4=>image.flipv(),5=>image.fliph().rotate270(),6=>image.rotate90(),7=>image.fliph().rotate90(),8=>image.rotate270(),_=>return Err(Error::InvalidInput("JPEG orientation")),
})}
