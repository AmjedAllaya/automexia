//! One streaming, display-oriented RGB pass shared by cuts, histograms, clipping,
//! neutral-patch measurements and motion/activity. No model or full-video cache.
use crate::{Cancellation, Error, Rational, Result};
use crate::color::*;
use crate::project::{Disposition, Project, TimeRange};

#[derive(Debug, Clone, Copy)]
pub struct VideoFrame<'a> {
    /// Exact absolute source presentation time, not a rounded frame number.
    pub pts:Rational, pub duration:Option<Rational>,
    pub width:u32, pub height:u32, pub rgb:&'a [u8],
}
pub type VideoFrameSink<'a> = dyn for<'f> FnMut(VideoFrame<'f>)->Result<()> + 'a;

struct Features {
    time:Rational, rgb:Vec<u8>,
    luma_hist:[u64;32], color_hist:[u64;64], pixels:u64,
    luma:f64, linear:f64, saturation:f64, bright:u64, dark:u64,
    max_rgb:[f64;3], min_rgb:[f64;3], neutral:Option<([f64;3],f64)>,
}
struct ShotSum {
    start:Rational, boundary:BoundaryKind, frames:u64, flashes:u64, useful:u64,
    pixels:u64, hist:[u64;32], luma:f64, linear:f64, saturation:f64,
    motion:f64, bright:u64, dark:u64, max_rgb:[f64;3],min_rgb:[f64;3], min_luma:f64,max_luma:f64,
    neutral:[f64;3],neutral_min:[f64;3],neutral_max:[f64;3], neutral_spread:f64, neutral_frames:u64,
}
impl ShotSum {
    fn new(start:Rational,boundary:BoundaryKind)->Self {
        Self{start,boundary,frames:0,flashes:0,useful:0,pixels:0,hist:[0;32],luma:0.0,linear:0.0,
            saturation:0.0,motion:0.0,bright:0,dark:0,max_rgb:[0.0;3],min_rgb:[1.0;3],min_luma:1.0,max_luma:0.0,
            neutral:[0.0;3],neutral_min:[1.0;3],neutral_max:[0.0;3],neutral_spread:0.0,neutral_frames:0}
    }
    fn add(&mut self,f:&Features,motion:f64,flash:bool) {
        self.frames+=1;
        if flash {self.flashes+=1;return;}
        self.useful+=1;self.pixels+=f.pixels;
        for i in 0..32 {self.hist[i]+=f.luma_hist[i];}
        self.luma+=f.luma;self.linear+=f.linear;self.saturation+=f.saturation;self.motion+=motion;
        self.bright+=f.bright;self.dark+=f.dark;
        self.min_luma=self.min_luma.min(f.luma);self.max_luma=self.max_luma.max(f.luma);
        for i in 0..3 {self.max_rgb[i]=self.max_rgb[i].max(f.max_rgb[i]);self.min_rgb[i]=self.min_rgb[i].min(f.min_rgb[i]);}
        if let Some((mean,spread))=f.neutral {
            for i in 0..3 {self.neutral[i]+=mean[i];self.neutral_min[i]=self.neutral_min[i].min(mean[i]);self.neutral_max[i]=self.neutral_max[i].max(mean[i]);}
            self.neutral_spread=self.neutral_spread.max(spread);self.neutral_frames+=1;
        }
    }
    fn finish(self,end:Rational,index:usize,settings:&ColorSettings)->Result<ColorShot> {
        if self.useful==0 || self.pixels==0 {return Err(Error::InvalidInput("shot has no usable frames"));}
        let n=self.useful as f64;
        let evidence=ShotEvidence{frames:self.frames,flash_frames:self.flashes,
            mean_luma:(self.luma/n).clamp(0.0,1.0),linear_luma:(self.linear/n).clamp(0.0,1.0),low_luma:quantile(&self.hist,0.1),
            high_luma:quantile(&self.hist,0.9),mean_saturation:(self.saturation/n).clamp(0.0,1.0),
            mean_motion:(self.motion/n).clamp(0.0,1.0),bright_fraction:self.bright as f64/self.pixels as f64,
            dark_fraction:self.dark as f64/self.pixels as f64,rgb_max:self.max_rgb,rgb_min:self.min_rgb,
            luma_variation:(self.max_luma-self.min_luma).clamp(0.0,1.0),
            neutral_mean:if self.neutral_frames==self.useful {
                Some(self.neutral.map(|x|(x/self.neutral_frames as f64).clamp(0.0,1.0)))
            }else{None},neutral_spread:if self.neutral_frames==self.useful {Some(self.neutral_spread.max((0..3).map(|i|self.neutral_max[i]-self.neutral_min[i]).fold(0.0,f64::max)))}else{None},
        };
        evidence.validate()?;
        let range=TimeRange::new(self.start,end)?;
        let (adjustment,reason)=recommend(&evidence,range.duration()?,settings)?;
        let changed=!adjustment.is_identity();
        Ok(ColorShot{id:format!("shot-{}",index+1),range,boundary:self.boundary,evidence,adjustment,
            disposition:if changed{Disposition::NeedsReview}else{Disposition::Ignore},enabled:changed,
            locked:false,user_override:false,reason})
    }
}

pub struct SceneAnalyzer {
    project:Project,settings:ColorSettings,width:u32,height:u32,
    previous:Option<Features>,pending:Option<Features>,previous_flash:bool,
    current:ShotSum,shots:Vec<ColorShot>,known:Vec<Rational>,known_index:usize,
    count:u64,last_pts:Option<Rational>,last_duration:Option<Rational>,failed:bool,
    linear_lut:[f64;256],
}
impl SceneAnalyzer {
    pub fn new(project:&Project,settings:ColorSettings,width:u32,height:u32,known:Vec<Rational>)->Result<Self> {
        project.validate()?;settings.validate()?;
        if project.sources.len()!=1 {return Err(Error::Unsupported("scene analysis is single-source"));}
        qualify_sdr(&project.sources[0].media.video)?;
        if width==0||height==0||width>320||height>320||width*height>57_600 ||
            known.len()>=settings.max_shots {return Err(Error::LimitExceeded("analysis geometry or known cuts"));}
        let duration=project.sources[0].duration;
        if duration>Rational::new(i64::from(settings.max_analysis_seconds),1)? {return Err(Error::LimitExceeded("video analysis duration"));}
        let zero=Rational::new(0,1)?;
        let mut last=zero;
        for t in &known {
            if *t<=last||*t>=duration {return Err(Error::InvalidInput("known cut order/range"));}last=*t;
        }
        Ok(Self{project:project.clone(),settings,width,height,previous:None,pending:None,previous_flash:false,
            current:ShotSum::new(zero,BoundaryKind::SourceStart),shots:vec![],known,known_index:0,
            count:0,last_pts:None,last_duration:None,failed:false,
            linear_lut:std::array::from_fn(|i|linear709(i as f64/255.0))})
    }
    pub fn push(&mut self,frame:VideoFrame<'_>,cancel:&Cancellation)->Result<()> {
        if self.failed {return Err(Error::InvalidInput("failed scene analysis"));}
        let result=self.push_inner(frame,cancel);
        if result.is_err(){self.failed=true;}result
    }
    fn push_inner(&mut self,frame:VideoFrame<'_>,cancel:&Cancellation)->Result<()> {
        cancel.check()?;
        if self.count>=self.settings.max_frames {return Err(Error::LimitExceeded("video frame budget"));}
        if frame.width!=self.width||frame.height!=self.height||frame.rgb.len()!=self.width as usize*self.height as usize*3 {
            return Err(Error::InvalidInput("incomplete or changed RGB frame"));
        }
        let source=&self.project.sources[0];
        let time=frame.pts.checked_sub(source.timeline_origin)?;
        if time.numerator()<0||time>=source.duration||self.last_pts.is_some_and(|t|frame.pts<=t) ||
            frame.duration.is_some_and(|d|!d.positive()||d>source.duration) {return Err(Error::InvalidInput("video timestamp order or bounds"));}
        if self.count==0 && time>source.media.video.time_base.ok_or(Error::InvalidProject("video time base"))?.checked_div(Rational::new(2,1)?)? {
            return Err(Error::InvalidInput("video scan did not start at the selected source origin"));
        }
        if let (Some(previous),Some(duration))=(self.last_pts,self.last_duration) {
            let tolerance=source.media.video.time_base.ok_or(Error::InvalidProject("video time base"))?.checked_div(Rational::new(2,1)?)?;
            if frame.pts.checked_sub(previous.checked_add(duration)?)?.as_f64().abs()>tolerance.as_f64()+0.000001 {return Err(Error::InvalidInput("video scan has incomplete or overlapping frame coverage"));}
        } else if self.last_pts.is_some() {return Err(Error::InvalidInput("frame duration required to prove continuous scan coverage"));}
        let features=extract(frame,time,self.settings.neutral_reference,&self.linear_lut,cancel)?;
        if let Some(pending)=self.pending.take(){self.process(pending,Some(&features))?;}
        self.pending=Some(features);self.last_pts=Some(frame.pts);self.last_duration=frame.duration;self.count+=1;
        Ok(())
    }
    fn process(&mut self,frame:Features,next:Option<&Features>)->Result<()> {
        let mut declared=false;
        if let Some(time)=self.known.get(self.known_index) {
            if *time<frame.time {return Err(Error::InvalidInput("declared cut does not coincide with a decoded frame"));}
            if *time==frame.time {declared=true;self.known_index+=1;}
        }
        let difference=self.previous.as_ref().map(|p|distance(p,&frame)).unwrap_or((0.0,0.0));
        let significant=difference.0>=self.settings.scene_histogram_threshold && difference.1>=self.settings.scene_pixel_threshold;
        // A one-frame near-white flash with immediate return is retained in time,
        // omitted from correction statistics and not used to reset shot state.
        let flash=!declared && significant && frame.luma>0.94 && frame.bright as f64/frame.pixels as f64>0.8 &&
            self.previous.as_ref().zip(next).is_some_and(|(p,n)|{
                let d=distance(p,n);d.0<0.05 && d.1<0.08
            });
        let boundary=declared || (significant && !flash && !self.previous_flash);
        if boundary && self.current.frames>0 {
            if self.shots.len()+1>=self.settings.max_shots {return Err(Error::LimitExceeded("scene count"));}
            let new=ShotSum::new(frame.time,if declared{BoundaryKind::DeclaredCut}else{BoundaryKind::DetectedCut});
            let old=std::mem::replace(&mut self.current,new);
            self.shots.push(old.finish(frame.time,self.shots.len(),&self.settings)?);
        }
        self.current.add(&frame,if boundary||self.previous_flash {0.0}else{difference.1},flash);
        self.previous=Some(frame);self.previous_flash=flash;Ok(())
    }
    pub fn finish(mut self,cancel:&Cancellation)->Result<ColorReport> {
        cancel.check()?;
        if self.failed||self.count==0 {return Err(Error::InvalidInput("empty or failed video scan"));}
        if let Some(frame)=self.pending.take(){self.process(frame,None)?;}
        if self.known_index!=self.known.len(){return Err(Error::InvalidInput("declared cut not observed"));}
        let source=&self.project.sources[0];
        let expected=source.timeline_origin.checked_add(source.duration)?;
        let last=self.last_pts.ok_or(Error::InvalidInput("no final video timestamp"))?;
        let duration=self.last_duration.ok_or(Error::InvalidInput("final frame duration is required for complete coverage"))?;
        let tolerance=source.media.video.time_base.ok_or(Error::InvalidProject("source time base"))?.checked_div(Rational::new(2,1)?)?;
        if last.checked_add(duration)?.checked_sub(expected)?.as_f64().abs()>tolerance.as_f64()+0.000_001 {
            return Err(Error::InvalidInput("video scan does not cover the complete source duration"));
        }
        self.shots.push(self.current.finish(source.duration,self.shots.len(),&self.settings)?);
        let profile=ColorProfile{version:COLOR_VERSION,source_id:source.id.clone(),source_sha256:source.fingerprint.sha256.clone(),
            stream_index:source.media.video.index,duration:source.duration,enabled:true,settings:self.settings,shots:self.shots};
        ColorReport::new(&self.project,profile,self.count,self.width,self.height)
    }
}
fn extract(frame:VideoFrame<'_>,time:Rational,roi:Option<NeutralReference>,lut:&[f64;256],cancel:&Cancellation)->Result<Features> {
    let mut f=Features{time,rgb:frame.rgb.to_vec(),luma_hist:[0;32],color_hist:[0;64],
        pixels:(frame.width*frame.height) as u64,luma:0.0,linear:0.0,saturation:0.0,bright:0,dark:0,max_rgb:[0.0;3],min_rgb:[1.0;3],neutral:None};
    let mut sum=[0.0;3];let mut squares=[0.0;3];let mut samples=0u64;
    let bounds=roi.map(|r|((r.x*f64::from(frame.width)).floor() as usize,(r.y*f64::from(frame.height)).floor() as usize,
        ((r.x+r.width)*f64::from(frame.width)).ceil() as usize,((r.y+r.height)*f64::from(frame.height)).ceil() as usize));
    for (i,p) in frame.rgb.chunks_exact(3).enumerate() {
        if i%4096==0 {cancel.check()?;}
        let rgb=[f64::from(p[0])/255.0,f64::from(p[1])/255.0,f64::from(p[2])/255.0];
        let y=0.2126*rgb[0]+0.7152*rgb[1]+0.0722*rgb[2];
        f.luma+=y;f.linear+=0.2126*lut[p[0] as usize]+0.7152*lut[p[1] as usize]+0.0722*lut[p[2] as usize];
        f.luma_hist[((y*32.0) as usize).min(31)]+=1;
        let bin=(p[0] as usize/64)*16+(p[1] as usize/64)*4+(p[2] as usize/64);f.color_hist[bin]+=1;
        let hi=rgb[0].max(rgb[1]).max(rgb[2]);let lo=rgb[0].min(rgb[1]).min(rgb[2]);
        f.saturation+=if hi>0.0{(hi-lo)/hi}else{0.0};
        if hi>=0.995 {f.bright+=1;}if y<=0.005 {f.dark+=1;}
        for j in 0..3 {f.max_rgb[j]=f.max_rgb[j].max(rgb[j]);f.min_rgb[j]=f.min_rgb[j].min(rgb[j]);}
        if let Some((x0,y0,x1,y1))=bounds {
            let x=i%frame.width as usize;let y=i/frame.width as usize;
            if x>=x0&&x<x1&&y>=y0&&y<y1 {samples+=1;for j in 0..3 {sum[j]+=rgb[j];squares[j]+=rgb[j]*rgb[j];}}
        }
    }
    f.luma=(f.luma/f.pixels as f64).clamp(0.0,1.0);f.linear=(f.linear/f.pixels as f64).clamp(0.0,1.0);f.saturation=(f.saturation/f.pixels as f64).clamp(0.0,1.0);
    if samples>=16 {
        let mean=sum.map(|v|(v/samples as f64).clamp(0.0,1.0));
        let spread=(0..3).map(|j|(squares[j]/samples as f64-mean[j]*mean[j]).max(0.0).sqrt()).fold(0.0,f64::max);
        f.neutral=Some((mean,spread));
    }
    Ok(f)
}
fn distance(a:&Features,b:&Features)->(f64,f64) {
    let hist=(0..64).map(|i|(a.color_hist[i] as f64/a.pixels as f64-b.color_hist[i] as f64/b.pixels as f64).abs()).sum::<f64>()/2.0;
    let luma=(0..32).map(|i|(a.luma_hist[i] as f64/a.pixels as f64-b.luma_hist[i] as f64/b.pixels as f64).abs()).sum::<f64>()/2.0;
    let pixel=a.rgb.iter().zip(&b.rgb).map(|(x,y)|f64::from(x.abs_diff(*y))/255.0).sum::<f64>()/a.rgb.len() as f64;
    (hist.max(luma),pixel)
}
fn quantile(h:&[u64;32],q:f64)->f64 {
    let target=(h.iter().sum::<u64>() as f64*q).ceil() as u64;let mut n=0;
    for (i,c) in h.iter().enumerate(){n+=c;if n>=target{return (i as f64+0.5)/32.0;}}1.0
}
pub(crate) fn linear709(x:f64)->f64 {if x<0.081 {x/4.5}else{((x+0.099)/1.099).powf(1.0/0.45)}}
pub(crate) fn recommend(e:&ShotEvidence,duration:Rational,s:&ColorSettings)->Result<(ColorAdjustment,String)> {
    let mut a=ColorAdjustment::default();
    let trusted=e.frames>=3 && duration.as_f64()>=s.min_correction_seconds &&
        e.bright_fraction<0.005 && e.dark_fraction<0.15 && e.mean_saturation<0.6 &&
        e.luma_variation<0.12 && e.high_luma-e.low_luma>0.06;
    let mut reasons=Vec::new();
    let choose=|mode:ColorMode,auto:f64,manual:f64,identity:f64|match mode{ColorMode::Off=>identity,ColorMode::Manual=>manual,ColorMode::Auto=>if trusted{auto}else{identity}};
    let exposure=if e.linear_luma>0.005 && (e.mean_luma<0.35 || e.mean_luma>0.65) {
        (0.18/e.linear_luma).log2().clamp(-s.max_auto_exposure_ev,s.max_auto_exposure_ev)
    }else{0.0};
    a.exposure_ev=choose(s.exposure,exposure,s.manual.exposure_ev,0.0);
    let gamma=if e.mean_luma<0.38{1.0+s.max_auto_gamma_delta}else if e.mean_luma>0.65{1.0-s.max_auto_gamma_delta}else{1.0};
    a.gamma=choose(s.gamma,gamma,s.manual.gamma,1.0);
    let contrast=if e.high_luma-e.low_luma<0.30 && e.low_luma>0.15 && e.high_luma<0.8{1.0+s.max_auto_contrast_delta}else{1.0};
    a.contrast=choose(s.contrast,contrast,s.manual.contrast,1.0);
    // Never infer that a deliberately muted image needs more saturation.
    let saturation=if e.mean_saturation>0.5{1.0-s.max_auto_saturation_delta}else{1.0};
    a.saturation=choose(s.saturation,saturation,s.manual.saturation,1.0);
    match s.white_balance {
        ColorMode::Manual=>a.white_balance=s.manual.white_balance,
        ColorMode::Auto=>{
            if let (Some(_),Some(rgb),Some(spread))=(s.neutral_reference,e.neutral_mean,e.neutral_spread) {
                let lo=rgb[0].min(rgb[1]).min(rgb[2]);let hi=rgb[0].max(rgb[1]).max(rgb[2]);
                if trusted && lo>0.12 && hi<0.85 && hi/lo<1.6 && spread<0.03 {
                    let linear=rgb.map(linear709);let target=linear.iter().sum::<f64>()/3.0;
                    a.white_balance=linear.map(|v|(target/v).clamp(1.0-s.max_auto_white_balance_delta,1.0+s.max_auto_white_balance_delta));
                    reasons.push("user-confirmed stable neutral patch");
                }
            }
        },ColorMode::Off=>{},
    }
    // Reject automatic channel gains that could clip an observed highlight.
    // Manual adjustments remain explicit review choices, not certified correction.
    if s.white_balance==ColorMode::Auto && (0..3).any(|i|linear709(e.rgb_max[i])*a.white_balance[i]>0.97) {
        a.white_balance=[1.0;3];reasons.push("automatic neutral balance bypassed for highlight headroom");
    }
    // Bound positive AUTO exposure by observed channel maxima. This is sampled
    // evidence, not a certificate for all original pixels. Manual/look changes
    // remain explicit review choices and may deliberately clip.
    if s.exposure==ColorMode::Auto && a.exposure_ev>0.0 {
        let max=e.rgb_max.into_iter().map(linear709).fold(0.0,f64::max)*a.white_balance.into_iter().fold(1.0,f64::max);
        if max>0.0 {a.exposure_ev=a.exposure_ev.min((0.97/max).log2().max(0.0));}
    }
    if s.gamma==ColorMode::Auto && e.rgb_max.into_iter().any(|v|v>0.95) {a.gamma=1.0;}
    if s.contrast==ColorMode::Auto && (e.rgb_max.into_iter().any(|v|v>0.90)||e.rgb_min.into_iter().any(|v|v<0.10)){a.contrast=1.0;}
    if s.look!=CreativeLook::None {
        match s.look {
            CreativeLook::Warm=>{a.white_balance[0]*=1.03;a.white_balance[2]*=0.97;},
            CreativeLook::Film=>{a.contrast*=1.03;a.saturation*=0.95;},
            CreativeLook::HighContrast=>a.contrast*=1.08,
            CreativeLook::None=>{},
        }
        a.contrast=a.contrast.clamp(0.85,1.15);a.saturation=a.saturation.clamp(0.8,1.15);
        a.white_balance=a.white_balance.map(|v|v.clamp(0.8,1.2));reasons.push("explicit creative look, not technical inference");
    }
    // Round stored values to keep decisions stable under harmless floating noise.
    let round=|v:f64|(v*1_000_000.0).round()/1_000_000.0;
    a.exposure_ev=round(a.exposure_ev);a.gamma=round(a.gamma);a.contrast=round(a.contrast);a.saturation=round(a.saturation);a.white_balance=a.white_balance.map(round);
    a.validate()?;
    if !trusted {reasons.push("automatic tone correction bypassed: insufficient, unstable, clipped or strongly colored evidence");}
    if a.is_identity(){reasons.push("preserve source");}else{reasons.push("bounded shot-constant correction; review before rendering");}
    Ok((a,reasons.join("; ")))
}
