use std::sync::{Arc, atomic::{AtomicBool, Ordering}};
use std::time::Instant;
use crate::{Error, Result};

/// Monotonic cancellation shared with a caller/host job. Cloning preserves identity.
#[derive(Clone, Debug)]
pub struct Cancellation { signals: Vec<Arc<AtomicBool>>, deadline: Option<Instant> }
impl Default for Cancellation { fn default() -> Self { Self::new() } }
impl Cancellation {
    pub fn new() -> Self { Self { signals: vec![Arc::new(AtomicBool::new(false))], deadline: None } }
    /// Restrict this operation and its descendants without changing the shared
    /// cancellation identity. An existing deadline can only become earlier.
    pub(crate) fn with_deadline(&self, deadline: Instant) -> Self {
        Self { signals: self.signals.clone(), deadline: Some(self.deadline.map_or(deadline, |old| old.min(deadline))) }
    }
    pub(crate) fn child(&self) -> Result<Self> {
        if self.signals.len() >= 16 { return Err(Error::LimitExceeded("cancellation nesting")); }
        let mut signals = vec![Arc::new(AtomicBool::new(false))];
        signals.extend(self.signals.iter().cloned());
        Ok(Self { signals, deadline: self.deadline })
    }
    pub(crate) fn linked(&self,other:&Self)->Result<Self>{
        let mut signals=vec![Arc::new(AtomicBool::new(false))];
        for signal in self.signals.iter().chain(other.signals.iter()) {
            if !signals.iter().any(|s|Arc::ptr_eq(s,signal)){signals.push(signal.clone());}
        }
        if signals.len()>16{return Err(Error::LimitExceeded("cancellation nesting"));}
        let deadline=match (self.deadline,other.deadline){(Some(a),Some(b))=>Some(a.min(b)),(a,b)=>a.or(b)};
        Ok(Self{signals,deadline})
    }
    pub fn cancel(&self) { self.signals[0].store(true, Ordering::Release); }
    pub fn is_cancelled(&self) -> bool { self.signals.iter().any(|s| s.load(Ordering::Acquire)) || self.deadline.is_some_and(|deadline|Instant::now()>=deadline) }
    pub fn check(&self) -> Result<()> {
        if self.signals.iter().any(|s|s.load(Ordering::Acquire)){Err(Error::Cancelled)}
        else if self.deadline.is_some_and(|deadline|Instant::now()>=deadline){Err(Error::Timeout)}
        else {Ok(())}
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::time::Duration;
    #[test] fn deadlines_expire_without_cancelling_the_owner(){
        let owner=Cancellation::new();let operation=owner.with_deadline(Instant::now());
        assert!(matches!(operation.check(),Err(Error::Timeout)));assert!(operation.is_cancelled());assert!(owner.check().is_ok());
    }
    #[test] fn descendants_and_links_keep_the_earliest_deadline(){
        let expired=Cancellation::new().with_deadline(Instant::now());let later=Instant::now()+Duration::from_secs(60);
        assert!(matches!(expired.with_deadline(later).check(),Err(Error::Timeout)));
        assert!(matches!(expired.child().unwrap().check(),Err(Error::Timeout)));
        assert!(matches!(Cancellation::new().linked(&expired).unwrap().check(),Err(Error::Timeout)));
        assert!(matches!(expired.linked(&Cancellation::new()).unwrap().check(),Err(Error::Timeout)));
    }
    #[test] fn explicit_cancellation_still_propagates_across_deadline_clones(){
        let owner=Cancellation::new();let operation=owner.with_deadline(Instant::now()+Duration::from_secs(60));
        operation.cancel();assert!(matches!(owner.check(),Err(Error::Cancelled)));assert!(matches!(operation.check(),Err(Error::Cancelled)));
    }
}
