//! Step 10: explicit, bounded editable interchange. No filesystem or process
//! authority lives in the serializers. Media verification/publication belongs
//! to `InterchangeHost`, which can reuse the existing application services.
mod build;
mod writers;
mod fcpxml;
pub mod paths;
pub mod timecode;
pub mod timing;
pub mod workflow;
pub use build::{assess_export,build_export,ExportMedia};
pub use timecode::EditRate;
pub use timing::{CfrEvidence,CfrVerifier};
pub use workflow::{ExportOutcome,ExportStatus,InterchangeHost};
use crate::{Error,Result,Rational};
use crate::host::{InputFile,OutputPolicy};
use serde::{Deserialize,Serialize};
use std::path::{Path,PathBuf};
use sha2::{Digest,Sha256};

pub const MAX_EXPORT_BYTES:usize=16*1024*1024;
pub const MAX_MARKERS:usize=1024;
pub const MAX_EXPORT_ITEMS:usize=8192;
#[derive(Debug,Clone,Copy,PartialEq,Eq,Serialize,Deserialize)]
#[serde(rename_all="snake_case")]
pub enum InterchangeFormat{Otio,Fcp7Xml,FcpXml,Edl}
impl InterchangeFormat{pub fn extension(self)->&'static str{match self{Self::Otio=>"otio",Self::Fcp7Xml=>"xml",Self::FcpXml=>"fcpxml",Self::Edl=>"edl"}}}
#[derive(Debug,Clone,Copy,PartialEq,Eq,Serialize,Deserialize)]
#[serde(rename_all="snake_case")]
pub enum TargetEditor{Generic,Resolve,Premiere,FinalCutPro}
#[derive(Debug,Clone,Copy,PartialEq,Eq,Serialize,Deserialize)]
#[serde(rename_all="snake_case")]
pub enum PathMode{AbsoluteFileUrl,RelativeToExport}
#[derive(Debug,Clone,Serialize,Deserialize)]
#[serde(tag="mode",rename_all="snake_case",deny_unknown_fields)]
pub enum VisualExport{Source,Bake{destination:PathBuf}}
#[derive(Debug,Clone,Serialize,Deserialize)]
#[serde(tag="mode",rename_all="snake_case",deny_unknown_fields)]
pub enum AudioExport{Source,BakeStem{destination:PathBuf},Omit}
#[derive(Debug,Clone,Serialize,Deserialize)]
#[serde(deny_unknown_fields)]
pub struct ExportMarker{
    pub id:String,pub name:String,pub comment:String,
    /// Source time relative to the selected video origin, not packet DTS.
    pub at:Rational,pub duration:Rational,
}
#[derive(Debug,Clone,Serialize,Deserialize)]
#[serde(deny_unknown_fields)]
pub struct ExportRequest{
    pub project_file:PathBuf,pub destination:PathBuf,pub output_policy:OutputPolicy,
    pub format:InterchangeFormat,pub target:TargetEditor,pub intended_editor_version:Option<String>,
    pub variant:String,pub name:String,pub rate:EditRate,
    /// Display offsets in frames; zero means explicit file-relative timecode.
    pub source_start_frames:i64,pub record_start_frames:i64,
    pub paths:PathMode,pub video:VisualExport,pub audio:AudioExport,pub markers:Vec<ExportMarker>,
}
impl ExportRequest{
    pub fn new(project_file:impl Into<PathBuf>,destination:impl Into<PathBuf>,format:InterchangeFormat,rate:EditRate)->Self{
        Self{project_file:project_file.into(),destination:destination.into(),output_policy:OutputPolicy::CreateNew,
            format,target:TargetEditor::Generic,intended_editor_version:None,variant:"main".into(),name:"Automexia edit".into(),
            rate,source_start_frames:0,record_start_frames:0,paths:PathMode::AbsoluteFileUrl,video:VisualExport::Source,audio:AudioExport::Source,markers:vec![]}
    }
    pub fn validate(&self)->Result<()>{
        self.rate.validate()?;paths::local_path(&self.project_file)?;paths::local_path(&self.destination)?;
        if !self.project_file.extension().and_then(|s|s.to_str()).is_some_and(|s|s.eq_ignore_ascii_case("amxv"))||
           !self.destination.extension().and_then(|s|s.to_str()).is_some_and(|s|s.eq_ignore_ascii_case(self.format.extension())){
            return Err(Error::InvalidInput("interchange and project file extensions"));
        }
        crate::project::id_ok(&self.variant)?;crate::project::text_ok(&self.name,128)?;
        if self.name.is_empty(){return Err(Error::InvalidInput("empty export title"));}
        if let Some(v)=&self.intended_editor_version{crate::project::text_ok(v,128)?;if v.is_empty(){return Err(Error::InvalidInput("empty intended editor version"));}}
        if self.format==InterchangeFormat::Edl&&self.rate.nominal()>30{return Err(Error::Unsupported("CMX3600 profile supports nominal rates at most 30; use OTIO or FCP7 XML for higher rates"));}
        if self.format==InterchangeFormat::Edl&&(!self.name.is_ascii()||self.name.len()>80){return Err(Error::Unsupported("CMX3600 title must be at most 80 ASCII characters"));}
        if self.format==InterchangeFormat::Fcp7Xml&&self.paths==PathMode::RelativeToExport{return Err(Error::Unsupported("legacy FCP7 XML uses absolute local file URLs; relative portability is provided by OTIO"));}
        self.rate.timecode(self.source_start_frames)?;self.rate.timecode(self.record_start_frames)?;
        let mut destinations=vec![self.project_file.clone(),self.destination.clone()];
        if let VisualExport::Bake{destination}=&self.video{paths::local_path(destination)?;if !destination.extension().and_then(|s|s.to_str()).is_some_and(|s|s.eq_ignore_ascii_case("mov")){return Err(Error::InvalidInput("explicit visual bake requires a .mov destination"));}destinations.push(destination.clone());}
        if let AudioExport::BakeStem{destination}=&self.audio{paths::local_path(destination)?;if !destination.extension().and_then(|s|s.to_str()).is_some_and(|s|s.eq_ignore_ascii_case("wav")){return Err(Error::InvalidInput("explicit audio bake requires a .wav destination"));}destinations.push(destination.clone());}
        let mut seen=std::collections::BTreeSet::new();for p in destinations{if !seen.insert(p){return Err(Error::SameFile);}}
        if self.markers.len()>MAX_MARKERS{return Err(Error::LimitExceeded("export markers"));}
        let mut ids=std::collections::BTreeSet::new();for m in &self.markers{
            crate::project::id_ok(&m.id)?;crate::project::text_ok(&m.name,256)?;crate::project::text_ok(&m.comment,1024)?;
            if !ids.insert(&m.id)||m.at.numerator()<0||m.duration.numerator()<0{return Err(Error::InvalidInput("marker identity or interval"));}
        }
        Ok(())
    }
    pub fn from_json(bytes:&[u8])->Result<Self>{
        if bytes.len()>256*1024{return Err(Error::LimitExceeded("export request bytes"));}
        let v=crate::project_json::parse_unique(bytes)?;let r:Self=serde_json::from_value(v).map_err(|_|Error::InvalidInput("export request schema"))?;r.validate()?;Ok(r)
    }
}
#[derive(Debug,Clone,Copy,PartialEq,Eq,Serialize,Deserialize)]
#[serde(rename_all="snake_case")]
pub enum Representation{Preserved,Translated,Baked,Unsupported}
#[derive(Debug,Clone,Serialize)]
pub struct CompatibilityItem{pub id:String,pub representation:Representation,pub detail:String,pub blocking:bool}
#[derive(Debug,Clone,Serialize)]
pub struct CompatibilityReport{
    pub project_id:String,pub project_revision:u64,pub decision_sha256:String,
    pub format:InterchangeFormat,pub target:TargetEditor,pub intended_editor_version:Option<String>,
    pub application_import_tested:bool,
    pub source_project:serde_json::Value,pub export_request:serde_json::Value,pub items:Vec<CompatibilityItem>,pub warnings:Vec<String>,
}
impl CompatibilityReport{
    pub fn blocked(&self)->bool{self.items.iter().any(|i|i.blocking)}
    pub(crate) fn add(&mut self,id:impl Into<String>,representation:Representation,detail:impl Into<String>,blocking:bool){self.items.push(CompatibilityItem{id:id.into(),representation,detail:detail.into(),blocking});}
    pub fn to_json(&self)->Result<Vec<u8>>{bounded_json(self)}
}
#[derive(Debug,Clone,Serialize)]
pub struct ExportClip{pub id:String,pub source_in:i64,pub source_out:i64,pub record_in:i64,pub record_out:i64}
#[derive(Debug,Clone,Serialize)]
pub struct AudioPiece{pub id:String,pub record_start:Rational,pub duration:Rational,pub source_start:Option<Rational>}
#[derive(Debug,Clone,Serialize)]
pub struct TimelineMarker{pub id:String,pub name:String,pub comment:String,pub at:Rational,pub duration:Rational}
#[derive(Debug,Clone,Serialize)]
pub struct ReferencedMedia{
    pub file:InputFile,pub url:String,pub available_duration:Rational,pub video_stream:Option<u32>,pub audio_stream:Option<u32>,
    pub width:Option<u32>,pub height:Option<u32>,pub sample_aspect:Rational,pub sample_rate:Option<u32>,pub channels:Option<u32>,
}
#[derive(Debug,Clone,Serialize)]
pub struct ExportTimeline{
    pub name:String,pub rate:EditRate,pub source_start_frames:i64,pub record_start_frames:i64,
    pub duration_frames:i64,pub clips:Vec<ExportClip>,pub video:ReferencedMedia,pub audio:Option<ReferencedMedia>,
    pub audio_pieces:Vec<AudioPiece>,pub markers:Vec<TimelineMarker>,pub report:CompatibilityReport,
}
/// Built from validated typed data; bytes and compatibility cannot be modified
/// independently. Creating a document does not read media or authorize a write.
#[derive(Debug,Clone)]
pub struct ExportDocument{format:InterchangeFormat,bytes:Vec<u8>,sha256:String,timeline:ExportTimeline,destination:PathBuf}
impl ExportDocument{
    pub fn bytes(&self)->&[u8]{&self.bytes}
    pub fn sha256(&self)->&str{&self.sha256}
    pub fn timeline(&self)->&ExportTimeline{&self.timeline}
    pub fn report(&self)->&CompatibilityReport{&self.timeline.report}
    pub fn format(&self)->InterchangeFormat{self.format}
    /// Serialized relative media references and embedded request provenance are
    /// bound to this exact destination. Rebuild to export into another directory.
    pub fn validate_destination(&self,path:&Path)->Result<()>{
        paths::local_path(path)?;
        if path!=self.destination.as_path() {return Err(Error::InvalidInput("interchange destination changed; rebuild the document for the new path"));}
        if !path.extension().and_then(|s|s.to_str()).is_some_and(|s|s.eq_ignore_ascii_case(self.format.extension())){return Err(Error::InvalidInput("interchange destination extension"));}
        Ok(())
    }
    pub(crate) fn new(timeline:ExportTimeline,format:InterchangeFormat,destination:PathBuf)->Result<Self>{
        paths::local_path(&destination)?;
        let bytes=writers::write(&timeline,format)?;
        if bytes.is_empty()||bytes.len()>MAX_EXPORT_BYTES{return Err(Error::LimitExceeded("interchange document bytes"));}
        Ok(Self{format,sha256:format!("{:x}",Sha256::digest(&bytes)),bytes,timeline,destination})
    }
}
pub(crate) fn bounded_json<T:Serialize>(v:&T)->Result<Vec<u8>>{
    let mut b=serde_json::to_vec_pretty(v).map_err(|_|Error::InvalidOutput("serialize interchange"))?;b.push(b'\n');
    if b.len()>MAX_EXPORT_BYTES{return Err(Error::LimitExceeded("interchange JSON bytes"));}Ok(b)
}
