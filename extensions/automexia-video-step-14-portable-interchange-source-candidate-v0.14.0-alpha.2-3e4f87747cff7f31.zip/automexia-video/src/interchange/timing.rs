//! Bounded whole-stream presentation-timestamp verification for editable export.
//! Equal nominal/average frame-rate tags alone are NOT proof of CFR.
use crate::{Cancellation, Error, Rational, Result};
use crate::host::InputFile;
use crate::project::ContentFingerprint;
use serde::Serialize;
use super::EditRate;

pub const MAX_CFR_FRAMES:u64=2_000_000;
pub const CFR_PROBE_PREFIX:&[&str]=&["-v","error","-threads","2","-max_alloc","268435456","-protocol_whitelist","file","-format_whitelist","mov,matroska,webm","-show_frames","-show_entries","frame=pts:frame_side_data=","-of","compact=p=0:nk=0"];

#[derive(Debug,Clone,Serialize)]
pub struct CfrEvidence {
    source:ContentFingerprint,stream:u32,rate:EditRate,origin:Rational,duration:Rational,
    frames:u64,time_base:Rational,
}
impl CfrEvidence {
    pub fn frames(&self)->u64{self.frames}
    pub fn rate(&self)->EditRate{self.rate}
    pub fn validate_for(&self,input:&InputFile,stream:u32,rate:EditRate,origin:Rational,duration:Rational)->Result<()> {
        if !self.source.matches(input)||self.stream!=stream||self.rate.fps!=rate.fps||self.origin!=origin||self.duration!=duration {
            return Err(Error::StaleReview);
        }
        Ok(())
    }
}
/// Feed actual `pts=N` records, not packet DTS or rounded decimal timestamps.
/// Clock quantization is tolerated up to half one source time-base tick, with
/// no cumulative drift. Duplicates, discontinuities, truncation and VFR fail.
pub struct CfrVerifier {input:InputFile,stream:u32,rate:EditRate,origin:Rational,duration:Rational,tb:Rational,count:u64,last:Option<i64>,line:Vec<u8>,failed:bool}
impl CfrVerifier {
    pub fn new(input:InputFile,stream:u32,rate:EditRate,origin:Rational,duration:Rational,tb:Rational)->Result<Self>{
        rate.validate()?;
        if !tb.positive()||!duration.positive()||tb>rate.fps.inverse()? {return Err(Error::Unsupported("source clock is too coarse for exact edit-rate verification"));}
        let frames=rate.exact_frames(duration)?;
        if frames<=0||frames as u64>MAX_CFR_FRAMES{return Err(Error::LimitExceeded("CFR verification frame count"));}
        Ok(Self{input,stream,rate,origin,duration,tb,count:0,last:None,line:vec![],failed:false})
    }
    pub fn feed(&mut self,bytes:&[u8],cancel:&Cancellation)->Result<()> {
        if self.failed{return Err(Error::InvalidProbe("timing verifier previously failed"));}
        let result=(||{
            for chunk in bytes.chunks(8192){cancel.check()?;for &b in chunk {
                if b==b'\n'{self.record()?;self.line.clear();}
                else {if self.line.len()>=256{return Err(Error::LimitExceeded("timing record bytes"));}self.line.push(b);}
            }}Ok(())})();
        if result.is_err(){self.failed=true;}result
    }
    fn record(&mut self)->Result<()> {
        let line=std::str::from_utf8(&self.line).map_err(|_|Error::InvalidProbe("timing UTF-8"))?.trim_end_matches('\r');
        // ffprobe can emit an empty separator for an explicitly empty side-data section.
        if line.is_empty(){return Ok(());}
        let value=line.strip_prefix("pts=").ok_or(Error::InvalidProbe("timing record key"))?;
        let value=value.strip_suffix('|').unwrap_or(value);
        let digits=value.strip_prefix('-').unwrap_or(value);
        if digits.is_empty()||!digits.as_bytes().iter().all(u8::is_ascii_digit){return Err(Error::InvalidProbe("timing PTS token"));}
        let pts=value.parse::<i64>().map_err(|_|Error::InvalidProbe("timing PTS"))?;
        if self.count>=MAX_CFR_FRAMES||self.last.is_some_and(|last|pts<=last){return Err(Error::InvalidProbe("duplicate, reordered or oversized frame timestamps"));}
        let observed=self.tb.ticks(pts)?.checked_sub(self.origin)?;
        let expected=self.rate.seconds(self.count as i64)?;
        let error=observed.checked_sub(expected)?;
        let half=self.tb.checked_div(Rational::new(2,1)?)?;
        if error>half||error<half.ticks(-1)?{return Err(Error::Unsupported("variable frame rate or discontinuous source requires an explicit CFR visual bake"));}
        self.count+=1;self.last=Some(pts);Ok(())
    }
    pub fn finish(self,cancel:&Cancellation)->Result<CfrEvidence>{
        cancel.check()?;
        if self.failed||!self.line.is_empty()||self.count==0||self.rate.seconds(self.count as i64)?!=self.duration {
            return Err(Error::InvalidProbe("incomplete frame scan or duration/frame-count mismatch"));
        }
        Ok(CfrEvidence{source:ContentFingerprint::from_stamp(&self.input.stamp)?,stream:self.stream,rate:self.rate,origin:self.origin,duration:self.duration,frames:self.count,time_base:self.tb})
    }
}
