//! Normal Video jobs, not a new export service. No editor is launched.
use super::*;
use crate::{Cancellation,VideoExtension};
use crate::host::{MediaHost,ProgressSink};
use crate::media::MediaInfo;
use crate::project::Project;
use crate::extension::emit;
use crate::progress::Stage;

pub trait InterchangeHost:MediaHost{
    /// Decode/scan every selected video frame's PTS. Never replace this with
    /// `avg_frame_rate == r_frame_rate`, packet count or a boolean from JSON.
    fn verify_cfr(&self,input:&InputFile,media:&MediaInfo,stream:u32,rate:EditRate,cancel:&Cancellation)->Result<CfrEvidence>;
    /// Publish one document atomically through current filesystem ownership.
    /// The complete compatibility report is already embedded in the document.
    /// No separate report file is required for publication to be self-contained.
    /// Revalidate every referenced video/audio file before commit, including
    /// explicit bakes. Protected paths alone are not media-identity evidence.
    fn publish_interchange(&self,source:&InputFile,protected:&[PathBuf],document:&ExportDocument,destination:&Path,policy:&OutputPolicy,cancel:&Cancellation)->Result<PathBuf>;
}
#[derive(Debug,Clone,Copy,PartialEq,Eq,Serialize)]
#[serde(rename_all="snake_case")]
pub enum ExportStatus{Published,PublishedUnverified,Blocked,Failed}
#[derive(Debug,Clone,Serialize)]
pub struct ExportOutcome{
    pub status:ExportStatus,pub destination:Option<PathBuf>,pub sha256:Option<String>,
    pub compatibility:CompatibilityReport,pub request:ExportRequest,
    /// Explicit bakes remain identifiable after a later export failure. They are
    /// not deleted or silently regenerated, and are never mistaken for originals.
    pub published_media:Vec<PathBuf>,pub error:Option<String>,
}
impl ExportOutcome{
    pub fn exit_code(&self)->i32{if self.status==ExportStatus::Published{0}else{2}}
    pub fn to_json(&self)->Result<Vec<u8>>{bounded_json(self)}
}
/// Prepared inside an already admitted job. Optional bakes are published only
/// to the explicitly supplied request paths; a bundle supplies its private lease.
pub(crate) struct PreparedInterchange {
    pub document:ExportDocument,pub source:InputFile,pub protected:Vec<PathBuf>,
}
impl<H:InterchangeHost> VideoExtension<H>{
    pub fn export_interchange(&self,project:&Project,request:&ExportRequest,cancel:&Cancellation,progress:&mut ProgressSink<'_>)->Result<ExportOutcome>{
        let report=assess_export(project,request)?;
        let mut out=ExportOutcome{status:ExportStatus::Blocked,destination:None,sha256:None,compatibility:report,request:request.clone(),published_media:vec![],error:None};
        if out.compatibility.blocked(){return Ok(out);}
        let job=self.begin(cancel)?;
        let result=(||->Result<ExportDocument>{
            let prepared=self.prepare_interchange_job(project,request,&job.cancel,progress,&mut out.published_media)?;
            let doc=prepared.document;let input=prepared.source;let protected=prepared.protected;
            out.compatibility=doc.report().clone();job.cancel.check()?;emit(progress,Stage::Publishing)?;
            let path=self.host().publish_interchange(&input,&protected,&doc,&request.destination,&request.output_policy,&job.cancel)?;
            out.destination=Some(path.clone());out.sha256=Some(doc.sha256().to_owned());
            // Publication is committed. A failed read-back MUST NOT return an
            // ordinary pre-publication failure that encourages blind retry.
            out.status=ExportStatus::PublishedUnverified;
            match self.host().inspect_input(&path,&job.cancel){
                Ok(file) if file.stamp.sha256==doc.sha256()&&file.stamp.size==doc.bytes().len() as u64=>{out.status=ExportStatus::Published;},
                _=>{out.error=Some("Document published; post-publication identity could not be verified. Inspect it before retrying.".into());}
            }
            Ok(doc)
        })();
        if let Err(error)=result{
            out.status=if matches!(error,Error::Unsupported(_)|Error::MissingCapability(_)|Error::UnresolvedEdits|Error::EmptyTimeline){ExportStatus::Blocked}else{ExportStatus::Failed};
            out.error=Some(error.to_string());out.compatibility.add("export-qualification",Representation::Unsupported,error.to_string(),true);
        }
        Ok(out)
    }
    pub(crate) fn prepare_interchange_job(&self,project:&Project,request:&ExportRequest,cancel:&Cancellation,progress:&mut ProgressSink<'_>,published_media:&mut Vec<PathBuf>)->Result<PreparedInterchange>{
        cancel.check()?;
        if assess_export(project,request)?.blocked(){return Err(Error::Unsupported("export assessment has blocking compatibility items"));}
        let source=&project.sources[0];
        let mut protected=vec![request.project_file.clone()];
        for s in &project.sources{protected.push(s.resolve(&request.project_file)?);}
        for v in &project.variants{if let Some(p)=&v.presentation{for a in p.all_asset_refs(){protected.push(a.resolve(&request.project_file)?);}}}
        if let Some(enhancement)=&project.settings.voice_enhancement{protected.push(enhancement.resolve(&request.project_file)?);}
        // Validate all requested destinations before the first optional bake.
        let mut destinations=vec![request.destination.clone()];
        if let VisualExport::Bake{destination}=&request.video{destinations.push(destination.clone());}
        if let AudioExport::BakeStem{destination}=&request.audio{destinations.push(destination.clone());}
        for d in &destinations{crate::presentation::guard_destination(project,&request.project_file,d,&OutputPolicy::CreateNew)?;if protected.contains(d){return Err(Error::SameFile);}}
        emit(progress,Stage::Inspecting)?;
        let input=self.host().inspect_input(&source.resolve(&request.project_file)?,cancel)?;source.check_input(&input)?;
        let info=self.probe_path(&input.canonical_path,cancel,progress)?;source.check_media(&info)?;
        let mut media=ExportMedia{input:input.clone(),info,timing:None,baked_video:None,baked_audio:None};
        if let VisualExport::Bake{destination}=&request.video{
            let mut copy=project.clone();
            if matches!(request.audio,AudioExport::Omit){copy.sources[0].media.audio=None;copy.settings.voice_cleanup=None;copy.settings.voice_enhancement=None;for v in &mut copy.variants{if let Some(p)=&mut v.presentation{p.volume=None;}}}
            let variant=copy.variants.iter_mut().find(|v|v.id==request.variant).ok_or(Error::InvalidProject("export variant"))?;
            variant.output_profile=Some(crate::DeliveryProfile::preset(crate::RenderIntent::Master,Some(crate::DeliveryFormat::ProResMov)));
            variant.render.frame_rate=crate::FrameRateMode::Constant(request.rate.fps);
            let render=crate::ProjectRenderRequest{project_file:request.project_file.clone(),variant:request.variant.clone(),output:destination.clone(),output_policy:OutputPolicy::CreateNew};
            let result=self.render_project_job(&copy,&render,cancel,progress)?;
            published_media.push(result.media.output.clone());
            let baked=self.host().inspect_input(&result.media.output,cancel)?;
            let v=result.media.output_media.streams.iter().find(|v|v.kind=="video").ok_or(Error::InvalidOutput("visual bake has no video"))?;
            let timing=self.host().verify_cfr(&baked,&result.media.output_media,v.index,request.rate,cancel)?;
            media.baked_video=Some((baked,result.media.output_media,timing));
        }else{
            emit(progress,Stage::VerifyingTimeline)?;
            media.timing=Some(self.host().verify_cfr(&input,&media.info,source.media.video.index,request.rate,cancel)?);
        }
        super::build::preflight_media(project,request,&media)?;
        if let AudioExport::BakeStem{destination}=&request.audio{
            let mut stem=crate::AudioStemRequest::new(&request.project_file,destination);stem.variant=request.variant.clone();
            let result=self.export_audio_stem_job(project,&stem,cancel,progress)?;
            published_media.push(result.output.clone());
            let file=self.host().inspect_input(&result.output,cancel)?;
            let probed=self.host().run_audio(&crate::voice_render::AudioTask::ProbeStem{input:file.clone()},cancel,progress)?;
            let info=crate::media::parse_probe(&probed.stdout)?;
            media.baked_audio=Some((file,info));
        }
        emit(progress,Stage::Exporting)?;
        let doc=build_export(project,request,&media)?;
        self.host().revalidate_input(&media.input,cancel)?;
        if let Some((f,_,_))=&media.baked_video{self.host().revalidate_input(f,cancel)?;protected.push(f.canonical_path.clone());}
        if let Some((f,_))=&media.baked_audio{self.host().revalidate_input(f,cancel)?;protected.push(f.canonical_path.clone());}
        Ok(PreparedInterchange{document:doc,source:input,protected})
    }
}
