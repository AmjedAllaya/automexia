use super::*;
use crate::project::Project;
use crate::media::MediaInfo;
use crate::{Disposition,EditKind};

/// Media already inspected through the host; baked objects must describe real,
/// fully validated output from the existing render/stem functions.
#[derive(Debug,Clone)]
pub struct ExportMedia{
    pub input:InputFile,pub info:MediaInfo,pub timing:Option<CfrEvidence>,
    pub baked_video:Option<(InputFile,MediaInfo,CfrEvidence)>,pub baked_audio:Option<(InputFile,MediaInfo)>,
}
pub fn assess_export(project:&Project,r:&ExportRequest)->Result<CompatibilityReport>{
    project.validate()?;r.validate()?;let v=project.variant(&r.variant)?;
    let baked=matches!(r.video,VisualExport::Bake{..});let stem=matches!(r.audio,AudioExport::BakeStem{..});let omit=matches!(r.audio,AudioExport::Omit);
    let mut report=CompatibilityReport{project_id:project.id.clone(),project_revision:project.revision,decision_sha256:project.decision_digest()?,format:r.format,target:r.target,intended_editor_version:r.intended_editor_version.clone(),application_import_tested:false,source_project:serde_json::to_value(project).map_err(|_|Error::InvalidProject("export provenance"))?,export_request:serde_json::to_value(r).map_err(|_|Error::InvalidInput("export request provenance"))?,items:vec![],warnings:vec!["No Resolve, Premiere or Final Cut application import is certified by this writer. The target family is routing intent, not qualification.".into(),"Source timecode is supplied explicitly (zero by default); container PTS is not a camera timecode label.".into()]};
    if let crate::FrameRateMode::Constant(fps)=v.render.frame_rate {if fps!=r.rate.fps&&!baked{report.add("delivery-frame-rate",Representation::Unsupported,"Saved constant-frame-rate delivery differs from the export sequence; explicitly bake at the desired export rate instead of changing cadence silently.",true);}}
    if project.sources.len()!=1{report.add("sources",Representation::Unsupported,"Current editable timeline requires exactly one selected source; variant assembly may reorder or repeat its retained ranges.",true);return Ok(report);}
    for c in &project.assembly{report.add(format!("clip:{}",c.id),if baked{Representation::Baked}else{Representation::Preserved},if baked{"The source assembly is flattened into an explicitly requested rendered variant; source handles are lost."}else{"Authored retained source intervals are preserved; the selected variant determines their exported occurrence order."},false);}
    for o in &project.operations{
        let pending=o.enabled&&o.disposition==Disposition::NeedsReview;
        let active=o.enabled&&o.disposition==Disposition::AutoApply;
        report.add(format!("operation:{}",o.id),if pending{Representation::Unsupported}else if active&&baked{Representation::Baked}else if active{Representation::Translated}else{Representation::Preserved},
            if pending{"Resolve the active pending decision before export."}else if !active{"Disabled/ignored edit has no playback effect; its identity and original .amxv decisions remain in the report provenance."}else if o.kind==EditKind::ProtectRange{"Protected source ranges constrain the exported cut list."}else if baked{"Removal is baked into the reference media; it cannot be undone using that reference alone."}else{"Removal is represented by source in/out boundaries, not by an effect plugin."},pending);
    }
    if let Some(assembly)=&v.assembly {
        let pending=assembly.ensure_resolved().is_err();
        let active=assembly.active();
        let speed=active&&assembly.clips.iter().any(|clip|clip.speed!=crate::timing::PlaybackSpeed::Normal);
        let blocking=pending||speed&&!baked;
        report.add("assembly",if blocking{Representation::Unsupported}else if active&&baked{Representation::Baked}else{Representation::Preserved},
            if pending{"Resolve the selected variant's pending assembly before export."}
            else if speed&&!baked{"Per-occurrence playback speeds require an explicit visual bake; this writer never emits equal source/output durations for a retimed clip."}
            else if active&&baked{"The reviewed occurrence order, repeats, removals and speeds are flattened into the explicitly requested rendered variant."}
            else if active{"Normal-speed occurrence order and repeated source ranges are preserved as separate editable clips with matching audio; source markers are copied into every retained occurrence."}
            else{"The variant assembly is bypassed; the chronological source edit remains authoritative."},blocking);
    }
    let timeline=match editable_timeline(project,&r.variant){Ok(t)=>Some(t),Err(crate::Error::UnresolvedEdits)=>None,Err(crate::Error::EmptyTimeline)=>{report.add("timeline",Representation::Unsupported,"The resolved edit contains no media.",true);None},Err(e)=>return Err(e)};
    if let Some(t)=&timeline{
        if !baked && (r.rate.exact_frames(t.duration).is_err()||t.segments.iter().any(|s|r.rate.exact_frames(s.source_range.start).is_err()||r.rate.exact_frames(s.source_range.end).is_err()||r.rate.exact_frames(s.output_range.start).is_err()||r.rate.exact_frames(s.output_range.end).is_err())) {
            report.add("frame-boundaries",Representation::Unsupported,"A cut falls between export-rate frames. No silent rounding: adjust the cut or explicitly bake a CFR variant.",true);
        }
    }
    // Repetition can multiply events and markers without increasing source
    // length. Reject bounded-format failures before any optional media publish.
    if let Some(t)=&timeline {
        let mut mapped_count=0usize;
        'markers: for marker in &r.markers {for segment in &t.segments {
            let retained=if marker.duration==Rational::new(0,1)? {segment.source_range.contains(marker.at)}
                else {marker.at.max(segment.source_range.start)<marker.at.checked_add(marker.duration)?.min(segment.source_range.end)};
            if retained {mapped_count=mapped_count.checked_add(1).ok_or(Error::LimitExceeded("split export markers"))?;if mapped_count>MAX_MARKERS*4{break 'markers;}}
        }}
        if mapped_count>MAX_MARKERS*4 {report.add("marker-occurrences",Representation::Unsupported,"Repeated assembly occurrences exceed the bounded exported-marker count; reduce the selected markers or assembly repetitions.",true);}
        let mut maximum_frames=t.duration.checked_mul(r.rate.fps)?.ceil_units(1)?;
        // A baked CFR result is checked with a one-frame duration tolerance.
        // Reserve that tolerance before publication, then validate the actual
        // measured frame count again when constructing the final document.
        if baked{maximum_frames=maximum_frames.checked_add(1).ok_or(Error::LimitExceeded("baked frame count"))?;}
        let record_end=r.record_start_frames.checked_add(maximum_frames);
        if record_end.map_or(true,|end|r.rate.timecode(end).is_err()) {
            report.add("record-timecode-limit",Representation::Unsupported,"The selected sequence and record start exceed the restricted 24-hour timecode range. Explicit CFR bakes reserve one frame of validation tolerance before any media is created.",true);
        }
        let source_frames=if baked{maximum_frames}else{t.segments.iter().map(|segment|segment.source_range.end.checked_mul(r.rate.fps).and_then(|end|end.ceil_units(1))).collect::<Result<Vec<_>>>()?.into_iter().max().ok_or(Error::EmptyTimeline)?};
        let source_end=(if baked{0i64}else{r.source_start_frames}).checked_add(source_frames);
        if source_end.map_or(true,|end|r.rate.timecode(end).is_err()) {
            report.add("source-timecode-limit",Representation::Unsupported,"A referenced source endpoint exceeds the restricted 24-hour source timecode range; choose a smaller source timecode offset or an explicit visual bake.",true);
        }
        if !baked&&r.format==InterchangeFormat::Edl {
            let audio_events=if omit||project.sources[0].media.audio.is_none(){0}else if stem{1}else{t.segments.len()};
            if t.segments.len().saturating_add(audio_events)>999 {report.add("edl-event-limit",Representation::Unsupported,"The repeated editable sequence exceeds the restricted CMX3600 999-event profile; choose OTIO/XML or explicitly bake.",true);}
        }
    }
    if let Some(timing)=&v.timing {
        let pending=timing.ensure_resolved().is_err();let active=timing.active();let speed=active&&timing.speed!=crate::timing::PlaybackSpeed::Normal;let dissolve=active&&timing.dissolve.positive();
        let unsupported=pending || !baked && (speed || dissolve && r.format!=InterchangeFormat::Otio);
        report.add("timing",if unsupported{Representation::Unsupported}else if active&&baked{Representation::Baked}else if dissolve{Representation::Translated}else{Representation::Preserved},"Reviewed speed changes require an explicit visual bake. OTIO preserves normal-speed pairwise cross-dissolves with source handles; the restricted XML/EDL writers require a bake for dissolves.",unsupported);
    }
    if stem {if let Some(t)=&timeline{if r.rate.exact_frames(t.duration).is_err(){report.add("stem-frame-grid",Representation::Unsupported,"The selected variant duration is not on the export frame grid; adjust timing before creating any media.",true);}}}
    if let Some(c)=&project.settings.color_correction{
        for shot in &c.shots{
            let pending=c.enabled&&shot.enabled&&shot.disposition==Disposition::NeedsReview;
            let active=c.enabled&&shot.active();
            report.add(format!("color:{}",shot.id),if pending||active&&!baked{Representation::Unsupported}else if active{Representation::Baked}else{Representation::Preserved},if pending{"Pending color decision."}else if active&&!baked{"Exact color processing is not translated to an unqualified editor filter; choose an explicit visual bake."}else if active{"Accepted color processing is baked into the rendered reference."}else{"Bypassed/identity color decision has no playback effect."},pending||active&&!baked);
        }
    }
    if let Some(f)=&v.framing{let pending=f.ensure_resolved().is_err();let active=f.active();report.add("framing",if pending||active&&!baked{Representation::Unsupported}else if active{Representation::Baked}else{Representation::Preserved},"Native crop/keyframe effects are not guessed across editors. Active framing requires an explicit visual bake.",pending||active&&!baked);}
    if let Some(p)=&v.presentation{
        let pending=p.ensure_resolved().is_err();if pending{report.add("presentation",Representation::Unsupported,"Resolve presentation before exporting.",true);}
        for o in &p.overlays{let active=p.active()&&o.enabled;report.add(format!("overlay:{}",o.id),if active&&!baked{Representation::Unsupported}else if active{Representation::Baked}else{Representation::Preserved},"Active graphics/animation require a visual bake; no editor-specific generator is fabricated.",active&&!baked);}
        if let Some(c)=&p.captions{let active=p.active()&&c.burn_in&&!c.document.cues.is_empty();report.add("captions",if active&&!baked{Representation::Unsupported}else if active{Representation::Baked}else{Representation::Preserved},if active{"Burned captions require a visual bake. Editable caption tracks are not silently synthesized."}else{"Sidecar-only captions stay in the source project; use the existing explicit subtitle export separately."},active&&!baked);}
        if let Some(f)=&p.fades{let active=p.active()&&(f.fade_in.positive()||f.fade_out.positive());report.add("video-fades",if active&&!baked{Representation::Unsupported}else if active{Representation::Baked}else{Representation::Preserved},"Source-endpoint fades bake explicitly; variant cross-dissolves are assessed separately.",active&&!baked);}
        if let Some(vol)=&p.volume{let active=p.active()&&vol.keys.iter().any(|k|k.gain!=1.0);report.add("volume",if active&&!stem&&!baked&&!omit{Representation::Unsupported}else if active&&!omit&&(stem||baked){Representation::Baked}else if active&&omit{Representation::Unsupported}else{Representation::Preserved},"Volume automation requires an audio stem or baked variant unless audio is explicitly omitted.",active&&!stem&&!baked&&!omit);}
    }
    let enhanced=project.settings.voice_enhancement.is_some();
    if enhanced{report.add("speech-enhancement",if omit||!stem&&!baked{Representation::Unsupported}else{Representation::Baked},"Reviewed speech enhancement is source-time audio processing. It must be baked into an explicit stem or rendered variant; it is never silently dropped from editable interchange.",!stem&&!baked&&!omit);}
    let voice=project.settings.voice_cleanup.as_ref().is_some_and(|v|v.active());
    if project.settings.voice_cleanup.is_some(){report.add("voice-cleanup",if voice&&(omit||!stem&&!baked){Representation::Unsupported}else if voice{Representation::Baked}else{Representation::Preserved},"Active traditional audio processing must be baked into an explicit stem or rendered variant.",voice&&!stem&&!baked&&!omit);}
    let fades=project.settings.pause_cleanup.as_ref().is_some_and(|p|p.join_fade_ms>0)&&project.operations.iter().any(|o|o.enabled&&o.disposition==Disposition::AutoApply&&matches!(&o.origin,crate::EditOrigin::Generator{id,..} if id==crate::pause::PAUSE_GENERATOR));
    if fades{report.add("pause-join-fades",if !omit&&(stem||baked){Representation::Baked}else{Representation::Unsupported},"The pause-join sample envelopes are not the same as an editor clip cross-dissolve; use an audio stem or bake.",!stem&&!baked&&!omit);}
    if !omit {if let Some(audio)=&project.sources[0].media.audio{if !matches!(audio.channels,Some(1)|Some(2))||!audio.sample_rate.is_some_and(|rate|rate>0){report.add("audio-layout",Representation::Unsupported,"Interchange requires a known mono/stereo sample clock; an unqualified stem cannot repair missing layout metadata.",true);}}}
    if matches!(r.format,InterchangeFormat::Fcp7Xml|InterchangeFormat::Edl) && !v.framing.as_ref().is_some_and(|f|f.active()) && project.sources[0].media.video.sample_aspect_ratio.is_some_and(|sar|sar!=Rational::new(1,1).unwrap()) {report.add("pixel-aspect",Representation::Unsupported,"This writer requires an explicit square-pixel framing/bake before media publication.",true);}
    if matches!(r.audio,AudioExport::BakeStem{..})&&project.sources[0].media.audio.is_none(){report.add("audio-stem",Representation::Unsupported,"There is no selected audio to bake.",true);}
    if omit&&project.sources[0].media.audio.is_some(){report.add("audio",Representation::Unsupported,"Audio is omitted by the explicit AudioExport::Omit request, not an implicit conversion loss.",false);}
    report.warnings.push("The original-media route preserves file references and stream identity, but the selected editor must be checked for codec priming, edit-list and timecode interpretation. This report is not a completed editor import test.".into());
    report.warnings.push("The embedded compatibility report includes the project, media paths, authored names and export settings. Review that information before sharing the document; no data is uploaded by this exporter.".into());
    if baked{report.warnings.push("Visual baking creates a new ProRes SDR reference with explicit CFR conversion. The export becomes a flattened clip; original editing handles are not preserved. Keep the .amxv and originals.".into());}
    if r.format==InterchangeFormat::Edl{report.warnings.push("CMX3600 uses a restricted cuts-only, at-most-stereo, <=999-event profile. Paths and markers in comments may require manual relinking; full data remains in the compatibility report.".into());}
    if r.format==InterchangeFormat::Otio{report.warnings.push("Stream/channel identity is namespaced metadata, not a universally implemented OTIO stream-selection API.".into());}
    if r.format==InterchangeFormat::FcpXml{report.warnings.push("FCPXML project markers are represented as one-frame point markers. Original mapped marker ranges and identities remain in custom metadata and the compatibility report; marker positions must lie on the sequence frame grid.".into());}
    if r.paths==PathMode::RelativeToExport{report.warnings.push("Relative URI references are relative to the exported document, not the process working directory. Qualify the intended importer before use.".into());}
    for m in &r.markers{if m.at>project.sources[0].duration||m.at.checked_add(m.duration)?>project.sources[0].duration{return Err(Error::InvalidInput("marker outside source"));}}
    if r.format==InterchangeFormat::FcpXml {
        if let Err(error)=fcpxml_preflight(project,r,timeline.as_ref(),&report) {
            report.add("fcpxml-wire-profile",Representation::Unsupported,error.to_string(),true);
        }
    }
    if report.items.len()>MAX_EXPORT_ITEMS{return Err(Error::LimitExceeded("compatibility items"));}
    Ok(report)
}
fn reference(input:&InputFile,info:&MediaInfo,video:Option<u32>,audio:Option<u32>,duration:Rational,r:&ExportRequest)->Result<ReferencedMedia>{
    crate::project::ContentFingerprint::from_stamp(&input.stamp)?;
    if !duration.positive(){return Err(Error::InvalidProbe("referenced media duration must be positive"));}
    let v=video.map(|i|info.stream(i)).transpose()?;let a=audio.map(|i|info.stream(i)).transpose()?;
    if let Some(a)=a {if a.kind!="audio"||!a.sample_rate.is_some_and(|n|n>0)||!matches!(a.channels,Some(1)|Some(2)){return Err(Error::Unsupported("interchange requires known mono/stereo audio rate and layout"));}}
    if let Some(v)=v{if v.kind!="video"||!v.width.is_some_and(|n|n>0)||!v.height.is_some_and(|n|n>0)||v.sample_aspect_ratio.is_some_and(|r|!r.positive()){return Err(Error::InvalidProbe("export video geometry"));}}
    Ok(ReferencedMedia{file:input.clone(),url:paths::media_url(&input.canonical_path,&r.destination,r.paths)?,available_duration:duration,video_stream:video,audio_stream:audio,
        width:v.and_then(|s|s.width),height:v.and_then(|s|s.height),sample_aspect:v.and_then(|s|s.sample_aspect_ratio).unwrap_or(Rational::new(1,1)?),sample_rate:a.and_then(|s|s.sample_rate),channels:a.and_then(|s|s.channels)})
}
fn piece(id:String,start:Rational,end:Rational,source:Option<Rational>)->Result<AudioPiece>{Ok(AudioPiece{id,record_start:start,duration:end.checked_sub(start)?,source_start:source})}
fn rounded_frames(rate:EditRate,t:Rational)->Result<i64>{let f=t.checked_div(rate.fps.inverse()?)?;f.nearest_units(1)}
/// The pure serializer never probes files. Native callers should use
/// `export_interchange`, which supplies verified media and timing evidence.
pub fn build_export(project:&Project,r:&ExportRequest,media:&ExportMedia)->Result<ExportDocument>{
    let mut report=assess_export(project,r)?;
    if report.blocked(){return Err(Error::Unsupported("export assessment has blocking compatibility items"));}
    let source=&project.sources[0];source.check_input(&media.input)?;source.check_media(&media.info)?;
    let t=editable_timeline(project,&r.variant)?;let baked=matches!(r.video,VisualExport::Bake{..});
    let mut clips=vec![];let video;let duration_frames;
    let video_count=media.info.streams.iter().filter(|s|s.kind=="video"&&!s.is_attached_picture()).count();
    let audio_count=media.info.streams.iter().filter(|s|s.kind=="audio").count();
    if baked{
        let (input,info,timing)=media.baked_video.as_ref().ok_or(Error::InvalidInput("visual bake result is required"))?;
        let v=info.streams.iter().find(|s|s.kind=="video").ok_or(Error::InvalidOutput("baked video stream missing"))?;
        let d=v.exact_duration().ok_or(Error::InvalidOutput("baked duration missing"))?;
        timing.validate_for(input,v.index,r.rate,v.exact_start().or(info.start_time).ok_or(Error::InvalidOutput("baked origin"))?,d)?;
        duration_frames=i64::try_from(timing.frames()).map_err(|_|Error::LimitExceeded("baked frame count"))?;
        if d.checked_sub(t.duration)?.as_f64().abs()>r.rate.fps.inverse()?.as_f64()+0.000001{return Err(Error::InvalidOutput("baked duration diverges from the edit"));}
        clips.push(ExportClip{id:"baked-1".into(),source_in:0,source_out:duration_frames,record_in:0,record_out:duration_frames});
        video=reference(input,info,Some(v.index),None,d,r)?;
        report.add("baked-timing",Representation::Translated,"The explicit CFR bake can round total duration by up to one frame; output duration is measured, not inferred.",false);
    }else{
        let evidence=media.timing.as_ref().ok_or(Error::MissingCapability("verified full-source CFR frame evidence"))?;
        evidence.validate_for(&media.input,source.media.video.index,r.rate,source.timeline_origin,source.duration)?;
        if video_count!=1{return Err(Error::Unsupported("source-reference export requires one video stream; use an explicit isolated visual bake"));}
        let source_video=&source.media.video;
        if !matches!(source_video.pixel_format.as_deref(),Some("yuv420p")|Some("yuvj420p")|Some("yuv422p")|Some("yuv444p"))||source_video.bits_per_raw_sample.is_some_and(|n|n>8)||matches!(source_video.color_transfer.as_deref(),Some("smpte2084")|Some("arib-std-b67"))||source_video.side_data.iter().any(|s|s.get("side_data_type").and_then(serde_json::Value::as_str).is_some_and(|n|n.contains("DOVI")||n.contains("Mastering display")||n.contains("Content light"))){return Err(Error::Unsupported("HDR/high-bit-depth or unqualified source pixel interpretation is not silently exported as SDR"));}
        if !matches!(source.media.video.field_order.as_deref(),Some("progressive")){return Err(Error::Unsupported("source-reference export requires explicitly progressive video; interlaced interpretation is not guessed"));}
        if source.media.video.rotation_degrees()?!=0{return Err(Error::Unsupported("rotate the reference through an explicit visual bake; importer rotation conventions are not assumed"));}
        video=reference(&media.input,&media.info,Some(source.media.video.index),None,source.duration,r)?;
        for (i,s) in t.segments.iter().enumerate(){clips.push(ExportClip{id:format!("clip-{}",i+1),source_in:r.rate.exact_frames(s.source_range.start)?,source_out:r.rate.exact_frames(s.source_range.end)?,record_in:r.rate.exact_frames(s.output_range.start)?,record_out:r.rate.exact_frames(s.output_range.end)?});}
        duration_frames=r.rate.exact_frames(t.duration)?;
    }
    r.rate.timecode(r.record_start_frames.checked_add(duration_frames).ok_or(Error::LimitExceeded("record timecode"))?)?;
    let last_source=clips.iter().map(|c|c.source_out).max().ok_or(Error::EmptyTimeline)?;
    r.rate.timecode((if baked {0i64}else{r.source_start_frames}).checked_add(last_source).ok_or(Error::LimitExceeded("source timecode"))?)?;
    let duration=r.rate.seconds(duration_frames)?;
    if r.format==InterchangeFormat::Edl && video.sample_aspect!=Rational::new(1,1)? {return Err(Error::Unsupported("EDL carries no reliable pixel-aspect metadata; choose a square-pixel bake"));}
    let mut audio=None;let mut audio_pieces=vec![];
    if !matches!(r.audio,AudioExport::Omit)&&source.media.audio.is_some(){
        let selected=source.media.audio.as_ref().ok_or(Error::InvalidProject("audio source"))?;
        if let AudioExport::BakeStem{..}=&r.audio{
            let (file,info)=media.baked_audio.as_ref().ok_or(Error::InvalidInput("requested audio stem result missing"))?;
            if info.streams.len()!=1{return Err(Error::InvalidOutput("baked stem must have exactly one audio stream"));}
            let a=info.streams.iter().find(|s|s.kind=="audio").ok_or(Error::InvalidOutput("audio stem stream"))?;
            let zero=Rational::new(0,1)?;if a.codec.as_deref()!=Some("pcm_s24le")||a.exact_start().is_some_and(|s|s!=zero){return Err(Error::InvalidOutput("audio stem codec/origin"));}
            let d=a.exact_duration().or(info.duration).ok_or(Error::InvalidOutput("audio stem duration"))?;
            if d.checked_sub(duration)?.as_f64().abs()>1.0/f64::from(a.sample_rate.unwrap_or(48000))+0.000001{return Err(Error::Unsupported("stem duration and export frame grid differ; choose an exact frame-aligned timeline"));}
            audio=Some(reference(file,info,None,Some(a.index),d,r)?);audio_pieces.push(piece("baked-audio".into(),Rational::new(0,1)?,duration,Some(Rational::new(0,1)?))?);
        }else if baked{
            let (file,info,_)=media.baked_video.as_ref().ok_or(Error::InvalidInput("baked video"))?;
            let a=info.streams.iter().find(|s|s.kind=="audio").ok_or(Error::InvalidOutput("baked audio missing"))?;
            let available=a.exact_duration().ok_or(Error::InvalidOutput("baked audio duration missing"))?;
            let origin=a.exact_start().unwrap_or(Rational::new(0,1)?);if origin!=Rational::new(0,1)?{return Err(Error::Unsupported("baked reference still has an audio offset"));}
            audio=Some(reference(file,info,None,Some(a.index),available,r)?);
            for c in &clips {
                let start=r.rate.seconds(c.record_in)?;let end=r.rate.seconds(c.record_out)?;let kept=end.min(available);
                if start<kept{audio_pieces.push(piece(c.id.clone(),start,kept,Some(start))?);}
                if kept<end{audio_pieces.push(piece(format!("{}-tail",c.id),kept.max(start),end,None)?);}
            }
        }else{
            if audio_count!=1{return Err(Error::Unsupported("multiple audio streams require an explicit selected-stream stem"));}
            let start=selected.exact_start().ok_or(Error::Unsupported("audio origin required"))?.checked_sub(source.timeline_origin)?;
            // File-reference audio in/out is interpreted in the same file clock.
            // Offset streams differ across importers: force explicit preparation.
            if start!=Rational::new(0,1)? {return Err(Error::Unsupported("nonzero audio/video origin offset requires a timeline-aligned stem"));}
            let available=selected.exact_duration().ok_or(Error::Unsupported("audio duration required"))?;
            audio=Some(reference(&media.input,&media.info,None,Some(selected.index),available,r)?);
            for (i,s) in t.segments.iter().enumerate(){
                let end=s.source_range.end.min(available);
                if s.source_range.start<end{
                    let out_end=s.output_range.start.checked_add(end.checked_sub(s.source_range.start)?)?;
                    audio_pieces.push(piece(format!("clip-{}",i+1),s.output_range.start,out_end,Some(s.source_range.start))?);
                    if out_end<s.output_range.end{audio_pieces.push(piece(format!("tail-{}",i+1),out_end,s.output_range.end,None)?);}
                }else{audio_pieces.push(piece(format!("gap-{}",i+1),s.output_range.start,s.output_range.end,None)?);}
            }
        }
    }
    if let Some(a)=&audio{
        if !matches!(a.channels,Some(1)|Some(2)){return Err(Error::Unsupported("interchange profile is mono/stereo; multichannel needs separately qualified channel mapping"));}
        if matches!(r.format,InterchangeFormat::Fcp7Xml|InterchangeFormat::Edl){
            for p in &audio_pieces{r.rate.exact_frames(p.record_start)?;r.rate.exact_frames(p.duration)?;if let Some(s)=p.source_start{let first=r.rate.exact_frames(s)?;let last=r.rate.exact_frames(s.checked_add(p.duration)?)?;let offset=if a.file.canonical_path==video.file.canonical_path&&!baked{r.source_start_frames}else{0};r.rate.timecode(first.checked_add(offset).ok_or(Error::LimitExceeded("audio timecode"))?)?;r.rate.timecode(last.checked_add(offset).ok_or(Error::LimitExceeded("audio timecode"))?)?;}}
        }
        if audio_pieces.iter().any(|p|p.source_start.is_some_and(|s|s.checked_add(p.duration).map_or(true,|e|e>a.available_duration))){return Err(Error::Unsupported("audio reference would exceed available samples; render a precisely aligned stem"));}
        report.add("audio-track",if matches!(r.audio,AudioExport::BakeStem{..})||baked{Representation::Baked}else{Representation::Preserved},"The selected mono/stereo track and explicit silent gaps are retained. Original nonzero stream offsets require a prepared stem.",false);
    }
    let mut markers=vec![];
    for m in &r.markers{
        let mut count=0;
        for s in &t.segments{
            let (at,length)=if m.duration==Rational::new(0,1)?{
                if !s.source_range.contains(m.at){continue;}(s.output_range.start.checked_add(m.at.checked_sub(s.source_range.start)?.checked_mul(s.output_range.duration()?)?.checked_div(s.source_range.duration()?)?)?,Rational::new(0,1)?)
            }else{
                let end=m.at.checked_add(m.duration)?.min(s.source_range.end);let start=m.at.max(s.source_range.start);
                if start>=end{continue;}(s.output_range.start.checked_add(start.checked_sub(s.source_range.start)?.checked_mul(s.output_range.duration()?)?.checked_div(s.source_range.duration()?)?)?,end.checked_sub(start)?.checked_mul(s.output_range.duration()?)?.checked_div(s.source_range.duration()?)?)
            };
            let (at,length)=if baked{
                let a=rounded_frames(r.rate,at)?.min(duration_frames);let b=rounded_frames(r.rate,at.checked_add(length)?)?.min(duration_frames);
                (r.rate.seconds(a)?,r.rate.seconds((b-a).max(0))?)
            }else{(at,length)};
            if at>=duration{continue;}
            if matches!(r.format,InterchangeFormat::Fcp7Xml|InterchangeFormat::Edl){r.rate.exact_frames(at)?;r.rate.exact_frames(length)?;}
            if r.format==InterchangeFormat::FcpXml{r.rate.exact_frames(at)?;}
            if markers.len()>=MAX_MARKERS*4{return Err(Error::LimitExceeded("split export markers"));}
            count+=1;markers.push(TimelineMarker{id:format!("{}-{}",m.id,count),name:m.name.clone(),comment:m.comment.clone(),at,duration:length});
        }
        report.add(format!("marker:{}",m.id),Representation::Translated,if count==0{"Marker lies wholly in removed footage and is omitted from playback markers; its original definition remains in the export request."}else if r.format==InterchangeFormat::Edl{"Marker is mapped through cuts and emitted as ASCII-escaped comments; automatic editor marker import is not promised."}else{"Source marker is mapped, split and repeated through every retained assembly occurrence into timeline markers."},false);
    }
    if markers.len()>MAX_MARKERS*4{return Err(Error::LimitExceeded("split export markers"));}
    if r.format==InterchangeFormat::Edl&&clips.len()+audio_pieces.iter().filter(|p|p.source_start.is_some()).count()>999{return Err(Error::LimitExceeded("CMX3600 999 event profile"));}
    let timeline=ExportTimeline{name:r.name.clone(),rate:r.rate,source_start_frames:if baked{0}else{r.source_start_frames},record_start_frames:r.record_start_frames,duration_frames,clips,video,audio,audio_pieces,markers,report};
    ExportDocument::new(timeline,r.format,r.destination.clone())
}

/// Rendering may merge contiguous ranges. Interchange must preserve explicit
/// assembly splits so the user can continue editing those cuts in another NLE.
fn editable_timeline(project:&Project,variant:&str)->Result<crate::project::Timeline>{
    let base=project.timeline_for_variant(variant)?;let mut segments=vec![];
    for s in &base.segments{
        let mut points=std::collections::BTreeSet::new();points.insert(s.source_range.start);points.insert(s.source_range.end);
        for c in &project.assembly{if c.source_id==s.source_id{for b in [c.range.start,c.range.end]{if b>s.source_range.start&&b<s.source_range.end{points.insert(b);}}}}
        let points:Vec<_>=points.into_iter().collect();
        for pair in points.windows(2){
            if segments.len()>=MAX_EXPORT_ITEMS{return Err(Error::LimitExceeded("editable interchange clip occurrences"));}
            let start=s.output_range.start.checked_add(pair[0].checked_sub(s.source_range.start)?.checked_mul(s.output_range.duration()?)?.checked_div(s.source_range.duration()?)?)?;
            segments.push(crate::project::TimelineSegment{source_id:s.source_id.clone(),source_range:crate::TimeRange::new(pair[0],pair[1])?,output_range:crate::TimeRange::new(start,start.checked_add(pair[1].checked_sub(pair[0])?.checked_mul(s.output_range.duration()?)?.checked_div(s.source_range.duration()?)?)?)?});}
    }
    Ok(crate::project::Timeline{segments,duration:base.duration})
}

/// Perform all source-reference and timeline checks before producing an optional
/// audio stem. The provisional stem is a typed clock description, never a file.
pub(crate) fn preflight_media(project:&Project,r:&ExportRequest,media:&ExportMedia)->Result<()> {
    if !matches!(r.video,VisualExport::Source) {return Ok(());}
    if matches!(r.audio,AudioExport::BakeStem{..}) {
        // Source video validation must still run when the selected original
        // audio has offsets or multiple streams that the requested stem fixes.
        let mut video_request=r.clone();video_request.audio=AudioExport::Omit;
        build_export(project,&video_request,media)?;
        let duration=project.timeline_for_variant(&r.variant)?.duration;r.rate.exact_frames(duration)?;
    }else{build_export(project,r,media)?;}
    Ok(())
}

/// Check known modern-XML wire restrictions before optional dependent media.
/// The writer validates the actual probed/baked objects again before publication.
fn fcpxml_preflight(project:&Project,r:&ExportRequest,timeline:Option<&crate::project::Timeline>,report:&CompatibilityReport)->Result<()> {
    let source=&project.sources[0];
    let source_tc=r.rate.seconds(if matches!(r.video,VisualExport::Bake{..}){0}else{r.source_start_frames})?;
    let record_tc=r.rate.seconds(r.record_start_frames)?;
    let wire=|value|super::fcpxml::time(value).map(|_|());
    wire(source_tc)?;wire(record_tc)?;wire(r.rate.fps.inverse()?)?;
    if matches!(r.video,VisualExport::Source){wire(source.duration)?;wire(source_tc.checked_add(source.duration)?)?;}
    if !matches!(r.audio,AudioExport::Omit) {
        if let Some(audio)=&source.media.audio {
            super::fcpxml::sample_rate(audio.sample_rate.ok_or(Error::Unsupported("FCPXML needs a known selected audio rate"))?)?;
            if matches!(r.audio,AudioExport::Source)&&matches!(r.video,VisualExport::Source) {
                let length=audio.exact_duration().ok_or(Error::Unsupported("FCPXML needs an exact source audio duration"))?;
                wire(length)?;wire(source_tc.checked_add(length)?)?;
            }
        }
    }
    if let Some(t)=timeline {
        wire(t.duration)?;wire(record_tc.checked_add(t.duration)?)?;
        for s in &t.segments {
            for at in [s.source_range.start,s.source_range.end]{wire(at)?;wire(source_tc.checked_add(at)?)?;}
            for at in [s.output_range.start,s.output_range.end]{wire(at)?;wire(record_tc.checked_add(at)?)?;}
            for m in &r.markers {
                let start=m.at.max(s.source_range.start);let end=m.at.checked_add(m.duration)?.min(s.source_range.end);
                if (m.duration==Rational::new(0,1)?&&s.source_range.contains(m.at))||start<end {
                    let mapped=s.output_range.start.checked_add(start.checked_sub(s.source_range.start)?.checked_mul(s.output_range.duration()?)?.checked_div(s.source_range.duration()?)?)?;
                    // Baked markers are snapped to the measured output frame grid.
                    if matches!(r.video,VisualExport::Source){r.rate.exact_frames(mapped)?;wire(mapped)?;wire(record_tc.checked_add(mapped)?)?;wire(source_tc.checked_add(start)?)?;}
                }
            }
        }
    }
    super::fcpxml::preflight_size(project,r,timeline,report)?;
    Ok(())
}
