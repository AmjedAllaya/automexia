use super::*;
use serde_json::{json,Value};
use std::fmt::Write;

pub(super) fn write(t:&ExportTimeline,format:InterchangeFormat)->Result<Vec<u8>>{
    match format{InterchangeFormat::Otio=>otio(t),InterchangeFormat::Fcp7Xml=>fcp7(t),InterchangeFormat::FcpXml=>super::fcpxml::write(t),InterchangeFormat::Edl=>edl(t)}
}
fn rt(value:i64,rate:f64)->Value{json!({"OTIO_SCHEMA":"RationalTime.1","value":value,"rate":rate})}
fn seconds(value:Rational)->Result<Value>{
    // JSON's doubles are OTIO's wire representation. Refuse integers beyond
    // exact binary64 representation instead of silently damaging long clocks.
    if value.numerator().unsigned_abs()>9_007_199_254_740_992||value.denominator()>9_007_199_254_740_992{return Err(Error::LimitExceeded("OTIO exact rational wire representation"));}
    Ok(rt(value.numerator(),value.denominator() as f64))
}
fn tr(start:Rational,duration:Rational)->Result<Value>{Ok(json!({"OTIO_SCHEMA":"TimeRange.1","start_time":seconds(start)?,"duration":seconds(duration)?}))}
fn frames(start:i64,duration:i64,rate:EditRate)->Value{json!({"OTIO_SCHEMA":"TimeRange.1","start_time":rt(start,rate.fps.as_f64()),"duration":rt(duration,rate.fps.as_f64())})}
fn ext(m:&ReferencedMedia,start:Rational)->Result<Value>{Ok(json!({"OTIO_SCHEMA":"ExternalReference.1","name":"","target_url":m.url,"available_range":tr(start,m.available_duration)?,"metadata":{"automexia":{"sha256":m.file.stamp.sha256,"video_stream_index":m.video_stream,"audio_stream_index":m.audio_stream,"channels":m.channels,"sample_rate":m.sample_rate,"sample_aspect":m.sample_aspect}},"available_image_bounds":null}))}
fn clip(name:&str,range:Value,reference:Value,group:&str)->Value{
    json!({"OTIO_SCHEMA":"Clip.2","name":name,"source_range":range,"effects":[],"markers":[],"metadata":{"automexia":{"link_group":group}},"media_references":{"DEFAULT_MEDIA":reference},"active_media_reference_key":"DEFAULT_MEDIA"})
}
fn track(name:&str,kind:&str,children:Vec<Value>,markers:Vec<Value>)->Value{json!({"OTIO_SCHEMA":"Track.1","name":name,"kind":kind,"children":children,"source_range":null,"effects":[],"markers":markers,"metadata":{}})}
fn audio_tc(t:&ExportTimeline)->i64{if t.audio.as_ref().is_some_and(|a|a.file.canonical_path==t.video.file.canonical_path){t.source_start_frames}else{0}}
fn transition(frames:i64,rate:EditRate)->Value{
    json!({"OTIO_SCHEMA":"Transition.1","name":"Reviewed dissolve","transition_type":"SMPTE_Dissolve","in_offset":rt(frames/2,rate.fps.as_f64()),"out_offset":rt(frames-frames/2,rate.fps.as_f64()),"metadata":{"automexia":{"reviewed":true}}})
}
fn otio(t:&ExportTimeline)->Result<Vec<u8>>{
    let mut videos=vec![];
    for (i,c) in t.clips.iter().enumerate(){
        let before=if i>0{(t.clips[i-1].record_out-c.record_in).max(0)}else{0};
        let after=if let Some(next)=t.clips.get(i+1){(c.record_out-next.record_in).max(0)}else{0};
        let trim_in=before/2;let trim_out=after-after/2;
        if before>0{videos.push(transition(before,t.rate));}
        videos.push(clip(&c.id,frames(c.source_in+t.source_start_frames+trim_in,c.source_out-c.source_in-trim_in-trim_out,t.rate),ext(&t.video,t.rate.seconds(t.source_start_frames)?)?,&c.id));
    }
    let mut markers=vec![];
    for m in &t.markers{markers.push(json!({"OTIO_SCHEMA":"Marker.2","name":m.name,"color":"GREEN","marked_range":tr(m.at,m.duration)?,"metadata":{"automexia":{"id":m.id,"comment":m.comment}}}));}
    let mut tracks=vec![];
    if let Some(a)=&t.audio{
        let mut children=vec![];let tc=t.rate.seconds(audio_tc(t))?;
        for (i,p) in t.audio_pieces.iter().enumerate(){
            let zero=Rational::new(0,1)?;
            let before=if i>0{t.audio_pieces[i-1].record_start.checked_add(t.audio_pieces[i-1].duration)?.checked_sub(p.record_start)?.max(zero)}else{zero};
            let after=if let Some(next)=t.audio_pieces.get(i+1){p.record_start.checked_add(p.duration)?.checked_sub(next.record_start)?.max(zero)}else{zero};
            let before_frames=t.rate.exact_frames(before)?;let after_frames=t.rate.exact_frames(after)?;
            let trim_in=t.rate.seconds(before_frames/2)?;let trim_out=t.rate.seconds(after_frames-after_frames/2)?;
            let length=p.duration.checked_sub(trim_in)?.checked_sub(trim_out)?;
            if before_frames>0{children.push(transition(before_frames,t.rate));}
            children.push(match p.source_start{Some(s)=>clip(&p.id,tr(s.checked_add(tc)?.checked_add(trim_in)?,length)?,ext(a,tc)?,&p.id),None=>json!({"OTIO_SCHEMA":"Gap.1","name":p.id,"source_range":tr(zero,length)?,"effects":[],"markers":[],"metadata":{}})});
        }
        tracks.push(track("A1","Audio",children,vec![]));
    }
    tracks.push(track("V1","Video",videos,markers));
    bounded_json(&json!({"OTIO_SCHEMA":"Timeline.1","name":t.name,"global_start_time":rt(t.record_start_frames,t.rate.fps.as_f64()),"metadata":{"automexia":{"compatibility":t.report,"exact_edit_rate":t.rate.fps}},"tracks":{"OTIO_SCHEMA":"Stack.1","name":"tracks","children":tracks,"source_range":null,"effects":[],"markers":[],"metadata":{}}}))
}
fn rate_xml(r:EditRate)->String{format!("<rate><timebase>{}</timebase><ntsc>{}</ntsc></rate>",r.nominal(),if r.ntsc(){"TRUE"}else{"FALSE"})}
fn tc_xml(r:EditRate,frame:i64)->Result<String>{Ok(format!("<timecode>{}<string>{}</string><frame>{frame}</frame><displayformat>{}</displayformat></timecode>",rate_xml(r),r.timecode(frame)?,if r.drop_frame{"DF"}else{"NDF"}))}
fn file_xml(t:&ExportTimeline,media:&ReferencedMedia,id:&str,first:bool)->Result<String>{
    if !first{return Ok(format!("<file id=\"{id}\"/>"));}
    let is_video=id=="media-video";
    let audio=if is_video {t.audio.as_ref().filter(|a|a.file.canonical_path==media.file.canonical_path)}else{Some(media)};
    let frames=if is_video{t.rate.exact_frames(media.available_duration)?}else{let x=media.available_duration.checked_div(t.rate.fps.inverse()?)?;x.ceil_units(1)?};
    let name=media.file.canonical_path.file_name().and_then(|s|s.to_str()).ok_or(Error::InvalidInput("interchange media name"))?;
    let mut s=format!("<file id=\"{id}\"><name>{}</name><pathurl>{}</pathurl><duration>{frames}</duration>{}{}<media>",paths::xml(name),paths::xml(&media.url),rate_xml(t.rate),tc_xml(t.rate,if is_video{t.source_start_frames}else{0})?);
    if is_video{
        let _=write!(s,"<video><samplecharacteristics>{}<width>{}</width><height>{}</height><pixelaspectratio>{}</pixelaspectratio><fielddominance>none</fielddominance><anamorphic>FALSE</anamorphic></samplecharacteristics></video>",rate_xml(t.rate),media.width.unwrap_or(0),media.height.unwrap_or(0),if media.sample_aspect==Rational::new(1,1)?{"square"}else{return Err(Error::Unsupported("legacy FCP7 pixel-aspect vocabulary requires a square-pixel bake"));});
    }
    if let Some(a)=audio{let _=write!(s,"<audio><samplecharacteristics><samplerate>{}</samplerate></samplecharacteristics><channelcount>{}</channelcount></audio>",a.sample_rate.ok_or(Error::InvalidProbe("audio sample rate"))?,a.channels.ok_or(Error::InvalidProbe("audio channels"))?);}
    s.push_str("</media></file>");Ok(s)
}
fn link_xml(refid:&str,kind:&str,track:u32,index:usize)->String{
    // Apple FCP7 XML: groupindex belongs to audio links, never video links.
    let group=if kind=="audio" {"<groupindex>1</groupindex>"} else {""};
    format!("<link><linkclipref>{refid}</linkclipref><mediatype>{kind}</mediatype><trackindex>{track}</trackindex><clipindex>{index}</clipindex>{group}</link>")
}
fn fcp7(t:&ExportTimeline)->Result<Vec<u8>>{
    let report=String::from_utf8(t.report.to_json()?).map_err(|_|Error::InvalidOutput("compatibility UTF-8"))?;
    let mut s=format!("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<xmeml version=\"5\"><sequence id=\"sequence-1\"><name>{}</name><duration>{}</duration>{}{}<logginginfo><lognote>{}</lognote></logginginfo>",paths::xml(&t.name),t.duration_frames,rate_xml(t.rate),tc_xml(t.rate,t.record_start_frames)?,paths::xml(&report));
    for m in &t.markers{let start=t.rate.exact_frames(m.at)?;let end=if m.duration.positive(){t.rate.exact_frames(m.at.checked_add(m.duration)?)?}else{-1};let _=write!(s,"<marker><name>{}</name><comment>{}</comment><in>{start}</in><out>{end}</out></marker>",paths::xml(&m.name),paths::xml(&m.comment));}
    let _=write!(s,"<media><video><format><samplecharacteristics>{}<width>{}</width><height>{}</height><pixelaspectratio>square</pixelaspectratio><fielddominance>none</fielddominance><anamorphic>FALSE</anamorphic></samplecharacteristics></format><track>",rate_xml(t.rate),t.video.width.unwrap_or(0),t.video.height.unwrap_or(0));
    for (i,c) in t.clips.iter().enumerate(){
        let _=write!(s,"<clipitem id=\"v{}\"><name>{}</name><enabled>TRUE</enabled><duration>{}</duration>{}<start>{}</start><end>{}</end><in>{}</in><out>{}</out>{}<sourcetrack><mediatype>video</mediatype><trackindex>1</trackindex></sourcetrack>",i+1,paths::xml(&c.id),t.rate.exact_frames(t.video.available_duration)?,rate_xml(t.rate),c.record_in,c.record_out,c.source_in,c.source_out,file_xml(t,&t.video,"media-video",i==0)?);
        s.push_str(&link_xml(&format!("v{}",i+1),"video",1,i+1));
        if let Some(a)=&t.audio{for (j,p) in t.audio_pieces.iter().filter(|p|p.source_start.is_some()).enumerate(){if t.rate.exact_frames(p.record_start)?==c.record_in&&t.rate.exact_frames(p.record_start.checked_add(p.duration)?)?==c.record_out{for channel in 1..=a.channels.unwrap_or(1){s.push_str(&link_xml(&format!("a{channel}-{}",j+1),"audio",channel,j+1));}}}}
        s.push_str("</clipitem>");
    }
    s.push_str("<enabled>TRUE</enabled><locked>FALSE</locked></track></video>");
    if let Some(a)=&t.audio{
        let _=write!(s,"<audio><numOutputChannels>{}</numOutputChannels><format><samplecharacteristics><depth>24</depth><samplerate>{}</samplerate></samplecharacteristics></format>",a.channels.unwrap_or(1),a.sample_rate.unwrap_or(48000));
        for channel in 1..=a.channels.unwrap_or(1){s.push_str("<track>");
            for (j,p) in t.audio_pieces.iter().filter(|p|p.source_start.is_some()).enumerate(){
                let start=t.rate.exact_frames(p.source_start.ok_or(Error::InvalidOutput("audio clip reference"))?)?;let length=t.rate.exact_frames(p.duration)?;
                let ri=t.rate.exact_frames(p.record_start)?;let ro=ri+length;
                let shared=a.file.canonical_path==t.video.file.canonical_path;
                let _=write!(s,"<clipitem id=\"a{channel}-{}\"><name>{}</name><enabled>TRUE</enabled><duration>{}</duration>{}<start>{ri}</start><end>{ro}</end><in>{start}</in><out>{}</out>{}<sourcetrack><mediatype>audio</mediatype><trackindex>{channel}</trackindex></sourcetrack>",j+1,paths::xml(&p.id),a.available_duration.checked_div(t.rate.fps.inverse()?)?.ceil_units(1)?,rate_xml(t.rate),start+length,file_xml(t,a,if shared{"media-video"}else{"media-audio"},!shared&&channel==1&&j==0)?);
                for (i,c) in t.clips.iter().enumerate(){if c.record_in==ri&&c.record_out==ro{s.push_str(&link_xml(&format!("v{}",i+1),"video",1,i+1));}}
                for ch in 1..=a.channels.unwrap_or(1){s.push_str(&link_xml(&format!("a{ch}-{}",j+1),"audio",ch,j+1));}
                s.push_str("</clipitem>");
            }
            s.push_str("<enabled>TRUE</enabled><locked>FALSE</locked></track>");
        }s.push_str("</audio>");
    }
    s.push_str("</media></sequence></xmeml>\n");
    // XML 1.0 excludes U+FFFE/U+FFFF, even though JSON and Rust strings permit
    // them. Never write an apparently successful document an XML reader rejects.
    if s.chars().any(|c|c=='\u{fffe}'||c=='\u{ffff}'||(c<'\u{20}'&&!matches!(c,'\t'|'\n'|'\r'))){return Err(Error::Unsupported("text contains characters not representable in XML 1.0"));}
    Ok(s.into_bytes())
}
fn edl_tc(rate:EditRate,frame:i64)->Result<String>{Ok(rate.timecode(frame)?.replace(';',":"))}
fn edl(t:&ExportTimeline)->Result<Vec<u8>>{
    let mut s=format!("TITLE: {}\nFCM: {}\n\n",t.name,if t.rate.drop_frame{"DROP FRAME"}else{"NON-DROP FRAME"});
    let mut event=0usize;
    for c in &t.clips{event+=1;let _=writeln!(s,"{event:03}  V0000001 V     C        {} {} {} {}",edl_tc(t.rate,c.source_in+t.source_start_frames)?,edl_tc(t.rate,c.source_out+t.source_start_frames)?,edl_tc(t.rate,c.record_in+t.record_start_frames)?,edl_tc(t.rate,c.record_out+t.record_start_frames)?);
        let _=writeln!(s,"* FROM CLIP NAME: {}\n* AMX MEDIA URL: {}\n",paths::comment_escape(t.video.file.canonical_path.file_name().and_then(|v|v.to_str()).unwrap_or("video")),t.video.url);
    }
    if let Some(a)=&t.audio{for p in &t.audio_pieces{if let Some(start)=p.source_start{
        event+=1;let si=t.rate.exact_frames(start)?+audio_tc(t);let d=t.rate.exact_frames(p.duration)?;let ri=t.rate.exact_frames(p.record_start)?+t.record_start_frames;
        let _=writeln!(s,"{event:03}  A0000001 {:<5} C        {} {} {} {}",if a.channels==Some(2){"AA"}else{"A"},edl_tc(t.rate,si)?,edl_tc(t.rate,si+d)?,edl_tc(t.rate,ri)?,edl_tc(t.rate,ri+d)?);
        let _=writeln!(s,"* FROM CLIP NAME: {}\n* AMX MEDIA URL: {}\n",paths::comment_escape(a.file.canonical_path.file_name().and_then(|v|v.to_str()).unwrap_or("audio")),a.url);
    }}}
    for m in &t.markers{let _=writeln!(s,"* AMX MARKER: {} {} {} {}",edl_tc(t.rate,t.rate.exact_frames(m.at)?+t.record_start_frames)?,t.rate.exact_frames(m.duration)?,paths::comment_escape(&m.name),paths::comment_escape(&m.comment));}
    for item in &t.report.items{let _=writeln!(s,"* AMX COMPATIBILITY: {:?} {} {}",item.representation,paths::comment_escape(&item.id),paths::comment_escape(&item.detail));}
    // Embed a line-split ASCII representation of the complete machine report.
    // A normal EDL consumer can ignore these comments; Automexia can recover it.
    let report=paths::comment_escape(&String::from_utf8(t.report.to_json()?).map_err(|_|Error::InvalidOutput("compatibility text"))?);
    for chunk in report.as_bytes().chunks(160){let _=writeln!(s,"* AMX REPORT: {}",std::str::from_utf8(chunk).map_err(|_|Error::InvalidOutput("report encoding"))?);}
    Ok(s.into_bytes())
}
