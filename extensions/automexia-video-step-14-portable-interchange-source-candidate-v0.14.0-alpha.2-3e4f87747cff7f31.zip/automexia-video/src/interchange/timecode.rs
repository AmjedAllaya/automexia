//! Exact frame arithmetic; frame numbers and source PTS are different clocks.
use crate::{Error, Rational, Result};
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct EditRate { pub fps: Rational, pub drop_frame: bool }
impl EditRate {
    pub fn new(fps: Rational, drop_frame: bool) -> Result<Self> {
        let value=Self{fps,drop_frame}; value.validate()?; Ok(value)
    }
    pub fn validate(&self)->Result<()> {
        let (n,d)=(self.fps.numerator(),self.fps.denominator());
        if !matches!((n,d),(24,1)|(25,1)|(30,1)|(48,1)|(50,1)|(60,1)|(24000,1001)|(30000,1001)|(60000,1001)) {
            return Err(Error::Unsupported("interchange rate must be 24/25/30/48/50/60 or 24000/30000/60000 over 1001"));
        }
        if self.drop_frame && !matches!((n,d),(30000,1001)|(60000,1001)) {
            return Err(Error::InvalidInput("drop-frame requires 30000/1001 or 60000/1001"));
        }
        Ok(())
    }
    pub fn nominal(&self)->i64 {if self.fps.denominator()==1001 {self.fps.numerator()/1000} else {self.fps.numerator()}}
    pub fn ntsc(&self)->bool {self.fps.denominator()==1001}
    pub fn exact_frames(&self, seconds:Rational)->Result<i64> {
        self.validate()?;
        let v=seconds.checked_div(self.fps.inverse()?)?;
        if v.denominator()!=1 {return Err(Error::Unsupported("edit boundary is not exactly representable at the export frame rate"));}
        Ok(v.numerator())
    }
    pub fn seconds(&self, frames:i64)->Result<Rational>{self.validate()?; self.fps.inverse()?.ticks(frames)}
    pub fn frames_per_day(&self)->i64 {
        let nominal=self.nominal(); let dropped=if self.drop_frame {nominal/15*54*24} else {0};
        nominal*86400-dropped
    }
    /// SMPTE display labels only. Drop-frame skips labels, never media frames.
    pub fn timecode(&self,frame:i64)->Result<String> {
        self.validate()?;
        if frame<0 || frame>=self.frames_per_day() {return Err(Error::Unsupported("negative or 24-hour-wrapped timecode"));}
        let nominal=self.nominal(); let mut label=frame;
        if self.drop_frame {
            let drop=nominal/15; let ten=nominal*600-drop*9; let minute=nominal*60-drop;
            let blocks=frame/ten; let remaining=frame%ten;
            label+=drop*9*blocks;
            if remaining>=drop {label+=drop*((remaining-drop)/minute);}
        }
        Ok(format!("{:02}:{:02}:{:02}{}{:02}",label/(nominal*3600),(label/(nominal*60))%60,(label/nominal)%60,if self.drop_frame {';'} else {':'},label%nominal))
    }
    pub fn parse_timecode(&self,text:&str)->Result<i64>{
        self.validate()?;
        if text.len()!=11 || !text.is_ascii() {return Err(Error::InvalidInput("timecode must be HH:MM:SS:FF or HH:MM:SS;FF"));}
        let b=text.as_bytes();
        if b[2]!=b':'||b[5]!=b':'||b[8]!=(if self.drop_frame {b';'}else{b':'}) {return Err(Error::InvalidInput("timecode separators disagree with rate"));}
        let pair=|i:usize|->Result<i64>{let p=&b[i..i+2];if !p.iter().all(u8::is_ascii_digit){return Err(Error::InvalidInput("timecode digits"));}Ok(i64::from(p[0]-b'0')*10+i64::from(p[1]-b'0'))};
        let (h,m,s,f)=(pair(0)?,pair(3)?,pair(6)?,pair(9)?);let n=self.nominal();
        if h>23||m>59||s>59||f>=n{return Err(Error::InvalidInput("timecode field range"));}
        let drop=if self.drop_frame {n/15}else{0};
        if self.drop_frame && m%10!=0 && s==0 && f<drop{return Err(Error::InvalidInput("nonexistent drop-frame label"));}
        let minutes=h*60+m;Ok((h*3600+m*60+s)*n+f-drop*(minutes-minutes/10))
    }
}
