//! Bounded FCPXML 1.10 cuts profile, distinct from legacy FCP7 xmeml.
//!
//! Apple references: /documentation/professional-video-applications/
//! document-type-definition, timing-attributes, media-rep, clip, audio.
//! A DTD-valid document is not proof of successful Final Cut Pro import.
use super::*;
use std::fmt::Write;

const MAX_COMPONENTS:usize=MAX_EXPORT_ITEMS*4;

pub(super) fn time(value:Rational)->Result<String>{
    // Apple's time representation has a 64-bit numerator and 32-bit denominator.
    // Refuse an unrepresentable clock instead of rounding to decimal seconds.
    if value.numerator()<0||value.denominator()>i64::from(u32::MAX){return Err(Error::Unsupported("FCPXML requires nonnegative exact clocks with 32-bit denominators"));}
    Ok(if value.denominator()==1{format!("{}s",value.numerator())}else{format!("{value}s")})
}
pub(super) fn attr(value:&str)->Result<String>{
    if value.chars().any(|c|c=='\u{fffe}'||c=='\u{ffff}'||(c<'\u{20}'&&!matches!(c,'\t'|'\n'|'\r'))){return Err(Error::Unsupported("text contains characters not representable in XML 1.0"));}
    // Attribute normalization would otherwise change authored whitespace.
    Ok(paths::xml(value).replace('\t',"&#9;").replace('\n',"&#10;").replace('\r',"&#13;"))
}
pub(super) fn sample_rate(rate:u32)->Result<&'static str>{
    match rate{32000=>Ok("32k"),44100=>Ok("44.1k"),48000=>Ok("48k"),88200=>Ok("88.2k"),96000=>Ok("96k"),176400=>Ok("176.4k"),192000=>Ok("192k"),_=>Err(Error::Unsupported("FCPXML sequence audio rate is outside the explicit 32/44.1/48/88.2/96/176.4/192 kHz profile"))}
}
fn media_name(m:&ReferencedMedia)->Result<&str>{m.file.canonical_path.file_name().and_then(|n|n.to_str()).ok_or(Error::InvalidInput("FCPXML media filename"))}
fn media_url(m:&ReferencedMedia)->Result<String>{
    // The canonical builder creates local file URLs or escaped relative URLs.
    // Also check here because bundle serialization rebases canonical references.
    if m.url.is_empty()||m.url.starts_with('/')||m.url.starts_with("//")||(!m.url.starts_with("file:///")&&m.url.contains(':'))||m.url.contains('\\')||m.url.chars().any(char::is_control){return Err(Error::Unsupported("FCPXML media references must be local file or relative URLs"));}
    attr(&m.url)
}
fn metadata(s:&mut String,key:&str,value:&str)->Result<()>{let _=write!(s,"<md key=\"{}\" value=\"{}\"/>",attr(key)?,attr(value)?);Ok(())}
fn asset(s:&mut String,id:&str,m:&ReferencedMedia,video:bool,audio:Option<&ReferencedMedia>,start:Rational)->Result<()>{
    let duration=audio.map_or(m.available_duration,|a|m.available_duration.max(a.available_duration));
    if !duration.positive(){return Err(Error::InvalidOutput("FCPXML asset duration"));}
    let _=write!(s,"<asset id=\"{id}\" name=\"{}\" start=\"{}\" duration=\"{}\"",attr(media_name(m)?)?,time(start)?,time(duration)?);
    if video{s.push_str(" hasVideo=\"1\" format=\"r-format\" videoSources=\"1\"");}else{s.push_str(" hasVideo=\"0\"");}
    if let Some(a)=audio{
        let channels=a.channels.filter(|n|matches!(*n,1|2)).ok_or(Error::Unsupported("FCPXML selected audio must be mono or stereo"))?;
        let rate=a.sample_rate.ok_or(Error::InvalidOutput("FCPXML audio sample rate"))?;sample_rate(rate)?;
        let _=write!(s," hasAudio=\"1\" audioSources=\"1\" audioChannels=\"{channels}\" audioRate=\"{rate}\"");
    }
    let _=write!(s,"><media-rep kind=\"original-media\" src=\"{}\"/><metadata>",media_url(m)?);
    metadata(s,"org.automexia.media.sha256",&m.file.stamp.sha256)?;
    if let Some(index)=m.video_stream{metadata(s,"org.automexia.media.video-stream-index",&index.to_string())?;}
    if let Some(index)=audio.and_then(|a|a.audio_stream){metadata(s,"org.automexia.media.audio-stream-index",&index.to_string())?;}
    s.push_str("</metadata></asset>");Ok(())
}
fn check_size(s:&str)->Result<()>{if s.len()>MAX_EXPORT_BYTES{Err(Error::LimitExceeded("FCPXML document bytes"))}else{Ok(())}}

fn escaped_len(value:&str)->Result<usize>{
    let mut length=0usize;
    for c in value.chars(){
        let bytes=match c{
            '\u{fffe}'|'\u{ffff}'=>return Err(Error::Unsupported("text contains characters not representable in XML 1.0")),
            '&'=>5,'<'|'>'=>4,'\"'|'\''=>6,'\t'=>4,'\n'|'\r'=>5,
            c if c<'\u{20}'=>return Err(Error::Unsupported("text contains characters not representable in XML 1.0")),
            c=>c.len_utf8(),
        };
        length=length.checked_add(bytes).ok_or(Error::LimitExceeded("FCPXML escaped text bytes"))?;
    }
    Ok(length)
}
fn add_budget(total:&mut usize,extra:usize)->Result<()>{
    *total=total.checked_add(extra).ok_or(Error::LimitExceeded("FCPXML conservative document byte budget"))?;
    if *total>MAX_EXPORT_BYTES{return Err(Error::LimitExceeded("FCPXML conservative document byte budget; reduce markers or authored metadata"));}
    Ok(())
}
/// Conservative pre-publication bound, evaluated before an optional visual bake.
/// It includes the XML-escaped report, final per-request marker report entries,
/// every repeated point marker, both marker metadata fields, and clip/resources.
/// A near-limit valid document may be refused; a bake must not be published only
/// to discover a known document-size failure afterwards. Exact serialization
/// still checks the hard byte limit. This is not a renderer-memory estimate.
pub(super) fn preflight_size(_project:&crate::Project,r:&ExportRequest,timeline:Option<&crate::project::Timeline>,report:&CompatibilityReport)->Result<usize>{
    let json=String::from_utf8(report.to_json()?).map_err(|_|Error::InvalidOutput("FCPXML report UTF-8"))?;
    let mut total=0;add_budget(&mut total,escaped_len(&json)?)?;
    // At most two assets: 4,096-byte local paths/filenames can expand through
    // URI and XML escaping. Also covers the root, format, project title, future
    // baked/audio report notes and the bundle's appended portability warning.
    add_budget(&mut total,256*1024)?;
    // build_export adds one bounded compatibility item per requested marker.
    // IDs are <=64 ASCII bytes; fixed messages plus JSON/XML punctuation are
    // below 2 KiB per item, independent of repeated display text counted below.
    add_budget(&mut total,r.markers.len().checked_mul(2048).ok_or(Error::LimitExceeded("FCPXML marker report bytes"))?)?;
    let Some(t)=timeline else{return Ok(total)};
    let clips=if matches!(r.video,VisualExport::Bake{..}){1}else{t.segments.len()};
    // Each source occurrence has one video and at most one non-silent source or
    // stem component; silent tails emit nothing. Generated IDs, exact 64/32-bit
    // time strings and per-clip metadata wrappers fit inside this 1 KiB reserve.
    add_budget(&mut total,clips.checked_mul(1024).ok_or(Error::LimitExceeded("FCPXML clip bytes"))?)?;
    let zero=Rational::new(0,1)?;let mut mapped_count=0usize;
    for marker in &r.markers{
        // Metadata keeps full exact original ranges (64-bit denominators are
        // permitted there as JSON strings), not merely the one-frame display.
        let longest_time="9223372036854775807/9223372036854775807";
        let longest_id=format!("{}-4096",marker.id);
        let range=serde_json::to_string(&serde_json::json!({"id":longest_id,"at":longest_time,"duration":longest_time,"name":marker.name,"comment":marker.comment}))
            .map_err(|_|Error::InvalidOutput("FCPXML marker range budget"))?;
        let identity=serde_json::to_string(&longest_id).map_err(|_|Error::InvalidOutput("FCPXML marker identity budget"))?;
        let mut per_marker=512usize; // point timing/tag punctuation, JSON commas
        for size in [escaped_len(&marker.name)?,escaped_len(&marker.comment)?,escaped_len(&range)?,escaped_len(&identity)?]{
            per_marker=per_marker.checked_add(size).ok_or(Error::LimitExceeded("FCPXML marker expansion"))?;
        }
        let marker_end=marker.at.checked_add(marker.duration)?;
        for segment in &t.segments{
            let retained=if marker.duration==zero{segment.source_range.contains(marker.at)}else{marker.at.max(segment.source_range.start)<marker_end.min(segment.source_range.end)};
            if retained{
                mapped_count+=1;
                if mapped_count>MAX_MARKERS*4{return Err(Error::LimitExceeded("FCPXML repeated marker budget"));}
                // A bake flattens video, but preserves all mapped occurrences.
                // Counting even markers rounded off its final endpoint is safe.
                add_budget(&mut total,per_marker)?;
            }
        }
    }
    Ok(total)
}

pub(super) fn write(t:&ExportTimeline)->Result<Vec<u8>>{
    t.rate.validate()?;
    if t.duration_frames<=0||t.clips.is_empty(){return Err(Error::EmptyTimeline);}
    if t.clips.len()>MAX_EXPORT_ITEMS||t.audio_pieces.len()>MAX_EXPORT_ITEMS*2||t.markers.len()>MAX_MARKERS*4{return Err(Error::LimitExceeded("FCPXML timeline components"));}
    let zero=Rational::new(0,1)?;let duration=t.rate.seconds(t.duration_frames)?;
    let source_tc=t.rate.seconds(t.source_start_frames)?;let record_tc=t.rate.seconds(t.record_start_frames)?;
    let mut previous=0;
    for c in &t.clips{
        if c.record_in!=previous||c.record_out<=c.record_in||c.source_in<0||c.source_out<=c.source_in||c.source_out.checked_sub(c.source_in)!=c.record_out.checked_sub(c.record_in){return Err(Error::Unsupported("FCPXML cuts profile requires contiguous normal-speed video occurrences; bake retimes or dissolves"));}
        if t.rate.seconds(c.source_out)?>t.video.available_duration{return Err(Error::InvalidOutput("FCPXML video exceeds available media"));}
        previous=c.record_out;
    }
    if previous!=t.duration_frames{return Err(Error::InvalidOutput("FCPXML sequence duration disagrees with clips"));}
    if t.audio.is_none()&&!t.audio_pieces.is_empty(){return Err(Error::InvalidOutput("FCPXML audio components have no asset"));}
    let mut audio_end=zero;
    for p in &t.audio_pieces{
        let end=p.record_start.checked_add(p.duration)?;
        if p.record_start<audio_end||!p.duration.positive()||end>duration{return Err(Error::Unsupported("FCPXML cuts profile requires ordered nonoverlapping bounded audio pieces"));}
        if let Some(start)=p.source_start{
            let a=t.audio.as_ref().ok_or(Error::InvalidOutput("FCPXML audio asset"))?;
            if start<zero||start.checked_add(p.duration)?>a.available_duration{return Err(Error::InvalidOutput("FCPXML audio exceeds available media"));}
        }
        audio_end=end;
    }
    for m in &t.markers{if m.at<zero||m.at>=duration||m.duration<zero||m.at.checked_add(m.duration)?>duration{return Err(Error::InvalidOutput("FCPXML marker outside sequence"));}}
    let width=t.video.width.filter(|v|*v>0).ok_or(Error::InvalidOutput("FCPXML video width"))?;
    let height=t.video.height.filter(|v|*v>0).ok_or(Error::InvalidOutput("FCPXML video height"))?;
    let sar=t.video.sample_aspect;if !sar.positive(){return Err(Error::InvalidOutput("FCPXML pixel aspect"));}
    let shared=t.audio.as_ref().is_some_and(|a|a.file.canonical_path==t.video.file.canonical_path);
    if shared&&t.audio.as_ref().is_some_and(|a|a.file.stamp!=t.video.file.stamp||a.url!=t.video.url){return Err(Error::InvalidOutput("FCPXML shared media identity differs"));}
    let mut s=String::from("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<!DOCTYPE fcpxml>\n<fcpxml version=\"1.10\"><resources>");
    let _=write!(s,"<format id=\"r-format\" frameDuration=\"{}\" width=\"{width}\" height=\"{height}\" fieldOrder=\"progressive\" paspH=\"{}\" paspV=\"{}\"/>",time(t.rate.fps.inverse()?)?,sar.numerator(),sar.denominator());
    asset(&mut s,"r-video",&t.video,true,if shared{t.audio.as_ref()}else{None},source_tc)?;
    if let Some(a)=t.audio.as_ref().filter(|_|!shared){asset(&mut s,"r-audio",a,false,Some(a),zero)?;}
    let _=write!(s,"</resources><library><event name=\"Automexia\"><project name=\"{}\"><sequence format=\"r-format\" duration=\"{}\" tcStart=\"{}\" tcFormat=\"{}\"",attr(&t.name)?,time(duration)?,time(record_tc)?,if t.rate.drop_frame{"DF"}else{"NDF"});
    if let Some(a)=&t.audio{let _=write!(s," audioLayout=\"{}\" audioRate=\"{}\"",if a.channels==Some(1){"mono"}else{"stereo"},sample_rate(a.sample_rate.ok_or(Error::InvalidOutput("FCPXML sample rate"))?)?);}
    s.push_str("><spine>");
    let mut audio_cursor=0;let mut components=0usize;
    let mut markers:Vec<_>=t.markers.iter().collect();markers.sort_by_key(|m|m.at);
    for c in &t.clips{
        let ri=t.rate.seconds(c.record_in)?;let ro=t.rate.seconds(c.record_out)?;
        let local=source_tc.checked_add(t.rate.seconds(c.source_in)?)?;let length=ro.checked_sub(ri)?;
        let _=write!(s,"<clip name=\"{}\" offset=\"{}\" start=\"{}\" duration=\"{}\" format=\"r-format\" tcFormat=\"{}\"><video ref=\"r-video\" offset=\"{}\" start=\"{}\" duration=\"{}\"/>",attr(&c.id)?,time(record_tc.checked_add(ri)?)?,time(local)?,time(length)?,if t.rate.drop_frame{"DF"}else{"NDF"},time(local)?,time(local)?,time(length)?);
        components+=2;
        while audio_cursor<t.audio_pieces.len()&&t.audio_pieces[audio_cursor].record_start.checked_add(t.audio_pieces[audio_cursor].duration)?<=ri{audio_cursor+=1;}
        if let Some(a)=&t.audio{
            for p in t.audio_pieces[audio_cursor..].iter().take_while(|p|p.record_start<ro){
                let Some(source)=p.source_start else{continue};
                let begin=p.record_start.max(ri);let end=p.record_start.checked_add(p.duration)?.min(ro);
                if begin>=end{continue;}
                let offset=local.checked_add(begin.checked_sub(ri)?)?;
                let start=source.checked_add(begin.checked_sub(p.record_start)?)?.checked_add(if shared{source_tc}else{zero})?;
                let _=write!(s,"<audio ref=\"{}\" lane=\"-1\" name=\"{}\" offset=\"{}\" start=\"{}\" duration=\"{}\" srcCh=\"{}\" role=\"dialogue\"/>",if shared{"r-video"}else{"r-audio"},attr(&p.id)?,time(offset)?,time(start)?,time(end.checked_sub(begin)?)?,if a.channels==Some(1){"1"}else{"1,2"});
                components+=1;
            }
        }
        // Apple defines project markers as points with one-frame FCPXML duration.
        // Keep authored range information and occurrence identity in metadata;
        // do not imply that a ranged Automexia marker became a ranged FCP marker.
        let mut marker_ids=Vec::new();let mut marker_ranges=Vec::new();
        for m in markers.iter().take_while(|m|m.at<ro){
            let end=m.at.checked_add(m.duration)?;
            if (m.duration==zero&&m.at<ri)||(m.duration.positive()&&end<=ri){continue;}
            let begin=m.at.max(ri);let length=if m.duration==zero{zero}else{end.min(ro).checked_sub(begin)?};
            t.rate.exact_frames(begin)?;let point_duration=t.rate.fps.inverse()?;
            let _=write!(s,"<marker start=\"{}\" duration=\"{}\" value=\"{}\" note=\"{}\"/>",time(local.checked_add(begin.checked_sub(ri)?)?)?,time(point_duration)?,attr(&m.name)?,attr(&m.comment)?);
            marker_ids.push(m.id.as_str());
            marker_ranges.push(serde_json::json!({"id":m.id,"at":begin,"duration":length,"name":m.name,"comment":m.comment}));components+=1;
        }
        s.push_str("<metadata>");metadata(&mut s,"org.automexia.clip-id",&c.id)?;
        if !marker_ids.is_empty(){
            metadata(&mut s,"org.automexia.marker-ids",&serde_json::to_string(&marker_ids).map_err(|_|Error::InvalidOutput("FCPXML marker identities"))?)?;
            metadata(&mut s,"org.automexia.marker-ranges",&serde_json::to_string(&marker_ranges).map_err(|_|Error::InvalidOutput("FCPXML marker ranges"))?)?;
        }
        s.push_str("</metadata></clip>");
        if components>MAX_COMPONENTS{return Err(Error::LimitExceeded("FCPXML expanded components"));}check_size(&s)?;
    }
    s.push_str("</spine><metadata>");
    metadata(&mut s,"org.automexia.compatibility",&String::from_utf8(t.report.to_json()?).map_err(|_|Error::InvalidOutput("FCPXML report UTF-8"))?)?;
    metadata(&mut s,"org.automexia.fcpxml-profile","1.10 cuts; exact rational clocks; editor import unqualified")?;
    s.push_str("</metadata></sequence></project></event></library></fcpxml>\n");check_size(&s)?;Ok(s.into_bytes())
}

#[cfg(test)]
mod tests{
    use super::*;
    #[test]fn exact_clock_refuses_wide_denominator(){assert!(time(Rational::new(1,i64::from(u32::MAX)+1).unwrap()).is_err());}
    #[test]fn exact_clock_never_uses_float(){assert_eq!(time(Rational::new(1001,30000).unwrap()).unwrap(),"1001/30000s");}
    #[test]fn xml_attribute_whitespace_roundtrips(){assert_eq!(attr("a\n\t\rb").unwrap(),"a&#10;&#9;&#13;b");}
    #[test]fn unsupported_sample_rate_is_not_rounded(){assert!(sample_rate(16000).is_err());assert_eq!(sample_rate(44100).unwrap(),"44.1k");}
    #[test]fn escaped_size_matches_actual_attribute_bytes(){for text in ["plain","<α & β>\"'","\t\n\r","\\&\"\n"]{assert_eq!(escaped_len(text).unwrap(),attr(text).unwrap().len());}}
    #[test]fn budget_includes_the_exact_limit_and_rejects_one_more_byte(){let mut bytes=MAX_EXPORT_BYTES-1;add_budget(&mut bytes,1).unwrap();assert!(add_budget(&mut bytes,1).is_err());}
}
