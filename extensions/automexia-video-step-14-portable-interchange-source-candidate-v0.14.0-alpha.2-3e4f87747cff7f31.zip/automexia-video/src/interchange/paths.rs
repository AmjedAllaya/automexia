use crate::{Error,Result};
use std::path::{Component,Path};
use super::PathMode;

pub fn local_path(path:&Path)->Result<()> {
    let s=path.to_str().ok_or(Error::InvalidInput("interchange paths require UTF-8"))?;
    if !path.is_absolute()||s.len()>4096||s.chars().any(char::is_control)||path.components().any(|c|matches!(c,Component::ParentDir|Component::CurDir)) {
        return Err(Error::InvalidInput("explicit absolute normalized local path required"));
    }
    if s.starts_with("//") {return Err(Error::Unsupported("network media references are not admitted"));}
    if let Some(Component::Prefix(p))=path.components().next(){
        if !matches!(p.kind(),std::path::Prefix::Disk(_)|std::path::Prefix::VerbatimDisk(_)){return Err(Error::Unsupported("network/UNC/device media references are not admitted"));}
    }
    Ok(())
}
fn escape(s:&str,slash:bool)->String {
    let mut out=String::with_capacity(s.len());
    for b in s.as_bytes(){if b.is_ascii_alphanumeric()||b"-._~".contains(b)||(slash&&*b==b'/'){out.push(*b as char);}else{out.push_str(&format!("%{b:02X}"));}}
    out
}
pub fn comment_escape(s:&str)->String{escape(s,false)}
/// References are local file URIs or relative URI references, never executable
/// text. Percent, XML punctuation and UTF-8 bytes are escaped once.
pub fn media_url(media:&Path,export:&Path,mode:PathMode)->Result<String>{
    local_path(media)?;local_path(export)?;
    if mode==PathMode::RelativeToExport {
        let parent=export.parent().ok_or(Error::InvalidInput("export directory"))?;
        let a:Vec<_>=parent.components().collect();let b:Vec<_>=media.components().collect();
        if a.first()!=b.first(){return Err(Error::Unsupported("relative references require one filesystem prefix"));}
        let same=a.iter().zip(&b).take_while(|(x,y)|x==y).count();
        let mut parts=Vec::new();for _ in same..a.len(){parts.push("..".to_owned());}
        for p in &b[same..]{match p {Component::Normal(s)=>parts.push(s.to_str().ok_or(Error::InvalidInput("media path UTF-8"))?.to_owned()),_=>return Err(Error::InvalidInput("relative URI components")),}}
        if parts.is_empty(){return Err(Error::SameFile);}
        return Ok(escape(&parts.join("/"),true));
    }
    let raw=media.to_str().ok_or(Error::InvalidInput("media path UTF-8"))?;
    let raw=if cfg!(windows){raw.strip_prefix("\\\\?\\").unwrap_or(raw)}else{raw};
    let mut s=if cfg!(windows){raw.replace('\\',"/")}else{raw.to_owned()};
    // Windows drive prefix is structural; any other colon is percent-encoded.
    if s.as_bytes().get(1)==Some(&b':'){
        let drive=s.remove(0);s.remove(0);return Ok(format!("file:///{drive}:{}",escape(&s,true)));
    }
    Ok(format!("file://{}",escape(&s,true)))
}
pub fn xml(s:&str)->String{s.replace('&',"&amp;").replace('<',"&lt;").replace('>',"&gt;").replace('"',"&quot;").replace('\'',"&apos;")}
