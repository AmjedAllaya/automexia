//! Optional model assistance on the existing job owner. The standard energy-only
//! path, manual edits, imported captions and rendering need no model provider.
use crate::{Cancellation,Error,Rational,Result,VideoExtension};
use crate::extension::emit;
use crate::host::{InputFile,MediaHost,ProgressSink,RuntimeCapabilities,words};
use crate::model_pack::ModelActivation;
use crate::pause_workflow::{AudioAnalysisHost,PauseAnalysisRequest};
use crate::progress::Stage;
use crate::project::Project;
use crate::speech::{SpeechAnalyzer,SpeechWindowBuffer,SpeechModelProvider,SpeechSettings,SpeechPauseReport,SpeechMediaRuntime,guard_pause_candidates,SPEECH_RATE};
use crate::speech_pipe::SpeechAudioSink;
use std::{ffi::OsString,path::PathBuf,time::{Duration,Instant}};

/// Optional metadata only. Register through the existing host dispatcher ONLY
/// when its explicit model selection and native execution requirements are met.
/// Never append these blindly to the default always-available action list.
pub const SPEECH_ACTIONS:&[crate::extension::ActionDescriptor]=&[
    crate::extension::ActionDescriptor{id:"video.speech.analyze",label:"Protect quiet-interval proposals with a selected local speech model",writes_output:false},
    crate::extension::ActionDescriptor{id:"video.speech.apply",label:"Add model-guarded pause proposals for review",writes_output:false},
];

pub const SPEECH_DECODE_PREFIX:&[&str]=&["-hide_banner","-nostats","-loglevel","info","-nostdin","-xerror","-max_alloc","268435456","-copyts","-threads","2","-protocol_whitelist","file","-format_whitelist","mov,matroska,webm","-i"];
// No asetnsamples/async filler: retain timestamps and reblock in Rust so a hole
// in the source audio cannot become a continuous invented quiet interval.
pub const SPEECH_DECODE_FILTER:&str="pan=mono|c0=c{channel},aresample=16000:async=0,asettb=expr=1/16000,atrim=start_pts={start}:end_pts={end},aformat=sample_fmts=flt,ashowinfo";
#[derive(Debug,Clone)]
pub struct SpeechScan {input:InputFile,stream:u32,channel:u16,origin:Rational,duration:Rational,timeout:Duration}
impl SpeechScan {
    pub fn from_project(project:&Project,input:InputFile,channel:u16,timeout:Duration)->Result<Self>{
        project.validate()?;crate::voice_render::validate_timeout(timeout)?;
        if project.sources.len()!=1{return Err(Error::Unsupported("speech analysis is single-source"));}
        let source=&project.sources[0];source.check_input(&input)?;
        let audio=source.media.audio.as_ref().ok_or(Error::Unsupported("speech analysis requires selected audio"))?;
        let channels=audio.channels.ok_or(Error::InvalidProject("selected audio channel count"))?;
        if channels==0||channels>8||u32::from(channel)>=channels{return Err(Error::InvalidInput("explicit speech-analysis channel"));}
        if !audio.sample_rate.is_some_and(|r|(7350..=192000).contains(&r)){return Err(Error::Unsupported("speech input sample rate"));}
        source.timeline_origin.ceil_units(i64::from(SPEECH_RATE))?;
        source.timeline_origin.checked_add(source.duration)?.ceil_units(i64::from(SPEECH_RATE))?;
        Ok(Self{input,stream:audio.index,channel,origin:source.timeline_origin,duration:source.duration,timeout})
    }
    pub fn input(&self)->&InputFile{&self.input}
    pub fn timeout(&self)->Duration{self.timeout}
    pub fn check_runtime(&self,runtime:&RuntimeCapabilities)->Result<()> {
        for f in ["pan","aresample","asettb","atrim","aformat","ashowinfo"]{if !runtime.filters.contains(f){return Err(Error::MissingCapability("speech decode filters"));}}
        if !runtime.encoders.contains("pcm_f32le")||!runtime.muxers.contains("f32le"){return Err(Error::MissingCapability("speech float PCM sink"));}Ok(())
    }
    pub fn arguments(&self)->Result<Vec<OsString>>{
        let start=self.origin.ceil_units(i64::from(SPEECH_RATE))?;
        let end=self.origin.checked_add(self.duration)?.ceil_units(i64::from(SPEECH_RATE))?;
        let filter=SPEECH_DECODE_FILTER.replace("{channel}",&self.channel.to_string()).replace("{start}",&start.to_string()).replace("{end}",&end.to_string());
        let mut args=words(SPEECH_DECODE_PREFIX);args.push(self.input.canonical_path.as_os_str().to_owned());
        args.extend(words(&["-map",&format!("0:{}",self.stream),"-vn","-sn","-dn","-filter_threads","1","-af",&filter,
            "-c:a","pcm_f32le","-threads:a","1","-map_metadata","-1","-f","f32le","pipe:1"]));Ok(args)
    }
}
pub trait SpeechAudioHost:MediaHost {
    /// Timestamped, mono, 16kHz float packets. Do not reset timestamps, insert
    /// missing samples or normalize amplitude. Nonzero child exit is failure.
    fn stream_speech_audio(&self,scan:&SpeechScan,cancel:&Cancellation,sink:&mut SpeechAudioSink<'_>)->Result<()>;
}
#[derive(Debug,Clone)]
pub struct SpeechPauseRequest {pub energy:PauseAnalysisRequest,pub speech:SpeechSettings}
impl SpeechPauseRequest {
    pub fn new(project_file:impl Into<PathBuf>)->Self{Self{energy:PauseAnalysisRequest::new(project_file),speech:SpeechSettings::default()}}
}
impl<H:MediaHost+AudioAnalysisHost+SpeechAudioHost> VideoExtension<H> {
    /// Runs only after an explicit model selection; no fallback, download, save,
    /// project mutation or automatic render. This method uses two bounded decode
    /// passes (all-channel native-rate energy; one 16kHz speech channel).
    pub fn analyze_speech_pauses(&self,project:&Project,request:&SpeechPauseRequest,
        provider:&dyn SpeechModelProvider,activation:&ModelActivation,cancel:&Cancellation,
        progress:&mut ProgressSink<'_>)->Result<SpeechPauseReport> {
        project.validate()?;request.speech.validate()?;request.energy.settings.validate()?;
        crate::voice_render::validate_timeout(request.energy.timeout)?;
        activation.check()?;
        let provider_identity=checked_provider(||Ok(provider.identity().clone()))?;
        provider_identity.validate()?;
        if provider_identity.contract != crate::model_pack::SILERO_CONTRACT || provider_identity.preprocessing != crate::model_pack::SPEECH_PROCESSING { return Err(Error::Unsupported("speech model identity contract")); }
        if &provider_identity!=activation.identity(){return Err(Error::InputChanged);}
        // A report belongs to the selected model and extension lifetime, not the
        // short-lived job permit (which is cancelled when the job returns).
        let scope=activation.scope(cancel)?;
        let report_owner=self.workflow_scope(&scope)?;
        let started=Instant::now();let total=request.energy.timeout;
        let deadline=started.checked_add(total).ok_or(Error::InvalidInput("speech analysis deadline"))?;
        // Restrict the operation, not the persistent report/selection lifetime.
        // Child energy jobs, model loading, decode and final identity checks all
        // inherit this same deadline rather than restarting a per-stage clock.
        let operation_owner=report_owner.with_deadline(deadline);
        let whole=self.workflow_operation(&operation_owner)?;
        checked_provider(||provider.revalidate(&whole.cancel))?;
        // Validate channel, metadata and access before doing an expensive first pass.
        let source=&project.sources[0];let path=source.resolve(&request.energy.project_file)?;
        let input=self.host().inspect_input(&path,&whole.cancel)?;source.check_input(&input)?;
        let initial=SpeechScan::from_project(project,input,request.speech.analysis_channel,remaining(started,total)?)?;
        let media_caps=self.host().runtime_capabilities(&whole.cancel)?;
        initial.check_runtime(&media_caps)?;let media_identity=SpeechMediaRuntime::capture(&media_caps)?;
        let mut energy_request=request.energy.clone();energy_request.timeout=remaining(started,total)?;
        let baseline=self.analyze_pauses(project,&energy_request,&whole.cancel,progress)?;
        let job=self.begin(&whole.cancel)?;emit(progress,Stage::LoadingModel)?;
        checked_provider(||provider.revalidate(&job.cancel))?;
        let session=checked_provider(||provider.open(&job.cancel))?;job.cancel.check()?;
        if checked_provider(||Ok(session.identity().clone()))?!=*activation.identity(){return Err(Error::InputChanged);}
        let analyzer=SpeechAnalyzer::new(session,activation,request.speech.clone(),source.timeline_origin,source.duration,remaining(started,total)?)?;
        let mut stream=SpeechWindowBuffer::with_timestamp_resolution(analyzer,source.media.audio.as_ref().and_then(|a|a.time_base))?;
        let input=self.host().inspect_input(&path,&job.cancel)?;source.check_input(&input)?;
        let current=self.probe_path(&input.canonical_path,&job.cancel,progress)?;source.check_media(&current)?;
        let scan=SpeechScan::from_project(project,input.clone(),request.speech.analysis_channel,remaining(started,total)?)?;
        scan.check_runtime(&self.host().runtime_capabilities(&job.cancel)?)?;
        emit(progress,Stage::AnalyzingSpeech)?;
        self.host().stream_speech_audio(&scan,&job.cancel,&mut |frame|{
            job.cancel.check()?;remaining(started,total)?;stream.push(frame,&job.cancel)
        })?;
        let observation=stream.finish(&job.cancel)?;checked_provider(||provider.revalidate(&job.cancel))?;
        if checked_provider(||Ok(provider.identity().clone()))?!=provider_identity {return Err(Error::InputChanged);}
        self.host().revalidate_input(&input,&job.cancel)?;remaining(started,total)?;
        let final_runtime=SpeechMediaRuntime::capture(&self.host().runtime_capabilities(&job.cancel)?)?;
        if final_runtime!=media_identity{return Err(Error::ToolIdentityChanged);}
        let report=guard_pause_candidates(baseline,observation,activation,&report_owner,media_identity)?;
        job.cancel.check()?;Ok(report)
    }
}
fn remaining(start:Instant,total:Duration)->Result<Duration>{let v=total.saturating_sub(start.elapsed());if v.is_zero(){Err(Error::Timeout)}else{Ok(v)}}

fn checked_provider<T>(call:impl FnOnce()->Result<T>)->Result<T>{
    std::panic::catch_unwind(std::panic::AssertUnwindSafe(call)).map_err(|_|Error::CallbackPanicked)?
}
