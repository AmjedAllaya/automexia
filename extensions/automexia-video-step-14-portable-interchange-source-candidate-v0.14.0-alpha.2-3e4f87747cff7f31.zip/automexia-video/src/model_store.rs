//! Host-owned local model inventory. Installation and selection are distinct;
//! no operation downloads assets, loads native code, or grants execution rights.
use crate::model_pack::{hash, ModelActivation, ModelIdentity, VerifiedModelPack};
use crate::{Cancellation, Error, Result};
use serde::{Deserialize, Serialize};
use std::collections::{BTreeMap, BTreeSet};
use std::sync::Mutex;

pub const MODEL_INVENTORY_LIMIT: usize = 2 * 1024 * 1024;
pub const MAX_INSTALLED_MODELS: usize = 1024;

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct ModelInventory {
    pub schema: u32,
    /// A compare-and-swap revision for a reviewed inventory/selection UI.
    pub generation: u64,
    pub installed: Vec<ModelIdentity>,
    /// Exact contract -> explicitly selected manifest SHA-256.
    pub selected: BTreeMap<String, String>,
}
impl Default for ModelInventory {
    fn default() -> Self {
        Self { schema: 1, generation: 0, installed: vec![], selected: BTreeMap::new() }
    }
}
impl ModelInventory {
    pub fn from_json(bytes: &[u8]) -> Result<Self> {
        if bytes.is_empty() || bytes.len() > MODEL_INVENTORY_LIMIT {
            return Err(Error::LimitExceeded("model inventory bytes"));
        }
        let value = crate::project_json::parse_unique(bytes)
            .map_err(|_| Error::InvalidInput("invalid or duplicate model inventory JSON"))?;
        let inventory: Self = serde_json::from_value(value)
            .map_err(|_| Error::InvalidInput("model inventory fields"))?;
        inventory.validate()?;
        Ok(inventory)
    }
    pub fn validate(&self) -> Result<()> {
        if self.schema != 1 { return Err(Error::Unsupported("model inventory schema")); }
        if self.installed.len() > MAX_INSTALLED_MODELS || self.selected.len() > MAX_INSTALLED_MODELS {
            return Err(Error::LimitExceeded("installed model count"));
        }
        let mut hashes = BTreeSet::new();
        let mut revisions = BTreeSet::new();
        for identity in &self.installed {
            identity.validate()?;
            if !hashes.insert(&identity.manifest_sha256)
                || !revisions.insert((&identity.id, &identity.revision)) {
                return Err(Error::InvalidInput("duplicate installed model identity"));
            }
        }
        for (contract, manifest) in &self.selected {
            hash(manifest)?;
            if !self.installed.iter().any(|i| &i.contract == contract && &i.manifest_sha256 == manifest) {
                return Err(Error::InvalidInput("selected model is not installed for its contract"));
            }
        }
        Ok(())
    }
    fn next(&self) -> Result<Self> {
        let mut next = self.clone();
        next.generation = next.generation.checked_add(1)
            .ok_or(Error::LimitExceeded("model inventory generation"))?;
        Ok(next)
    }
}

/// The existing component owner supplies storage and protects it from unrelated
/// writers. NativeModelStorage holds an OS advisory lock for its whole lifetime.
/// A failed commit MUST leave the previous inventory authoritative. Once commit
/// succeeds it must return success even if cancellation arrives afterwards.
/// Pack writes are immutable and durable before an inventory may reference them.
pub trait ModelStorage: Send + Sync {
    fn load_inventory(&self, cancel: &Cancellation) -> Result<ModelInventory>;
    fn read_pack(&self, manifest_sha256: &str, cancel: &Cancellation) -> Result<VerifiedModelPack>;
    fn write_pack(&self, pack: &VerifiedModelPack, cancel: &Cancellation) -> Result<()>;
    fn commit_inventory(&self, expected_generation: u64, next: &ModelInventory, cancel: &Cancellation) -> Result<()>;
    /// Called only after removal is committed and all associated activations
    /// are revoked. Existing readers own immutable bytes. False means the files
    /// remain unreferenced and may be retried by an explicit removal operation.
    fn remove_pack(&self, manifest_sha256: &str) -> bool;
}

#[derive(Debug, Clone)]
pub struct ModelSelection { pack: VerifiedModelPack, activation: ModelActivation }
impl ModelSelection {
    pub fn pack(&self) -> &VerifiedModelPack { &self.pack }
    pub fn activation(&self) -> &ModelActivation { &self.activation }
    pub fn check(&self) -> Result<()> { self.activation.check() }
}
#[derive(Debug, Clone)]
pub struct ModelRemoval { pub inventory: ModelInventory, pub files_removed: bool }
struct State { inventory: ModelInventory, active: BTreeMap<String, ModelSelection> }

/// One component-lifetime manager. Readers retain immutable verified bytes;
/// changing or removing selection monotonically revokes every issued activation.
/// Dropping the manager revokes its reports/sessions, without deleting user edits.
pub struct ModelStore<B: ModelStorage> { backend: B, state: Mutex<State> }
impl<B: ModelStorage> ModelStore<B> {
    pub fn open(backend: B, cancel: &Cancellation) -> Result<Self> {
        let inventory = backend.load_inventory(cancel)?;
        inventory.validate()?;
        Ok(Self { backend, state: Mutex::new(State { inventory, active: BTreeMap::new() }) })
    }
    pub fn inventory(&self, cancel: &Cancellation) -> Result<ModelInventory> {
        cancel.check()?;
        Ok(self.state.lock().map_err(|_| Error::Poisoned)?.inventory.clone())
    }
    fn expected(state: &State, generation: u64, cancel: &Cancellation) -> Result<()> {
        cancel.check()?;
        if state.inventory.generation != generation { return Err(Error::InputChanged); }
        Ok(())
    }
    /// Install already verified, explicitly supplied local bytes. Does not select.
    pub fn install(&self, pack: &VerifiedModelPack, expected_generation: u64, cancel: &Cancellation) -> Result<ModelInventory> {
        let mut state = self.state.lock().map_err(|_| Error::Poisoned)?;
        Self::expected(&state, expected_generation, cancel)?;
        if state.inventory.installed.iter().any(|i| i == pack.identity()) {
            self.backend.write_pack(pack, cancel)?;
            return Ok(state.inventory.clone());
        }
        let mut next = state.inventory.next()?;
        next.installed.push(pack.identity().clone());
        next.validate()?;
        self.backend.write_pack(pack, cancel)?;
        self.backend.commit_inventory(expected_generation, &next, cancel)?;
        state.inventory = next.clone();
        Ok(next)
    }
    /// Selection is a separately explicit operation using the exact pinned hash.
    pub fn select(&self, manifest: &str, expected_generation: u64, cancel: &Cancellation) -> Result<ModelSelection> {
        hash(manifest)?;
        let mut state = self.state.lock().map_err(|_| Error::Poisoned)?;
        Self::expected(&state, expected_generation, cancel)?;
        let identity = state.inventory.installed.iter().find(|i| i.manifest_sha256 == manifest)
            .ok_or(Error::InvalidInput("model is not installed"))?.clone();
        let selected = self.load_selection(&identity, cancel)?;
        let mut next = state.inventory.next()?;
        next.selected.insert(identity.contract.clone(), manifest.to_owned());
        self.backend.commit_inventory(expected_generation, &next, cancel)?;
        Self::revoke_contract(&mut state, &identity.contract);
        state.inventory = next;
        state.active.insert(identity.contract, selected.clone());
        Ok(selected)
    }
    /// Acquire the owner's persisted choice; this verifies all three files and
    /// never initializes a runtime. A forged project cannot call this implicitly.
    pub fn selected(&self, contract: &str, cancel: &Cancellation) -> Result<Option<ModelSelection>> {
        cancel.check()?;
        let mut state = self.state.lock().map_err(|_| Error::Poisoned)?;
        let Some(manifest) = state.inventory.selected.get(contract) else { return Ok(None); };
        if let Some(existing) = state.active.get(contract) {
            existing.check()?;
            return Ok(Some(existing.clone()));
        }
        let identity = state.inventory.installed.iter().find(|i| &i.manifest_sha256 == manifest)
            .ok_or(Error::InvalidInput("selected model inventory"))?.clone();
        let selected = self.load_selection(&identity, cancel)?;
        state.active.insert(contract.to_owned(), selected.clone());
        Ok(Some(selected))
    }
    /// Atomic install-and-select with both inventory and previous selection CAS.
    /// The old pack remains installed for a separately reviewed rollback/removal.
    pub fn update_selected(&self, previous_manifest: &str, pack: &VerifiedModelPack, expected_generation: u64, cancel: &Cancellation) -> Result<ModelSelection> {
        hash(previous_manifest)?;
        let mut state = self.state.lock().map_err(|_| Error::Poisoned)?;
        Self::expected(&state, expected_generation, cancel)?;
        let contract = &pack.identity().contract;
        if state.inventory.selected.get(contract).map(String::as_str) != Some(previous_manifest) {
            return Err(Error::InputChanged);
        }
        let previous = state.inventory.installed.iter().find(|i| i.manifest_sha256 == previous_manifest)
            .ok_or(Error::InputChanged)?;
        if previous.id != pack.identity().id { return Err(Error::InvalidInput("model update changes component id")); }
        let mut next = state.inventory.next()?;
        if !next.installed.iter().any(|i| i == pack.identity()) { next.installed.push(pack.identity().clone()); }
        next.selected.insert(contract.clone(), pack.identity().manifest_sha256.clone());
        next.validate()?;
        self.backend.write_pack(pack, cancel)?;
        let selection = ModelSelection { pack: pack.clone(), activation: ModelActivation::selected(pack.identity().clone())? };
        self.backend.commit_inventory(expected_generation, &next, cancel)?;
        Self::revoke_contract(&mut state, contract);
        state.inventory = next;
        state.active.insert(contract.clone(), selection.clone());
        Ok(selection)
    }
    /// Deselect without uninstalling. Failure preserves the current selection.
    pub fn revoke(&self, contract: &str, expected_generation: u64, cancel: &Cancellation) -> Result<ModelInventory> {
        let mut state = self.state.lock().map_err(|_| Error::Poisoned)?;
        Self::expected(&state, expected_generation, cancel)?;
        if !state.inventory.selected.contains_key(contract) { return Ok(state.inventory.clone()); }
        let mut next = state.inventory.next()?;
        next.selected.remove(contract);
        self.backend.commit_inventory(expected_generation, &next, cancel)?;
        Self::revoke_contract(&mut state, contract);
        state.inventory = next.clone();
        Ok(next)
    }
    pub fn remove(&self, manifest: &str, expected_generation: u64, cancel: &Cancellation) -> Result<ModelRemoval> {
        hash(manifest)?;
        let mut state = self.state.lock().map_err(|_| Error::Poisoned)?;
        Self::expected(&state, expected_generation, cancel)?;
        if !state.inventory.installed.iter().any(|i| i.manifest_sha256 == manifest) {
            return Err(Error::InvalidInput("model is not installed"));
        }
        let mut next = state.inventory.next()?;
        next.installed.retain(|i| i.manifest_sha256 != manifest);
        let contracts: Vec<String> = next.selected.iter().filter(|(_, v)| v.as_str() == manifest).map(|(k, _)| k.clone()).collect();
        next.selected.retain(|_, v| v != manifest);
        self.backend.commit_inventory(expected_generation, &next, cancel)?;
        for contract in contracts { Self::revoke_contract(&mut state, &contract); }
        state.inventory = next.clone();
        let files_removed = self.backend.remove_pack(manifest);
        Ok(ModelRemoval { inventory: next, files_removed })
    }
    /// Explicit cleanup of an unreferenced exact digest after a cancelled install
    /// or a removal whose files could not yet be deleted. Never scans for packs.
    pub fn purge_unreferenced(&self, manifest: &str, expected_generation: u64, cancel: &Cancellation) -> Result<bool> {
        hash(manifest)?;
        let state = self.state.lock().map_err(|_| Error::Poisoned)?;
        Self::expected(&state, expected_generation, cancel)?;
        if state.inventory.installed.iter().any(|i| i.manifest_sha256 == manifest) {
            return Err(Error::InvalidInput("cannot purge an installed model"));
        }
        Ok(self.backend.remove_pack(manifest))
    }
    fn load_selection(&self, identity: &ModelIdentity, cancel: &Cancellation) -> Result<ModelSelection> {
        let pack = self.backend.read_pack(&identity.manifest_sha256, cancel)?;
        if pack.identity() != identity { return Err(Error::InputChanged); }
        Ok(ModelSelection { pack, activation: ModelActivation::selected(identity.clone())? })
    }
    fn revoke_contract(state: &mut State, contract: &str) {
        if let Some(previous) = state.active.remove(contract) { previous.activation.revoke(); }
    }
}
impl<B: ModelStorage> Drop for ModelStore<B> {
    fn drop(&mut self) {
        // Recover poisoned state too: shutdown must not leave live capabilities.
        let state = self.state.get_mut().unwrap_or_else(|p| p.into_inner());
        for selection in state.active.values() { selection.activation.revoke(); }
    }
}
