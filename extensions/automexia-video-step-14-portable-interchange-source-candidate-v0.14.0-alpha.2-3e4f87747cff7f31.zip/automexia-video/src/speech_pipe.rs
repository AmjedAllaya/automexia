//! Bounded pairing of FFmpeg ashowinfo headers and float PCM. Transport order
//! across stdout/stderr is arbitrary; either side may arrive first. All retained
//! data is bounded, and unmatched/truncated records fail at EOF.
use crate::{Error,Result};
use crate::speech::{SpeechAudioFrame,SPEECH_RATE};
use std::collections::VecDeque;
pub const MAX_PCM_PENDING:usize=1024*1024;
pub const MAX_PCM_HEADERS:usize=1024;
pub const MAX_DECODE_SAMPLES:usize=8192;
pub type SpeechAudioSink<'a>=dyn FnMut(SpeechAudioFrame)->Result<()>+'a;
#[derive(Debug)] struct Header{pts:i64,samples:usize}
pub struct SpeechPcmPipe<'a,'b> {
    sink:&'a mut SpeechAudioSink<'b>,bytes:VecDeque<u8>,headers:VecDeque<Header>,
    line:Vec<u8>,next:u64,failed:bool,total_log:u64,
}
impl<'a,'b> SpeechPcmPipe<'a,'b> {
    pub fn new(sink:&'a mut SpeechAudioSink<'b>)->Self{Self{sink,bytes:VecDeque::new(),headers:VecDeque::new(),line:vec![],next:0,failed:false,total_log:0}}
    pub fn pcm(&mut self,bytes:&[u8])->Result<()> {
        if self.failed{return Err(Error::InvalidOutput("failed speech transport"));}
        let result=self.pcm_inner(bytes);if result.is_err(){self.failed=true;}result
    }
    fn pcm_inner(&mut self,bytes:&[u8])->Result<()> {
        if self.bytes.len().saturating_add(bytes.len())>MAX_PCM_PENDING{return Err(Error::LimitExceeded("speech PCM pipe skew"));}
        self.bytes.extend(bytes.iter().copied());self.drain()
    }
    pub fn diagnostics(&mut self,bytes:&[u8])->Result<()> {
        if self.failed{return Err(Error::InvalidOutput("failed speech transport"));}
        let result=self.diagnostics_inner(bytes);if result.is_err(){self.failed=true;}result
    }
    fn diagnostics_inner(&mut self,bytes:&[u8])->Result<()> {
        self.total_log=self.total_log.checked_add(bytes.len() as u64).ok_or(Error::LimitExceeded("speech diagnostics"))?;
        // Per-frame headers are expected on long sources; bounded total remains
        // separate from the small outstanding-header and line budgets.
        if self.total_log>1024*1024*1024{return Err(Error::LimitExceeded("speech diagnostics"));}
        for &b in bytes {
            if b==b'\n' {
                let line=std::str::from_utf8(&self.line).map_err(|_|Error::InvalidOutput("speech header UTF-8"))?.to_owned();
                self.line.clear();self.header(&line)?;
            }else{
                if self.line.len()>=4096{return Err(Error::LimitExceeded("speech header line"));}self.line.push(b);
            }
        }self.drain()
    }
    fn header(&mut self,line:&str)->Result<()> {
        if !line.contains("Parsed_ashowinfo_"){return Ok(());}
        let (_,data)=line.split_once("] ").ok_or(Error::InvalidOutput("speech header prefix"))?;
        let mut fields=std::collections::BTreeMap::new();
        for word in data.split_whitespace() {
            if let Some((k,v))=word.split_once(':') {
                if ["n","pts","fmt","channels","chlayout","rate","nb_samples"].contains(&k)
                    && fields.insert(k,v).is_some(){return Err(Error::InvalidOutput("duplicate speech header key"));}
            }
        }
        let number=|key:&str|->Result<u64>{fields.get(key).ok_or(Error::InvalidOutput("missing speech header key"))?
            .parse().map_err(|_|Error::InvalidOutput("speech header integer"))};
        let n=number("n")?;
        if n!=self.next{return Err(Error::InvalidOutput("speech header sequence"));}
        if number("rate")?!=u64::from(SPEECH_RATE)||number("channels")?!=1
            ||fields.get("fmt")!=Some(&"flt")||fields.get("chlayout")!=Some(&"mono"){
            return Err(Error::InvalidOutput("speech PCM format"));
        }
        let pts=fields.get("pts").ok_or(Error::InvalidOutput("missing speech PTS"))?.parse::<i64>()
            .map_err(|_|Error::InvalidOutput("speech PTS"))?;
        let samples=usize::try_from(number("nb_samples")?).map_err(|_|Error::LimitExceeded("speech PCM samples"))?;
        if samples==0||samples>MAX_DECODE_SAMPLES{return Err(Error::LimitExceeded("speech PCM frame samples"));}
        if self.headers.len()>=MAX_PCM_HEADERS{return Err(Error::LimitExceeded("speech header pipe skew"));}
        self.headers.push_back(Header{pts,samples});self.next=self.next.checked_add(1).ok_or(Error::LimitExceeded("speech header count"))?;
        self.drain()
    }
    fn drain(&mut self)->Result<()> {
        while let Some(header)=self.headers.front() {
            let length=header.samples*4;if self.bytes.len()<length{break;}
            let header=self.headers.pop_front().ok_or(Error::InvalidOutput("speech header queue"))?;
            let mut samples=Vec::with_capacity(header.samples);
            for _ in 0..header.samples {
                let mut value=[0u8;4];for byte in &mut value{*byte=self.bytes.pop_front().ok_or(Error::InvalidOutput("speech PCM queue"))?;}
                let v=f32::from_le_bytes(value);
                if !v.is_finite()||v.abs()>8.0{return Err(Error::InvalidOutput("speech PCM nonfinite/out-of-range"));}
                samples.push(v);
            }
            (self.sink)(SpeechAudioFrame{pts:header.pts,samples})?;
        }Ok(())
    }
    pub fn finish(self)->Result<()> {
        if self.failed{return Err(Error::InvalidOutput("failed speech transport"));}
        if !self.line.is_empty()||!self.headers.is_empty()||!self.bytes.is_empty()||self.next==0{
            return Err(Error::InvalidOutput("truncated/unmatched speech PCM transport"));
        }Ok(())
    }
}
