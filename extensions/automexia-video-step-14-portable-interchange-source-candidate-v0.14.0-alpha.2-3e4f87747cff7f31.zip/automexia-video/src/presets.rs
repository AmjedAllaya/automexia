//! Strict configuration resolution. Presets contain settings, not approvals.
use crate::{Error, Result};
use crate::{delivery::{DeliveryFormat, DeliveryProfile, RenderIntent}, project::Project};
use crate::{pause::PauseSettings, voice::VoiceSettings, color::ColorSettings, plan::FrameRateMode};
use serde::{Deserialize, Serialize};
use serde_json::{json, Value};

pub const MAX_CONFIG_BYTES: usize = 64 * 1024;
pub const WORKFLOW_REVISION: u32 = 1;
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all="snake_case")]
pub enum EditPreset { Clean, Social, Podcast }
impl EditPreset {
    pub fn name(self) -> &'static str { match self { Self::Clean=>"clean", Self::Social=>"social", Self::Podcast=>"podcast" } }
    fn patch(self) -> Value {
        let (pause,voice) = match self { Self::Clean=>(PauseSettings::clean(),VoiceSettings::clean()), Self::Social=>(PauseSettings::social(),VoiceSettings::social()), Self::Podcast=>(PauseSettings::podcast(),VoiceSettings::podcast()) };
        let mut p = serde_json::to_value(pause).expect("finite built-in pause preset");
        let mut v = serde_json::to_value(voice).expect("finite built-in voice preset");
        // Editorial defaults may override editorial settings, not user evidence.
        for key in ["content","allow_mixed_music_proposals"] {p.as_object_mut().unwrap().remove(key);}
        for key in ["content","noise_confirmed"] {v.as_object_mut().unwrap().remove(key);}
        json!({"analyze_pauses":true,"analyze_voice":true,"analyze_color":self!=Self::Podcast,
            "pause_settings":p,"voice_settings":v})
    }
}
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct WorkflowSettings {
    pub analyze_pauses: bool,
    pub analyze_voice: bool,
    pub analyze_color: bool,
    pub pause_settings: PauseSettings,
    pub voice_settings: VoiceSettings,
    pub color_settings: ColorSettings,
    pub frame_rate: FrameRateMode,
    pub output: DeliveryProfile,
}
impl Default for WorkflowSettings {
    fn default() -> Self {Self {analyze_pauses:false,analyze_voice:false,analyze_color:false,
        pause_settings:PauseSettings::clean(),voice_settings:VoiceSettings::clean(),color_settings:ColorSettings::default(),
        frame_rate:FrameRateMode::PreserveTimestamps,output:DeliveryProfile::preset(RenderIntent::Publish,None)}}
}
impl WorkflowSettings {
    pub fn validate(&self)->Result<()> {
        self.pause_settings.validate()?;self.voice_settings.validate()?;self.color_settings.validate()?;self.output.validate()?;
        crate::RenderOptions{frame_rate:self.frame_rate,..Default::default()}.validate()
    }
}
/// A bounded, duplicate-key-rejecting partial JSON object. Missing keys inherit;
/// null is a value, not a remove/execute instruction. No untyped object reaches a runner.
#[derive(Debug, Clone)]
pub struct WorkflowPatch { value: Value }
impl WorkflowPatch {
    pub fn from_json(bytes:&[u8])->Result<Self> {
        if bytes.len()>MAX_CONFIG_BYTES{return Err(Error::LimitExceeded("workflow configuration bytes"));}
        let value=crate::project_json::parse_unique(bytes)?;
        if !value.is_object(){return Err(Error::InvalidInput("workflow patch must be an object"));}
        let patch=Self{value};
        // Catch unknown keys even in a layer later overridden by another layer.
        let mut probe=serde_json::to_value(WorkflowSettings::default()).map_err(|_|Error::InvalidInput("default config"))?;
        merge(&mut probe,&patch.value,0)?;
        let parsed:WorkflowSettings=serde_json::from_value(probe).map_err(|_|Error::InvalidInput("unknown or invalid workflow setting"))?;
        parsed.validate()?;
        Ok(patch)
    }
    pub fn render_mode(intent:RenderIntent,format:Option<DeliveryFormat>)->Result<Self>{
        let value=json!({"output":DeliveryProfile::preset(intent,format)});
        Self::from_json(&serde_json::to_vec(&value).map_err(|_|Error::InvalidInput("output config"))?)
    }
}
#[derive(Debug,Clone,Serialize,Deserialize)]
#[serde(deny_unknown_fields)]
pub struct WorkflowSnapshot {
    pub revision:u32,
    pub preset:Option<EditPreset>,
    pub preset_revision:Option<u32>,
    pub settings:WorkflowSettings,
}
impl WorkflowSnapshot {
    pub fn validate(&self)->Result<()> {
        if self.revision!=WORKFLOW_REVISION || self.preset_revision!=self.preset.map(|_|1) {return Err(Error::InvalidProject("workflow/preset revision"));}
        self.settings.validate()
    }
    /// Explicit configuration change. It does not regenerate, approve, or
    /// replace any accepted cut, cleanup, color, framing or presentation decision.
    pub fn apply(&self,project:&mut Project,variant:&str)->Result<()> {
        self.validate()?;project.variant(variant)?;
        project.edit(|p|{
            p.settings.workflow=Some(self.clone());
            p.settings.preset_name=self.preset.map(|s|s.name().into());
            p.settings.preset_revision=self.preset_revision.map(|v|v.to_string());
            let v=p.variants.iter_mut().find(|v|v.id==variant).ok_or(Error::InvalidProject("unknown variant"))?;
            v.output_profile=Some(self.settings.output.clone());v.render.frame_rate=self.settings.frame_rate;
            Ok(())
        })
    }
}
/// defaults < user < project < named preset < explicit overrides.
/// The complete result is stored once; render/retry never consult this resolver.
pub fn resolve_workflow(user:Option<&WorkflowPatch>,project:Option<&WorkflowPatch>,preset:Option<EditPreset>,overrides:Option<&WorkflowPatch>)->Result<WorkflowSnapshot>{
    let mut value=serde_json::to_value(WorkflowSettings::default()).map_err(|_|Error::InvalidInput("default configuration"))?;
    for patch in [user,project].into_iter().flatten(){merge(&mut value,&patch.value,0)?;}
    if let Some(preset)=preset{merge(&mut value,&preset.patch(),0)?;}
    if let Some(overrides)=overrides{merge(&mut value,&overrides.value,0)?;}
    let settings:WorkflowSettings=serde_json::from_value(value).map_err(|_|Error::InvalidInput("unknown or invalid resolved setting"))?;
    let snapshot=WorkflowSnapshot{revision:WORKFLOW_REVISION,preset,preset_revision:preset.map(|_|1),settings};
    snapshot.validate()?;Ok(snapshot)
}
fn merge(base:&mut Value,patch:&Value,depth:usize)->Result<()> {
    if depth>16{return Err(Error::LimitExceeded("configuration nesting"));}
    match (base,patch) {
        (Value::Object(base),Value::Object(patch))=>{
            for (key,value) in patch {
                let slot=base.get_mut(key).ok_or(Error::InvalidInput("unknown configuration field"))?;
                // Tagged alternatives replace together rather than leaving a stale
                // `rate` when changing CFR back to passthrough (and vice versa).
                if key=="frame_rate" { *slot=value.clone(); } else {merge(slot,value,depth+1)?;}
            }
        },
        (base,patch)=>*base=patch.clone(),
    }
    Ok(())
}
