//! Exact edit-clock mapping and a bounded transparent-image timeline.
//! Raster preparation is delegated to an explicit host capability.
use crate::{Error,Result,Rational,Cancellation};
use crate::presentation::*;
use crate::project::{Project,Timeline,TimeRange};
use crate::edit_render::EditRender;
use crate::reframe::{OutputSize,PixelRect};
use crate::host::RuntimeCapabilities;
use serde::Serialize;
use std::{collections::BTreeSet,path::{Path,PathBuf}};

// The independent FFmpeg harness uses this exact template from the Rust source.
// Overlay frames are private generated PNGs in a generated concat manifest.
// Main video controls frame timing. A transparent terminal sample prevents
// repeat-last from extending a caption, and no overlay is permitted to extend video.
pub const COMPOSITE_GRAPH:&str="[pres_base]scale=in_color_matrix=bt709:in_range={range}:out_range=pc,format=rgb24[pres_rgb];[1:v]setsar=sar={sar}:max=1000000,format=rgba[pres_overlay];[pres_rgb][pres_overlay]overlay=format=rgb:eof_action=pass:repeatlast=0:shortest=0:alpha=straight,scale=out_color_matrix=bt709:out_range={range},format=yuv420p[vout]";
pub const GRAPHICS_INPUT:&[&str]=&["-protocol_whitelist","file","-format_whitelist","concat,png_pipe","-f","concat","-safe","0","-i"];
#[derive(Debug,Clone,Serialize)]
pub struct GraphicEvent {
    pub id:String,pub range:TimeRange,pub source_range:TimeRange,
    pub animation_origin:Rational,pub animation_duration:Rational,
    pub content:GraphicContent,pub placement:Placement,pub animation:Animation,
}
impl GraphicEvent {
    pub fn elapsed(&self,output_time:Rational)->Result<Rational>{self.source_range.start.checked_add(output_time.checked_sub(self.range.start)?.checked_mul(self.source_range.duration()?)?.checked_div(self.range.duration()?)?)?.checked_sub(self.animation_origin)}
}
#[derive(Debug,Clone,Serialize)]
pub struct PresentationRender {
    pub settings:PresentationSettings,pub encoded:OutputSize,pub canvas:OutputSize,pub sar:Rational,
    pub duration:Rational,pub source_duration:Rational,pub source_origin:Rational,
    pub timeline:Timeline,pub events:Vec<GraphicEvent>,pub mapped_captions:Vec<crate::subtitles::MappedCue>,
    /// Reordered, repeated, retimed or dissolved branches use already composed
    /// source frames, including source-volume keys.
    pub source_composition:bool,pub source_time_base:Rational,
}
impl PresentationRender {
    pub fn from_project(project:&Project,variant:&str,edit:&EditRender,encoded:OutputSize,sar:Rational,runtime:&RuntimeCapabilities)->Result<Option<Self>>{
        let mut settings=match &project.variant(variant)?.presentation{Some(p)=>p.clone(),None=>return Ok(None)};
        settings.ensure_resolved()?;if !settings.active(){return Ok(None);}
        if let Some(f)=project.variant(variant)?.framing.as_ref().filter(|f|f.active()) {
            let g=f.safe_zone;settings.safe_zone.left=settings.safe_zone.left.max(g.left);settings.safe_zone.right=settings.safe_zone.right.max(g.right);
            settings.safe_zone.top=settings.safe_zone.top.max(g.top);settings.safe_zone.bottom=settings.safe_zone.bottom.max(g.bottom);
        }
        let source=&project.sources[0];settings.validate(source.duration)?;
        let source_composition=edit.requires_branching();
        let source_time_base=match source.media.video.time_base{Some(tb)=>tb,None if source_composition&&settings.has_pixels()=>return Err(Error::InvalidProject("presentation source time base")),None=>Rational::new(1,1_000_000)?};
        let video=&source.media.video;
        if settings.has_pixels() {
            if video.color_space.as_deref()!=Some("bt709")||video.color_transfer.as_deref()!=Some("bt709")||video.color_primaries.as_deref()!=Some("bt709"){
                return Err(Error::Unsupported("graphics composition requires explicit Rec.709 source tags"));
            }
            for filter in ["scale","format","setsar","overlay"]{if !runtime.filters.contains(filter){return Err(Error::MissingCapability("presentation composition filters"));}}
        }
        if settings.volume.is_some()&&source.media.audio.is_none(){return Err(Error::InvalidProject("volume keys require selected audio"));}
        if settings.volume.is_some()&&!runtime.filters.contains("volume"){return Err(Error::MissingCapability("volume filter"));}
        if settings.fades.is_some()&&!runtime.filters.contains("fade"){return Err(Error::MissingCapability("fade filter"));}
        // Draw at square display pixels, then resample to the encoded raster.
        // This avoids distorted glyphs on anamorphic/non-square-pixel outputs.
        let dw=Rational::new(i64::from(encoded.width),1)?.checked_div(sar.inverse()?)?.nearest_units(1)?;
        let width=u32::try_from(dw.checked_add(1).ok_or(Error::LimitExceeded("display canvas width"))?/2*2).map_err(|_|Error::LimitExceeded("display canvas width"))?;
        let canvas=OutputSize::new(width,encoded.height)?;settings.validate_layout(canvas)?;
        let output_timeline=effective_timeline(edit)?;
        if let Some(captions)=&mut settings.captions{captions.document=captions.document.for_timeline(&output_timeline,&source.id)?;}
        let mapped_captions=settings.captions.as_ref().map(|c|c.document.remap(&output_timeline,&source.id)).transpose()?.unwrap_or_default();
        let timeline=if source_composition{Timeline{duration:source.duration,segments:vec![crate::project::TimelineSegment{source_id:source.id.clone(),source_range:TimeRange::new(Rational::new(0,1)?,source.duration)?,output_range:TimeRange::new(Rational::new(0,1)?,source.duration)?}]}}else{output_timeline.clone()};
        // A source compositor sees only the union of retained ranges, so removed
        // graphics cannot trigger collisions/state budgets and repeated ranges
        // cannot duplicate the same source image or restart its animation.
        let event_timeline=if source_composition {
            Timeline{duration:source.duration,segments:crate::subtitles::retained_source_ranges(&output_timeline,&source.id)?.into_iter().map(|range|crate::project::TimelineSegment{source_id:source.id.clone(),source_range:range,output_range:range}).collect()}
        }else{timeline.clone()};
        let mut events=Vec::new();
        for overlay in &settings.overlays {if !overlay.enabled{continue;}
            map_event(&mut events,&event_timeline,&overlay.id,overlay.range,&overlay.content,&overlay.placement,&overlay.animation)?;
        }
        if let Some(c)=&settings.captions{if c.burn_in {for cue in &c.document.cues {
            let content=GraphicContent::Text{text:cue.text.clone(),style:c.style.clone().ok_or(Error::InvalidProject("caption style"))?};
            map_event(&mut events,&event_timeline,&format!("caption-{}",cue.id),cue.range,&content,c.placement.as_ref().ok_or(Error::InvalidProject("caption placement"))?,&Animation::default())?;
        }}}
        if events.len()>crate::subtitles::MAX_CUES*4+MAX_OVERLAYS*128{return Err(Error::LimitExceeded("mapped presentation events"));}
        let plan=Self{settings:settings.clone(),encoded,canvas,sar,duration:if source_composition{source.duration}else{edit.duration},source_duration:source.duration,source_origin:source.timeline_origin,timeline,events,mapped_captions,source_composition,source_time_base};
        plan.validate_collisions()?;plan.sample_times()?;Ok(Some(plan))
    }
    pub fn has_pixels(&self)->bool{!self.events.is_empty()}
    pub fn rect(&self,event:&GraphicEvent,time:Rational)->Result<(PixelRect,f64)> {
        let base=event.placement.rect(self.canvas,self.settings.safe_zone)?;
        let state=event.animation.state(event.elapsed(time)?,event.animation_duration)?;
        let width=(f64::from(base.width)*state.scale).round().max(1.0) as u32;
        let height=(f64::from(base.height)*state.scale).round().max(1.0) as u32;
        let x=(f64::from(base.x)+(f64::from(base.width)-f64::from(width))/2.0+state.dx).round();
        let y=(f64::from(base.y)+(f64::from(base.height)-f64::from(height))/2.0+state.dy).round();
        if !x.is_finite()||!y.is_finite()||x<0.0||y<0.0||x+f64::from(width)>f64::from(self.canvas.width)||y+f64::from(height)>f64::from(self.canvas.height){return Err(Error::InvalidProject("graphic animation raster bounds"));}
        let safe=self.settings.safe_zone.pixels(self.canvas)?;
        if x<f64::from(safe.x)||y<f64::from(safe.y)||x+f64::from(width)>f64::from(safe.x+safe.width)||y+f64::from(height)>f64::from(safe.y+safe.height){return Err(Error::InvalidProject("rounded graphic leaves safe zone"));}
        Ok((PixelRect{x:x as u32,y:y as u32,width,height},state.opacity))
    }
    /// All cue edges are exact microsecond events; only continuous animation is
    /// sampled at an explicit, persisted rate. This is not motion interpolation.
    pub fn sample_times(&self)->Result<Vec<i64>> {
        let end=self.duration.ceil_units(1_000_000)?;let mut times=BTreeSet::new();times.insert(0);times.insert(end);
        for e in &self.events {
            let start=e.range.start.nearest_units(1_000_000)?.max(0);let finish=e.range.end.nearest_units(1_000_000)?.min(end);
            if start>=finish{continue;}times.insert(start);times.insert(finish);
            if e.animation.moving(){
                let first=(start as i128*i128::from(self.settings.raster.animation_fps)+999999)/1000000;
                let mut n=first;loop {let t=i64::try_from((n*1000000)/i128::from(self.settings.raster.animation_fps)).map_err(|_|Error::LimitExceeded("animation clock"))?;
                    if t>=finish{break;}if t>=start{times.insert(t);}n+=1;
                    if times.len()>self.settings.raster.max_states{return Err(Error::LimitExceeded("graphics animation states; shorten animations or lower sampling rate"));}
                }
                // Boundaries within a cut preserve their SOURCE animation phase.
                for k in &e.animation.keys {
                    let at=e.animation_origin.checked_add(k.at)?;
                    if e.source_range.contains(at){times.insert(e.range.start.checked_add(at.checked_sub(e.source_range.start)?.checked_mul(e.range.duration()?)?.checked_div(e.source_range.duration()?)?)?.nearest_units(1_000_000)?);}
                }
            }
            if times.len()>self.settings.raster.max_states{return Err(Error::LimitExceeded("graphics state count"));}
        }if times.len()>self.settings.raster.max_states{return Err(Error::LimitExceeded("graphics state count"));}Ok(times.into_iter().collect())
    }
    pub fn validate_collisions(&self)->Result<()> {
        // Closed-world collisions: supplied overlays/captions only. No claim to
        // recognize faces, existing source text or arbitrary objects.
        // Conservatively compare whole animation envelopes during overlapping time.
        if self.settings.collisions==CollisionPolicy::AllowReviewed{return Ok(());}
        let mut ordered:Vec<_>=self.events.iter().collect();ordered.sort_by_key(|e|e.range.start);
        let mut comparisons=0usize;
        for (i,a) in ordered.iter().enumerate(){for b in ordered.iter().skip(i+1){
            if b.range.start>=a.range.end{break;}
            comparisons+=1;if comparisons>1_000_000{return Err(Error::LimitExceeded("simultaneous graphic collision comparisons"));}
            if !a.range.overlaps(&b.range){continue;}
            let ra=envelope(a,self.canvas,self.settings.safe_zone)?;let rb=envelope(b,self.canvas,self.settings.safe_zone)?;
            if intersects(ra,rb){return Err(Error::InvalidProject("known graphic/caption collision: reposition, retime or use a combined graphic"));}
        }}Ok(())
    }
    pub(crate) fn video_filter(&self)->Result<String>{
        let f=match &self.settings.fades{Some(f)=>f,None=>return Ok(String::new())};
        // Shift only for the fade's clock, then restore source origin before the
        // existing edit mapping. A preview fragment does not restart either fade.
        let mut filters=vec![format!("setpts=PTS-({})/TB",self.source_origin)];
        if f.fade_in.positive(){filters.push(format!("fade=t=in:st=0:d={:.9}",f.fade_in.as_f64()));}
        if f.fade_out.positive(){filters.push(format!("fade=t=out:st={:.9}:d={:.9}",self.source_duration.checked_sub(f.fade_out)?.as_f64(),f.fade_out.as_f64()));}
        filters.push(format!("setpts=PTS+({})/TB",self.source_origin));Ok(filters.join(","))
    }
    /// Composes on source time before trim/rate/dissolve, retaining the original
    /// video clock after the overlay framesync. Only trusted plan-built filters
    /// and integer stream indices enter this private graph constructor.
    pub(crate) fn source_composite_graph(&self,video:u32,graphics_input:usize,source_filters:&str,full_range:bool)->Result<String>{
        if !self.source_composition||!self.has_pixels(){return Err(Error::InvalidInput("source composition plan"));}
        if self.source_time_base<Rational::new(1,1_000_000)?{return Err(Error::Unsupported("source graphics require a source clock at least one microsecond per tick"));}
        let ticks=self.source_origin.checked_div(self.source_time_base)?;
        if ticks.denominator()!=1{return Err(Error::Unsupported("source graphics require source origin on the video clock"));}
        let prefix=if source_filters.is_empty(){String::new()}else{format!("{source_filters},")};
        let base=format!("[0:{video}]{prefix}settb=expr={},setpts=PTS-({}),settb=expr=1/1000000[pres_base]",self.source_time_base,ticks.numerator());
        let composite=COMPOSITE_GRAPH.replace("{range}",if full_range{"pc"}else{"tv"}).replace("{sar}",&self.sar.to_string()).replace("[1:v]",&format!("[{graphics_input}:v]")).replace("[vout]","[pres_composed]");
        let graph=format!("{base};{composite};[pres_composed]settb=expr={},setpts=PTS+({})[pres_source]",self.source_time_base,ticks.numerator());
        if graph.len()>32*1024{return Err(Error::LimitExceeded("source presentation filter graph"));}Ok(graph)
    }
    /// Source-time attenuation runs before sample trimming, speed and overlap.
    /// Enhanced PCM supplies zero here; untouched source audio supplies its saved
    /// timeline origin. The caller owns comma placement in the audio pre-chain.
    pub(crate) fn source_volume_filter(&self,origin:Rational)->Result<String>{
        if !self.source_composition{return Ok(String::new());}
        let Some(volume)=&self.settings.volume else{return Ok(String::new())};
        let expression=volume.expression(&format!("t-({origin})"));
        if expression.len()>16*1024{return Err(Error::LimitExceeded("source volume expression"));}
        Ok(format!("volume='{expression}':eval=frame:precision=double"))
    }
    pub(crate) fn volume_filter(&self)->Result<String>{
        if self.source_composition{return Ok(String::new());}
        let volume=match &self.settings.volume{Some(v)=>v,None=>return Ok(String::new())};
        let mut clock="0".to_owned();
        for s in self.timeline.segments.iter().rev(){let speed=s.source_range.duration()?.checked_div(s.output_range.duration()?)?.as_f64();
            clock=format!("if(lt(t,{:.9}),(t-({:.9}))*{speed:.9}+({:.9}),{clock})",s.output_range.end.as_f64(),s.output_range.start.as_f64(),s.source_range.start.as_f64());}
        let expression=volume.expression(&clock);
        if expression.len()>16*1024{return Err(Error::LimitExceeded("volume expression"));}
        Ok(format!(",volume='{expression}':eval=frame:precision=double"))
    }
}
/// Millisecond sidecars and the image clock derive from the same microsecond
/// shift used by the renderer. The source ranges remain exact in .amxv.
pub fn effective_timeline(edit:&EditRender)->Result<Timeline>{
    // This exact affine map is authoritative for captions and animation. Video
    // expressions quantize only at the final microsecond clock boundary.
    Ok(edit.requested.clone())
}

fn map_event(result:&mut Vec<GraphicEvent>,timeline:&Timeline,id:&str,range:TimeRange,content:&GraphicContent,placement:&Placement,animation:&Animation)->Result<()> {
    for s in &timeline.segments {let start=range.start.max(s.source_range.start);let end=range.end.min(s.source_range.end);if start>=end{continue;}
        if result.len()>=crate::subtitles::MAX_CUES*4+MAX_OVERLAYS*128{return Err(Error::LimitExceeded("mapped presentation events"));}
        result.push(GraphicEvent{id:id.into(),source_range:TimeRange::new(start,end)?,range:TimeRange::new(s.output_range.start.checked_add(start.checked_sub(s.source_range.start)?.checked_mul(s.output_range.duration()?)?.checked_div(s.source_range.duration()?)?)?,s.output_range.start.checked_add(end.checked_sub(s.source_range.start)?.checked_mul(s.output_range.duration()?)?.checked_div(s.source_range.duration()?)?)?)?,animation_origin:range.start,animation_duration:range.duration()?,content:content.clone(),placement:placement.clone(),animation:animation.clone()});
    }Ok(())
}
fn envelope(e:&GraphicEvent,canvas:OutputSize,safe:crate::reframe::SafeZone)->Result<PixelRect>{
    let base=e.placement.rect(canvas,safe)?;let mut left=f64::from(base.x);let mut top=f64::from(base.y);let mut right=f64::from(base.x+base.width);let mut bottom=f64::from(base.y+base.height);
    for k in &e.animation.keys{let w=f64::from(base.width)*k.scale;let h=f64::from(base.height)*k.scale;let x=f64::from(base.x)+(f64::from(base.width)-w)/2.0+f64::from(k.dx);let y=f64::from(base.y)+(f64::from(base.height)-h)/2.0+f64::from(k.dy);
        left=left.min(x);top=top.min(y);right=right.max(x+w);bottom=bottom.max(y+h);}
    if left<0.0||top<0.0{return Err(Error::InvalidProject("graphic envelope"));}
    Ok(PixelRect{x:left.floor() as u32,y:top.floor() as u32,width:(right.ceil()-left.floor()) as u32,height:(bottom.ceil()-top.floor()) as u32})
}
fn intersects(a:PixelRect,b:PixelRect)->bool{a.x<b.x+b.width&&b.x<a.x+a.width&&a.y<b.y+b.height&&b.y<a.y+a.height}

/// A temporary sequence is never a delivery video. Keep the lease alive until
/// rendering completes. Hosts must authorize selected assets and private paths.
pub trait PresentationLease:Send {
    fn sequence_path(&self)->&Path;
    fn revalidate(&self,destination:Option<&Path>,cancel:&Cancellation)->Result<()>;
    fn bytes(&self)->u64;
    fn receipts(&self)->&[AssetReceipt];
}
#[derive(Debug,Clone,Serialize)]
pub struct AssetReceipt {pub path:PathBuf,pub sha256:String,pub size:u64,pub renderer:String,pub font_family:Option<String>}
