//! Explicit RNNoise speech enhancement through the existing host audio executor.
//! No runtime/model discovery, download, process scheduler or background owner.
use crate::{Cancellation,Error,Result,Rational};
use crate::enhancement::{EnhancementIdentity,EnhancementMode,EnhancementReceipt,EnhancementRequest,EnhancementStrength,SpeechEnhancer};
use crate::host::{InputFile,MediaHost,ProgressSink,RuntimeCapabilities,words};
use crate::model_pack::{ModelActivation,VerifiedModelPack,RNNOISE_CONTRACT,RNNOISE_PROCESSING};
use std::{ffi::OsString,fs::File,io::Write,path::{Path,PathBuf},time::{Duration,Instant}};

/// One supported RNNoise frame (10 ms at 48 kHz). Padding flushes the delayed
/// tail before trimming this many leading samples. FFmpeg 7.1 is the admitted
/// production clock contract; qualification includes a delayed-dry impulse.
pub const RNNOISE_RATE:u32=48_000;
pub const RNNOISE_DELAY_SAMPLES:u32=480;

pub struct NativeRnnoiseEnhancer<'a,H:MediaHost> {
    host:&'a H,
    pack:VerifiedModelPack,
    activation:ModelActivation,
    identity:EnhancementIdentity,
}
impl<'a,H:MediaHost> NativeRnnoiseEnhancer<'a,H> {
    pub fn new(host:&'a H,pack:VerifiedModelPack,activation:ModelActivation,cancel:&Cancellation)->Result<Self> {
        activation.check()?;cancel.check()?;
        if pack.identity()!=activation.identity() {return Err(Error::InputChanged);}
        if pack.identity().contract!=RNNOISE_CONTRACT||pack.identity().preprocessing!=RNNOISE_PROCESSING {
            return Err(Error::Unsupported("selected model does not implement RNNoise preprocessing"));
        }
        crate::model_pack::check_rnnoise_model(pack.weights(),cancel)?;
        let identity=EnhancementIdentity{engine:"ffmpeg-arnndn".into(),engine_version:concat!(env!("CARGO_PKG_VERSION"),"/rnnoise-frame480-v1").into(),runtime:format!("ffmpeg-sha256:{}",pack.identity().runtime.artifact_sha256),model_id:Some(pack.identity().id.clone()),model_sha256:Some(pack.identity().weights_sha256.clone())};
        identity.validate()?;
        let provider=Self{host,pack,activation,identity};provider.revalidate(cancel)?;Ok(provider)
    }
    fn runtime(&self,cancel:&Cancellation)->Result<RuntimeCapabilities> {
        let runtime=self.host.runtime_capabilities(cancel)?;
        let selected=&self.pack.identity().runtime;
        if selected.adapter!="ffmpeg-arnndn" || runtime.ffmpeg_identity.as_deref()!=Some(selected.artifact_sha256.as_str())
            ||crate::model_pack::digest(runtime.ffmpeg_version.as_bytes(),cancel)?!=selected.build_info_sha256 {
            return Err(Error::ToolIdentityChanged);
        }
        if !crate::voice_render::afftdn_timing_qualified(&runtime.ffmpeg_version) {
            return Err(Error::Unsupported("RNNoise sample-delay contract requires FFmpeg 7.1"));
        }
        if ["arnndn","asetpts","aresample","aformat","apad","atrim"].iter().any(|filter|!runtime.filters.contains(*filter))
            ||!runtime.encoders.contains("pcm_s24le")||!runtime.muxers.contains("wav") {
            return Err(Error::MissingCapability("RNNoise selected-layout PCM24 audio chain"));
        }
        Ok(runtime)
    }
}
impl<H:MediaHost> SpeechEnhancer for NativeRnnoiseEnhancer<'_,H> {
    fn identity(&self)->Result<EnhancementIdentity>{self.activation.check()?;Ok(self.identity.clone())}
    fn revalidate(&self,cancel:&Cancellation)->Result<()> {
        let scope=self.activation.scope(cancel)?;self.runtime(&scope)?;scope.check()
    }
    fn enhance(&self,request:&EnhancementRequest,cancel:&Cancellation,progress:&mut ProgressSink<'_>)->Result<EnhancementReceipt> {
        request.validate()?;
        if request.settings.mode!=EnhancementMode::Learned {
            return Err(Error::InvalidInput("RNNoise requires explicit learned speech enhancement"));
        }
        let start=Instant::now();
        let deadline=start.checked_add(request.timeout).ok_or(Error::InvalidInput("RNNoise deadline overflow"))?;
        let scope=self.activation.scope(cancel)?.with_deadline(deadline);self.revalidate(&scope)?;
        let remaining=||->Result<Duration>{let t=request.timeout.saturating_sub(start.elapsed());if t.is_zero(){Err(Error::Timeout)}else{Ok(t)}};
        self.host.revalidate_input(&request.source,&scope)?;
        let parent=request.staged_output.parent().ok_or(Error::InvalidInput("enhancement staged parent"))?;
        let private=crate::native::private_tempdir("rnnoise-",Some(parent)).map_err(|_|Error::Io("create private RNNoise lease"))?;
        let model_path=private.path().join("selected.rnnn");
        let mut file=File::create(&model_path).map_err(|_|Error::Io("create private RNNoise model"))?;
        for chunk in self.pack.weights().chunks(64*1024) {scope.check()?;remaining()?;file.write_all(chunk).map_err(|_|Error::Io("write private RNNoise model"))?;}
        file.sync_all().map_err(|_|Error::Io("sync private RNNoise model"))?;drop(file);
        let model=self.host.inspect_input(&model_path,&scope)?;
        if model.stamp.sha256!=self.pack.identity().weights_sha256||model.stamp.size!=self.pack.weights().len() as u64 {return Err(Error::InputChanged);}
        let task=RnnoiseTask::new(request,model,remaining()?)?;
        self.host.run_audio(&crate::voice_render::AudioTask::EnhanceRnnoise{task},&scope,progress)?;
        self.host.revalidate_input(&request.source,&scope)?;self.revalidate(&scope)?;remaining()?;scope.check()?;
        let receipt=EnhancementReceipt{identity:self.identity.clone(),sample_rate:request.sample_rate,channels:request.channels,channel_layout:request.channel_layout.clone(),source_samples:request.source_samples,output_samples:request.source_samples,delay_samples:0,peak_dbfs:None,warnings:vec![
            "Explicit RNNoise speech enhancement may remove desired speech detail; compare the untreated side before applying.".into(),
            "Channels retain their selected layout; each channel is processed independently at 48 kHz, with a compensated 480-sample RNNoise delay and the exact original sample count restored.".into(),
        ]};receipt.validate(&request.settings)?;Ok(receipt)
    }
}

/// A bounded typed task. The verified private model lease remains alive in the
/// provider until the host executor has revalidated and finished this operation.
#[derive(Debug,Clone)]
pub struct RnnoiseTask {input:InputFile,model:InputFile,stream:u32,rate:u32,channels:u32,layout:String,samples:u64,origin:Rational,strength:EnhancementStrength,output:PathBuf,timeout:Duration}
impl RnnoiseTask {
    fn new(request:&EnhancementRequest,model:InputFile,timeout:Duration)->Result<Self> {
        request.validate()?;
        let task=Self{input:request.source.clone(),model,stream:request.stream_index,rate:request.sample_rate,channels:request.channels,layout:request.channel_layout.clone(),samples:request.source_samples,origin:request.source_origin,strength:request.settings.strength,output:request.staged_output.clone(),timeout};task.arguments()?;Ok(task)
    }
    pub fn input(&self)->&InputFile {&self.input}
    pub fn model(&self)->&InputFile {&self.model}
    pub fn output(&self)->&Path {&self.output}
    pub fn timeout(&self)->Duration {self.timeout}
    pub fn maximum_bytes(&self)->Result<u64>{self.samples.checked_mul(u64::from(self.channels)).and_then(|n|n.checked_mul(3)).and_then(|n|n.checked_add(1024*1024)).ok_or(Error::LimitExceeded("RNNoise output byte limit"))}
    pub fn arguments(&self)->Result<Vec<OsString>> {
        crate::voice_render::validate_timeout(self.timeout)?;
        if self.input.canonical_path==self.output||self.model.canonical_path==self.output{return Err(Error::SameFile);}
        let mix=match self.strength{EnhancementStrength::Gentle=>"0.35",EnhancementStrength::Balanced=>"0.65",EnhancementStrength::Strong=>"1"};
        let model=escape_filter_path(&self.model.canonical_path)?;
        let filter=format!("asetpts=PTS-({}/{})/TB,aresample={}:async=1:first_pts=0,apad=whole_len={},atrim=end_sample={},aformat=channel_layouts={},aresample=48000,apad=pad_len=480,arnndn=m={model}:mix={mix},atrim=start_sample=480,asetpts=PTS-STARTPTS,aresample={},aformat=sample_rates={}:channel_layouts={},apad=whole_len={},atrim=end_sample={}",self.origin.numerator(),self.origin.denominator(),self.rate,self.samples,self.samples,self.layout,self.rate,self.rate,self.layout,self.samples,self.samples);
        let mut args=words(&["-hide_banner","-loglevel","error","-nostdin","-xerror","-max_alloc","268435456","-y","-copyts","-threads","2","-protocol_whitelist","file","-format_whitelist","mov,matroska,webm","-i"]);
        args.push(self.input.canonical_path.as_os_str().to_owned());
        args.extend(words(&["-map",&format!("0:{}",self.stream),"-vn","-sn","-dn","-map_metadata","-1","-map_chapters","-1","-filter_threads","1","-af",&filter,"-c:a","pcm_s24le","-threads:a","1","-rf64","auto","-progress","pipe:1","-nostats","-f","wav"]));args.push(self.output.as_os_str().to_owned());
        if args.iter().map(|a|a.as_encoded_bytes().len()+1).sum::<usize>()>30*1024{return Err(Error::LimitExceeded("RNNoise arguments"));}Ok(args)
    }
}
fn escape_filter_path(path:&Path)->Result<String> {
    let text=path.to_str().ok_or(Error::Unsupported("RNNoise model path requires UTF-8"))?;
    if !path.is_absolute()||text.len()>4096||text.chars().any(char::is_control){return Err(Error::InvalidInput("RNNoise model path"));}
    // FFmpeg parses the option value and then the filter graph. Escape each
    // layer independently; no shell is involved.
    let option=text.chars().flat_map(|c|if matches!(c,'\\'|'\''|':'){vec!['\\',c]}else{vec![c]}).collect::<String>();
    Ok(option.chars().flat_map(|c|if matches!(c,'\\'|'\''|'['|']'|','|';'){vec!['\\',c]}else{vec![c]}).collect())
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::host::FileStamp;
    fn input(name:&str)->InputFile{InputFile{canonical_path:std::env::temp_dir().join("rnnoise-contract").join(name),stamp:FileStamp{size:1024,modified_ns:None,sha256:"a".repeat(64),file_id:None}}}
    fn task()->RnnoiseTask{RnnoiseTask{input:input("source.mov"),model:input("selected.rnnn"),stream:1,rate:44100,channels:2,layout:"stereo".into(),samples:88200,origin:Rational::new(5,1).unwrap(),strength:EnhancementStrength::Balanced,output:input("staged.wav").canonical_path,timeout:Duration::from_secs(10)}}
    #[test]fn task_compensates_origin_and_model_latency_before_restoring_exact_layout(){let args=task().arguments().unwrap();let filter=args.windows(2).find(|pair|pair[0]=="-af").unwrap()[1].to_str().unwrap();assert!(filter.starts_with("asetpts=PTS-(5/1)/TB,aresample=44100:async=1:first_pts=0"));assert!(filter.contains("apad=pad_len=480,arnndn=m="));assert!(filter.contains("mix=0.65,atrim=start_sample=480,asetpts=PTS-STARTPTS"));assert!(filter.ends_with("aformat=sample_rates=44100:channel_layouts=stereo,apad=whole_len=88200,atrim=end_sample=88200"));}
    #[test]fn output_bound_uses_original_rate_and_channel_count(){assert_eq!(task().maximum_bytes().unwrap(),88200*2*3+1024*1024);}
    #[test]fn refuses_source_or_model_output_collision(){let mut task=task();task.output=task.input.canonical_path.clone();assert_eq!(task.arguments(),Err(Error::SameFile));task.output=task.model.canonical_path.clone();assert_eq!(task.arguments(),Err(Error::SameFile));}
    #[test]fn model_path_uses_two_parser_escape_layers(){let path=std::env::temp_dir().join("comma,colon:quote'bracket[semi;back\\slash").join("selected.rnnn");let escaped=escape_filter_path(&path).unwrap();assert!(escaped.contains("\\,"));assert!(escaped.contains("\\\\:"));assert!(escaped.contains("\\["));assert!(escaped.contains("\\;"));}
}
