# Step 9 review and verification history

## Baseline and scope

This implementation was rebuilt from the verified Step 8 delivery-repair archive,
SHA-256 `4c723c365b24455963a4e8943b8efe0f3f2acdb20be18c0434fc3fd5c557febc`.
It does not recover or validate the missing Step 9 archives announced in earlier
responses. Work remains in one Video crate and uses its existing host boundaries.

## Pass 1 — implementation and independent media checks

Implemented typed delivery profiles, strict layered settings, project snapshots,
schema migration, sequential delivery, JSON events and explicit run orchestration.
The first independent FFmpeg delivery pass recorded **26 passed / 14 failed**.
The failures were investigated, not hidden by treating an encoder exit as success:

- Eight profile metadata checks: the generated input did not actually retain all
  intended Rec.709 tags. The fixture now supplies the required encoder tags, and
  output checks continue to require the source's actual metadata.
- One rotation check: the fixture's `rotate` metadata did not create a display
  matrix. The fixture now uses an input display-rotation override and checks the
  rotated output dimensions.
- One non-square-pixel WebM check: Matroska/WebM integer display dimensions really
  quantize this ratio. The source validation now permits at most one display pixel
  for non-square pixel ratios, reports the exception, and remains strict for
  square-pixel compositions. It does not silently change crop geometry.
- Four flash/tone checks: the test raw decoder was duplicating frames while the
  timestamp list described original decoded frames. The test now uses passthrough
  timing, asserts equal counts, and compares the actual decoded onsets.

See [first-pass results](../reports/step9/media-pass1.json) and
[corrected results](../reports/step9/media-pass2.json). The corrected 40-case run
passed. These are independent command-recipe checks, not execution of Rust code.

## Pass 2 — failure, cancellation and retry source review

Review found that fail-fast could discard a previously completed target's receipt
before that target was revisited. Unvisited rows now retain the old receipt without
being declared newly validated. A later retry reopens and checks that file instead
of rerendering it. The same applies when revalidation itself is cancelled.

Publication and receipt capture are separate. A committed file with a failed
receipt read is `published_unverified`, not a failed attempt known to have created
nothing. It is never automatically overwritten. Observer panics after publication
preserve committed results and stop further work. An extension lifetime token
prevents disable/re-enable from reviving a suspended run between its child jobs.

Added Rust mock-host tests exercise these branches, strict result deserialization,
stale requests, changed/missing outputs, bounded attempts and unresolved approvals.
They are supplied but **not run** because no Rust toolchain is available.

## Pass 3 — integration and persistence source review

- Reject invalid settings in an overridden lower layer, not only the final merge.
- Preserve explicit per-variant encoding choices in `run_workflow`.
- Apply a workflow snapshot to an open review without discarding unsaved edits.
- Report compact observed output properties with the actual encoding runtime.
- Keep an empty or malformed manually constructed report from returning success.
- Reject schema-7 delivery-history fields masquerading as an older project schema.
- Add tests ensuring output-option replacement leaves the private graphics input,
  its demuxer flags, the filter graph and literal output path intact.
- Keep old project fields optional, and migrate known schemas without introducing
  any new automatic analysis or approvals.

No compiler/typechecker was available to execute these source assertions. Review
is not equivalent to compilation. Existing unrelated implementation limitations
remain documented rather than being marked fixed by Step 9.

## Regression execution and interruption handling

The import/cut/preview/pause/audio/scene/framing/presentation and new delivery
scripts are rerun against this source. Two command-window interruptions occurred
while running the longer retained suites; their partial runs were **not counted**.
The preview and audio scripts were rerun through completion. Final complete reports,
not an interrupted log, determine the totals in
[verification.json](../reports/step9/verification.json).

The packaging regression suite and the immutable delivery gate are separate from
application/media checks. A fresh extracted ZIP is rechecked independently, and
links are emitted only by the gate after reopening the final files.

The final CI review also found an embedded Python re-verification command still
expecting Step 8 after the shell build command had advanced to Step 9. Both
expectations now explicitly require Step 9 / 0.9.0; a fixture-based smoke execution
checks the build-result-to-receipt sequence. No remote CI execution is claimed.

## What is not proven

Rust compilation, type correctness, mock/native Cargo tests, actual terminal UI,
hardware encoding, Windows/macOS, subjective visual/listening quality, long-recording
stress and concurrent hostile-filesystem behavior are not established here.
The source continues to implement the inherited SDR scope; a ProRes output is not
an HDR qualification. Shared-decode batching remains an explicit optimization to
qualify later, and is not necessary for the implemented sequential reference path.
