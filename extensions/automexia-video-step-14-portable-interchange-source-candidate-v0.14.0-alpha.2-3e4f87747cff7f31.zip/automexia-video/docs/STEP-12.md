# Step 12 — targeted pre-AI modernization

**Version:** 0.12.0-rc.1. **Project schema:** 7, unchanged. **Product:** the same Automexia Video extension core; no Kubernetes work, new terminal framework or models.

**Verification boundary:** implemented Rust source with supplied crate/native regression tests. Rust and Cargo are unavailable in this execution environment. Neither the inherited crate nor these changes have been compiled or typechecked here. Independently executed FFmpeg recipes and source/delivery checks do not replace Rust tests. Step 11's actual-host, release, editor-import and recorded-footage qualifications remain open. Step 13 is not started by this source delivery.

[Roadmap](video-roadmap.md#step-12--final-non-ai-milestone-targeted-modernization-before-ai) · [Review log](STEP-12-REVIEW.md) · [Manual checks](STEP-12-MANUAL.md) · [Current results](../reports/step12/verification.json)

## 1. What changed and why

Inspection found three concrete ownership/cost problems, rather than a reason to split every feature into a library:

| Finding in the retained code | Implemented change |
|---|---|
| Native capability discovery ran six child-process queries on every call. | Per-native-host capability memo. Hits still fingerprint both executable files; no global cache. |
| Admission, active jobs and cancellation lifetime were managed using separate fields/locks in the extension. | One private job registry owns admission, lifetime cancellation and drain. An explicit workflow lease covers the gaps between child stages. |
| Repeat pause, voice and color scans had no reusable observation owner. | Optional, caller-owned, bounded in-memory cache storing typed source facts, not old projects or accepted decisions. |
| Native byte-pipe process lifecycle was embedded in a large filesystem/publication module. | Extracted a private subprocess transport module, retaining the existing native adapter and request interfaces. |
| Hosts could need to accumulate progress events for a UI queue. | Optional single-slot progress mailbox; terminal outcomes remain returned receipts, never coalesced progress. |

We kept one Cargo package and its existing feature gates. No project/time/render/interchange crate was extracted: there is no independently demonstrated consumer or measured dependency benefit justifying that additional compatibility boundary. The original domain models, serializer, editing/render algorithms and interchange writer are retained.

[Baseline file identities](../reports/step12/baseline.json) pin the complete Step 11 input. [Dependency baseline](../reports/step12/contract-baseline.json) records the unchanged dependency/feature configuration. These are source baselines, not proof of runtime quality.

## 2. Ownership, cancellation and drain

`src/lifecycle.rs` is private. `VideoExtension` keeps its existing `new`, `status`, `enable`, `disable` and `cancel_all` methods. A single mutex protects admission, enabled state, active job identities, tracked multi-stage workflows and lifetime changes. A condition variable is notified when work returns; no polling worker/thread is created.

A job permit releases its admission slot and cancels its child token on every return path, including unwinding. Poison recovery in Drop prevents stranding a slot. Ordinary operational calls return `Error::Poisoned` instead of pretending the state is healthy.

`run_workflow` now holds a separate workflow lease for the whole call. Its individual media stages still use the normal job limit. The lease prevents the gap between create/analyze/save/render calls from looking like complete shutdown. It is not another executor or job queue.

New operation:

```rust
let drained = video.disable_and_drain(std::time::Duration::from_secs(5))?;
if !drained.complete {
    // Keep native code and host owners alive. Await the host's remaining workers.
    eprintln!("jobs={}, workflows={}", drained.remaining_jobs, drained.remaining_workflows);
}
```

A zero timeout disables and polls once. A positive timeout waits up to the requested bound, subject to normal mutex/OS scheduling. Timeout leaves the extension disabled and reports remaining jobs/workflows; it is never reported as success. `enable` returns Busy while a disabled owner still has active work or a drain is in progress. Once work returns, re-enable starts a new cancellation lifetime. Old reviews/caches/workflows cannot revive. `cancel_all` cancels the old generation while leaving the current enabled/disabled state unchanged.

Call drain from the host's lifecycle worker, **not from a progress callback within an admitted operation**. The latter would wait for itself until timeout. Drain is not safe-to-unload proof: the host must also join its worker threads and close retained player, preview, cache, I/O and dynamic-library handles. Cancellation is cooperative; it does not forcibly terminate a blocking host callback. The registry is dropped before the host field, so its cancellation signals are issued before host teardown.

## 3. Reusable observations, not reusable authority

Existing `analyze_pauses`, `analyze_voice` and `analyze_color` remain uncached. The opt-in methods add only a caller-supplied cache parameter:

```rust
let mut cache = video.observation_cache(CacheLimits::default())?;
let request = PauseAnalysisRequest::new(&project_location);
let first = video.analyze_pauses_cached(
    &project, &request, &mut cache, &cancel, &mut progress)?;
let repeat = video.analyze_pauses_cached(
    &project, &request, &mut cache, &cancel, &mut progress)?;
// repeat.cache can be Hit. repeat.report is newly bound to THIS project's decisions.
```

Equivalent `analyze_voice_cached` and `analyze_color_cached` methods exist. Cache construction performs no filesystem access, process startup, allocation of the maximum cache capacity, network activity or model loading.

### Stored data

| Kind | Retained facts | Not retained |
|---|---|---|
| Pause | Per-source quiet intervals and bounded energy summary | A previous accepted cut list, review approval or rendered audio |
| Voice | Per-channel preflight facts and original full-source loudness | A previous cleanup decision or loudness gain for an edited timeline |
| Color | Per-shot intervals, boundary kind, signal statistics and scan dimensions/count | Accepted color parameters, locks or previous approvals |

Every cache hit reruns the existing deterministic recommendation/report constructor against the **current** project. Manual protections, locks, rejected decisions and current review bindings therefore remain authoritative. A hit never applies, saves, approves, renders or exports a decision.

Before either a hit or a miss, the workflow uses the existing host to inspect the current locator, compare full source size/content SHA-256 and probe the selected technical metadata. It checks required runtime capabilities and revalidates the input again before returning. A cached measurement is not a file-access grant. A revoked permission, changed source or incompatible metadata cannot be bypassed by a hit.

The cache key includes source size/content digest, selected video/audio metadata, source origin/duration, observation kind and algorithm revision, all requested settings, relevant explicit boundaries, and the runtime capability record. Both tool executable identities must be supplied as full lowercase SHA-256 values. Missing/invalid runtime pins decline reuse (`UnpinnedRuntime`) and run a fresh scan. No fast fingerprint is promoted to a high-integrity identity.

The key deliberately excludes path, project ID/revision and edit decisions. An authorized relocation of identical footage can reuse observations; the new proposal is still bound to the relocated/current project. Changing streams, settings, source technical interpretation or runtime identity causes a miss. Settings are conservatively keyed as a whole; changing even a proposal-only option may require a new scan.

Full-source voice loudness is cached only as an observation. Actual rendering still remeasures the exact cleaned, assembled signal through the unchanged `prepare_voice` path. Cutting footage never reuses an obsolete full-source gain.

### Bounds and eviction

Defaults: 16 entries, 8 MiB charged payload, 1 MiB per entry. Maximum configurable entry count is 64 and maximum charged payload 64 MiB. Key serialization is streamed into SHA-256 with a 1 MiB ceiling instead of allocating a whole key JSON string. Least-recently-used entries are evicted by count and charged bytes. Oversized entries are not retained; valid analysis still returns `MissNotStored` without evicting useful entries merely to fail admission.

Accounting includes the inline entry/value, source digest capacity and retained observation-vector/string capacities. B-tree/allocator bookkeeping, cache-owner signals, transient parser allocations, cloned return reports and caller-held references are **not a total-process RSS budget**. Audio/frame input limits remain enforced by the existing analyzers and native runner.

`clear` and `invalidate_source` release retained values. An owner-cancelled cache clears on its next access and rejects use; the host should drop it immediately on workspace revocation or unload, rather than relying on a future access. The cache is not a background observer of permission changes. Use one cache per trusted host ownership domain; `ObservationCache::new` is explicitly caller-owned and `video.observation_cache` follows the extension lifetime.

Status meanings: `Disabled`, `UnpinnedRuntime`, `Hit`, `MissStored`, `MissNotStored`. Hit/miss counters count lookups, not successful user operations or performance measurements. Failed/truncated scans store nothing. Entry data is private typed memory; there is no arbitrary serialized cache import or disk-cache format in this step.

## 4. Native process transport

`src/native/runner.rs` is now the sole production `Command::new` owner. Filesystem grants, inspected file identities, staging/publication and the typed `MediaHost` surface remain in their existing owners. Default builds do not gain native I/O.

The transport retains separate argv tokens and a cleared child environment. Added request admission caps are 4,096 arguments and 4 MiB aggregate encoded argument bytes including terminators; NUL is rejected before spawn. OS-specific command-size limits can be tighter and produce an explicit launch error. No shell command or arbitrary executable is exposed through this module.

Two pipe readers feed one bounded queue of 16 chunks, each at most 8,192 bytes (128 KiB queued payload). Each reader and the active consumer hold additional bounded chunks; this is not a whole-process memory limit. Existing stdout, diagnostic/progress, media parser and output-size bounds remain. Raw RGB/PCM is handed directly to typed consumers, not placed into JSON progress messages.

Child cleanup ownership and channel receivers now unwind **inside** the scoped-thread body. On callback error/panic, cancellation, deadline, read error or reader-start failure, the child is stopped and the receiver dropped before scoped readers are joined. This avoids a child/pipe-reader deadlock during unwinding. Deadline timing begins before spawn, and a child that closes both pipes but continues running is still polled with a deadline. The runner does not signal a reaped PID again.

Unix process-group termination and the existing direct-child path are retained; Windows job-object containment is not newly implemented. OS process creation, uninterruptible kernel I/O and a host callback that itself never returns are not hard real-time bounded by this cooperative mechanism. Do not label it an OS sandbox.

## 5. Runtime capability memo

Each `NativeMediaHost` memoizes its six version/encoder/muxer/filter/bitstream-filter queries after successful completion and before/after executable fingerprint checks. Subsequent calls rehash both pinned tools before returning cached capability data. Cancelled/failed discovery never populates the memo. Replaced executables cause `ToolIdentityChanged`, not automatic repinning.

No memo lock is held while hashing or running subprocesses. Two simultaneous first calls may perform duplicate bounded discovery; avoiding a long cancellation-blocking lock takes priority over perfect first-call coalescing.

This memo assumes the **effective runtime environment is immutable for the native host's lifetime**. Executable hashes do not cover dynamically linked libraries, OS/GPU drivers or codecs installed outside those files. After any such dependency update, the host must drop/recreate the native adapter and observation cache (and perform its runtime qualification). This step does not claim a complete binary dependency attestation system or hardware capability cache.

## 6. One-slot progress bridge

`progress_mailbox(cancel)` creates a cloneable `ProgressSender` and a single owner `ProgressReceiver`. Publishing replaces the last unconsumed progress item; `take` retrieves it. A counter reports overwritten intermediate updates. Cancellation remains out-of-band and clears/refuses obsolete events. Dropping/closing the receiver invalidates all senders for that pair. A fresh host request uses a fresh pair; old senders cannot publish into it.

Only the fixed-size `Progress` structure travels through this mailbox. Final errors, publication outcomes, file receipts and authorizations must remain on their existing return/control path. `encoding_finished` does not mean output validation/publication succeeded. There is no worker, callback registration, timer, UI polling loop or terminal event binding inside this helper.

## 7. Integration and compatibility

No required or optional `MediaHost`, `ProjectStore`, `AudioAnalysisHost` or player method signature changes. No action ID changes, no project-schema bump and no model permissions. No new dependency or Cargo feature. Existing analyze/render/export entry points remain. New APIs are opt-in cache entry points, `disable_and_drain`, cache ownership and the progress mailbox.

Behavioral adjustment: re-enable while disabled work still exists is now Busy; wait for drain rather than replacing live ownership. Ordinary `status.active_jobs` still counts media job permits, not long-lived review handles or the additional whole-workflow lease. Drain reports jobs and workflows separately.

Saved projects, cut geometry, presets, serializers, render-filter plans, graphical composition and interchange writers are pinned to unchanged Step 11 bytes. The private color recommender changed visibility only to share its exact implementation. User decisions stay in `.amxv`; the new cache is disposable and memory-only.

Rollback means restoring the preceding source package and rebuilding the host integration. Projects remain schema 7. Always drain/join the actual host workers before unloading/replacing code; do not carry Rust objects across an unqualified dynamic-library ABI. Dropping the optional cache loses performance only, not accepted edit intent.

## 8. Tests, measurements and remaining acceptance

New Rust tests cover cache hit/fresh equivalence, changed/revoked inputs, moved locators, settings/runtime/stream invalidation, current-project rebinding, manual protection, rejected choices, budgets/LRU, failed scans, scope teardown, workflow gaps, wait/drain, mailbox backpressure and process cleanup. Native tests exercise the real Rust-to-FFmpeg path, three caches, source preservation, changed executables and cancellation. They are supplied, **not executed here**.

The existing independent FFmpeg corpus exercises actual encoded/decoded media but not the Rust transport/analyzers. The small Python boundary suite validates its own exact-source/fixture/dependency guards, not language semantics. Do not add those numbers to unexecuted Rust tests.

Coupling counts are lexical source observations, not a compiled dependency graph. The six capability subprocesses avoided on a hit are an implementation property checked by a supplied native wrapper test, not a measured application startup result. There is no claimed cache speedup/RSS/typing budget without running the actual core/host on representative hardware.

[Manual procedure](STEP-12-MANUAL.md) includes equivalence, repeated-work performance, permissions, runtime-update invalidation, cancellation and rollback. Step 11's compilation/platform/editor/legal/perceptual blockers remain. Step 12's source work must not be read as approval to start Step 13 in production before these requirements are met.
