# Step 13E: editable local transcription

The alpha.5 source implements optional local transcription, editable source-time
words, subtitle generation, literal search, sentence boundaries, chapter
suggestions and reviewed filler/punch-in proposals. It uses the existing
extension, project, lifecycle, media decode and native process owners.

**Current verification:** the reattached alpha.3 archive contained no
transcription implementation. This implementation and its regression tests were
rebuilt during this revision. A Rust compiler, the selected whisper.cpp runtime
and real tiny/base weights were not available in this workspace. The Rust tests
and actual-model smoke example are supplied but must pass on the build host.
Earlier alpha.4 execution results are historical and do not qualify these bytes.
See the current verification report for the independently executed checks.

## Explicit model and runtime selection

The supported candidate is whisper.cpp **1.7.6 CLI**, with an unquantized tiny or
base GGML model that fits the 160 MiB pack limit (normally F16), mono 16 kHz PCM, CPU execution, two inference threads and one
processor. English-only and multilingual tiny/base headers are accepted. GGUF,
quantized weights, larger models, alternate mel frontends, translation, diarization,
cloud services and automatic executable/model discovery are outside this contract.

The existing component owner supplies and reviews:

- Manifest JSON and its independently selected SHA-256.
- Exact local model weights and notices matching that manifest.
- A canonical local `whisper-cli` executable whose SHA-256 matches
  `runtime.artifact_sha256`.
- A canonical local UTF-8 build-information file whose SHA-256 matches
  `runtime.build_info_sha256`. Record the source revision, build options,
  CPU architecture and runtime deployment dependencies here.
- A canonical private-work parent directory and the usual explicit source-media,
  FFmpeg and ffprobe grants.

Use these manifest identity strings:

| Field | Required value |
|---|---|
| `contract` | `whisper-cpp-ggml-tiny-base-v1` |
| `preprocessing` | `explicit-channel-pcm16-16k-source-clock-v1` |
| `runtime.adapter` | `whisper-cpp-1.7.6-cli-cpu-v1` |

The model-pack guard validates the GGML header, tiny/base dimensions, mel table,
embedded vocabulary and bounded tensor records. It rejects truncated data,
duplicate tensor names, unsupported tensor types and incompatible essential
tensor shapes. The maximum model size is 160 MiB for this contract; ONNX pack
limits remain separate. This structural check is not a publisher signature,
complete numerical model verifier or memory sandbox. Selection, distribution
rights and provider-process resource limits remain with the trusted host.

The principal executable and selected build information are checked before and
after execution. Shared-library placement and provenance remain deployment
responsibilities. The adapter sets `--no-gpu` and does not discover GPU backends
or invoke another executable owner.

## Analyze, review, save

`VideoExtension::transcribe` takes an immutable project, `TranscriptRequest`,
`TranscriptProvider`, live `ModelActivation`, cancellation and progress sink.
`WhisperCppProvider` is the concrete native implementation. The default library
remains independent of native executable loading; another authorized host can
implement the provider trait.

```rust,ignore
let activation = ModelActivation::selected(pack.identity().clone())?;
let provider = whisper_cpp::WhisperCppProvider::new(
    pack, selected_executable, selected_build_info, private_work_parent,
)?;
let mut request = TranscriptRequest::new(project_file);
request.settings.language = "en".into();
request.settings.analysis_channel = 0;

let report = video.transcribe(
    &project, &request, &provider, &activation, &cancel, &mut progress,
)?;
// Present the observations, uncertainties and provenance through the host UI.
report.apply(&mut project)?;
// Saving remains the ordinary explicit ProjectStore operation.
```

Analysis never edits, publishes, saves or renders the project. Applying the
report installs transcript evidence in exactly one project revision. It does not
approve generated cuts, framing or captions. A changed project digest, cancelled
caller, revoked activation or disabled extension invalidates an unapplied report.
Accepted text remains ordinary project data and needs no installed model to read,
correct, search, export, save or render.

The report is connected to `ReviewSession::apply_transcript_report`. Optional
transcription actions should be registered only after explicit host selection;
action metadata itself is not executable permission.

## Source clock and bounded inference

The existing timestamped selected-channel speech decode supplies mono float PCM
at 16 kHz. The adapter does not average channels, normalize amplitude or insert
silence. PCM16 conversion clips only to the PCM format range; clipping counts are
recorded and make word timing/confidence uncertain.

The first decoded sample retains its offset relative to the first selected video
presentation timestamp. Recognized millisecond offsets are converted to exact
rational source-relative times. Source content, saved timing/geometry, selected
audio, pinned FFmpeg/ffprobe and provider identity are revalidated around analysis.

This candidate accepts one source up to **30 minutes**, with at most 8,192 words
and 65,536 token observations in an 8 MiB result. Sources with audio timestamp gaps
or genuine overlaps fail explicitly; segment such sources before transcription.
A source time base no coarser than 1 ms allows only one source tick plus one 16 kHz
sample of packet-clock quantization. Comparison is against the cumulative sample
clock, so tolerance cannot accumulate drift. Every accepted repair is recorded as
uncertainty. No missing source samples become invented silence.

The entire request, model staging and child execution obey the caller's bounded
deadline. Cancellation stops the existing native process group and cleans the
job-owned staging files. One provider admits one inference at a time. The host's
existing job limit and provider-process controls remain the stronger scheduling
and resource boundary.

The selected CLI runs with full JSON output, `--max-len 1` and `--split-on-word`.
The parser requires integer millisecond offsets to agree with display timestamps,
valid ordered nonoverlapping word ranges, bounded token IDs/text/probabilities,
matching token and word text, and selected model/language metadata. Duplicate
keys, missing token evidence, unexpected protocol fields, changed languages,
translation and multiword segments fail explicitly. A token with zero duration
marks its containing word uncertain. These are estimated word boundaries, not
forced-alignment precision.

## Corrections and persistent evidence

Schema 9 adds optional `Project.transcript`. Schema 8 and older migrate with the
field absent; older-schema files containing the new field, including `null`, are
rejected. The project records:

- Exact immutable original recognized words, source times and optional confidence.
- A digest of those observations and the source content fingerprint.
- A digest binding the selected source streams, media geometry and original clock.
- Selected model, runtime, decode identities and transcription settings.
- Separate editable words, correction/review flags and explicit locks.

`correct_transcript_word` and `review_transcript_word` are atomic project edits.
Invalid text, overlapping corrections, out-of-source times and locked changes
leave the project untouched. Reviewing a low-confidence word does not delete or
rewrite its original confidence. `set_transcript_word_locked` explicitly changes
the lock; `clear_transcript` refuses locked words.

Reanalysis preserves corrected, reviewed and locked words when their stable
original observation identities match. If a fresh model observation cannot be
matched, replacement fails instead of dropping that human work. The caller can
explicitly unlock and clear the old transcript before accepting a different one.
Model paths, executable paths and activation permissions are never serialized.

## Search, subtitles and editing suggestions

`Transcript::search` performs bounded literal Unicode lowercase matching and
returns source-time word ranges. `sentences` uses punctuation, pauses and bounded
length; it makes no claim of semantic sentence understanding. Chapter suggestions
use those boundaries and an explicitly supplied minimum spacing of 30–600 seconds.
Their titles are excerpts of recognized text and require human review.

`subtitle_document` creates normal editable source-time SRT or WebVTT cues while
preserving uncertain words. `subtitles_for_project` remaps those cues through the
current timeline; `subtitles_for_variant` also uses the selected variant's approved
speed and transitions. Generated documents retain `generated_words` timing in
schema 9 so a later cut removes the corresponding words from both sidecars and
burned captions. An ordinary imported cue has no invented word alignment. Explicitly
editing a cue removes only that cue's generated alignment. Subtitle millisecond quantization is outward, as for imported
captions. `Project::install_transcript_captions` installs the document into an
existing variant presentation while preserving its other layers; existing captions
and locks prevent replacement. Burn-in requires explicit font/style and placement.
The normal presentation approval and render paths apply.
After correcting transcript words, `refresh_transcript_captions` explicitly
refreshes an existing generated layer. It preserves style and placement and refuses
to overwrite individually edited caption cues or locked presentation settings.

Filler removal requires an explicit vocabulary and individually reviewed words.
Locked words, locked clips, protected ranges and words longer than one second are
excluded. `propose_transcript_fillers` adds only `NeedsReview` removal operations.
Existing user decisions and locks survive regeneration. Listen to word boundaries
before accepting a cut; confidence never gives consent to remove speech.

Sentence punch-in suggestions are source-time ranges, not face-safety assertions.
`propose_transcript_punch_ins` accepts explicit sentence IDs, canvas and restrained
zoom. It uses the existing punch-in helper and known cut boundaries, requires an
empty framing layer, and leaves the result pending. Existing framing and locks are
preserved. Check subject visibility, composition and graphic collisions before
approving the framing.

## Reproducible checks and real-model smoke

Core tests are in `tests/transcript.rs` and `tests/transcript_workflow.rs`.
`tests/whisper_cpp.rs` checks synthetic protocol fixtures under `native`; native
transport tests use clearly identified fake shell fixtures inside the test build.
They test error handling and ownership, not recognition quality.

```sh
cargo test --locked --test transcript --test transcript_workflow
cargo test --locked --features native --test whisper_cpp
cargo test --locked --features native --lib native::transcript
```

For actual execution, set these explicit example inputs and run the checked-in
example. No path is inferred by the provider, and a missing asset causes failure.

| Environment variable | Explicit input |
|---|---|
| `AMXV_WHISPER_MANIFEST` | Selected manifest JSON |
| `AMXV_WHISPER_WEIGHTS` | Selected tiny/base GGML file |
| `AMXV_WHISPER_NOTICES` | Notices matching the manifest |
| `AMXV_WHISPER_MANIFEST_SHA256` | Independently reviewed manifest SHA-256 |
| `AMXV_WHISPER_EXECUTABLE` | Canonical selected whisper.cpp CLI |
| `AMXV_WHISPER_BUILD_INFO` | Canonical selected UTF-8 build information |
| `AMXV_FFMPEG`, `AMXV_FFPROBE` | Explicit qualified media tools |
| `AMXV_TRANSCRIPT_INPUT` | Recording with known spoken content |
| `AMXV_TRANSCRIPT_OUTPUT` | Absolute new output directory; must not exist |
| `AMXV_TRANSCRIPT_LANGUAGE` | Optional explicit language code; default `auto` |
| `AMXV_TRANSCRIPT_CHANNEL` | Optional explicit channel index; default `0` |

```sh
cargo run --locked --features native --example transcript_smoke
```

The example creates `transcript.amxv`, `transcript.vtt` and `transcript.json` only
after successful transcription and an exact project round trip. The record includes
model/runtime provenance, word and sentence counts, elapsed time and media duration.
Successful synthetic or real-model execution does not qualify word error rate,
accents, languages, noisy/music recordings, overlapping speakers, timing precision
or quality on the user's recordings. Those remain measured host acceptance work.

The adapter contract targets the [whisper.cpp 1.7.6 CLI source](https://github.com/ggml-org/whisper.cpp/blob/v1.7.6/examples/cli/cli.cpp)
and [model loader](https://github.com/ggml-org/whisper.cpp/blob/v1.7.6/src/whisper.cpp).
The current environment could not fetch those exact source files or execute the
runtime, so matching the strict JSON/weight contract is an explicit required smoke
gate before enabling this provider in a host deployment.
