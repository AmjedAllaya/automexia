# Reviewed playback speed and dissolves

Variant-local timing is stored in schema 9 as optional `OutputVariant.timing`.
It does not rewrite source-time clips, operations, captions or framing keys.
The available playback speeds are 0.5×, 1× and 2×. A reviewed nonzero dissolve
applies at every join between retained, noncontiguous source intervals.

```rust,ignore
use automexia_video::{Disposition, Rational};
use automexia_video::timing::{PlaybackSpeed, TimingSettings};

project.set_timing("main", Some(TimingSettings {
    speed: PlaybackSpeed::Half,
    dissolve: Rational::new(0, 1)?,
    ..TimingSettings::default()
}))?;
// After review of this exact proposal:
project.review_timing("main", Disposition::AutoApply, true)?;
let timeline = project.timeline_for_variant("main")?;
```

Replacing settings returns them to review. Locked timing must be unlocked before
replacement, removal or a changed disposition. Disabled or rejected timing is an
identity operation. A normal-speed, zero-dissolve render never invokes
`atempo=1`, avoiding an unnecessary audio filter that can shift sparse content.

The timeline uses affine source/output mappings. During a dissolve,
`output_to_sources()` returns both contributors. The legacy singular
`output_to_source()` chooses the first contributor in timeline order; callers
which display overlap information should use the plural method. Caption ranges,
markers and animation clocks use the same affine mapping.

Rendering speed or overlap requires complete decoded CFR evidence, an explicitly
supported edit rate, and source/output boundaries on that frame grid. A dissolve
is at most five seconds and at most half each participating segment. This avoids
three simultaneous contributors. Ordinary cuts retain their existing timestamp
policy. Audio slices use exact cumulative sample boundaries, including fractional
NTSC frame durations; the last sample is rounded upward once for the output.

Source graphics and caption burn-in are composed **before** a dissolve. Their raster sequence follows the original source clock; trim, speed conversion and the video dissolve operate on those already composed frames. This makes titles fade with their own source picture rather than appearing fully opaque over both contributors. Source-volume keys likewise run before audio trimming, time stretching and overlap, using the correct original or enhanced-audio origin. Ordinary non-overlap presentation keeps its existing output-clock route.

The source compositor restores the original video time base after overlay synchronization. This bounded path requires a source clock with at least one microsecond per tick and a source origin exactly on that clock. More precise or incompatible clocks fail explicitly. It retains the existing graphic asset, animation-state, scratch-byte and process limits. Transcript-generated captions filter removed words before source or output rasterization; the saved original transcript/caption evidence remains unchanged.

The independent `tests/media/run_timing_checks.py` recipe tests actual decoded frame counts and PTS, 48 kHz PCM sample counts, fractional NTSC cut impulse locations, positive source origins, all three playback speeds, audio/video dissolves, and source graphics/volume through the overlap. Its PCM graph checks omit a mux-level `-t` because FFmpeg rounds a fractional PCM endpoint to the nearest sample; the graph itself implements the documented upward-rounded sample boundary. These recipes do not execute Rust or establish the Automexia host integration.

OTIO preserves normal-speed dissolves as transitions with explicit source
handles. XML and EDL require an explicit visual bake for dissolves. Speed changes
require an explicit visual bake in every interchange format. Compatibility is
assessed before optional media are published. A baked audio track is represented
once, rather than duplicated under overlapping video clips.

Regression declarations are in `tests/timing.rs`, `tests/native_timing.rs`,
`tests/interchange.rs`, and the existing presentation and pause targets. See the
current verification report for what was actually executed in this rebuild;
source inspection and independent FFmpeg recipes do not substitute for Rust
compilation or native workflow execution.


## Step 14A assembly interaction

In schema 10, an optional reviewed `variants[].assembly` is resolved before global timing. Each source-range occurrence has a constant 0.5×/1×/2× speed. Global timing multiplies that speed, giving effective 0.25×/0.5×/1×/2×/4× rates across a mixed sequence. Output/source mapping retains all repeated occurrences; source-time graphics, animation and volume keep their original phase.

Changed-speed selected audio requires both retained source and mapped output spans of at least 100 ms. The native recipe pads 250 ms before windowed tempo filtering, then trims emitted output to its exact sample target. It does not mask missing tempo output with post-filter padding. Pitch-preserving WSOLA can shift or lose isolated transients; exact duration is not a fidelity guarantee. Video-only timing retains its frame-grid constraints without this audio minimum.

Reordered/repeated video uses bounded branch composition and one final global CFR frame index. Single-frame branches therefore have valid sequence timestamps, and fractional frame clocks do not accumulate branch rounding. See [Step 14A](STEP-14.md) for assembly review, limits and qualification status.
