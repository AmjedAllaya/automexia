# Source-package delivery — Step 14B

The current identity is **Step 14B / 0.14.0-alpha.2**, an unverified implementation source candidate. The source includes portable interchange bundles, modern FCPXML, reviewed single-source clip assembly and retained Steps 0–13 workflows, but Rust/native/model execution and product acceptance remain open. This package is not a compiled or installable extension.

Current evidence is in `reports/step14b/verification.json`. Earlier reports are historical. The exact archive identity is generated from `delivery-policy.json` and verified bytes; no hand-written filename is authoritative.

The packager verifies every member CRC, the exact SHA-256 manifest, Cargo/policy/candidate version and milestone consistency, required files, fresh extraction, source stability and the published archive reopened from disk. These checks establish source integrity, not compilation or functional completeness.

The full archive must include the current source, tests, examples, documentation, architecture policy and fresh evidence. It excludes compiled targets, model/runtime binaries, fonts and user recordings. Cargo.lock is currently absent because no working Cargo was available; the first connected builder must resolve/review it before native qualification. Do not fabricate the file to satisfy a packaging checklist.

## Build and verify a source delivery

Requires Python 3.11 or newer, standard library only. It does not run inside the
Video extension and adds no Rust dependency, host permission or application API.
Run from the extracted package root:

```bash
python3 -B -m unittest discover -s tests/packaging -v

python3 -B tools/package_delivery.py build \
  --source . --output-dir /absolute/fresh/delivery-directory \
  --expected-step 14 --expected-version 0.14.0-alpha.2
```

On success the JSON output contains the **exact receipt path**. Use that path;
do not guess it or use a broad wildcard. The archive's immutable filename contains
the actual step, Cargo version, delivery label and archive hash prefix.

```bash
python3 -B tools/package_delivery.py verify \
  --receipt /absolute/path/returned-by-build.delivery.json \
  --expected-step 14 --expected-version 0.14.0-alpha.2
```

For a conversation delivery only, `links` reopens every artifact before emitting
Markdown. It requires the files to be beneath `/mnt/data`:

```bash
python3 -B tools/package_delivery.py links \
  --receipt /absolute/path/returned-by-build.delivery.json \
  --expected-step 14 --expected-version 0.14.0-alpha.2
```

A failed command exits nonzero and emits **no success output or links**. Do not
continue to a manual link in an answer or a publish step. There is no force,
skip-verification or success-on-missing switch. Checks do not rely on Python
`assert`, so `python -O` cannot remove them.

## What the gate checks

The builder verifies the explicit expected step, delivery policy and Cargo
package/version. Required source and milestone-guide files must exist and be
nonempty. It performs repeated full source scans, rejects unreadable subtrees,
unexpected top-level files/directories, symlinks, portable-path conflicts, case-colliding components, fonts, oversize
inputs and special files, and excludes only documented build/cache directories.

The archive is first written to a private staging area. Its member CRCs, exact
SHA-256 manifest, package identity, file set and portable paths are checked. It is
then extracted into a new directory and the extracted bytes are checked.

Only then are the ZIP and checksum published, without overwriting a conflicting
existing artifact. The ZIP is reopened at its final path. An adjacent receipt is
created last and verified again. A caught publication failure removes the files
created by that attempt; previous deliveries remain untouched. A hard process
kill or filesystem failure can leave staging files or an orphan ZIP, but **no
valid receipt and no generated links** qualifies that incomplete attempt.

The receipt is bound to the exact final filename, size and SHA-256. `verify` and
`links` recheck actual files rather than trusting the word “verified” in a JSON
record. Missing/altered ZIPs or sidecars and stale receipts are errors. Receipts
cannot claim application-test or browser-download success.

## Advancing beyond this candidate

Do not merely rename this ZIP or change a header. Implement/recover the real
next milestone source and documentation first. Update Cargo version, the milestone policy,
its required files and the explicit build expectations together. Use the existing
application/media tests to establish feature behavior separately. Passing this
source-package gate is necessary for delivery but not proof of implementation.

## Limits

These are source-distribution integrity checks, not a signature, a sandbox,
feature-completeness proof or release certification. The local tools cannot click
the ChatGPT download endpoint on the user's device, upload to an external service,
or control conversation retention. A link valid at publication can later expire
under platform retention rules; save the verified archive and adjacent checksum
locally. No claim is made that this script changes ChatGPT's platform behavior or
forces a future assistant to use it.

Do not distribute font files. Graphics tests continue to require a separately
selected local font as described in the existing Step 8 integration guide.

Current package milestone: **14 / 0.14.0-alpha.2**, implementing the explicitly bounded Step 14B subset. Prior receipts are historical.
