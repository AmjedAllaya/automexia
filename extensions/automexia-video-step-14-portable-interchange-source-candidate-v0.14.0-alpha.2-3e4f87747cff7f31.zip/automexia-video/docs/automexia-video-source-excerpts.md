# Automexia Video — source excerpts

> Standalone-package note: links into the full documentation archive are retained as labelled path references where those files are not part of this core source package. The quoted requirements are unchanged.

These are exact line-range excerpts from the supplied documentation archive. They support the companion roadmap; they are not implementation, runtime-compatibility, current-version, or redistribution approvals. Original source labels distinguish historical alternatives and later research amendments.

**Archive:** `automexia-documentation-ce4-presentation-actions-2026-09-09.zip`  
**Archive SHA-256:** `482e4ff653caeadcbd78a81df5226ff71cdba4369c9492ded0bf22290e7c49b8`

**Roadmap revisions:** the companion plan makes the requested classic extension approach explicit and moves learned-model integration after the pre-AI modernization phase. Its new step numbering and implementation breakdown are planning proposals, not source-reported completion.

## Contents

- [Product scope and user commands](#s1)
- [Existing extension ownership and non-GUI-dependent operation](#s2)
- [Actual documented capability restriction](#s3)
- [Projects, non-destructive operations, confidence and dry run](#s4)
- [Silence editing, smoothing and audio](#s5)
- [Color, reframing, graphics, subtitles and effects](#s6)
- [Rendering and interchange](#s7)
- [Optional packs, full feature inventory and future scope](#s8)
- [Media authority, cache and detector/enhancer choices](#s9)
- [Timing, HDR, review, render modes and NLE export](#s10)
- [Original staged roadmap and revised product promise](#s11)
- [VideoLab test and quality requirements](#s12)

<a id="s1"></a>

## Product scope and user commands

**Source:** `docs/developer/future/video-automation.md`, archive-file lines 85–125.  
**Source file SHA-256:** `b58a1f358f8809f564a72ce4379cd8a78a22e2304242e3abbb778fec57d31276`

The following fenced block preserves the source text verbatim. Section-local source-line numbers inside it refer to the earlier source documents, not the archive-file line range above.

````markdown
## 1. Executive Summary

*Source lines 12–51.*

Automexia is a lightweight Rust terminal whose domain capabilities live in extensions. The core terminal should remain small, fast, and independent from video, ML, DevOps, database, or other domain-specific runtimes.

The video capability is an extension named conceptually `automexia-video`. It is not a full non-linear editor and does not attempt to recreate Premiere Pro, DaVinci Resolve, or a motion-graphics GUI. Its purpose is to automate repetitive post-production tasks that are expensive to perform manually:

- smart silence shortening and cut cleanup
- voice enhancement
- conservative color correction
- face-aware reframing for multiple platform formats
- simple automatic graphic placement
- restrained punch-ins, transitions, and animations
- multi-target rendering
- export of the edit to professional NLE interchange formats

The normal user experience should stay close to:

```bash
video run recording.mp4
```

or:

```bash
video run recording.mp4 \
  --preset social \
  --to youtube,tiktok,reel
```

Professional users can stop before render and continue elsewhere:

```bash
video run recording.mov --no-render
video export recording.amxv --to resolve
```

The default video extension must require **no LLM, no AI agent, no paid API, no cloud inference, no Python, no PyTorch, no Node.js, and no Chromium**.

<a id="m2-s043-0002"></a>
````


<a id="s2"></a>

## Existing extension ownership and non-GUI-dependent operation

**Source:** `docs/developer/future/video-automation-details/part-03.md`, archive-file lines 93–162.  
**Source file SHA-256:** `14efd5a85708b08fd6f59e730e76df928919b9e8e1a5c38ac557aa58fd870984`

The following fenced block preserves the source text verbatim. Section-local source-line numbers inside it refer to the earlier source documents, not the archive-file line range above.

````markdown
## Document preamble

*Source lines 1–20.*

**Repository-alignment preface.**

**State:** future product-discovery proposal; no current implementation.

Do not add these dependencies to the active terminal roadmap until core activation/security/native/accessibility/signing/packaging/resource gates are substantially closed.

The design should be interpreted as **CLI-complete with optional renderer-native review UI**, not "no GUI."

Managed FFmpeg is a reproducibility candidate, not an automatic distribution decision; actual adoption requires codec/license/security/signing/redistribution analysis.

Within the retained proposal body, “ProcessBroker” means the logical role of
the existing application-owned `ExternalToolRunner`, not a new crate or daemon.
“Policy Engine” is a hypothetical future service; current work must use accepted
capability/policy owners and may not assume that service exists.

No large LLM, paid inference API, or cloud AI service is required.

<a id="m2-s095-0001"></a>

## Automexia — Architecture & Video Automation Specification

*Source lines 21–31.*

> **Status:** Future research candidate — no implementation or dependency is authorized
> **Project:** Automexia
> **Primary language:** Rust
> **Architecture:** lightweight terminal core + isolated extensions
> **Primary video principle:** **Models observe. Rust decides. Automexia authorizes. FFmpeg executes.**
> **Design goal:** remain CLI-complete with local deterministic processing, while allowing optional renderer-native keyboard-complete review overlays when they materially improve review.

<a id="m2-s095-0003"></a>

## 1. Executive Summary — 1.1 Explicit local-only intelligence policy

*Source lines 70–75.*

The candidate video design excludes large language models, paid inference APIs, cloud AI inference, and agent loops. Small local specialized models remain candidates only as bounded observers behind Rust interfaces. Deterministic Rust would remain the edit-decision authority.

<a id="m2-s095-0004"></a>

## 2. Non-Negotiable Architecture Rules

*Source lines 76–79.*

*Context: Automexia — Architecture & Video Automation Specification*

These rules prevent architectural drift.

<a id="m2-s095-0007"></a>

## 2. Non-Negotiable Architecture Rules — 2.3 CLI-complete; renderer-native review UI optional

*Source lines 109–121.*

The workflow must remain fully operable from commands/projects. Optional renderer-native review overlays are allowed, but the workflow must not require:

- a visual timeline
- drag-and-drop
- a node editor
- an embedded video editor
- an effect browser
- a waveform GUI

Commands, presets, workflows, project files, logs, and generated media are the primary interface.

<a id="m2-s095-0012"></a>
````


<a id="s3"></a>

## Actual documented capability restriction

**Source:** `docs/project/adr/0003-extension-capability-and-threading.md`, archive-file lines 1–18.  
**Source file SHA-256:** `39468ec7d2dbb7a209cad5bca56193b574bbdaaf41efd7c54e36ccfc9339720b`

The following fenced block preserves the source text verbatim. Section-local source-line numbers inside it refer to the earlier source documents, not the archive-file line range above.

````markdown
<a id="m2-base-0000"></a>

# ADR 0003: Extension capability and threading boundary

Status: accepted.

Built-in extensions declare least-privilege local-read capabilities. Discovery
uses a bounded worker queue and session-scoped cached snapshots. Rendering and
PTY processing never perform extension I/O or wait for worker completion. New
process or network capabilities require a security review, two protected-path
approvals, and a replacement ADR.

ADR 0012 (original archive reference: `0012-first-party-ssh-and-session-launch-boundary.md`) is the accepted
replacement only for a narrowly scoped, application-owned first-party
`session.launch` capability. This ADR still requires two independent protected-
path approvals bound to the exact head plus non-bypassable server enforcement,
attestation, and native evidence before activation. Until those gates pass, the
local-read-only runtime boundary remains authoritative.
````


<a id="s4"></a>

## Projects, non-destructive operations, confidence and dry run

**Source:** `docs/developer/future/video-automation-details/part-01.md`, archive-file lines 196–370.  
**Source file SHA-256:** `2927f93989a3013fd1b65f4b7d4ae6dcfd04f293472f0d6ba081e1bcaaed789c`

The following fenced block preserves the source text verbatim. Section-local source-line numbers inside it refer to the earlier source documents, not the archive-file line range above.

````markdown
## 34. `.amxv` Project Format

*Source lines 1120–1163.*

Use a versioned, human-readable JSON project.

Extension:

```text
.amxv
```

Goals:

- inspectable
- Git-diffable
- scriptable
- migration-friendly
- independent of Automexia session state

Paths should be project-relative when possible.

The schema supports multiple source records so it does not need to be redesigned later. V1 automation, however, should optimize for **one primary video/program source plus optional graphics, subtitles, and auxiliary audio assets**. Full multi-camera/multi-clip creative editing is not a V1 goal.

Example high-level structure:

```json
{
  "schema":"automexia.video.project",
  "version":1,
  "created_with":{
    "extension":"1.0.0"
  },
  "sources":[],
  "analysis":{},
  "timeline":{},
  "operations":[],
  "variants":{},
  "graphics":{},
  "render":{},
  "exports":{}
}
```

<a id="m2-s043-0066"></a>

## 35. Required `.amxv` Source Record

*Source lines 1164–1195.*

Example:

```json
{
  "id":"source-1",
  "path":"media/recording.mp4",
  "fingerprint":{
    "size":123456789,
    "mtime_ns":123456789000,
    "partial_sha256":"..."
  },
  "streams":{
    "video":0,
    "audio":1
  },
  "probe":{
    "width":3840,
    "height":2160,
    "video_time_base":{"num":1,"den":90000},
    "audio_time_base":{"num":1,"den":48000},
    "color_space":"bt709",
    "rotation":0
  }
}
```

Do not embed the entire raw ffprobe response unless placed in an optional diagnostics section/cache. Store the normalized subset required to compile the project.

<a id="m2-s043-0067"></a>

## 36. Edit Operation Model

*Source lines 1196–1236.*

Operations should be typed, versioned, and explainable.

Example:

```json
{
  "id":"op-42",
  "kind":"shorten_silence",
  "source":"source-1",
  "range":{
    "start":{"pts":1287720,"tb":{"num":1,"den":90000}},
    "end":{"pts":1458000,"tb":{"num":1,"den":90000}}
  },
  "parameters":{
    "keep_ms":180
  },
  "confidence":0.96,
  "reason":[
    "vad_non_speech",
    "low_audio_energy",
    "duration_above_threshold"
  ],
  "generator":{
    "algorithm":"silence-v1",
    "version":1
  }
}
```

Manual edits made directly to the project may set:

```json
{"locked":true}
```

A recomputation pass should not overwrite locked operations unless explicitly requested.

<a id="m2-s043-0068"></a>

## 37. Decision Confidence

*Source lines 1237–1254.*

Confidence is useful only when it affects behavior.

Default policy can be preset-controlled:

```text
high confidence      -> apply
medium confidence    -> keep proposal in project but disable by default
low confidence       -> ignore
```

Do not hard-code one global threshold for every feature. Silence, color, graphic placement, and reframing have different confidence models.

Every automated operation should store reason codes so a dry run can explain what the system intends to do.

<a id="m2-s043-0069"></a>

## 38. Dry Run

*Source lines 1255–1285.*

```bash
video run recording.mp4 --dry-run
```

Dry run performs probe, analysis, and decision generation but does not render final media.

Example:

```text
Input: recording.mp4
Duration: 18:32

Would apply:
  37 pause edits
   8 subtle punch-ins
   1 voice-enhancement chain
  11 shot-level exposure corrections
   1 9:16 reframe track

Estimated edited duration: 15:47

Project preview: recording.amxv
No final video rendered.
```

The project may still be written because it is the main inspectable artifact.

<a id="m2-s043-0070"></a>
````


<a id="s5"></a>

## Silence editing, smoothing and audio

**Source:** `docs/developer/future/video-automation-details/part-01.md`, archive-file lines 372–533.  
**Source file SHA-256:** `2927f93989a3013fd1b65f4b7d4ae6dcfd04f293472f0d6ba081e1bcaaed789c`

The following fenced block preserves the source text verbatim. Section-local source-line numbers inside it refer to the earlier source documents, not the archive-file line range above.

````markdown
## 39. Smart Silence Analysis

*Source lines 1286–1310.*

Use multiple signals rather than a raw dB threshold.

Inputs:

- Silero VAD probability
- RMS/energy
- pause duration
- speech padding requirements
- adjacent audio continuity

Initial preset behavior:

```text
very short pauses      -> preserve
normal speech pauses   -> preserve or shorten slightly
long pauses            -> shorten
very long dead air     -> shorten aggressively
```

Exact thresholds belong in presets and should be tuned with a regression dataset.

<a id="m2-s043-0071"></a>

## 40. Smart Silence Guardrails

*Source lines 1311–1330.*

Silence editing must avoid robotic speech and audio discontinuities.

Rules:

- keep padding before and after detected speech
- enforce a minimum retained gap
- do not cut through low-confidence speech boundaries
- avoid repeated cuts separated by tiny speech islands
- merge nearby silence candidates when appropriate
- preserve breaths when the default `clean` preset considers them natural
- use short audio fades/crossfades to avoid clicks

Important limitation:

A video containing a continuous music bed mixed into the same audio stream cannot have arbitrary time removed without also jumping the music. The default algorithm should detect meaningful non-speech background energy and become more conservative, or warn. Best results occur when music is on a separate stream/track or silence shortening is disabled for music-heavy mixes.

<a id="m2-s043-0073"></a>

## Audio

*Source lines 1333–1343.*

*Context: 41. Cut Smoothing*

Use:

- zero-crossing-aware boundaries where practical
- micro fades
- short crossfades
- optional room-tone preservation

Do not use long crossfades between spoken words because they can smear phonemes.

<a id="m2-s043-0074"></a>

## Video

*Source lines 1344–1357.*

*Context: 41. Cut Smoothing*

Normal behavior is a hard cut.

A jump-cut mitigation can alter crop/scale after the cut when:

- the cut remains in the same scene
- a stable face exists
- the new crop remains compositionally safe

Do not add a transition merely because a cut exists.

<a id="m2-s043-0075"></a>

## 42. Voice Enhancement Pipeline

*Source lines 1358–1390.*

Before processing, perform a cheap audio preflight:

- peak level and clipping count
- DC offset
- integrated/short-term loudness measurements as needed
- channel imbalance
- 50/60 Hz hum evidence and harmonics
- speech occupancy from VAD
- continuous non-speech bed energy

This preflight determines whether optional cleanup such as a hum notch is safe. If the source is already digitally clipped, report it; normal compression/normalization cannot reconstruct missing peaks.

Default spoken-word chain:

```text
decode / channel selection
    -> DC/rumble cleanup
    -> optional high-confidence 50/60 Hz dehum notch
    -> RNNoise
    -> edit/cut assembly
    -> conservative EQ
    -> de-esser
    -> compression
    -> loudness normalization
    -> true-peak limiting
```

Use FFmpeg filters where they are mature and appropriate; RNNoise can be integrated as a small native processing stage.

<a id="m2-s043-0076"></a>

## 43. Voice Enhancement Safety

*Source lines 1391–1412.*

V1 should optimize for spoken-word content, not arbitrary music mastering.

Rules:

- inspect speech occupancy before enabling aggressive voice processing in `auto` mode
- keep denoise conservative when strong continuous non-speech content is present
- do not assume a multi-channel surround mix is a dialogue track
- for more than stereo or multiple audio streams, choose a clear default stream and allow explicit selection
- never silently downmix the final output merely because VAD analysis uses mono

Suggested mode:

```text
voice_mode = auto | on | off
```

`auto` enables the full voice chain only when the input appears to be primarily spoken-word content.

<a id="m2-s043-0077"></a>

## 44. Loudness Processing

*Source lines 1413–1430.*

Use measurement-based loudness normalization rather than a single gain adjustment.

For high-quality presets, use a measurement pass followed by a correction pass.

Targets belong to presets, not platform mythology. Example starting points may include:

```text
clean spoken-word: configurable around -16 LUFS
social:           configurable around -14 to -16 LUFS
true peak:        configurable ceiling
```

These are starting defaults, not claims about mandatory platform requirements.

<a id="m2-s043-0078"></a>
````


<a id="s6"></a>

## Color, reframing, graphics, subtitles and effects

**Source:** `docs/developer/future/video-automation-details/part-01.md`, archive-file lines 535–1012.  
**Source file SHA-256:** `2927f93989a3013fd1b65f4b7d4ae6dcfd04f293472f0d6ba081e1bcaaed789c`

The following fenced block preserves the source text verbatim. Section-local source-line numbers inside it refer to the earlier source documents, not the archive-file line range above.

````markdown
## 45. Color Analysis

*Source lines 1431–1454.*

V1 color automation should be conservative and correction-oriented.

Analyze per shot:

- luminance percentiles
- clipping
- channel balance
- neutral/low-saturation regions
- basic contrast distribution
- face-region luma as an additional guard when a face exists

Possible algorithms:

- histogram percentiles
- gray-world/shades-of-gray white balance
- gamma/exposure correction
- restrained tone curve

Do not attempt artistic grading automatically.

<a id="m2-s043-0079"></a>

## 46. Color Correction Guardrails

*Source lines 1455–1471.*

Suggested initial safety clamps to tune during testing:

- exposure correction limited to a conservative range
- white-balance gains clamped to prevent strong color casts
- saturation changes small by default
- avoid correction when neutral-reference confidence is low
- smooth correction within a shot
- allow discontinuity at an actual scene cut

If the algorithm is not confident, preserve the source rather than force a correction.

Creative looks such as `warm`, `film`, or `high-contrast` are explicit user presets, not part of automatic correction.

<a id="m2-s043-0080"></a>

## 47. Scene Detection

*Source lines 1472–1487.*

Scene boundaries support:

- color analysis
- crop reset
- transition policy
- graphic placement stability
- punch-in reset

V1 can use FFmpeg scene scoring or a low-resolution histogram/frame-difference algorithm.

Scene detection should process the low-resolution decode at sufficient temporal resolution to avoid missing one-frame cuts.

<a id="m2-s043-0081"></a>

## 48. V1 Face Tracking Without OpenCV

*Source lines 1488–1505.*

Do not add OpenCV just to maintain a face track.

V1 approach:

1. run UltraFace on sampled low-resolution frames
2. associate detections between samples using:
   - IoU
   - center distance
   - size consistency
3. predict/smooth track state with a small Kalman implementation
4. expire a track after a configurable miss window

The detector can be sampled at a configurable rate; it does not need to run on every full-resolution frame.

<a id="m2-s043-0082"></a>

## 49. Smart Reframing

*Source lines 1506–1529.*

Supported targets are data-driven presets:

```text
16:9
9:16
4:5
1:1
custom WxH/aspect
```

The crop algorithm should operate in source **display space**.

V1 inputs:

- stable face tracks
- face group geometry
- simple motion/activity estimate
- output safe zones
- previous crop state

<a id="m2-s043-0084"></a>

## One face

*Source lines 1532–1535.*

*Context: 50. Reframing Behavior*

Track it while respecting composition.

<a id="m2-s043-0085"></a>

## Multiple nearby faces

*Source lines 1536–1539.*

*Context: 50. Reframing Behavior*

Prefer a crop that contains the group.

<a id="m2-s043-0086"></a>

## Multiple separated faces

*Source lines 1540–1545.*

*Context: 50. Reframing Behavior*

V1 should prefer the largest/stablest subject unless the crop can include the group cleanly.

Active-speaker switching is not a default V1 dependency.

<a id="m2-s043-0087"></a>

## No face

*Source lines 1546–1558.*

*Context: 50. Reframing Behavior*

Be conservative:

- preserve original composition when possible
- use a centered/stable crop
- use simple motion/activity to avoid obviously bad framing
- do not invent camera motion unnecessarily

Advanced object-aware nature/B-roll framing belongs in `vision+`.

<a id="m2-s043-0088"></a>

## 51. Composition Rules

*Source lines 1559–1577.*

The crop target is not simply face center.

Use:

- headroom
- rule-of-thirds preference
- body/face margin
- look direction only if a reliable cheap signal exists
- movement direction only if reliable
- multiple-person inclusion
- platform safe zone
- previous crop position

When uncertain, prefer stable composition over continuous movement.

<a id="m2-s043-0089"></a>

## 52. Reframe Smoothing

*Source lines 1578–1598.*

Raw detections must never become direct crop coordinates.

Pipeline:

```text
detections
   -> association
   -> target rectangle
   -> dead zone
   -> Kalman/low-pass smoothing
   -> velocity limit
   -> acceleration limit
   -> keyframes
```

The virtual camera should not chase small head movements.

<a id="m2-s043-0090"></a>

## 53. Reframe Keyframes

*Source lines 1599–1618.*

Store reframing as metadata, not baked pixels.

Example:

```json
{
  "variant":"tiktok",
  "keyframes":[
    {"t":"...","cx":0.52,"cy":0.48,"scale":1.42},
    {"t":"...","cx":0.54,"cy":0.48,"scale":1.42}
  ]
}
```

`cx`/`cy` can be normalized display-space coordinates. Round persisted floating values consistently to avoid noisy diffs.

<a id="m2-s043-0091"></a>

## 54. Platform Presets and Safe Zones

*Source lines 1619–1643.*

Platform behavior changes over time, so safe zones must be data, not algorithm code.

Example:

```toml
[target.tiktok]
width = 1080
height = 1920
aspect = "9:16"

[safe_zone]
top = 0.06
bottom = 0.16
left = 0.05
right = 0.12
```

Safe-zone values are conservative extension presets, not guarantees about a platform's current UI.

Platform preset files should be versioned and updateable independently from the core algorithm.

<a id="m2-s043-0092"></a>

## 55. Automatic Graphic Placement — Scope

*Source lines 1644–1669.*

Automexia can automatically decide **where** and **how** to place a supplied graphic.

Without language understanding it should not claim to automatically decide the semantic moment when an arbitrary chart/logo/callout should exist.

Timing comes from:

- workflow configuration
- subtitle timing
- a user-provided time range
- a reusable template
- optional transcription-based rules when transcription is installed

Supported V1 graphic types:

- logo/watermark
- title
- lower third
- subtitle/caption asset
- supplied image/SVG

Object-following callouts are later/optional.

<a id="m2-s043-0093"></a>

## 56. V1 Graphic Placement Cost Map

*Source lines 1670–1691.*

Default inputs should only depend on capabilities actually installed.

Base cost signals:

```text
face overlap              very expensive
Automexia-owned text      expensive
platform unsafe zone      forbidden/highest cost
frame edge/clutter        moderate
local edge density        moderate
local variance            moderate
motion/activity           moderate
placement movement        penalty
empty/quiet region        preferred
```

Do **not** claim base V1 understands arbitrary people, objects, active speakers, or baked-in text unless the corresponding optional detector is installed.

<a id="m2-s043-0094"></a>

## 57. Graphic Placement Algorithm

*Source lines 1692–1726.*

Evaluate a small set of stable candidate anchors rather than searching every pixel.

Examples:

```text
top-left
top-center
top-right
middle-left
middle-right
bottom-left
bottom-center
bottom-right
```

For each candidate compute:

```text
cost =
    face_overlap
  + known_graphic_overlap
  + unsafe_zone_penalty
  + edge_density
  + visual_activity
  + movement_from_previous_position
```

Choose the lowest-cost candidate satisfying minimum readability constraints.

Placement should be optimized per shot/segment, not every frame.

<a id="m2-s043-0095"></a>

## 58. Graphic Readability

*Source lines 1727–1747.*

Measure the region under text/graphics:

- average luminance
- contrast
- local variance
- edge density

Possible reactions:

- choose light/dark text variant
- add shadow
- add opaque/semi-opaque background plate
- move to another candidate zone
- reduce size within preset limits

If no candidate is safe, prefer a background plate or a less-obstructive placement instead of covering a face.

<a id="m2-s043-0096"></a>

## 59. Graphic Rendering Stack

*Source lines 1748–1775.*

Do not use Chromium/HyperFrames in the default build.

Use static Rust-native assets:

```text
SVG template + supplied text/images
          |
     usvg/resvg
          |
      raster RGBA
          |
     FFmpeg overlay
```

`resvg` is a static SVG renderer; animation comes from Automexia keyframes/FFmpeg transforms, not from SVG animation.

Fonts must be handled deliberately:

- built-in templates should reference fonts that Automexia is allowed to redistribute, or
- use a documented system-font fallback strategy
- project files should record the resolved font family/file identity when reproducibility matters

Do not silently substitute a dramatically different font without warning for a professional export.

<a id="m2-s043-0097"></a>

## 60. Subtitle Input

*Source lines 1776–1790.*

Subtitles do not require transcription if a subtitle file already exists.

Support ingest of common text subtitle formats as appropriate, such as:

- SRT
- WebVTT

Optional `whisper.cpp` can generate subtitle timing/text when the transcription feature is installed.

Subtitle placement uses known caption boxes and face/safe-zone avoidance.

<a id="m2-s043-0098"></a>

## 61. Effects and Transitions — V1 Philosophy

*Source lines 1791–1815.*

Automatic effects should solve editing problems, not decorate footage.

V1 effects:

- hard cuts
- subtle crop/punch-in changes
- short fades/dissolves only when an explicit rule/preset allows them
- basic title/lower-third fade or slide
- reframe motion

Not V1:

- whip transitions
- flash transitions
- automatic motion blur
- background segmentation
- cinematic masking
- complex compositing
- automatic speed ramps
- beat-synchronized editing

<a id="m2-s043-0099"></a>

## 62. Punch-In Rules

*Source lines 1816–1839.*

Punch-ins primarily hide or soften talking-head jump cuts.

Possible base triggers:

- a silence-removal cut inside the same detected scene
- a long static shot exceeding a preset interval

Optional triggers only when their feature exists:

- sentence boundary from transcription
- speaker change from future speaker tracking

Rules:

- use small zoom changes by default
- enforce a minimum interval
- avoid zooming if the face would violate safe margins
- reset behavior at scene changes
- do not alternate zoom mechanically on every cut

<a id="m2-s043-0100"></a>

## 63. Transition Rules

*Source lines 1840–1853.*

Default transition is a hard cut.

A clean preset may allow a short dissolve/fade only when:

- the segments represent a clear scene/section change
- the edit is not simply a silence-removal jump cut
- the transition does not damage speech/audio continuity

If confidence is low, use a hard cut.

<a id="m2-s043-0101"></a>
````


<a id="s7"></a>

## Rendering and interchange

**Source:** `docs/developer/future/video-automation-details/part-01.md`, archive-file lines 1045–1277.  
**Source file SHA-256:** `2927f93989a3013fd1b65f4b7d4ae6dcfd04f293472f0d6ba081e1bcaaed789c`

The following fenced block preserves the source text verbatim. Section-local source-line numbers inside it refer to the earlier source documents, not the archive-file line range above.

````markdown
## 65. Platform Variants

*Source lines 1883–1902.*

One master edit should create multiple output compositions.

```text
                    Master edit
                        |
          ┌─────────────┼─────────────┐
          ▼             ▼             ▼
        16:9           9:16           4:5
          |             |             |
       YouTube        TikTok        Feed/Reel
```

Time edits and common audio corrections belong to the master edit.

Reframe and graphic placement are variant-specific because output geometry and safe zones differ.

<a id="m2-s043-0103"></a>

## 66. Render Graph Ordering

*Source lines 1903–1932.*

A typical video branch should compile in roughly this order:

```text
source orientation / normalization
    -> timeline trims/concats
    -> shot-level color correction
    -> variant crop/reframe
    -> scale/output geometry
    -> graphic overlays
    -> output pixel/color format
    -> encoder
```

Audio branch:

```text
selected source audio
    -> source-level cleanup / RNNoise where enabled
    -> timeline cuts/assembly
    -> EQ / de-ess / compression
    -> loudness normalization / limiting
    -> output audio encoder
```

Exact ordering may be adjusted after quality testing, but it must be deterministic and documented.

<a id="m2-s043-0104"></a>

## 67. Multi-Target Render Optimization

*Source lines 1933–1958.*

Default caching should focus on analysis metadata.

For rendering multiple variants, the compiler should prefer a **single FFmpeg process with shared decode/common filters and split branches** when practical:

```text
source decode
     |
common edits/color/audio
     |
   split
  /  |  \
16:9 9:16 4:5
 |    |    |
encode each target
```

This avoids creating large intermediate master files solely for caching.

If memory/encoder constraints make a combined graph unreliable, fall back to sequential target renders.

Rendered intermediate caching can be an opt-in optimization for repeated professional workflows, not the default.

<a id="m2-s043-0105"></a>

## 68. Render Presets

*Source lines 1959–1997.*

Separate **edit presets** from **output presets**.

Edit preset:

```text
clean
social
podcast
```

Output target:

```text
youtube
tiktok
reel
feed
square
master
```

Output presets specify:

- width/height or aspect
- frame-rate behavior
- container preference
- encoder preference order
- quality mode
- audio codec preference
- pixel format
- color metadata policy
- safe zone

Do not bury editing behavior inside a codec preset.

<a id="m2-s043-0106"></a>

## 69. Codec Selection

*Source lines 1998–2021.*

The output preset expresses preferences, not assumptions.

Example preference:

```text
H.264 target
    -> preferred available hardware H.264 encoder
    -> compatible software H.264 encoder
    -> clear unsupported-capability error
```

Professional master:

```text
ProRes target
    -> available compatible ProRes encoder
```

The extension must report the chosen encoder in the project/render report.

<a id="m2-s043-0107"></a>

## 70. Output Collision and Atomicity

*Source lines 2022–2035.*

Rules:

- never overwrite an existing output by default
- require `--overwrite` or generate a new deterministic filename
- render to a temporary path first when possible
- atomically rename completed output into place
- remove incomplete files on failure unless `--keep-temp` is set

Project writes should also use write-temp-then-rename to avoid corrupting `.amxv` on crash.

<a id="m2-s043-0108"></a>

## 71. Project Export vs Render

*Source lines 2036–2051.*

These are separate operations.

```text
video render
    -> final media

video export
    -> editable timeline/project interchange
```

Do not call a rendered MP4 an exported project.

<a id="m2-s043-0109"></a>

## 72. V1 NLE Interchange Strategy

*Source lines 2052–2079.*

Use a neutral internal Automexia timeline and dedicated exporters.

Initial formats:

- **OTIO JSON (`.otio`)** — preferred structural interchange where the target supports it
- **Final Cut Pro 7 XML / legacy Final Cut Pro XML** — useful for Premiere-compatible XML workflows
- **CMX 3600 EDL** — simple universal fallback

Important terminology:

- legacy Final Cut Pro XML and modern Final Cut Pro `.fcpxml` are not the same format
- current Premiere documentation supports Final Cut Pro XML workflows but does not directly import modern Final Cut Pro X `.fcpxml` without conversion
- do not label a legacy XML exporter simply `fcpxml`

Suggested CLI names:

```text
--format otio
--format fcp7xml
--format edl
```

Modern Final Cut Pro `.fcpxml`, AAF, proprietary Premiere project files, and Resolve project files are later work.

<a id="m2-s043-0110"></a>

## 73. NLE Target Mapping

*Source lines 2080–2098.*

V1 logical target mapping:

```text
--to resolve
    -> prefer OTIO after compatibility test
    -> export report

--to premiere
    -> prefer legacy Final Cut Pro XML
    -> EDL fallback for very simple timelines
    -> export report
```

Do not assume all NLE versions support the same features. Maintain automated interoperability fixtures for supported target versions.

<a id="m2-s043-0111"></a>
````


<a id="s8"></a>

## Optional packs, full feature inventory and future scope

**Source:** `docs/developer/future/video-automation-details/part-02.md`, archive-file lines 481–722.  
**Source file SHA-256:** `835588ffc63c76eb531c48798864852e6de3032b64e3d4bb7e3a2b6bb84a1e2a`

The following fenced block preserves the source text verbatim. Section-local source-line numbers inside it refer to the earlier source documents, not the archive-file line range above.

````markdown
## 88. Feature Pack Installation

*Source lines 2457–2473.*

Keep one video extension. Do not fragment it into many user-visible extensions.

Example management commands:

```bash
automexia ext install video
automexia ext feature add video transcription
automexia ext feature add video voice-quality
automexia ext feature remove video transcription
```

Normal editing commands remain unchanged.

<a id="m2-s043-0136"></a>

## 89. V1 Presets

*Source lines 2474–2477.*

Keep built-in edit presets few and understandable.

<a id="m2-s043-0137"></a>

## `clean`

*Source lines 2478–2486.*

*Context: 89. V1 Presets*

- natural pause shortening
- conservative RNNoise
- spoken-word EQ/compression
- conservative color correction
- subtle jump-cut mitigation
- no automatic aspect conversion unless requested

<a id="m2-s043-0138"></a>

## `social`

*Source lines 2487–2495.*

*Context: 89. V1 Presets*

- tighter pauses
- stronger but bounded voice presence
- face-aware social reframing when target is vertical/square
- platform safe zones
- slightly more frequent punch-ins
- still conservative transitions

<a id="m2-s043-0139"></a>

## `podcast`

*Source lines 2496–2506.*

*Context: 89. V1 Presets*

- natural pauses by default
- strong focus on voice consistency
- minimal visual effects
- multi-person framing tries to preserve the group

Users can create custom presets rather than requiring dozens of built-ins.

<a id="m2-s043-0140"></a>

## 90. V1 Deliverable

*Source lines 2507–2512.*

V1 should solve this job well:

> Take ordinary talking-head, course, podcast, or creator footage and produce a clean, polished, correctly framed output with one command.

<a id="m2-s043-0141"></a>

## V1 editing

*Source lines 2513–2520.*

*Context: 90. V1 Deliverable*

- media probe
- one shared low-resolution analysis pass
- smart silence shortening
- audio/video cut smoothing
- subtle jump-cut punch-ins

<a id="m2-s043-0142"></a>

## V1 audio

*Source lines 2521–2530.*

*Context: 90. V1 Deliverable*

- RNNoise
- high-pass/rumble cleanup
- conservative EQ
- de-essing
- compression
- loudness normalization
- limiter

<a id="m2-s043-0143"></a>

## V1 video

*Source lines 2531–2538.*

*Context: 90. V1 Deliverable*

- scene detection
- SDR-only conservative exposure/white-balance correction
- basic contrast correction
- UltraFace detection
- light face tracking

<a id="m2-s043-0144"></a>

## V1 reframing

*Source lines 2539–2550.*

*Context: 90. V1 Deliverable*

- 16:9
- 9:16
- 4:5
- 1:1
- custom aspect
- face-aware crop
- dead zone and smooth crop
- conservative no-face fallback
- platform safe zones

<a id="m2-s043-0145"></a>

## V1 graphics

*Source lines 2551–2559.*

*Context: 90. V1 Deliverable*

- logo
- title
- lower third
- existing subtitle input
- safe automatic placement
- fade/slide/simple scale animation

<a id="m2-s043-0146"></a>

## V1 project/output

*Source lines 2560–2572.*

*Context: 90. V1 Deliverable*

- `.amxv` JSON project
- dry run
- multi-target rendering
- logical H.264/H.265/ProRes/WebM/master presets subject to detected encoder support
- OTIO export
- legacy Final Cut Pro XML export for Premiere workflows
- CMX 3600 EDL fallback
- export compatibility report

<a id="m2-s043-0147"></a>

## 91. V2 Candidates

*Source lines 2573–2591.*

Only add based on usage data and user demand.

Candidates:

- `whisper.cpp` transcription pack
- generated subtitles
- filler-word workflow
- sentence-aware punch-in triggers
- DeepFilterNet quality pack
- small object/person detector
- improved nature/B-roll reframing
- active-speaker tracking
- more robust graphic placement
- better export fidelity

<a id="m2-s043-0148"></a>

## 92. V3 / Later Candidates

*Source lines 2592–2609.*

- advanced stabilization
- optical-flow tracking
- object-following callouts
- speed ramps
- beat-aware editing
- segmentation/background effects
- richer animation templates
- multi-camera workflows
- AAF
- modern Final Cut Pro `.fcpxml`
- advanced shot matching

None of these justify adding a GUI requirement.

<a id="m2-s043-0149"></a>

## 93. Things Explicitly Excluded from the Default Path

*Source lines 2610–2633.*

```text
WhisperX
HyperFrames
Python
PyTorch
TensorFlow
Node.js
Chromium
large language models
AI agents
paid inference APIs
cloud media processing
OpenCV unless vision-advanced is installed
DeepFilterNet unless voice-quality is installed
whisper.cpp unless transcription is installed
large object/segmentation models
full NLE GUI/TUI
custom GPU compositor
```

<a id="m2-s043-0151"></a>
````


<a id="s9"></a>

## Media authority, cache and detector/enhancer choices

**Source:** `docs/developer/future/video-automation-details/part-03.md`, archive-file lines 951–1313.  
**Source file SHA-256:** `14efd5a85708b08fd6f59e730e76df928919b9e8e1a5c38ac557aa58fd870984`

The following fenced block preserves the source text verbatim. Section-local source-line numbers inside it refer to the earlier source documents, not the archive-file line range above.

````markdown
## 106. Correct Extension Integration

*Source lines 3025–3069.*

*Context: Automexia — Architecture & Video Automation Specification*

The video extension is a first-party domain extension, not a privileged exception to Automexia architecture.

```text
Automexia Core
    ├── Extension Runtime
    ├── Policy Engine
    ├── ProcessBroker
    ├── Capability Broker
    ├── Job Manager
    ├── Overlay System
    ├── Evidence Graph
    └── Automexia Lab
             │
             ▼
      automexia-video
             │
      ┌──────┼──────────┐
      ▼      ▼          ▼
  Analysis  Rust       Exporters
            Decision
            Engine
      │      │
      └──┬───┘
         ▼
       .amxv
         │
         ▼
     RenderPlan
         │
         ▼
  Automexia ProcessBroker
         │
    verified FFmpeg
         │
      sandbox
         │
      output
```

The video worker may request media-tool execution. It never receives an unrestricted `run arbitrary executable` capability.

<a id="m2-s095-0174"></a>

## 107. FFmpeg Distribution Strategy

*Source lines 3070–3100.*

*Context: Automexia — Architecture & Video Automation Specification*

An Automexia-managed pinned/verified FFmpeg package is the preferred reproducibility candidate, **subject to a future distribution/licensing/security/signing ADR**. A fully probed system/package-manager FFmpeg remains a viable alternative if it better matches deployment policy.

The runtime identity includes:

```text
FFmpeg source/version
binary hash
build/configure flags
linked codec/filter libraries
license mode
platform/architecture
supported encoder/filter capability snapshot
```

If a managed runtime is selected, advanced users may explicitly select a compatible system FFmpeg. If system FFmpeg is the selected distribution strategy, Automexia still records exact executable/build capability identity.

System FFmpeg is not assumed equivalent to the managed build. It is fully probed and stored as a distinct runtime identity in project/render provenance.

This improves:

- reproducibility;
- supportability;
- codec/filter testing;
- license clarity;
- security review;
- stable benchmark baselines.

<a id="m2-s095-0175"></a>

## 108. ProcessBroker and Media Sandbox

*Source lines 3101–3142.*

*Context: Automexia — Architecture & Video Automation Specification*

FFmpeg/ffprobe execution goes through Automexia ProcessBroker.

Conceptual Rust plan:

```rust
pub struct MediaProcessPlan {
    pub tool: MediaTool,
    pub executable: ExecutableIdentity,
    pub args: Vec<OsString>,
    pub input_grants: Vec<PathGrant>,
    pub output_grants: Vec<PathGrant>,
    pub temp_dir: PathBuf,
    pub network: NetworkPolicy,
    pub limits: ResourceLimits,
}
```

Normal media processing policy:

```text
READ
    explicit source media
    explicit project assets
    approved models/fonts/runtime assets

WRITE
    request temp directory
    analysis cache
    explicit output directory

NETWORK
    DENY
```

Where OS sandboxing permits it, FFmpeg/media workers should not be able to read unrelated home-directory data, SSH keys, cloud credentials, or browser profiles.

All child processes are owned by the ProcessBroker for cancellation and cleanup.

<a id="m2-s095-0176"></a>

## 109. Worker Protocol Hardening

*Source lines 3143–3163.*

*Context: Automexia — Architecture & Video Automation Specification*

A first prototype may use JSONL, but the production design should prefer a dedicated inherited pipe/handle with length-prefixed messages.

```text
[u32 bounded length]
[JSON payload]
```

Rules:

- protocol stdout is not shared with arbitrary native-library stdout;
- payload length is validated before allocation;
- maximum frame size is fixed;
- outstanding requests are bounded;
- request IDs, cancellation, deadlines, and protocol versions are explicit;
- media bytes are transferred through files/descriptors/pipes, not JSON/base64;
- stderr is diagnostics only and is bounded/redacted.

<a id="m2-s095-0177"></a>

## 110. `.amxv` Is the Edit-Intent Source of Truth

*Source lines 3164–3193.*

*Context: Automexia — Architecture & Video Automation Specification*

The `.amxv` file should remain:

```text
human-readable
Git-diffable
portable
migration-friendly
non-destructive
```

It stores:

- media references/fingerprints;
- selected streams;
- resolved preset snapshot;
- typed edit operations;
- confidence/reason/safety information;
- variant-specific keyframes;
- model/algorithm identities;
- render/export provenance;
- references to analysis-cache identity.

Do **not** turn `.amxv` into a massive observation database.

Large face samples, VAD streams, motion samples, and luma/color statistics belong in a separate machine-oriented analysis cache.

<a id="m2-s095-0178"></a>

## 111. Analysis Cache and Content Identity

*Source lines 3194–3227.*

*Context: Automexia — Architecture & Video Automation Specification*

Separate:

```text
FastFingerprint
```

from:

```text
ContentIdentity
```

Fast cache identity can combine:

```text
size
mtime
first chunk hash
middle chunk hash
final chunk hash
```

High-integrity/professional workflows may request a full BLAKE3/SHA-256 content hash.

Path is a locator, not permanent content identity.

The analysis cache may use SQLite, CBOR, MessagePack, or another bounded indexed representation selected by benchmarks.

The cache stores observations; `.amxv` stores decisions.

<a id="m2-s095-0179"></a>

## 112. Streaming Analysis and Backpressure

*Source lines 3228–3256.*

*Context: Automexia — Architecture & Video Automation Specification*

Do not accumulate decoded video frames or a full long-form podcast's observations in unbounded `Vec`s.

Use bounded pipelines:

```text
low-res decoder
    ↓
bounded frame queue
    ├── FaceDetector
    ├── scene detector
    ├── color/luma stats
    └── motion stats

analysis audio
    ↓
bounded audio queue
    ├── Silero VAD
    ├── loudness/energy
    └── noise/music-bed stats
```

Each analyzer declares sampling requirements.

Cancellation and backpressure are mandatory.

<a id="m2-s095-0180"></a>

## 113. Face Detector Architecture

*Source lines 3257–3293.*

*Context: Automexia — Architecture & Video Automation Specification*

The decision engine depends on:

```rust
pub trait FaceDetector {
    fn detect(&mut self, frame: &AnalysisFrame)
        -> Result<Vec<FaceDetection>>;
}
```

Candidate policy:

```text
YuNet ONNX
    primary 2026 candidate

UltraFace
    benchmark/legacy candidate
```

The release default is selected from Automexia's own media corpus based on:

- false-negative rate;
- false-positive rate;
- profile/edge-face behavior;
- small-face behavior;
- CPU throughput;
- memory;
- cross-platform repeatability.

The detector only observes.

Rust owns tracking, composition, smoothing, crop safety, and keyframe decisions.

<a id="m2-s095-0181"></a>

## 114. SpeechEnhancer Architecture

*Source lines 3294–3354.*

*Context: Automexia — Architecture & Video Automation Specification*

Do not make RNNoise mandatory.

Use:

```rust
pub trait SpeechEnhancer {
    fn info(&self) -> EnhancerInfo;
    fn process(
        &mut self,
        audio: &AudioChunk,
        config: &EnhancementConfig,
    ) -> Result<AudioChunk>;
}
```

The default preset is:

```text
voice_enhancer = auto
```

Rust decides first:

```rust
pub enum EnhancementDecision {
    Preserve,
    TraditionalCleanup,
    Neural {
        engine: EnhancerId,
        strength: f32,
    },
    NeedsReview,
}
```

Clean audio should often choose `Preserve`.

Candidate roles:

```text
Traditional FFmpeg DSP
    always-available conservative baseline

WebRTC AudioProcessing
    active low-cost/reference/communications candidate

RNNoise
    optional lightweight/legacy backend
    pin/vendor only if Automexia corpus justifies it

DeepFilterNet
    primary high-quality candidate
    blocked from bundled-model release until exact weight redistribution rights are approved
```

A slowly maintained library is not rejected only because commits are old. It simply cannot become an irreplaceable architecture dependency without an ownership/maintenance plan.
````


<a id="s10"></a>

## Timing, HDR, review, render modes and NLE export

**Source:** `docs/developer/future/video-automation-details/part-04.md`, archive-file lines 143–338.  
**Source file SHA-256:** `e11bfd776b31bfbdf7e791bbfc44e441da62ba9298510db63c5144640b8d8304`

The following fenced block preserves the source text verbatim. Section-local source-line numbers inside it refer to the earlier source documents, not the archive-file line range above.

````markdown
## 117. Time Model Hardening

*Source lines 3438–3455.*

*Context: Automexia — Architecture & Video Automation Specification*

In addition to rational PTS/time-base handling, normalize:

- stream start times;
- negative timestamps;
- container edit lists;
- AAC priming/encoder delay;
- Opus pre-skip;
- DTS vs PTS;
- B-frame reordering.

Use a normalized source timeline mapping while preserving original source timing references in `.amxv`.

A/V sync is verified through real render/probe/media tests, not only unit math.

<a id="m2-s095-0185"></a>

## 118. HDR Capability Matrix

*Source lines 3456–3479.*

*Context: Automexia — Architecture & Video Automation Specification*

HDR safety is operation-specific.

Do not assume that preserving metadata means preserving HDR content.

Initial policy should explicitly qualify:

```text
trim                 supported
compatible concat    tested path only
audio processing     supported
crop                 only validated 10-bit path
scale                only validated HDR path
auto exposure        blocked initially
auto white balance   blocked initially
8-bit graphic overlay blocked until validated
Dolby Vision dynamic metadata preserve-only/unsupported initially
```

Unsupported transforms fail visibly rather than silently converting or lying about metadata.

<a id="m2-s095-0186"></a>

## 119. Human Review Is a Core Video Capability

*Source lines 3480–3522.*

*Context: Automexia — Architecture & Video Automation Specification*

Add:

```bash
video review PROJECT
```

This is a keyboard-first Automexia overlay, not an NLE timeline.

Example:

```text
EDIT REVIEW — recording.amxv

37 pause edits
8 reframe/punch-in proposals

> 02:14.230  Silence  3.8s → 0.4s  confidence 72%
  03:01.150  Silence  2.1s → 0.3s  confidence 96%

Enter   Preview
A       Approve
R       Reject
L       Lock
Space   Toggle
Esc     Close
```

Every automated operation ends with a disposition:

```rust
pub enum DecisionDisposition {
    AutoApply,
    NeedsReview,
    Ignore,
}
```

Confidence thresholds are feature-specific.

<a id="m2-s095-0187"></a>

## 120. Review Proxy Clips

*Source lines 3523–3546.*

*Context: Automexia — Architecture & Video Automation Specification*

For medium-confidence edits, generate low-resolution review proxies containing a short window around the proposal.

Example:

```text
2–3 seconds before
proposed edit
2–3 seconds after
```

Useful for:

- silence cuts;
- jump-cut punch-ins;
- reframes;
- color proposals;
- graphic placement.

Review proxies are temporary/cache artifacts, not source-of-truth media.

<a id="m2-s095-0188"></a>

## 121. Render Modes

*Source lines 3547–3577.*

*Context: Automexia — Architecture & Video Automation Specification*

Expose intent-based modes instead of forcing codec expertise:

```text
video render project.amxv --mode preview
video render project.amxv --mode fast
video render project.amxv --mode publish
video render project.amxv --mode master
```

Conceptually:

```text
preview
    low-resolution fast review

fast
    hardware encoding allowed

publish
    normal delivery quality

master
    validated high-quality/mezzanine path
```

Every render records the chosen actual encoder and runtime identity.

<a id="m2-s095-0189"></a>

## 122. NLE Export Strategy

*Source lines 3578–3610.*

*Context: Automexia — Architecture & Video Automation Specification*

Keep:

```text
OTIO JSON
legacy FCP/FCP7 XML
CMX3600 EDL
```

as initial interchange targets.

Prefer native Rust exporters for the subset Automexia promises. Do not add Python only to reuse adapter plugins.

Export claims are version-qualified:

```text
target application
version family
OS if relevant
format
features preserved
features translated
features baked
known unsupported items
```

Real import fixtures are required. Valid XML/JSON alone is not release evidence.

Never claim lossless Premiere/Resolve project conversion.

<a id="m2-s095-0190"></a>
````


<a id="s11"></a>

## Original staged roadmap and revised product promise

**Source:** `docs/developer/future/video-automation-details/part-04.md`, archive-file lines 540–605.  
**Source file SHA-256:** `e11bfd776b31bfbdf7e791bbfc44e441da62ba9298510db63c5144640b8d8304`

The following fenced block preserves the source text verbatim. Section-local source-line numbers inside it refer to the earlier source documents, not the archive-file line range above.

````markdown
## 127. Staged Implementation Roadmap

*Source lines 3795–3820.*

*Context: Automexia — Architecture & Video Automation Specification*

Do not build every smart feature simultaneously.

| Phase | Scope | Exit gate |
|---|---|---|
| V0 | worker protocol, existing external-tool boundary, sandbox, selected verified FFmpeg/ffprobe after distribution ADR, `.amxv`, time/color/stream model | no-op round-trip corpus passes |
| V0.1 | VideoLab, cache, cancellation/failure injection, output validation | foundation passes required native OSes |
| V1 | Silero + deterministic pause editing | pause naturalness/keep-rate target |
| V1.1 | audio preflight + SpeechEnhancer selection + loudness chain | blind listening + audio regression gate |
| V1.2 | scene + FaceDetector abstraction + YuNet/UltraFace benchmark + tracking | tracking/reframe quality gate |
| V1.3 | 16:9 / 9:16 / 4:5 / 1:1 variants | crop/safe-zone quality gate |
| V1.4 | review overlay + proxy previews | medium-confidence review usability gate |
| V1.5 | graphics/subtitles/lower thirds | placement/readability regression gate |
| V1.6 | multi-target render optimization | equivalent-output validation vs sequential path |
| V1.7 | OTIO/FCP7XML/EDL | real NLE import fixtures pass |
| V2 | optional transcription | pack quality/license gate |
| V2 | optional higher-quality voice engine | model-license + quality gate |
| V2 | vision+ | demonstrated demand + quality gate |

The guiding rule is:

> Get one vertical slice boringly reliable before adding the next one.

<a id="m2-s095-0195"></a>

## 128. Revised V1 Product Promise

*Source lines 3821–3853.*

*Context: Automexia — Architecture & Video Automation Specification*

V1 should promise:

> **Automate the boring 80% of spoken-word post-production.**

Strong initial targets:

```text
talking-head video
courses/tutorials
podcasts
YouTube commentary
product demos
screen recording + presenter
social repurposing
```

Do not market V1 as a universal video editor for:

```text
cinema/narrative editing
sports
music videos
complex multicamera
heavy motion graphics
artistic color grading
```

Reliability comes from constrained scope.

<a id="m2-s095-0196"></a>
````


<a id="s12"></a>

## VideoLab test and quality requirements

**Source:** `docs/developer/verification/video-lab.md`, archive-file lines 30–375.  
**Source file SHA-256:** `1f0c77c42052489f89c34b49199e09558f46387ba6b00042e4533fd43869cea7`

The following fenced block preserves the source text verbatim. Section-local source-line numbers inside it refer to the earlier source documents, not the archive-file line range above.

````markdown
### VideoLab — Media Quality, Security, and Regression Harness

*Source I044 (original archive reference: `../../project/merge-audit/round4/source-directory.md#i044`), lines 401–414.*

*Context: VideoLab: Conditional Media Qualification and Delivery*

VideoLab is the Automexia Lab module for `automexia-video`.

Its job is to prove media correctness, edit quality, security, resource bounds, failure recovery, and interoperability before a smart-edit capability is activated.

<a id="r4-i044-0017"></a>

### Corpus

*Source I044 (original archive reference: `../../project/merge-audit/round4/source-directory.md#i044`), lines 415–455.*

*Context: VideoLab: Conditional Media Qualification and Delivery*

Maintain legally distributable/internal fixtures covering at least:

```text
webcam
DSLR/mirrorless
iPhone / Android
VFR phone footage
OBS/screen recording
video-call recording
podcast
lav / USB / room microphone
fan / keyboard / street / cafe noise
background music
clipped audio
single / multiple / profile faces
faces entering/exiting frame
portrait / rotation metadata
23.976 / 29.97 / 59.94
10-bit
HDR10 / HLG / Dolby Vision metadata case
interlaced
multiple audio streams
5.1
AAC priming
Opus pre-skip
long-GOP
broken timestamps
```

Build the corpus before aggressive algorithm tuning.

<a id="r4-i044-0018"></a>

### Deterministic scenarios

*Source I044 (original archive reference: `../../project/merge-audit/round4/source-directory.md#i044`), lines 456–487.*

*Context: VideoLab: Conditional Media Qualification and Delivery*

Scenarios operate over the full pipeline:

```text
probe -> analyze -> decide -> .amxv -> review -> compile -> render -> validate -> export
```

Example:

```yaml
scenario: natural-pause-cleanup
input: corpus/talking-head-01.mov
preset: clean
expect:
  silence_edits:
    min: 30
    max: 38
  speech_damage_regions:
    max: 0
  av_sync_ms:
    max: 10
```

<a id="r4-i044-0019"></a>

### Speech-enhancer bake-off

*Source I044 (original archive reference: `../../project/merge-audit/round4/source-directory.md#i044`), lines 488–523.*

*Context: VideoLab: Conditional Media Qualification and Delivery*

Compare:

```text
Original
Traditional DSP
WebRTC AudioProcessing
RNNoise
DeepFilterNet candidate
```

Measure:

```text
noise attenuation
speech preservation
sibilance/transient damage
breath preservation
musical noise
CPU
RAM
throughput
model/startup time
```

Also run blind human listening. A denoiser is not selected by numeric noise suppression alone.

<a id="r4-i044-0020"></a>

### Face-detector bake-off

*Source I044 (original archive reference: `../../project/merge-audit/round4/source-directory.md#i044`), lines 524–547.*

*Context: VideoLab: Conditional Media Qualification and Delivery*

Compare YuNet, UltraFace, and future approved alternatives using the same corpus.

Measure:

```text
false negatives
false positives
profile/edge faces
small-face behavior
CPU
RAM
cross-platform repeatability
```

<a id="r4-i044-0021"></a>

### Decision quality

*Source I044 (original archive reference: `../../project/merge-audit/round4/source-directory.md#i044`), lines 548–590.*

*Context: VideoLab: Conditional Media Qualification and Delivery*

Silence metrics:

```text
speech damaged/removed
pause precision
retained-pause distribution
manual reject rate
```

Reframe metrics:

```text
face clipped rate
safe-zone rate
crop jitter
crop velocity/acceleration
manual correction rate
```

Color metrics:

```text
auto-correction reject rate
clipping change
shot inconsistency
```

A key product metric is:

```text
percentage of automated edits users keep
```

<a id="r4-i044-0022"></a>

### Failure injection

*Source I044 (original archive reference: `../../project/merge-audit/round4/source-directory.md#i044`), lines 591–615.*

*Context: VideoLab: Conditional Media Qualification and Delivery*

Inject:

Expected:

```text
source media unchanged
valid .amxv not corrupted
terminal alive
owned child processes cleaned
incomplete outputs handled predictably
valid analysis cache reusable where safe
```

<a id="r4-i044-0023"></a>

### Hostile media

*Source I044 (original archive reference: `../../project/merge-audit/round4/source-directory.md#i044`), lines 616–647.*

*Context: VideoLab: Conditional Media Qualification and Delivery*

Test malformed/corrupt:

```text
MP4/MKV/MOV
subtitles
SVGs
metadata
bogus dimensions/durations
negative/broken timestamps
playlist/network references
stream tables
```

Verify:

```text
network remains denied
memory/process/temp usage bounded
terminal survives
sandbox grants remain scoped
```

<a id="r4-i044-0024"></a>

### Timing/A/V sync

*Source I044 (original archive reference: `../../project/merge-audit/round4/source-directory.md#i044`), lines 648–670.*

*Context: VideoLab: Conditional Media Qualification and Delivery*

Validate rational timing plus:

```text
start offsets
edit lists
AAC priming
Opus pre-skip
DTS/PTS differences
B-frame reordering
```

Post-render A/V sync is a release metric.

<a id="r4-i044-0025"></a>

### HDR matrix

*Source I044 (original archive reference: `../../project/merge-audit/round4/source-directory.md#i044`), lines 671–682.*

*Context: VideoLab: Conditional Media Qualification and Delivery*

Maintain fixtures for every operation that claims HDR support. Copying metadata is not sufficient evidence.

<a id="r4-i044-0026"></a>

### Render validation

*Source I044 (original archive reference: `../../project/merge-audit/round4/source-directory.md#i044`), lines 683–707.*

*Context: VideoLab: Conditional Media Qualification and Delivery*

A zero FFmpeg exit code is not sufficient.

Validate with ffprobe and targeted media checks:

```text
file exists/nonzero
expected duration
resolution
streams
channel layout
frame-rate mode
color/HDR policy
A/V sync
```

<a id="r4-i044-0027"></a>

### NLE interoperability

*Source I044 (original archive reference: `../../project/merge-audit/round4/source-directory.md#i044`), lines 708–728.*

*Context: VideoLab: Conditional Media Qualification and Delivery*

For every supported target/version family:

```text
export
open/import in real application
inspect cuts/tracks/markers/transitions/audio/relinks
compare against expected timeline
```

Syntax validation alone does not qualify an exporter.

<a id="r4-i044-0028"></a>

### Performance

*Source I044 (original archive reference: `../../project/merge-audit/round4/source-directory.md#i044`), lines 729–752.*

*Context: VideoLab: Conditional Media Qualification and Delivery*

Benchmark low/mid/high representative hardware:

```text
analysis wall time
peak RSS
worker idle/startup memory
render speed
cache speedup
VAD throughput
face detector throughput
preview latency
multi-target shared-vs-sequential efficiency
```

<a id="r4-i044-0029"></a>

### Dependency/runtime drift qualification

*Source I044 (original archive reference: `../../project/merge-audit/round4/source-directory.md#i044`), lines 753–775.*

*Context: VideoLab: Conditional Media Qualification and Delivery*

Any upgrade to FFmpeg, ONNX Runtime, Silero, YuNet/FaceDetector, SpeechEnhancer, resvg, or NLE exporter logic runs the same frozen VideoLab corpus before adoption.

Do not approve a new dependency solely because it is newer. Compare:

```text
edit-decision stability
quality metrics
human review acceptance
performance/RAM
cross-platform behavior
license/provenance
security advisories
```

The corpus is the release authority for model/backend changes.

````
