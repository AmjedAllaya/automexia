# Step 11 — package and qualify the non-AI Video extension

**Version:** 0.11.0-rc.1. **Base:** verified Step 10 handoff 0.10.1.
**Project schema:** 7, unchanged. **Current artifact:** source qualification
candidate, not a compiled/loadable/signed extension release.

[Quick start](QUICKSTART.md) · [Current scope](SUPPORTED-SCOPE.md) ·
[Qualification procedure](RELEASE-QUALIFICATION.md) ·
[Current verification](../reports/step11/verification.json) ·
[Review log](STEP-11-REVIEW.md) · [Integration](INTEGRATION.md)

## 1. Work in the actual extension core

The native subtitle publisher contained a call to `media_guard()` that had no
binding in that method. A similarly named closure exists only in the separate
interchange method and cannot be used here. It is replaced with the actual
`self.revalidate_input(source, cancel)` call before the final protected-path and
publication checks. This fixes an identified compile defect and restores the
intended source-identity check; it is not described as a compiled test pass.

`ReviewSession` instances returned through `VideoExtension::review_project` now
carry the extension's existing lifetime cancellation. Disable, cancel_all and
owner drop invalidate them and their preview tokens. Resetting a search, selection
or decision cannot replace that link with a fresh unrelated token. Re-enable
creates a new lifetime; old reviews remain closed. Standalone `ReviewSession::new`
remains explicitly caller-owned and compatible with direct use outside a host.

A closed/invalidated review still provides its in-memory project for recovery; it
does not silently save or discard edits. Snapshot reports the closed state and
rejects new mutations. Dropping the owner cancels tokens even when its mutexes
were poisoned. The host still controls serialized UI events, player shutdown and
waiting for jobs before native unloading.

Native Unix fingerprint opens now use nonblocking/no-follow flags on the final
path component. Project and graphic/font reads reuse the same regular-file opener
and cancellation-aware bounded reads rather than reopening with a blocking
`File::open`. A source replaced by a FIFO cannot hold revalidation in a blocking
open; a source replaced by a symlink cannot silently redirect it. The parent
hierarchy and OS permissions remain host responsibilities. This is not a new
sandbox, credential system or extension platform. Staged-output size checks reject
symlinks instead of following them. Requests already cancelled or with zero
deadlines are rejected before child creation; no process is launched to discover
those preconditions.

## 2. Regression coverage added

[Core release tests](../tests/release.rs) exercise lazy construction, settings,
review ownership, repeated lifecycle changes, disabled operation refusal,
recoverable decisions and sibling review independence. [Native release tests](../tests/native_release.rs)
exercise real file publication, sidecar source changes/collisions/cancellation,
staged-output cleanup, protected aliases and Unix symlink/FIFO replacement.
These are actual Rust tests; their supplied source is not counted as execution.

The new [independent failure suite](../tests/media/run_release_checks.py) uses
actual FFmpeg/ffprobe commands derived from the production prefixes: disguised
HLS/concat inputs with a localhost connection canary; corrupt/truncated media;
filenames with Unicode and shell punctuation; 5.1 and fractional-rate long-GOP
footage; forced termination, permission denial, `/dev/full`, missing destinations;
original-file preservation and two bounded resource measurements. These do not
exercise the Rust adapter or certify source-file alias checking in that adapter.

## 3. Reproducible qualification instead of inferred test success

[tools/qualify_release.py](../tools/qualify_release.py) orchestrates the existing
Cargo, graphics/native, independent-media and packaging tests. It is developer
support for Step 11, not a replacement video product. Commands, exit statuses,
logs, source fingerprints and report totals are recorded separately. Missing
Rust/Cargo or Cargo.lock yields `blocked`; passing media scripts do not promote
that result to a build success. Outputs go outside the source tree, with a new
directory for each run. Tests that change source cannot qualify that snapshot.

The repaired existing source packager remains the only link-producing path. It
checks step/version, required files, portable paths, CRC, exact manifests, fresh
extraction and final reopened bytes before emitting a link. Its receipt cannot
claim tests it does not run. The source-delivery policy now requires Step 11's
implementation, regression tests, notices and current report.

## 4. Six roadmap requirements

| Step 11 requirement | Delivered now | Remaining qualification |
|---|---|---|
| One ordinary non-AI package | Same crate; verified source package; explicit runtime/dependency arrangement; no new installer | Actual host-format artifact/signing and project license owner decision |
| Install/enable/update/disable/remove | Corrected core owner lifetimes, regression tests, host lifecycle procedure | Actual host/build/platform lifecycle tests |
| Legally usable media corpus | Retained synthetic fixtures; extra encoded failure/resource fixtures; corpus guidance | Consented human-recorded camera/voice/long-session corpus |
| Failure/resource safety | Specific source fixes; native regressions and independent tool failure tests | Cargo-native execution, hostile filesystem/OS cases and real host response |
| Measured resources | Local independent encode/decode wall time and sampled process-tree RSS | Rust/application measurements, real typing latency and representative 4K/long jobs |
| Accurate release documentation | Quick start, current scope, notices, recovery, integration/test procedures | Publish only after unverified scope is completed or narrowed explicitly |

No host method signature, project data format, runtime dependency, model,
new scheduler or core-terminal code is introduced. The former `SUPPORTED-SCOPE.md`
incorrectly began with Step 9 and called interchange unimplemented despite its
Step 10 source. It is now one current summary; its old contents remain as
[historical notes](STEP-10-SUPPORTED-SCOPE.md).

## 5. Status and handoff

The available environment still lacks Rust/Cargo and cannot resolve the compiler
or package-registry hosts. The attempt and current commands are recorded, not
replaced with declarations of passing Rust tests. Compilation/typechecking,
editor imports, the Automexia package lifecycle and non-Linux behavior are **not**
qualified by this source delivery.

The supported manual continuation is to generate/review Cargo.lock, build and run
the exact core/graphics/native suites, integrate with the existing host and follow
[release qualification](RELEASE-QUALIFICATION.md). No new terminal source is
required merely to receive this core; host adjustments remain at its boundary.

This step does not implement AI, hardware/shared-decode optimizations, cross-clip
dissolves or non-unit speed. The known outstanding work remains visible in
[current scope](SUPPORTED-SCOPE.md). Do not treat Step 11 as product-release
complete solely because its ZIP or independent recipes pass.
