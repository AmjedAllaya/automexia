# Step 10 — Editable interchange, not another rendered video

**Package:** automexia-video 0.10.1. **Project schema:** 7, unchanged.
**Implemented source:** OTIO JSON, legacy Final Cut Pro 7 XML, a cuts-only CMX3600 EDL profile, compatibility assessment, verified source timing, explicit media baking and protected publication.
**Qualification:** Rust compilation/Cargo execution and actual editor-application imports have not been performed in the delivery environment. Independent tests read reference documents and replay their cut lists through real FFmpeg. Their scope is not a claim that the Rust adapter or an NLE has run.

[Manual testing](MANUAL-TESTING.md) · [0.10.1 fixes](HANDOFF-REVIEW.md) · [Integration](INTEGRATION.md) · [Format contract](INTERCHANGE-FORMATS.md) · [Review record](STEP-10-REVIEW.md) · [Verification](../reports/step10/verification.json) · [Roadmap](video-roadmap.md)

## 1. What the user gets

Export a resolved `.amxv` edit into an editable interchange document that references the original footage, with separate source in/out and sequence placement. Rendering still creates delivery media; exporting does not replace that operation.

An unchanged source can provide editing handles outside the retained ranges. An explicitly baked variant is a new flattened reference and loses those original handles. The exported report states that loss. The original project and media are never modified by export.

The three formats share one validated export timeline, rather than maintaining three separate edit algorithms. The source is still one chronological video source with one selected mono/stereo audio stream or explicit video-only output. Multiple camera sources, arbitrary reorder and cross-dissolves are not invented in the exporter.

## 2. Five implementation responsibilities

| Roadmap responsibility | Implementation | Remaining qualification |
|---|---|---|
| Three dedicated exporters | `src/interchange/writers.rs` serializes OTIO, `xmeml` and CMX3600 | Compile and run actual Rust output through the named editor/version |
| Accurate timing, tracks, markers | `timecode.rs`, `timing.rs`, `build.rs`; whole-source PTS scan; source/record clocks | Codec priming and editor-specific file-time interpretation |
| Honest target compatibility | Generic/Resolve/Premiere routing intent; complete compatibility report; import-tested flag fixed false | No advertised editor family/version has been qualified here |
| No silent effect loss | Cold assessment, explicit source/stem/bake choices, preserved project provenance | Current effects are baked, not translated into unqualified plugins |
| Safe references and publication | Local URIs, explicit paths, fingerprint checks, current native output lease | Host filesystem authority, cross-process races and each OS must be tested |

## 3. Core API and module ownership

`src/interchange/` is an internal module in the existing crate, not a new plugin or service.

- `ExportRequest` defines the format, target intent, selected variant, paths, timecode offsets, markers and explicit media policy.
- `assess_export(project, request)` performs a cold compatibility check with no I/O, rendering, source scan or approval.
- `CfrVerifier` consumes actual selected-frame presentation timestamps. `CfrEvidence` has private fields and no deserialization shortcut.
- `build_export(project, request, verified_media)` creates immutable document bytes and a bound SHA-256 from validated data. It does not publish or grant access.
- `VideoExtension::export_interchange` connects source verification, optional baking and publication to the ordinary Video job.
- `ExportOutcome` returns the outcome, destination, checksum, compatibility report and any already-published baked media.

The serializers have no process, network or filesystem implementation. They cannot start an editor. Existing host methods are reused; there is no new queue, daemon, loader, framework or runtime dependency.

## 4. A normal host call

The following is adapter-side Rust, not a claim of an already registered terminal command:

```rust
use automexia_video::*;

let mut request = ExportRequest::new(
    "/approved/project/edit.amxv",
    "/approved/export/edit.otio",
    InterchangeFormat::Otio,
    EditRate::new("30000/1001".parse()?, true)?,
);
request.target = TargetEditor::Resolve;
request.intended_editor_version = Some("version selected by your operator".into());
request.variant = "main".into();
request.record_start_frames = 107_892; // 01:00:00;00 at 29.97 DF

let outcome = extension.export_interchange(
    &project, &request, &cancel, &mut progress,
)?;
// Show compatibility, output identity and any retained bakes before retrying.
```

Changing the target label does not change the serialization into a proprietary project, authorize a bake, or claim editor compatibility. No `.prproj`, `.drp`, AAF or modern `.fcpxml` is written.

Use the full integration example in [interchange_smoke.rs](../examples/interchange_smoke.rs). It loads an actual saved project and calls the native adapter. It requires explicitly selected FFmpeg/ffprobe paths and an absolute output path with an existing canonical parent.

## 5. Timing: source PTS, media frames and timecode labels

The exporter treats three clocks separately:

1. The selected video stream's original PTS/time base, including nonzero or negative container origins.
2. Source-relative edit time and exact frame counts at the requested interchange rate.
3. Source and sequence timecode display offsets, explicitly supplied in frames.

Default source timecode zero means file-relative labeling. It is not a claim to have recovered the camera's timecode. A container PTS of 3,600 seconds is not automatically a camera start timecode of 01:00:00:00.

Supported edit rates are 24, 25, 30, 48, 50 and 60, plus 24000/1001, 30000/1001 and 60000/1001. Drop-frame labeling is accepted only for 30000/1001 and 60000/1001. CMX3600 is further limited to nominal rates at most 30 in this profile.

The timecode conversion rejects invalid separators, impossible fields, dropped labels such as 00:01:00;00 at 29.97 DF, negative timecodes and wrap beyond 24 hours. It skips timecode labels, not frames. No `29.97` decimal substitute is used for the rational edit-rate decision.

A source-reference export requires every video cut to land exactly on the requested frame grid. No rounding is concealed. An explicit CFR visual bake may resolve a VFR source or non-frame edit; its measured duration can differ by up to one output frame, and the report says so. Markers in a baked result are mapped through the retained edit and explicitly rounded to that output grid.

## 6. Whole-source CFR verification

Equal nominal and average frame-rate tags are not evidence of constant frame rate. The native adapter asks pinned ffprobe to decode the selected stream and emits only integer `pts=` records. Side-data output is excluded.

The verifier processes bounded chunks and lines, supports split input records, honors cancellation, and rejects missing/truncated records, unknown fields, duplicates, reordered PTS, variable frame gaps and count/duration disagreement. A single trailing compact-output delimiter is admitted; extra delimiters/fields are not.

Observed times must follow the requested grid within half one source time-base tick without cumulative drift. The full decoded count must agree exactly with the known source duration. There is a maximum of 2,000,000 source frames per scan. The existing media-runner timeout also bounds execution. Long sources beyond that profile fail clearly rather than receiving partial evidence.

This strictness can reject legitimate media with ambiguous tail-duration metadata. The remedy is a deliberately verified conform/bake or a future separately tested broader timing policy, not a guessed frame count.

## 7. Editable cuts and linked audio

The renderer can merge contiguous ranges for efficiency. The exporter restores explicit assembly split boundaries so adjacent clips remain independently editable in another application.

Source in/out positions and sequence positions are distinct. The sequence duration is the sum of the retained ranges. Manual removals, protected ranges and disabled decisions remain represented in the compatibility provenance.

Source-reference audio requires one known mono/stereo stream with a known sample rate and the same origin as video. Nonzero offsets and multiple audio streams require an explicit timeline-aligned stem or visual bake. This avoids relying on an unverified importer to interpret a chosen stream or shift.

OTIO can describe rational audio durations and explicit silent gaps. Legacy XML and EDL reject sub-frame audio gaps/ranges rather than shifting them to a convenient frame. Audio references cannot exceed measured available samples. An intentionally shorter source audio track gets explicit trailing gaps.

FCP7 XML maps mono/stereo channels to separate audio tracks and gives matching audio/video items resolvable link references. OTIO stores selected stream/channel identity in Automexia metadata; that is not a universally implemented OTIO stream-selection API. Original source bit depth is not fabricated as 24-bit merely because the output sequence uses that default.

## 8. Markers

Markers are explicit source-relative point or range records in the export request. They are not a newly invented `.amxv` field; a host can retain the request for repeatable exports.

Markers map through the retained intervals. A range spanning removed material splits into retained portions. A marker wholly in a removed region is not placed at an arbitrary surviving frame; its omission is reported and its original definition stays in the embedded request.

OTIO/XML store actual timeline markers. EDL emits escaped marker comments with timecodes; automatic marker import by a particular editor is not promised. Limits are 1,024 input markers and 4,096 mapped parts.

## 9. Compatibility and explicit baking

Each applicable decision is classified as `preserved`, `translated`, `baked` or `unsupported`, with a reason and a blocking flag. All formats embed the complete report and original project/request metadata, so a detached document does not depend on an accidentally missing sidecar report.

| Current feature | Original-media export | Explicit preparation |
|---|---|---|
| Resolved cuts and protected ranges | Editable cut references | Visual bake flattens them and loses original handles |
| Manual assembly splits | Preserved | Flattened in visual-bake mode |
| Pending active decisions | Blocks | Baking does not approve them |
| Voice cleanup / pause join fades / volume automation | Blocks while active | PCM24 stem or complete baked variant |
| Color, framing, graphics, burned subtitles and video-endpoint fades | Blocks while active | Explicit ProRes variant bake |
| Disabled/ignored decisions | No playback effect; retained metadata | No implicit activation |
| Sidecar-only subtitles | Remain original project metadata | Existing explicit subtitle-export operation |
| Clip cross-dissolves / non-unit speed | Not in the current supported project model | Not implemented by Step 10 |

`AudioExport::BakeStem` uses the existing accepted audio/edit chain and creates a separate PCM24 WAV. The WAV is inspected through the audio-specific probe, not the generic video-only format whitelist. Stem timing must agree with the sequence grid; padding beyond available samples is not invented.

`VisualExport::Bake` explicitly renders the selected resolved variant as ProRes SDR/CFR. The output is one flattened clip with no original media handles. There is no silent automatic baking. Original source limits still apply: requesting a ProRes output does not qualify unsupported HDR input or recover missing bit depth.

`AudioExport::Omit` is an explicit audio omission and is disclosed. It does not make active audio effects appear to have been applied.

## 10. References, privacy and filesystem safety

The source project resolves its existing relative references against its project path. The exported OTIO/EDL may use local absolute file URLs or URI references relative to the export directory; legacy FCP7 XML uses absolute file URLs only in this profile. Relative references across Windows drives are rejected. UNC/device/network sources are not admitted.

UTF-8 names, spaces, percent signs, XML punctuation and URI-special characters are escaped exactly once. A literal Unix backslash remains a filename character, not an invented directory separator. XML text is escaped; invalid XML 1.0 characters fail. No input document/entity/network resolver is introduced by the serializers.

The embedded report contains original paths, authored text and settings. Review it before sharing exported files. The exporter does not upload this information. No automatic source copying, media bundling, recursive directory traversal, font download or model call occurs.

The native publication adapter protects the `.amxv`, all source paths, all graphic/font references (including disabled ones), and any new baked references. It revalidates actual media fingerprints before commit, not just path names. A final destination is written through the existing private output lease, hash-checked and synchronized before atomic publication. Existing output replacement requires the existing reviewed-identity policy.

Cross-process writers must still be serialized by the host. This native adapter is not an OS sandbox, and path checks do not certify an adversarial filesystem. No broad filesystem authority is granted by this trait.

## 11. Failure, cancellation and partial output

`ExportOutcome` separates published, published-but-unverified, blocked and failed outcomes. Only `Published` returns exit code 0. A malformed request or failure before a job exists can return the ordinary `Result` error instead.

Baked media is explicitly requested final output. If a later document step fails, the outcome keeps those already-published paths; it does not erase them or blindly overwrite them on retry. An unchanged create-new retry against an existing bake will fail, requiring a deliberate new destination or user-managed reconciliation.

The report is embedded, so publication of the document itself is one file rather than a non-atomic document/report pair. A read-back failure after a successful commit produces `PublishedUnverified` with the destination, expected digest and warning. It is not reported as though nothing were written.

Source scanning, media tasks and writes share the existing job's cancellation. No editor/player is opened. All source operations are unchanged. Cancelled staging is cleaned up by the existing lease ownership; successful bakes remain visible in the outcome.

## 12. Host integration delta

The five original required `MediaHost` methods and two `ProjectStore` methods retain their signatures. Step 10 adds a separate optional extension trait:

```rust
pub trait InterchangeHost: MediaHost {
    fn verify_cfr(&self, input: &InputFile, media: &MediaInfo,
        stream: u32, rate: EditRate, cancel: &Cancellation)
        -> Result<CfrEvidence>;
    fn publish_interchange(&self, source: &InputFile, protected: &[PathBuf],
        document: &ExportDocument, destination: &Path,
        policy: &OutputPolicy, cancel: &Cancellation) -> Result<PathBuf>;
}
```

The supplied `NativeMediaHost` implements it using the existing runner and output lease. Custom hosts map those two methods to their approved scan and file-publication owners. Map `Stage::VerifyingTimeline` and `Stage::Exporting` in progress displays. Reuse the existing command dispatcher for `video export`; this package does not register a new terminal ABI or loader.

A small internal refactor shares the existing audio-stem job body with export. It prevents nested-job admission from breaking a one-slot host; no public stem signature changes.

## 13. Reproduce and distinguish the test layers

```bash
cargo test --no-default-features
FFMPEG=/usr/bin/ffmpeg FFPROBE=/usr/bin/ffprobe \
VIDEO_TEST_FONT=/absolute/path/to/your.ttf cargo test --features native
python3 -B tests/media/run_interchange_checks.py --output /tmp/interchange-checks.json
python3 -B -m unittest discover -s tests/packaging -v
```

The independent test script generates its own expressly labeled reference serializations. It reads their edit lists and reconstructs video/audio from encoded footage, testing time arithmetic and media correspondence. It does not invoke Rust or claim editor imports.

For **actual Rust output** in a Rust-enabled environment:

```bash
mkdir -p /tmp/amx-interchange-source /tmp/amx-interchange-rust
python3 -B tests/media/run_interchange_checks.py \
  --output /tmp/reference-results.json --keep /tmp/amx-interchange-source
FFMPEG=/usr/bin/ffmpeg FFPROBE=/usr/bin/ffprobe \
  cargo run --features native --example interchange_fixture -- \
  /tmp/amx-interchange-source/interchange-source.mov /tmp/amx-interchange-rust
python3 -B tests/media/run_interchange_checks.py \
  --rust-exports /tmp/amx-interchange-rust --output /tmp/rust-document-readback.json
```

An installed OpenTimelineIO SDK can additionally read the OTIO artifact. `--require-otio-sdk` fails when absent; absence is not counted as a pass. Use new output directories for the example; create-new policy is deliberate.

## 14. Application qualification remains open

For each named Premiere/Resolve/Final Cut version, import **Rust-generated** output and inspect:

1. Original media relink, duration, source in/out, explicit splits and original handles.
2. Audio/video linkage, mono/stereo mapping, tail gaps, offsets and codec priming.
3. Fractional rates, drop-frame labels, sequence start and source timecode.
4. Point/range markers and expected EDL comment limitations.
5. Actual audio stems, baked looks, lost handles and retained `.amxv` provenance.
6. Spaces/Unicode/percent signs, missing media, moved projects and deliberate relink.

No application/version is marked qualified in this delivery. A JSON/XML parser or FFmpeg reconstruction is not a substitute for these imports. The Step 10 source and delivery can be inspected independently, but the roadmap's complete end-to-end acceptance remains subject to these checks and actual Rust compilation.
