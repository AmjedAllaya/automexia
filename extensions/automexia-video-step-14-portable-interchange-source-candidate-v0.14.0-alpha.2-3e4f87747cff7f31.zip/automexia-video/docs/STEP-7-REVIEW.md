# Step 7 review and correction log

This records actual source reviews and independent media runs. No Cargo failure/pass is fabricated. The compiler is unavailable; source corrections below still need Rust compilation and test execution.

## Pass 1 — implementation and media boundaries

Added the variant-local model, geometry, motion, preset and render interfaces, project migration and review/preview integration. The first media suite ran **36 cases: 30 passed, 6 failed**.

Two failures exposed the same real animated-zoom defect: variable upstream scaling did not refresh the downstream crop's bounds as expected. The image drifted off-center during zoom. Replacing only the position expression did not fix the stale bound clamp.

Four other failures were fixture problems: three rotated fixtures and the rotated non-square-pixel fixture did not carry a display matrix when rotation was assigned with the old metadata-copy approach. The fixture generation now uses explicit input display rotation and verifies the resulting matrix before testing normalization. Tests were not relabeled successful without genuine rotation metadata.

## Pass 2 — fixed-raster animated viewport

Static zoom and pan retain the fixed scale/crop path. Changing zoom uses a constant 4:4:4 raster sampled at the desired normalized source viewport, followed by fixed-size output scaling. Per-frame expression-state caching avoids recalculating the motion curve for every pixel.

The corrected **36-case media suite passed all 36**. Decoded center/edge pixels confirm zoom behavior. PTS, output size, rotation, SAR and audio checks also passed.

Some initial synchronous test invocations were terminated by the execution-call ceiling before writing their report. They are not counted as complete runs. The completed report is retained as `step7-media-pass2.json`.

Source review additionally corrected: explicit rectangle target validation, the actual sampler's source-raster budget, saved preset serialization names, new-example API names, Rust numeric literal spelling, obsolete future-schema assertions, and audio-only reference plans unnecessarily retaining pixel framing.

## Pass 3 — timing, state and resource regressions

Expanded to **42 media cases**. The initial expanded run passed **41** and failed one same-source-frame comparison across an edit. The lossy outputs differed by five RGB levels at the sampled pixel because different encoding histories are not bit-identical.

The check now renders that exact equivalence case losslessly and compares the **entire decoded frame**, not a loosened pixel tolerance. The same source frame after the cut matches exactly. The final **42-case suite passed all 42**.

The expanded tests cover varying zoom on VFR input, cut/source-clock identity, exact shot zoom reset, full-range input, rotated non-square pixels and center stability. The constant-geometry and earlier media tests remain retained.

Further source review fixed two new integration/resource issues: framing-only blocker wording could conceal a shared unresolved edit, and a small Fit image could fit its budget while the padded output canvas exceeded that budget. Shared blocker precedence and padded-canvas checks now have supplied Rust regressions.

## Current verification boundary

The working tree passed all **166 retained independent media checks** and the **42 new checks**. Native Rust tests were supplied for actual project save/load/render/preview/cancel/cleanup, but remain unexecuted. The source test additions total **97**: 83 core/internal and 14 native, bringing the declaration count to **613**.

A clean-extraction repeat and package integrity records accompany the final delivery. Those records establish exactly what ran and which files were packaged; they do not turn independent recipes or lexical checks into Rust execution or native terminal qualification.
