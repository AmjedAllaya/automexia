# Source patterns and implementation choices

## Supplied-source direction retained

- `automexia-video-extension-roadmap.md`, Steps 0–1: one first-party Rust extension, narrow current-host adaptation, local footage probing and first no-edit output, no early model/UI/framework expansion.
- Architecture `Original §1` and `Original §90`: domain behavior belongs outside terminal internals; expose a focused capability and keep wrappers thin; do not split merely to increase package count.
- The extension/provider examples: typed domain requests, host-owned generic actions/progress, bounded data, explicit lifecycle and cancellation, optional native work away from input/render hot paths.
- Video automation source: original media immutable; FFmpeg/ffprobe through a reviewed execution role; rational timing; explicit streams, VFR, rotation, aspect and color handling.

The supplied references describe multiple historical/target extension layouts. They do not supply one complete current binary loader ABI. `MediaHost`, `VideoExtension` and their method/type names are **new local implementation interfaces**, not claimed exact copies of unavailable application source. The user explicitly permits adapting this small boundary.

## Concrete choices made in this delivery

One unpublished Rust crate with internal modules; no new workspace-wide services. Core I/O is injected through `MediaHost`. An optional native adapter supplies real local/provider operations for integration and testing. The first output profile is H.264/AAC MP4 for a bounded 8-bit SDR subset; unsupported media profiles fail explicitly. Artifact signing, OS sandboxing and actual application registration stay with the existing host.

No default Rust process dependency, Python runtime, model, Node application, GUI, terminal engine change or artificial gate database was introduced. Python appears only in independent media tests. The package does not include earlier CE/Kubernetes prototypes.

## External implementation references consulted

The FFmpeg command and ffprobe manuals were checked for stream mapping, input/output option placement, timestamp preservation, frame-rate control, progress and structured probe output. This is implementation context, not a rewrite of the supplied product specification:

- https://ffmpeg.org/ffmpeg.html
- https://ffmpeg.org/ffprobe.html

The installed FFmpeg 7.1.5 tools were the actual source of truth for the executed media tests. No claim is made that a web page or a version string validates an entire media pipeline.

## Step 2 extension

The actual Video roadmap's editable-project step is implemented in the same crate. `ProjectStore` is a local adapter contract for the existing host's persistence owner, not a claim about an exact shipped terminal ABI. The user explicitly permitted those adapter adjustments. Single-source chronological rendering, exact rational strings and schema 1 are concrete implementation choices documented in [AMXV-FORMAT.md](AMXV-FORMAT.md); they do not assert an undocumented legacy project format.

External technical references used when implementing the media recipe:

- [FFmpeg filters](https://ffmpeg.org/ffmpeg-filters.html): selection, timestamp conversion, audio trimming/padding/concatenation.
- [FFmpeg bitstream filters, setts](https://ffmpeg.org/ffmpeg-bitstream-filters.html#setts): distinct PTS/DTS and packet-duration expressions.
- [Rust filesystem rename](https://doc.rust-lang.org/std/fs/fn.rename.html): platform-dependent filesystem replacement behavior. Project saving uses the existing tempfile dependency and documents stronger host responsibilities.

These references describe mechanisms, not proof that this Rust crate has compiled. Actual independent-media results and outstanding Rust verification remain explicit in the verification record.
