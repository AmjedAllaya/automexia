# Step 9 — frozen presets, delivery profiles and repeatable workflows

**Edition:** Automexia Video 0.9.0; `.amxv` schema 7. Rebuilt from the verified Step 8 delivery-repair archive, not from either missing Step 9 attempt.

**Implementation:** Rust source in the same crate. The default library adds no runtime dependencies or I/O authority. No terminal source changes, framework, daemon, model download, scheduler or new end-user application are introduced.

**Verification boundary:** this delivery includes independently exercised FFmpeg recipes and Rust regression tests. Rust/Cargo could not be found or obtained in the execution environment. Consequently the crate, including the inherited code, has **not** been compiled or typechecked here, and Cargo tests are **not** claimed as passing. The current machine-readable record is [verification.json](../reports/step9/verification.json). Previous step reports are historical, not evidence of current Rust execution.

## 1. Scope and original requirements

The implementation follows [Video roadmap Step 9](video-roadmap.md#step-9--finish-presets-rendering-and-repeatable-workflows): separate edit presets, composition targets and encoding intentions; capture settings; reuse the accepted project; validate each output; preserve partial results and safe retries.

| Requirement | Implementation and boundary |
|---|---|
| Clean/Social/Podcast | Versioned editorial settings built from the existing pause/voice profiles; settings never imply approval of a cut or visual change. |
| Layer precedence | Defaults < user < project < named preset < explicit override; bounded strict JSON, duplicate/unknown-field rejection and validation. |
| Preview/Fast/Publish/Master | Frozen `DeliveryProfile`, distinct from composition and editing; explicit software codecs and containers. |
| Correct render pipeline | Reuses existing edit, voice, color, framing and presentation code, replacing only generated output encoding options. |
| Multiple targets | Sequential reference implementation, one existing host job slot for a complete delivery. |
| Failure/retry | Per-target statuses, compact output properties, exact file fingerprints and complete revalidation of successful outputs. |
| Normal command surface | Core entry points for the host's `run`, `review`, `render`, existing media/sidecar export; Step 10 NLE exporters remain later. |

Shared-decode multi-output optimization and hardware encoders are **not implemented or qualified**. There is no fake optimized branch or silent hardware/software switch. Sequential software output is the implemented reference. Existing Step 8 clip-to-clip cross-dissolves and non-unit-speed gaps remain unchanged.

## 2. One crate and host ownership

The three added modules are [delivery.rs](../src/delivery.rs), [presets.rs](../src/presets.rs) and [delivery_workflow.rs](../src/delivery_workflow.rs). Existing [plan.rs](../src/plan.rs) compiles and validates the actual media plan. Existing [project_workflow.rs](../src/project_workflow.rs) executes it. No algorithm is replaced by an unrelated Python prototype.

The five required `MediaHost` methods and two `ProjectStore` methods retain their signatures. The optional native adapter runs the generated media tasks through its existing restricted runner. Explicitly selected files, approved tools, overwrite consent, UI, job scheduling and progress presentation remain host responsibilities.

Calls are blocking and run on the host's existing worker. `render_targets` occupies one job slot. `run_workflow` calls existing analysis/save/render methods under a linked lifetime cancellation scope. It starts no thread pool or service. The host may queue several independent `RunRequest`s using its existing job system. This library does not promise encoder pause/resume or reboot recovery from a process checkpoint.

## 3. Strict settings and meaningful presets

`WorkflowPatch::from_json` reads a caller-supplied byte slice, up to 64 KiB. It accepts only a partial typed configuration object. Unknown keys, duplicate keys, invalid enum variants, incorrect types and out-of-range settings are errors, even when another layer would override them. Missing keys inherit; `null` is not an instruction to execute or remove arbitrary state. Tagged frame-rate alternatives replace as a whole so a stale CFR rate cannot survive switching to timestamp preservation.

`resolve_workflow(user, project, preset, overrides)` returns `WorkflowSnapshot`. It records the known snapshot/preset revision and complete resolved settings. `WorkflowSnapshot::apply` explicitly updates the named output variant and saves the settings; `ReviewSession::apply_workflow_snapshot` does the same through the current review owner without discarding other unsaved edits, then invalidates stale previews.

Clean selects natural pause/audio defaults and conservative color analysis. Social selects the existing tighter, bounded pause and voice defaults. Podcast retains longer pauses and does not automatically analyze color. These presets request analysis; they do not magically produce correct results or approve findings. Manual/reviewed edits remain unchanged when settings are applied.

Explicit content declarations and noise-confirmation evidence are preserved across editorial preset selection. Presets do not manufacture a dialogue classification, confirmed noise, music-removal consent, crop approval or model authorization. The no-preset defaults request **no analysis**. Mixed music and unknown content retain the previous conservative treatment rules. Color analysis retains Step 6's strict input requirements; an incompatible request returns an error with the latest draft rather than silently applying an alternative grade.

Editing, target geometry and output encoding remain separate. Selecting a Social edit preset does not silently crop the picture. Framing presets remain Step 7's independently reviewed variant settings. Preview encoding intent does not change geometry; use existing review proxies when a bounded low-resolution review file is required.

### Example of explicit resolution

```rust
use automexia_video::*;
let user = WorkflowPatch::from_json(br#"{
  "pause_settings": {"content":"dialogue"},
  "voice_settings": {"content":"dialogue"}
}"#)?;
let output = WorkflowPatch::render_mode(
    RenderIntent::Publish, Some(DeliveryFormat::HevcMp4))?;
let resolved = resolve_workflow(Some(&user), None,
    Some(EditPreset::Clean), Some(&output))?;
// Apply through the existing project or ReviewSession owner. No approval occurs.
# Ok::<(), automexia_video::Error>(())
```

Render/retry reads the saved variant/profile. It never calls the resolver, downloads components or reruns pause, voice or color analysis. Reopening a project therefore does not adopt changed global settings.

## 4. Frozen delivery profiles

| Format | Container / extension | Video | Pixel format | Audio |
|---|---|---|---|---|
| `h264_mp4` | MP4 / `.mp4` | libx264 | yuv420p | AAC, original supported sample rate |
| `hevc_mp4` | MP4 / `.mp4` | libx265, hvc1 tag | yuv420p | AAC, original supported sample rate |
| `vp9_webm` | WebM / `.webm` | libvpx-vp9 | yuv420p | Opus at explicitly selected profile rate 48 kHz |
| `av1_webm` | WebM / `.webm` | libaom-av1 | yuv420p | Opus at explicitly selected profile rate 48 kHz |
| `prores_mov` | MOV / `.mov` | prores_ks profile 3 by default | yuv422p10le | PCM24, original supported sample rate |

The requested encoder, audio encoder when needed, and muxer must be present. Missing codecs do not trigger fallback. Other existing filter and runtime checks still apply. Listing a codec does not guarantee a particular build will successfully encode every input: process errors and decode/property validation still prevent publication.

Preview, Fast, Publish and Master contain explicit codec-specific quality/speed defaults. Quality values are not a common cross-codec scale or a claimed perceptual ranking. Master defaults to ProRes; selecting an alternative codec for Master is explicit. Video-only output requires no audio encoder. All modes remain inside the existing progressive 8-bit SDR input/transformation scope.

ProRes's 10-bit output container does not restore lost source precision or enable HDR processing. Full-range ProRes is rejected until an explicit range-conversion policy is qualified. The exercised limited-range MOV path can omit its range tag; that one exception is disclosed and not generalized to other color metadata. WebM's integer display dimensions may quantize non-square sample aspect ratios by at most one display pixel; square-pixel output is held to the original strict tolerance. A warning records this, and framing to an explicit square-pixel target avoids it.

The new encoding compiler rewrites only the generated output section after the last `-map_metadata`. It must not replace a private graphic input's `-f concat`, alter source paths, reinterpret filter text or build a shell command. The existing input protocol/demuxer restrictions remain unchanged.

Every output is privately staged, probed, fully decoded, checked for timing/geometry/selected streams and published through the existing output lease. Voice processing retains its measured-gain and post-encode peak validation. There is no automatic intermediate master. A requested ProRes Master is a deliberate final output and can be large; native host limits continue to apply.

## 5. Sequential delivery and results

`DeliveryRequest` has an absolute normalized `.amxv` location, 1–16 targets and an explicit `fail_fast` choice. Each target has a stable ID, saved variant ID, absolute output path and existing `OutputPolicy`. Duplicate IDs and case-folded destinations, incompatible filename extensions, source/project/asset destinations and unsafe paths are rejected. Native identity/alias checks remain essential; lexical validation is not an OS sandbox.

`VideoExtension::render_targets` runs each target in order, with isolated outcomes. It uses the already-resolved project and one monotonic cancellation token. A target failure does not erase a completed result. Fail-fast leaves later targets unstarted. Disable/re-enable or `cancel_all` cannot revive the old delivery.

`DeliveryReport` contains the request/decision digests, project revision, sequential strategy and per-target receipt: requested profile, observed codec/pixel geometry/rate/color/audio information, runtime versions and executable identities when supplied by the host, final fingerprint, attempts, warnings and errors. Raw source packet JSON is not duplicated into the report. Receipts are bounded, strict JSON, not signatures or proof that a dishonest host supplied true information.

| Status | Meaning |
|---|---|
| `succeeded` | Output was validated/published and its final fingerprint captured. |
| `reused` | An earlier output was reopened at the requested path, matched and revalidated without reencoding. |
| `failed` | This target did not complete; existing successful targets remain represented. |
| `cancelled` | Cancellation interrupted this target; an existing receipt remains retained when present. |
| `not_started` | Not revisited in this attempt; any prior receipt remains attached, but this is not newly qualified success. |
| `invalidated` | A previously completed file/source/validation no longer matches; never automatically overwritten. |
| `published_unverified` | Publication succeeded but receipt capture/summary failed; explicit inspection is needed, not blind retry. |

Structured `DeliveryEvent`s report start, target start, normal progress, target completion and overall completion. They serialize as one bounded JSON object per line. The host decides where to display/write them. Observer panics are caught; prior completed output remains in the report. The library does not silently write logs or receipts to disk.

Exit codes are 0 for complete delivery, 2 for failure/incomplete, 3 when a target is cancelled. `RunResult::exit_code` additionally uses 4 for a prepared project that needs review. These are library conventions for the host's command adapter, not new terminal commands already installed by this ZIP.

## 6. Safe retries

`retry_targets` requires the same request, project revision and exact decision digest. It retains successes, retries failed/unstarted targets, and never deletes valid outputs. Reuse reopens the **requested destination**, checks canonical path and file fingerprint, verifies the source and current plan, probes the output, fully decodes it and rechecks the source/output identities.

A report edited to point at another file cannot select that file as the destination. A changed or missing successful file becomes invalidated, not an overwrite opportunity. Restoring the original file permits subsequent revalidation. To replace a genuinely changed output, make a new explicitly reviewed delivery request with the normal replacement policy.

Fail-fast and cancellation preserve receipts for targets not revisited in the current attempt. A cancelled revalidation cannot turn a committed file into a fresh render on the next retry. A committed output without a trustworthy final fingerprint remains `published_unverified` until explicitly resolved. Receipt writing and long-term storage are host concerns.

Request validation errors and exhausted attempt counters are checked before work. Per-target errors after work starts are recorded in the returned report so earlier successful work does not disappear. A completed publication is not undone because the progress observer fails afterwards.

## 7. `run` orchestration versus saved-project rendering

`run_workflow` creates a project from a selected input, installs the complete explicit variants, freezes settings, runs only requested existing analysis stages, optionally saves through `ProjectStore`, and delivers only when the project is resolved and the request is not a dry run.

It returns the latest in-memory draft when an analysis/save/delivery stage fails. New cuts, color, framing and presentation still need their existing review. The user can save/review the draft and later call `render_targets`; retry does not rerun generators. `RunRequest` with no output request simply prepares a draft. Optional save policy is explicit. Dry run never produces final delivery media, but an explicitly requested project save is reported. No persistent analysis cache is introduced; `cache_written` remains false.

A caller-supplied per-variant profile has precedence over the request's default profile. Unspecified variant profiles inherit the frozen default. Explicit independent variants are not silently converted into one format. Source restrictions and review gates are not weakened to make one-command processing appear successful.

## 8. Integration delta

Add `workflow: None` to explicit `ResolvedSettings` constructors, `output_profile: None` to `OutputVariant`, and `delivery_profile: None` to explicit `RenderHistory`/`RenderResult` constructors. The serializers omit these absent fields. Known `.amxv` schemas 1–6 migrate to 7 without enabling any analysis or output profile; older readers cannot read newly saved schema-7 projects. Unknown future profile/preset revisions and hidden new fields under old schemas are rejected.

The existing required host method signatures do not change. No optional method is added. Event/receipt fields are provided by new module types. Map the added `video.run`, `video.render` and `video.delivery.retry` action metadata to your existing dispatcher. The example [delivery_smoke.rs](../examples/delivery_smoke.rs) demonstrates real native execution once compiled; it is not a shipping substitute application.

## 9. Tests and remaining qualification

Run the actual Rust checks in an environment with Cargo and the approved media tools:

```bash
cargo test --no-default-features
VIDEO_TEST_FONT=/absolute/path/to/your.ttf cargo test --features graphics
FFMPEG=/usr/bin/ffmpeg FFPROBE=/usr/bin/ffprobe \
VIDEO_TEST_FONT=/absolute/path/to/your.ttf cargo test --features native
python3 -B tests/media/run_delivery_checks.py --output /tmp/video-delivery.json
python3 -B -m unittest discover -s tests/packaging -v
```

The first three commands have **not** been executed here. [Core tests](../tests/delivery.rs) cover strict configuration, schema/profile identity, golden output arguments, receipt integrity, partial failures, cancelled reuse, fail-fast receipt retention and observer failure. [Native tests](../tests/native_delivery.rs) execute the actual Rust-to-FFmpeg path when run; missing required tools are failures, not silently skipped passes.

The independent Python media suite is test-only. It reads production edit templates and committed encoding vectors and checks actual encoded/decoded output. A supplied Rust golden test verifies those vectors against the Rust encoder planner; until Cargo runs, that equivalence is reviewed rather than dynamically proven. Current executed results, errors and fixes are in [review history](STEP-9-REVIEW.md) and [verification](../reports/step9/verification.json).

Unqualified work: Rust compilation/typechecking and test execution, native Automexia integration, non-Linux systems, hardware encoders, shared-decode output graphs, representative long media, perceptual listening/visual-quality studies, sustained fuzzing and crash/reboot recovery. No NLE exporter, new learned model, early architecture split or completion of Step 8's two missing effects is claimed.
