# Step 5 review and correction record

This distinguishes actual FFmpeg experiment failures from source-review findings and unexecuted Rust tests. No Cargo success is inferred.

## Pass 1 — implementation and initial recipes

Added source-bound settings/preflight, bounded PCM analysis, deterministic stage resolution, shared filter compilation, edited-signal metering, output reports and WAV stem operations. Integrated the accepted profile with projects, rendering and review previews.

The first independent media run recorded **30 passes and one failure**. The full-scale AAC fixture exceeded its −1.5 dBTP ceiling (about −1.10 dBTP) despite initial headroom. The workflow now measures the decoded private output, lowers constant gain and retries at most twice within the accepted attenuation bound. It refuses publication if the final check still fails. The second media run passed all **31** then-present cases.

[Initial result](../reports/step5-media-pass1.json) · [After peak correction](../reports/step5-media-pass2.json)

## Pass 2 — timing, bounds and persistence

An additional independent transient experiment exposed about 25 ms of uncompensated `afftdn` delay at 48 kHz. The official FFmpeg 7.1 source describes a sample advance of floor(rate/80), a three-hop window, and a two-hop delay. Padding flushes the tail; sample trimming and a matching timestamp adjustment remove that delay without resetting source origin. Runtime version qualification prevents guessing the same contract on other releases.

Added actual tests at four rates, the final 10 ms of a recording, audio shorter than the delay, nonzero audio start and flash/tone synchronization through cuts. The expanded suite passed all **42** cases.

Source review also corrected effective versus requested stem duration, malformed trailing metric-object ordering, missing volume capability checks when limiter correction may attenuate, inconsistent preflight sample/window/RMS evidence, and required explicit saved stage validation. These fixes have source regression tests; they were **not** observed through an executed Rust suite.

## Pass 3 — regression, A/B and packaging review

Added two executed signal tests: formant-synthesized speech with added hum/noise/DC, and a synthetic breath-like burst that must not be hard-gated. The final audio suite passed **44 of 44**. Neither is a recorded-human or blind listening evaluation.

Added a native Rust A/B test for an untreated original, processed comparison, unchanged project and proxy cleanup. This raises the Step-5 Rust additions to **87**: 68 core and 19 native. During review, two older native-review test literals (`.1`) were corrected to valid `0.1` notation. This is a source correction, not a claim that the crate now compiles.

The retained independent import, edit, preview and pause suites passed **19 + 18 + 23 + 30 = 90**. Combined with 44 new cases, the working-tree total is **134 passed**. Test-only Python reads the relevant Rust filter constants, but builds the fixture oracle independently; it does not execute Rust workflow/permission/state logic.

## Deliberate limitations, not hidden successes

- No rustc/Cargo: compilation, typechecking, Rust tests, formatter, Clippy and native Rust execution have not been performed.
- No blind listening, human-recorded speech release corpus or perceptual certification.
- No installed Automexia UI/permission/player integration, Windows/macOS qualification, model runtime or terminal modification.
- Peak/level guarantees are restricted to checked outputs and configured tolerances; arbitrary codecs and runtime versions are not qualified.
- Denoise delay compensation is currently restricted to FFmpeg 7.1 releases. Custom builds still need validation.
- Explicit user On choices may alter music/sibilants/breaths; spectral/RMS observations are not semantic classification.

[Final audio results](../reports/step5-media-final.json) · [Current verification](VERIFICATION.md) · [Implementation status](../reports/implementation-status.json)
