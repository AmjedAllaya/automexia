> Historical Step 8 README. Its test counts and implementation status describe the input edition, not this Step 9 build.

# Automexia Video core — Steps 0–8 (rebuilt)

> **Delivery correction (10 September 2026):** This remains Step 8 / version 0.8.0.
> Step 9's previously announced archive was not delivered and no Step 9 source was
> recoverable. This copy adds tested delivery checks, not Step 9 features. All Video
> Rust source is unchanged. Read [the recovery and packaging procedure](../docs/DELIVERY.md).


One Rust crate with an adjustable host boundary. Version **0.8.0** adds supplied SRT/WebVTT captions, editable branding/titles, explicit assets and fonts, timed graphics, restrained animation/volume controls, sidecars, and project/review/preview integration to the retained Video core.

**This is the real rebuilt source from the verified Step 7 archive. It is not the missing earlier Step 8 package.**

**Verification:** **263 independent FFmpeg/media checks passed** (208 retained + 55 new). **Rust/Cargo are unavailable: the source has not been compiled/typechecked, and its 733 supplied Rust tests have not run.** The new media checks use Pillow artwork, not the Rust rasterizer. No native Automexia installation or UI result is claimed. See [verification](../docs/VERIFICATION.md).

**Remaining Step 8 scope:** overlapping adjacent-video-clip cross-dissolves and non-unit playback-speed edits are not implemented. Graphic-to-graphic layering dissolves and source-endpoint fades are supported. This is not a claim that every roadmap effect is complete.

## Start here

[Step 8 implementation](../docs/STEP-8.md) · [Integration](../docs/INTEGRATION.md) · [Project format](../docs/AMXV-FORMAT.md) · [Supported scope](../docs/SUPPORTED-SCOPE.md) · [Review history](../docs/STEP-8-REVIEW.md) · [Video roadmap](../docs/video-roadmap.md)

## Typical workflow

Open/create `.amxv` → choose an output variant → import selected subtitle bytes and/or supply explicit graphic/font references → set placement, style and restrained animation → review/approve → save → render using the existing media runner.

Subtitle import and project editing do not read files or launch processes. Approved rendering prepares privately owned graphic rasters through the host. There is no automatic font search, asset download, model load, sidecar write, platform-specific new UI, player or terminal loader. Sidecar export is an explicit operation and does not require fonts when burn-in is off.

Timing follows the actual edited audio/video clock. Cues crossing cuts split into retained parts; animation does not restart inside a preview excerpt. Variants retain independent presentation, framing and safe-zone settings. New or changed presentation requires review. Disabled profiles restore the previous render behavior without requiring their missing graphic assets.

## Build and test

```bash
cargo test --no-default-features
VIDEO_TEST_FONT=/absolute/path/to/your.ttf cargo test --features graphics
FFMPEG=/usr/bin/ffmpeg FFPROBE=/usr/bin/ffprobe \
VIDEO_TEST_FONT=/absolute/path/to/your.ttf cargo test --features native
python3 -B tests/media/run_presentation_checks.py --output /tmp/presentation-tests.json
```

The three Cargo commands could not execute here. There is no fabricated Cargo.lock or successful CI result. The independent recipe tests ran with FFmpeg 7.1.5; they do not execute Rust parser, rasterizer, review, filesystem or cancellation code. Optional Step 5 denoiser timing remains restricted to the qualified FFmpeg 7.1 family.

The new optional `graphics` feature uses pinned resvg/image/roxmltree/ttf-parser dependencies. The optional `native` adapter enables it; the default core has no native I/O or rasterizer dependency. **No font files are distributed.** Select a permitted single-face font and its exact family for the [integration example](../examples/presentation_smoke.rs).

## Host integration delta

The five existing required `MediaHost` methods and two `ProjectStore` methods keep their signatures. Two default-denied optional methods are added: `prepare_presentation` and `publish_subtitles`; the native adapter implements both. The latter receives protected source/project/asset paths. No raw arbitrary subprocess method is exposed by the new feature.

Map `Stage::PreparingGraphics`, `ReviewTarget::PresentationVariant`, `ReviewCommand::ChangePresentation`, `ReviewDetail.presentation`, and `presentation: None` in explicit `OutputVariant` constructors. Save `.amxv` as schema **6**; known schemas 1–5 migrate without adding graphics or permissions. Older readers cannot read schema 6. Preserve asset receipts from the full render result when recording provenance.

The host still owns authorization, selected-file access, job scheduling, storage, UI/accessibility and approved playback. The native adapter is a supplied integration implementation, not an OS sandbox or proof of current terminal binary compatibility.

## Retained core

[Projects/cuts](../docs/STEP-2.md), [review/previews](../docs/STEP-3.md), [pause cleanup](../docs/STEP-4.md), [traditional audio](../docs/STEP-5.md), [scene/color](../docs/STEP-6.md), and [framing](../docs/STEP-7.md) remain in this crate. No Kubernetes prototype is included. Earlier per-step reports remain historical; use the [current status](../reports/step8-implementation-status.json) and this edition's checksum manifest.

## Samples

[Synthetic source](../samples/presentation-source.mp4) · [Two-line title/plate](../samples/presentation-titles.mp4) · [Layered graphic dissolve](../samples/presentation-graphic-dissolve.mp4) · [Sample notes](../samples/PRESENTATION-SAMPLES.md)

[Authored logo SVG](../samples/presentation-logo.svg) · [SRT](../samples/presentation-captions.srt) · [WebVTT](../samples/presentation-captions.vtt)

Videos are independent FFmpeg/Pillow fixtures, not output from the uncompiled Rust crate. The SVG and subtitles are selected-input examples, not a new extension manifest. Windows/macOS, representative filmed-footage quality, multilingual typography, long-duration resources and actual Automexia integration remain unverified.
