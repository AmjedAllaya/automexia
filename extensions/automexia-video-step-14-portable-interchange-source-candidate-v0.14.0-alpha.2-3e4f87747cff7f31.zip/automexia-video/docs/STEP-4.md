# Step 4 — conservative non-AI pause shortening

**Extension:** Automexia Video, existing Rust crate, version 0.4.0.  
**Delivered:** bounded audio-energy analysis, reversible pause proposals, existing project/review integration, saved settings and short join fades.  
**Verification:** 90 independent FFmpeg media checks passed. Rust/Cargo are unavailable here: the Rust source, including the 339 supplied Rust tests, has **not** been compiled, typechecked or executed. The media recipes are exercised independently, not through the Rust adapter. See [current verification](VERIFICATION.md) and the [actual build attempt](../reports/step4-cargo-attempt.txt).

This is Step 4 of the **Video** roadmap. It adds no Kubernetes code, model runtime, speech recognizer, denoiser, new terminal framework, package loader or scheduling service. The host-specific adjustment is one optional streaming audio operation alongside the existing five `MediaHost` methods. The user may adapt that operation to the current terminal/provider runner.

## 1. End-to-end behavior

The implemented source path is:

**Existing `.amxv` project → validate selected source and audio → stream bounded energy measurements → propose interior quiet cuts → inspect count/duration/reasons → add pending decisions → existing review and short previews → explicit approval → existing renderer → validated shorter video.**

Analysis never changes the project, creates output files, saves a cache, or starts a render. Applying a report changes in-memory project intent only. Saving, preview generation and final rendering remain separate, explicit operations through existing ownership.

Every new pause removal is `NeedsReview`. Low energy cannot establish absence of speech, breathing or music. Declaring `Dialogue` is a user assertion, not a classification. Declaring `MixedMusic` preserves everything by default; an explicit proposal opt-in still requires review and does not repair jumps in the music. Very quiet spoken words below both thresholds may be proposed: **listen before approving**. No “speech-safe” or release-corpus quality guarantee is claimed.

## 2. Stream measurements without storing PCM

[`pause_workflow.rs`](../src/pause_workflow.rs) creates an `AnalysisDecode` from the inspected input, selected audio index, known source origin and duration. Its fields are private; it emits separate argument tokens, not a shell command or arbitrary filter text.

The native implementation reuses the existing pinned FFmpeg executable, process guard, bounded reader channel, deadlines and cancellation. It does not add another process API or permanent worker. The input policy remains local MP4/MOV/MKV/WebM through the approved file grant; it does not fetch media, inspect credentials or follow arbitrary network resources.

The fixed audio filter converts **sample representation only** to planar doubles, keeps the native sample rate and all selected channels, establishes the corresponding sample time base, restricts analysis to the selected video interval, clears inherited metadata and publishes per-frame `astats` measurements. There is no downmix, loudness normalization, resampling, generated gap filling or timestamp reset in analysis.

Each decoder frame supplies integer source PTS, sample count, and RMS/peak plus invalid-sample counts for every channel. Forcing floating sample representation is necessary because integer input did not emit the required NaN/Infinity counters in the exercised runtime. FFmpeg's option names and emitted metadata names differ; the parser uses the actual emitted `Number of NaNs` / `Number of Infs` keys.

[`MetricParser`](../src/pause_metrics.rs) incrementally consumes that fixed protocol. It rejects duplicate/missing fields, unknown keys, wrong sequences, nonfinite or inconsistent measurements, oversized lines and truncated final records. `-inf` in both RMS and peak means measured digital zero; it is not missing data. A decoder failure, parser error, cancelled callback or failing consumer cannot yield a successful partial report.

Callbacks are owner-serialized on the existing blocking job. They must remain fast and nonblocking. The host must stop/reap the media child on cancellation, error or panic and must return success only after the decoder finishes successfully. This interface is not an OS sandbox.

## 3. Conservative interval detection

[`EnergyAnalyzer`](../src/pause.rs) retains a running accumulator, at most one open quiet interval and one pending activity flank, plus bounded completed intervals. No full PCM buffer or per-frame history is retained.

A frame is quiet only when **every channel** is below both RMS and peak thresholds. This prevents a silent channel, antiphase stereo cancellation or short loud transient from disappearing in an average. A pause must last long enough and have measured sustained activity on both sides. Brief clicks do not establish that activity. Short pauses, leading/trailing quiet, all-silent footage and uncertain flanks are retained.

Time calculations use existing exact `Rational` values and native sample counts. The saved video origin is subtracted from the original audio timestamps. Ordinary sample-clock rounding permits one sample. For streams with a documented coarser clock, `with_timestamp_resolution` allows its quantization up to **1 ms plus one sample**. It reports the tolerance and rounding events, does not count overlaps twice, and does not fill positive gaps into observed-duration statistics. Larger gaps break candidate continuity; excessive overlaps/non-increasing timestamps fail. Coarser-than-1-ms clocks and decoder frames over 250 ms are rejected rather than guessed.

A bounded timestamp-quantization envelope can lie inside a measured run; the much larger retained padding and review requirement remain in effect. Missing leading/trailing audio and real discontinuities are reported, not treated as measured silence. Measurements with unsupported or unstable decoder timing require qualification rather than a claimed universal audio-format guarantee.

The summary includes measured duration, quiet duration, uncovered duration, discontinuities, weighted energy RMS and peak/clipping indicators. Weighted RMS is **not** integrated LUFS and is not the audio-enhancement stage.

## 4. Configurable presets and limits

`PauseSettings::clean()`, `social()` and `podcast()` are explicit configuration values. The complete selected values are stored in the project when a report is applied; rendering does not look up a newer global preset.

| Setting | Clean | Social | Podcast |
|---|---:|---:|---:|
| Quiet RMS ceiling | -50 dBFS | -50 dBFS | -50 dBFS |
| Quiet peak ceiling | -40 dBFS | -40 dBFS | -40 dBFS |
| Minimum measured quiet | 1,200 ms | 1,000 ms | 1,800 ms |
| Boundary padding before / after | 200 / 250 ms | 150 / 200 ms | 300 / 350 ms |
| Minimum retained pause | 500 ms | 400 ms | 800 ms |
| Minimum removal | 250 ms | 250 ms | 250 ms |
| Minimum retained segment | 700 ms | 700 ms | 700 ms |
| Minimum spacing between new cuts | 2,000 ms | 1,500 ms | 3,000 ms |
| Sustained activity on each flank | 180 ms | 180 ms | 180 ms |
| Join fade, each side | 5 ms | 5 ms | 5 ms |
| New cuts per pass | 64 | 64 | 64 |
| Maximum newly removed share of accepted timeline | 50% | 50% | 50% |

These are **conservative implementation defaults**, not measured perceptual optima or requirements imported from a speech model. All settings have validated ranges. They do not guarantee natural speech under arbitrary recording conditions. Reducing the analysis cap or choosing stricter thresholds is permitted; bypassing review is not.

| Resource | Bound |
|---|---:|
| Selected audio channels | 1–8; no hidden downmix |
| Native sample rate | 7,350–192,000 Hz |
| Decoder frame duration | At most 250 ms |
| Duration | Default 6 hours, configurable up to 24 hours |
| Decoder metric frames | 4,500,000 |
| Completed qualifying quiet intervals | 4,096 |
| Metric line / total streamed metric bytes | 256 bytes / 1 GiB |
| New pause cuts | Up to 64; existing 128-segment render bound still applies |
| Join fades | 0–10 ms; further limited to one quarter of adjacent segment |
| Project / filter graph | Existing 4 MiB / 24 KiB |
| Media jobs | Existing `VideoSettings` limit, default 1 |

Independent caps apply together: six-hour multichannel media is not promised to fit the byte budget simply because it fits the duration limit. Limit overflow is an explicit failure, not truncation presented as complete analysis. Bounds do not cover every FFmpeg allocation, Rust allocator overhead or host-retained clone. Calls must stay off terminal input/render callbacks.

The requested timeout bounds the decoder streaming stage and is also capped by native runner settings. Initial fingerprinting and probing retain their existing cancellation/timeout rules; this is not a claim of one hard wall-clock deadline covering arbitrary host callbacks or all filesystem I/O.

## 5. Create reversible proposals

The proposer trims the **middle** of eligible quiet intervals. It retains both configured boundary paddings and adds any extra time needed to meet the minimum retained pause. Removal boundaries are rounded inward to audio samples so rounding cannot reduce that padding.

It refuses a candidate that would create a short retained segment, violate cut spacing, exceed new-removal/cut-count limits, or sit outside the actual accepted assembly. Locked clips, protected intervals, manual edits and previously reviewed/disabled/rejected choices are barriers. An intersecting quiet interval is skipped as a whole instead of split around a barrier into multiple small cuts.

A stable candidate ID is derived from source content, source ID and the measured quiet-run range. The origin is `video-energy-pauses`, version `1`; there is no classifier confidence score. Threshold changes may change measured bounds and therefore IDs, but overlap with reviewed ranges still vetoes regeneration. Locked and manually overridden decisions survive recomputation, including rejections.

The report distinguishes accepted duration, hypothetical proposed duration, newly removed duration, candidates, skipped intervals and their reasons. Existing unrelated pending edits are explicitly excluded from the estimate and continue to block final rendering. Reanalysis replaces only unreviewed output owned by this generator. The actual report application and hypothetical timeline/filter graph are validated before returning the report, so an invalid transaction does not half-update a project.

`PauseReport::apply` binds to the exact project ID, revision, decision digest and source hash. It does not grant permission to read or execute anything. The host must cancel superseded analyses and compare the returned settings with the current request; a project digest alone does not order concurrent analyses of an unchanged project. Nothing auto-applies a returned result. A stale report fails; saved or deserialized hand-authored JSON cannot be promoted into a `PauseReport` because it has no public deserializer/constructor. Hashes protect local consistency, not an adversarial in-process caller or host authorization.

## 6. Existing review and previews

Use `ReviewSession::apply_pause_report(&token, &report)` to update an open review. It constructs the new project and view before committing, marks the session dirty and invalidates old preview work. Closed sessions and old tokens fail. A selected operation remains selected only when it still exists in the current filtered view.

Approve/reject, enable/disable, lock/unlock, adjust-range, save and before/proposed previews are the existing Step 3 operations. Approval is explicit. Rejecting or disabling a pause removal restores its source time on the next render. Changing its range sends it back to review. Normal manual decisions can intentionally override generator protections under the existing project rules; a later protection is not an automatic undo of an explicitly approved manual override.

No automatic save, preview playback, render or terminal insertion is added to analysis. There is no new screen, shortcut, player or UI toolkit. The host presents the provided summary/rows through its existing interface.

## 7. Sample-based joins without A/V drift

Approved cuts use the same Step 2 `Timeline` / `EditRender` mapping for both streams. Video joins remain hard cuts. At actual pause-derived gaps, the audio receives short linear fade-out/fade-in envelopes. They change amplitude only: **no overlap, shortened samples, added silence or cumulative crossfade time shift**.

The fade uses saved project settings, defaults to 5 ms per side, and can be explicitly disabled. It is bounded by 10 ms and one quarter of the relevant segment. Ordinary manual cuts and contiguous clip splits retain previous behavior. A redundant pause decision wholly covered by a manual removal cannot introduce a fade: the implementation compares the authoritative timeline with pause decisions disabled instead of guessing from overlapping labels.

Changing the saved fade during reanalysis is refused when it would silently change retained reviewed/locked pause edits. Preserve the setting or make an explicit project editing decision instead. No seamless music repair, zero-crossing guarantee, speech reconstruction or denoising is claimed.

## 8. Project schema and adapter changes

The crate is version **0.4.0**, and `.amxv` is now **schema 2**. `ResolvedSettings` adds optional `pause_cleanup`. Schema 1 has a known built-in migration: preserve existing edit/media/settings fields and leave pause cleanup absent. No new fades or inferred settings are introduced. Unknown future versions fail. A version-1 file carrying version-2 pause fields is rejected rather than interpreted silently. Existing samples stay version 1 as migration fixtures.

A current pause-generator operation must have its matching saved configuration and supported generator version. Settings and edits round-trip as project data, not large observation arrays. The old schema-1 reader will reject a newly saved schema-2 file: this is an intentional format extension, not universal backward-reader compatibility.

Integration changes:

| Surface | Change |
|---|---|
| `MediaHost` | Existing five signatures unchanged |
| `ProjectStore` | Existing two signatures unchanged |
| `PreviewOpener` / `OutputLease` | Unchanged from Step 3 |
| `AudioAnalysisHost` | New optional `stream_energy` operation; supplied native implementation |
| `Stage` | Add `Analyzing` to any exhaustive host match |
| `ResolvedSettings` | Add `pause_cleanup: None` to programmatic initializers; stored JSON is migrated |
| `RuntimeCapabilities` | Existing fields; include the analysis filters, `pcm_s16le` encoder and `null` muxer |

## 9. Integration sequence

Inside a fallible existing host action, using already-approved paths and the existing job executor:

```rust
use automexia_video::{Cancellation, PauseAnalysisRequest, PauseSettings, ReviewCommand};

// core: VideoExtension<H>, H: MediaHost + AudioAnalysisHost + ProjectStore
// project is the current validated project, project_file an approved .amxv path.
let cancel = Cancellation::new();
let mut request = PauseAnalysisRequest::new(&project_file);
request.settings = PauseSettings::clean();
let report = core.analyze_pauses(&project, &request, &cancel, &mut progress)?;

// Show counts, warnings and duration, then apply only after the user requests it.
let mut review = core.review_project(&project)?;
let view = review.snapshot()?;
let view = review.apply_pause_report(&view.token, &report)?;

// Existing Select / Inspect / preview commands let the user review a proposal.
// Only an actual user decision should dispatch ReviewCommand::Approve.
// Existing save_review/save_project and render_project follow separately.
```

The import of `ReviewCommand` identifies the existing integration action; this snippet intentionally does not auto-approve all proposals. [`examples/pause_smoke.rs`](../examples/pause_smoke.rs) is a concrete build/integration example. Its optional `--approve-for-fixture` is explicitly for known generated test media, not normal product behavior.

## 10. Validation and remaining qualification

See [review history](STEP-4-REVIEW.md), [media results](../reports/step4-media-final.json), [Rust tests](../tests/pauses.rs), [native Rust tests](../tests/native_pauses.rs) and [verification](VERIFICATION.md). The 70 new pure-Rust tests and 13 native-Rust tests are supplied, not reported as executed.

Executed independent checks cover encoded AAC/PCM/Opus, stereo antiphase, a silent versus audible channel, separate audio-stream selection, sustained and short quiet, low-level tones, breath-/fan-like signals, music beds, real timestamp gaps, Matroska rounding, NaN samples, VFR and fractional frames, restoration, cancellation, literal paths, fade amplitude and decoded flash/tone synchronization. Formant-synthesized speech with an inserted pause is included, labeled as synthetic. No human listening or human-recorded release corpus was evaluated.

Before release: compile/typecheck, run the Cargo suites through the native Rust host, qualify current terminal callbacks and permissions, and perform actual listening/recorded-media review. The media recipes passing does not establish that the uncompiled Rust parser/analyzer executes correctly. Windows/macOS are not newly qualified. Step 5 enhancement, learned VAD, transcription and all AI remain outside this delivery.
