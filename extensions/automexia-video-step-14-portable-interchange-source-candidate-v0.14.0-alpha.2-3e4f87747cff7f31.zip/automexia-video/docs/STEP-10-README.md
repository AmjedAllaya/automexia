> Historical Step 10 handoff README. Current status is in [the main README](../README.md).

# Automexia Video core — Steps 0–10

**Version 0.10.1** adds editable OTIO JSON, legacy Final Cut Pro 7 XML (`xmeml`, not modern `.fcpxml`) and a cuts-only CMX3600 EDL profile to the verified Step 9 Video crate. Export stays separate from finished-media rendering.

**Source implementation, not a compiled release.** Rust/Cargo are unavailable in this execution environment. Rust compilation, typechecking, Cargo tests and actual Resolve/Premiere/Final Cut imports have not been performed. Independent reference-format/FFmpeg checks do not certify the Rust adapter or an editor. See the current [handoff verification](../reports/handoff/verification.json) and the historical [Step 10 implementation record](../reports/step10/verification.json) and [review history](STEP-10-REVIEW.md).

## Start here

[Manual build and editor-import checklist](MANUAL-TESTING.md) · [Finalization fixes](HANDOFF-REVIEW.md)


[Step 10 implementation](STEP-10.md) · [Interchange formats](INTERCHANGE-FORMATS.md) · [Native export example](../examples/interchange_smoke.rs) · [Integration](INTEGRATION.md) · [Project format](AMXV-FORMAT.md) · [Roadmap](video-roadmap.md) · [Verified delivery](DELIVERY.md)

## New workflow

Open a resolved `.amxv` → choose interchange format/rate/target → inspect compatibility → either retain original references or explicitly bake unsupported processing → validate source timing → export a self-contained document → import and qualify in the intended editor.

The exporter preserves exact chronological cuts, explicit split points, source/record timecode offsets, linked mono/stereo references and mapped point/range markers. Original-media references must pass a full selected-frame CFR scan. Sub-frame cuts are not rounded silently. An explicit visual bake creates a flattened ProRes/CFR reference; audio cleanup requires an explicit stem or baked variant. The original project and source remain untouched.

Every relevant decision is classified as preserved, translated, baked or unsupported. The report and original project/request metadata are embedded in each format. Review that private path/text information before sharing. No automatic media copy, folder scan, cloud upload, model download or editor launch occurs.

## Scope and compatibility

One Rust crate, the existing host boundary, unchanged `.amxv` schema 7. Step 10 adds no runtime dependency. The two-method optional `InterchangeHost` trait is implemented by the supplied native adapter; the original five required `MediaHost` methods and two `ProjectStore` signatures do not change.

The qualified source profile remains deliberately conservative: one chronological, explicitly progressive 8-bit SDR video stream; original mono/stereo audio with known timing, or explicit stem/bake. XML/EDL require square-pixel references and frame-aligned audio intervals. EDL is cuts-only with at most 999 events and nominal frame rates no higher than 30. No application-version compatibility is assumed.

The prior Step 8 missing clip cross-dissolves/non-unit-speed features remain unimplemented. Their absence is not concealed by exporting an unrelated transition. Existing video-endpoint fades and other nonportable effects require explicit baking. Hardware encoding and shared-decode multi-output optimization remain unqualified from Step 9.

## Tests

```bash
cargo test --no-default-features
VIDEO_TEST_FONT=/absolute/path/to/your.ttf cargo test --features graphics
FFMPEG=/usr/bin/ffmpeg FFPROBE=/usr/bin/ffprobe \
VIDEO_TEST_FONT=/absolute/path/to/your.ttf cargo test --features native
python3 -B tests/media/run_interchange_checks.py --output /tmp/interchange.json
python3 -B -m unittest discover -s tests/packaging -v
```

The [Step 10 guide](STEP-10.md#13-reproduce-and-distinguish-the-test-layers) also supplies the procedure for generating **actual Rust** files and reading them back. An optional OTIO SDK check reports absence as not run; `--require-otio-sdk` makes that absence a failure. No fonts, compiler, SDK binaries or fabricated Cargo.lock are bundled.

## Delivery integrity

Use `tools/package_delivery.py` with expected Step 10/version 0.10.1. It creates an immutable hash-named ZIP, verifies the exact member set and checksums, extracts it freshly, then reopens final files before emitting links. Artifact integrity is not a runtime or browser test. All previous source paths and historical test records remain; [the preceding README](STEP-9-README.md) is explicitly historical.
