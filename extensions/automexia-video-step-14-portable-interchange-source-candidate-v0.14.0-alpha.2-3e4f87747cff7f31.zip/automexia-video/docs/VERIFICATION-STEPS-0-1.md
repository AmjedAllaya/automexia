# Verification and review record

## Honest test boundary

This environment has FFmpeg/ffprobe but no `rustc`, Cargo or rustfmt. Attempts to retrieve a toolchain failed. Consequently:

- **Rust compilation, typechecking, Cargo tests and Rust native-adapter execution were not run.**
- 60 core test functions and 14 native-media test functions are provided for a Rust-enabled environment.
- A lexical-token/delimiter check is recorded separately and is not described as compilation.
- No terminal installation, native widget, shell dispatcher or signed package was tested.

The source is delivered so the maintainer can wire and adjust the extension; terminal repository access is no longer a prerequisite to preparing the core.

## Tests that were actually run

`tests/media/run_media_checks.py` generates small encoded fixtures and runs real FFmpeg/ffprobe processes. It reads fixed argument prefixes from Rust source, uses an expected argument fixture that Cargo tests also compare, and exercises the FFmpeg recipes independently. It is a **test-only helper**, not Python extension code or a replacement product.

The final 19 cases passed:

1. Ordinary H.264/AAC input with B-frame reordering.
2. Matroska input without audio.
3. Portrait rotation, verified in decoded pixels and output metadata.
4. Variable-frame-rate presentation timestamps preserved relative to one common source origin.
5. Explicit constant-frame-rate conversion.
6. Selection of a second audio stream, verified by its decoded tone frequency.
7. Audio/video start-offset preservation.
8. Nonzero source-origin normalization.
9. WebM/Opus input to MP4/AAC output.
10. Nonsquare pixel aspect and its reciprocal under quarter-turn rotation.
11. Full-range color metadata.
12. Explicit BT.709 color tags.
13. Unicode and shell-metacharacter filenames treated literally.
14. Corrupt input failure.
15. Playlist/network input rejection by the restricted tool policy.
16. Full-decode detection of truncated media.
17. Cancellation of an actual running encoder process.
18. Decoded flash/tone synchronization before and after transcoding.
19. Stereo channel-layout preservation.

These are generated clips, not a representative customer camera corpus. Numerical A/V checks are not a human lip-sync review or comprehensive perceptual-quality certification. The encoder cancellation test proves the FFmpeg process can be cancelled; the Rust `ChildGuard` itself remains unexecuted here.

Run this independent media check with:

```bash
python3 tests/media/run_media_checks.py --output /tmp/video-media-checks.json
```

Do not use `--update-fixtures` in ordinary validation. That option deliberately replaces golden fixtures after review. Ordinary tests write only the explicitly selected report and temporary media, not the committed content.

## Review passes and fixes

### First media pass

13/17 recipe cases passed. Four failed assertions exposed test-assumption problems: legacy rotation metadata did not actually create a rotated source; the VFR test compared absolute timestamps instead of subtracting the common container origin; the rotated-SAR test inherited that missing rotation; and fixture encoding did not write the promised transfer/primaries tags.

The fixtures were corrected using an actual display rotation, explicit x264 color tags and correct shared-origin comparisons. No failed case was silently deleted or labelled a success.

### Second media pass

17/17 passed. Further inspection identified a genuine output-policy problem: FFmpeg could omit an explicit limited-range tag even when requested. The render recipe now writes `videoformat=component` in x264 VUI when explicit color information is required, and checks the resulting tags. The tests now derive known source color fields rather than omit them.

### Source review

The review tightened source/destination replacement checks, cancellation during staging, output-size checks, timestamp-overflow checks, runtime time-base capability declaration, pixel-format validation, job cleanup and pure status behavior. It also removed repeated process-group termination and prevents signaling an already-reaped child PID and corrected Rust iterator argument conversions found by inspection.

Native tool pinning is lazy; extension/native-adapter construction no longer performs filesystem I/O. Host-specific settings, file authority and actual terminal registration remain explicitly outside the core's claims.

### Third media pass

19/19 passed after adding decoded flash/tone and stereo checks. The numeric results are in `reports/media-pass3.json`. Earlier reports remain as review history. The final independent run is recorded in `reports/media-final.json`. The final package is also re-extracted and the 19-case media check rerun without rewriting committed fixtures.

## Remaining validation before calling this a release

Run `cargo test --no-default-features` and `cargo test --features native`, then compile against the actual host adapter. Run the native output-collision, changed-source, cancellation, deadline and cleanup tests rather than relying on the independent Python recipe runner. Test the precise Windows/macOS process and filesystem adapters that will ship. Expand the sample corpus and benchmark long recordings and resource pressure before broad compatibility/performance claims.

Only those results can establish Rust compilation, end-to-end native-adapter operation, or application integration. This record does not manufacture any of them.
