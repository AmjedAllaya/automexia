# Step 14B review and verification notes

This review concerns modern FCPXML plus a portable OTIO/FCPXML ZIP64 handoff, built on the Step 14A source candidate. The `.amxv` schema stays at 10. It does not claim completion of the entire optional Step 14 backlog or a portable backup of every source-project asset.

## Review passes

The implementation was divided into the FCPXML writer, pure bundle domain, streaming ZIP64/native lease and existing-job integration. The owners reviewed their own changes and exchanged independent reviews at the shared interfaces. Documentation and release evidence must distinguish reviewed source from executed code.

Concrete problems addressed during implementation include:

1. **Bundle references and file authority:** copied media references must be rebuilt through typed `ExportTimeline` data. Altering `InputFile.canonical_path` to a nonexistent extracted file would discard the original verification authority, and string replacement in XML/JSON would disconnect serialized output from the reviewed plan. The plan keeps actual identities, rebases only URLs and regenerates the document.
2. **Explicit bake identity:** the generic pure export builder can receive supplied inspected bake objects. The bundle additionally checks that its video and audio bake identities describe the exact private destinations selected by its request. It rejects a source object substituted for a requested private bake.
3. **Archive byte accounting:** payload-only limits omit headers and central directory data. The plan and writer account for the complete stored ZIP64 structure before copying and reject arithmetic overflow or an exceeded budget.
4. **Deduplication and aliases:** one file used for selected video and audio should be copied once. Content aliases must keep every original inspected identity so a second path cannot change unnoticed before commit. Conflicting path stamps, file IDs or digest sizes fail explicitly.
5. **One publication boundary:** optional bundle bakes must remain private until the final archive succeeds. The existing interchange preparation logic runs inside the already admitted job; a bundle supplies leased destinations. Standalone export keeps its existing independent bake-outcome accounting.
6. **Late cancellation and callbacks:** a post-commit read-back failure must not erase the published path or encourage an unsafe blind retry. Bundle outcomes preserve the `PublishedUnverified` distinction, and native final guards follow the last progress callback.
7. **Modern XML audio and marker clocks:** video and audio are explicit components, avoiding duplicate source/stem audio. Connected audio and markers use their containing clip's local clock, including repeated and reordered source occurrences. Apple's marker semantics require a one-frame point; exact Automexia marker ranges remain disclosed in namespaced metadata and the compatibility report rather than being misrepresented as native ranged markers.
8. **Format-specific preflight:** exact rational wire limits, known audio-rate values and XML text representability are assessed before dependent media preparation when they can be established from the reviewed project. Unsupported effects retain explicit bake requirements.

9. **Escaped document size before baking:** repeated long marker comments can expand far beyond their JSON size. The FCPXML preflight now counts escaped report text, point attributes, repeated marker range/identity metadata and a conservative structural reserve. Near-limit documents can be refused before a visual bake rather than failing only after publication.
10. **Canonical destination readback:** a selected path through a directory symlink can legitimately publish at a canonical path. Readback opens the requested destination and checks its resolved identity and the returned hash/size, preserving successful publication status.
11. **Directory substitution:** final review found an authored native regression was stronger than its implementation. The lease now captures and rechecks Unix device/inode identities for both its workspace and `Media` directory, in addition to rejecting symlinks/non-directories. Other platforms retain the existing host-directory authorization scope; hostile-parent race protection is not claimed.
12. **Offline unreferenced assets:** protected project assets with absent parent directories remain protected by their known paths but no longer prevent a source-only handoff that does not read them.

The native lease also binds the final plan to its own workspace and selected inputs, preventing a plan prepared for another lease from being used only because its public destination and byte budget happen to match.

13. **CI package identity and coverage:** the retained workflow still packaged Step 13 and omitted the new optional suites. It now derives milestone/version from current metadata and invokes assembly, modern FCPXML and actual source/baked-bundle readback. YAML and embedded Python syntax were checked locally; remote CI execution remains unclaimed.

## Regression coverage

The new pure bundle tests cover strict request parsing, unknown/duplicate fields, absence of external bake paths, deterministic private destinations, portable-format selection, path safety, source/bake identity, source/audio deduplication, content aliases, conflicting stamps, full archive size, manifest content, SHA-256 values, provenance, exact URL rebasing, explicit audio omission and immutable original documents/projects.

Workflow tests cover assessment before host access, pending review decisions, cancellation, disabled extensions, private lease cleanup on failure, one publication transaction and post-commit reporting. Native tests cover the actual archive/filesystem boundary; the ZIP64 serializer has its own bounded stream and archive-layout checks. Modern FCPXML tests cover document structure, local clocks, explicit audio components, resource references, repeated occurrences, markers, path/text escaping and rejected wire values.

Exact test counts and pass/fail/blocked status belong to the final [verification report](VERIFICATION.md) and [Step 14B machine-readable results](../reports/step14b/verification.json). The configured suite inventory contains the 17 retained suites plus the modern FCPXML and portable-bundle reference suites. Do not infer execution from the presence of a test declaration or use an earlier release's pass count as evidence for this source tree.

Independent writer review also caught a regression-test harness error: FCPXML intentionally emits its document-type declaration, while the XML test parser rejects declarations by default. The bundle test now explicitly admits the declaration without loading any external DTD. This changes the test parser setting, not the production XML profile or qualification claim.

## What the evidence does and does not establish

| Layer | Evidence and limit |
|---|---|
| Source review | Finds concrete contract, ownership, timing and serialization defects; does not compile Rust |
| Lexical/source inventory | Finds certain delimiter/include/struct-literal problems; does not parse, type-check or execute Rust |
| Python/reference tests | Executes its stated algorithms and generated media/archive recipes; does not by itself execute the Rust production implementation |
| Pure Rust tests | Exercise the production domain/writer when Cargo actually runs; otherwise remain authored and unexecuted |
| Native Rust tests | Exercise real file transactions and runtime seams only when their toolchain/runtime prerequisites are satisfied |
| DTD/structural validation | Establishes the checked XML structure; does not certify editor semantics or import behavior |
| Actual host/editor qualification | Requires the real host controls, supported operating systems and named editor versions |

The current environment's missing prerequisites must stay visible in release reports. Native FFmpeg/ffprobe requirements are not lowered to make a development reference runtime appear qualified. No GUI editor import, platform qualification or full source-project roundtrip is implied by a successfully constructed portable archive.

## Final evidence recovery

The final CI-configuration run's media/tooling commands passed their available checks, but the retained-evidence audit rejected a color report containing an intermediate snapshot. The original failed record and preliminary recovery remain developmental. Only that suite was rerun synchronously in isolation, against the same source identity, and all 42 log/report hashes were verified again after assembly and copying. The final record explicitly describes the combined evidence set; failed retention attempts are excluded from final totals.
