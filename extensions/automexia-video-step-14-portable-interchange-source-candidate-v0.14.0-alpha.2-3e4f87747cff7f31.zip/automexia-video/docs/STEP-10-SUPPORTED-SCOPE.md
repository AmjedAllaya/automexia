# Historical scope notes retained from Step 10

This is not the current release-status authority. See [current scope](SUPPORTED-SCOPE.md).

# Step 9 scope delta

**Implemented source:** strict versioned Clean/Social/Podcast settings; explicit
Preview/Fast/Publish/Master encoding intent; software H.264/AAC MP4, HEVC/AAC MP4,
VP9/Opus WebM, AV1/Opus WebM and ProRes/PCM MOV profiles when actual capabilities
permit them; sequential multi-target delivery; per-target failures; safe reuse of
verified successful outputs; JSON events/results; explicit run/save orchestration.

No new dependencies or host method signatures are introduced. Known project
schemas 1–6 migrate to schema 7. Source-level mock/native tests are supplied but
unexecuted. Independently exercised media recipes do not establish Rust behavior.

**Restrictions:** inherited progressive 8-bit SDR input remains. ProRes creates
10-bit 4:2:2 storage from that pipeline, not recovered precision or HDR. WebM uses
explicit 48 kHz Opus output, with one display-pixel tolerance only for nonsquare
SAR. Hardware encoders, shared-decode output batches, multi-source editing,
non-unit playback speed, adjacent-video-clip cross-dissolves and Step 10 editor
interchange remain unimplemented or unqualified. No new AI/model stage runs.

Preview encoding intent is not automatic canvas resizing; choose variant framing
or the existing bounded review-proxy path. A missing encoder fails the affected
target; there is no silent hardware/software, format or quality substitution.

[Current implementation](STEP-9.md) · [Verification](../reports/step9/verification.json)

---

## Retained Step 8 and earlier scope

Older output/schema statements below describe their editions; the delta above
adds the current delivery formats without relaxing the older input restrictions.

# Current Step-8 presentation scope

The current additions are supplied plain-text SRT/WebVTT, explicit PNG/JPEG/static SVG, supplied-font titles/captions, safe-zone placement, reviewed layering, source-time graphic animation and attenuation, source-endpoint fades and explicit Step-7 punch-in generation. Pixel composition requires qualified progressive 8-bit SDR Rec.709 media. Sidecar-only captions do not require a graphics or font runtime.

**Not implemented:** non-unit speed changes, overlapping adjacent-clip cross-dissolves, unrestricted SVG/CSS/WebVTT styling, automatic semantic placement/tracking, automatic transcription, HDR/ICC graphics conversion, or a terminal UI/player. [Step 8](STEP-8.md) contains the exact supported profile and limits. Rust build/raster/native adapter tests are not yet executed.

The following sections retain prior scope details; statements about graphics being a future step belong to those historical editions.

---

# Supported scope — Video core 0.7.0

This package implements source for Video Steps 0–7 in one Rust crate. It is not a compiled, installed or all-platform-qualified extension. Independent media recipes were exercised; the supplied Rust tests, host wiring and native Windows/macOS behavior were not. See [verification](VERIFICATION.md).

## Retained editing and audio

The core supplies a lazy entry, bounded local probing, explicit stream selection, no-edit H.264/AAC MP4 rendering, versioned editable `.amxv` projects, chronological keep/trim/split/removal/protection, manual/lock precedence, stable saved settings, relinking, guarded project storage, dry-run/no-render, saved-project rendering and optional render history.

Review supplies paginated decisions, explicit approval/rejection/adjustment/locks, original/proposed temporary proxies, stale-request protection and an optional approved-player handoff. It does not provide a native player, graphical timeline or terminal UI implementation.

Pause cleanup uses per-channel energy, review-required interior-quiet proposals and short amplitude-only joins. Audio absence is not measured silence. Mixed music is preserved by default. Traditional audio includes bounded preflight, explicit Auto/On/Off treatment, DC/rumble/hum/noise handling, EQ/de-essing/compression, measured constant gain, validated peaks and PCM24 WAV stems. No learned model is added. Optional `afftdn` timing remains qualified only for the FFmpeg 7.1 release family.

## Step-6 color scope

Implemented: one full-rate display-oriented RGB analysis pass; cut, histogram, luma, channel, clipping, neutral-patch and activity observations; exact supplied source cuts; one-frame flash handling; conservative fixed-per-shot correction; explicit manual adjustments/looks; pending/rejected/approved/locked states; global bypass/reset; source-bound reports; original/proposed previews and source-time rendering.

The color path requires explicit **Rec.709 matrix/transfer/primaries, known limited/full range, progressive 8-bit YUV, no alpha and supported orthogonal rotation**. Unknown interpretation, HDR10/HLG/Dolby Vision, HDR side metadata, 10-bit SDR, interlaced frames or midstream color-range changes are rejected. White balance requires a user-confirmed neutral patch for Auto. No gray-world, face, skin or object inference occurs.

Shot parameters are constant, not adaptive relighting. This prevents parameter pumping inside a shot; it does not claim optimal grading, universal shot detection or absence of every full-resolution clipped pixel. Low-resolution statistics and pending proposals need visual review. Explicit looks/manual adjustments may intentionally clip.

HDR-preserving remux, trim with HDR metadata preservation, video-copy audio editing and tone mapping remain **unimplemented/unqualified**. They are not silently advertised because metadata can be copied. Arbitrary crop/layout/overlay and later model-assisted work are also not implemented. Existing preview scaling is a separate narrow path.

## Current render profile

- Local MP4/MOV/MKV/WebM only when the actual container/decoder is supported by the approved runtime; no playlist or network media.
- One chronological source and one explicitly selected audio stream, or video-only output. No arbitrary reordering/multicamera/multisource assembly.
- Progressive 8-bit SDR H.264/AAC MP4, even final dimensions and supported nonmirrored orthogonal display orientation. No automatic crop or odd-size workaround.
- Preserve presentation timing or explicitly request CFR. Known duration, time base and nominal frame duration are required for edited rendering. Audio uses the same video-origin timeline, with explicit leading/trailing absence handling.
- Qualified rate/layout preservation within existing audio limits. Audio preflight is bounded to 96 kHz/eight channels; stereo phase and imbalance are not silently normalized. Earlier pause measurement has its own documented limits.
- Source-time color applies before cutting. Pending color blocks final video, not unrelated audio-stem export. The new color guard does not tighten the older uncolored path unless a color profile is present.
- Output properties, full decode and applicable decoded peaks are checked before existing publication. No codec-universal playback or bit-identical transcode promise.

## Step-7 framing scope

Implemented source: per-variant Fit/padding and explicit Crop; exact bounded even output canvases; rotation/SAR-aware geometry; source-time quintic pan/zoom; explicit dead-zone reduction; shot resets; saved speed/acceleration/upscale/pixel limits; versioned editable target-guide presets; project persistence, review and original/proposed composition. Sequential outputs reuse the current runner and shared edits.

Fit preserves the full picture subject to even-raster quantization. Crop fills the target, with explicit bounds rather than silent center clamping. Animated zoom uses a fixed-raster viewport sampler, with additional CPU/resampling cost and no real-time 4K/8K claim. Scale/raster/expression budgets all apply. Dynamic source resolution/SAR/rotation changes within one stream have not been qualified.

The existing progressive 8-bit SDR render guard remains; this is not HDR scaling/tone mapping, face/group/speaker tracking, learned vision, subtitles, burned-in safe zones, a new UI or a native player. Guides are authored presets, not current service specifications. Other pending variants do not bypass shared edit/color review.

## Project compatibility

New saves use schema 5. Known schemas 1–4 migrate without activating newly introduced stages. Required saved settings remain explicit. Older readers cannot read newer documents. Color observations are compact per-shot summaries; no raw frame/PCM cache is embedded.

Default builds provide no native filesystem/process implementation. `native` supplies it through the same adapter design. FFmpeg and ffprobe are neither downloaded nor bundled. The five required media methods and two project-store methods keep their signatures; new optional operations default to a missing-capability error.

## Platform, resource and authority limits

The host owns permissions, trusted process creation, cancellation, job scheduling, UI/player lifecycle and serialized saves. Native identity/path checks are not an operating-system sandbox. Atomic publication is not a portable adversarial compare-and-swap against hostile concurrent writers.

Analysis and queues are bounded, and a limit failure returns an error rather than a partial successful analysis. Declared maximum source duration does not guarantee fitting frame/shot/diagnostic/command limits. No measured terminal input-latency SLO, 4-hour resource soak or universal valid-file guarantee is asserted.

The executed tests use generated media, including charts, tones and synthetic speech, not a representative camera/voice corpus. No human listening panel, calibrated display evaluation, Dolby Vision camera file or actual terminal UI/permission test was performed. Rust compilation/typechecking must still be completed.
