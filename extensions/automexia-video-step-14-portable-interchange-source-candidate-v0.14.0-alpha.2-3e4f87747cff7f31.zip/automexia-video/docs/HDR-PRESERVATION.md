# Restricted HDR preservation source path

**Alpha.5 verification status:** the Rust/native workflow is supplied but has not been compiled or executed in this continuation. Independent generated-media packet/pixel recipes ran against FFmpeg 6.1.1; they do not qualify the native >=7.1 path.

`VideoExtension::preserve_hdr()` provides an explicit MP4 delivery route for a
bounded subset of HDR sources. It copies encoded video and verifies the result
before publishing it. It is separate from the SDR render and color pipelines.

The source must be MOV/MP4 HEVC, progressive 4:2:0 10-bit, limited range, BT.2020
primaries and nonconstant-luminance matrix, with PQ or HLG transfer metadata. It
must have known positive dimensions and sample aspect, zero display rotation,
an exact supported CFR clock and at most 20,000 decoded frames. Dimensions must be even and at most 8,192 per axis. Evidence is
bounded to 8 MiB per task. No dynamic HDR or Dolby Vision metadata is accepted.

The retained timeline must be one contiguous source interval. Adjacent assembly
splits are merged by the normal timeline rules. Full-source preservation allows
ordinary reordered GOPs. A trim must begin at a verified keyframe and the source
must have no B-frame or PTS/DTS reordering. The seek and duration must be exactly
representable in FFmpeg's microsecond option clock. Unsupported boundaries fail;
they are not silently moved to nearby keyframes.

```rust,ignore
use automexia_video::{Cancellation, HdrRequest};
let request = HdrRequest::new("/approved/project.amxv", "/approved/output.mp4");
let result = extension.preserve_hdr(
    &project, &request, &Cancellation::new(), &mut |_| {}
)?;
```

The request selects a saved output variant. Active HDR crop, scaling, color
correction, graphics, fades, speed changes and dissolves are rejected. This route
does not claim an HDR image-processing or tone-mapping pipeline. Original
resolution and pixel interpretation are preserved. An explicit variant CFR choice must equal the source rate. This dedicated preservation request fixes video-copy/MP4 and selected-audio AAC behavior; saved encoder codec/CRF choices do not override that route, and the result reports that limitation.

Selected audio is processed by the existing audio-only planner. Accepted
traditional treatment, source-time volume keys and a verified enhancement stem
therefore keep their existing semantics. A private PCM24 lease supplies the final
AAC encode; it is never separately published. The final AAC result is measured by
the existing peak feedback loop when traditional treatment is active. Original
video packets are rechecked after every encode attempt. The MP4 movie timescale
uses the bounded least common multiple of the frame-rate numerator and audio
sample rate, so NTSC frame and sample boundaries are representable together.

Before publication, the workflow compares selected codec-header and packet
SHA-256 hashes, normalized packet PTS/DTS/durations, all decoded frame clocks,
static mastering/content-light metadata and every decoded pixel hash. Pixel hash
records carry the source stream time base, and their clocks are checked against
the independently decoded frame records. Source and intermediate identities are
revalidated before commit. Only the final MP4 lease is published.

Unselected streams, chapters and descriptive metadata are omitted. Mastering
metadata does not prove calibrated display appearance. Application import,
platform execution, monitor evaluation and camera-corpus acceptance remain
separate qualification gates. The current verification report distinguishes
supplied Rust/native tests from commands actually executed in this workspace.
