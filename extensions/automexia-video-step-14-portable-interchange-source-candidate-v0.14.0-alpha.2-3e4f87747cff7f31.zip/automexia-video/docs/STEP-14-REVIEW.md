# Step 14 review index

The current increment is [Step 14B](STEP-14B-REVIEW.md), package 0.14.0-alpha.2 with schema 10. The previous [Step 14A review](STEP-14A-REVIEW.md) is retained for its implementation history. Current evidence is under `reports/step14b`; older reports retain their original edition identities.
