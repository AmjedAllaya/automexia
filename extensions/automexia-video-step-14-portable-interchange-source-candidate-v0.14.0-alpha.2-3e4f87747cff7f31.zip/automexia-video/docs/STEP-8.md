# Step 8 — supplied captions, graphics and restrained presentation

**Package:** `automexia-video` 0.8.0, rebuilt from the verified Step 7 archive.  
**Project format:** `.amxv` schema 6.  
**Build status:** Rust source implemented but **not compiled or typechecked in this environment**. Cargo tests are supplied, not reported as run. Independent media tests execute FFmpeg and inspect decoded results; Pillow, not Rust/resvg, creates their test artwork.

This package is real source inside the same Video crate. It is not the missing earlier Step 8 archive, a Kubernetes prototype, or a replacement terminal application. All prior source paths remain. The host adapter is intentionally adjustable, as requested.

## 1. Delivered scope and remaining work

| Requirement | Implementation in this edition | Qualification or limit |
|---|---|---|
| Logos, images and SVG | Explicit, fingerprinted PNG/JPEG/static-SVG assets with bounded Rust rasterization | Selected local files only; no animated images, embedded links or arbitrary SVG/CSS |
| Titles and lower thirds | Plain text, supplied font, color, alignment, margins, plate, shadow and animation | Manual line breaks; overflow and missing glyphs are errors |
| SRT/WebVTT | Plain-text UTF-8 parser, original preservation, editable cues, cut-aware burn-in and explicit sidecars | WebVTT styling/regions/positioning and formatting tags are rejected, not silently stripped |
| Placement | Nine anchors, target/presentation safe zones, whole-animation bounds, known-layer collision checks | No face, object or baked-in source-text recognition |
| Optional placement suggestions | Pure thumbnail luma/edge/activity observations, obstacle filtering and stability penalty | The caller supplies an already decoded, target-oriented thumbnail; no automatic scan is started |
| Small effects | Linear/ease-in/ease-out/ease-in-out position, scale, opacity and volume keys; title fades/slides; source-endpoint video fades | Volume is attenuation only and evaluated per audio frame/block |
| Punch-ins | Explicit conservative intervals produce the existing Step 7 crop track | At most 8% zoom; known cuts, spacing and source bounds are enforced; not inferred emphasis |
| Dissolves | Explicit graphic-to-graphic layering with a fade-in over an opaque earlier layer | **Overlapping adjacent video-clip cross-dissolves are not implemented** |
| Playback speed | Existing unchanged source-time playback | **Non-unit playback-speed edits and speed ramps are not implemented**; unknown settings fail |
| Review/project integration | Variant-local settings, approval, bypass, locks, persistence and hypothetical previews | UI/player integration remains host-owned |

This is therefore **not a declaration that every optional effect in the broad roadmap is complete**, nor that the extension has been qualified inside Automexia. The unsupported transitions/speeds need a deliberate overlapping/time-warp timeline change; they were not approximated with misleading metadata.

## 2. One crate and the existing execution pattern

The new modules are ordinary internal responsibilities:

| Source | Responsibility |
|---|---|
| [subtitles.rs](../src/subtitles.rs) | Bounded parser, reversible caption records, exact remapping and sidecar serialization |
| [presentation.rs](../src/presentation.rs) | Editable graphics, fonts, placement, animation, guides, validation and project edits |
| [presentation_render.rs](../src/presentation_render.rs) | Effective render clock, events, collision checks and typed filter composition |
| [graphics.rs](../src/graphics.rs) | Optional Rust image/SVG/text rasterization from explicitly supplied bytes |
| [graphics_native.rs](../src/graphics_native.rs) | Optional native asset reads and owned, private PNG timelines |
| [presentation_workflow.rs](../src/presentation_workflow.rs) | Import and explicit sidecar export entry points |

Existing project, review, preview, audio and media-runner code is extended rather than replaced. No new scheduler, window, browser, decoder engine, model runtime or terminal loader is introduced. Blocking decode/raster/render work belongs on the host's existing job executor, never its typing/render callbacks.

Construction, status, project editing and plain subtitle parsing do not start media processing or scan fonts. The optional native adapter does local I/O only when an explicit operation requests it. It is not an OS sandbox or an extension permission grant.

## 3. Subtitle input, preservation and editing

`VideoExtension::import_subtitles(bytes, format)` and `SubtitleDocument::parse` accept selected UTF-8 bytes. Input is bounded to 1 MiB; the document admits at most 2,048 cues, each at most 4,096 UTF-8 bytes and eight lines. Cue times must be ordered, nonnegative, nonempty half-open intervals within the source when attached to a project.

The exact original string, including its BOM and accepted line endings, is retained with SHA-256. Edited cues do not rewrite it. SRT numbering and WebVTT external IDs remain recoverable from that original; internal cue identities are stable ordinal IDs such as `cue-1`.

Plain text supports Unicode and a small explicit character-reference vocabulary. `&amp;`, `&lt;`, `&gt;`, `&quot;`, `&apos;`, `&nbsp;` and valid numeric references become text. Literal markup is rejected at import, not executed or silently discarded. Edited literal brackets are escaped on sidecar output. Unsafe control characters, bidi overrides, malformed timestamps, duplicate external IDs and unsupported WebVTT settings are rejected.

Use `Project::change_caption` to change text or timing. The change is validated transactionally, the active cues are reordered by time, the original remains intact, and the presentation profile returns to `NeedsReview`. It must be unlocked before changing a locked profile.

### Timing through cuts

Subtitle timestamps are **source-relative to the selected video's project origin**, not automatically absolute container time. The host/user must explicitly adjust supplied captions authored in another time domain; no hidden synchronization is guessed.

For a cue `[0.5, 2.5)` and retained source ranges `[0,1)` and `[2,3)`, output contains `[0.5,1)` and `[1,1.5)`. A wholly removed cue produces no output. Overlapping cues remain in the data; burn-in collision policy decides whether their chosen boxes are acceptable.

Caption mapping uses `effective_timeline(EditRender)`, matching the renderer's microsecond shifts and sample-rounded audio assembly. It does not build a competing timeline from rounded frame numbers. Burn-in event edges use the same microsecond clock. SRT/WebVTT sidecars necessarily quantize outward to milliseconds; the export report discloses that policy. Extremely short cues can share or overlap a rounded sidecar millisecond.

### Burn-in versus sidecar

`CaptionLayer` contains the document, optional style and placement, and `burn_in`.

* Burn-in requires an explicit font/style and box; the host prepares those assets and rasterizes text.
* Sidecar-only use needs neither fonts nor graphics capability. It still requires resolved edits and explicit export authorization.
* `export_subtitles` writes only the requested `.srt` or `.vtt`; rendering never silently creates an additional sidecar.

The sidecar publisher receives protected project, source and asset paths, and must reject aliases and changed replacement targets. Native implementation checks these around staging. Create-new is the normal policy; reviewed replacement is deliberate.

## 4. Assets, fonts and static rasterization

`AssetRef` stores a selected local path, byte size and SHA-256. A relative path resolves against the absolute project location. URLs, parent traversal, controls and invalid fingerprints are rejected. Save-as rebases graphics and fonts alongside media references, **including disabled layers**.

The graphics feature uses pinned `resvg 0.45.1`, `image 0.25.5`, `roxmltree 0.20.0` and `ttf-parser 0.25.1`. These are new optional media dependencies, not default terminal dependencies. The `native` feature enables `graphics`; the default core can author/validate plans without it. No model, Python, Node or browser dependency is added to the Rust runtime. Python/Pillow are only independent-test tools.

### Image profile

PNG/JPEG are admitted as static, qualified SDR graphics. They preserve their aspect inside the selected box, using transparent padding rather than silently stretching a logo. Dimensions, decoded pixels and allocation are bounded before full use. JPEG EXIF orientations 1–8 are normalized explicitly.

Animated PNG, 16-bit graphics, CMYK/high-bit-depth JPEG, ICC-managed input and contradictory PNG gamma/chromaticity/HDR metadata are rejected. Untagged RGB graphics use an explicit sRGB assumption. Normalize unsupported source assets deliberately before selecting them; this package is not an ICC or HDR graphic conversion system.

### SVG profile

Only a bounded static subset is accepted: shapes, paths, groups, local gradients, definitions and descriptive text nodes. DTD/entities, scripts, CSS, foreign content, image/use references and externally supplied SVG text are rejected. Both usvg image resolvers return `None`, and no resource directory is configured. It must not read an image or font merely because an SVG names it.

### Text and fonts

Titles/captions use **one explicitly supplied single-face TTF/OTF** with its actual family and fingerprint. No system-font discovery or silent fallback runs. Unsupported glyphs, a mismatched family, font collections or overflowing text produce actionable errors. Text is XML-escaped before the private generated SVG is rasterized. `%{pts}`, shell metacharacters and XML-like text are data, not FFmpeg drawtext expressions.

Font files are **not bundled** in this archive. The tests require an explicitly selected test font. Unicode preservation is implemented; a multilingual typography/platform campaign has not been performed.

Text offers light/dark variants, optional background plates, shadows, padding, line height and left/center/right alignment. Break lines or change the box/font size explicitly when text does not fit. There is no undisclosed clipping or guessed automatic line wrapping.

The renderer converts premultiplied raster data back to straight alpha. Scaling premultiplies before filtering to avoid dark fringes and hidden-color bleed. Final overlay code values are converted from sRGB to Rec.709 before video composition. Layer composition is ordinary 8-bit code-value composition, not a claim of linear-light mastering quality.

## 5. Placement and target guides

An element has an explicit width, height, margin and one of nine anchors. For an active framed variant, the effective margins are the **maximum per edge** of its saved target guides and its presentation guides. A weaker title setting cannot silently overrule the target's larger reserved area.

Bounds cover every supported keyframe's affine rectangle and therefore the complete monotone interpolation envelope, including scale and displacement. Rounded integer rectangles are checked again during rasterization. Neither an off-screen slide nor a shadow/text overflow is silently accepted.

Known overlapping graphics/captions fail by default. For intentional layers, the user sets `CollisionPolicy::AllowReviewed` and approves that exact profile. This does not disable canvas bounds or grant asset access. It simply acknowledges deliberate overlap.

`suggest_anchor` ranks the fixed candidates using supplied luma, edge/activity, known obstacles and a prior-anchor stability cost. `measure_anchors` can obtain those observations from caller-supplied, already target-oriented RGB thumbnails with bounded sampling. These functions do not decode footage, infer subjects or continuously reposition graphics. Use them once per proposed shot/segment, then review and persist a stable placement.

## 6. Small effects and their exact clock

`VisualKey` values use elapsed **source time within the element's source range**. Supported values are position displacement, scale and opacity. Linear, ease-in, ease-out and ease-in-out curves are deterministic and monotone. First key is at zero; ordering, finiteness, bounds and count are validated.

`Animation` adds explicit fade-in/fade-out durations. Cutting away the beginning of an element or previewing its middle does not restart its fade or slide. Source-time event phase is retained through the effective edit map.

Continuous animation is sampled at the saved `RasterPolicy.animation_fps` (default 60). This bounds raster work and is not motion interpolation or a guarantee of continuously smooth 240 fps output. Static cue edges remain separately represented. The generated overlay stream must neither repeat a finished caption nor extend the main video's duration.

A graphic-to-graphic dissolve is achievable with intentional overlap: retain the first opaque element while the second fades in, then end the first. Do not fade both over transparency and call that an equivalent cross-dissolve; it would expose the background. The independent suite checks the opaque-underlay composition.

`VolumeTrack` uses source-time gain keys in `[0,1]`. The mapping follows cuts and is applied after accepted voice postprocessing but before final measured gain/limiting. Evaluation follows FFmpeg audio-frame/block timing; it is **not sample-accurate gain automation**. Bypass/removal of the profile restores prior audio behavior. If voice loudness correction is active, it measures the actually assembled signal including volume settings.

`VideoFades` applies short fades at the original source's beginning/end and preserves the source timestamp origin. A trimmed/previewed middle segment does not manufacture a new fade. These are not adjacent-clip overlap transitions.

`explicit_punch_ins` produces existing Step 7 crop shots for user-selected source intervals. Zoom is bounded to 1.08, spacing to at least one second, and known cuts cannot lie inside a requested interval. It creates a reviewable crop profile, not an immediate render or a face-safe claim. Explicit intervals are not automatic emphasis detection or alternating zoom on every pause cut.

**Non-unit playback speeds, speed ramps and overlapping video-clip cross-dissolves remain unsupported.** Supporting them safely requires extending the one-source, non-overlapping time map, including captions, audio, review and export. Unknown fields fail instead of appearing editable while doing nothing.

## 7. Render, preview and source protection

Final rendering remains `render_project`; there is no new user-facing converter. Its order is: approved source-time color/framing/fades and source selection → shared edit-time remapping → timed graphics/captions → proxy scaling when applicable → the existing output profile and validation.

The host prepares a leased, private PNG timeline. Selected paths never enter ffconcat text: manifests contain only generated ASCII content-hash filenames. `-safe 0` is limited to that internally generated manifest because its per-file framerate option requires it; the file/format allowlists remain narrow.

Final output retains the existing decode, timing, channel, color and publication checks. Assets are fingerprinted on read and rechecked before publication. Media and named graphic/font references are protected from output replacement, including disabled references; a reviewed destination matching protected asset bytes is conservatively refused. The native lease adds live alias checks. This is not a guarantee against arbitrary same-user filesystem attacks or all platform race conditions; the host still owns trusted file grants and serialization.

Before previews remove presentation. Proposed previews apply only the selected profile hypothetically along with already resolved edits. They do not approve or save. Graphics phases follow the original source clock, and the final composed image is scaled for the proxy. Playback revalidates both the proxy and the corresponding selected assets.

`PresentationLease` owns the generated timeline for the necessary operation/preview lifetime. Cancellation is checked while reading, rasterizing, writing and running media tools. Rust decoding/raster calls are not force-preemptible within a call, and temporary-directory cleanup is not an OS sandbox. Hosts retain normal error reporting and player/file-handle lifetime responsibilities.

## 8. Project, review and migration

Each output variant now optionally stores `presentation`. Shared cuts, voice, color and sibling variants remain independent. Projects save as schema 6; the known 5→6 migration adds **no** presentation or permissions. Known earlier migrations remain. Older readers cannot read schema 6.

Normal edits use `Project::set_presentation`, `update_overlay`, `remove_overlay`, `change_caption`, `review_presentation` and `set_presentation_locked`. Changing content or timing returns the group to `NeedsReview`. Approval currently covers **the whole variant presentation profile**, not independently approved individual glyphs/cues.

`ReviewSession::set_presentation` attaches/replaces a profile without discarding other unsaved work. Existing dispatch gains `ReviewTarget::PresentationVariant` and `ReviewCommand::ChangePresentation`. Details expose the full profile. Changes cancel obsolete previews, set dirty state and preserve the existing optimistic-concurrency binding.

An unresolved active profile blocks that variant's final render. Other resolved variants remain available when shared edits are resolved. Sidecar export requires that profile's explicit approval. A disabled profile does not require its missing graphics to render the source normally.

Pure voice preflight does not read graphics. Audio-only work strips pixel requirements while retaining applicable volume intent. An unresolved presentation group that contains volume must still be reviewed before audio export uses it.

## 9. Small host integration delta

The existing five required `MediaHost` and two `ProjectStore` signatures are unchanged. Two optional default-denied methods are added, with native implementations supplied:

```rust
fn prepare_presentation(
    &self,
    plan: &PresentationRender,
    project_file: &std::path::Path,
    cancel: &Cancellation,
) -> Result<Box<dyn PresentationLease>>;

fn publish_subtitles(
    &self,
    source: &InputFile,
    protected: &[std::path::PathBuf],
    destination: &std::path::Path,
    policy: &OutputPolicy,
    bytes: &[u8],
    cancel: &Cancellation,
) -> Result<std::path::PathBuf>;
```

Map `Stage::PreparingGraphics`, the two review variants, new action descriptors, `ReviewDetail.presentation`, and `presentation: None` in explicit `OutputVariant` constructors. `ProjectRenderResult.presentation_assets` returns observed graphic/font identities and renderer identity; it does not pretend the old compact render-history record stores every receipt automatically.

Reuse existing action, picker, settings, job, confirmation and player facilities. New names are this crate's adjustable API, not a claim about the terminal's current binary ABI. No terminal source was needed to produce this core; the actual host integration remains the user's adapter task.

## 10. Resource limits

| Object | Default / hard ceiling |
|---|---:|
| Subtitle input | 1 MiB / 2,048 cues |
| Cue text | 4 KiB / 8 lines |
| Mapped cue parts | 8,192 |
| Graphics per profile | 64 |
| Visual or volume keys | 32 per track |
| Asset | 16 MiB |
| SVG | 1 MiB, 10,000 elements, depth 64 |
| Unique loaded asset bytes | 64 MiB |
| Decoded patch cache | 64 MiB |
| Canvas/raster | at most 8,192 per edge and 16,777,216 pixels |
| Animation sampling | default 60; range 1–240 fps |
| Raster timeline states | default 8,192; maximum 16,384 |
| Owned scratch | default 512 MiB; maximum 2 GiB |
| Preparation timeout | default 120; maximum 600 seconds |
| Known collision comparisons | 1,000,000 |

Limits reject rather than silently truncate. They bound retained bytes/states, not total process RSS: parser objects, decoder allocations, resampling buffers and concurrent host work add overhead. Static layers deduplicate into reused PNGs; long high-frequency animation can hit state/scratch limits even if the media itself is short enough to render.

## 11. Reproduction and evidence

```bash
cargo test --no-default-features
VIDEO_TEST_FONT=/absolute/path/to/selected.ttf cargo test --features graphics
FFMPEG=/usr/bin/ffmpeg FFPROBE=/usr/bin/ffprobe \
VIDEO_TEST_FONT=/absolute/path/to/selected.ttf cargo test --features native
python3 -B tests/media/run_presentation_checks.py --output /tmp/step8-media.json
```

The Rust commands were **not executable here** because no Rust/Cargo toolchain is present. The optional dependencies have not been resolved into a lockfile. Use the supplied CI configuration or your build environment; a provided workflow is not a successful CI run.

The independent suite reads the actual Rust filter/input literals but supplies Pillow artwork and its own test mapping. It verifies FFmpeg output, not Rust parsing, usvg/resvg, host permission code, project storage, callbacks or native UI. The new Cargo tests target those actual Rust paths and intentionally do not disguise absence as a pass.

See [current verification](VERIFICATION.md), [review log](STEP-8-REVIEW.md), [implementation status](../reports/step8-implementation-status.json), and [integration example](../examples/presentation_smoke.rs). Calibrated display, representative filmed footage, large multilingual font sets, Windows/macOS, long-duration resource and native Automexia qualification remain outstanding.
