# Step 12 — implementation review record

This record separates observed source defects from executed tests. No Rust compiler is available; source corrections and supplied Rust tests are not claimed as Cargo passes.

## Pass 1 — baseline and implementation

Read the Video Step 12 roadmap and verified the complete Step 11 source ZIP and SHA manifest. Recorded immutable input identities and static module coupling. Identified repeated native capability queries, spread-out lifecycle state and repeated source analysis. Kept one crate rather than introducing package count for its own sake.

Implemented a private job registry, explicitly scoped observation reuse for pause/voice/color, a private native pipe runner and an optional one-slot progress bridge. Existing edit/render/interchange models were retained.

## Pass 2 — source-level adversarial review

1. **Unwind ordering:** placing child cleanup outside `thread::scope` can postpone termination until blocked readers are joined. Moved the child guard and channel receiver into the scoped body; reader-start failure, callback panic/error and cancellation stop the child and release the receiver before implicit joins.
2. **Long-held capability memo lock:** first implementation held the cache lock during six process queries. Revised it to short snapshot/publication locks; concurrent first-use duplicate work is allowed rather than delaying cancellation on a long-held mutex.
3. **Incomplete drain:** counting only admitted media jobs can report completion between stages of `run_workflow`. Added a bounded whole-workflow lease and separate remaining-workflow count. Re-enable while disabled work remains returns Busy.
4. **Teardown order:** put the job/lifetime owner before the host field so cancellation occurs before the host destructor.
5. **Cache accounting:** use checked multiplication for vector/string capacity accounting. Retain facts only; rebuild every proposal against current project decisions and maintain the existing source/grant revalidation on hits.
6. **Runtime scope:** document that executable hashes do not pin shared libraries/drivers. An effective runtime change requires a new native host and observation cache; no false full-runtime-attestation claim.

Supplied focused Rust and native regression tests for these paths. They remain unexecuted locally.

## Pass 3 — executable checks and final delivery

The new eight-test Python source-boundary guard suite passed its initial run. The suite deliberately corrupts project/algorithm/dependency/process boundaries to check rejection. It is not a Rust parser or feature-behavior test.

The first full execution passed all 354 independent media cases, 58 packaging
regressions and the 45 retained qualification-runner tests. Its aggregate status
was correctly blocked by missing Rust/Cargo, but review exposed a stale hardcoded
`step: 11` label in the generic qualifier. The report is preserved unchanged as
first-pass evidence, not edited after the fact.

The qualifier now reads matching current Cargo/delivery-policy/release-candidate
identities before creating output and includes those identities in its source
digest. Six new tests exercise current-step labeling, mismatched versions,
boolean/duplicate milestones, missing policy and identity mutation. All 51
qualification-runner tests passed after this fix. The full current
independent-media and packaging/qualification results are in [verification.json](../reports/step12/verification.json). Previous step reports remain historical. Final publication must use `package_delivery.py`, verify its exact immutable archive/receipt, and rerun checks from a fresh extraction. A missing compiler remains a blocked check, not a pass or a reason to invent results.
