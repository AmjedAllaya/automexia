# Supported source scope — 0.14.0-alpha.2

**Format:** `.amxv` schema 10. **Artifact:** one Rust source crate. **Execution status:** current Rust compilation, native workflows and selected model inference are unverified. “Implemented” below means code is supplied; it does not claim host installation or production qualification.

| Area | Implemented source | Explicit limits |
|---|---|---|
| Media and clocks | Selected local media, stream identities, orientation/SAR, exact rational time, decode/encode and output validation | Supported demuxers/codecs depend on approved FFmpeg/ffprobe 7.1 or newer; no universal file-extension promise |
| Editing and projects | One selected source, retained ranges, split/remove/protect, variant reorder/repeat/trim, reversible decisions, locks, relink and migrations | Multisource/multicamera assembly remains deferred; authored clips are bounded to 64 |
| Review | Decision inspection, disposition/lock controls, source-bound previews, pending-edit gates | Host keyboard/focus/player integration requires the actual application |
| Pauses and voice | Conservative energy proposals, optional speech veto, classical cleanup, measured loudness and peak control, PCM stems | Classification uncertainty remains reviewable; no recovery of already clipped audio |
| Color | Source-shot boundaries, bounded SDR correction and explicit manual looks | Pixel-changing color/framing/graphics paths remain progressive 8-bit SDR; no general HDR grading |
| Geometry and timing | Fit/crop, source-space tracks, reviewed variants, per-clip/global 0.5×/1×/2× speed with effective 0.25×–4×, pairwise dissolves | No speed ramps, triple overlap or unconstrained transitions; timing/export preconditions must pass |
| Presentation | Restricted assets, explicit fonts, supplied/generated subtitles, bounded animation, measured anchor suggestions | No arbitrary SVG/WebVTT browser semantics; no recognition of unknown baked-in graphics |
| Delivery | Frozen presets/profiles, sequential variants, retries, explicit software encoder capabilities | No hardware encoders or shared-decode multi-output optimization |
| Interchange | OTIO, modern FCPXML 1.10, legacy FCP7 XML and restricted CMX3600; portable OTIO/FCPXML ZIP64 bundles, explicit PCM stem/ProRes bake and compatibility reports | No AAF or full `.amxv` asset backup; operation support differs by writer; actual editor imports remain untested |
| Model lifecycle | Verified local packs, persistent inventory, install/select/update/revoke/remove, generation checks | No asset discovery/downloader or publisher-signature infrastructure; the host approves assets and rights |
| Speech/face/transcript | Silero contract, RNNoise adapter, UltraFace RFB-320 adapter, bounded whisper.cpp provider and editable transcript workflow | No learned-model execution or quality ranking performed in this continuation; no diarization/active-speaker/identity recognition |
| Integration | Explicit action registry ownership, typed dispatch, cancellation/drain and removal | No actual Automexia ABI, manifest or installer supplied; registration source alone does not complete Step 0 |

Audio-only work validates the selected audio instead of imposing unrelated SDR video encoder requirements. The separate HDR preservation workflow is deliberately narrower than ordinary rendering; consult its request validator and phase review before using it. General HDR crop/scale/color/overlay processing, Dolby Vision rewriting and arbitrary HDR concatenation are not advertised.

Automatic observations do not approve edits. Saved manual corrections and locks take precedence. Model activation, source fingerprints, project revision and relevant asset identities bind adoption and execution. Changed sources or revoked selections invalidate dependent reports. Accepted edit metadata remains independent of later model availability.

The default library starts no process and loads no model. Native execution stays inside the existing pinned-tool runner. Native filesystem controls are not an operating-system sandbox, hostile-directory guarantee or portable power-loss transaction.

## Qualification limits

The fresh environment had no Rust/Cargo, no dependency cache and the earlier toolchain download attempt failed. `Cargo.lock` therefore remains absent and must be generated/reviewed at the first connected build. FFmpeg/ffprobe 6.1.1 was available for independent Python recipes but does not satisfy the production native adapter's 7.1 minimum. The fixture-only checks do not establish Rust integration or model quality.

Linux native qualification, Windows/macOS execution, actual Automexia install/update/remove, editor imports and representative camera/speech listening/visual acceptance remain open. Existing CI schedules these checks; a workflow file does not prove that CI ran.

The bounded [Step 14A assembly](STEP-14A.md) and [Step 14B portable interchange](STEP-14B.md) increments are implemented in source. Other Step 14 backlog items and explicitly excluded cloud/generative/editor products remain outside this continuation. See [the current review](STEP-14-REVIEW.md) for implementation scope and outstanding acceptance.
