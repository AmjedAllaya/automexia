# Step 12 — build, integration and manual acceptance

Source candidate only. Read [Step 12](STEP-12.md) and the unchanged [release requirements](RELEASE-QUALIFICATION.md). No editor/application, platform or Rust-build acceptance is asserted by an archive-integrity check.

## 1. Compile and test the actual code

Use Rust >=1.85 and approved FFmpeg/ffprobe. Generate and review a real Cargo.lock before frozen build/distribution; the source candidate does not invent dependency resolution or an owner license.

```bash
cargo generate-lockfile
cargo test --locked --no-default-features
cargo test --locked --no-default-features --test modernization
VIDEO_TEST_FONT=/absolute/path/to/your.ttf cargo test --locked --features graphics
FFMPEG=/absolute/path/to/ffmpeg FFPROBE=/absolute/path/to/ffprobe \
VIDEO_TEST_FONT=/absolute/path/to/your.ttf cargo test --locked --features native
```

The graphics font is a caller-selected local prerequisite, not a bundled file. A complete build failure is a failed gate even if independent media tests pass. The new native modernization suite must not be substituted with Python media recipes.

## 2. Compare repeated analysis with fresh analysis

For pause, voice and color on qualified real source footage, record the uncached output and repeat with a new cache, then a hit. Compare recommendations, source metadata, time ranges, warnings and `.amxv` resulting decisions. Repeat after a manual protect/reject/lock and after moving identical media. Confirm a new report carries the current project binding; an old report must remain stale.

Revoke the input grant or change the file before a would-be hit. It must fail through the current host. Change selected streams, settings, declared cuts and effective runtime identity; reuse must stop. Disabled/cancelled caches cannot revive after re-enable. Extremely small cache budgets return fresh results without storing them.

Record cold/repeat elapsed time, subprocess count, total extension+helper RSS, transient peak memory and host responsiveness. Hits still hash/probe the source: do not assume zero I/O or a fixed speedup. Compare using the same machine, files and runtime. Include long recordings and many scene boundaries.

## 3. Cancellation, drain and ownership

Cancel during hashing, native discovery, each analysis stream, rendering, preview and interchange publication. Also disable between stages of `run_workflow`. Call `disable_and_drain` from a separate lifecycle worker; a timeout must report unfinished jobs/workflows and leave the extension disabled. Try immediate re-enable: it must be Busy while old admitted work remains.

After complete drain, join the host's threads and stop/release its player and preview handles. Drop the cache explicitly. Only then unload or replace native code. A report indicating zero core jobs does not prove OS handles or host callbacks were released.

Inject consumer rejection, panic, closed pipes, a failed reader start where possible, and a child that closes stdout/stderr without exiting. No process or pipe-reader thread should remain. Test the actual Windows containment path separately; Linux process-group results do not qualify it.

## 4. Progress bridge

Generate updates faster than the UI consumes them. The mailbox should retain one current value and count overwritten progress. Cancellation must not wait behind the data. Use a new sender/receiver pair after a request change and reject old senders. Return final receipts/errors normally; never treat encoder-end or the last progress event as publication success.

## 5. Compatibility and rollback

Open saved schema-7 projects and compare cut/color/framing/presentation decisions, output metadata and editor interchange with the prior candidate. Existing real-media and editor-import acceptance remains mandatory. No accepted decisions belong to the observation cache. Delete/drop it and confirm rerender from saved decisions still works.

Runtime libraries/drivers updated while an executable file remains unchanged are outside the executable-hash memo's attestation. Recreate the native host and observation cache after such an update; do not reuse old qualified capability information blindly.

Rollback to the previous source build should open unchanged schema-7 projects. Do not transfer Rust memory objects across dynamic builds. Preserve valid outputs/projects when cancelling or uninstalling; never delete user files to simulate cleanup.

## 6. Reproduce source and delivery checks

```bash
python3 -B tools/check_modernization.py
python3 -B -m unittest discover -s tests/modernization -v
python3 -B -m unittest discover -s tests/packaging -v
python3 -B -m unittest discover -s tests/qualification -v
python3 -B tools/qualify_release.py --source . --output /absolute/new/outside-directory --suite all
```

These checks have distinct scopes. The last command reports missing build requirements as Blocked. Packaging verifies real file identity and archive/extraction integrity; it does not approve an application release or authorize AI. Step 13 remains separate.
