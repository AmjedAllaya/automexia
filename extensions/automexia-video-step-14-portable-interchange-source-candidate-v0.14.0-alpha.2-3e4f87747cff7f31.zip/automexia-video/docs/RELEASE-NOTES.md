# 0.14.0-alpha.2 — Step 14B portable interchange

Continues the complete **0.14.0-alpha.1** project with modern FCPXML 1.10 and portable OTIO/FCPXML ZIP64 handoffs. A handoff includes its timeline, complete referenced media, a SHA-256 manifest and a compatibility report. Content names are portable and deduplicated while every inspected input identity remains bound to publication.

Explicit ProRes/video and PCM/stem bakes remain inside private staging. One create-new commit publishes the completed archive; source changes, collisions, cancellation and callback failures before commit leave no public partial bundle. Post-commit readback uncertainty stays visibly published but unverified. Native archive streaming and exact overhead accounting add no runtime dependency. The project schema remains 10.

FCPXML preserves exact rational timing, pixel aspect ratio, selected audio, source/record timecode and one-frame project markers with original ranged metadata. Unsupported clocks, XML characters and known excessive escaped XML size block before baking. The legacy FCP7 writer remains available. New typed dispatch and optional bundle registration connect to the existing host owner.

Independent reviews and regression material cover private-workspace/input binding, archive and metadata limits, source aliases, canonical destination readback and failed-publication cleanup. Executed totals and outstanding prerequisites are in [verification](VERIFICATION.md). Rust compilation/native execution and actual editor imports remain unverified here. No model weights, external binaries, fonts or Cargo.lock are fabricated.

Step 14 remains an optional backlog; multisource/multicamera editing, continuous ramps, AAF and full `.amxv` asset backups are outside this increment. Product, host, native, editor and selected-model qualification flags remain false.
