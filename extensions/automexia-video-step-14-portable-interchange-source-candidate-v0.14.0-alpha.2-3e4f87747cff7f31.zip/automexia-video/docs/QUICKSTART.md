# Quick start — 0.14.0-alpha.2

This package is the Video extension core and its developer examples. Integrate it with the actual Automexia dispatcher and approved media/file/job services. It is not an already installed `video` executable or a second editor application. [Integration](INTEGRATION.md) describes the adapter surface.

## First connected build

The current continuation environment has no Rust/Cargo and could not reach official toolchain/dependency sources. **Cargo.lock is absent.** Use Rust/Cargo meeting the declared Rust 1.85 minimum, resolve dependencies once, inspect the lockfile and retain it:

```bash
rustc --version
cargo --version
cargo generate-lockfile
cargo metadata --locked --all-features --format-version 1
cargo test --locked --no-default-features
```

Do not substitute an old lockfile or a previous edition's test counts. After dependencies have been fetched, `--frozen` enforces locked/offline Cargo operation. Build-time Cargo resolution is separate from the extension's runtime behavior; the media/model providers do not download assets.

## Approved media tools and font

Set explicit absolute paths to FFmpeg/ffprobe **7.1 or newer** and your selected graphics-test font. The installed 6.1.1 tools used for independent recipes in this workspace are insufficient for native qualification.

```bash
export FFMPEG=/absolute/path/to/approved/ffmpeg
export FFPROBE=/absolute/path/to/approved/ffprobe
export VIDEO_TEST_FONT=/absolute/path/to/selected/DejaVuSans.ttf
cargo test --locked --features graphics
cargo test --locked --features native
cargo check --locked --all-features --all-targets
cargo test --locked --all-features --lib
```

PowerShell uses `$env:FFMPEG`, `$env:FFPROBE` and `$env:VIDEO_TEST_FONT` with the same Cargo commands. Font files, runtime binaries and model weights are not included in the archive. `native` provides filesystem/media adapters; `silero-onnx` and `face-onnx` explicitly add the ORT-backed providers.

## First actual output

Use a compatible progressive 8-bit SDR clip and a fresh destination. The developer example invokes the real native adapter once compiled:

```bash
cargo run --locked --features native --example native_smoke -- \
  /absolute/input.mp4 /absolute/new-output.mp4 "$FFMPEG" "$FFPROBE"
```

The project example intentionally removes the middle third, demonstrating reversible metadata edits:

```bash
cargo run --locked --features native --example project_smoke -- \
  /absolute/input.mp4 /absolute/new-project.amxv /absolute/new-edit.mp4 \
  "$FFMPEG" "$FFPROBE"
```

Use the ordinary project/review APIs to inspect, approve/reject, lock, save and render decisions. Pending proposals block final use; a preview is not approval. The saved project freezes chosen settings, selected streams and source identity. New global presets do not silently replace saved decisions.

## Optional local intelligence

- [Model packs](MODEL-PACKS.md) describe explicit verification, storage, selection and revocation.
- [Step 13C](STEP-13C.md) describes reviewed voice enhancement.
- [UltraFace](FACE-ONNX.md) describes the exact face graph/runtime contract and explicit framing/anchor/punch-in choices.
- [Transcription](TRANSCRIPTION.md) describes the pinned whisper.cpp contract, editable words and the `transcript_smoke` example.
- [Placement](PLACEMENT.md) is available without a learned model.

Supply assets and expected identities through the trusted host. The tests do not select arbitrary installed weights. Missing model assets are qualification blockers, not successful inference cases.

## Repeat the qualification record

Create a parent directory outside the source tree and choose a fresh run directory:

```bash
mkdir -p ../video-qualification
python3 -B tools/qualify_release.py --suite all \
  --output ../video-qualification/run-1 --timeout 1800
python3 -B tools/dependency_inventory.py \
  --output ../video-qualification/dependencies.json
```

The runner records pass/fail/blocked states and source fingerprints. It includes independent recipes and Rust-generated interchange readback as distinct layers. It cannot perform an unavailable host installation, graphical editor import or human quality review. See [release qualification](RELEASE-QUALIFICATION.md) before marking any product gate complete.


## Reviewed assembly demonstration

With approved native tools and a compatible selected source of at least four seconds, run:

```bash
cargo run --locked --features native --example assembly_smoke -- \
  /absolute/input.mov /absolute/new-project.amxv /absolute/new-output.mp4 \
  "$FFMPEG" "$FFPROBE"
```

The example chooses an even frame count `C = 2 × ceil(fps / 2)`, approximately one second. It explicitly approves its documented demo sequence: later source frames `[2C, 3C)` at normal speed, earlier `[0, C)` at half speed, and later `[2C, 3C)` again at double speed. The source needs at least `3C` frames; the output contains `3.5C` frames. Start with a 320×180 fixture to stay comfortably inside the conservative retained-branch memory estimate.

The example saves the project, reloads it, renders via the normal selected-variant workflow and records render history. Use fresh project/output paths. This command is supplied for a qualified build environment and was not executed here. See [Step 14A](STEP-14A.md) for the editable API and preview/export limits.

## Portable editor handoff

After saving and reviewing a project, use a fresh `.zip` destination. The example reads saved intent and does not approve edits:

```bash
cargo run --locked --features native --example bundle_smoke -- \
  /absolute/project.amxv /absolute/new-handoff.zip fcpxml 30000/1001 source source
```

Use `otio` for an OTIO bundle, `bake` as the fifth argument for a private visual bake, and `source`, `stem` or `omit` as the sixth argument for audio. Baking is explicit; compatibility assessment may require it for effects the chosen writer cannot represent. Extract the complete archive together and import `timeline.fcpxml` or `timeline.otio`. See [Step 14B](STEP-14B.md) for byte budgets and limits. This example is supplied for a qualified Rust/native environment and was not executed here.
