# Explicit local model packs and lifecycle

Video provides a bounded model inventory and local storage adapter for the existing
host/component owner. It does not download models, discover a preferred model,
install runtimes, or acquire native execution privileges. Installation, selection,
runtime initialization, analysis and proposal acceptance remain separate actions.

`ModelManifest` and `VerifiedModelPack` support these exact typed families:

| Contract | Preprocessing | Maximum model bytes |
|---|---|---:|
| `silero-16k-512-context64-state2x1x128-v1` | `explicit-channel-ffmpeg-resample16k-no-normalization-v1` | 32 MiB |
| `ultraface-bbox-v1` | `display-rgb-lowres-letterbox-v1` | 32 MiB |
| `yunet-face-bbox-v1` | `display-rgb-lowres-letterbox-v1` | 32 MiB |
| `rnnoise-48k-frame480-v1` | `selected-layout-resample48k-delay480-v1` | 32 MiB |
| `whisper-cpp-ggml-tiny-base-v1` | `explicit-channel-pcm16-16k-source-clock-v1` | 160 MiB |

A manifest contract does not imply that every family has a concrete native adapter.
The implemented face adapter is UltraFace; YuNet remains a typed host-provider
contract. Each concrete adapter must reject another family's manifest before
loading a runtime and validate its own input/output tensor or file contract.

## Explicit files and identities

Supply a manifest, monolithic weights and notices as three explicit local files.
The host separately pins the expected manifest SHA-256 after reviewing its origin.
`native_model_store::read_selected_pack` is available with `native`, independently
of the optional ONNX feature. The original `silero_onnx::read_selected_pack` entry
point delegates to it for compatibility. Neither function scans directories or
fetches URLs.

A SHA-256 match proves byte identity, not publisher authenticity, safe model
behavior or distribution rights. `ModelActivation::selected` represents the
existing owner's reviewed choice; it grants no system permission.

The following field illustration is deliberately not an installable manifest:

```json
{
  "schema": 1,
  "id": "org.automexia.video.speech",
  "revision": "OWNER_SELECTED_REVISION",
  "source_revision": "EXACT_UPSTREAM_SOURCE_REVISION",
  "contract": "silero-16k-512-context64-state2x1x128-v1",
  "preprocessing": "explicit-channel-ffmpeg-resample16k-no-normalization-v1",
  "weights_sha256": "MEASURED_LOWERCASE_SHA256",
  "weights_bytes": 0,
  "runtime": {
    "adapter": "ort-2.0.0-rc.10-cpu-v1",
    "build_info_sha256": "HASH_OF_ACTUAL_RUNTIME_BUILD_STRING",
    "artifact_sha256": "MEASURED_RUNTIME_LIBRARY_SHA256"
  },
  "code_license": "REVIEWED_CODE_LICENSE_EXPRESSION",
  "weights_license": "REVIEWED_WEIGHT_TERMS",
  "notices_sha256": "MEASURED_NOTICE_FILE_SHA256"
}
```

Measure `weights_bytes` and replace every identity placeholder from actual files.
Manifest data is at most 32 KiB and notices at most 256 KiB. IDs are bounded ASCII
tokens. Hashes contain exactly 64 lowercase hex characters. Duplicate or unknown
fields, incompatible preprocessing, mismatched lengths and altered bytes fail.
The verifier preserves the exact original manifest and notices alongside immutable
owned weight bytes; serializing a manifest again must not change the trusted hash.

## Persistent storage and selection

`ModelStore<B: ModelStorage>` implements the lifecycle independently of a filesystem.
A host can supply its existing storage mechanism through `ModelStorage`.
`NativeModelStorage` supplies an optional filesystem implementation and a
`NativeModelStore` alias. Construct it only in the trusted component owner, using
an explicitly chosen canonical private directory. On Unix the directory must be
0700; newly written files are 0600. Other platforms require equivalent host ACLs.
The advisory lock remains held for the whole manager lifetime, excludes another
process or manager, and is released when the owner drops it. The lock file itself
is retained to avoid creating competing lock inodes.

```rust,ignore
use automexia_video::{Cancellation, NativeModelStorage};
use automexia_video::native_model_store::read_selected_pack;

let cancel = Cancellation::new();
let store = NativeModelStorage::open(&owner_selected_store_directory, &cancel)?
    .into_store(&cancel)?;
let pack = read_selected_pack(&manifest, &weights, &notices,
    &externally_reviewed_manifest_sha256, &cancel)?;
let reviewed = store.inventory(&cancel)?;
let installed = store.install(&pack, reviewed.generation, &cancel)?;
// A separate explicit choice. Installation does not select a model.
let choice = store.select(&pack.identity().manifest_sha256,
    installed.generation, &cancel)?;
let provider = build_the_matching_provider(choice.pack().clone())?;
// Pass BOTH provider and choice.activation() to the optional workflow.
```

The inventory contains a generation, installed exact identities, and a map from
contract to explicitly selected manifest hash. It is bounded to 1,024 installed
models and 2 MiB of serialized inventory. Every mutation checks the caller's
reviewed generation. A stale view returns `InputChanged` rather than overwriting a
newer choice. Installation rejects a conflicting manifest under an existing
component ID and revision. Reinstalling the identical pack is idempotent.

`update_selected(previous_manifest, pack, generation, cancel)` atomically installs
and selects a new revision of the same component. It also compares the previous
selection hash. The old pack remains installed for an explicitly chosen rollback
or removal. Pack directories are named by the verified manifest digest and written
through private staging before the atomically replaced inventory references them.
A failed inventory commit leaves the previous selection authoritative; any fully
written orphan remains unselected and can be reused only after reverification.

Opening an inventory does not initialize a model or native library. The explicit
`selected(contract, cancel)` acquisition honors the owner's persisted choice and
reverifies its three files before issuing the first immutable reader in that
manager lifetime. It never chooses an alternative model or enables an optional
workflow by itself.

## Revocation, removal and cancellation

A selection owns immutable verified bytes and a shared `ModelActivation`.
`revoke`, successful selection replacement, successful removal, and manager drop
invalidate every activation clone issued by that manager. Running inference receives
an activation-linked cancellation token, so a blocking provider can stop while it
is executing. Completed reports also check the activation before application.
Revoking a choice never erases edits that the user already accepted and saved.

`remove` commits inventory removal before revoking readers and deleting owned files.
Readers retain valid memory until their last clone drops, even when disk files are
removed. A cleanup failure returns a successful removal with `files_removed: false`;
it must not report that a committed inventory mutation was rolled back. An explicit
`purge_unreferenced(exact_manifest_hash, generation, cancel)` retries an unreferenced
pack's cleanup. It cannot purge an installed pack, never scans for candidates, and
never recursively deletes unexpected files. Such files remain for owner inspection.

Cancellation before commit prevents the mutation. Once the atomic inventory rename
has committed, the operation reports its committed result even if cancellation
arrives immediately afterwards. File contents are synchronized before publication;
directory synchronization is attempted where the target filesystem supports it.
Advisory locking protects cooperating owners, not an attacker with write access to
the protected store. The host must preserve directory ownership and equivalent
platform protections.

## Runtime setup and loader constraints

The ONNX adapters use optional `ort`/`ort-sys` 2.0.0-rc.10 with dynamic loading and no
runtime downloads. The host supplies an approved compatible ONNX Runtime deployment
and reviews its transitive libraries. A principal-library hash does not establish
that the entire deployment is trustworthy. Use a canonical real file path; the
adapter rejects an alias path for initial loading.

The following explicitly loads native code and belongs in trusted setup:

```bash
cargo run --features silero-onnx --example model_runtime_identity -- \
  /absolute/approved/libonnxruntime.so \
  THE_REVIEWED_64_CHARACTER_LIBRARY_SHA256
```

Record the measured actual runtime build hash in the reviewed manifest. This is
neither a signature nor a runtime installer. No model weights or runtime libraries
are bundled in the source delivery. The verification report identifies any actual
selected-model runs performed for the current artifact; historical runs do not
qualify newly reconstructed source.

Constructing a provider keeps verified bytes without loading a model session.
Analysis opens a bounded CPU session under the existing job owner, then releases
its state and cancellation observer. The process-global ONNX library remains
resident until the provider process exits. Change its deployment by draining and
restarting that owner, not by hot-swapping an in-process library.

The ONNX structural guard rejects external tensor files, training graphs, local
functions, sparse tensor surfaces and nonstandard operator domains, including
nested graphs. It is not a complete operator verifier or a native memory sandbox.
RNNoise validates the supported embedded text topology and bounded parameters.
Whisper validates its supported embedded GGML family. Expensive but structurally
valid models still require exact-model review and provider resource limits.
No custom operator library, GPU provider, automatic fallback or downloader is
introduced. Human speech retention, transcription accuracy, denoising quality and
face-crop quality remain separate evaluation tasks.
