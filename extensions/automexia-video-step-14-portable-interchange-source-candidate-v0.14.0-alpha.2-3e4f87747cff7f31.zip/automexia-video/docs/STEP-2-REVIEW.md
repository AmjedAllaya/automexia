# Step 2 review and correction log

## Scope and evidence boundary

This work extended the prior **Rust Video core**. It did not modify the terminal or repurpose the old Kubernetes prototypes. Changes are normal modules in the same crate, an optional native persistence implementation, tests and integration documentation.

Rust/Cargo/rustfmt are absent; toolchain retrieval was unavailable. Therefore all Rust source review is explicitly separate from compilation/typechecking or execution. Rust tests described below are supplied and not reported as passed. Actual executed tests run independent FFmpeg command recipes on generated encoded media.

## Implementation pass

Added strict project schema, exact ranges/timeline mapping, transactional edits, locked/manual precedence, source identity/relinking, frozen settings, project storage, project workflows and cut render plans. Fifteen initial independent cut cases passed, recorded in `reports/step2-media-pass1.json`.

Core review tightened generator ownership, preserved user overrides without erasing original generator provenance, and normalized dense cut/protection intervals before applying them to clips. Saved projects retain selected metadata, not an entire raw probe or large observation history. Pending or empty edit drafts remain saveable but cannot render.

## Boundary-focused review: a real failing media case

A new regression kept `[1/30, 2/3)` from 30 fps footage. Nineteen frames should be decodable; only eighteen were observed. The test was retained and the failures are recorded in `reports/step2-media-review-failure.json` and `reports/step2-media-pass2.json`.

Two independent issues were found:

1. Selecting after conversion to microseconds could discard a frame exactly on a rational source boundary. Selection now uses original source ticks before rescaling.
2. The timestamp mapping left zero-duration video packets in this pipeline. The last reordered frame could be marked discard by the MP4 output. Timestamp-preserving encoding now uses `setts` to retain **PTS and DTS independently**, supplying nominal duration only when the packet's duration is zero. Rewriting both timestamps to the same value would break reordered-frame semantics and is not done.

After both fixes, the boundary case has nineteen decoded frames and the sixteen-case pass succeeded (`reports/step2-media-pass3.json`). The final suite adds a 44.1 kHz sample case and a short-audio-tail case: eighteen new cases passed.

## Final source review

Further code inspection corrected or explicitly constrained:

- Preserve the legacy rotation tag while omitting descriptive/location tags.
- Reject changed selected frame-rate/color/codec/timing interpretation rather than silently using a new probe interpretation for a saved project.
- Check timestamp-shift arithmetic instead of risking integer overflow; reject timestamps outside the exact-integer range used by FFmpeg expressions.
- Reject unknown nested frame-policy fields and parent traversal in project locations.
- Reject an unknown output variant before unnecessary media operations.
- Compare and hash before/after project reads; bound JSON before accepting it.
- Make create-new collision and reviewed replacement distinct; reject media-source hardlink aliases.
- Avoid fallible post-commit work that could misreport an already published project save.
- Require explicit save-as rebasing and actual identical-content relinking.
- Keep old settings frozen and optional render-history updates outside edit revisions/digests.
- Do not ship invented legacy migrations, host command syntax, UI integration or source reordering.

Regression cases for these findings are included in Rust, but their execution remains pending a compiler. No static inspection is labelled a passing Cargo test.

## Final media regression

`reports/step2-media-final.json` records 18 passing new cut cases. `reports/step1-regression-final.json` records 19 passing retained no-edit cases. These tests check decoded frames/audio as well as metadata, including VFR timing, rational boundaries, A/V offsets, rotation, audio stream selection, 35 short cuts and flash/tone synchronization.

Python is test-only. The independent runner reads literal filter templates from Rust and compares a golden graph; it is not executing the Rust methods, storage or process adapter. The supplied Rust graph test makes that comparison against actual Rust output once run.

## Completion statement

The project/edit/storage/render features are implemented in the delivered source, and the 37 exercised media recipes pass. **Compiled Rust correctness, execution of the 163 Cargo tests, native save/reopen/render through this Rust adapter, and terminal/Windows/macOS integration remain unverified.** The package does not claim those missing results. Follow the supplied Cargo commands and CI workflow before treating it as a release.
