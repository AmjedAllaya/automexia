# Step 14A implementation review

**Scope:** reviewed, variant-local, single-source clip assembly. **Version:** 0.14.0-alpha.1/schema 10. The full Step 14 backlog remains open. Implementation statements refer to supplied source; current Rust/native execution has not been demonstrated here.

| Requirement | Implementation and review focus | Acceptance evidence still needed |
|---|---|---|
| Reorder/repeat/trim/speed | `assembly.rs`, stable occurrence IDs, transactional helpers, 64-clip and 128 retained-piece bounds | Execute Rust assembly tests |
| Authoritative existing edits | Resolved-source intersection, cuts stay removed, empty occurrences fail | Removal/protection and invalidation regressions |
| Reviewed variant state | Project/review mutators, approval reset, locks, token/revision invalidation, selected-variant readiness | Actual host controls and stale-session exercise |
| Exact clocks and audio | Rational affine mapping, exact sample partitioning, staged tempo and global video clock | Rust-generated native media on required runtime |
| Presentation and captions | Source-time effects, repeated occurrence mapping, generated-word filtering | Rust raster/subtitle tests and visual inspection |
| Preview and export | Whole-assembly preview, occurrence semantics, writer/workflow limits | Native previews, Rust export readback and editor imports |
| Persistence | Schema 10 migration; new field absent on migration and rejected in old schemas | All migration/strict JSON tests |
| Delivery and evidence | Metadata consistency, 17 reference suites, retained evidence identity recheck | Final archive checks; source integrity does not qualify behavior |

Separate assembly, rendering, presentation, preview/export and project/review inspections cover this change. Generated-media checks found a fractional-clock defect: concatenating single-frame branches collapsed timestamps because no branch duration was inferred; longer fractional branches could also accumulate rounding. The recipe now assigns one global output frame index after composition, with four- and 64-occurrence frame/PCM-impulse regressions. Development failures remain in the iteration record and are not counted as final passing tests.

The new reference suite reads shared Rust graph literals and uses real generated media, but dynamically mirrors a recipe rather than invoking Rust. Its green caption plates demonstrate source-time lifetime and repeated composition, not text shaping or subtitle-parser execution. Resampling checks allow the expected half-output-slot distance in source frames at 2×/4×; faster playback does not retain every input frame.

A second review found that very short speed-changed audio could become silence after tempo processing while output padding still satisfied sample-count checks. Selected-audio speed spans now require 100 ms in both source and output, supply 250 ms input-tail flushing before tempo, and avoid post-tempo padding. Reference assertions now inspect DC/tone signal content across 16/44.1/48 kHz as well as counts. WSOLA may still shift or lose isolated transients; no sample-for-sample fidelity or perceptual quality claim is made.

Removing output padding exposed a mixed-speed dissolve packet-size issue: each tempo branch independently had its complete sample count, but chaining them in one graph truncated the resulting audio. Normalizing branch packets with `asetnsamples=n=1024:p=0` before `acrossfade` restored the expected count without adding samples. Mixed-speed three-entry dissolve checks cover both 30fps and 30000/1001fps.

Final packaging review also found generated media directories left under the source checkout when temporary storage fell back to the current directory. Those outputs were moved outside source. The qualifier now creates external temporary storage and sets `TMPDIR`, `TEMP` and `TMP` for every child; a regression checks source cleanliness. The initial successful media run is retained as historical evidence, and final qualification was repeated on the corrected tooling source.

No new runtime dependency, model, process construction owner, required host ABI or installer was introduced. Optional AI workflows retain their qualification gates. No Rust build, model execution, host installation or editor import is inferred from Python tooling or reference media.

The authoritative fresh result is [reports/step14/verification.json](../reports/step14/verification.json), including exact counts, logs, source identity, evidence hashes and blocked prerequisites. Prior alpha.5 counts are historical only. `product_release_qualified`, `step13_complete`, `step14_complete` and `step14a_runtime_qualified` remain false until applicable evidence is available.
