# Step 2 — editable projects and reversible basic editing

**Edition:** extension core 0.2.0; project schema 1. **Scope:** the actual Video roadmap's Step 2. The user has explicitly allowed terminal-specific adapter adjustments; the core is not blocked on receiving terminal source.

This guide describes implemented Rust source. Compilation/typechecking and execution of that Rust source remain unverified in this environment. The separate FFmpeg tests exercise actual encoded media and the underlying recipes, not this API or native storage. See [VERIFICATION.md](VERIFICATION.md).

## 1. What is now in the same extension crate

The existing `VideoExtension`, `MediaHost`, cancellation, progress, probe parser, native runner and no-edit render path are retained. Step 2 adds project decisions, pure timeline calculation, a cut planner and two project-storage methods. There is no second extension, worker framework, standalone editor or application rebuild in this package.

| Roadmap requirement | Implementation | Focused Rust tests supplied |
|---|---|---|
| Versioned editable project and fingerprints | `project.rs`, `project_json.rs` | Round trips, exact values, unknown/duplicate fields, fingerprints, limits |
| Trim/keep/split/remove with common A/V mapping | `Project` edit methods, `Timeline`, `edit_render.rs` | Boundaries, ordering, overlaps, inverse mapping, actual media cuts |
| Stable identity, reason, provenance, disposition and locks | `EditOperation`, transactional edits, `replace_generated` | Preservation, explicit overrides, collisions, pending proposals |
| Frozen settings, relinking, atomic saves, explicit migrations | `FrozenRenderSettings`, `ProjectStore`, native implementation | Missing fields, changed settings, relocation, save collision/cancellation |
| No-render/dry-run and rendering saved intent | `project_workflow.rs` | No media writes, reopen/rerender, source changes, history |

## 2. Create a project from an explicitly selected source

Call `create_project(NewProjectRequest, cancellation, progress)` on the existing host job executor. It validates the request, probes the input using the existing media path, resolves explicit stream selection, stores the content fingerprint and freezes the selected settings.

The initial project keeps the full selected video duration. The source time origin is the selected video's first presentation timestamp. Source ticks, duration and requested edit boundaries are exact `Rational` values; no rounded frame count is used as the edit model.

Creating a project does not render, write a project/cache, load a model or scan unrelated media. It does inspect/hash/probe the chosen source. A source with unknown video duration is rejected for editable projects rather than substituting a potentially longer container/audio duration.

`ProjectSource` saves essential selected-stream metadata, including geometry, color and codec timing. It omits the full raw probe, sampled packets and descriptive/location tags. The legacy `rotate` tag is retained because it affects image geometry.

## 3. Specify and modify the assembly

All ranges are half-open `[start, end)` in seconds relative to the saved video origin. The first included timestamp belongs to the range; the ending timestamp does not.

`set_keep_ranges(source_id, ranges)` replaces the current assembly with explicit, chronological, non-overlapping ranges. It does not silently sort, clamp or merge a malformed request. Adjacent ranges may remain separate editable clips while the render plan coalesces them.

`trim_clip(clip_id, range)` adjusts the keep interval. `split_clip(clip_id, at)` produces a stable new clip identity and splits metadata without changing output duration. Split points must lie strictly inside the current clip.

`remove_range(source_id, range, reason)` records a reversible removal operation. Overlapping removals are unioned so time is not subtracted twice. Disabling or ignoring that operation restores its source interval wherever the base keep assembly still includes it. Restoring time previously excluded by the base trim requires adjusting the keep assembly as well.

Every mutating API uses a draft copy: apply, increment the revision with overflow checks, validate, then replace the original. Errors leave the old project intact. JSON is intentionally editable; locks are user-decision rules enforced by these APIs, not a security boundary against a caller rewriting the file.

## 4. Preserve manual decisions and future generator provenance

Each edit stores identity, source, kind, range, reason, origin, disposition, enabled state, lock state and `user_override`.

- A manual operation is an explicit user decision.
- `resolve_operation`, `change_operation_range` and enable/disable changes set `user_override`, without erasing the original generator identity/version.
- Locked operations cannot be changed until explicitly unlocked.
- `replace_generated(generator, version, proposals)` replaces only that generator's unmodified/unlocked decisions. Manual, user-overridden and locked decisions survive missing or changed proposals.
- A collision with another generator's identity is rejected. New generated proposals start `NeedsReview` even if an incoming object claims approval.
- `ProtectRange` is manual-only. It prevents automatically accepted generated cuts inside the protected interval. An explicit manual removal or manual override can still remove that time.
- Locked keep clips likewise resist generated removals; explicit manual edits remain distinct.

No detector is implemented or run by this step. These methods are the decision substrate for later analysis and review. `AutoApply` describes resolved local edit intent, not a grant of file/process permission.

## 5. Compile a shared timeline

`Project::timeline()` calculates kept segments and total duration using exact fractions. `output_to_source` and `source_to_output` use that same map. Endpoints follow the half-open convention; removed source times have no output position.

Disabled and ignored proposals do not alter the timeline. An enabled `NeedsReview` operation prevents rendering. A draft with pending proposals or a full-source removal can still be saved/inspected; it cannot silently produce a final result.

This edition renders one source in chronological order. Multiple sources and out-of-order/overlapping keep ranges are not silently flattened. The schema exposes source identities for future work without claiming multicamera or arbitrary reorder support.

## 6. Save and reopen `.amxv`

The pure core serializes/deserializes JSON and never opens files. `ProjectStore` provides two ordinary host methods: `load_project` and `save_project`. `NativeMediaHost` includes a working-source implementation of those methods; a terminal adapter may supply its own persistence owner instead.

Native saving performs these operations:

1. Validate the absolute `.amxv` location and entire bounded project.
2. Use an existing destination directory; do not create unexpected directories.
3. Reject source aliases and invalid/nonregular destinations.
4. Honor create-new or an explicit reviewed replacement stamp.
5. Write to a private temporary file on the destination filesystem with cancellation checks.
6. Flush and synchronize its complete contents.
7. Recheck the destination, then atomically publish the file.
8. Return the committed path/stamp without introducing a fallible post-commit notification that could misreport success as failure.

A dropped or failed save cleans its own temporary file. Native loading checks bounded bytes against before/after identity and rejects malformed or duplicate JSON keys. It does not grant or perform access to referenced media merely because the project loads.

**Concurrency/durability boundary:** atomic publication prevents a partial final document; reviewed target checks are not a portable compare-and-swap against an adversarial writer. Serialize writes to the same project through the existing host owner. Directory synchronization is best effort after commit. Network filesystems, power-loss guarantees and Windows/macOS behavior need native qualification. The native adapter is not an OS sandbox.

## 7. Relative paths, save-as and moved footage

Paths are resolved against the project directory, never ambient CWD. UTF-8 local references are required in this schema. Parent traversal, URL references and control characters are rejected. The native save path requires a canonical project parent when relative source references are present.

Media under the project directory uses a relative reference where possible. Media outside it remains absolute rather than introducing `..` traversal. For save-as, call `rebase_paths(old_project_file, new_project_file)` before saving; this preserves which media is referenced. Merely moving a project file changes the base of its relative paths and should be handled as relinking or save-as.

For moved media, ask the existing host to inspect the explicitly chosen new file, then call `relink`. Equal size and SHA-256 allow a new inode/mtime/location. Different bytes are rejected. Relinking neither copies media nor rewrites the edit intervals.

Before rendering, the host checks actual bytes again, and the core verifies selected timing, geometry, codec/color and frame-rate interpretation against the saved snapshot. A project reference is not a file-access capability.

## 8. Saved settings and project versions

`FrozenRenderSettings` explicitly requires frame policy, CRF, speed and thread count. There are no deserialization defaults that would adopt future global presets. `ResolvedSettings` records the selected preset name/revision and snapshot; each output variant carries its resolved render settings.

The initial `main` variant is copied from that snapshot. Rendering a saved variant uses that variant, not mutable global settings or a detector. `set_variant_settings` is an explicit project edit. This step's variants cover only implemented encoding options, not future crop/graphic compositions.

The format identity is `automexia-video`, schema version 1. Unknown future versions are rejected. No historical `.amxv` version is fabricated. `from_json_with_migrations` accepts explicitly supplied pure migration functions; the default loader has none. A host adding a real older schema must review and test its conversion. Migration tests in this package use a clearly synthetic version-0 fixture only.

## 9. Dry-run and no-render semantics

| Method | Reads media? | Writes project? | Renders delivery media? |
|---|---:|---:|---:|
| `create_project` | Yes: selected file/probe | No | No |
| `dry_run(existing_project)` | No | No | No |
| `no_render(project, path, policy)` | No media probe; destination/source-alias checks in native storage | Yes | No |
| `dry_run_and_save` | Same as no-render | Explicitly yes | No |
| `load_project` | Reads the selected project only | No | No |
| `render_project` | Yes: validate source/probe/decode | No implicit project save | Yes |

`DryRunResult` explicitly reports project/cache/final-media writes. A pure dry run describes saved intent; it does not attest that files still exist or a runtime is available. Empty/pending drafts return a reason instead of an apparently usable rendered timeline. Map your existing command flags to these methods; no installed terminal command is invented here.

## 10. Render cuts and validate the output

`render_project` derives everything from the saved project and chosen output variant. It checks draft validity before staging output, obtains the current source through the existing host, verifies it, checks runtime capabilities, creates a private output, renders, probes, fully decodes, revalidates the source and publishes.

The edited graph uses one selected source and bounded filter expressions containing only generated numeric values. Paths remain independent OS arguments, not shell or filter expressions.

**Video:** choose membership using original source ticks first. Convert to a microsecond time base only after selection, then map retained intervals to their output positions. Preserve timestamps or perform the explicitly chosen constant-frame-rate conversion. For timestamp-preserving output, `setts` retains existing PTS/DTS and supplies a nominal duration only to packets with zero duration, preventing the observed final B-frame loss.

**Audio:** subtract the same video origin, place leading samples using their timestamps, pad genuine missing leading/trailing audio with silence, trim on sample indices, and concatenate selected spans. Never independently zero audio in a way that erases a real input A/V offset. Audio before the selected video's origin is intentionally omitted.

Saved decisions stay exact. Renderable audio boundaries are quantized upward to sample indices; video-only duration uses microseconds, and video remains discrete frames. The plan exposes requested and effective segment data. This is not a promise of subframe video rendering or bit-identical encodes across toolchains. The input's known nominal frame duration is only the fallback for zero-duration packets; it is not permission to force a VFR source to CFR.

Output validation checks streams, geometry, rotation, SAR, supported color, sample rate/layout and duration/start tolerances, followed by full decoding. It is not a content-level lip-sync guarantee for all cameras. Boundary previews, micro-fades and listening-quality work are later steps; this edition makes basic hard cuts.

## 11. Record render provenance explicitly

`ProjectRenderResult` contains the result, mathematical timeline, project revision, decision digest and selected variant. Its `history()` creates a record with the actual runtime identity and output path.

`record_render` keeps at most 64 records and does not change the edit revision/digest. A render does not silently save the project afterwards. This avoids treating a failed history save as though a completed output failed. The caller may save the amended project with the last reviewed stamp.

A decision digest is a local integrity marker, not a signature, permission token or reproducibility guarantee for encoded bytes.

## 12. Tests and remaining qualification

The source includes 73 new core cases and 16 new native-project cases, in addition to the prior 60 + 14. They are **supplied, not executed here**. They cover serialization, strict schemas, range math, manual/lock precedence, transactional failures, source changes, relinking, saves, no-render and actual-core rerenders.

Executed checks are the 18 new independent cut recipes and 19 previous independent media recipes. See [the detailed review](STEP-2-REVIEW.md) and machine-readable reports. Run Cargo and the native project suite in a Rust-enabled environment before calling this compiled/functional Rust integration.
