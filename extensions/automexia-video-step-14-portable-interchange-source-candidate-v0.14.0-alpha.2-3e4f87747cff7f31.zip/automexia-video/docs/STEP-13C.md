# Step 13C — explicit local speech enhancement

The alpha.5 rebuild includes the provider-neutral `SpeechEnhancer` contract and a concrete `NativeRnnoiseEnhancer` using the existing host's typed FFmpeg audio executor. No model or native executable is bundled or discovered automatically. Traditional Step-5 treatment and `Preserve` remain available independently.

## Explicit selection and processing

Learned enhancement requires `speech_only_confirmed=true`. Construct an RNNoise provider with a `VerifiedModelPack`, its matching live `ModelActivation`, and the already configured media host. The standard RNNoise text topology is validated before entering FFmpeg: 42→24 input dense, 24→24 VAD GRU, 90→48 noise GRU, 114→96 denoise GRU, 96→22 gain dense, and 24→1 VAD dense. Unsupported topologies, malformed arrays, out-of-range weights, trailing data and incomplete files are rejected.

The selected manifest uses contract `rnnoise-48k-frame480-v1`, preprocessing `selected-layout-resample48k-delay480-v1`, and runtime adapter `ffmpeg-arnndn`. Its `runtime.artifact_sha256` must match the configured FFmpeg executable; `runtime.build_info_sha256` must be the SHA-256 of the exact first FFmpeg version line, without a trailing newline. The provider admits the FFmpeg 7.1 release family for the compensated sample-delay contract. Tool changes and revoked activations stop the operation.

The provider processes each channel of the selected layout at 48 kHz, compensates the 480-sample filter delay using trailing padding and leading trimming, converts back to the selected source rate, and writes precisely the accepted source sample count to PCM24 WAV. Strength is an explicit wet/dry mix: Gentle 0.35, Balanced 0.65, Strong 1.0. No analysis downmix or automatic volume normalization occurs in this provider.

Model bytes are copied into a private operation-owned directory under the host's staging area. The lease remains alive throughout native execution and verification. Source, model, executable identity, activation, cancellation, output byte bounds and the operation deadline are checked. The extension creates no second process executor or background scheduler.

## Publication and saved behavior

`enhance_voice` returns a candidate enhanced stem and a `VoiceEnhancement` receipt. It does not apply or save the setting. The caller explicitly applies the returned setting using `Project::set_voice_enhancement` and may then save the project.

Before publication, the workflow checks the exact model/provider identity, selected stream, sample rate, layout, source sample count, zero uncompensated delay, exact decoded WAV duration, zero output origin, complete decode and immutable content hash. Receipt construction and project-relative path validation happen before the host's atomic commit. Cancellation that arrives after a successful commit cannot turn the completed output into a reported failure.

The receipt records the original source origin; the WAV itself starts at project time zero. Final renders, proposed review proxies and audio stems use that zero-origin signal even when traditional cleanup and volume automation are disabled. They retain source-time cut coordinates and do not subtract the original container origin a second time. Untreated review proxies continue to use the original recording. Missing or changed accepted stems block rendering.

Audio-only planning checks audio capabilities independently of the video publishing profile. An explicit PCM stem or voice measurement can therefore use selected audio from an HDR or 10-bit recording without demanding an SDR video conversion, graphics approval, video encoder or MP4 timing capability. This does not by itself authorize an HDR video render.

Schema-8 enhancement receipts remain readable: their absent `source_origin` is treated as legacy provenance. New receipts always record it. The pinned source bytes, selected stream, layout, exact sample count and compensated delay remain mandatory for both old and new receipts. Save-As rebases the stem reference; persistent fingerprints use content size and SHA-256, not a temporary staging inode.

## Verification and qualification limits

`tests/enhancement.rs` covers receipt and source validation, callback/provider failure, exact sample checks and the publication commit boundary. `tests/native_enhancement.rs` exercises enhancement-only final/proxy/stem routing, a nonzero source origin, HDR audio-only extraction, actual RNNoise processing with generated zero weights, and activation revocation. `tests/voice.rs` includes bit-exact project persistence and an audio-only capability regression.

`tests/media/run_enhancement_checks.py` independently checks PCM transport, native RNNoise text parsing, the delayed dry impulse, compensated impulse position, special-character model paths, stereo layout and exact sample counts at 16, 44.1 and 48 kHz. Generated zero weights exercise parser and DSP plumbing; they are not a trained speech model or evidence of perceptual improvement. Consult the delivered verification report for which checks actually ran in the rebuild environment.

Before enabling a trained enhancer by default, evaluate the exact selected weights/runtime on legally usable recorded speech with noise, breaths, fricatives, transients, music bleed, clipping and representative accents/languages. Record blind preference and speech damage alongside resource and cancellation measurements. Code implementation and synthetic transport checks do not replace that evaluation.
