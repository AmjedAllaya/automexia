# Release qualification — Step 14B

This procedure measures the supplied source. It does not grant release authority or turn missing prerequisites into passing checks. The current continuation has executed Python tooling and independent recipes; **Rust compilation, native workflow execution and selected-model inference remain blocked**.

## Prepare the build

Use the declared Rust 1.85 minimum or a newer explicitly tested toolchain, approved FFmpeg/ffprobe 7.1 or newer, Python 3.11+, Pillow for presentation fixtures and a selected font. Install the test-only `espeak` executable to exercise generated-speech fixture cases. It is not an extension runtime dependency.

The input and this continuation have no Cargo.lock because Cargo was unavailable. Generate the lockfile on the first connected build, inspect the resolution and notices, and retain it before qualification:

```bash
cargo generate-lockfile
cargo metadata --locked --all-features --format-version 1
```

Set `FFMPEG`, `FFPROBE` and `VIDEO_TEST_FONT` to approved absolute files. Qualify the exact selected media binary and model preprocessing contracts; do not change the native version requirement merely because an older installed FFmpeg can execute some recipes.

## Run one fresh automated record

Output must be outside the source checkout and must not already exist. Child Cargo targets and all three child temporary-directory variables (`TMPDIR`, `TEMP`, `TMP`) point under that external output. A fixture cannot fall back to writing temporary media into the source checkout.

```bash
mkdir -p ../video-qualification
python3 -B tools/qualify_release.py --suite all \
  --output ../video-qualification/run-1 --timeout 1800
```

| Layer | Executed by the runner | Interpretation |
|---|---|---|
| Core / graphics / native | Separate locked Cargo test configurations | Configurations overlap; do not add their counts as unique tests |
| Optional-feature coverage | All-feature/all-target check and all-feature library tests | Compilation and library execution do not prove selected-model inference |
| Selected Silero | Explicit manifest/weights/notices/runtime test target | Missing asset configuration produces BLOCKED |
| Selected UltraFace | Explicit ignored face qualification target and RGB fixture | Fixture detector tests are not learned-model execution |
| Selected whisper.cpp | Explicit `transcript_smoke` example | Actual executable/weights/input required |
| Independent recipes | 19 Python media/reference suites | Some inspect source or reference geometry; no Rust execution is implied |
| Interchange integration | Rust fixture generation then independent legacy/modern XML and ZIP64 archive readback | Does not prove a target graphical editor imported the result |
| Package/qualification/architecture tools | Python regressions and dependency/process guards | Source integrity and tooling evidence only |
| Cargo packaging | `cargo package --locked --allow-dirty` | Not an Automexia installer or supported ABI |

The runner binds executable source, tests, fixtures, Cargo configuration, CI and release/architecture policies before and after the run. A changed source tree invalidates a passing run. Reports/docs are outputs and do not rewrite test evidence. Before completing a run, the runner reopens every recorded log and media report and verifies the saved SHA-256. Repeat that evidence check after copying reports into the source delivery.

Reports reject duplicate keys, nonfinite constants and overflowed JSON floats. Case totals must match actual case statuses. Unavailable espeak or credential switching is explicit BLOCKED; a failed command, timeout or assertion remains failure. Unavailable RSS is null. Tests must run without Python `-O`.

## Modern XML and portable archive evidence

For the optional official schema layer, obtain the FCPXML 1.10 DTD from [Apple](https://developer.apple.com/documentation/professional-video-applications/document-type-definition), select the local file with `AMX_FCPXML_DTD`, and retain its identity with the run. The suite uses Python `lxml` for local/external DTD validation; missing dependencies or the selected official DTD are explicit blockers. The authored restricted DTD remains available in the project. No DTD is downloaded by the runner.

When Cargo and a reviewed lockfile are available, `interchange_fixture` generates actual OTIO/legacy XML/modern FCPXML/EDL documents. `bundle_fixture` generates source OTIO, source FCPXML and explicit video-plus-stem baked FCPXML archives from the independent generated 30 fps fixture. All outputs must reach `Published`; each is then read independently. The bundle reader verifies member paths, CRC, SHA-256/size manifest, actual relative media URLs and complete membership. Missing Rust blocks these three integration layers separately.

The ZIP64 reference suite uses sparse files to check offsets/sizes past 4 GiB without copying gigabytes. It does not qualify CRC across those sparse payloads or Rust large-file execution. Its ordinary generated-media archive case does compare decoded media before/after copying. Repeated reference cases in an actual readback report are not additional unique tests. These checks still require real target-editor import and OS/native testing before qualification.

## Supply selected model assets

Silero tests require `VIDEO_MODEL_MANIFEST`, `VIDEO_MODEL_WEIGHTS`, `VIDEO_MODEL_NOTICES`, `VIDEO_MODEL_MANIFEST_SHA256` and `VIDEO_ORT_LIBRARY`. See [model packs](MODEL-PACKS.md).

UltraFace tests require `FACE_MODEL_MANIFEST`, `FACE_MODEL_WEIGHTS`, `FACE_MODEL_NOTICES`, `FACE_EXPECTED_MANIFEST_SHA256`, `ORT_DYLIB_PATH`, `FACE_FIXTURE_RGB`, `FACE_FIXTURE_WIDTH` and `FACE_FIXTURE_HEIGHT`. See [the provider guide](FACE-ONNX.md).

The whisper.cpp example requires `AMXV_WHISPER_MANIFEST`, `AMXV_WHISPER_WEIGHTS`, `AMXV_WHISPER_NOTICES`, `AMXV_WHISPER_MANIFEST_SHA256`, `AMXV_WHISPER_EXECUTABLE`, `AMXV_WHISPER_BUILD_INFO`, `AMXV_TRANSCRIPT_INPUT`, `AMXV_FFMPEG` and `AMXV_FFPROBE`. The runner supplies a fresh `AMXV_TRANSCRIPT_OUTPUT` path. See [transcription](TRANSCRIPTION.md).

No tool here downloads model assets, chooses licenses or approves production activation. Expected digests must come from the component owner's reviewed selection, not be trusted merely because they appear beside downloaded bytes.

## Dependency and source delivery evidence

After successful locked resolution:

```bash
python3 -B tools/dependency_inventory.py \
  --output ../video-qualification/dependencies.json
```

The inventory records actual all-feature metadata, lockfile hash, dependency versions, checksums and declared license metadata. It refuses absent/changed lockfiles and unsuccessful Cargo execution; unknown license metadata stays unknown. Metadata is not legal approval.

Build and reverify the ZIP using [the delivery procedure](DELIVERY.md). A final source ZIP includes source, documentation, tests and measured reports. External weights, tools, fonts and test recordings remain outside it.

## External acceptance still required

Actual Automexia discovery/action registration, install/update/disable/remove and preview UI must be tested in its real repository. Test native filesystem/process/cancellation behavior on each supported OS. Import actual generated exports into each claimed editor/version. Evaluate representative, consented camera/speech media, speech loss, face crop stability and visual/listening quality. Measure host interaction and resource budgets. Complete owner licensing/distribution decisions.

Keep `product_release_qualified`, `learned_inference_qualified` `step13_complete`, `step14_complete` and `step14a_runtime_qualified`, `step14b_runtime_qualified`, `portable_bundle_native_qualified` and `modern_fcpxml_import_qualified` false until the applicable evidence exists. Synthetic fixtures, compilation-only jobs and this source archive cannot satisfy those gates.
