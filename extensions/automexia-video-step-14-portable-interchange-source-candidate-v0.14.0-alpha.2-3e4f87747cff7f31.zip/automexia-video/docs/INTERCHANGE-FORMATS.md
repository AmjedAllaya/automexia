# Interchange format contract and reference sources

This document records the implemented subset, not a guarantee of interoperability with every editor. [Step 10](STEP-10.md) contains the integration and qualification procedure.

## OTIO JSON

The serializer uses Timeline.1, Stack.1, Track.1, Clip.2 with `media_references`/`DEFAULT_MEDIA`, ExternalReference.1, RationalTime.1, TimeRange.1, Gap.1, and the legacy Marker.2 color convention. It does not claim to emit the newest possible version of every OTIO schema. Video is one chronological track; selected mono/stereo audio is a second track, with exact rational gaps where needed.

The rate is stored as the OTIO numeric representation; exact Automexia rational rate and original project intent are retained in namespaced metadata. Numerators/denominators that exceed exact binary64 integer representation are rejected. Fractional-rate arithmetic stays rational before serialization; no cross-editor floating-point identity is promised.

Source timecode offset is added to each referenced source range and available range. Global start time is the record timecode offset. Track-local marker positions remain local to the sequence. Stream indices and link-group identities are namespaced metadata and need importer support. Relative target URLs, when selected, are relative to the exported file.

## Modern Final Cut Pro XML 1.10

`InterchangeFormat::FcpXml` emits `<fcpxml version="1.10">`, a resource table and a project/sequence/spine using clip, video and connected audio components. Source and record timecode remain separate. Exact seconds use signed 64-bit numerators and 32-bit denominators; unsupported wire clocks block. Source pixel aspect ratio is preserved, and no color space is guessed. This bounded cuts profile supports normal-speed editable source occurrences and explicitly flattened bakes for otherwise unsupported effects.

Media references use `media-rep kind="original-media"`. Local absolute URLs and relative URLs are supported; bundle URLs point into the adjacent `Media/` directory. Selected source audio shares its resource identity, separate PCM stems have their own asset, and source gaps/tails become component timing. Audio rate labels are restricted to the rates represented by FCPXML 1.10. Marker positions lie on the sequence frame grid. Native project markers have a one-frame duration; original mapped marker ranges, IDs, names and comments remain in `org.automexia.marker-ranges` metadata and the compatibility report. Editors may discard custom metadata.

The source includes an authored restricted DTD profile. The reference suite can additionally validate against an explicitly supplied official Apple 1.10 DTD (`AMX_FCPXML_DTD`); Apple's DTD is not redistributed. Schema validity and independent clock checks do not establish successful Final Cut Pro import. See [fixture instructions](../tests/fcpxml_fixtures/README.md).

## Portable OTIO/FCPXML archives

`BundleRequest` selects a single `.zip` destination and explicit source/bake modes. The stored ZIP64 archive includes `timeline.otio` or `timeline.fcpxml`, `compatibility.json`, `manifest.json`, and complete referenced media under SHA-256 names in `Media/`. Extract all members together before importing. Original identities and paths remain in provenance metadata. The archive's manifest describes every other member; the returned full archive hash protects the complete artifact. The limits and private publication contract are in [Step 14B](STEP-14B.md).

## Legacy Final Cut Pro XML

The root is `xmeml version="5"`, not `fcpxml`. It includes sequence rate/duration/timecode, video and mono/stereo audio tracks, file definitions, source-track indices, clipitem links, markers, and an escaped report in logging information. All generated IDs come from counters, not unescaped user input.

Source clip `<in>`/`<out>` are file-relative frame counts. `<start>`/`<end>` are sequence-relative. File timecode and sequence timecode are separately represented. Known fractional rates use the nominal `<timebase>` and `<ntsc>TRUE</ntsc>`. Point-marker `<out>` uses -1. Original audio bit depth is omitted rather than guessed.

This profile requires square pixels, progressive footage, exact frame-aligned ranges and absolute local file URLs. Sub-frame audio gaps are rejected. It does not synthesize editor-specific color/audio plugins, multicam constructs or transitions absent from the existing model.

## CMX3600 EDL

The bounded cuts-only profile uses `TITLE`, `FCM`, numbered events, eight-character deterministic reels, V/A/AA track codes and four inclusive-start/exclusive-end timecode labels. Events are limited to 999 total; nominal rate is at most 30 and timecode wrap is rejected. Source and record offsets are explicit. Drop-frame intent is in FCM; event separators use the ordinary EDL colon representation.

Media URLs, marker definitions and compatibility details are ASCII-escaped comments. These preserve information for inspection but do not promise automatic relink or marker import by third-party software. A complete JSON report is percent-encoded and split across `* AMX REPORT:` lines, reassembled before decoding. Track rate is available in that report; a legacy editor may ask the operator to set its project rate.

Unsupported effects block the original-media export. Explicit bakes may be referenced as flattened media; that is not an editable recreation of the original effect graph.

## Primary format references consulted

These references inform the serializers; no specification pages or SDK binaries are repackaged.

- OpenTimelineIO file-format specification: https://opentimelineio.readthedocs.io/en/latest/tutorials/otio-file-format-specification.html
- OpenTimelineIO serialized schema: https://opentimelineio.readthedocs.io/en/latest/tutorials/otio-serialized-schema.html
- OpenTimelineIO adapter overview (versioned): https://opentimelineio.readthedocs.io/en/v0.16.0/tutorials/adapters.html
- Apple legacy Final Cut Pro XML elements: https://developer.apple.com/library/archive/documentation/AppleApplications/Reference/FinalCutPro_XML/Elements/Elements.html
- Apple legacy XML application examples: https://developer.apple.com/library/archive/documentation/AppleApplications/Reference/FinalCutPro_XML/Applications/Applications.html

The CMX3600 implementation is deliberately narrower than all editor/vendor EDL extensions. Independent fixtures and readers test that subset. OTIO SDK import is optional and explicitly reported when unavailable; no Resolve/Premiere/Final Cut application has been run here.

Modern FCPXML references: [Apple DTD](https://developer.apple.com/documentation/professional-video-applications/document-type-definition), [media references](https://developer.apple.com/documentation/professional-video-applications/media-rep), [timing](https://developer.apple.com/documentation/professional-video-applications/timing-attributes), [markers and metadata](https://developer.apple.com/documentation/professional-video-applications/associating-ratings-keywords-markers-and-metadata-with-media). ZIP64 layout follows [PKWARE APPNOTE](https://pkware.cachefly.net/webdocs/casestudies/APPNOTE.TXT).
