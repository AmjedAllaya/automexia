# Step 5 — traditional voice and audio cleanup

**Crate:** `automexia-video` 0.5.0. **Scope:** the Video roadmap's Step 5, not a terminal architecture milestone. **Status:** Rust implementation delivered; independent media recipes exercised; Rust compilation/test execution and native host qualification remain unverified.

[Roadmap](video-roadmap.md#step-5--add-traditional-voice-and-audio-cleanup) · [Source](../src/voice.rs) · [Render plans](../src/voice_render.rs) · [Workflows](../src/voice_workflow.rs) · [Review findings](STEP-5-REVIEW.md) · [Verification](VERIFICATION.md)

## 1. Requirement-to-implementation map

| Roadmap responsibility | Concrete implementation | Verification boundary |
|---|---|---|
| Audio preflight, clipping/DC/rumble/imbalance/hum | `PcmPreflight`, `AudioPreflight`, `VoiceReport` | Rust tests supplied. Independent signal/filter tests executed; they do not execute the accumulator. |
| Global and per-stage auto/on/off | `VoiceSettings`, `resolve_stages`, source-bound `VoiceCleanup` | Validation and mode tests supplied; no model or speech classifier. |
| DC/rumble/hum/noise → edit assembly → EQ/de-ess/compression | Typed filter templates plus the existing audio timeline builder | Isolated filters and combined edited media exercised. |
| Measured loudness and true-peak control | First pass over the exact cleaned/assembled audio; constant-gain decision; decoded-output measurement and bounded correction | Actual FFmpeg level/peak, delay and synchronization checks executed. |
| Preserve selected channel layout | Per-channel analysis; no `-ac 1`/implicit downmix; final rate/layout assertions | Mono, stereo, quad, 5.1, 5.1(side), 7.1 recipe checks. Other accepted layouts need additional media qualification. |
| Editable settings, bypass, A/B and stems | Project schema 3; explicit apply/reconfigure/clear; original/proposed previews; PCM24 WAV export | Project/review/native tests supplied; recipe output tests executed. |
| Perceptual qualification | Test scenarios and original/processed sample supplied | Human listening and human-recorded release-corpus assessment have **not** been performed. |

## 2. One ordinary extension, no new platform

All work stays in the existing crate. Three new internal modules own settings/statistics, typed audio plans, and workflow coordination. They reuse `Project`, `ReviewSession`, `RenderPlan`, `MediaHost`, `OutputLease`, the existing native process reader, and `ProjectStore`.

No audio-only replacement product, plugin SDK, browser UI, new scheduler, permanent daemon, ONNX runtime, learned model, network download, or automatic tool installer is added. Test-only Python invokes FFmpeg to exercise command recipes independently; it is not a runtime dependency of the extension.

## 3. Preflight: inspect, do not mutate

`VideoExtension::analyze_voice` checks the project, explicit source identity, selected audio, settings, duration and runtime capabilities. It requests only that stream as bounded interleaved little-endian f32 samples. No downmix or normalization occurs during that request. Audio outside the selected video-origin interval is excluded.

The accumulator retains channel statistics, a fixed level histogram, a small set of tone accumulators and one Hann window—not an entire recording. It calculates RMS and peak levels, mean/DC offset, near-full-scale counts and longest runs, low-band energy fraction, lower-decile window RMS, persistent fundamental/harmonic observations and an inter-channel level difference. Windows are 200 ms. Partial final windows contribute whole-recording statistics, but not fabricated complete-window tone evidence.

A separate `loudnorm` measurement describes the unedited source interval. Its **input** loudness/true-peak fields are observations. The filter's own normalized output is discarded. This source observation is not reused as the render gain after edits.

Cancellation, invalid PCM, truncated channel frames, overflow, malformed meter output, source change or decoder failure rejects the report. A failed accumulator is poisoned, so a valid prefix cannot later be labeled a successful scan.

Analysis creates no project/cache/media file. Its returned report is bound to the exact project decision digest; applying it after another decision change returns `StaleReview`.

### What these observations do not establish

Energy and spectral concentration do not prove speech, noise type, sibilance, clipping recovery or musical intent. The low-band statistic includes DC and legitimate bass; a hum candidate can be intentional sound. Quiet-window RMS is not a calibrated noise-floor or SNR estimator. Near-full-scale samples are warning evidence, not permission to claim declipping.

## 4. Explicit controls and conservative defaults

Each stage has `off`, `auto`, `on`, plus an overall mode. `off` globally resolves an inactive profile without source processing. Per-stage Off remains Off even when the overall mode is On. Overall On forces most Auto stages; it is an explicit treatment request, not evidence that they improve the recording. Hum still needs an explicit 50/60 Hz choice or an unambiguous candidate.

Default content is `Unknown`. The user may explicitly declare `Dialogue` or `MixedMusic`. Unknown/MixedMusic Auto does not enable voice-specific rumble, hum, denoise, compression or loudness treatment. A demonstrable DC offset can still receive technical correction. No file-name inference occurs.

Auto hum requires at least ten complete windows, a persistent fundamental plus harmonic in at least 70% of windows on a channel, and no conflicting 50/60 candidate. Auto denoising additionally needs an affirmative `noise_confirmed` choice and a bounded observed quiet-window level. It does not remove quiet speech on the strength of low amplitude alone.

Auto compression uses a conservative peak-to-RMS indicator on declared dialogue; it is not a learned speech model. EQ and de-essing default Off. Silence/very low signal bypasses stages rather than requesting infinite gain. Actual edited-signal measurements can bypass unnecessary gain/limiting even when their stage is enabled.

### Presets

| Setting | Clean | Social | Podcast |
|---|---:|---:|---:|
| Integrated loudness target | −18 LUFS | −16 LUFS | −19 LUFS |
| Compressor ratio when used | 2:1 | 2:1 | 1.8:1 |
| True-peak ceiling | −1.5 dBTP | −1.5 dBTP | −1.5 dBTP |
| Initial codec headroom | 0.7 dB | 0.7 dB | 0.7 dB |
| Maximum requested boost | 12 dB | 12 dB | 12 dB |
| Maximum attenuation | 24 dB | 24 dB | 24 dB |
| Rumble high-pass frequency | 70 Hz | 70 Hz | 70 Hz |
| Optional denoise reduction | 6 dB | 6 dB | 6 dB |
| EQ / de-essing | Off | Off | Off |

These are editorial defaults, not externally mandated platform targets or measured optimal settings. Every field is saved explicitly; a changed global preset cannot silently alter an existing project.

## 5. Processing order

The accepted settings compile into this order:

```text
Selected stream decode
    → optional DC high-pass
    → optional rumble high-pass
    → selected/evidence-backed fundamental and harmonic notches
    → optional traditional FFT denoise, with qualified delay compensation
    → existing common-origin audio/video edit assembly and pause-join fades
    → optional restrained presence EQ
    → optional de-essing
    → optional linked compression
    → measured constant gain
    → optional oversampled peak limiting
    → original sample rate and channel layout
    → exact edited sample length
    → AAC video output or explicit PCM24 WAV stem
```

DC uses a 10 Hz one-pole high-pass. Rumble uses a bounded two-pole high-pass. Hum uses one to three narrow notch frequencies with bounded Q. Denoising uses `afftdn` with explicit reduction/noise-floor settings and no adaptive noise-tracking toggle. EQ is bounded ±3 dB at 3 kHz. De-essing is optional and low-intensity; the filter cannot know whether high-frequency content is intentional. Compression has linked detection, explicit attack/release, bounded ratio and unity makeup. Channel imbalance is reported, not silently corrected.

This changes signal amplitude/shape, not the edit timeline. Full source audio is not retained in memory, and no stem is automatically created as an intermediate.

## 6. Denoiser delay: qualify, flush and compensate

An actual FFmpeg experiment found about **25 ms** of latency from the uncompensated `afftdn` path at 48 kHz. In FFmpeg 7.1, the hop is `floor(sample_rate / 80)` and the algorithmic delay is two hops. The implementation pads that many samples, discards the corresponding delayed samples, and subtracts the same duration from timestamps without resetting the original source origin.

The pad is necessary: trimming only the initial delay would discard real sound at the end. Tests exercise onset, final 10 ms, clips shorter than the delay, selected-stream offsets and synchronization after cuts. Independent onset-threshold measurements stayed within two samples at 8,000, 44,100, 48,000 and 96,000 Hz. This is not a claim that all DSP phase changes are sample-identical.

**This timing contract is admitted only for FFmpeg 7.1 release strings.** A different or custom build still requires qualification. On an unqualified version, disable denoise explicitly or qualify and update the timing adapter; do not guess latency or silently substitute a neural denoiser.

Official reference: [FFmpeg 7.1 `af_afftdn.c`](https://ffmpeg.org/doxygen/7.1/af__afftdn_8c_source.html). Filter interface reference: [FFmpeg filters](https://ffmpeg.org/ffmpeg-filters.html). The measured test runtime is recorded in the result JSON.

## 7. Loudness: measure the edited signal, then render

A processing plan cannot render final media before its gain pass is resolved. `prepare_voice` measures the exact cleanup + accepted assembly + post-edit EQ/dynamics chain. Changing cuts means a new measurement; it does not reuse a pre-cut measurement or rerun every edit generator.

The desired gain is target minus measured integrated loudness. The implementation limits boost/attenuation and available peak headroom, then applies a **constant** gain. It does not silently fall back to dynamic loudness normalization. Auto bypasses gain within 0.5 LU of target. Gated silence or an unmeasurably short signal receives no invented normalization boost.

When peak protection is enabled, the limiter uses oversampling to 192 kHz, explicit ceiling/headroom, disabled automatic makeup (`level=0`), lookahead compensation (`latency=1`), and conversion back to the original rate. The accepted signal is padded/trimmed only to its existing effective edited length.

### Validate the encoded file, not just the pre-encode signal

AAC reconstruction can overshoot a pre-encode limit. The first new media pass detected an encoded peak around −1.10 dBTP despite a −1.5 dBTP target and initial headroom. The final workflow decodes/meters the private output before publication.

If it exceeds the requested ceiling plus the explicit 0.05 dB measurement tolerance, the gain is reduced by the excess plus 0.3 dB and the same private output is rerendered. At most **two correction rerenders** are allowed, within the accepted maximum attenuation. No further compression is invented. Exhausted correction, invalid measurements or missing capabilities cause failure and cleanup, not publication of the previous bytes.

Final reports expose actual LUFS/true peak, applied gain, whether the limiter ran, corrections and warnings. A target miss beyond 1 LU is explicitly reported; gain bounds and peak protection take precedence over hitting a loudness number. Peak limits are not enforced when the user explicitly disables that protection. Encoded results can differ across runtimes.

## 8. Projects, review and bypass

`VoiceReport::apply` accepts a source/stream-bound profile into the project. It is a user/host decision; analysis alone is not approval or persistence. `ReviewSession::apply_voice_report` commits the same profile transactionally, marks review dirty and invalidates obsolete preview requests. `VoiceCleanup::reconfigure` reuses recorded observations for an explicit settings adjustment; call `Project::set_voice_cleanup` to commit it. Clear the profile with `None` for full treatment bypass.

Settings, resolved stages and compact preflight evidence live in **`.amxv` schema 3**. No PCM or per-frame signal buffer is stored. Known schema 2 files migrate with no voice profile; schema 1 follows its earlier no-pause migration first. A schema-2 document carrying schema-3 treatment fields is rejected. Unknown future versions/fields are rejected. Older readers cannot open newly saved schema-3 documents.

Saved stage choices are checked against their versioned settings/evidence; they are not reclassified by a new global preset. Render gain is intentionally transient and measured against the current assembly. This preserves edit intent while allowing legitimate recomputation after cuts.

A/B previews use unprocessed original audio on the Before side and accepted cleanup on the Proposed side. The Proposed side inherits gain from the complete proposed timeline, not its short excerpt. The encoded preview still gets peak validation and may need its own disclosed correction. Disabling cleanup invalidates the old decision digest; no stale processed preview should represent bypass mode.

Bypass means **no cleanup filters**. It does not mean bit-identical AAC through an existing lossy transcode. Source files always remain separate from outputs. Rejected/pending cut decisions retain their existing behavior and are not approved by audio analysis.

## 9. Explicit enhanced-audio stem

`export_audio_stem` writes one requested **PCM24 WAV** with the selected original rate/layout and accepted timeline. It uses the same gain/filter logic as video rendering, validates stream metadata and exact sample duration, fully decodes, meters and publishes through `OutputLease`. RF64 automatic mode is requested for large WAV output.

Create-new is the default. Existing-target replacement still requires the host's reviewed identity. A source alias, invalid destination, missing codec/filter, cancellation or failed validation prevents publication. The stem is not an implicitly generated large intermediate or a completed editor-interchange exporter.

Current stem export works from the existing qualified Video project profile. It is not a new audio-only importer or an arbitrary multichannel mastering application. Its setup currently shares the H.264/AAC project planner and therefore still requires those capabilities even when the final requested file is WAV.

## 10. Adapter changes

Five existing required `MediaHost` methods and the two `ProjectStore` signatures remain unchanged. Two optional methods have default errors, so old implementations can be rebuilt without immediately implementing audio processing:

```rust
fn stream_voice_pcm(
    &self,
    request: &VoiceScan,
    cancel: &Cancellation,
    sink: &mut PcmSink<'_>,
) -> Result<()>;

fn run_audio(
    &self,
    task: &AudioTask,
    cancel: &Cancellation,
    progress: &mut ProgressSink<'_>,
) -> Result<ToolOutput>;
```

`VoiceScan` supplies validated selected-stream decode arguments. `AudioTask` is a closed set: measure a plan, measure a file, render a stem, probe a stem, validate a stem. There is no arbitrary shell-string or executable-path capability. `run_audio` returns the bounded meter JSON diagnostics as `ToolOutput.stdout` for measurement tasks, not ordinary FFmpeg progress text.

The native adapter implements both with the existing approved executable identities, separate arguments, bounded pipe reader and output leases. Add `Stage::MeasuringAudio` to exhaustive progress handlers. Existing Rust struct literals for `ResolvedSettings` need the new optional `voice_cleanup` field.

Execute these blocking functions on the host's existing job executor. Host authority still decides which source/output paths may be accessed and when a native process may run. A typed request or digest is not an access grant. The local adapter is not an OS sandbox.

## 11. Resource and failure limits

| Area | Bound / behavior |
|---|---|
| Analysis duration | Default 21,600 s; configurable hard maximum 86,400 s |
| Audio format for this stage | Native selected rate 7,350–96,000 Hz; at most eight channels; explicit recognized layout for multichannel |
| PCM callback | At most 1 MiB per supplied chunk; internally cancel-checked in 8 KiB blocks |
| Retained analysis state | One 200 ms window, per-channel fixed accumulators/histogram and less than one pending interleaved frame |
| Loudness diagnostic result | At most 64 KiB, strict required numeric fields, no NaN acceptance |
| Filter graph / argv | Existing 24 KiB audio graph and 30 KiB edited/audio argument bounds |
| Native child lifetime | Task timeout, limited further by native runner settings; parent cancellation also applies |
| Encoded peak retries | At most two rerenders, within accepted attenuation |
| Output files | Existing per-host size policy and source/destination checks |

Deadlines are per task, **not a promise that an entire multi-pass workflow completes within one task timeout**. The host should apply a total job deadline through parent cancellation where required. No memory/RSS or CPU performance guarantee is inferred from a streaming input bound. Rust objects, FFT/codec state, decoder buffers and outputs have separate costs.

## 12. Reproduce and qualify

```bash
cargo test --no-default-features
FFMPEG=/usr/bin/ffmpeg FFPROBE=/usr/bin/ffprobe cargo test --features native
python3 -B tests/media/run_voice_checks.py --output /tmp/video-audio.json
```

The last command is an independent recipe suite and requires `espeak` for a clearly labeled synthetic speech fixture. It is not a substitute for the Cargo commands. The crate adds no runtime Python or speech-synthesizer dependency.

The current execution environment has no Rust compiler. **68 new core and 19 new native Rust tests are supplied but not run**, for 426 total supplied tests. Forty-four new audio recipes and all ninety prior recipes passed. No user terminal was modified or installed, no native UI/player integration tested, and no blind/human listening campaign performed.

Before release: build/typecheck and run the supplied Rust tests; exercise native save/review/runner and failure cleanup; listen to representative recorded quiet/noisy/clipped voices, breaths, music beds and multi-speaker/channel mixes; verify supported OS/runtimes and long-media resource limits. Automated signal tests do not establish universal perceptual improvement.
