# Step 10 finalization — 0.10.1

**Date:** 11 September 2026. Input: the saved Step 10 0.10.0 archive,
SHA-256 `6621a130ab406a5fcf6c67e278296f0f0422757463c8c55faac66002580c358d`.
This is a patch of recovered source, not a recreation from missing files.

## Source review fixes

1. The FCP7 writer unconditionally put `<groupindex>1</groupindex>` into every
   link, including video links. Apple's legacy XML element catalogue explicitly
   reserves that field for audio links. The Rust writer now emits it only for
   audio links. The independent reference generator and packaged sample were
   corrected too. The independent reader rejects this invalid video-link field.
2. `ExportDocument::validate_destination` previously checked only local-path
   shape and extension. A prepared document could be passed directly to the
   native publication adapter at a different path, invalidating relative media
   URLs and embedded request provenance. A private destination field now binds
   the bytes to the requested path. To export elsewhere, rebuild explicitly.
   Normal `export_interchange` calls already used the original path and retain
   that behavior. This check is not an operating-system sandbox.
3. `reports/DELIVERY-STATUS.md` incorrectly called this the Step 8 repair and
   said Step 9 was absent. The current page, README, Cargo version, delivery
   policy, CI expectations and manual-test instructions now agree on Step 10
   version 0.10.1. Historical logs remain unchanged and clearly labeled.

Six Rust regressions cover the two source changes. They are supplied, not
executed. Two independent XML contract cases exercise the updated reference
writer/reader. Neither those cases nor FFmpeg recipes execute the Rust crate.

Primary format references checked during this review:
- Apple FCP7 XML Elements Catalog, `groupindex`:
  https://developer.apple.com/library/archive/documentation/AppleApplications/Reference/FinalCutPro_XML/Elements/Elements.html
- OpenTimelineIO file format (draft reference, not an application test):
  https://opentimelineio.readthedocs.io/en/latest/tutorials/otio-file-format-specification.html

## Environment and testing layers

Rust/Cargo are not installed. A connection attempt to the official Rust
artifact host failed DNS resolution. No compiler or lockfile was fabricated.
The OpenTimelineIO Python SDK and graphical target editors are not installed.
The user has explicitly accepted performing these remaining checks manually.

The independent media suites execute their own FFmpeg recipes and reference
serializers. Fresh results are in [the handoff record](../reports/handoff/verification.json).
The older report's test totals are not substituted for this run.

## Remaining acceptance

Use [MANUAL-TESTING.md](MANUAL-TESTING.md). Compile first; generate the actual
Rust interchange documents next; only then test imports in specific editor
versions. Cross-platform behavior, long/real-camera media, listening/visual
quality, source relinking and host lifecycle must be assessed on those systems.

This handoff does not implement the older missing clip-to-clip cross-dissolve
or non-unit-speed features, or qualify hardware/shared-decode optimizations.
It does not start Step 11, modify the terminal, open editors or upload media.
