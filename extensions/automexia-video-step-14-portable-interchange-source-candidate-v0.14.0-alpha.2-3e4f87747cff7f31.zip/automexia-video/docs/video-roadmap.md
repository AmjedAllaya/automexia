# Automexia Video — complete extension roadmap

**Extension:** `automexia-video`  
**Roadmap date:** 10 September 2026  
**Status:** implementation roadmap. The accompanying 0.6.0 crate supplies source for Steps 0–6 and independently exercised media recipes; Rust compilation and actual host qualification remain unverified. Later steps are not implemented.  
**Delivery direction:** one conventional first-party extension, following the existing Automexia extension patterns. No terminal rewrite, new extension platform, or many-library split is a prerequisite.  
**Order:** useful non-AI video editing → release-quality non-AI extension → targeted pre-AI modernization → optional local intelligence.

This roadmap concerns video editing and automated post-production only. The previous CE-0–CE-4 Kubernetes recipe/reference-tool work does not complete any step below.

## 1. What the extension delivers

The main workflow is:

**Open or select footage → inspect → create an editable project → clean/edit → review → render one or more versions, or export the edit to another editor.**

The product focuses on talking-head recordings, courses, tutorials, podcasts, commentary, product demos, screen recordings with a presenter, and social repurposing. It automates repetitive editing while letting the user inspect, reject, adjust, and lock decisions. It is not a requirement to build a full Premiere/Resolve-style graphical timeline application. The existing specification explicitly makes the workflow command-complete and permits optional keyboard-complete review surfaces. [Source S1](automexia-video-source-excerpts.md#s1) · [Source S2](automexia-video-source-excerpts.md#s2)

**Important scheduling change:** the supplied video proposal places several small learned models in its early V1 stages. Following the requested “AI later” sequence, this roadmap moves *all learned-model features* after Step 12: Silero speech detection, neural speech enhancement, face detection, transcription, and object detection. Earlier silence proposals use conservative signal measurements, and earlier crops/graphic placement do not claim face or semantic understanding. Those are explicitly reduced non-AI capabilities, not silent substitutes for the later model-assisted features.

The step numbers below are local to this video roadmap. They are not application release versions and are not the earlier generic CE steps. Exact action IDs, host versions, package fields and installation commands must come from the actual existing extension contract; the examples here do not invent a shipping loader or claim current binary compatibility.

## 2. Keep the implementation conventional

### One extension, ordinary internal modules

Use the language, build conventions, dependency policy, registration mechanism, settings ownership and lifecycle shape of the relevant existing first-party extension. For the documented native Automexia direction, the video-domain implementation is Rust. Keep its responsibilities as internal modules initially:

| Module responsibility | What belongs there |
|---|---|
| Existing-host adapter | Current command/action registration, settings, existing presentation, permission checks, job lifecycle and cancellation callbacks. |
| Media foundation | Probe results, selected streams, rational timing, display orientation, color/HDR classification and runtime capabilities. |
| Project and edits | `.amxv`, source references, typed edit operations, variants, locked decisions and migrations. |
| Analysis | Bounded audio/video observations, scene/color statistics, pause candidates and cache invalidation. |
| Audio and composition | Audio cleanup, crop/layout rules, graphics, subtitles and small keyframe operations. |
| Review | Decision lists, explanations, approvals/rejections, locks and short proxy previews. |
| Rendering and exporters | Compile approved project intent into media-tool plans, render validation and editor-interchange files. |

These are responsibilities, not eight required crates, services or separately installable plugins. Optional model packs stay inside the same user-facing Video extension.

### Reuse the existing host, do not build a new host

Use the current extension entry/discovery mechanism, current action dispatcher, current settings format, current list/picker/detail/progress/confirmation facilities, current approved native-tool execution boundary, and current cancellation and cleanup owners. Do not create a video-specific global scheduler, permission system, native-library loader, daemon, browser-based interface, public SDK or independent evidence authority.

A media-processing child is acceptable only through a supported and authorized existing execution mechanism. It is not permission to invent a native helper loader or give the extension arbitrary subprocess access. The source-aligned proposal describes “ProcessBroker” as the logical role of the existing application-owned `ExternalToolRunner`, not a mandatory new daemon or crate. [Source S2](automexia-video-source-excerpts.md#s2)

**One real compatibility constraint:** the retained accepted capability ADR describes a local-read boundary with separately controlled execution approvals. It does not establish that the actual current binary can load and run a new video worker. Step 0 must identify the real supported entry point and media-execution path. If either is absent, that exact integration is blocked under the no-terminal-change constraint. Do not change activation constants, rebuild the application, substitute a standalone product, or call a local simulation an installed extension. This is a small initial integration task, not another multi-phase audit-tool project. [Source S3](automexia-video-source-excerpts.md#s3)

### The initial dependency set

Use the extension's existing Rust/JSON/TOML conventions and a verified, capability-probed FFmpeg/ffprobe runtime through the approved execution path. Add Rust-native SVG rasterization only when graphics arrive. No Python, PyTorch, Node.js, Chromium, OpenCV, ONNX runtime or model bundle is required for the initial non-AI version.

For FFmpeg, choose and document one primary supported deployment: an approved compatible installed runtime, or a verified runtime distributed with the video package after its distribution requirements are resolved. Bundling is a packaging decision, not an already approved fact. Do not silently install tools during an edit. Missing encoders or filters produce a clear error for the requested feature; advertised software fallback is allowed only when equivalent enough and explicitly reported. [Source S9](automexia-video-source-excerpts.md#s9)

## 3. Roadmap at a glance

| Step | Work | Visible outcome |
|---:|---|---|
| 0 | Existing-extension integration | Video appears through the same supported route as other extensions; real entry, settings, lifecycle and media-tool access are identified. |
| 1 | Import, probing and first render | A real input becomes a correctly oriented, synchronized output without touching the source. |
| 2 | Editable projects and basic cuts | A saved `.amxv` describes reversible trims/cuts and can be reopened and rerendered. |
| 3 | Review and preview | The user can inspect, approve/reject and lock edits, and see short previews. |
| 4 | Non-AI pause cleanup | Measured quiet intervals become conservative, reviewable shortening proposals. |
| 5 | Non-AI voice cleanup | Cleaner, consistent audio without mandatory neural processing. |
| 6 | Scene and conservative color correction | Shot-aware SDR correction with explicit HDR restrictions. |
| 7 | Reframing and output variants | Landscape, portrait, square and custom versions from one master edit. |
| 8 | Graphics, subtitles and restrained effects | Titles, logos, lower thirds, supplied captions, simple animations and controlled punch-ins. |
| 9 | Presets, complete rendering and batch/workflow use | Repeatable clean/social/podcast workflows and efficient multi-target outputs. |
| 10 | Editor interchange | Editable OTIO, legacy FCP7 XML and simple EDL exports with compatibility reports. |
| 11 | Packaging and real-media release qualification | An installable, documented non-AI extension on explicitly tested platforms. |
| 12 | Final pre-AI modernization | Only demonstrated architectural gaps are fixed; projects and user commands remain compatible. |
| 13 | Optional local intelligence | Speech-aware cuts, selected denoisers, face-aware framing and transcription. |
| 14 | Later demand-driven enhancements | Advanced tracking, stabilization, multicamera/interchange and richer effects, without bloating the default install. |

Tests belong inside every feature step. “VideoLab” is the video scenario collection under the existing test system, not a new application framework to build before media editing.

---

## Step 0 — Connect one real Video extension using the existing pattern

**Goal:** establish the actual host-facing extension, not an offline imitation of it.

1. Choose a real existing first-party extension as the integration template. Reuse its supported discovery/package route, entry interface, naming, configuration and enable/disable behavior. Give Video one stable identity; do not invent a manifest version or application compatibility range.
2. Connect the extension's entry and help/settings presentation through the current action/command route. Start with useful Video status: available runtime, supported media operations and missing prerequisites. Do not add new global shortcuts or core UI widgets.
3. Reuse the existing approved native-tool path for FFmpeg/ffprobe. Bind explicit input/output/temp access, supplied arguments, progress and cancellation. No shell command construction and no unrestricted process API.
4. Use lazy startup. Opening a normal terminal without Video must not start a codec worker, scan media, load models or create background activity.
5. Test opening, closing, disabling and removing Video through the actual existing mechanism. Capture only the normal implementation/test records already used by other extensions. If the format is compiled-in rather than loadable, state that limitation immediately instead of declaring drop-in support.

**Deliverable:** the extension entry, adapter, ordinary settings/help, dependency status and initial smoke tests in the existing repository style.

**Done when:** the unchanged compatible terminal discovers and calls Video through its real supported route, and the approved media-tool boundary is usable. A hello-world component that cannot reach approved media execution is not enough to claim a video editor works.

## Step 1 — Import media, inspect it and produce the first real output

**Goal:** obtain a working input-to-output vertical slice before smart editing or architecture expansion.

1. Accept explicitly selected local footage and supported project assets. Cover common MP4/MOV/MKV/WebM inputs where the chosen runtime has the required demuxer/decoder; audio and image assets are admitted only when their role is supported. Do not advertise every extension as automatically decodable.
2. Probe selected/default video and audio streams. Record codecs, dimensions, stream indices/dispositions, sample rates, channel layouts, rational time bases, frame-rate/VFR information, durations/start offsets, sample/display aspect ratios, rotation/display matrix, interlacing, color range/primaries/transfer and HDR metadata. Allow explicit stream selection; handle missing audio without silently choosing a different stream.
3. Introduce exact source-time mapping immediately. Preserve source timestamps and rational time bases, normalize offsets/edit lists/delay metadata, and handle AAC priming, Opus pre-skip, negative timestamps and reordered frames. Never derive all edits from rounded frame counts or early floating-point conversions.
4. Implement a no-edit render path with verified runtime capabilities. Respect orientation, display aspect, expected stream selection and channel layout. Make preserve-frame-rate versus explicit constant-frame-rate conversion a project/output choice.
5. Add request-owned temporary output, collision protection, overwrite confirmation, cancellation, bounded progress/errors and output probing. Validate the completed file before promoting it to its final destination. Never overwrite the source, including through an alias of its path.

**Deliverable:** one real clip can be probed and rendered; errors are actionable; source footage remains unchanged.

**Tests:** ordinary footage, no-audio footage, portrait rotation, VFR, multiple audio streams, Unicode/spaces in paths, missing runtime/encoder, corrupt input, denied output and cancellation. Check decoded orientation/timing and A/V synchronization, not just exit status.

**Done when:** a representative input becomes playable output with correct declared properties through the existing terminal integration. This is the first usable media milestone.

## Step 2 — Implement `.amxv` and reversible basic editing

**Goal:** separate editable decisions from generated media.

1. Create the versioned, human-readable `.amxv` JSON project described in the specification. Store source references/fingerprints, selected streams, normalized timing, resolved settings, typed operations, variants and render/export provenance. Prefer project-relative paths where possible. Large observations stay outside the project.
2. Implement explicit trim/keep ranges and ordered cut assembly. Splitting a range is an operation on edit metadata; removing a segment does not delete source media. Keep audio/video changes tied to the same edit mapping. Preserve room for multiple sources in the schema without promising a full multicamera editor now.
3. Store a stable operation identity, kind, source interval, parameters, reason, generator version and disposition. Manual user choices take precedence; locked operations survive recomputation. The detailed controls for explicit trim/split/range adjustment are proposed usability elaborations of the source's editable operations, not claims that an existing host API already implements them.
4. Preserve resolved presets in the project. Reopening/rerendering must not silently adopt newly edited global settings. Use atomic project writes; support old approved schema migrations and reject unknown newer semantics rather than guessing.
5. Implement `--no-render` and `--dry-run` behavior. Dry run may probe/analyze and save the inspectable project, but must explicitly report whether it wrote project/cache files and must not render final delivery media. `render` uses saved edit intent rather than rerunning every detector.

**Deliverable:** a real project can be saved, reopened, adjusted and rerendered with the same edit decisions.

**Tests:** trim boundaries, adjacent/overlapping/empty invalid ranges, A/V mapping, locked edits, changed source identity, moved/relinked media, old/new schemas, preset changes, failed project saves and long recordings.

**Done when:** the user can undo an automated proposal by disabling it or restoring its source range and rerender without losing the original. Bit-identical compressed files across different encoders are not promised; stable edit intent is. [Source S4](automexia-video-source-excerpts.md#s4)

## Step 3 — Add review and short previews before automatic decisions expand

**Goal:** make edits inspectable and reversible before automatic cleanup becomes aggressive.

1. Add the proposed `video review PROJECT` operation through current extension commands/actions. Present edit time, type, old/new duration or geometry, reason, confidence where meaningful, current disposition and lock state.
2. Support inspect/preview, approve, reject, enable/disable and lock using the existing keyboard-complete interaction model. Use existing list/detail/confirmation surfaces where exposed. Pointer actions are optional equivalents; focus, theme, reduced-motion and accessibility behavior follow the host.
3. Generate bounded low-resolution review proxies around individual decisions, typically a short before/proposed/after window. Support useful audio A/B review as well as visual review. Proxies are disposable and tied to the source/project/operation revision; they never replace the original.
4. Reuse an already supported preview/playback route. Do not create a renderer, browser UI or terminal video widget simply to display proxies. If no such route is exposed, preserve command/project review and identify the preview integration gap rather than claim playback works. Opening a generated proxy through an existing approved opener is not a separate editor product.
5. Apply feature-specific dispositions: `AutoApply`, `NeedsReview`, `Ignore`. Pending proposals must not silently enter an export/render. Changing an operation invalidates obsolete proxy/review state. Unsafe or unknown state cannot inherit a previous approval.

**Deliverable:** a useful decision-review workflow, with native preview where the current host exposes it.

**Tests:** keyboard-only use, focus return to terminal, stale selection/proxy, empty project, missing asset, reject/lock persistence, cancellation and render behavior with unresolved proposals.

**Done when:** the user can understand and control the edits actually used in the next render. An offline selection-state test is not proof of host UI or playback. [Source S10](automexia-video-source-excerpts.md#s10)

## Step 4 — Add conservative pause shortening without AI

**Goal:** shorten obvious dead air while preserving natural speech.

1. Analyze selected audio in bounded chunks for RMS/energy, sustained quiet intervals, durations and adjacent continuity. Reuse the same observation stream for loudness/noise statistics where practical.
2. Propose changes only for sufficiently long, clearly quiet intervals. Keep configurable padding around boundaries, a minimum retained pause and protected/manual regions. Preserve short pauses and avoid tiny speech islands and mechanically repeated cuts.
3. Assemble matching video/audio edits from one timing map. Use micro-fades, short crossfades or suitable zero-crossing-aware boundaries where practical; avoid long fades that smear spoken words. Default video joins are hard cuts.
4. Treat low-volume speech, breathing, continuous music and uncertain background content conservatively. Energy is not a speech detector. When a music bed shares the same stream, explain that removing time also jumps the music; preserve or require review rather than imply seamless music continuity.
5. Show proposed cut count, retained gaps and expected final duration before rendering. Keep thresholds in presets, not one universal hardcoded setting. The later speech-aware model stage upgrades these proposals without changing the project format.

**Deliverable:** reviewable quiet-interval cleanup that creates a shorter real video.

**Tests:** clean speech, very quiet words, breath-heavy speech, long and short pauses, keyboard/fan noise, music mixed with voice, multiple streams and explicit keep regions. Listen at edit boundaries and check A/V synchronization.

**Done when:** obvious dead air is shortened without known damaged speech in the release corpus. Do not label this pre-AI algorithm “speech-aware Silero editing.” [Source S5](automexia-video-source-excerpts.md#s5)

## Step 5 — Add traditional voice and audio cleanup

**Goal:** produce consistent spoken-word audio without a mandatory neural denoiser.

1. Run audio preflight: peak/clipping, DC offset, low-frequency rumble, channel balance, loudness, likely hum and continuous background energy. Let the user select the intended dialogue stream; do not assume every surround or stereo mix is dialogue.
2. Provide `auto`, `on` and `off` controls with per-stage settings. Under uncertain non-AI classification, `auto` is conservative and may preserve the signal. Already clean audio should often bypass denoising entirely.
3. Implement the necessary chain: decode/stream selection → DC/rumble cleanup → evidence-based 50/60 Hz hum reduction where appropriate → optional traditional cleanup → edit assembly → restrained EQ/de-essing/compression → measured loudness correction → true-peak limiting. Keep effects individually reversible/configurable in the project.
4. Preserve channel layout unless the user explicitly requests a change. Mono analysis is not consent to downmix final audio. Auxiliary audio assets remain separate references where supported; a full music-mastering workstation is not required.
5. Make loudness and true-peak targets preset data. Use measurement/correction passes for quality output. The source's example LUFS values are starting editorial defaults, not mandatory platform rules. Flag digitally clipped input; ordinary compression cannot reconstruct already missing signal.

**Deliverable:** useful audio improvement in rendered video, and an enhanced audio stem where needed for export.

**Tests:** clean/noisy/clipped recordings, hum, sibilance, breaths, music bed, mono/stereo/multichannel, channel imbalance and bypass. Check loudness, peaks and sync; include blind listening instead of maximizing noise reduction alone.

**Done when:** the user can compare original/processed audio and obtain a demonstrably usable result without installing any model. Neural engines remain Step 13. [Source S5](automexia-video-source-excerpts.md#s5)

## Step 6 — Add scene detection and conservative color correction

**Goal:** improve technical consistency without automatic artistic grading.

1. Share a low-resolution, display-oriented decode for scene scoring, histogram/luma/color statistics and motion/activity estimates. Sample sufficiently for the promised cut-detection behavior. Do not repeatedly decode full footage for each feature.
2. Detect shot boundaries and use them to reset crop/effect state and delimit color decisions. Preserve known source cuts; one-frame or rapid transitions belong in the regression corpus.
3. For qualified SDR input, implement bounded exposure/gamma, white-balance, contrast and restrained saturation correction. Use luminance/clipping/channel/neutral-region evidence. Preserve a shot when confidence is low; do not force gray-world correction onto intentionally colored lighting.
4. Smooth corrections within a shot and allow reset at a genuine cut. Keep creative looks such as warm/film/high-contrast explicit user presets. Face-region checks are added only when a detector is actually available later.
5. Keep an operation-specific HDR policy. Qualify trims and audio-only work; separately qualify compatible concatenation, crop, scale, color and overlays. Initially reject unqualified HDR exposure/white-balance and 8-bit overlay paths. Treat Dolby Vision dynamic metadata as preserve-only or unsupported until specifically tested. Copying HDR metadata is not proof of correct pixels.

**Deliverable:** shot-aware SDR corrections and honest handling of unsupported HDR transformations.

**Tests:** SDR reference charts, bright/dark footage, saturated scenes, intentional color casts, flashes, rapid cuts, 10-bit/HDR10/HLG/Dolby Vision samples, rotation and interlacing. Compare decoded imagery and metadata.

**Done when:** correction improves the qualified cases without introducing clipping, shot flicker or silent HDR-to-SDR conversion. [Source S6](automexia-video-source-excerpts.md#s6) · [Source S10](automexia-video-source-excerpts.md#s10)

## Step 7 — Add aspect conversion, crop control and social variants

**Goal:** produce several compositions from one master edit.

1. Support 16:9, 9:16, 4:5, 1:1 and custom dimensions/aspect. Separate shared time/audio edits from target-specific crop, scaling, graphics and subtitle placement.
2. Implement explicit crop framing, center/stable framing and user-supplied crop/keyframe adjustments in source display space. Preserve full composition with a fit/padding choice when a crop would remove important content. Fit/padding is a proposed straightforward user-control detail, not a face detector.
3. Respect rotation and non-square pixels. Validate crop bounds, scale limits and output aspect. When crop motion is requested, use a small deterministic keyframe/smoothing implementation, with dead zone and velocity/acceleration limits where applicable.
4. Store crop tracks and target geometry in `.amxv`. Do not bake them prematurely; changing one variant must not rewrite other compositions or the shared edit.
5. Create versioned target presets for YouTube, TikTok, Reel, Feed, Square and Master. Their safe zones are editable conservative presets, not promises about a platform's current UI. Before local vision arrives, no automatic face/group/speaker tracking is claimed.

**Deliverable:** a landscape, portrait, square or custom render from the same editable project; sequential target rendering is acceptable first.

**Tests:** portrait and landscape originals, extreme aspect differences, source-edge crop, fit/padding, rotation, non-square pixels, scene resets, target-specific safe zones and synchronized outputs.

**Done when:** multiple real outputs have the intended composition and aspect, and the user can correct a crop without rerunning unrelated analysis. [Source S6](automexia-video-source-excerpts.md#s6) · [Source S7](automexia-video-source-excerpts.md#s7)

## Step 8 — Add graphics, supplied subtitles and restrained effects

**Goal:** complete normal creator presentation without a browser or motion-graphics engine.

1. Add supplied logos/watermarks, images/SVG, titles and lower thirds. Timing comes from explicit ranges, templates, workflows or existing subtitle times—not invented semantic understanding of the footage.
2. Import SRT and WebVTT; validate structure and bounded text/timing. Remap captions through the source-to-edited timeline, define behavior at deleted ranges, preserve Unicode and allow layout/readability adjustments. Provide burned-in captions and/or a remapped subtitle sidecar where implemented. Sidecar output and manual timing/text adjustment are explicit usability elaborations of the source's subtitle-input requirement.
3. Start placement with user-selected anchors, safe zones, known overlay/caption collisions, local luminance/edges/activity and stability penalties. Prefer a small candidate-anchor set evaluated per shot/segment, not per-pixel searching or per-frame jumping. Face avoidance becomes available only in Step 13; base placement does not understand arbitrary baked-in text or objects.
4. Implement light/dark variants, background plates, shadows, margins and bounded size adjustment. Rasterize safe static SVG templates using the selected Rust-native renderer and composite through FFmpeg. Block arbitrary external asset/network fetches. Record actual template and font identity; warn about significant font substitution.
5. Add a deliberately small effect/keyframe vocabulary: position, crop, scale, opacity, volume and explicitly supported speed values; linear/ease-in/ease-out/ease-in-out interpolation. A speed field is not a promise of automatic speed-ramp generation. Support title fades/slides, short fades/dissolves when requested and restrained punch-ins.
6. Default to hard cuts. Use punch-ins only for suitable same-scene jumps or explicit intervals, with small zoom changes, safe crop bounds, a minimum interval and scene resets. No automatic face-safe punch-in claim before vision is present. Avoid mechanical zoom alternation and decorative transitions on every pause cut.

**Deliverable:** polished footage with supplied captions, branding and restrained animation in each chosen target format.

**Tests:** subtitle remapping around cuts, long/multiline/Unicode text, missing fonts, transparent/oversized assets, malformed SVG/subtitles, external references, poor-contrast backgrounds, overlapping overlays, target edges and preview/render consistency.

**Done when:** text remains legible and synchronized, assets do not cause hidden file/network access, and graphics/effects remain editable. [Source S6](automexia-video-source-excerpts.md#s6)

## Step 9 — Finish presets, rendering and repeatable workflows

**Goal:** make the useful workflow simple for users and efficient for repeat runs.

1. Ship three understandable edit presets: **clean** for natural pauses/technical cleanup; **social** for tighter but controlled edits and chosen output geometry; **podcast** for natural delivery, voice consistency and minimal visual effects. Preserve the same names when local intelligence later adds capabilities. Never silently activate model stages merely because a preset contains optional settings.
2. Separate edit presets from output targets and render modes. Use the documented precedence: built-in defaults < user settings < project settings < named preset < explicit flags. Snapshot effective editing settings into `.amxv`; strict configuration errors identify unknown options.
3. Implement four output intents: **preview**, **fast**, **publish**, **master**. Support the requested container/encoder only when capability probing qualifies it. H.264/H.265, WebM, ProRes and optional AV1 remain runtime-dependent output choices, not universal guarantees. Record the actual FFmpeg build, encoder, pixel format, audio codec, settings and warnings.
4. Compile deterministic branches: orientation/normalization → shared time edits → qualified color → variant crop/scale → overlays → output pixel/color format → encoder. Audio uses the selected cleanup, shared time mapping and final loudness/limiting chain. Validate every result, including duration/streams/channel layout/frame-rate/color policy and sync.
5. Keep sequential multi-target renders as the known-good reference. Optimize with shared decode/common filters and split output branches only when quality, memory and encoder tests pass. Fall back visibly to sequential work if needed. Do not create giant intermediate masters by default; opt-in intermediates must have ownership and storage limits.
6. Reuse the current job/workflow system for progress, logs, cancel, retry and result paths. Queue batches of independent projects or targets through existing facilities; do not add a workflow language. Isolate per-target failures, keep valid analysis/project state, and retry failed work without discarding successful outputs. Generic pause/resume is not promised for encoders that cannot resume safely.
7. Keep normal use to the four proposed commands `run`, `review`, `render`, `export`. JSON results/events and documented exit states serve scripts; human logs remain separate. Default processing is offline and does not fetch models, publish videos or upload diagnostics.

**Deliverable:** repeatable one-command workflows, useful background jobs where supported, and efficient multi-format publishing.

**Tests:** configuration precedence, changed global presets, absent optional packs, missing encoders, hardware/software paths, sequential versus combined outputs, partial target failure, output collisions, disk full, cache hits/invalidation, long jobs and cancellation.

**Done when:** a real input can reliably become the selected output set, with deterministic edit intent and individually validated outputs. [Source S7](automexia-video-source-excerpts.md#s7) · [Source S8](automexia-video-source-excerpts.md#s8)

## Step 10 — Export editable timelines to other editors

**Goal:** preserve the user's ability to continue editing outside Automexia.

1. Implement dedicated Rust exporters for the promised subset of **OTIO JSON**, **legacy Final Cut Pro 7 XML (`fcp7xml`)**, and **CMX3600 EDL**. Rendering creates finished media; exporting creates an editable interchange representation. They remain separate operations.
2. Represent supported cuts, source in/out points, track/stream relationships, markers and basic transitions using accurate timing. Qualify frame/timecode conversions and declared rate requirements, especially for EDL and VFR sources.
3. Define logical target profiles such as Resolve and Premiere, but support claims must name tested application/version families and formats. Do not call legacy FCP7 XML modern `.fcpxml`, promise every application imports OTIO, or write reverse-engineered `.prproj`/`.drp` files.
4. Classify every operation as **preserved**, **translated**, **baked** or **unsupported**. Emit a compatibility report; never silently drop an edit. Bake an enhanced audio stem when the target cannot represent the processing, and use explicit user consent for visual baking that sacrifices editability.
5. Support project-relative or explicit absolute media references, deliberate source relinking and path validation. Copy/bundle media is an explicit future/export option, not an automatic bulk duplication. State EDL's supported simple-timeline subset and reject unrepresentable structures when warnings are insufficient.

**Deliverable:** real editable interchange files plus honest compatibility reports.

**Tests:** actual import in each advertised editor/version, inspecting cuts, offsets, tracks, transitions, markers, audio stems, missing assets, relinks, path characters and timing. Valid JSON/XML alone does not qualify the feature.

**Done when:** the intended edit opens correctly in the advertised target with documented, visible limitations. [Source S7](automexia-video-source-excerpts.md#s7) · [Source S10](automexia-video-source-excerpts.md#s10)

## Step 11 — Package and qualify the non-AI extension

**Goal:** deliver a real installable Video extension, not a test-report bundle.

1. Package one Video extension through the existing release mechanism. Include only its implemented non-AI code, presets/assets, supported runtime arrangement, license/notices and normal documentation. Do not introduce a new installer, model manager or core dependency to make the package appear complete.
2. Test the real installation/enable/update/disable/remove lifecycle on declared targets. The source's practical starting matrix is Linux x86_64, Windows x86_64 and macOS Apple Silicon; add other architectures only with their own packaging and tests. Do not label an untested platform supported.
3. Use a legally usable real-media corpus in the current test system: webcam/camera/phone, OBS/screen capture, video calls, short creator material and a long podcast; clean/quiet/noisy/clipped audio, music, multiple streams/5.1; VFR/fractional rates, rotation, interlace, long GOP, 10-bit/HDR and broken timing.
4. Exercise crash/hang/cancel, exhausted disk, unwritable destination, missing/changing source, corrupted assets/cache, oversized metadata/dimensions, playlist/network references and temporary cleanup failure. Originals and valid project files survive; no unrelated files are removed; processing stays offline; the terminal remains responsive.
5. Measure actual total resource use, analysis/render speed, cache reuse, preview latency and typing responsiveness on representative hardware. Set budgets from a measured baseline rather than fabricated performance promises. Bounded caches/queues and released idle resources are required from the first implementation, not deferred to this step.
6. Release only the tested non-AI scope. Include a quick start, dependencies, presets, settings, project portability, expected outputs, failure/recovery instructions, supported formats/OSes and explicit model-dependent features that are still unavailable.

**Deliverable:** a functional non-AI video extension release with matching user documentation.

**Done when:** a user can install it through the normal compatible-host route, process actual footage, review and rerender the project, export advertised formats, cancel safely and remove the extension without terminal modifications. All earlier integration blockers must actually be closed; local reference-code tests cannot satisfy this step. [Source S12](automexia-video-source-excerpts.md#s12)

## Step 12 — Final non-AI milestone: targeted modernization before AI

**Goal:** apply only the useful architectural improvements discussed earlier, immediately before adding models.

This step is deliberately after the useful non-AI extension. It is not permission to ship unsafe process, file or media handling earlier.

1. Freeze representative projects, fixtures, workflows and behavior from the working extension. Measure actual coupling, failure modes, startup/resource costs and repeated code. Identify concrete gaps rather than assume every module needs extraction.
2. Keep one user-facing Video package. Extract a private library only where a real boundary helps: reusable project/time/edit models, headless analysis/decision code, render-plan compilation or interchange logic. Keep ordinary views/features as modules; no per-effect services or plugin-inside-plugin system.
3. Strengthen only missing generic host seams: typed media requests, explicit input/output grants, cancellation/ownership, bounded progress/data transport and current-session publication. Reuse the accepted authority owners. Do not invent a new Policy Engine or ProcessBroker daemon just because those names occur in a proposal.
4. Isolate heavy native/model work using the supported worker/provider pattern. Introduce a new generic isolation/transport facility only if a documented gap genuinely requires a separately reviewed host change. Keep bulk frames/audio out of JSON and off the terminal input/render path; control messages, cancellation and progress remain bounded.
5. Keep original references/decisions in `.amxv`, and large observations in a rebuildable cache. Separate path-as-locator from content identity; invalidate by selected streams, algorithm/settings/runtime/model identities. A fast fingerprint is for cache lookup; use full content hashing when an explicit high-integrity workflow requires it.
6. Complete ordinary package compatibility, owned cleanup, rollback, dependency review and public/privileged boundary tests for the changed implementation. Preserve project identities and command behavior. Do not publish a general extension SDK merely for Video.
7. Rerun the full non-AI corpus and actual-host tests. Compare outputs, decisions, imports, resources and cancellation with the previous release. Only after behavior is preserved does Step 13 begin.

**Deliverable:** the same useful extension with proven maintainability and isolation where necessary—not a rewritten terminal.

**Done when:** the improved implementation preserves existing projects and workflows and has the bounded interfaces needed for optional models. Host changes, if still necessary, are explicit work in this later milestone; no engine rewrite is assumed. [Source S2](automexia-video-source-excerpts.md#s2) · [Source S9](automexia-video-source-excerpts.md#s9)

## Step 13 — Add optional local intelligence, one capability at a time

**Goal:** upgrade the existing editing workflow without making it dependent on cloud services or large models.

The rule remains: **models observe; Rust decides; Automexia authorizes media work; FFmpeg renders; humans review uncertainty.** The following are substeps of the same Video extension, not separate applications.

### 13A. Common model-pack support

Reuse existing optional-component management. Install/update packs only through explicit supported user operations. Pin exact runtime, weights, checksums, model input/pre/postprocessing and relevant licenses; code licensing alone is not weight-redistribution approval. Lazy-load models only for requested features and release their memory. Start with a qualified CPU path; GPU inference providers require measured benefit and their own support qualification. An absent pack must not disable manual edits, rendering of compatible saved decisions or imported subtitles. Never silently substitute a different analysis model.

### 13B. Speech-aware pause editing

Add the documented Silero VAD candidate through an observation interface. Analyze the appropriate mono analysis stream while preserving output channels. Combine speech probability with energy, duration, continuity and padding; keep deterministic Rust responsible for applying or proposing cuts. Respect locked keep regions and unresolved speech boundaries. Compare against Step 4 on quiet speech, breaths, noise and music; track speech loss, pause precision, retained-gap distribution and rejected proposals. Do not require a transcript to shorten pauses.

### 13C. Optional higher-quality speech enhancement

Add the `SpeechEnhancer` interface only when required by the selected backends. Keep Preserve and traditional cleanup as valid outcomes. Compare suitable WebRTC AudioProcessing, RNNoise and DeepFilterNet candidates on the actual corpus; verify whether each exact backend uses learned components and package it accordingly. RNNoise is not mandatory; DeepFilterNet is not approved merely by naming it. Require exact weight/distribution approval and blind listening, plus speech/breath/transient preservation, noise reduction, CPU/RAM and latency measurements. Expose engine/strength controls and the optional `voice-quality` pack without changing the normal command workflow.

### 13D. Face-aware reframing and graphic avoidance

Implement a normalized `FaceDetector` interface. The revised source identifies YuNet as the primary candidate and UltraFace as a comparison/legacy candidate—not an independently verified current best model. Test them before selecting one. Detect on sampled low-resolution display-oriented frames; associate by overlap, center distance and size consistency; smooth/predict and expire missed tracks without adding OpenCV solely for basic tracking.

Use one-face tracking, nearby-group framing, stable subject/group choices for separated faces and conservative no-face fallback. Respect headroom, body margin, safe zones, source edges and reliable motion/look signals only. Apply dead zones, smoothing and speed/acceleration limits; reset on scene cuts and store editable keyframes. Use valid face tracks for safe punch-ins and face-avoiding graphic/caption placement. Do not claim active-speaker identity from face size alone. Measure face clipping, jitter, safe-zone success and manual corrections.

### 13E. Optional local transcription

Add the documented `whisper.cpp` tiny/base candidate as an optional `transcription` pack. Generate editable text/timestamps and subtitles; support transcript search, sentence boundaries, chapter suggestions and sentence-based punch-in proposals. Map generated captions through subsequent cuts; preserve locked corrections and low-confidence words for review.

Filler-word removal is a reviewable proposal, not blanket deletion. Include language/accent/noise/music/overlapping-speaker cases. Precise forced alignment is a separately justified optional addition, not a reason to add WhisperX/Python to the base package. No cloud transcription, LLM story generation or agent loop is part of this stage.

**Deliverable:** the full model-assisted spoken-word pipeline and optional transcription/quality-voice packs, still one extension.

**Done when:** each added capability beats or usefully complements the non-AI baseline on actual media, preserves manual controls and project portability, and passes exact-asset installation/offline/cancel/quality tests. A model loading successfully is not a complete editing feature. [Source S8](automexia-video-source-excerpts.md#s8) · [Source S9](automexia-video-source-excerpts.md#s9) · [Source S12](automexia-video-source-excerpts.md#s12)

## Step 14 — Preserve the advanced feature backlog without bloating the first release

**Goal:** retain the full documented ambition while keeping the initial product deliverable.

These are demand-driven follow-ons, not missing prerequisites for Steps 0–13. Some use models, some traditional processing; none automatically enters the base installation.

| Optional area | Features retained from the video specification | Rule before implementation/release |
|---|---|---|
| `vision+` | Person/object detection, better no-face landscape/B-roll framing, more robust graphic avoidance and placement. | Demonstrate a workflow that face/center framing cannot solve; qualify the exact detector and its scope. |
| Speaker-aware editing | Active-speaker tracking, speaker-aware reframing and speaker-change triggers. | Combine appropriate evidence; do not infer speaking from a face bounding box alone. |
| `vision-advanced` | Optical-flow tracking, stabilization, homography where required, object-following callouts. | Add OpenCV or another heavy stack only when the proven feature needs it; measure cost and quality. |
| Advanced timing/effects | Speed ramps, beat-aware editing, richer animation templates, more advanced motion/curves. | Preserve timing/sync and reversible operations; explicitly define the supported subset. |
| Advanced composition | Segmentation/background effects, richer masks/compositing and advanced shot matching. | Separate optional dependencies; retain original pixels/references and honest export limits. |
| Larger projects | Multicamera and broader multiclip workflows. | Extend editing behavior deliberately; the initial multiple-source schema is not a claim these workflows already exist. |
| Interchange expansion | Better fidelity, explicit media bundling, modern Final Cut Pro `.fcpxml`, AAF. | Add real target/version import tests and operation-level compatibility reporting. |

**Still outside the agreed default design:** generative B-roll/video, text-to-video, automatic script writing, large LLMs, agents, paid inference APIs, cloud rendering/transcription, collaborative editing services, proprietary `.prproj`/`.drp` reverse engineering, custom codecs, a full native NLE GUI/TUI, and a custom full-resolution GPU compositor. They require a separate product decision, not an implied promise under “all features.” [Source S1](automexia-video-source-excerpts.md#s1) · [Source S8](automexia-video-source-excerpts.md#s8)

## 4. Small user-facing command surface

These examples are the **proposed video commands from the specification**, to be wired through the actual existing extension mechanism. They are not claims that the current installed terminal already supports them.

```bash
# Analyze, build an editable project and render using implemented preset stages.
video run recording.mp4 --preset clean

# Analyze and inspect proposed decisions without final delivery rendering.
video run recording.mp4 --dry-run
video review recording.amxv

# Keep the project without producing final media yet.
video run recording.mov --no-render

# Render saved decisions, optionally into multiple geometries.
video render recording.amxv --mode publish
video run recording.mp4 --preset social --to youtube,tiktok,reel

# Produce a qualified master where the runtime supports the requested encoder.
video render recording.amxv --mode master --codec prores --output master.mov

# Export edit intent instead of a finished video.
video export recording.amxv --format otio
video export recording.amxv --format fcp7xml
video export recording.amxv --format edl
```

`--json`, foreground/background execution, `--overwrite`, diagnostic logging and temporary-file retention should follow the existing host conventions and the video's documented behavior. There is no requirement to create separate mandatory reframe/enhance/effects applications. Optional models enhance these same commands and presets.

## 5. Data and lifetime rules that apply throughout

| Data/activity | Owner and lifetime |
|---|---|
| Original footage and supplied assets | User-owned; never modified or deleted implicitly. Access only explicitly authorized inputs. |
| `.amxv` | Durable user project with decisions, references, parameters and relevant provenance. Atomic save, explicit migrations and relinking. |
| Analysis cache | Rebuildable observations with content/settings/runtime/algorithm/model identity, bounded size and invalidation. Not all observations embedded in the project. |
| Proxies and temporary files | Job/project-owned disposable data; bounded retention; cleanup does not touch unrelated files. |
| Final media and interchange exports | Explicit user destinations, collision handling and completion validation. Successful targets survive a separate failed target. |
| Processing jobs and native children | Existing host authority/lifecycle; bounded concurrency, cancellation, deadlines and cleanup. No hidden daemon. |
| Optional models | Explicitly installed verified components; not loaded by normal terminal startup or downloaded during rendering. |
| Diagnostics | Useful stage/request/runtime/error information, bounded and redacted; no uploads or media content in logs by default. |

## 6. Complete feature coverage map

This table is a navigation checklist, not a claim of implementation. All entries are planned or later-optional.

| Feature family | Included coverage | Step |
|---|---|---|
| Conventional extension delivery | Same entry, settings, lifecycle, action/UI conventions and approved execution path as current extensions. | 0, 11 |
| Media import | Explicit inputs/assets, ffprobe, default/explicit streams, formats qualified by runtime. | 1 |
| Time correctness | Rational source PTS/time bases, VFR/CFR choice, negative/start offsets, edit lists, codec delay, AAC/Opus, DTS/PTS/B-frames. | 1, 2 |
| Display correctness | Rotation, sample/display aspect, interlacing/deinterlacing and target geometry. | 1, 6, 7 |
| Editable project | Human-readable `.amxv`, relative references/relinking, typed operations, locks, versioned settings, migrations and provenance. | 2 |
| Basic editing | Trim, retained ranges, splits/cut assembly, reversible decisions and synchronized audio/video. | 2 |
| Review | Reasons, feature-specific dispositions, approve/reject/lock, short video/audio proxies and native keyboard behavior. | 3 |
| Silence | Energy-based conservative proposals first; speech-probability-assisted cleanup later, with breath/padding/music safeguards. | 4, 13B |
| Audio | Preflight, DC/rumble/dehum, optional cleanup, EQ/de-ess/compression, loudness/true peak, channel preservation and stems. | 5 |
| Speech enhancement | Preserve/traditional/neural/review decisions, qualified optional engines and `voice-quality`. | 13C |
| Scenes and color | Shot detection, SDR exposure/white balance/contrast, explicit looks, smoothing and operation-specific HDR qualification. | 6 |
| Geometry | 16:9, 9:16, 4:5, 1:1/custom, explicit/stable crop, safe zones and variant-specific composition. | 7 |
| Face-aware framing | Detector choice, tracking/group handling, no-face fallback, composition/smoothing/keyframes and face avoidance. | 13D |
| Graphics | Logos/watermarks, titles/lower thirds, supplied images/SVG, safe anchors, contrast plates/shadows, fonts and stable placement. | 8, 13D |
| Captions | SRT/WebVTT input, cut-time remapping, editable supplied text/timing, burned-in/sidecar output; generated subtitles later. | 8, 13E |
| Effects | Hard cuts, micro audio fades, restrained punch-ins, short fades/dissolves, title fade/slide and limited keyframes. | 4, 8 |
| Presets | Clean/social/podcast; independent output targets; predictable overrides and project snapshots. | 9 |
| Render modes | Preview/fast/publish/master, encoder capability selection, CPU/software fallback where appropriate, exact runtime reporting. | 1, 9 |
| Multi-target | Shared master, per-target layout, sequential reference then shared-decode optimization with partial-failure recovery. | 7, 9 |
| Repeatable operations | Dry run, no-render, render from saved decisions, machine-readable output, jobs, batches via existing workflows, cancel and retry. | 2, 9 |
| Caching and resources | Shared low-resolution analysis, bounded queues/cache, source change detection, optional full hashes and released idle resources. | 1 onward, 9, 12 |
| Editor export | OTIO/FCP7XML/EDL, preserve/translate/bake/unsupported report, audio stems, relinking and real import qualification. | 10 |
| Local transcription | Optional model pack, subtitles, search, sentence boundaries, chapters and reviewable filler-word operations. | 13E |
| Optional advanced scope | Vision+, speaker-aware editing, advanced vision, stabilization, callouts, richer effects, multicamera, AAF/modern FCPXML. | 14 |
| Safety and shipping | No source overwrite, scoped local access, runtime/package integrity, hostile-media recovery, real-media tests and supported-platform packaging. | Every step, release in 11 |

## 7. Tests and completion: useful media, not paperwork

For each feature, the implementation loop is **build the feature → run its focused tests → process real sample media → inspect/listen/review → test relevant failure cases → fix defects → rerun the feature and regression tests**. Record known limitations and unrun checks honestly. Do not substitute a large number of synthetic tests for the native workflow.

A feature is complete only when its visible path works through the intended extension interface, its output matches the project intent, source/project data is safe, failure/cancellation works, relevant CPU/RAM/temp bounds hold and documentation describes the actual behavior. New library/runtime/model versions rerun the same corpus before adoption. A passed unit suite does not mean an untested editor import or OS integration works.

## 8. Source basis and explicit changes

The feature inventory is based on `docs/developer/future/video-automation.md`, its four continuation chapters, and `docs/developer/verification/video-lab.md` inside `automexia-documentation-ce4-presentation-actions-2026-09-09.zip`. Existing capability restrictions are checked against ADR 0003; domain ownership is consistent with ADR 0035. The original archive is not modified by this roadmap delivery.

The later repository-aligned video proposal is used when older alternatives disagree: no mandatory RNNoise, no assumed native-worker privilege, FFmpeg distribution remains a decision to resolve, `.amxv` contains edit intent rather than huge observations, and review is command-complete with optional current-host UI. Runtime/model names are retained **source candidates**, not new external recommendations or claims of current upstream status.

The specific planning changes in this roadmap are: one conventional extension first; no new host system as an immediate prerequisite; small explicit range-edit controls; early human review; optional fit/padding and remapped subtitle sidecars; non-AI energy-only pause proposals before models; reuse of current jobs for batch workflows; targeted modernization as the last committed non-AI step; and all learned models afterward. These are clearly proposed elaborations/resequencing, not silently attributed to an existing implementation.

[Exact source excerpts and source-file hashes](automexia-video-source-excerpts.md) are supplied alongside this roadmap. No existing generic prototype tests are counted as Video implementation progress.
