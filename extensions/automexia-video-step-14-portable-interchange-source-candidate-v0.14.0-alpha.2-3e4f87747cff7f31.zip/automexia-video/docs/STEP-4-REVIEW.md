# Step 4 — implementation review and verification history

This log concerns the actual Video crate. It distinguishes source review, independent FFmpeg executions and unexecuted Rust regression tests. It is not an application security approval or a listening-test report.

## Pass 1 — core implementation and protocol experiments

Added the bounded per-channel energy analyzer, conservative proposal rules, existing project/review application, fixed native metadata stream, schema-2 settings snapshot and pause-only join envelopes. Existing media/source/persistence owners remain in place. Every new operation is pending, and analysis itself produces no files.

Direct FFmpeg experiments uncovered and corrected three concrete interoperability issues:

1. The initially tried pipe escaping in `ametadata` did not target stdout reliably. The fixed filter uses the documented `file=-:direct=1` route.
2. `astats` option flags use `Number_of_NaNs` / `Number_of_Infs`, while emitted per-channel metadata keys contain spaces. The Rust parser now expects the observed emitted spelling.
3. Integer PCM did not emit required floating-point validity counters. Converting the sample representation to `dblp` before statistics made those checks explicit, without downmixing or changing sample rate.

These were actual filter/protocol observations, not results from Rust execution. The captured metadata fixture records the final one-frame protocol.

## Pass 2 — timing, adverse signals and actual output

A direct container timing experiment found AAC at 44.1 kHz in Matroska could differ from adjacent sample ends by -7 samples despite legitimate 1-ms timestamp quantization. A fixed one-sample rejection policy was too strict for that container. The analyzer now takes the saved time-base resolution, caps admissible quantization to 1 ms plus one sample, rejects larger overlap and preserves real gaps. The report exposes rounding events and uncovered time. Dedicated supplied Rust regressions distinguish this from arbitrary backward time.

The first integrated independent suite ran 27 cases: **26 passed and one failed**. The failure was a test-fixture assertion: a 1-ms, high-amplitude pulse did not have the expected low frame RMS. The filter already preserved the transient. The fixture was corrected to a single-sample pulse at lower amplitude; it now explicitly exercises RMS below the quiet ceiling while peak remains above it. The threshold was not weakened to make the test pass.

The second suite expanded to **30 cases and all passed**. Added direct invalid-float observations, decoded flash/tone synchronization after fades, restored-duration output and a formant-synthesized speech recording with a deliberately inserted pause. This verifies exercised FFmpeg recipes; the Python fixture oracle is not the production Rust analyzer.

## Pass 3 — source, ownership and regression review

Source review corrected two further fail-closed details:

- Reject an unterminated final metric record, so a truncated numeric sample count is not mistaken for a shorter complete value.
- Compute whether a pause actually contributes to a removed gap by comparing authoritative timelines. A redundant pause wholly covered by a manual removal must not add a new fade to that unrelated cut.

Additional supplied Rust tests cover captured real metadata, every chunk boundary in a bounded two-frame record, stale/cancelled application, invalid settings, stream mismatch, protected/locked/rejected decisions, sample-grid rounding, exact fade counts, schema migration and recomputation.

All 19 foundation and 18 cut recipe regressions passed. A combined command reached its execution time limit partway through the preview suite; the preview suite was rerun separately and **all 23 passed**. This execution-envelope timeout was not counted as a product failure or silently as a passing incomplete run.

The current supplied Rust tests total **339**, including **83 new Step 4 tests** (70 core/13 native). A lexical delimiter scan found no mismatched brackets in the Rust files; that is not Rust parsing, compilation or typechecking. The actual Cargo/Rust commands both failed with “command not found”; [the attempt is retained](../reports/step4-cargo-attempt.txt). No Cargo result, compile success, or native Rust execution is fabricated.

## Final media and packaging review

Current independent results: **19 import/render + 18 cuts + 23 previews + 30 pauses = 90 passing checks**. Read [pause results](../reports/step4-media-final.json), [import regression](../reports/step4-regression-import.json), [cut regression](../reports/step4-regression-edits.json) and [preview regression](../reports/step4-regression-previews.json).

The final archive is extracted into a clean directory and each independent suite is rerun with result files outside that directory. Hashes, retained input paths and ZIP integrity are checked separately. The resulting external clean-extraction record accompanies the download. Prior edition reports remain historical snapshots, not current manifests.

## Not established by these passes

Rust build correctness; actual terminal registration/permissions or UI; native Windows/macOS behavior; a human-recorded speech release corpus; subjective listening quality; all codec/timestamp corner cases; real-world 6-hour or 8-channel performance; OS sandboxing; crash-proof filesystem publication under adversarial writers. No reviewer can certify all possible defects absent from an uncompiled program. Compile, run the supplied Rust/native tests and perform listening/camera-corpus qualification before production release.
