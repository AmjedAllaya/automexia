# Automexia Video — pre-AI modernization source candidate

**Version 0.12.0-rc.1 · Video Step 12 · `.amxv` schema 7 unchanged.**

One Rust Video extension core: non-destructive editing, reviewed analysis, framing,
supplied graphics/subtitles, rendering and editable interchange. This edition adds
targeted lifecycle, transport and observation-reuse changes before optional AI.
It does not introduce a terminal rewrite, plugin framework, model or new crate.

**This is source for integration, not a compiled plugin or qualified release.**
Rust/Cargo are unavailable in the delivery environment; Cargo tests and actual
Automexia/editor/platform tests are not claimed as passing. The independently run
FFmpeg media corpus does not execute the Rust implementation. Step 11's release
qualification remains open; Step 13 is not started.

## Start here

[Step 12 implementation](../STEP-12.md) · [Manual acceptance](../STEP-12-MANUAL.md) ·
[Quick start](../QUICKSTART.md) · [Integration](../INTEGRATION.md) ·
[Current scope](../SUPPORTED-SCOPE.md) · [Release requirements](../RELEASE-QUALIFICATION.md)

## What changed

- A private job registry owns admission, cancellation and explicit disable/drain.
  Whole-workflow leases prevent false completion between child stages.
- Opt-in source-observation caches reuse pause, voice and shot statistics while
  regenerating proposals against current decisions and rechecking source grants.
- The existing native process transport is isolated in a private module with
  bounded pipes and cleanup before scoped-reader joins.
- Native capabilities are memoized only after successful pinned discovery; every
  hit still rechecks both executable fingerprints.
- An optional one-slot progress bridge bounds UI progress accumulation. Outcomes
  and publication receipts are never substituted with progress events.

Existing project/media models, serializers, render plans, effects and interchange
writers remain unchanged. No host method, action ID, schema or dependency is added.
Cache APIs are optional; previous analyze calls remain uncached.

## Build and test

Generate and review a real Cargo.lock where the Rust toolchain and dependencies
are available. No lockfile or project license has been invented.

```bash
cargo generate-lockfile
cargo test --locked --no-default-features
VIDEO_TEST_FONT=/absolute/path/to/your.ttf cargo test --locked --features graphics
FFMPEG=/absolute/path/to/ffmpeg FFPROBE=/absolute/path/to/ffprobe \
VIDEO_TEST_FONT=/absolute/path/to/your.ttf cargo test --locked --features native
python3 -B tools/check_modernization.py
python3 -B -m unittest discover -s tests/modernization -v
python3 -B tools/qualify_release.py --source . --output /absolute/new-results-directory --suite all
```

The qualifier records missing requirements as blocked. Its logs and build output
stay outside the source checkout. [Current verification](../../reports/step12/verification.json)
and [review history](../STEP-12-REVIEW.md) distinguish executed source/media checks
from unexecuted Rust tests. A passing source hash is not application acceptance.

## Source delivery and limits

Use the [verified delivery process](../DELIVERY.md) with Step 12 / 0.12.0-rc.1.
The package contains no FFmpeg/compiler/font/model binaries. [Dependency and distribution
notices](../../THIRD-PARTY-NOTICES.md) retain the owner's unresolved public-release decisions.

Unsupported clip-to-clip dissolves, non-unit-speed editing, unqualified HDR,
hardware/shared-decode optimization and learned models remain explicitly outside
this candidate. Host UI/player ownership, permissions, real editor imports,
recorded-footage quality and cross-platform testing remain integration work.

Deleting the new memory cache loses observations only, never accepted edits.
Drain, join host workers and release player/cache handles before unloading or
rolling back. Existing schema-7 projects do not require migration.
