# Step 14B — Modern FCPXML and portable interchange bundles

**Package:** 0.14.0-alpha.2. **Status:** source implementation candidate. **Project schema:** 10, unchanged from Step 14A. Consult [current verification](VERIFICATION.md) and [Step 14B's machine-readable report](../reports/step14b/verification.json) for executed checks. Rust/native execution and actual editor import qualification must be distinguished from source review and reference tests.

This increment implements another bounded part of the [Step 14 advanced backlog](video-roadmap.md): a modern FCPXML writer and a portable interchange handoff containing the actual media referenced by an exported timeline. It builds on Step 14A's reviewed single-source assembly. It does not complete the full backlog, add multisource editing or change the saved `.amxv` schema.

## Modern FCPXML profile

`InterchangeFormat::FcpXml` produces `.fcpxml` using the FCPXML 1.10 vocabulary. It is separate from the existing `Fcp7Xml` `.xml` writer, which remains legacy `xmeml`. `TargetEditor::FinalCutPro` records intended destination software; it is not an assertion that a specific installed editor has imported the output successfully. JSON uses `fcp_xml` and `final_cut_pro`.

The modern writer emits explicit media resources, sequence format/timecode, a contiguous video spine and selected audio components. Normal-speed source ranges remain editable. Reordered and repeated ranges retain their occurrence boundaries. Point markers map through cuts and repetitions and are anchored in each containing clip's local clock. FCPXML represents native markers as one-frame point locations; exact mapped Automexia marker ranges remain in `org.automexia.marker-ranges` metadata and the compatibility report. Separate stems use their own audio resource; explicit video and audio components prevent accidental playback of both source audio and the stem.

Time values use exact rational seconds. Supported edit rates remain the deliberately bounded existing `EditRate` set; there is no decimal-rate guess or silent rounding. FCPXML wire times require nonnegative numerators and a denominator no larger than `u32::MAX`. Sequence audio rates are explicitly admitted at 32, 44.1, 48, 88.2, 96, 176.4 and 192 kHz. Selected audio must be known mono or stereo. Valid source-time audio gaps and component boundaries use exact clocks; a missing or unrepresentable clock fails explicitly.

Source and record timecode offsets remain distinct from media packet timestamps. Media URLs may be local file URLs or document-relative references. Text is escaped as XML data, including attribute whitespace, and unrepresentable XML characters are rejected. A conservative escaped-size estimate rejects known oversized documents before optional media baking; it can reject near-limit documents that would otherwise fit the exact serializer limit. The complete compatibility report remains embedded in the document. The format declaration alone is not an editor-import test.

| Feature | Modern FCPXML behavior |
|---|---|
| Normal-speed cuts, source range repeats and reordering | Separate editable occurrences |
| Selected source video/audio | Explicit media references and stream provenance |
| Matching original audio | Explicit components using the referenced media clock |
| Separate prepared audio stem | Separate audio asset with original audio excluded from playback |
| Missing audio or explicit omission | No invented audio track |
| Source point markers | Mapped onto exact frame-grid locations in containing clip clocks |
| Source ranged markers | Native point plus exact mapped range retained in namespaced metadata/report |
| Constant per-entry/global retiming | Requires explicit visual bake |
| Cross-dissolves | Requires explicit visual bake in this restricted XML profile |
| Active framing, color, graphics and burned captions | Requires explicit visual bake |
| Active audio processing | Requires an explicit stem or a rendered variant, unless omitted |
| Active unresolved review decisions | Blocks the selected export |
| Unsupported media interpretation or clocks | Explicit failure or blocking compatibility item |

The existing source-reference restrictions still apply: verified whole-source CFR timing, explicit progressive SDR interpretation, one selected source and supported stream layouts. Existing render and native runtime gates apply to any requested bake.

## One portable ZIP64 handoff

`BundleRequest` selects a `.zip` destination, OTIO or modern FCPXML, variant, title, edit rate, timecode offsets, markers and explicit video/audio modes. The archive contains:

```text
timeline.otio                  or timeline.fcpxml
Media/<full-sha256>.mov        actual referenced media, with a supported suffix
Media/<full-sha256>.wav        only when a separate referenced stem is needed
compatibility.json
manifest.json
```

These names describe archive members, not standalone extra files published alongside the ZIP. The plan retains each inspected source `InputFile` unchanged and rebuilds typed timeline URLs to `Media/...`. It never pretends that a copied file already exists, and it does not patch serialized XML or JSON text to substitute paths.

The source route copies complete referenced files, including unselected handles outside the exported cuts. Source audio and video referencing the same file share one copied media entry. Identical content with multiple allowed names is deduplicated by full SHA-256 and byte count, with deterministic naming. Every inspected alias remains in the plan and manifest and must be revalidated. Differing stamps for one path, conflicting file identities or inconsistent sizes for one digest are rejected.

The three metadata entries are deterministic for the same request, workspace binding and inspected identities. `manifest.json` lists every other entry with its SHA-256, byte count, kind and original media identities. It excludes its own digest to avoid self-reference; the plan exposes the manifest digest, and the publication outcome exposes the complete archive digest. `compatibility.json` records the bundle request and the exported timeline's complete compatibility report.

## Explicit media choices

| Request choice | Result |
|---|---|
| `BundleVideo::Source` | Copy the selected verified original video reference |
| `BundleVideo::Bake` | Render the selected variant to private `Media/video.mov`, then copy its validated result into the archive |
| `BundleAudio::Source` with source video | Retain the selected original audio reference |
| `BundleAudio::Source` with baked video | Use the rendered variant's audio in that same baked file |
| `BundleAudio::BakeStem` | Create private `Media/audio.wav` and reference that selected timeline-aligned stem |
| `BundleAudio::Omit` | Explicitly omit timeline audio; the report discloses the choice |

The bundle request has no external bake destinations and no replacement policy. Every bake is created inside the one lease's private workspace. A failure before archive publication drops that workspace; there is no partial public bundle or independently published bake to clean up. Standalone interchange exports retain their existing, separately requested bake behavior.

## Bounds and transaction

| Bound | Portable profile |
|---|---|
| Container | Stored ZIP64, no compression or encryption |
| Public publication | One create-new file; an existing destination is never replaced |
| Portable timeline formats | OTIO and modern FCPXML |
| Complete archive limit | 64 GiB by default; explicit limit greater than zero and at most 512 GiB |
| Size accounting | Media, metadata, local/central headers and ZIP64 end records |
| Entry count | At most 16; current single-source profile normally uses four or five |
| Aggregate static metadata | At most 16 MiB |
| Member paths | At most 240 ASCII bytes; no traversal, drive prefix, control bytes, backslashes, URI escapes, reserved device names or case collisions |
| Media suffixes | `mov`, `mp4`, `m4v`, `mkv`, `webm`, `wav`, normalized to lowercase |
| Host limits | Existing native input/output limits can be stricter than the requested archive budget |

Pure assessment performs no filesystem access. Execution enters the existing admitted Video job, checks the selected project and source, acquires one archive/workspace lease, prepares selected media, builds the immutable bundle plan, streams each entry with bounded reads and cancellation checks, validates hashes and revalidates inputs before the exclusive commit. The native adapter uses the existing single-file output lease instead of a racy check-then-rename directory transaction.

A progress callback can cancel or change a file, so final source, reference, output and destination guards run after the last callback. An error before commit leaves no public archive. Once publication succeeds, a failed read-back or later cancellation is reported as `PublishedUnverified`, with the published path retained, rather than as an ordinary retryable failure.

## Host integration

The existing `InterchangeHost` supports standalone assessment/export. The new `BundleHost` adds `stage_bundle`, returning a `BundleLease` that owns an existing private workspace and the final create-new transaction. `NativeMediaHost` implements the lease using existing file identity and output ownership controls. No new shell language, arbitrary tool arguments, global worker service or automatic editor launch is introduced.

Use the pure assessment before execution:

```rust,ignore
use automexia_video::{
    assess_bundle, BundleAudio, BundleRequest, BundleVideo, Cancellation,
    EditRate, InterchangeFormat, TargetEditor,
};

let mut request = BundleRequest::new(
    project_path,
    handoff_zip_path,
    InterchangeFormat::FcpXml,
    EditRate::new("30000/1001".parse()?, false)?,
);
request.target = TargetEditor::FinalCutPro;
request.variant = "main".into();
request.video = BundleVideo::Source;
request.audio = BundleAudio::Source;

let assessment = assess_bundle(&project, &request)?;
if !assessment.blocked() {
    let outcome = extension.export_bundle(
        &project, &request, &Cancellation::new(), &mut |_| {},
    )?;
    // Present outcome.status, destination, compatibility and any error.
    // PublishedUnverified already has a public file; do not blindly retry.
}
```

This is an integration fragment, not an installed command-line interface. `RegisteredVideo::dispatch_interchange` and `dispatch_bundle` expose typed assessment/export commands. `OptionalActions::portable_bundles` lets the host register `video.export.bundle` only when it supplies the archive lease capability. Lifecycle, cancellation and existing registry cleanup remain authoritative.

## Opening the handoff

Extract the complete archive into one directory using a ZIP64-capable extractor. Verify the complete ZIP digest from the publication outcome when one is available, then verify each manifest entry's byte count and SHA-256. Open `timeline.otio` or `timeline.fcpxml` from that directory. Keep the `Media` directory beside it. Opening the timeline while it is still inside a ZIP is not supported by this handoff contract.

The playable references are relative, so the extracted directory can be moved together. Compatibility metadata deliberately retains authored names, the original project decisions, original paths and private bake paths for provenance. Review that information before sharing.

This is a portable **interchange handoff**, not a full `.amxv` backup. Graphics, fonts, models, enhancement intermediates and other project assets are included only through rendered media when the selected bake uses them. Sidecar-only subtitles are not automatically added. Preserve the original project and its assets separately if later source-project editing is required.

## Verification and remaining work

[Step 14B review](STEP-14B-REVIEW.md) records the review findings and validation layers. [Current verification](VERIFICATION.md) and retained machine-readable reports state which checks actually executed. Rust tests and native transaction tests are meaningful executable specifications, but source review and Python/reference checks do not establish that those Rust tests passed.

Before qualifying deployment, compile and run the required Rust/native suites with the supported toolchain and FFmpeg/ffprobe runtime, exercise actual host actions on supported platforms, and import representative extracted bundles into each claimed editor/version. `application_import_tested` remains false until an actual qualification process changes the claim.

Multisource/multicamera editing, continuous speed ramps, speaker-aware editing, tracking, segmentation and the remaining optional Step 14 items remain outside this increment.
