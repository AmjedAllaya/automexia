# Step 3 — review passes and actual verification

This record concerns the real **Video** Rust core. It does not count the earlier Kubernetes/Python prototype as implementation. Rust source review is not called Rust compilation or execution.

## Pass 1: implement and exercise the media recipes

Implemented project-backed list/detail review, transactional decisions and locks, bounded original/proposed proxy planning and execution through MediaHost, private temporary leases and a host-approved opener. Prepared 63 core and 16 native Rust tests, but could not execute them because `cargo`/`rustc` were absent.

An initial partial FFmpeg run recorded eight passing cases and a failed portrait assertion before an outer execution timeout interrupted it. Investigation showed that the **test fixture** had no display-rotation metadata: writing a legacy output rotate tag did not create the intended rotated input. The test now uses the explicit input `-display_rotation:v:0 90` option for a stream-copy fixture and checks that metadata before testing the proxy. This was a fixture correction, not a claim that the Rust adapter had failed at runtime.

The completed first media pass then passed all 19 cases. [Partial finding](../reports/step3-initial-review.json) · [Completed pass](../reports/step3-media-pass1.json).

## Pass 2: source review and missing behavior

Source-path review found and corrected these gaps before packaging:

- A second preview request with a different focus could share the same view/operation identity as the earlier one. Added latest-request tickets, request-specific cancellation and acceptance checks so a late result cannot replace the current requested view.
- Proxy planning always used the first saved output variant. Added explicit `variant_id` selection and bound it into request identity; unknown variants are rejected.
- Detail text could list the selected pending operation as omitted even while showing its hypothetical applied duration. Excluded the selected operation from that list and retained explicit disclosure for other pending edits.
- Locked generated decisions needed consistent protection semantics between duration inspection and preview. A locked applied operation retains its semantics; an inactive/pending locked operation cannot be hypothetically enabled through the apply-selected route.
- Review view construction was moved before the state commit so a failed projection cannot leave a half-applied action. Range changes invalidate the old operation approval; original generator attribution remains.
- Preview leases needed a `Send` bound for worker-to-host ownership handoff. Added the bound rather than assuming a thread-affine custom lease can move safely.
- The request hash was renamed from cache key to request key. Runtime identity and encoded digests are separate, and no persistent cache is claimed.
- Added accurate messages for current-resolved versus apply-selected preview intent, and clarified that explicit manual approval differs from generator-only protection rules.

These are findings from reading/tracing the implementation, not failed Cargo test observations. Regression cases were added for them. One test draft used the wrong saved-frame-policy enum name; it was corrected to the existing `FrameRateMode` before delivery.

Expanded to **73 core review tests and 20 native review tests**, all supplied and still unrun. Expanded independent media checks to **23**, adding source-start/source-end windows, a one-frame playable output and stereo 44.1 kHz preservation. That completed pass passed all 23. [Second media pass](../reports/step3-media-pass2.json).

## Pass 3: regression and delivery review

Reran the existing independent foundation and cut checks: **19 + 18 passed**. Strengthened the new rotation test to compare decoded pixels after proxy downscaling, not only dimensions/metadata, and retained source-template/golden-argument comparison.

Reviewed host handoff, original-source protection, unpublished lease ownership, stale project/source/file rejection, no-media results, progress interpretation, cancellation and scope claims. Default/native Cargo commands and a native integration example are supplied, but the current environment cannot run them. [Compiler attempt](../reports/step3-cargo-attempt.txt).

Final media results are [step3-media-final.json](../reports/step3-media-final.json), [foundation regression](../reports/step3-regression-media-step1.json), and [cut regression](../reports/step3-regression-media-step2.json). They exercise generated encoded files with FFmpeg, not the Rust binary. Package integrity and clean-extraction reruns are additional delivery checks, not extra feature tests.

## No false completion claims

The source implements Step 3 within the same crate, with your adjustable host integration boundary. It remains **uncompiled and type-unchecked here**. The 256 supplied Rust tests, actual terminal UI/player/focus behavior, Windows/macOS operation, listening quality and full source-camera coverage are not reported as passing. None of the media tests proves those layers indirectly.

The appropriate next validation is to build and run the Cargo suites and the native `review_smoke` example, then wire the existing host surfaces and opener. No new terminal architecture, Python product runtime, AI model or public extension framework is a prerequisite.
