# Documentation index — Step 14B

Current package **0.14.0-alpha.2** writes `.amxv` schema **10**. This uncompiled source candidate continues Step 14A with portable OTIO/FCPXML bundles and modern FCPXML 1.10. Read current verification limits before using historical counts.

| Purpose | Document |
|---|---|
| Current portable export scope and workflow | [Step 14B](STEP-14B.md) |
| Retained reviewed assembly | [Step 14A](STEP-14A.md) |
| Optional backlog and increment index | [Step 14](STEP-14.md) |
| Implementation review and remaining gates | [Step 14B review](STEP-14B-REVIEW.md) |
| Retained Steps 0–13 implementation and gaps | [Previous phase review](STEPS-0-13-REVIEW.md) |
| Current implementation scope | [Supported scope](SUPPORTED-SCOPE.md) |
| Build, runtime and first output | [Quick start](QUICKSTART.md) |
| Existing-host registration and adapters | [Integration](INTEGRATION.md) |
| Project data and migrations | [AMXV format](AMXV-FORMAT.md) |
| Optional local model workflows | [Step 13](STEP-13.md) |
| Model manifests and storage | [Model packs](MODEL-PACKS.md) |
| Higher-quality speech enhancement | [Step 13C](STEP-13C.md) |
| Concrete UltraFace and explicit choices | [Face provider](FACE-ONNX.md) |
| Graphic/caption placement | [Placement](PLACEMENT.md) |
| Transcription | [Transcription](TRANSCRIPTION.md) |
| Global speed and dissolves | [Timing](TIMING.md) |
| Restricted HDR preservation | [HDR preservation](HDR-PRESERVATION.md) |
| Interchange scope | [Interchange formats](INTERCHANGE-FORMATS.md) |
| Executed versus blocked checks | [Verification](VERIFICATION.md) |
| Repeating all automated layers | [Release qualification](RELEASE-QUALIFICATION.md) |
| Source archive verification | [Delivery](DELIVERY.md) |
| Original requirements and advanced backlog | [Roadmap](video-roadmap.md) |

Step 0–13 guides and review files, `reports/alpha5/`, older `reports/step*`, `reports/handoff/` and `docs/history/` describe their named editions. Historical schema/scope statements do not override the current Step 14B guide and do not count as fresh execution. The original roadmap remains the requirements baseline.
