# Step 13 primary contracts and implementation choices

The source of product scope is the retained [Video roadmap](video-roadmap.md#step-13--add-optional-local-intelligence-one-capability-at-a-time).
This edition implements initial 13A and 13B only. Thresholds, explicit-channel
policy, conservative veto-only behavior, structural guard and resource bounds are
local implementation choices, not claims copied from upstream accuracy results.

Primary implementation API references checked on 11 September 2026:

- [Silero upstream streaming wrapper](https://github.com/snakers4/silero-vad/blob/master/src/silero_vad/utils_vad.py): 16 kHz, 512-sample calls, 64-sample context and recurrent state conventions. The mutable source link is a contract reference, **not** a selected immutable model revision or asset checksum.
- [ort 2.0.0-rc.10](https://docs.rs/ort/2.0.0-rc.10/ort/): exact Rust API candidate; not an assertion that this is the latest release.
- [EnvironmentBuilder](https://docs.rs/ort/2.0.0-rc.10/ort/environment/struct.EnvironmentBuilder.html) and [init_from](https://docs.rs/ort/2.0.0-rc.10/ort/environment/fn.init_from.html): explicit dynamic library setup, initialization ownership and telemetry configuration.
- [SessionBuilder](https://docs.rs/ort/2.0.0-rc.10/ort/session/builder/struct.SessionBuilder.html): CPU/default execution path, threading and in-memory model loading.
- [RunOptions](https://docs.rs/ort/2.0.0-rc.10/ort/session/run_options/struct.RunOptions.html): termination request is cooperative, not a hard process-kill guarantee.
- [Session](https://docs.rs/ort/2.0.0-rc.10/ort/session/struct.Session.html) and [SessionOutputs](https://docs.rs/ort/2.0.0-rc.10/ort/session/output/struct.SessionOutputs.html): named tensors, execution and output inspection.
- [ONNX protobuf schema](https://github.com/onnx/onnx/blob/main/onnx/onnx.proto): external tensor surfaces, graph/attribute recursion and operator domains for the bounded guard.

No trained weights, original recordings, ONNX Runtime distribution or third-party
license approval is supplied by these references. No quality numbers are inferred
from a model's reputation. The exact deployment must be pinned and tested by the
component owner as described in [MODEL-PACKS.md](MODEL-PACKS.md).
