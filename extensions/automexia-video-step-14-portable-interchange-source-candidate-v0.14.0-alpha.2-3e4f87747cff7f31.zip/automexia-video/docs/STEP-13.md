# Step 13 — optional local intelligence

**Edition:** 0.13.0-alpha.5. **Project:** schema 9. This continuation supplies source implementations for 13A–E, including concrete optional providers and their workflow connections. It has not compiled or executed Rust/model code in the current environment. The whole product milestone remains unqualified.

[Phase review](STEPS-0-13-REVIEW.md) · [Current evidence](../reports/alpha5/verification.json) · [Model packs](MODEL-PACKS.md) · [Qualification](RELEASE-QUALIFICATION.md)

## Scope by substep

| Substep | Source implementation | Remaining evidence |
|---|---|---|
| 13A model packs | Strict manifests and bounded format guards; immutable verified bytes; generation-checked persistent install/select/update/revoke/remove; native advisory locking | Compile storage adapters, run native/race tests and connect approved host component operations |
| 13B speech protection | Selected-channel PCM, optional pinned Silero ORT provider, bounded recurrent inference, speech veto of existing energy proposals | Execute selected graph/runtime; annotated speech-loss and pause-quality evaluation |
| 13C enhancement | Reviewable enhanced PCM receipt, concrete FFmpeg RNNoise provider, timing/latency handling, output/stem integration | Actual model/provider execution with required runtime; representative backend comparison and blind listening |
| 13D faces | Concrete UltraFace RFB-320 ORT provider, conservative tracking and crop proposals, explicit anchor/punch-in adoption, complete-layer collision checks | Selected graph/runtime execution and representative visual/crop-quality review |
| 13E transcription | Pinned whisper.cpp provider, bounded transcription, editable words/provenance/uncertainty/locks, search, subtitles, chapters and reviewable filler/punch-in proposals | Actual executable/model integration, timing and representative recognition-quality review |

Models observe; typed Rust workflows validate and propose; the host grants access and owns lifetimes; FFmpeg renders; the user reviews uncertain edits. None of these optional providers is loaded by ordinary construction/status or selected automatically.

## Public workflow connections

- `ModelStore` and `NativeModelStorage` provide explicit verified pack lifecycle operations. A generation mismatch, revoked activation or removed selection does not silently substitute another model.
- `VideoExtension::analyze_speech_pauses` adds model evidence to existing quiet-interval proposals. It cannot authorize fresh deletion from a speech score alone.
- The enhancement workflow produces a verified local PCM result for review and later accepted rendering. See [Step 13C](STEP-13C.md).
- `VideoExtension::analyze_faces` returns a report. `apply` proposes framing; `apply_choices` accepts explicitly selected framing/anchor/punch-in choices and leaves changed decisions pending. See [UltraFace and face choices](FACE-ONNX.md).
- `VideoExtension::transcribe` returns a source/model-bound transcript report. Adoption, correction, subtitle installation and editorial suggestions use project/review transactions. See [transcription](TRANSCRIPTION.md).
- `VideoExtension::analyze_placement` connects non-model luminance/edge/activity measurements to typed overlay/caption anchors. See [placement](PLACEMENT.md).

Reports are bound to source and project state, relevant settings, selected model identity and the owner lifetime. Changing those prerequisites invalidates adoption. Mutable report diagnostics are not permission to bypass private validated observations. Accepted edit metadata remains ordinary saved project state, independent of later model availability.

## Dependencies and runtime boundary

`native` selects filesystem/media implementations. `silero-onnx` selects exact-pinned `ort`/`ort-sys` 2.0.0-rc.10 with dynamic loading, and `face-onnx` adds the face provider through that same dependency boundary. No build-time model/runtime download feature is enabled. Native model storage adds optional `fs2` 0.4.3. JSON uses `float_roundtrip` for stable persisted finite values.

The host supplies approved canonical tool/model/runtime files and expected identities. Native media execution reuses the existing restricted runner; the module does not create a new unrestricted process service, scheduler, model marketplace or terminal UI. The actual Automexia install/discovery contract was not provided and is not invented.

## Qualification boundary

The fresh continuation ran Python tooling and independent media/reference recipes. Installed FFmpeg 6.1.1 is below the required native 7.1 minimum. Rust/Cargo, reviewed selected-model assets and reachable compiler download routes were absent; no Cargo.lock or model inference result is fabricated. Missing espeak affects speech fixture cases and is explicitly BLOCKED.

The presence of provider source or deterministic fixture detections is not evidence of learned inference. Inference success is not evidence of perceptual quality. Step 11/12 host/platform/resource gates and the relevant model quality studies remain open alongside this step. `step13_complete` and release qualification flags remain false.

The [original roadmap](video-roadmap.md) remains the requirements baseline. Step 14 features such as diarization, active-speaker inference, arbitrary object tracking, richer speed ramps and broader editor formats are not silently included in Step 13.
