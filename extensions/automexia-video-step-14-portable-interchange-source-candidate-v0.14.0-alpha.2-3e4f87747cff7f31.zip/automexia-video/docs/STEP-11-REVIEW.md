# Step 11 review history

## Pass 1 — source and baseline

The exact Step 10 handoff archive was CRC/hash checked before extraction. It had
no Cargo.lock. Rust/Cargo and resolvable package hosts were unavailable, so no
compilation/test claim was made. Source review found the undefined subtitle
`media_guard` call, unbound extension-created reviews and teardown cancellation,
and blocking/following Unix file revalidation. These received actual source fixes
and Rust regressions, whose execution remains pending.

The initial qualification-runner suite passed 30 cases. The complete independent
media run passed all 354 individual cases: the existing 338 plus 16 new failure/
resource cases. The first aggregator nonetheless correctly finished **failed**
because it did not recognize the retained voice suite's boolean case-status shape.
That aggregator result is retained unchanged under pass1; it is not rewritten
into a fabricated all-green original run.

## Pass 2 — negative cases and fixes

Ten additional adversarial cases (40 total with the original suite) produced
eight assertion failures and two errors. Duplicate report keys, nonfinite report
numbers, report symlinks and conflicting case arrays were accepted; build.rs,
Cargo configuration and toolchain selection were absent from source identity;
oversized logs were rejected but not truncated for retained evidence. Those eight
issues were fixed. A top-level JSON list caused an unhandled AttributeError and
now fails as a typed validation error. A missing source directory was already
rejected with FileNotFoundError; its exception was normalized, not misrepresented
as a previously allowed missing directory. The integrated 40-case suite passed.

The actual voice-report integration gap was fixed with strict support for either
its boolean `passed` or the other suites' `status`. Conflicting values, truthy
strings and false rows are refused. Sample identities were added to source
tracking. All 45 tests passed, and the actual saved voice report revalidated.
All 58 existing packaging regressions passed. The 16 new independent failure and
resource recipes passed a second execution.

Native review added pre-spawn cancellation/deadline checks, symlink rejection in
staged-file monitoring, and one regular-file/bounded-read implementation shared by
fingerprinting, project loading and graphic/font reads. This removes the related
blocking second-open paths without adding a public host API or claiming a sandbox.
The added native/core source has 32 Rust test declarations; none is claimed run.

## Pass 3 — exact source candidate and fresh extraction

The final runner suite passed 45 tests again after the source review. Current
Cargo, policy, README, integration, scope, verification and CI identity now agree
on Step 11 / 0.11.0-rc.1. Stale Step 9/10 status text is explicitly historical.
Fourteen relative links in the relocated historical README initially failed
local validation; they were rebased and the complete local-link check passed.
CI syntax is parsed, not represented as a remote workflow run. Project schema 7
and existing dependency declarations stay unchanged.

The existing source packager is used to build, CRC-check, hash-check and freshly
extract the immutable ZIP, and its `links` command reopens the final artifacts.
The exact post-extraction suite results and source hashes are recorded in the
external final verification file after they actually finish; the archive cannot
contain a self-referential hash of itself. A blocked compiler remains blocked even
when all independent media and developer-tool tests pass.

[Current verification](../reports/step11/verification.json) ·
[Qualification procedure](RELEASE-QUALIFICATION.md)
