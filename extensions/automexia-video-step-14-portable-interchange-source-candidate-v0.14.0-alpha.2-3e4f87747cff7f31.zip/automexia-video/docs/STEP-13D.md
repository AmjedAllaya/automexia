# Step 13D — optional face framing and placement

**Current source candidate: 0.13.0-alpha.5; project schema 9.** This revision rebuilds and extends the implementation from the reattached alpha.3 archive. Earlier-turn alpha.4 test totals are not evidence for this source revision. See `reports/alpha5/verification.json` for fresh execution status.

The optional face workflow connects a selected detector to the existing framing and presentation models. A concrete UltraFace RFB-320 CPU provider is implemented under `face-onnx`; the pure detector interface also permits a separately qualified YuNet provider. No YuNet native provider is implemented here. Model absence leaves manual framing, saved crop tracks, supplied captions and rendering available.

`VideoExtension::analyze_faces` decodes one bounded display-oriented RGB stream, samples source timestamps, and emits advisory normalized face rectangles. Deterministic Rust validates confidence and box bounds, associates tracks with overlap/center/size consistency, expires missed tracks, resets association at known cuts, and selects reliable individual subjects or nearby groups. It does not recognize identity, classify demographics, or determine who is speaking.

The selected sample interval is 80–2,000 ms, with a 250 ms default. A request is limited to 2,048 detector calls, 64 detections per sampled frame and 128 tracks. The first available frame of each saved source/crop shot is included. Source-relative timestamps must be representable on the original source clock. Crop-key timestamps come from actual observations rather than off-grid arithmetic midpoints.

Generated framing preserves the target, saved safe zone, motion limits, dead zone and scale budget. No-face scenes retain their existing saved crop keys; a Fit proposal stays Fit if any scene lacks sufficient observations. Generated motion is checked against the saved derivative limits. A failed proposal keeps a conservative static shot or the saved framing rather than changing those limits. Margins and headroom are measured on sampled face rectangles and diagnosed explicitly when the target cannot include them.

The report includes qualified whole-shot punch-in candidates only where sampled evidence covers a single subject throughout the shot, contains no missed-face samples, lasts at least one second, and retains face margins/headroom in a zoom no greater than 1.08 relative to the proposed framing. The baseline framing reserves available headroom for this optional choice. A range is a review suggestion, not proof about unsampled frames.

Face avoidance examines every accepted face observation during a graphic's visible lifetime, including actual caption cue ranges. It tests all nine anchors using actual crop geometry and complete graphic animation envelopes. Typed targets distinguish a real caption layer from an overlay whose ID happens to be `captions`. Missing observed coverage supplies no safe anchor, rather than silently claiming success.

`FaceFramingReport::apply` adopts ordinary pending crop keys. `apply_choices` accepts explicit `FaceApplyChoices` for framing, selected anchors and qualified punch-ins. The workflow revalidates all choices against the final framing, checks all relevant shots, and rejects newly introduced layer collisions. Locked framing/presentation stays locked. The full selection commits atomically in one project revision and all modified layers remain `NeedsReview`; normal review and preview actions approve the result later.

Reports retain private observations, settings, original project decision digest, activation and owner lifetime. Application recomputes from this evidence. Editing public report diagnostics cannot authorize another crop, anchor or punch-in. Project changes, extension disable/cancel-all and model revocation invalidate unapplied reports. Completed job cleanup does not invalidate a still-owned report. Approved project framing remains usable after unloading the model.

Diagnostics include sample/detection/track counts, missing-face samples, sampled clipping, center jitter and safe-anchor coverage. Manual correction count is `null` until a human evaluation measures it; zero is not invented. Runtime/quality deployment qualification is separate from reference arithmetic and synthetic-detector integration tests.

See [FACE-ONNX.md](FACE-ONNX.md) for exact model, preprocessing, tensor and runtime contracts; [PLACEMENT.md](PLACEMENT.md) for model-free thumbnail placement; and [STEP-13D-MANUAL.md](STEP-13D-MANUAL.md) for host and human acceptance work.
