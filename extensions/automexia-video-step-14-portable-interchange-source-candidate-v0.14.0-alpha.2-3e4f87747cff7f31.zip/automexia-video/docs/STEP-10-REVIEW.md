# Step 10 review and verification history

This record distinguishes source inspection, executable independent reference/media checks, and Rust/application tests. It does not convert a supplied Rust test into an executed one.

## Pass 1 — Implementation and first real-media checks

The exporter was implemented in the existing crate with a common exact timeline, three serializers, source-bound CFR evidence, cold compatibility assessment and ordinary host job/publication ownership.

Source review found that Unix backslashes in media names were being treated as separators. URI encoding now preserves them as `%5C`. Review also found original OTIO audio/video items used inconsistent link-group IDs; they now share the stable clip identity. Original audio bit depth is no longer fabricated as 24-bit in FCP7 file metadata.

The first independent interchange suite ran **33 checks: 32 passed, 1 failed**. The failed case exposed a WAV probe routed through the generic video-only format whitelist. The test now uses an unrestricted test probe for WAV; the Rust implementation was separately corrected to use its existing typed `AudioTask::ProbeStem`. No extra media format or arbitrary process API was added.

## Pass 2 — Corrections and regression expansion

The repeated independent suite passed **33 of 33**. It includes actual decoded-frame PTS, VFR rejection, timecode boundaries, three reference-format readers, reconstruction of exact selected video frames/audio samples, explicit ProRes media, PCM stem, corrupt input and cancellation.

Further source review tightened publication so **every actually referenced video/audio file** is fingerprint-checked before commit. Protecting only filenames was insufficient for a changed baked output. Whole-source timing scans now include the existing allocation/protocol/format restrictions. Native test declarations exercise source changes at the publishing boundary.

The EDL report now correctly classifies explicit audio omission rather than pretending an omitted volume/voice stage was baked. Baked audio availability is measured; a shorter tail does not justify inventing unavailable samples. Mapped-marker growth is checked before allocation expands past its bound.

## Pass 3 — Full prior regression and finalization

A final source review rejected extra compact-output columns, repeated delimiters and malformed PTS tokens; retained one documented trailing delimiter; checked empty editor-version strings; and added explicit information-sharing warnings because complete project metadata contains paths and authored text.

The packaging review found 12 relative links broken by moving the preceding README into `docs/`. Their targets were rebased and the complete local link check was repeated before final delivery.

A last manual API review found the new native publication-race test used `Stage` without importing it; that missing import was fixed before the final rebuild. This was a source-review finding, not a compiler result.

Additional core/native declarations cover missing frame interpretation, HDR metadata, unknown audio sample rate, output aliases, timecode wrap and unchanged unsaved projects. Windows path declarations are supplied but not run on this Linux environment.

All **303 retained media checks and 33 new interchange checks** passed in the full regression run. **58 existing packaging regression tests** passed. The actual report files, environment and test inventory are in [verification.json](../reports/step10/verification.json). Final archive extraction/repetition is recorded externally so it cannot create a checksum cycle inside the ZIP.

## What these results do not establish

Rust/Cargo are absent. The Rust crate, optional graphics/native builds and the new Rust tests were not compiled or run. The independent scripts use expressly labeled Python reference serializations and real FFmpeg; they do not execute the Rust serializer. The native example and CI path are prepared to generate actual Rust output, but no remote CI run is claimed.

OpenTimelineIO's Python SDK is absent; its import check is recorded as not run. No Resolve, Premiere or Final Cut application was run. None of those families or versions is qualified by this delivery. XML well-formedness, reference readback and decoded-media correspondence are useful separate evidence, not full editor compatibility.

No terminal code, plugin loader, server, database, model runtime or network authority was added. The outstanding Step 8 effects and Step 9 optimization limits remain explicit.
