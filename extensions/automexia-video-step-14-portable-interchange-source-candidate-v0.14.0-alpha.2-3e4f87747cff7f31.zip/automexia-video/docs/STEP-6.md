# Step 6 — scene detection and conservative SDR color correction

**Crate:** `automexia-video` 0.6.0. **Roadmap:** Video Step 6 only. **Delivery:** source implementation in the existing single crate, independent FFmpeg/pixel tests, and host-adapter instructions. **Build qualification:** Rust/Cargo are unavailable in the execution environment; Rust compilation, typechecking, formatting, Clippy and Cargo tests have not run. Independent media checks do not execute the Rust implementation.

[Video roadmap](video-roadmap.md#step-6--add-scene-detection-and-conservative-color-correction) · [Settings and saved decisions](../src/color.rs) · [Analyzer](../src/color_analysis.rs) · [Workflow](../src/color_workflow.rs) · [Render plans](../src/color_render.rs) · [Review findings](STEP-6-REVIEW.md) · [Verification](VERIFICATION.md)

## 1. What this step implements

| Requirement | Implementation | Qualification boundary |
|---|---|---|
| Shared low-resolution visual analysis | One display-oriented RGB stream, original PTS and every decoded frame; histogram, luminance, clipping, channel, neutral-patch and activity measurements in one accumulator | No thumbnail frame sampling or repeated decode for each statistic. Rust accumulator tests supplied; actual FFmpeg protocol/pixels exercised independently. |
| Shot boundaries | Combined histogram and pixel difference, exact user-supplied known boundaries, one-frame white-flash exclusion, complete contiguous shot coverage | Signal-based cuts, not semantic recognition or a claim to detect every visually similar edit. |
| Conservative SDR corrections | Bounded exposure, gamma, contrast, restrained saturation, user-confirmed neutral-patch balance and explicit manual controls | All non-identity results require review. No face analysis, gray-world assumption, learned model or automatic artistic grade. |
| Stable corrections within a shot | One fixed adjustment per shot, applied before source-time selection/remapping | Constant parameters eliminate analysis-driven gain pumping. Gradual relighting is not tracked; unstable shots are normally preserved. |
| Explicit HDR/interlace policy | Strict color eligibility and decoded-frame checks; no silent bit-depth/range/transfer reinterpretation | HDR preserve/remux, HDR color edits, tone mapping, Dolby Vision and deinterlacing are NOT implemented. |
| Reversible projects, review and output | Schema 4, source-bound report, pending/approved/rejected/locked shots, bypass, original/proposed previews, existing guarded render publication | Native host UI/player/permission integration and Rust execution remain unverified. |

No terminal code, loader, scheduler, graphics API, player, public SDK or new runtime dependency is introduced. FFmpeg/ffprobe remain approved external tools. Python in `tests/media` is only an independent test harness.

## 2. Analyze once, without changing the project

`VideoExtension::analyze_color` validates the supplied project and settings, checks the selected source identity, re-probes current media, verifies the runtime's relevant capabilities, and requests a bounded video stream on the existing host worker. It revalidates the source after successful decoding. It does not save a project, cache frames, create output footage or run any model.

The new optional `MediaHost::stream_video_frames` method is default-denied. `NativeMediaHost` implements it using the existing identified executable and bounded process runner. Arguments are typed; there is no raw shell construction. The native adapter drains raw RGB on stdout and named `showinfo` diagnostics on stderr. A bounded correlator pairs them without assuming which pipe becomes readable first.

Frames carry exact absolute presentation times in the original video's time base, not ffprobe's rounded display seconds. Automatic orientation is applied before analysis. Scale geometry respects displayed aspect ratio, including non-square pixels and orthogonal rotation, without deliberately upscaling a small source. The RGB analysis raster has square pixels. Full-frame-rate decoding retains one-frame shots; it costs more than sampling and is explicitly bounded.

The pure analyzer retains two frame records for previous/pending lookahead, one shot accumulator and a bounded vector of finished shot summaries. It accumulates 32-bin luma and 64-bin RGB histograms, gamma-encoded and linear-light means, luminance quantiles, channel extrema, clipped/dark fractions, saturation, temporal variation, pixel change and optional neutral-patch statistics. Per-frame histograms and pixels are not written to `.amxv`.

### Native stream failure handling

Source frames must remain progressive 8-bit YUV with the expected Rec.709 interpretation and **the initially selected range**. A limited-to-full range switch is rejected even if the other color tags stay unchanged. HDR/Dolby Vision side information is rejected. RGB size, format, exact timestamp order, frame sequences, source-tag records and final payload completeness are checked.

Invalid input, unmatched-frame overflow, incomplete/truncated metrics or RGB, missing final duration, failed decode, changed source, cancellation or callback failure cannot produce a successful partial report. The pure accumulator and pipe correlator remain failed after an error. Custom adapters must propagate decoder failure rather than presenting a truncated stream as complete.

## 3. Scene detection and flashes

A boundary requires both a sufficiently different image histogram and pixel difference. The defaults are histogram distance **0.30** and mean RGB absolute difference **0.12**, each normalized to 0–1. These are engineering heuristics, not calibrated semantic confidence.

The analyzer delays one frame to distinguish a near-white flash followed by an immediate return to a similar picture. Such a flash remains in the footage and frame count, but is omitted from correction statistics and does not itself split the shot. A colored one-frame shot is not removed by that white-flash rule. Known source cut times supplied by the caller override it.

Known boundaries must be ordered, inside the source duration and coincide with actual decoded frame PTS. Missing or non-frame boundaries are rejected, not snapped to an invented cut. First/last coverage is verified against source origin and duration. Every successful profile partitions the complete source into contiguous half-open intervals.

Histogram changes and camera motion can be ambiguous. Dissolves, similar-image cuts, white title cards and very subtle edits are not universally classified. Known cuts are available for explicit correction. The output is observations for review, not an inference that an object or event changed.

A shot's activity statistic excludes the jump entering that shot and the return from an excluded flash. It measures within-shot pixel change, not the preceding edit.

## 4. Conservative correction settings

Each stage supports `Off`, `Auto` and `Manual`. `ColorSettings::off()` disables all correction stages and creative looks while permitting scene analysis. Manual values are explicit bounded inputs. All resolved values are saved, so changes to future defaults do not alter an existing project.

| Setting | Default automatic limit | Maximum configurable automatic limit | Manual range |
|---|---:|---:|---:|
| Exposure | ±0.25 EV | ±0.5 EV | −1 to +1 EV |
| Gamma delta from 1 | 0.04 | 0.10 | 0.85–1.15 |
| Contrast delta from 1 | 0.04 | 0.10 | 0.85–1.15 |
| Saturation delta from 1 | 0.03 | 0.10 | 0.80–1.15 |
| Linear RGB balance gain delta from 1 | 0.04 | 0.10 | 0.80–1.20 per channel |
| Minimum automatic-correction shot duration | 0.4 seconds | Configurable 0.1–10 seconds | Manual settings remain explicit choices |

Auto needs at least three frames and adequate shot duration, usable tonal variation, low clipping, limited extreme shadows, restrained saturation and stable luminance. Highly colored, clipped, nearly blank, brief or significantly changing shots normally remain unchanged. Auto does not infer that every dark shot was underexposed or every muted shot needs saturation; any non-identity result still needs user review.

Positive automatic exposure is limited by observed channel headroom. Automatic balance avoids gains that would clip measured highlights. Gamma and contrast have additional highlight/shadow bypass rules. Measurements are on downsampled frames, so they cannot guarantee headroom in every full-resolution pixel. Manual choices and explicitly requested looks can intentionally exceed that observed headroom and must be checked in preview.

### White balance

There is no global gray-world assumption. Automatic white balance requires a caller-supplied **user-confirmed neutral rectangle** in normalized, display-oriented coordinates. That region must contain sufficient pixels and remain spatially homogeneous, temporally stable, neither dark nor clipped, and only moderately color-shifted.

The patch is not a tracked object. If the camera moves or the region ceases to be neutral, Auto may bypass it. Per-shot temporal neutral spread is checked in addition to within-frame spread. A user who incorrectly designates colored content as neutral can still request an unsuitable correction; review remains necessary.

### Explicit looks and temporal stability

`None` is the default look. `Warm`, `Film` and `HighContrast` are small, explicit parameter presets, not automatic artistic grading. Their non-identity results also require review.

Parameters are constant inside each shot. This is the deliberately simple smoothing policy: it prevents per-frame exposure pumping, and a genuine cut begins another independent adjustment. It does not implement local relighting, gradual adaptive curves, stabilization, face-aware color or shot matching. A later adaptive implementation would need separate evidence and controls.

## 5. Reversible `.amxv` integration

The new project schema is **4**. `settings.color_correction` is optional; migrated projects keep it absent. Known schemas 1–3 migrate using the existing migration chain without enabling new treatment. A schema-3 document cannot smuggle color settings into the older schema. Older readers cannot open a newly saved schema-4 document.

The color subprofile version is 1. It stores the selected source ID, SHA-256, video stream index, exact duration, settings, global enabled state and contiguous shot records. Each shot records a stable ID, source interval, boundary kind, compact evidence, resolved adjustment, reason, disposition, enabled/locked state and user-override marker. No full-frame cache, shell expression or arbitrary FFmpeg graph is serialized.

`ColorReport::apply` checks the exact current project decision digest before transactionally adding pending results. It preserves an earlier global bypass. On rescan, manually changed, approved, rejected or locked exact-range shots remain intact. If a rescan would repartition such a shot, application fails and asks for explicit reset or preserved boundaries rather than discarding the user's decisions. Unrelated time cuts, audio settings and output variants are not replaced.

`Project::decide_color` implements approve, reject, enable/disable, lock/unlock and adjustment. Changing parameters resets disposition to `NeedsReview`; enabling is not approval. Locks must be explicitly removed before ordinary modification. Invalid changes do not increment project revision or partially commit.

`Project::enable_color(false)` bypasses all color processing while retaining settings and decisions. `clear_color` is an explicit reset, including locks, not an automatic recomputation operation.

## 6. Review and previews

`ReviewSession::apply_color_report` uses the existing transaction, dirty-state, selection and preview-cancellation machinery. `ReviewTarget::ColorShot` adds rows to existing lists and detail views. The view exposes the profile, observations, parameters, reasons and dispositions. There is no invented numeric confidence score.

`ReviewCommand::ChangeColor` updates selected-shot parameters. Existing approve/reject/enable/lock actions work on color shots. Color does not change timeline duration, but active pending color makes the final **video** render unavailable. Dry-run and review summaries report that blocker separately from timeline edits.

Original previews have no voice or color treatment. The proposed side applies only the selected pending correction hypothetically on a private copy; other unresolved changes are omitted and disclosed. Existing accepted edits/audio settings remain in the proposed copy. The project is not approved or saved by previewing. Proxy range/variant/source/revision binding and cancellation remain unchanged.

A globally bypassed profile stays bypassed in a final render. The explicitly requested hypothetical preview can show the selected correction despite that bypass; its hypothetical intent remains visible.

Pure audio-stem export and audio preflight use a private color-free copy. Unapproved pixel corrections or a missing `zscale` capability therefore do not block audio-only work inside the existing supported project profile. This does **not** add general HDR import or a new audio-only project type.

## 7. Pixel pipeline and timing

Reviewed exposure and diagonal white-balance gains run in linear-light RGB through explicit Rec.709 conversion with `zscale`. Gamma, contrast and saturation run with explicit full-range working YUV. Output is converted back to the input's qualified limited/full range and the current 8-bit output format. Required filters are checked before staging a render.

Color transforms occur **before** the existing timeline's source selection and timestamp remapping. Per-shot predicates use half-open source intervals and reconstruct source ticks from FFmpeg's `t` value. Absolute enable ticks are limited to 2^46 to retain floating-point conversion headroom. Fractional frame boundaries and large source origins are part of the independent media suite. The color chain does not resample/drop frames, change duration or modify audio.

Per-shot parameters are not blended across an actual cut. Bypassing the entire profile takes the unchanged older render path. In an active profile, unadjusted intervals still traverse the shared color-format conversion, so bit-identical unadjusted pixels are not promised; small quantization changes are possible. Transcoded output is never claimed bit-identical across codecs or runtime versions.

Existing cut/voice processing, low-resolution preview scaling, output property checks, full decode, peak validation, temporary ownership and publication remain in charge. No new arbitrary-filter permission is exposed. The color graph is bounded to 24 KiB, combined graph to 48 KiB and the existing command limit remains 30 KiB; a dense graph can reach that smaller practical limit first.

## 8. HDR, bit depth and unsupported operations

The new color path requires an explicitly tagged **Rec.709 matrix, transfer and primaries, a known limited/full range, progressive 8-bit YUV, no alpha, and a supported orthogonal display orientation**. Unspecified tags are not inferred from resolution or container name. Per-frame native diagnostics must continue to match the initial interpretation.

| Input/operation | Current behavior |
|---|---|
| Qualified Rec.709 progressive 8-bit color analysis/correction | Implemented source path; independent SDR media tests executed |
| Existing one-source cuts/audio within that profile | Reused; correction applies in source time |
| Unknown tags or a midstream range/transfer change | Reject the color path; do not guess or reinterpret |
| 10-bit SDR, HDR10, HLG, HDR side metadata | Reject this color path |
| Dolby Vision | Reject; no dynamic-metadata-preserving pipeline qualified |
| Interlaced footage | Reject; no silent deinterlacing |
| HDR-preserving trim/remux/audio-only-video-copy | Not implemented or qualified by this delivery |
| Arbitrary crop/scale/overlay composition | Later milestone; existing disposable review scaling is separate |

The operation-support helper describes eligibility when using Step-6 color, not every feature of earlier uncolored paths. No existing uncolored render profile is silently broadened. The HDR10/HLG/10-bit/interlace fixtures prove the tested metadata is present; the Rust rejection tests are supplied but unexecuted. No Dolby Vision camera file or complete HDR playback chain was tested. Copying tags is explicitly not proof of correct HDR pixels.

## 9. Resource and lifecycle limits

Defaults: a 192×108 bounding box, all decoded frames, at most 4 hours of declared source duration, 3,456,000 frames and 128 shots. Callers may tighten these limits. Analysis bounds may grow to 320 per axis but at most 57,600 pixels. The first reached limit wins; this is not a promise that every 4-hour source fits every other cap.

The pipe holds at most 64 unmatched frame/header records, a partial frame, 16 KiB per diagnostic line and 512 MiB total diagnostics. It rejects overload rather than retaining unbounded media. The existing process queue remains bounded. Small very-high-rate inputs or a severely stalled consumer can hit that bound and must be retried with an appropriate supported workflow, not accepted as a partial success.

Analysis uses the host's existing job limit and cancellation token, with a default requested decode deadline of two hours; the native adapter's stricter timeout wins. Progress is emitted approximately once per source second. File fingerprinting/probing retain their existing independent limits. No permanent worker, global timer, model, scan-on-startup or cache is added. These are payload/work limits, not an operating-system RSS sandbox.

## 10. Host adaptation

The five required `MediaHost` and two `ProjectStore` method signatures remain unchanged. Implement the additional optional method to use Step 6:

```rust
fn stream_video_frames(
    &self,
    request: &VideoScan,
    cancel: &Cancellation,
    sink: &mut automexia_video::color_analysis::VideoFrameSink<'_>,
) -> Result<()>;
```

The default returns a missing-capability error. The supplied native adapter provides an implementation. Custom adapters must emit display-oriented, full-range RGB24 at the requested raster, exact source PTS, complete decode and final duration, honor cancellation/deadlines and enforce the requested SDR interpretation.

Map `Stage::AnalyzingVideo`, `ReviewTarget::ColorShot` and `ReviewCommand::ChangeColor` in exhaustive matches. Add `color_correction: None` in explicit `ResolvedSettings` constructors. Surface reasons, parameters, pending state and global bypass in existing details/settings rather than adding a new UI framework.

Typical sequence: load/create the project → `analyze_color` → explicitly apply the report → inspect/preview → explicitly decide each changed shot → save → `render_project`. The included [color_smoke example](../examples/color_smoke.rs) analyzes by default. `--save-review` explicitly writes a new pending project; it does not approve or render it.

## 11. Reproduce and qualify

```bash
cargo test --no-default-features
FFMPEG=/usr/bin/ffmpeg FFPROBE=/usr/bin/ffprobe cargo test --features native
python3 -B tests/media/run_color_checks.py --output /tmp/video-color.json
```

The first two commands were **not run** here because Rust/Cargo were unavailable. The third ran real FFmpeg recipes, pixel checks and a separately labeled Python signal reference. It does not execute `SceneAnalyzer`, the parser, serialization, review or the adapter. Native Windows/macOS, the actual Automexia UI/player, calibrated-monitor judging and a diverse camera/HDR corpus remain untested.

See [verification](VERIFICATION.md) for exact results and [review findings](STEP-6-REVIEW.md) for the errors/fixture issues found. The included sample chart clips are synthetic and generated by the independent harness, not the uncompiled Rust crate.
