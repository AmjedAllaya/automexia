# Step 13D manual qualification

The following is an acceptance procedure, not a record of completed measurements. The source candidate's current measured status is in `reports/alpha5/verification.json`.

1. Build the locked default, graphics, native and all-feature targets. Run the face, placement, review, render and lifecycle regressions. Keep blocked runtime/model checks visible.
2. Explicitly select one UltraFace RFB-320 pack and its canonical reviewed ORT library through the existing component owner. Record manifest/weights/notices hashes, model source revision, preprocessing, runtime artifact/build hashes and deployment/license decisions. A YuNet comparison requires a separately implemented and qualified provider.
3. Run the ignored `face_qualification` tests using a known tightly packed RGB24 face fixture and explicit environment inputs described in `FACE-ONNX.md`. A synthetic detector or Python reference recipe does not establish actual learned-model quality.
4. Exercise one face, nearby groups, separated faces, no face, occlusion, profile views, rapid motion, scene cuts, rotations, VFR, non-square pixels, dark scenes, tiny faces and false positives. Include graphics and real caption cue lifetimes in portrait, square and Fit compositions.
5. Record precision/recall, sampled clipping, crop jitter, safe-zone success, manually observed correction counts, CPU, RSS and latency. Preserve unknown metrics as unavailable. Inspect unsampled frames around cuts and fast motion before accepting framing or punch-ins.
6. Revoke a selection during inference and before application. Disable/cancel-all/remove the extension during a detector call and after receiving a report. Calls must cancel and stale reports must fail. A newly generated report must remain adoptable after its analysis job completes while its owner remains enabled.
7. Inspect proposed framing and choose explicit anchors/punch-ins. Verify diagnostics cannot be edited to authorize arbitrary changes, existing locks are retained, motion limits remain unchanged, and all selected changes require ordinary approval. Reject anchors that collide in any visible shot, including animation key extremes and the zoomed framing.
8. Verify sequential layers may reuse an anchor and that an overlay named `captions` cannot be confused with actual captions. No-face scenes should retain saved framing; an unobserved layer must not claim safe placement. Baked-in text/logos remain a manual composition concern.
9. Approve, render, save, reopen, and rerender without a loaded model. Accepted source-time framing should reproduce consistently. Repeat on the actual Automexia host and supported platform/runtime matrix before treating the provider as generally qualified.

The optional model and native runtime remain explicit host selections. These source implementations do not establish installation compatibility or human quality acceptance by themselves.
