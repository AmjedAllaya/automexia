# Step 8 rebuild review log

This log records work from the verified Step 7 archive. Earlier statements about a missing Step 8 ZIP are not used as implementation or test evidence.

## Pass 1 — reconstruction and first media exercise

Read the existing project, edit planner, review, native output lease, preview and audio paths. Added bounded supplied-caption records, variant presentation, deterministic composition, explicit assets/fonts, safe static rasterization and the existing pipeline integration.

The initial direct FFmpeg experiment preserved 60 source frames and showed a red overlay only on frames 15–29. The first independent presentation suite then passed **48/48** cases. These runs used Pillow test artwork and FFmpeg, not Rust.

## Pass 2 — integration and adversarial source review

Source review identified and corrected missing Save As rebasing for graphics/fonts, including disabled layers; silent intentional overlap ambiguity; weak accounting at mapped-event insertion; missing safe-zone inheritance from active framing; and protected-file alias checks in explicit subtitle publication.

The raster profile was tightened to reject unqualified ICC/HDR/16-bit graphic conversion and to resize premultiplied alpha. Explicit font family/glyph and SVG-resource handling were reviewed. Review-session attachment was added so presentation does not require reloading away other unsaved work. Asset/output guards include disabled references.

These are source-review findings with added Cargo regression cases. They are **not** reported as Rust tests that failed and later passed: Rust execution was unavailable.

All seven retained independent media suites passed: 19 import/render, 18 cut, 23 preview, 30 pause, 44 voice, 32 color and 42 framing checks, totaling **208**.

## Pass 3 — expanded timing and color checks

Expanded the new suite to **55 cases** with fade-out excerpts, layered graphic dissolves, full-range composition, square-display geometry on anamorphic media, decoded flash/tone synchronization and lossless same-source-frame comparison between final rendering and preview excerpts.

The first expanded run had **54 passes and one failed assertion**. The dissolve midpoint assertion compared an sRGB code value of 128 against Rec.709-transfer output. Decoded output was approximately (112,0,114), consistent with the implemented transfer. The assertion was corrected to check that declared color space and to retain a strict no-background-leak green-channel check. The full repeated suite then passed **55/55**.

A small rendered multiline-caption frame was visually inspected: both supplied lines were legible within the plate. This was a synthetic Pillow/FFmpeg fixture, not a typography campaign or Rust rasterizer run.

## Source/build and scope audit

New Rust tests cover parsing, mutation, migration, layout, keyframe bounds, explicit punch-ins, assets, actual raster calls and actual native render/preview/publication workflows. Counts are declarations until Cargo runs.

A Pygments lexical/delimiter scan found no lexer/delimiter issues. It is not a Rust parser, compiler, type checker or assurance of link compatibility. Rust/Cargo were absent; recorded build commands exit 127 rather than being counted as passing.

The supported-effect list does not pretend that clip-to-clip overlapping dissolves or non-unit playback speed exist. They remain explicit missing capabilities. No terminal UI, AI, native extension loader or model package is invented.

## Final packaging review

Only source, documentation, sample media and reports are packaged. No font files, compiler binaries, generated raster-cache directories, Python caches or build targets are included. Historical step reports stay as historical records.

The final ZIP is created, opened for CRC verification, extracted into a new directory, and its hashes are checked. Independent media suites are repeated from that extraction with outputs outside the package. The exact final results and artifact digest are recorded in the separate clean-extraction report; this paragraph does not substitute for those results.
