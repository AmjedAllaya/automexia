# Automexia Video core — Steps 0–9

**Version 0.9.0** adds frozen Clean/Social/Podcast workflow settings, separate Preview/Fast/Publish/Master encoding profiles, software H.264/HEVC/VP9/AV1/ProRes delivery, sequential multi-target execution, structured results and safe retry/reuse. It is rebuilt from the verified Step 8 delivery-repair archive, not either missing Step 9 attempt.

**Source implementation, not a compiled release.** Rust/Cargo are unavailable in this execution environment. Compilation, typechecking, Cargo tests and native Automexia integration have not been performed. Independent FFmpeg tests exercise media recipes, not the Rust adapter. Use the current [verification record](../reports/step9/verification.json) and [review history](STEP-9-REVIEW.md); prior reports remain historical.

**Executed in this rebuild:** 303 independent media checks and 58 packaging regressions passed. The 800 Rust test declarations (67 new) are supplied, not executed. No local result is presented as a Cargo or terminal-integration pass.

## Start here

[Step 9 implementation](STEP-9.md) · [Native integration example](../examples/delivery_smoke.rs) · [Integration](INTEGRATION.md) · [Project format](AMXV-FORMAT.md) · [Video roadmap](video-roadmap.md) · [Verified packaging procedure](DELIVERY.md)

One Rust crate, one Video extension, the same adjustable host boundary. No new runtime dependency, terminal framework, process authority, scheduler, daemon, cloud service or model is introduced by Step 9. Sequential software encoding is the reference; shared-decode optimization and hardware encoding are not claimed.

## Normal workflow

Create/open an editable project → choose explicit editorial settings and output compositions → review generated decisions → save → deliver selected variants → inspect per-target results → retry failed targets while revalidating completed files.

`run_workflow` prepares new input using a frozen settings snapshot. `render_targets` renders saved decisions without reanalysis. `retry_targets` retains and verifies successful output receipts. Existing review, preview, media-stem and subtitle exports remain available. Step 10's OTIO/XML/EDL exporters are not implemented here.

Clean/Social/Podcast are edit settings, not approval of cuts or geometry. Output profile changes never silently download models, replace source files or select another codec after failure. New profiles must match destination extensions and available runtime capabilities.

## Build and tests

```bash
cargo test --no-default-features
VIDEO_TEST_FONT=/absolute/path/to/your.ttf cargo test --features graphics
FFMPEG=/usr/bin/ffmpeg FFPROBE=/usr/bin/ffprobe \
VIDEO_TEST_FONT=/absolute/path/to/your.ttf cargo test --features native
python3 -B tests/media/run_delivery_checks.py --output /tmp/delivery-media.json
python3 -B -m unittest discover -s tests/packaging -v
```

No font or fabricated Cargo.lock is distributed. The inherited graphics dependencies remain optional; media executables and fonts must be explicitly approved. Native denoiser timing remains restricted to the previously qualified FFmpeg 7.1 family. The native adapter is not an OS sandbox.

## Compatibility

`.amxv` schema **7** adds optional frozen workflow and delivery-profile fields. Known schemas 1–6 migrate without enabling new processing. Required `MediaHost`/`ProjectStore` method signatures are unchanged. See [Step 9 integration delta](STEP-9.md#8-integration-delta) for new data fields.

The inherited input scope remains one chronological source, progressive 8-bit SDR, selected audio or video-only output. ProRes output does not enable HDR or recover source bit depth. Existing [Step 8](STEP-8.md) video-clip cross-dissolves and non-unit-speed gaps remain explicit. [Step 8's previous README](STEP-8-README.md) is preserved as historical context.

## Delivery integrity

The final source ZIP is built and reverified using [package_delivery.py](../tools/package_delivery.py), an explicit milestone/version policy, SHA-256 manifest and clean extraction. The tool prints download links only after rechecking the exact final files. These checks establish artifact integrity, not application functionality or a browser download test.
