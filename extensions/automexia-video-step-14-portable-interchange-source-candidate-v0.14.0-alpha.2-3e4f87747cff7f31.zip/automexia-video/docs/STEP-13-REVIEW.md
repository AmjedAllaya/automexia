# Current Step 13 review

The current continuation is **0.13.0-alpha.5**, schema 9. Its implementation and remaining gaps are in [Steps 0–13 review](STEPS-0-13-REVIEW.md), with fresh evidence in [reports/alpha5/verification.json](../reports/alpha5/verification.json). Source implementations now include 13E transcription and concrete optional providers. Rust/native/model execution remains unverified in this environment.

## Historical alpha.3 review

The following record belongs to the original edition. Its old schema/implementation statements and counts are not current qualification evidence.

# Step 13A–B implementation reviews

## Pass 1 — contracts, code and initial media exercises

Built the actual optional Rust model pack, tensor adapter, speech analyzer,
selected-channel decoder, probability veto and existing review integration.
Checked the exact candidate ort API against primary documentation. The model
contract follows the retained Video roadmap and the upstream streaming wrapper.
No default model, model download, forced transcript or automatic edit approval
was introduced. Full 13C–E scope was kept explicitly outstanding.

Source review found a lifecycle error: the completed speech report was originally
bound to the short-lived job token that becomes cancelled on normal return. Its
owner is now the model selection/caller/extension lifetime, while active jobs
retain their own short-lived cancellation. Revoking the model or disabling Video
still invalidates unapplied reports. A regression test exercises real native
integration with a fake probability provider; it remains unexecuted without Rust.

The initial independent speech-media suite recorded **28 passes and one failure**.
The actual Matroska discontinuity fixture exposed three overlapping resampled
analysis timestamps. Rejecting every overlap was too strict for that qualified
container-timing case. The original failed report is retained, not rewritten.

## Pass 2 — timestamp and compatibility correction

Added a source-time-base-dependent tolerance, bounded to one declared tick plus
one 16 kHz sample and never more than 17 samples. Only overlapping analysis
coverage is clipped. Recurrent state resets and the affected inference window is
Uncertain. Gaps remain gaps; wholly duplicated or excessive overlaps fail.
No output media or edit timeline is retimed. The corrected 29-case suite passed.

The default buffer remains strict when timing resolution is absent/coarser than
one millisecond. Added Rust regressions for correction limits, duplicates,
uncertain state, sample accounting and missing-coverage preservation.

Verified that `.amxv` remains schema 7 and non-AI planning/serialization/fixtures
are unchanged. Extended the existing static boundary guard with the explicit
Step 12 baseline and reviewed optional dependency additions rather than disabling
its checks. The eight mutation tests still reject unintended changes.

## Pass 3 — exact assets, tests and delivery

Added opt-in actual-model contract tests and two integration examples. Missing
reviewed assets fail those tests. Compiler/model availability is not disguised as
successful inference. Model rights, transitive native dependencies, process-global
runtime ownership and the dynamic-library path-swap limitation are documented.

Added eight qualification-runner regressions so missing, relative, symlinked or
placeholder model configuration cannot qualify the selected-model test. The
configuration check neither loads nor validates the placeholder test bytes; it
only confirms prerequisite presence. Actual verification happens in Rust.

Expanded independent media coverage to **34 passing cases**, including per-stream
selection, opposite-phase channels, explicit mono choice, source offsets, real
gaps, resampler tails, bounded repairs, malformed stream data, cancellation and
seeded packetization. Veto tests use explicit synthetic classes and are not
learned-model or speech-quality measurements.

A final source review moved malformed expected-digest validation ahead of model
file I/O and added provider-panic, invalid-state, in-flight revocation and wrong-
model regressions. These are supplied Rust cases, not executed tests.

Also repaired a stale current-state paragraph in `docs/DELIVERY.md` that said
Step 11 while giving version 0.12.0. Current documentation, Cargo identity, release
policy and CI now agree on Step 13A–B / 0.13.0-alpha.1. Historical reports retain
their own original identities.

## Final evidence

[Verification](../reports/step13/verification.json) records the actual repeated
suite outcomes and missing qualifications. ZIP/manifest/fresh-extraction checks
are delivery-integrity checks only. No unexecuted Rust test, selected model,
perceptual metric or target-platform result is labelled as passing.


## 13C review — alpha.2

13C adds a provider-neutral enhancement boundary rather than selecting a model by name. Reviews closed silent-loss paths in final rendering, proposed previews, audio-stem export and editor interchange; Save-As and publication now protect the reviewed stem. The native staging suffix is derived from the destination so a WAV enhancer does not receive an MP4-named temporary path.

A portability review changed saved-stem validation from inode/mtime equality to content hash + size, while live alias checks remain separate. Learned enhancement requires explicit speech-only confirmation, zero uncompensated delay in this candidate, PCM24 output, exact source rate/layout and full decode validation.

Executed current-source checks: enhancement transport 22/22, speech 34/34, interchange 35/35, packaging 58/58, qualification runner 59/59 and static boundaries 8/8. The long retained voice and delivery suites exceeded their execution windows and are not claimed as current passes. Rust/Cargo and actual voice-quality backends were unavailable.


## 13D review — 0.13.0-alpha.3

- Added provider-neutral face observations plus deterministic tracking/reframing.
- Generalized model-pack contracts, then added an explicit speech-contract guard so face packs cannot enter the speech analyzer.
- Linked model revocation into the face decode/provider cancellation scope.
- Fixed conservative no-face behavior: an existing Fit composition is preserved when a scene lacks reliable face evidence.
- Added Fit-mode face-to-output mapping for graphic/caption avoidance.
- Kept render/compositor modules byte-identical to 13C; 13D only proposes existing editable crop/presentation choices.
- Rust compilation and real YuNet/UltraFace inference remain unexecuted.
