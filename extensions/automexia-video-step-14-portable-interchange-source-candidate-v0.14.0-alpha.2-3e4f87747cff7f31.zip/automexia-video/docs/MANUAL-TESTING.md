# Manual build and editor-import checklist — Step 10, version 0.10.1

This package contains the Video core through Step 10. It is source for your
existing extension adapter, not a binary installer or a new terminal application.
The local handoff verified the source archive and executable independent tests;
it did **not** compile Rust or open an editing application.

[Implementation](STEP-10.md) · [Integration](INTEGRATION.md) · [Fixes](HANDOFF-REVIEW.md)

## 1. Verify and extract

Keep the adjacent `.zip.sha256` file with the ZIP. On Linux/macOS, compare the
archive's SHA-256 using `sha256sum` or `shasum -a 256`. On Windows, use
`Get-FileHash -Algorithm SHA256`. Extract into a new directory, then work inside
`automexia-video/`, the directory containing `Cargo.toml`.

The archive is a normal Deflate ZIP, not a nested ZIP collection. The internal
`SHA256SUMS` covers every packaged file except itself. Do not overlay this tree
onto an older checkout before confirming your current work is backed up.

## 2. Compile the actual Rust implementation

Provide Rust/Cargo supporting the crate's declared minimum Rust 1.85. First
resolution requires access to the declared Cargo dependencies; this ZIP does
not contain a vendor directory or an invented Cargo.lock. Preserve the lockfile
Cargo generates during your successful build so later runs can use `--locked`.

From the package root:

```bash
rustc --version
cargo --version
cargo test --no-default-features
```

A compilation error is a failed build, not a feature test pass. Retain the first
complete compiler diagnostic before changing more code or generating media.

For the graphics and native paths, select an existing local font and your
approved FFmpeg/ffprobe binaries. No font, model, FFmpeg or compiler is bundled.

```bash
export FFMPEG=/absolute/path/to/ffmpeg
export FFPROBE=/absolute/path/to/ffprobe
export VIDEO_TEST_FONT=/absolute/path/to/your-font.ttf

"$FFMPEG" -version
"$FFPROBE" -version
cargo test --features graphics
cargo test --features native
```

The independent local run used FFmpeg 7.1.5 on Linux. This is not a guarantee
that every installed FFmpeg build exposes the needed encoders/filters. The
inherited `afftdn` latency qualification is intentionally restricted to 7.1.x.
Missing tools or capabilities should be reported, not silently passed or replaced.

PowerShell uses the same Cargo commands after setting explicit paths:

```powershell
$env:FFMPEG = 'C:\approved-tools\ffmpeg.exe'
$env:FFPROBE = 'C:\approved-tools\ffprobe.exe'
$env:VIDEO_TEST_FONT = 'C:\your-fonts\test-font.ttf'
cargo test --features native
```

Those paths are examples to replace, not a requested installation layout.

## 3. Run the focused Step 10 tests

These execute the actual Rust modules and native adapter once compiled:

```bash
cargo test --no-default-features --test interchange
cargo test --features native --test native_interchange
```

The tests include source/record timing, frame-rate rules, cuts, marker mapping,
XML links, escaping, explicit stems/bakes, pending decisions, cancellation,
source changes, output replacement and source-alias protection. The 0.10.1
regressions additionally check video-link grouping and destination binding.

A published document is bound to its export destination. Rebuild the document
for a different path rather than calling `publish_interchange` with a different
location; relative media URLs and embedded request information must agree.

## 4. Generate real Rust exports from the included synthetic media

Use an empty output directory. The example deliberately uses create-new
publication and will not overwrite existing files.

Linux/macOS:

```bash
TEST_OUTPUT="$HOME/automexia-step10-test-new"
mkdir "$TEST_OUTPUT"
cargo run --features native --example interchange_fixture -- \
  samples/interchange/source.mov "$TEST_OUTPUT"
```

PowerShell:

```powershell
$TestOutput = Join-Path $env:TEMP 'automexia-step10-test-new'
New-Item -ItemType Directory -Path $TestOutput -ErrorAction Stop
cargo run --features native --example interchange_fixture -- `
  samples/interchange/source.mov $TestOutput
```

Expected files: `timeline.otio`, `timeline.xml`, `timeline.edl`. This fixture
constructs an in-memory project and does not pretend to save `fixture.amxv`.
It must return an error when any document is not published and verified.

The included source is a two-second, 30 fps synthetic picture/tone fixture.
The example removes source [0.5, 1.0) seconds. Expected sequence:

| Property | Expected |
|---|---|
| Video intervals | Source frames [0, 15), then [30, 60) |
| Total duration | 45 frames / 1.5 seconds |
| Sequence start label | 01:00:00:00 at 30 fps non-drop |
| Audio | Matching selected source audio, no downmix or hidden cleanup |
| Marker | Source 1.5 seconds becomes sequence-relative 1.0 second (frame 30) |
| Original source | Unchanged |

The prebuilt files in `samples/interchange/` are independent reference fixtures,
not Rust-generated proof. Their README explains relink placeholders. Test the
newly generated `timeline.*` files for actual implementation acceptance.

## 5. Read back the Rust documents independently

With Python, NumPy, Pillow and the explicit media tools available:

```bash
python3 -B tests/media/run_interchange_checks.py \
  --rust-exports "$TEST_OUTPUT" \
  --output "$TEST_OUTPUT/readback.json"
```

On Windows use `python` and `$TestOutput` instead. This script includes a
`supplied_rust_document_readback` result that checks the artifacts you generated.
It also runs independent reference/media cases, which are labeled separately.
It does not launch an editing application or compile Rust for you.

When the OpenTimelineIO SDK is installed in that Python environment, its reader
is exercised too. Adding `--require-otio-sdk` makes a missing SDK a failure rather
than an unexecuted optional check. Record the SDK version in your test result.

## 6. Import in your actual editor

Record the exact editor name/version and OS. A target label such as Resolve or
Premiere in the request is not an import-compatibility certificate.

Use the editor's supported import route for **legacy Final Cut Pro XML**,
**CMX3600 EDL**, or OTIO where supported. `timeline.xml` is `xmeml`, not modern
`.fcpxml`; do not rename the extension to imply that other format.

Check the following against the table above:

1. Relink the original source; inspect duration, first/last retained frames and
   the cut at output frame 15. Scrub and play with audio.
2. Verify the sequence rate and one-hour start label. Check the point marker at
   sequence-relative frame 30. EDL marker comments may require manual handling.
3. Extend a source-reference cut to confirm original handles remain available.
   A separately requested flattened visual bake must not claim those handles.
4. Inspect audio/video links and mono/stereo channels; no duplicate audio or
   automatic channel substitution should occur.
5. Repeat with your own footage: 30000/1001 or 60000/1001 and drop-frame labels,
   Unicode paths, moved source files and deliberate relinking.
6. Exercise explicit processed-audio stems and visual bakes using the full
   `ExportRequest` API in STEP-10.md. Inspect the compatibility report and the
   already-published-media paths if the later document publication fails.

For VFR, non-frame-aligned cuts, unqualified channel layouts, unsupported HDR or
ambiguous source offsets, a clear error or explicit supported preparation is
expected. A rejection is not proof the input was silently converted correctly.

## 7. Failure and preservation checks

Use throwaway copies and a private test directory, never unique original footage.
Verify cancellation, an occupied output name, a missing or changed source,
changed replacement bytes and a read-only/unwritable output directory. Previously
successful outputs and valid projects must remain intact. Review cleanup of
owned temporary files without deleting unrelated files.

The native adapter is not a general OS sandbox. Your host still owns file access,
process approvals, UI, scheduling and serialization of concurrent writers.

## 8. Results to retain

Keep tool versions, exact commands, exit codes, complete build/test logs, generated
interchange files, compatibility reports and editor screenshots/notes. Record
not-run checks explicitly. Do not turn a missing compiler, codec, font, SDK or
editor into a passing test.

Known scope not completed by this patch: clip-to-clip video cross-dissolves,
non-unit-speed editing, hardware/shared-decode optimizations and host-specific
installation/UI/player qualification. The project remains one chronological
source; no multicamera or proprietary `.prproj`/`.drp` writer is implied.
