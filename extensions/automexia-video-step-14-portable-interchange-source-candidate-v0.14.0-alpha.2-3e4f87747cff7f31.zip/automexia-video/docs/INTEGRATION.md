# Current source integration — 0.14.0-alpha.2

The current source provides `integration::RegisteredVideo<H>` as an adjustable
entry for the existing Automexia action registry and job executor. It does not
claim an installed Automexia binary, loader ABI or extension manifest. The host
continues to own path authorization, model selection, native execution, scheduling,
UI dispatch, preview playback and deployment.

Implement `ActionRegistry::register_video` to register the supplied action
metadata atomically and return one `RegistrationLease`. If registration fails or
panics, the host must roll back its partial registrations. The lease owns those
registration handles and the owner's preview playback. It implements bounded,
nonblocking `stop_playback` and `unregister` methods.

`RegisteredVideo::register` constructs the extension and explicitly invokes the
registry. It does not probe media, scan the filesystem or initialize a model.
`OptionalActions::default()` exposes no speech-model, voice-enhancement, face-model
or transcription actions; restricted HDR preservation also has a separate host-capability flag. Set each family flag only after the host has provided
its explicit selection/provider and execution capability. Flags do not grant
permission or load a model; the actual workflows still enforce identity,
activation, runtime and contract checks.

The owner offers typed `VideoCommand` / `VideoCommandResult` dispatch for status,
runtime inspection, media probing, unedited rendering, project creation/dry run/
rendering, review/proxy creation, subtitle import/export, classical voice/color
analysis and audio stems. `dispatch_project` adds typed load/save/save-without-render
commands when `H: ProjectStore`. Requests borrow the actual domain types, not shell
text or arbitrary executable arguments. The host maps the remaining domain-specific
review and optional-provider actions to their existing explicit core methods through
`extension()`. It must retain model selection leases and preview file leases for
as long as those operations need them.

Call `deactivate(timeout)` on the existing lifecycle worker. It rejects new dispatch,
disables and cancels the extension, stops playback, unregisters actions, releases
the registration lease, and then drains admitted core jobs/workflows. Cleanup
phases are individually protected against callback panics, and every phase is
attempted even if an earlier one fails. `DeactivationStatus` carries both drain
status and all cleanup errors; `complete()` requires successful cleanup and a
complete drain. A zero timeout polls without waiting. A later call may retry the
drain but never repeats host cleanup or restores registrations. Concurrent
lifecycle calls return `Busy` so one caller cannot claim completion while another
is still closing playback.

Dropping the owner signals cancellation and performs each host cleanup at most
once, with no job wait. Actual code unloading requires a prior successful explicit
drain. Captured old review tokens stay revoked. Register a new owner for a fresh
activation rather than trying to revive an unregistered entry.

Model lifecycle is implemented separately through `ModelStore` and
`NativeModelStorage`: verified immutable packs, persistent inventory and explicit
selection/update/removal. See [model packs](MODEL-PACKS.md). Model installation
never selects or starts inference. Optional transcript and enhancement records are
part of the current project schema; consult [project format](AMXV-FORMAT.md) and
the current verification report for the actual schema and measured checks.

## Step 14B portable interchange dispatch

For `H: InterchangeHost`, `dispatch_interchange` accepts `InterchangeCommand::Assess` and `::Export`, returning a compatibility report or `ExportOutcome`. `InterchangeFormat::FcpXml` serializes as `fcp_xml` and uses `.fcpxml`; `Fcp7Xml` retains legacy behavior. Update exhaustive format matches.

For `H: BundleHost`, `dispatch_bundle` accepts `BundleCommand::Assess` and `::Export`. Pure assessment opens no source and performs no bake. `BundleHost::stage_bundle` authorizes one create-new archive and returns a `BundleLease` whose canonical private workspace contains `Media/`. The workflow prepares normal interchange and optional media bakes within one admitted job. The lease revalidates every identity, streams the bounded archive, and returns `BundlePublication` only after commit. Dropping a lease before commit cleans its staging. `NativeMediaHost` supplies this optional trait without changing the existing `MediaHost` signatures.

Set `OptionalActions::portable_bundles` only when the host has connected that capability. Explicit full `OptionalActions` literals need this new field, normally `false`; `..Default::default()` remains appropriate. Register `video.export.assess` and expose `video.export.bundle` only with the bundle flag. These descriptors do not authorize paths or guarantee a UI exists.

Surface the compatibility report, selected format, source/bake choices, whole-file copying and archive byte budget before execution. After success, display the archive path and hash. `PublishedUnverified` means a commit occurred but readback did not verify it; reconcile the existing output before retrying. A portable archive is an interchange handoff, not a full `.amxv` backup. See [Step 14B](STEP-14B.md).

The sections below are historical integration deltas. Their old versions, schema
numbers and statements about unimplemented features describe those earlier source
deliveries. Current source and the current verification report take precedence.

---

# Step 11 integration delta — 0.11.0-rc.1

> **Step 13A–D candidate update:** optional pinned speech-model support is described in [STEP-13.md](STEP-13.md). Default non-AI behavior is unchanged. Models, Rust compilation, installation and perceptual quality are **not qualified** by this source delivery. Step 13E is still outstanding; Step 13C source integration is described in [STEP-13C.md](STEP-13C.md).

All required and optional host method signatures remain unchanged. `.amxv` schema 8 adds only the optional voice-enhancement record.
The native subtitle guard and fingerprint routines are fixed in place.
Extension-created review sessions now end with the extension's lifetime. On disable,
cancel-all or owner drop, discard their closed UI tokens, stop preview playback,
release handles and keep `session.project()` available for ordinary recovery/save
in a new approved context. Re-enable creates a new review lifetime.

Do not unload code while its host workers are still executing. The owner signals
cancellation; your existing scheduler waits for completion, stops players and
cleans owned resources. This crate adds no waiting UI, thread pool or native loader.
Direct `ReviewSession::new` remains caller-owned. No source-declaration test is proof
of your actual installer/update/remove path.

See [Step 11](STEP-11.md), [quick start](QUICKSTART.md) and [qualification](RELEASE-QUALIFICATION.md).
Earlier deltas below are retained chronological integration history.

---

# Step 10 integration delta — version 0.10.1

The 0.10.1 handoff fixes XML link grouping and binds prepared exports to their destination; public host signatures and project schema stay unchanged. See [manual testing](MANUAL-TESTING.md).

The [Step 10 guide](STEP-10.md) is authoritative for this edition. Map the existing
`video export` action to `export_interchange`. The new optional `InterchangeHost`
trait contains `verify_cfr` (whole-source frame PTS evidence) and
`publish_interchange` (one protected, self-contained interchange document).
The supplied `NativeMediaHost` implements both. The five required `MediaHost`
methods and the two `ProjectStore` methods are unchanged.

Map the new `VerifyingTimeline` and `Exporting` progress states. Surface the exact
compatibility report, output status and retained explicit bake paths. A target
editor/version field is intended routing, not an import qualification claim.
Baking requires explicit destinations. Pending active decisions are never
implicitly approved. Retain the export request through existing host storage when
repeatability is required; `.amxv` remains schema 7.

There is no terminal framework change, new daemon, remote service, runtime
dependency, schema migration or editor launcher. Editor UI interoperability and
Rust build/test qualification have not been performed in this delivery environment.

---

# Step 9 integration delta — version 0.9.0

The new [Step 9 guide](STEP-9.md) is authoritative for this edition. Existing
required `MediaHost`, `ProjectStore`, analysis-stream and presentation/player
method signatures are unchanged. This edition adds no new runner or dependency.

Map `video.run`, `video.render` and `video.delivery.retry` to `run_workflow`,
`render_targets` and `retry_targets` on the existing job executor. Keep `review`
and the currently implemented subtitle/audio exports on their existing routes;
editor-interchange export is still Step 10. No shell-text parsing is added.

For explicit struct initializers add `ResolvedSettings.workflow: None`,
`OutputVariant.output_profile: None`, `RenderHistory.delivery_profile: None`,
and `RenderResult.delivery_profile` where adapting result construction. New
profile fields are optional in project JSON. Runtime encoder/muxer inventories
must describe actual available software, not presumed hardware availability.

Persist the returned `DeliveryReport` through your normal workflow storage owner.
It is an integrity aid, not a signed authorization. A retry reopens the requested
outputs and revalidates hashes/media; changed outputs are not overwritten. Surface
`published_unverified` distinctly and require explicit reconciliation, not a retry
loop. Event callbacks must be bounded; catchable callback panics stop new work but
cannot undo a committed file. No pause/resume semantics are invented.

`RunResult` returns the latest in-memory project on an analysis/delivery error.
Persistence is explicit; the host must offer normal save/review/recovery. A new
input/default run does not analyze unless the resolved settings request it. Presets
request traditional analysis, not models or implicit approval. Render/retry uses
saved decisions and does not call analyzers.

[Native integration example](../examples/delivery_smoke.rs) ·
[Tests](../tests/delivery.rs) · [Native tests](../tests/native_delivery.rs)

---

## Retained Step 8 and earlier integration reference

The sections below describe the earlier edition. Where they quote an older
crate/schema version or default output-only profile, the Step 9 delta above applies.

# Current Step-8 adapter additions

Version **0.8.0** adds editable presentation to the same Video crate. Add `presentation: None` to explicit `OutputVariant` constructors. Map `Stage::PreparingGraphics`, `ReviewTarget::PresentationVariant`, `ReviewCommand::ChangePresentation`, `ReviewDetail.presentation` and the local `video.presentation.*` / `video.subtitles.*` descriptors. `ReviewSession::set_presentation` preserves other unsaved edits.

The five required `MediaHost` and two `ProjectStore` signatures remain. Two optional default-denied methods are added: `prepare_presentation` returns owned private raster inputs, and `publish_subtitles` publishes bounded sidecar bytes while protecting the supplied project/media/asset paths and aliases. `NativeMediaHost` implements both. Existing hosts must implement the capabilities they expose, not return optimistic flags.

The optional `graphics` feature uses pinned Rust raster dependencies. `native` enables it; default core authoring remains free of file/process/raster implementations. Explicit fonts are user-selected assets, never an ambient scan. No font files are bundled.

New saves use `.amxv` schema **6**. Known 1–5 migrations do not enable new presentation. Media/filter timing, captions, review and previews share the existing timeline. No actual terminal binary integration or Rust compilation is claimed.

[Step-8 implementation](STEP-8.md) · [Integration example](../examples/presentation_smoke.rs) · [Verification](VERIFICATION.md).

The sections below retain earlier changes chronologically, not current schema declarations.

---

# Retained Step-7 adapter additions

Version **0.7.0** adds per-output composition inside the same crate. No new `MediaHost`, `ProjectStore`, analysis stream, player, scheduler or execution-authority method is required. Existing native/approved-runner integration remains reusable.

Add `framing: None` to explicit `OutputVariant` literals. Map `ReviewTarget::FramingVariant`, `ReviewCommand::ChangeFraming`, `ReviewDetail.framing`, and optional `video.variant.add` / `video.framing.*` action metadata to existing forms and dispatch. Public core methods include `Project::add_output_variant`, `set_variant_framing`, `decide_framing`, `FramingSettings::geometry_at`, and `ReviewSession::set_framing`.

Use `ProjectRenderRequest.variant` (not an invented new request field) to render a selected output. Sequential calls are sufficient. Project changes invalidate stale review/proxy identities. Audio-only work does not gain dependencies on geometry.

New saves use **schema 5**; known schemas 1–4 migrate without new framing. Older readers cannot read schema 5. Static Fit/crop requires existing scale/pad/crop filters as appropriate; varying zoom additionally requires `geq`. All media calls remain blocking and belong on the existing job executor.

[Step-7 implementation](STEP-7.md) · [Native integration example](../examples/reframe_smoke.rs) · [Current verification](VERIFICATION.md).

**Rust compilation and actual host integration are still unverified.** Exact names here are the source package's adjustable API, not claims about an already shipped terminal ABI.

The sections below retain earlier additions chronologically. Schema 5 was current for that edition.

---

# Retained Step-6 adapter additions

Version **0.6.0** retains the single Video crate and the five required `MediaHost` / two `ProjectStore` signatures. One new optional default-denied method, `MediaHost::stream_video_frames`, delivers bounded display-oriented RGB24 with exact original presentation times. `NativeMediaHost` implements it through the existing process/reader path. No new scheduler, loader, privilege authority or video player is required.

Map `Stage::AnalyzingVideo`, `ReviewTarget::ColorShot`, `ReviewCommand::ChangeColor` and `color_correction: None` in exhaustive matches and explicit settings constructors. New saves use `.amxv` schema **4**; known 1–3 migrations do not enable color processing. Older readers cannot read new schema-4 files.

Use `analyze_color` → inspect → explicit `ColorReport::apply` or `ReviewSession::apply_color_report` → per-shot decisions → existing save/render. `Project::enable_color(false)` bypasses without forgetting decisions. Changing a shot's parameters needs fresh review. Existing original/proposed proxy playback stays host-owned. Pure audio operations do not acquire a dependency on pixel processing.

The method contract, limits, supported Rec.709 path, stream failure policy and review steps are detailed in [STEP-6](STEP-6.md#10-host-adaptation). See the [integration example](../examples/color_smoke.rs). Source signatures and field names are local to this crate, not assertions about the terminal's existing ABI. **Rust build and host integration remain unverified.**

The sections below describe retained earlier changes chronologically. Schema 4 was current for that edition.

---

# Retained Step-5 adapter additions

Version 0.5.0 keeps one Video crate. The five required `MediaHost` signatures, `ProjectStore`, `AudioAnalysisHost` pause API and `PreviewOpener` remain. Two optional default-denied `MediaHost` methods add typed PCM preflight and measurement/stem operations: `stream_voice_pcm` and `run_audio`. `NativeMediaHost` implements both. Earlier adapters build using defaults but active voice functionality then returns `MissingCapability`.

Map the new `Stage::MeasuringAudio` progress value and add `voice_cleanup: None` to explicit Rust `ResolvedSettings` constructors. New `.amxv` saves use schema 3; known schemas 1 and 2 migrate with no newly enabled cleanup. Older readers cannot load schema 3.

Use `analyze_voice` → inspect report → explicit `VoiceReport::apply` or `ReviewSession::apply_voice_report` → existing save/render. `export_audio_stem` is an explicit PCM24 WAV operation. No process starts from object construction. Per-task deadlines do not replace your overall job cancellation policy. All blocking work belongs on the existing host executor.

[Detailed Step-5 API and behavior](STEP-5.md#10-adapter-changes) · [Complete smoke example](../examples/voice_smoke.rs) · [Supported scope](SUPPORTED-SCOPE.md)

The retained earlier integration guidance follows. References to schema 2 there describe the Step-4 change; schema 3 was current for that earlier edition.

---

# Step 4 integration additions

Version 0.4.0 retains the five `MediaHost` and two `ProjectStore` method signatures. Add `AudioAnalysisHost::stream_energy` only when pause analysis is enabled; `NativeMediaHost` supplies it. It streams ordered `EnergyFrame`s through the existing bounded runner; never downmix, fill gaps, reset source timestamps or return a partial success. Include `Stage::Analyzing` in exhaustive matches and `pause_cleanup: None` in new programmatic `ResolvedSettings` initializers. Saved files use schema 2 with a known schema-1 migration. [Detailed contract and workflow](STEP-4.md).

Analysis is cancellable and returns an immutable report; it does not alter or save the project. The host cancels/rejects superseded analyses, displays warnings/estimates, applies the exact report on request, and then uses the existing review/preview and rendering route. No new terminal source is required to adapt the core.

The following retained integration guide describes the prior surfaces, which remain in use. Historical claims of unimplemented silence detection refer to those earlier steps; the new current scope is the bounded, review-required analysis above. Rust build and native integration remain unverified in this delivery.

---

# Integrating the Video core

Use the existing terminal extension entry, command dispatcher, settings, UI and job owners. This package is a Rust core with a small adjustable adapter; **it does not claim the current terminal already exposes these exact method names or a compatible binary loader**. The user has explicitly accepted making host-specific adjustments.

## Existing media adapter: unchanged signatures

`MediaHost` remains the boundary for:

| Method | Host responsibility |
|---|---|
| `inspect_input` | Authorize and identify the explicitly selected local media |
| `revalidate_input` | Recheck observed source identity during an operation |
| `runtime_capabilities` | Return approved tools, identity and available encoders/muxers/filters |
| `run` | Translate typed `MediaTask` values to the existing reviewed process runner |
| `stage_output` | Own temporary output, collision policy, publication and cleanup |

Keep argument tokens separate; never join them into shell text. `RenderPlan` constructs only the implemented media profile. Do not turn `MediaTask` into a general arbitrary-process permission.

Step 2 adds two capability sets: `RuntimeCapabilities.filters` and `bitstream_filters`. The native implementation queries them. The host adapter must populate actual capabilities rather than infer them from an extension flag. Old serialized capability records default those new sets to empty; an edited render then reports missing capability instead of assuming support. Existing source code constructing a full literal must add the fields or use `..Default::default()`.

## Project persistence: two additional methods

Implement `ProjectStore` on the same host type:

```rust
pub trait ProjectStore: Send + Sync {
    fn load_project(
        &self, path: &std::path::Path, cancel: &Cancellation,
    ) -> Result<LoadedProject>;

    fn save_project(
        &self, project: &Project, path: &std::path::Path,
        policy: &OutputPolicy, cancel: &Cancellation,
    ) -> Result<SavedProject>;
}
```

These are ordinary host-owned file operations, not a new storage service. Reads must be bounded; writes must be staged and safely published, source aliases protected, and replacement decisions bound to the reviewed target. Loading project JSON does not grant access to its media references. Serialize concurrent saves to the same project through the current owner.

The optional `native` feature implements this trait on `NativeMediaHost`. It supports create-new and reviewed replacement, rejects symlink/nonregular final project files, uses existing canonical destination directories and cancels before commit. It is not an OS sandbox or adversarial filesystem compare-and-swap. The source's Unix process-group behavior and Windows child-only behavior retain their existing scope; stronger isolation belongs to the real host.

## Entry points and command mapping

| Existing-host action you wire | Core operation |
|---|---|
| Video status/help | `status()`, `HELP`, local `ACTIONS` metadata |
| Inspect input | `probe()` |
| Basic no-edit transcode | `render_unedited()` |
| Create editable project | `create_project()` |
| Inspect saved intent / dry run | `dry_run()` |
| Save without delivery media | `no_render()` |
| Explicit dry-run with project save | `dry_run_and_save()` |
| Reopen / save project | `load_project()` / `save_project()` |
| Render saved edits | `render_project()` |
| Open edit review | `review_project()` then `ReviewSession::snapshot/dispatch` |
| Request/cancel a preview | `ReviewSession::begin_preview()` / returned ticket cancellation |
| Render A/B review files | `preview_edit()` via the same existing media host |
| Accept latest async result | `ReviewSession::accept_preview()` |
| Open through the approved player | `open_preview()` with your `PreviewOpener` |
| Disable or cancel | `disable()` or the linked `Cancellation` |

Suggested action names are metadata for your adapter, not new global keybindings. A full shell command parser is not shipped. Map your existing `--no-render`/`--dry-run` interface to the methods rather than registering another CLI application.

Calls are blocking and belong on the current background executor. Constructing `VideoExtension` or `NativeMediaHost` starts no workers, media tools, models or scans. Status remains cheap. Jobs use the existing bounded admission and cancellation fields.

## Working with a project

The complete example [project_smoke.rs](../examples/project_smoke.rs) creates a project, explicitly removes its middle third, saves, reloads, renders and records the result. It calls the actual Rust API once compiled. It is not a standalone substitute product.

Use absolute project locations and explicit media/output selections. A newly created project automatically chooses a relative source reference only where safe. For save-as, call `rebase_paths` first. For a moved source, use `inspect_input` on the user's newly selected path and call `relink` with the returned identity. Do not auto-search a disk or download missing media.

A loaded `FileStamp` can bind an explicitly authorized later save. It is not itself user consent. The core does not silently overwrite either project or media output. Project history is saved explicitly after a successful media output so a metadata-save failure cannot mislabel a finished render as failed.

## What the terminal does not need to know

The host need not parse edit ranges, own `.amxv` semantics, track generator provenance, implement video timing, construct FFmpeg filters, or change VT/renderer internals. All of those are inside the same Video crate. UI and authorization remain with your established integration.

## Validation before shipping the adapter

Compile and run both Cargo suites, exercise your actual entry/settings/lifecycle, and run project save/reopen/trim/restore on real media. Confirm approved path access, current cancellation and source/output protection on each OS. The supplied Linux recipe results do not prove those host behaviors. See [verification](VERIFICATION.md) and [supported scope](SUPPORTED-SCOPE.md).


## Step 3: adjustable review and player integration

The full implementation and usage are in [STEP-3.md](STEP-3.md). Map ordinary list/detail/navigation and decision actions to `ReviewSession`; route keyboard, pointer and palette actions through the same dispatcher. The session is not a new UI toolkit. It returns literal display data, action availability and a focus-return instruction.

Use `begin_preview` / `accept_preview` tickets around async media jobs. A project digest alone cannot distinguish an older focus request for the same selected edit. Preview requests may choose an explicit saved `variant_id`; no global preset is read. Save reviewed changes with the existing `ProjectStore`; changing a range resets that operation to `NeedsReview`.

`PreviewOpener::open(&VerifiedPreview)` is the only optional new host-facing trait. Connect it to the existing approved preview/file-opening facility. Retain `PreviewSet` until that playback ends; close playback before dropping it. On close/disable/route removal, cancel the ticket and dispose of the old set through the normal host owner.

`MediaHost` and `ProjectStore` method signatures are unchanged. `OutputLease` gains a `Send` bound so results can move from a worker to the owning UI task. The native lease has no thread-affine state. Map custom thread-affine leases through the existing owner instead of falsely declaring them safe to move.

Render plans expose `output_byte_limit()` for per-proxy size monitoring; use the stricter request or host limit. The core also rejects oversized completed files before handoff. Default proxies are private, never published; their file names/request keys grant no permission and do not form a persistent cache.

`PreviewOpener` does not grant arbitrary process execution. A project file does not authorize its source references. Apply your current file/tool/player permissions. Native OS focus/accessibility, actual playback and platform-specific player cleanup are integration responsibilities and were not tested here.

## Step 12 — opt-in modernization delta

[Complete integration detail](STEP-12.md) · [Manual checks](STEP-12-MANUAL.md).
No existing host/player/storage method or project field changes. Optional calls:
`observation_cache`, `analyze_pauses_cached`, `analyze_voice_cached`,
`analyze_color_cached`, `disable_and_drain`, and `progress_mailbox`.

A disabled owner cannot be re-enabled while core jobs/workflows remain. Drain
reports both counts. Existing root action identifiers and schema 7 are preserved.
Cache owner revocation means clear/drop; no disk or IPC cache schema is introduced.
The host must still authorize input reads on every reuse, join workers and release
playback handles before unload. Recreate the native host and cache after runtime
libraries/drivers change, not only when the executable file changes.


## Step 14A assembly controls

The source supplies optional reviewed variant assembly through typed `SetAssembly`, `ReviewAssembly` and `LockAssembly` commands on `VideoCommand`, using the existing dispatcher and project/review ownership. Action descriptors `video.assembly.set` and `video.assembly.decide` describe this capability. Stable clip insertion, movement, repetition, trimming and speed edits use `Project`/`ReviewSession` mutators; changes clear assembly approval and invalidate old revision tokens.

Actual Automexia UI wiring remains required: expose the selected variant and occurrence IDs, source ranges, order, speed, review/lock state and bounded whole-sequence before/after preview. A repeated source timestamp alone does not identify an occurrence. Native preview/export/runtime qualification and actual host installation have not executed here. [Step 14A](STEP-14A.md) defines the bounded one-source scope; descriptor registration is not evidence of an installed host feature.
