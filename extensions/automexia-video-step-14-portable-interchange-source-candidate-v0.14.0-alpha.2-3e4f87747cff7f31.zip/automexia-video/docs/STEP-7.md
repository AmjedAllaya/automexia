# Step 7 — Aspect conversion, crop control and output variants

**Video core:** 0.7.0. **Project schema:** `.amxv` 5. **Scope:** the existing one-source, progressive 8-bit SDR Video core. This is the video roadmap's Step 7, not a Kubernetes milestone or terminal refactor.

**Delivered source:** per-variant Fit/crop settings, source-time pan/zoom tracks, exact output sizes, explicit review and reversible persistence, render/preview composition, and versioned target presets. No new crate, runtime dependency, worker, player, filesystem owner or host execution method is introduced.

**Verification boundary:** independent FFmpeg recipes are executed on encoded fixtures and decoded pixels. They do not execute Rust. Rust/Cargo are unavailable in the authoring environment; the source and supplied Rust tests still need compilation, typechecking and execution. No tested binary, successful CI run, native terminal integration or production release is claimed.

[Roadmap](video-roadmap.md#step-7--add-aspect-conversion-crop-control-and-social-variants) · [Integration](INTEGRATION.md) · [Format](AMXV-FORMAT.md) · [Review log](STEP-7-REVIEW.md) · [Verification](VERIFICATION.md)

## 1. Variant-local composition, shared edit intent

The source, selected audio/video streams, time edits, pause decisions, audio cleanup and shot-color profile remain in the master project. Each existing `OutputVariant` now has an optional `framing` field. Its canvas, crop track, safe-zone guide and scale policy affect only that variant.

`None` restores the pre-Step-7 render path. Changing a variant does not rewrite another variant, move common cuts, rescan scenes, rerun a detector or change accepted audio treatment. A new final render still performs the existing source/runtime/output checks and any audio measurement required by that render.

A project can store up to the existing 16 variants. Render them sequentially by calling `render_project` with a different `ProjectRenderRequest.variant` and an explicitly selected output path. Successful earlier outputs remain valid if a later independent render fails. There is no new queue, batch language or implicit overwrite policy.

## 2. Exact target sizes

`OutputSize::new(width, height)` accepts even integer dimensions. `OutputSize::from_aspect(aspect, long_edge)` accepts an exact rational aspect when the chosen longest edge can express it exactly with even dimensions; it returns an error rather than silently substituting another requested size.

| Requested shape | Example canvas |
|---|---:|
| 16:9 | 1920 × 1080 |
| 9:16 | 1080 × 1920 |
| 4:5 | 1080 × 1350 |
| 1:1 | 1080 × 1080 |
| Custom 3:2 | 210 × 140, or another exact even size |

Final framed output has square pixels and the exact requested canvas size. The inherited output validator checks that size, pixel aspect ratio, orientation, selected streams, timing, color properties and full decode before publication.

Odd, zero, oversized or infeasible dimensions are explicit errors. Subpixel display aspects and scaling are ultimately quantized to an even pixel raster; geometry inspection reports the realized integer dimensions rather than pretending an integer canvas can express every ideal rectangle exactly.

## 3. Fit: preserve the complete composition

`FramingSettings::fit(size)` keeps the full picture, scales it within the canvas and pads the remaining area. It does not identify a face, speaker or important object.

The saved normalized anchor controls the image position inside the free space. `(0.5, 0.5)` is centered; `(0, 0)` is top-left. Padding color is a typed RGB value, not arbitrary FFmpeg text. Safe zones do not change padding.

Scaling preserves the source display aspect as closely as even integer image dimensions permit. The displayed image may therefore differ by up to the documented raster-rounding quantum; arbitrary aspect stretching is not an available mode.

With `max_upscale = 1`, a small source stays small and receives additional padding. Selecting a large output preset does not imply an unlimited enlargement. If an extreme aspect leaves fewer than two scaled pixels on one axis, the requested geometry is rejected.

## 4. Crop: explicit source-space framing

`FramingSettings::center_crop(size, duration)` fills the canvas with a stable centered crop. The user can replace its pose or supply a `CropTrack`.

A `CropPose` contains a normalized display-space center and zoom. Zoom 1 means the largest source rectangle matching the target aspect. Larger zoom means a smaller rectangle. `CropPose::from_rectangle` converts an explicitly supplied normalized rectangle only when its display aspect matches the target; it never silently stretches an incompatible rectangle.

Rotation is normalized first. A 90/270-degree source swaps its coded dimensions and inverts its sample aspect ratio. Both Fit and crop calculations use this display-oriented geometry. Sources with non-square pixels are not treated as if their coded width alone defined their display shape.

Every keyframe must keep the desired source rectangle inside the source. Invalid centers, nonfinite values, inverted ranges, unsafe enlargements and invalid sizes fail; the core does not silently turn a user error into a different valid composition.

## 5. Source-time keyframes and scene resets

Keys use exact rational seconds relative to the selected video's original presentation origin, not the assembled output time or an inferred frame number. Removing source seconds 1–2 does not move a key originally at second 3 to source second 2.

Each crop shot covers a half-open source interval. Crop shots partition the full source duration in order. Each shot's first key is at its start. Keys are strictly increasing; the last pose is held to the shot end. A final endpoint can be inspected without becoming an extra rendered frame.

Between keys, the curve is quintic smoothstep:

```text
q(u) = 6u^5 - 15u^4 + 10u^3, 0 <= u <= 1
pose = first_pose + (last_pose - first_pose) * q(u)
```

The curve has zero first and second derivatives at each endpoint. The implementation checks analytic upper bounds for normalized center speed/acceleration and zoom speed/acceleration. Impossible timing is rejected rather than retimed. A shot reset is an explicit discontinuity and is not smoothed across.

`CropTrack::suppress_small_moves()` is a separate, pure editing operation. It snaps tiny successive center changes to the prior center while preserving all keyframe times, shot boundaries and zoom values. It is not applied silently during rendering. Submit/review/save its returned track normally.

When a Step-6 shot profile exists, moving interpolation may not straddle one of its recorded source cuts. Split the crop shot or place a knot at the boundary. Constant framing can span a known cut. This is not new scene detection, subject tracking or a way to infer missing cut boundaries.

Velocity and acceleration limits describe the continuous normalized model, not a guarantee that an integer sampled crop has mathematically continuous pixel derivatives. Final pixels remain discrete.

## 6. Render pipeline and animated-zoom correction

The selected source flows through:

```text
existing orientation normalization
→ accepted shot color
→ source-frame selection
→ variant framing in original source time
→ existing timestamp remapping
→ optional review-proxy scale
→ inherited video encoding/validation/publication
```

Audio follows the existing shared edit and cleanup path. Geometry is not inserted into audio graphs. Audio-only preflight, stems and preview loudness-reference measurement clear unrelated pixel-only profiles in private planning copies.

Three backends are exposed by `ReframeRender::backend()`:

| Backend | Implementation |
|---|---|
| `Fit` | Fixed Lanczos scale, typed padding and square output pixels |
| `ConstantZoomCrop` | Fixed enlarged raster, per-frame source-time crop position, 4:4:4 exact crop coordinates |
| `AnimatedViewport` | Fixed 4:4:4 source raster, bilinear viewport sampling, then fixed-size Lanczos output scale |

A variable-size upstream scale followed by crop was tested and rejected: crop retained initial input bounds and the center drifted during zoom. Animated zoom therefore uses the fixed-raster sampler. Its motion values are cached once per frame per expression state, not recomputed for every sampled pixel. The frame number only identifies the cached evaluation; interpolation always uses the original presentation time.

The animated backend requires FFmpeg's `geq` capability. It costs more CPU and an additional resampling pass than static crop. It is not claimed to be real-time on 4K/8K footage. Worker scheduling and cancellation stay with the current host. The displayed intermediate crop geometry is conceptual for this backend; `desired_crop` is the requested normalized viewport.

The expressions contain only validated numeric values generated by the core. There is no arbitrary filter text, shell expansion, external command stream, script file or model runtime.

## 7. Presets and safe-zone guides

The preset stamp records a name and revision; the actual resolved settings remain in the project. Editing a global preset cannot silently change an existing project.

| Preset revision 1 | Canvas | Insets: left / top / right / bottom |
|---|---:|---:|
| YouTube | 1920 × 1080 | 5% / 5% / 5% / 5% |
| TikTok | 1080 × 1920 | 5% / 10% / 12% / 18% |
| Reel | 1080 × 1920 | 5% / 10% / 12% / 18% |
| Feed | 1080 × 1350 | 5% / 5% / 5% / 10% |
| Square | 1080 × 1080 | 5% / 5% / 5% / 5% |
| Master | Nearest bounded even display size of the source | None |

These are authored, editable conservative guides, **not current platform UI specifications, upload guarantees or mandatory platform margins**. They are metadata for existing review/layout and later graphics; no safe-zone overlay is burned into the video.

Every preset starts in Fit mode and `NeedsReview`. Choosing an output shape alone must not silently discard source edges. Switching to Crop, changing anchors, adjusting limits or editing the guide is an explicit project edit.

## 8. Review, locks and saved decisions

`Project::set_variant_framing` creates/replaces a framing proposal. `Project::decide_framing` approves, rejects, enables/disables or locks/unlocks it. Settings replacement always invalidates the prior approval and preserves no inherited lock. A locked setting cannot be replaced or removed until explicitly unlocked.

`ReviewTarget::FramingVariant(id)` adds a row to the existing review model. `ReviewCommand::ChangeFraming` edits the selected variant; `ReviewSession::set_framing` edits a named variant through the current host form/action. Details include the complete settings, unchanged timeline duration, source-time interpretation and guide metadata.

Changes increment project revision, mark the review dirty and cancel stale preview work. A pending framed variant blocks its own final render. Other resolved variants can render only when the shared edits and color are also ready. Shared blockers are not hidden behind a framing-only message.

The original preview remains original source footage, without framing or color/voice treatment. A proposed preview can hypothetically apply the selected pending framing on a private copy. It must use that same target variant. Previewing never approves, saves or mutates the source project. Older jobs/tickets cannot reopen or display results for changed geometry.

Long-source framing previews use the existing short-window focus controls. The final proxy is bounded, but the composition may still require a larger intermediate source or target raster; the proxy cap is not an overall memory or decode-cost guarantee.

## 9. Persistence and compatibility

New saves use `.amxv` schema **5**. Known schemas 1–4 migrate without introducing new framing. A pre-5 file cannot smuggle a `framing` field, including null. Unsupported newer schemas/versions, duplicate keys and unknown nested fields remain errors.

The optional field lives at `variants[i].framing`; global `ResolvedSettings` does not receive a new framing field. Every present profile stores its version, target, mode/track, guide, limits, preset stamp, enabled/disposition/lock state. There are no paths, credentials, raw frames or arbitrary executable expressions inside it.

`None` removes the profile and restores the inherited no-framing path. Disabled/rejected profiles remain editable but do not execute. No shape is baked into source footage or master cut decisions. Older core readers cannot read schema-5 files.

## 10. Limits and failure behavior

| Boundary | Limit or behavior |
|---|---|
| Final canvas | Even 2–8192 pixels per axis; <= 33,554,432 pixels |
| Source/intermediate raster | <= 16384 per axis and <= 67,108,864 pixels, with stricter saved limits honored |
| Enlargement | Default <= 4× per oriented coded axis; configurable 1–16× |
| Crop zoom | 1–8; enlargement/raster limits can impose a lower feasible zoom |
| Crop track | <= 16 shots and <= 32 total keys |
| Expressions | <= 20 KiB for framing, plus existing combined-graph/argv budgets |
| Motion defaults | Center speed 0.75/s; center acceleration 3/s²; zoom speed 2/s; zoom acceleration 8/s² |
| Dead-zone default | 0.002 normalized source units, explicitly applied only |
| Time expression | Keys must be representable in the source time base and exact-expression tick range |

These are implementation choices, not measured production SLOs. Count limits do not guarantee every dense multi-axis track fits the expression budget. Pixel bounds are not a full process-RSS quota: planar conversion, codec buffers, temporaries and the source decode also use memory. Cancellation/deadlines and stronger OS controls remain the host's responsibility.

No unavailable safe composition falls back to a distorted image, hidden crop, unrestricted subprocess or shell command. The inherited output collision, source identity, temporary ownership, decode validation and publication rules remain active.

## 11. Integration surface

No `MediaHost`, `ProjectStore`, analysis-stream or player method signature is added or changed by Step 7.

Adapt only ordinary data/action matches:

- Add `framing: None` to explicit `OutputVariant` literals.
- Handle `ReviewTarget::FramingVariant`, `ReviewCommand::ChangeFraming` and `ReviewDetail.framing` in existing UI forms.
- Map the new action metadata into your existing dispatcher if desired; the IDs are this crate's metadata, not a claim about an installed host ABI.
- Save schema 5 and retain the existing exact-build/runtime checks.

```rust
use automexia_video::*;

fn propose_portrait(project: &mut Project) -> Result<()> {
    let framing = FramingSettings::fit(OutputSize::new(1080, 1920)?)?;
    let render = project.variants[0].render.clone();
    project.add_output_variant("portrait", render, Some(framing))?;
    // Return this pending proposal to the existing review UI.
    Ok(())
}
```

After explicit approval, set `ProjectRenderRequest.variant = "portrait".into()` and use the existing `render_project`. See [reframe_smoke](../examples/reframe_smoke.rs) for sequential Fit exports. It is a provider-side integration example, not an installed standalone editor or loader.

## 12. Test and completion record

The independent media checks use encoded fixtures, decode the output, and check geometry, crop content, pan/zoom, timestamps and unchanged audio. Lossless output is used for the exact same-source-frame comparison across a cut; ordinary delivery samples use the normal lossy profile. Native Rust tests cover save/load, edits/review, render, preview, cancellation, source replacement, aliases and cleanup, but remain unexecuted here.

Run:

```bash
cargo test --no-default-features
FFMPEG=/usr/bin/ffmpeg FFPROBE=/usr/bin/ffprobe cargo test --features native
python3 -B tests/media/run_reframe_checks.py --output /tmp/video-framing-results.json
```

See [verification](VERIFICATION.md) and [review history](STEP-7-REVIEW.md) for exact executed counts and limits. A passing independent recipe is not Rust compilation or actual Automexia integration. No face/group/speaker tracking, subtitles, learned model, HDR conversion or Step-8 graphics implementation is claimed.
