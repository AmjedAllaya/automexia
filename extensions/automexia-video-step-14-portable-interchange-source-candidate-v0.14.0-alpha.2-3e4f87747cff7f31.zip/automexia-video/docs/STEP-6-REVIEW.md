# Step 6 — review history and remaining qualification

This log distinguishes source inspection, independent FFmpeg experiments and supplied-but-unexecuted Rust tests. No Rust failure/pass is inferred from a Python or FFmpeg result.

## Pass 1 — implementation and direct media experiments

Implemented source-bound color settings/report/profile, exact shot intervals, one-pass statistics, neutral-patch conditions, typed linear-light/encoded-tone filters, project migration, review/preview integration and native streaming. All non-identity proposals remain pending. The existing one-crate/host ownership remains.

Direct tests checked `zscale` range/matrix/transfer, floating RGB exposure/balance, `eq`, named `showinfo` headers, output tags and image samples. Test fixture generation initially did not retain all desired Rec.709 tags using ordinary output flags. It was corrected with explicit x264 VUI metadata. Final **render** recipes use the existing Rust planner's actual output flags and `videoformat=component`, not that stronger fixture-only tag workaround; output tags are then checked.

The first exploratory run also exposed two test-oracle/fixture errors: ffprobe's displayed timestamps have fewer decimal places than exact source PTS, and an output `rotate` tag did not create the intended rotation fixture. The time assertion now allows only the displayed precision, while the underlying named-showinfo ticks stay exact. The orientation fixture uses actual input display rotation and decoded pixels.

The complete first 28-case pass had **27 passes and one failed fixture**: the interlaced encoder input height was not divisible by four. The fixture height was corrected rather than changing the source's reject-interlaced policy. See [pass 1](../reports/step6-media-pass1.json) and [early experiments](../reports/step6-first-experiments.txt).

## Pass 2 — conservative decisions, provenance and native protocol

Source review added observed channel minima/maxima, automatic highlight/shadow guards, temporal neutral-patch stability, global bypass preservation on rescan and exact-range preservation of reviewed/locked shots. The analyzer rejects incomplete source coverage, non-frame declared cuts and poisoned partial results.

The protocol checks every decoded source frame's progressive 8-bit format, color interpretation and tag sequence. Missing/duplicate/truncated frames or headers are rejected. The existing native process runner gained an optional stderr consumer so both media pipes can be correlated without unbounded capture. The rest of its capture modes remain unchanged.

Review and preview now disclose pending color decisions. Selected hypothetical corrections are applied only to the private proposal copy; the original preview is untreated. Audio preflight/stem operations clear unrelated pixel settings on a private copy so pending video changes do not block audio-only work.

The second independent pass had **28 passes, no failures**. All five earlier media suites were rerun: **134 passes, no failures**. These are media recipes, not native Rust execution. See [pass 2](../reports/step6-media-pass2.json).

## Pass 3 — exact boundaries, range changes and expanded media cases

Source review found that permitting either `tv` or `pc` per decoded frame could accept a midstream range change while the scale filter retained its initial interpretation. The pipe is now bound to the **expected initial range**, with explicit full-range acceptance and range-change rejection tests.

Within-shot motion accumulation no longer includes a detected boundary jump or the return from an excluded flash. Color enable expressions use a conservative 2^46 absolute-tick ceiling. Dual-pipe callbacks are scoped before consuming their correlator, making borrow and cleanup lifetimes explicit. Per-packet stdout flushing is requested for small frames.

The final independent suite was expanded to **32 cases**. Added media checks cover adjacent-shot adjustment resets, nearly equal-luma chroma cuts, explicitly 10-bit SDR metadata and tiny full-frame-rate media. The final pass used the literal source filter templates and actual Rust render metadata flag recipe: **32 passes, no failures**.

The package supplies **78 color-core and 12 native-color Rust tests**, alongside the earlier 426 tests: **516 declarations total**. The added tests cover malformed settings, nonfinite gains, scenes/flashes/known cuts, full coverage, HDR guards, range changes, neutral-patch stability, bypass/locks, migration, pending output blocking, native scan/render/preview/cancellation and audio-stem independence. **None has been executed here.**

## Checks that do not establish correctness

A lexical/delimiter scan is useful for catching malformed source text; it is not Rust parsing, typechecking, borrow checking or compilation. The Python harness's scene reference is separate code, so its results do not certify `SceneAnalyzer`. ffprobe tags and full decode do not certify HDR pixels, every codec, or a complete player pipeline.

The project/save/review/cancellation assertions require execution of the supplied Cargo suite in a build environment. Source review does not substitute for those tests. No calibrated monitor study, representative camera corpus, Dolby Vision file or native Windows/macOS integration was evaluated.

## Before release qualification

Compile/typecheck, format and run Cargo/Clippy; run all real native integration tests; exercise the actual host's permissions/jobs/UI/player; assess bright/dark/colored/skin/flash footage on the supported display pipeline; qualify each advertised runtime/platform; and test long-media resource behavior. HDR-preserving operations remain explicitly outside the implemented path, not a claimed completed qualification.
