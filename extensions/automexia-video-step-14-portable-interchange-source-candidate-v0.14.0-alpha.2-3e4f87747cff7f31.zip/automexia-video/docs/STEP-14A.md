# Step 14A — Reviewed single-source clip assembly

**Package:** 0.14.0-alpha.1. **Project schema:** 10. **Status:** source implementation candidate; Rust/native execution and actual-host qualification remain open.

The original [Step 14 roadmap](video-roadmap.md#step-14--preserve-the-advanced-feature-backlog-without-bloating-the-first-release) preserves a broad, demand-driven backlog. This increment implements a bounded part of larger-project editing and advanced timing: an authored sequence of ranges from one selected source. The full Step 14 backlog remains open.

## User-visible behavior

Each output variant can hold its own optional assembly. A user may insert a source range, move it to another sequence position, repeat it under a new stable ID, trim its source range, remove it, or set constant 0.5×/1×/2× speed. Changes reset assembly to `needs_review`. Locked assemblies require explicit unlocking. Approval is an explicit review operation; rendering rejects active unresolved assembly.

For example, a variant can play source seconds 8–10, then 0–2, then 8–10 again at half speed. The second appearance of 8–10 is a distinct occurrence with its own ID and output interval. Editing one occurrence does not silently edit the other or a sibling variant.

Source edits remain authoritative. Assembly intersects each requested range with the shared retained timeline, preserving cuts rather than restoring removed media. Existing protection/manual-override semantics still apply while producing that retained timeline. Every entry must contain some retained material; an entry that becomes entirely removed produces a contextual error instead of silently disappearing. Source edits can split one entry into several retained pieces.

## Saved model and limits

`variants[].assembly` contains `AssemblySettings`: `enabled`, `disposition`, `locked` and `clips`. Every `AssemblyClip` carries a unique stable `id`, exact half-open source `range`, and typed `speed` (`half`, `normal` or `double`). No source bytes, arbitrary FFmpeg filters, shell text or new execution authority are saved.

| Bound or rule | Step 14A behavior |
|---|---|
| Sources rendered | One selected source; multisource assembly rejected |
| Authored occurrences | 1–64 clips |
| Effective retained segments | At most 128 after cuts split entries |
| Stable clip identity | Unique bounded ASCII identifiers |
| Per-clip speed | 0.5×, 1× or 2× |
| Existing global speed | 0.5×, 1× or 2×, applied after assembly |
| Effective segment speed | 0.25×, 0.5×, 1×, 2× or 4× |
| Source intervals | Positive, in-bounds half-open ranges |
| Empty entry after authoritative cuts | Explicit error |
| Disabled or ignored assembly | Bypassed; valid saved data retained |
| Pending active assembly | Reviewable, blocks affected variant execution |
| Absent assembly | Shared chronological timeline, preserving previous behavior |

Schema 1–9 projects migrate with assembly absent. A document declaring schema 9 or earlier may not include the new field, including `null`. Old readers cannot read schema 10. See [the current format](AMXV-FORMAT.md).

## Timeline, media and presentation

The source timeline resolves first, then variant assembly, then existing global timing/dissolves. Exact rational arithmetic maps every occurrence between source and output. Source-to-output mapping returns all matching occurrences; output intervals may have two contributors during a dissolve. Consumers cannot assume a source timestamp appears only once.

Rendering splits the selected source into bounded branches, trims each exact span, applies effective speed, and assembles output in authored order. Audio uses staged 0.5×/2× tempo filters for effective 0.25×/4×, with exact output sample targets. Changed-speed selected audio requires both source and output spans of at least 100 ms. The compiler supplies 250 ms input-tail padding before the windowed tempo filters, then trims the real emitted output; it does not hide missing tempo output with post-filter silence. These pitch-preserving WSOLA filters can shift or lose isolated transients. Exact sample counts establish the output clock, not transient preservation or perceptual quality. Video-only speed entries retain their frame-grid rules without this audio minimum. Each segment uses `ceil(output_end × sample_rate) − ceil(output_start × sample_rate)` samples. The final target is `ceil(total_duration × sample_rate)`; fractional clocks do not accumulate per-clip sample loss.

Video branches normalize to one global output frame index after assembly. This prevents per-branch microsecond rounding accumulating through repeated one-frame NTSC clips. Non-unit timing requires existing verified constant-frame-rate evidence and exact frame-grid/duration constraints. Reordered unit-speed branches use the verified timing path. A bounded retained-branch estimate rejects excessive future-frame/audio retention before execution; this estimate is not a total process-memory guarantee.

Graphics, source animation, volume, color and framing remain bound to source time. Repeating a span reproduces its source phase at the corresponding output speed. Supplied/generated captions map to each occurrence; generated word timing continues to exclude removed material. Pairwise dissolves mix complete source contributions, including presentation. Audio packets are normalized before `acrossfade` without padding, so mixed tempo branches retain their full intended sample counts.

## Preview and export

An active assembly uses a bounded whole-sequence before/after preview. Before plays selected source coverage once chronologically at normal speed, with processing disabled. Proposed preserves authored order, repetition, speed and resolved processing. Source-time boundary focuses are rejected for active assembly because a repeated source position is ambiguous. The disclosed source window is the source envelope and can include unplayed gaps; each actual proxy must fit the configured maximum window, at most 30 seconds.

Normal-speed assemblies preserve repeated linked video/audio references in editable OTIO, legacy FCP7 XML and restricted CMX3600 exports. Markers map to all occurrences. Per-entry speed requires explicit visual bake, including when an audio stem is requested. Pending assembly blocks export; event/marker bounds are checked before generating assets. Actual editor imports remain unverified.

The separate HDR preservation workflow accepts only its existing single contiguous, unit-speed interval constraints. It explicitly rejects reordered/repeated or speed-changing material it cannot preserve. See [HDR preservation](HDR-PRESERVATION.md) and [interchange formats](INTERCHANGE-FORMATS.md).

## Integration workflow

Use existing `Project` and token-bound `ReviewSession` mutators. Begin from a project with selected source metadata; construct or modify variant assembly, inspect affected duration and review rows, preview the whole sequence, explicitly approve it, then invoke normal selected-variant rendering/export. New edits invalidate old review/preview bindings through revision changes.

Pure `AssemblySettings` helpers cover insertion, movement, repetition, trim, speed and removal. They are not host commands or file permissions. Typed `VideoCommand` assembly operations use the existing dispatch boundary. A host must expose these controls through its own UI/action contract; no installed command or ABI is invented here.

The native developer example `assembly_smoke` demonstrates project creation, reviewed variant assembly and normal rendering. Its invocation is documented in [Quick start](QUICKSTART.md); it requires the approved native runtime and has not executed here.

## Verification and remaining scope

[Current verification](VERIFICATION.md) separates executed Python tooling and generated FFmpeg reference recipes from authored Rust tests and unexecuted native/host integration. `tests/media/run_assembly_checks.py` checks real encoded/decoded reordered/repeated frame markers, fractional output clocks, exact PCM counts, repeated impulses, mixed speeds, source-time graphic/caption-plate lifetimes, volume and dissolves. Caption plates exercise timing/composition only; they do not execute the Rust subtitle parser or rasterizer.

Before claiming functional completion, run Rust/native suites with Rust ≥1.85, a reviewed lockfile and approved FFmpeg/ffprobe ≥7.1; exercise actual host controls and preview lifetime, supported platforms and claimed editor imports. Multisource/multicamera projects, continuous ramps, beat-aware editing, speaker tracking, additional vision models, segmentation and modern interchange expansion remain future Step 14 increments.
