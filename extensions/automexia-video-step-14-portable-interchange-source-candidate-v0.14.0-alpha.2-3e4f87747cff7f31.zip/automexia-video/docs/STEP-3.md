# Step 3 — review edits and render disposable A/B previews

**Product:** Automexia Video, same `automexia-video` Rust crate; package 0.3.0.  
**Scope:** implement the review/preview step on the Step 2 project and media core.  
**Verification boundary:** the FFmpeg recipes were executed on actual encoded media; the Rust crate and its tests were **not compiled or executed** in this environment. This is source for integration/build review, not a qualified terminal binary. No terminal source is required to use or adapt this core.

## What is implemented

| Requirement | Concrete implementation |
|---|---|
| Review saved edit intent | `VideoExtension::review_project`, `ReviewSession`, paginated `ReviewView` and `ReviewDetail` over the real `Project` model |
| Explain decisions | Stable clip/operation identity, exact source ranges, reasons, generator attribution, disposition, enabled/locked state and marginal duration comparison |
| Approve/reject/enable/disable/lock | Typed `ReviewCommand` dispatch invokes transactional project mutations; no display-string execution |
| Keyboard-complete core flow | Next/previous/first/last/select/filter/inspect/back/close commands, with stable selection and focus-return instruction |
| Short previews | Real media plans for original/proposed MP4 proxies, explicit source window, saved variant, resolution and byte limits |
| Audio A/B | Both proxies carry the same explicitly selected audio stream, including its timing/channel layout; no fabricated audio for video-only input |
| Preview pending edits safely | A separate hypothetical project copy; original approvals, revision and render history never change |
| Reject stale results | Project revision plus decision digest, view/session tokens, latest-request preview tickets and file revalidation |
| Temporary ownership | Unpublished `OutputLease`s held by `PreviewSet`; dropping the set removes only its owned temporary files |
| Existing player integration | Optional `PreviewOpener` receives a revalidated file; no new video player, window, browser or global shortcut |
| Preserve final-render safety | Active `NeedsReview` decisions still block `render_project`; preview never weakens that gate |

No silence detector, denoiser, subtitle generator, model download or AI feature is introduced here. A/B in this edition compares existing range edits; it is not a claim of audio enhancement.

## 1. Review the project already loaded by the host

Use the existing `ProjectStore` to load an approved `.amxv`, then call `review_project`. Opening review needs no codec worker, media scan or filesystem access. The session owns a bounded project snapshot, not a second project format or database.

Rows include both explicit keep clips and edit operations. Source times are exact rationals. Ordering is deterministic by source, range, type and identity. A filter is bounded literal text with case-insensitive AND-of-words matching; it is not a regex, shell command or query against media.

The default page holds 50 rows; callers may choose 1–100. The search is limited to 256 UTF-8 bytes. Existing project limits remain in effect: 4 MiB serialized project, 512 clips, 1,024 operations, and 128 render segments. The UI adapter should materialize only the supplied page, not one widget per project entry.

`confidence` is deliberately `None`: the current schema has no calibrated model score. Reasons are preserved in the project, while control/format characters are escaped for presentation. Do not render a reason as HTML, a command, or a trusted link.

An empty operation list is a normal review state: explicit keep clips remain visible. A fully removed timeline stays reviewable with a “no retained media” message. Invalid projects are rejected rather than padded with invented clips.

## 2. Apply explicit review decisions

| Command | Effect |
|---|---|
| `Approve` | Explicitly enables the selected operation and sets `AutoApply` in one revision |
| `Reject` | Disables the operation and sets `Ignore`, restoring its contribution to the source timeline |
| `SetEnabled(false)` | Disables the operation without deleting its record |
| `SetEnabled(true)` | Re-enables it without converting `NeedsReview` or `Ignore` into approval |
| `SetLocked(true/false)` | Locks or explicitly unlocks the operation/keep clip |
| `ChangeRange(range)` | Validated range change; an operation becomes `NeedsReview` again |
| `Inspect` / `Back` | Enter detail / return to list; back from list closes the panel |
| `Close` | Cancels linked preview work and asks the host to restore focus |

Approving a generated removal records an explicit manual override. Under the existing Step 2 rules, manual removals can cross regions protected against generators; the detail explanation makes that distinction visible.

A locked edit cannot be approved, rejected, enabled/disabled or adjusted until explicitly unlocked. Approval and rejection are not applicable to a keep clip: that clip already represents a manual assembly decision. It can be adjusted or locked through the appropriate commands.

Changes are prepared and validated on a clone, including the resulting review view, before committing. Invalid input must not partially update a project or advance its revision. Original generator attribution remains intact; an explicit user choice is represented by the existing `user_override` field.

Detail durations are counterfactual **whole-project** durations with the selected operation off/on and other pending decisions explicitly omitted. Overlapping removals or protected ranges can make an operation’s marginal effect zero. These values are not automatic approvals or claims that every codec can render the project. Locked decisions retain their existing protection semantics.

The session tracks changes relative to the snapshot it opened. `dirty == false` does not establish that an arbitrary in-memory project was ever saved to disk. Saving remains an explicit call to `save_project`; call `mark_saved` with the exact saved binding only after successful persistence. An outdated save completion cannot clear newer changes. Reload refuses to discard dirty decisions unless the caller explicitly authorizes that discard. Closing the review does not itself write or delete the project; keep the session until the host resolves unsaved work.

## 3. Render a specific review window

`PreviewRequest` names the project location, existing scratch directory, selected clip/operation, saved output variant, source focus, intent and limits. `new` uses the first saved output variant by default; `variant_id` can explicitly select another. Unknown variants are rejected, never guessed.

**Default:** at most 12 seconds of source footage, two seconds of contextual padding, encoded-raster bounds 640×360, and 32 MiB per encoded file. Hard request limits are 30 seconds, 1280×720, and 64 MiB per file. Use tighter limits when the real host requires them.

`Whole` includes the operation and contextual footage. When that exceeds the limit, the request fails with an instruction to choose `StartBoundary`, `EndBoundary` or `At(source_time)`; it does not silently hide most of a long edit. Boundary/explicit-time windows are clamped to the actual source. Coverage and exact ranges are returned for the host to display.

The source’s display orientation is normalized through the existing renderer. Downscaling never upscales the input and uses even H.264-compatible pixel dimensions. Adjusted sample aspect ratio preserves display aspect, including rotated or non-square-pixel footage. Players must honor that metadata. Saved frame-rate policy and qualified color/audio properties remain in effect; the proxy changes only quality/speed/thread and size settings on its private copy.

**Before** is original footage within the window. **Proposed** is the current resolved edit assembly in that window, with the selected operation applied hypothetically only when `ApplySelected` is requested. `CurrentResolved` applies no extra hypothesis. Other active pending proposals are omitted and listed explicitly. A locked inactive/pending decision must be unlocked before an apply-selected preview; a locked already-applied decision retains its existing semantics.

If the proposed edit removes the entire window, `proposed_timeline` and proposed metadata are `None`. Show “no retained media in this window”; do not fabricate a black clip or return the original as the proposed result.

Both sides use the real Step 2 source-tick video selection and sample-based audio assembly, then the low-resolution scale/SAR filter. They are rendered sequentially through the same `MediaHost`, not a separate process API or scheduler. FFmpeg/probe capability checks occur before either file is staged. The selected audio is retained; absent leading/trailing audio follows the existing explicit padding policy. Progress describes sequential component operations: an encoder `progress=end` for the first side does not complete the pair. Wait for `preview_edit` to return a validated `PreviewSet` before presenting overall success.

A/B files may have different durations. Their same elapsed playback second need not identify the same source time. Use the returned source/output timeline maps when implementing a synchronized comparison UI. Step 3 does not invent a native scrubber or claim synchronized host playback.

## 4. Keep files private, bounded and disposable

Each side is staged using `CreateNew` through the existing `OutputLease`. **The proxy path is never published** to a final delivery destination and the project is never automatically saved. A completed A file is also dropped if generating B fails.

After encoding, each file is identified, checked against its byte limit, probed for the expected dimensions/duration/streams/color policy, fully decoded, and revalidated. The original source is revalidated throughout. Reusing the native adapter adds monitoring of the request’s tighter output limit; the final returned files cannot exceed it. Monitoring is not an OS-enforced disk quota: temporary writes can overshoot between checks before the process is stopped.

The pair retains at most twice the per-file compressed limit. This is not a process-RSS limit or a system-wide disk budget. There is no automatic persistent cache or global preview registry. The host should keep only its current result and drop replaced/closed results. The request key identifies the requested decisions, window, variant and settings; **it is not a complete cross-runtime cache key**. Actual runtime identity and encoded output digests are available separately.

`PreviewSet` owns both leases and is movable between the existing worker and host-owner tasks. `OutputLease` now requires `Send`; the supplied native implementation and test leases meet the intended ownership shape. A custom lease containing thread-affine state must be adapted rather than marked thread-safe without justification.

A running player must retain the owning set until playback ends and close its handles before dropping it, particularly on Windows. The core does not own external player lifetimes or guarantee deletion while another process holds a non-shareable handle. A host requiring stronger crash-recovery cleanup should use its current temporary-resource owner, not delete arbitrary scratch files by filename pattern.

The shared decoder can scan preceding footage. Short output duration does not guarantee low latency on a long/slow input. Existing host deadlines, cancellation and CPU limits still apply; no false fast-seek guarantee is made.

## 5. Reject stale selections and async completions

A review token includes session identity, view revision and the project decision binding. A binding includes project ID, revision and decision digest, so hand-edited JSON with an unchanged revision cannot reuse an old decision. Render history alone does not change edit intent. The current project is the host-owned in-memory snapshot: an external `.amxv` edit requires the host to reread/reload it before acting. This core does not add file watchers or claim to detect an external project edit without that refresh.

Use `begin_preview(token, request)` before scheduling a preview and keep its `ReviewPreviewTicket` beside the job. A newer focus, variant or request cancels the earlier ticket, even when the project and selected operation are unchanged. Before displaying the result, call `accept_preview(ticket, result)` on the owning session. This checks latest-request identity as well as the view, selected target, cancellation and project binding.

Changing project decisions, selection, filter, page, source binding, or reloading/closing invalidates applicable prior view results. The lower-level `validate_preview` method checks view/selection only; it is not a replacement for the ticket path in an asynchronous UI.

Before actual playback, `open_preview` rechecks the current project, the original source, the exact proxy file and the lease path. Changed source bytes or a modified proxy must not reach the opener. Opening does not approve, save or publish anything. Opener failure/panic is reported without changing project intent; the host remains responsible for rolling back any partial player-side action.

## 6. Wire ordinary existing host actions

The core is behind the proposed `video review PROJECT` operation, but it does not fabricate a shipped command parser or loader. Map your existing dispatcher and UI events to the local `ACTIONS` descriptors and session commands. Keyboard, pointer and palette actions should converge on this same path. Preserve the host’s theme, accessibility, reduced-motion and focus behavior.

The new optional adapter is only:

```rust
pub trait PreviewOpener {
    fn open(&mut self, preview: &VerifiedPreview<'_>) -> Result<()>;
}
```

It receives an already revalidated local file plus review metadata. Implement it using your approved existing media preview or file-opening facility. No shell command, executable path, arbitrary URL or raw terminal injection is accepted by this trait.

`MediaHost` retains its five methods and `ProjectStore` retains its two. `MediaTask` adds no arbitrary process operation. File references in `.amxv` remain requests, not grants: authorize source, scratch and project/output access through the current host policy. The optional `NativeMediaHost` is a local integration adapter, not an OS sandbox.

On extension disable, route removal or review close: cancel the job ticket, close playback, drop the proxy set, and use the existing UI owner to restore focus. The library reports `restore_host_focus`; it cannot directly prove or perform a native focus change without your adapter.

## 7. Minimal integration flow

The following belongs inside the current host’s fallible action/job implementation. `video` has a `MediaHost + ProjectStore`; paths and `opener` have already been authorized by the host.

```rust
use automexia_video::{Cancellation, PreviewRequest, PreviewSide,
    ReviewCommand, ReviewTarget};

let cancel = Cancellation::new();
let loaded = video.load_project(&project_path, &cancel)?;
let mut review = video.review_project(&loaded.project)?;
let view = review.snapshot()?;
let view = review.dispatch(&view.token,
    ReviewCommand::Select(ReviewTarget::Operation(operation_id)))?;
let view = review.dispatch(&view.token, ReviewCommand::Inspect)?;
// Present `view` with the existing UI, not a new terminal renderer.

let request = PreviewRequest::new(review.project(), &loaded.path,
    &scratch_directory, review.selected_target(&view.token)?)?;
let ticket = review.begin_preview(&view.token, &request)?;
// Run the blocking media call on your current background executor.
let previews = video.preview_edit(review.project(), &request,
    &ticket.cancellation(), &mut progress)?;
review.accept_preview(&ticket, &previews)?;
video.open_preview(&previews, review.project(), PreviewSide::Before,
    &mut opener, &cancel)?;

// Only after the corresponding explicit user action:
let view = review.dispatch(&view.token, ReviewCommand::Approve)?;
review.dispatch(&view.token, ReviewCommand::SetLocked(true))?;
// The old previews are now stale. Stop player handles, then release them.
drop(previews);
let binding = review.binding()?;
video.save_project(review.project(), &loaded.path,
    &automexia_video::OutputPolicy::ReplaceReviewed(loaded.stamp), &cancel)?;
review.mark_saved(&binding)?;
```

For asynchronous use, send an immutable project/request snapshot plus cancellation to the worker; receive the result on the owning task and call `accept_preview`. Do not hold UI locks across FFmpeg work. A normal save/replace remains subject to actual user consent and current-file identity.

`examples/review_smoke.rs` exercises the same Rust calls once compiled, using an explicitly synthetic cut proposal. Its opener deliberately copies A/B files to named new demo outputs; that is an example-only archival action, not the default lifecycle or a fabricated native player.

## 8. Tests and boundaries

[VERIFICATION.md](VERIFICATION.md) distinguishes **60 executed independent FFmpeg recipe checks** (19 foundation, 18 cuts, 23 proxies) from **256 supplied Rust tests, none executed here**. Step 3 adds 73 core review/preview tests and 20 native review tests. The supplied CI runs both Cargo configurations and all media recipes; it was not run remotely in this turn.

New tests cover transactionality, decision persistence, locks, stale/foreign tokens, source changes, latest-focus rejection, pending-only previews, exact window geometry, no-media outcomes, source protection, byte limits, cleanup, cancellation and failed/panicking openers. Real-media checks cover ordinary/VFR/fractional/CFR footage, selected/missing/delayed/stereo audio, rotation/SAR, color, tiny and edge windows, corrupt media, literal filenames and decoded synchronization.

No test here establishes Automexia native UI/player/focus behavior, Windows/macOS operation, audible quality judgments or all-camera compatibility. Preview plans are limited to the same single-source, progressive 8-bit SDR H.264/AAC output profile as the current media core. Unknown future effect kinds are not silently approximated. Nothing in this milestone enables automatic analysis or AI.
