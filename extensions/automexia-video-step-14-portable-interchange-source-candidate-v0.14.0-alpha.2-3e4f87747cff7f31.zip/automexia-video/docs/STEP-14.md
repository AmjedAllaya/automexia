# Step 14 — Optional advanced increments

Current source edition: **0.14.0-alpha.2**, project schema **10**.

The roadmap defines Step 14 as an optional backlog. The supplied source now contains these bounded increments:

- [Step 14A: reviewed single-source assembly](STEP-14A.md), retained from alpha.1.
- [Step 14B: portable export bundles and modern FCPXML](STEP-14B.md), added in alpha.2.

See [the current review](STEP-14B-REVIEW.md), [verification](VERIFICATION.md) and [original roadmap](video-roadmap.md). Multisource/multicamera editing, continuous speed ramps, new vision models and the rest of the optional backlog remain future work. No Rust/native/actual-editor qualification is inferred from source or reference recipes.
