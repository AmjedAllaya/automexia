# `.amxv` schema 10 — reviewed variant clip assembly

Version **0.14.0-alpha.1** writes schema **10**. Built-in migrations accept known schemas **1–9** without enabling optional processing or approving proposals. Older readers cannot open schema 10. Unknown newer versions, duplicate keys, unknown fields and malformed historical documents are rejected.

| Field | Current meaning |
|---|---|
| `format` / `schema_version` | `automexia-video` / `10` |
| `sources` | Explicit source references, content fingerprints, selected media streams, source clock and geometry |
| `assembly` / `operations` | Retained source ranges and reversible decisions with stable IDs, provenance, dispositions and locks |
| `settings` | Frozen render/workflow settings and optional pause, classical voice, color and voice-enhancement decisions |
| `variants[].assembly` | Optional reviewed sequence of 1–64 source-range occurrences with stable IDs and typed per-clip speed; intersects authoritative retained source edits |
| `variants[].timing` | Optional reviewed `TimingSettings`: enabled/disposition/lock, `half`/`normal`/`double` playback speed, exact output-time dissolve duration |
| `variants[].framing` / `presentation` | Variant-local editable crop, graphics, captions and bounded animation |
| `variants[].output_profile` | Optional frozen delivery profile |
| `variants[].presentation.captions.document.generated_words` | Optional generated-caption word timing, retained through subsequent cut/speed mapping; manual cue edits clear stale generated-word annotation |
| `transcript` | Optional source-bound original recognized words, editable word state, uncertainty/review/locks and model/source provenance |
| `renders` | Bounded history of explicitly recorded output results |

Schema 8 introduced the optional reviewed voice-enhancement record. Schema 9 adds `transcript`, variant-local `timing` and optional generated-caption word timing. A document declaring an older schema cannot include these schema-9 fields, even with null values. Migration creates absent optional state; it does not infer timing or transcribe media.

Schema 10 adds `variants[].assembly`. Projects declaring schema 9 or earlier cannot include it, even as null. Migration leaves assembly absent; no clip order, repetition, speed or approval is inferred.

Exact clocks use rational strings such as `"1001/30000"`. Saved geometry/confidence values remain finite floating-point values; the `serde_json` `float_roundtrip` feature prevents accepted floating-point values from changing during a save/load cycle. Limits, semantic validation and revision/source identity checks still apply.

`Project::timeline()` represents the shared retained source assembly. `Project::timeline_for_variant()` intersects the selected variant's reviewed clip assembly with that retained source timeline, then applies reviewed global speed and dissolves. A source timestamp can map to several output occurrences; use the complete mapping result. A dissolve intentionally has two source contributors during the overlap; consumers must use the overlap-aware mapping API rather than assume one source for every output instant.

Transcript recognition does not modify the project. Explicit report adoption and subsequent word corrections go through project transactions. Original observations and edited state remain distinguishable. Transcript filler and sentence-punch-in operations are pending proposals, not silent automatic cuts or speaker/emphasis recognition.

The normative definitions and validation are in [project.rs](../src/project.rs), [assembly.rs](../src/assembly.rs), [timing.rs](../src/timing.rs) and [transcript.rs](../src/transcript.rs). Source references, project saves and export publication still require the host's explicit permissions; a stored path or digest grants no access.

---

## Retained schema 6 and earlier reference

The following sections describe historical schemas only. Current output is schema 10; consult the current field summary and Rust definitions above.

# `.amxv` schema 6

**Status:** schema 6 adds variant-local presentation; schema 5 adds per-variant framing; schema 4 adds source-bound, reviewable shot-color settings; schema 3 added explicit source-bound classical voice-cleanup settings to schema 2; schema 2 introduced pause-cleanup settings. This is a Video project document, not a terminal installation manifest, WIT interface or authority grant.

The normative field definitions and validation are in [project.rs](../src/project.rs). A complete example is [basic-cut.amxv](../samples/basic-cut.amxv); this example references the included input by size and SHA-256. Large observations and decoded media are not embedded in the project.

## Document layout

| Field | Meaning |
|---|---|
| `format` | Must be `automexia-video` |
| `schema_version` | Must be 6; schemas 1–5 have known no-new-processing migrations |
| `id`, `revision`, `next_id` | Stable project identity, checked edit revision and generated-ID counter |
| `sources` | Source identities, local paths, content fingerprints, selected-stream snapshots, origin and duration |
| `assembly` | Chronological keep clips, each with a stable ID, source ID, range and lock |
| `operations` | Reversible removal/protection decisions, explanations and provenance |
| `settings` | Resolved preset name/revision, render-settings snapshot and optional `pause_cleanup` / `voice_cleanup` / `color_correction` |
| `variants` | Named, explicitly resolved render settings and optional `framing` and `presentation`; `main` is created initially |
| `renders` | Bounded history of explicitly recorded results |

Objects reject unknown fields; duplicate keys are rejected even inside nested objects. Exact time values are strings such as `"1001/30000"`, not floating-point frame counts. Optional metadata is null or absent where serde's optional-field rules allow it. Required settings have no automatic defaults.

## Source identity and location

`fingerprint` stores `{ "size": ..., "sha256": "..." }`. Persisted equality is content-based rather than inode-based, so moving the same footage can be relinked. During a single native operation, the existing `InputFile/FileStamp` additionally rechecks observed file metadata. A project digest or a path is not permission to read that file.

Relative paths resolve against the absolute project directory. They must not contain `..`; when the source is outside that directory, store an explicit absolute reference. Non-UTF-8 paths, URL syntax and controls are rejected rather than lossy-converted. Save-as requires deliberate rebasing; moved media requires approved inspection and relinking.

Only selected streams are stored. They retain relevant geometry, color, frame-rate and codec timing. Descriptive tags and raw sampled packets are excluded; a legacy rotation tag is retained as geometry. Large observations belong in a later disposable cache, not this document.

## Time semantics

Each source has an exact `timeline_origin` equal to the first selected video presentation time, and a positive known video `duration`. Edit intervals are half-open `[start,end)`, nonnegative and relative to that origin. A range must not exceed its source.

The timeline concatenates retained source spans. Adjacent spans may coalesce in the render plan while distinct clip IDs remain editable. Removed source times map to no output time. An output endpoint is outside a half-open segment, preventing duplicate boundary ownership.

Audio/video use this shared map. Actual rendering has discrete video frames and sample-quantized audio; effective rendering boundaries are exposed separately in `EditRender`. Saved source intent is never rewritten to hide quantization. Boundaries outside the exact-integer range of FFmpeg expression evaluation are rejected before rendering.

## Operation semantics

An operation contains:

```json
{
  "id": "edit-2",
  "source_id": "source-1",
  "kind": "remove_range",
  "range": { "start": "1/2", "end": "1/1" },
  "reason": "Remove an unwanted section",
  "origin": { "kind": "manual" },
  "disposition": "auto_apply",
  "enabled": true,
  "locked": false,
  "user_override": true
}
```

Supported operation kinds are `remove_range` and `protect_range`. Dispositions are `auto_apply`, `needs_review`, `ignore`. Generator provenance is `{ "kind":"generator", "id":"...", "version":"..." }`.

A manual decision or `user_override` survives replacement of generated proposals. This preserves the original generator attribution when a user changes it. Locked operations require unlocking before normal modification. Protected ranges and locked clips block generated removals, not a later explicit user removal. Only manual operations can protect ranges.

Pending enabled operations block rendering. Ignored/disabled operations do not affect the timeline. An entirely removed timeline can be saved as a draft but cannot render. The format stores edit intent, never arbitrary FFmpeg arguments or shell text.

## Bounds

| Object | Current ceiling |
|---|---:|
| Encoded project | 4 MiB |
| Sources represented in schema | 16 |
| Sources rendered in this edition | **1** |
| Keep clips | 512 |
| Edit operations | 1,024 |
| Effective render segments | 128 |
| Output variants | 16 |
| Render history records | 64 |
| Source duration | 7 days |
| Identity | 64 ASCII identifier bytes |
| Edit reason | 1,024 bytes, no controls |
| Project source path | 4,096 UTF-8 bytes, local only |
| Color filter chain | 24 KiB |
| Combined edit/color filter graph | 48 KiB (existing 30 KiB command limit can fail earlier) |
| Edited command arguments | 30 KiB |

These are implementation limits, not measured performance SLOs. Encoded-size bounds do not bound all Rust allocator/serde/FFmpeg overhead. Programmatic objects also pass validation before use, but callers must not allocate unbounded objects before invoking it.

## Settings and migrations

Frame-rate policy, CRF, speed and thread count are explicit. `main` stores the initial snapshot; changing global presets does not change a saved variant. Changing variant settings is an intentional project edit.

Import accepts schema 6. The known 5→6 migration leaves presentation absent; pre-6 files cannot carry that field. The built-in 4→5 migration leaves every variant unframed; pre-5 documents cannot contain the new field. The built-in 3→4 migration leaves color settings absent and preserves all older decisions. A schema-3 file carrying `color_correction` is rejected. The built-in 2→3 migration preserves prior decisions and leaves `settings.voice_cleanup` absent, adding no audio processing. A schema-2 file that already carries the schema-3 field is rejected. Schema 1 follows its known 1→2 migration (no pause profile/fades), then 2→3. Unknown older formats require explicit pure `ProjectMigration` functions; unknown future semantics are rejected. Older schema-1/2/3 readers cannot read newly saved schema-6 documents.

When pause cleanup is present, every `PauseSettings` field is explicitly saved and validated. It is not resolved from global defaults on reopen. The current `video-energy-pauses` generator version `1` requires this snapshot. The snapshot includes analysis thresholds/padding/limits/content declaration and the 0–10 ms join-fade setting. Current paused cuts remain ordinary `remove_range` operations, and all newly generated cuts are `needs_review`. Large measurements and per-frame data are not embedded.

Join fades are derived only at a timeline gap to which an applied pause removal actually contributes. They do not change time. Ordinary manual cuts, disabled pause edits, contiguous splits and migrated schema-1 projects retain prior behavior. Changing the fade setting while retaining reviewed/locked pause operations is blocked in the analysis-application path, rather than silently altering prior approvals. See [Step 4](STEP-4.md).

## Persistence and provenance

Create-new is the default save policy. Replacements require the host's explicit reviewed target identity and repeat validation. Atomic publication avoids partial JSON; the host must serialize competing writers. Local checks do not establish a portable adversarial compare-and-swap or filesystem power-loss guarantee.

Render history is optional and added explicitly. It does not change the edit revision/digest. Runtime and output fields describe that observed render, not a promise of bit-identical compressed files after changing encoders.


## Classical audio profile (schema 3)

`settings.voice_cleanup`, when present, contains `version`, `source_sha256`, `stream_index`, every resolved `VoiceSettings` field, concrete `VoiceStages`, and optional compact `AudioPreflight`. An Off profile may omit preflight; an active profile cannot. Source hash, selected stream, rate, channel count, evidence consistency and deterministic stage resolution are validated. The source-bound fields are not capabilities or file-access authority.

Statistics contain bounded per-channel RMS/peak/DC/clipping warnings, low-band/quiet-window observations and tone persistence. There is no raw PCM or per-frame media buffer in JSON. Defaults are construction conveniences, not serde defaults for saved fields. Unknown fields/versions and nonfinite values fail.

Analysis returns a report; explicit apply or reconfiguration commits the profile in one project revision and invalidates review/proxy bindings. `None` fully bypasses treatment without removing any cut. Changing cuts intentionally invalidates the normalization measurement: gain is recalculated from the exact processed assembly rather than saved as an obsolete source-wide number. Source-bound stage choices remain as accepted.

Transient `AudioRenderReport` values expose actual output loudness/peak and correction passes. Existing render-history schema is not expanded to pretend it stores those full observations; callers may retain returned render reports separately. See [Step 5](STEP-5.md) for controls, chain order, limits and integration.

## Shot color profile (schema 4)

`settings.color_correction` stores color subprofile `version: 1`, source ID/hash/stream/duration, every `ColorSettings` field, global enabled state and contiguous `shots`. Each shot includes ID, exact source range, boundary kind, bounded `ShotEvidence`, resolved `ColorAdjustment`, disposition, enabled/locked/user-override flags and reason. Parameters use bounded finite values. There are at most 128 shots; all cover the source once in order. No pixel buffer or arbitrary filter text is stored.

Color decisions are separate from time-edit operations: no new duration-changing `EditKind` is invented. Active pending color blocks final video rendering without changing the timeline duration. Review, explicit decision changes, bypass and reset increment project revision and invalidate old previews through the existing ownership rules. Automatic rescans retain exact-range reviewed/locked choices or fail rather than repartition them silently.

Bypass preserves pending/rejected/approved settings. Explicit clear forgets the color profile, including locks, without removing audio/time edits. A hypothetical preview operates on a private copy and cannot approve saved decisions. Older projects and disabled profiles do not receive new global color defaults. See [Step 6](STEP-6.md).


## Variant framing (schema 5)

`variants[i].framing` is absent when bypassing the new feature completely. When present it stores all `FramingSettings` fields: version 1, target even width/height, tagged Fit/crop mode, safe-zone insets, scale limits, optional preset name/revision, enabled state, disposition and lock.

Fit stores a normalized anchor and typed RGB padding. Crop stores source-time shots, exact rational key times, normalized center/zoom poses and explicit motion limits. Times are relative to the original selected video origin, not assembled output time. Shots cover the source once and do not interpolate across reset boundaries.

Safe-zone insets are integer basis points (1/10000 of the output canvas). They are layout metadata, not masks or a current platform contract. Presets are resolved snapshots; edits to them need review. Changing one variant does not overwrite the master edit or a sibling variant.

Validated mutators clear obsolete approval on replacement, retain locks until explicit unlock, advance revision and invalidate stale review/proxy results. Disabled/rejected settings remain stored but do not execute. Pending geometry blocks that variant's final render, not other resolved variants or unrelated audio-only operations.

Only generated bounded numeric filter expressions are compiled; JSON never contains arbitrary FFmpeg expressions, commands, media bytes or credentials. See [Step 7](STEP-7.md).


## Variant presentation (schema 6)

Each variant may store `presentation`: enabled/disposition/lock, explicit guides and collision policy, overlays, supplied captions, volume keys, short source-endpoint fades and raster resource policy. Unknown fields fail. Exact definitions are in [presentation.rs](../src/presentation.rs); behavior and bounds are in [Step 8](STEP-8.md).

Graphic/font references carry a local path, size and SHA-256. Save As rebases them alongside source media, including disabled elements. Captions retain their original UTF-8 document and digest separately from editable cue text/timing. A sidecar-only caption layer has no required font or box; burned-in captions require both.

Approval is group-level for the variant presentation profile. Content/timing changes require review. Disabled/ignored profiles are bypassed; pending active profiles block the affected output. Effects are data, not arbitrary FFmpeg expressions or a new execution authority.

The return value `ProjectRenderResult.presentation_assets` contains observed asset/font/renderer receipts. Existing compact history records are not silently expanded; applications retaining complete render evidence should retain that returned report explicitly. Non-unit speeds and overlapping clip transitions have no accepted serialization in this edition.


## Schema 8 delta

`settings.voice_enhancement` is optional. When present it records the exact source digest/stream, explicit enhancement settings, backend/model/runtime receipt, project-relative or absolute PCM24 stem path, and the published stem fingerprint. A schema-7 project migrates with the field absent and therefore keeps its previous audio behavior. Missing or changed stems block enhanced rendering; they never cause silent fallback.
