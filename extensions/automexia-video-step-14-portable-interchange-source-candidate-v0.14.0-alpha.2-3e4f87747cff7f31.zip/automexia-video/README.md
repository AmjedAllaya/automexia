# Automexia Video

**0.14.0-alpha.2 · Step 14B portable interchange bundles and modern FCPXML · `.amxv` schema 10**

This full Rust source project continues **0.14.0-alpha.1**. Step 14B adds modern Final Cut Pro XML 1.10 and portable OTIO/FCPXML handoffs containing the timeline, its referenced media, a compatibility report and SHA-256 manifest in one ZIP64 archive. Explicit video/audio bakes stay private until the completed archive is published. Existing Steps 0–13 and Step 14A reviewed single-source assembly remain included.

**Current Rust compilation and native execution remain unverified.** The environment has no Rust/Cargo or dependency cache; the earlier official toolchain request failed. Installed FFmpeg/ffprobe 6.1.1 can execute independent reference recipes but is below the native adapter's required 7.1 minimum. This is source and repeatable qualification material; it does not claim to be an installable, production-qualified Automexia extension.

## Start here

- [Step 14B scope, requests and host workflow](docs/STEP-14B.md)
- [Implementation and review record](docs/STEP-14B-REVIEW.md)
- [Current supported scope](docs/SUPPORTED-SCOPE.md)
- [Build and integration quick start](docs/QUICKSTART.md)
- [Documentation index](docs/README.md)
- [Current verification](reports/step14b/verification.json)
- [Repeatable qualification procedure](docs/RELEASE-QUALIFICATION.md)

## This continuation

- Modern **FCPXML 1.10** with exact rational clocks, source/record timecode, pixel aspect ratio, selected mono/stereo audio and local relative media URLs. The existing legacy FCP7 XML writer remains separate.
- Native one-frame Final Cut markers with their exact original ranges and identities retained in metadata and the compatibility report. Unsupported clocks and known excessive XML expansion block before baking.
- Portable **OTIO/FCPXML ZIP64 bundles** with full referenced media, SHA-256 content names, deduplicated compatible identities, bounded metadata and complete archive byte accounting.
- Explicit private ProRes/video and PCM/audio bakes. One create-new publication exposes the complete archive; cancellation/failure before commit cleans private staging, and post-commit uncertainty remains visibly published but unverified.
- Typed `InterchangeCommand` and `BundleCommand` dispatch, optional `BundleHost` support and a separate `portable_bundles` registration flag.
- Two additional independent suites, plus actual Rust-generated XML/archive readback commands for a qualified build environment. No new runtime dependencies or project schema migration.

Step 14 is an advanced-feature backlog. This edition implements the bounded **Step 14B** subset and retains **Step 14A**. Multisource/multicamera assembly, continuous speed ramps, beat editing, AAF and advanced composition remain future work. A portable handoff includes the exported timeline's referenced media; it is not a complete backup of every asset in the original `.amxv` project.

Executed checks and outstanding prerequisites are recorded in [current verification](docs/VERIFICATION.md). Reference fixtures, Rust execution and completed editor/host acceptance are separate evidence layers.

## Build and test

Use Rust/Cargo meeting the declared Rust 1.85 minimum, approved FFmpeg/ffprobe 7.1 or newer, and an explicitly selected test font. The first connected build must generate and review the missing lockfile:

```bash
cargo generate-lockfile
cargo metadata --locked --all-features --format-version 1
cargo test --locked --no-default-features
cargo test --locked --features graphics
cargo test --locked --features native
cargo check --locked --all-features --all-targets
cargo test --locked --all-features --lib
```

Set `FFMPEG`, `FFPROBE` and `VIDEO_TEST_FONT` to approved absolute paths before native/graphics tests. Retain the reviewed lockfile. Model qualification additionally requires explicit files and identities documented in the provider guides.

The default crate has no process/filesystem implementation. `native` selects native media and filesystem adapters; `silero-onnx` and `face-onnx` explicitly select ORT-backed providers. This continuation adds no runtime dependency. The archive contains no compiler, model weights, external runtime binary, font or user recording.

## Integration and acceptance

The package supplies `VideoExtension`, `MediaHost`, typed workflows and registration adapters. The actual Automexia repository, discovery format, ABI, preview UI and installer were not supplied. They must be connected and exercised through the existing host.

Remaining gates include a real Rust build, native execution on the required runtime, actual selected-model execution, supported OS execution, editor imports, and representative visual/listening evaluation. `product_release_qualified`, `step13_complete`, `step14_complete`, `step14a_runtime_qualified`, `step14b_runtime_qualified`, `modern_fcpxml_import_qualified` and `portable_bundle_native_qualified` remain false. Prior reports retain their edition identities; fresh evidence belongs under `reports/step14b/`.
