# 0.14.0-alpha.2 — Step 14B portable interchange

Continues the complete **0.14.0-alpha.1** project with modern FCPXML 1.10 and portable OTIO/FCPXML ZIP64 handoffs. A handoff includes its timeline, complete referenced media, a SHA-256 manifest and a compatibility report. Content names are portable and deduplicated while every inspected input identity remains bound to publication.

Explicit ProRes/video and PCM/stem bakes remain inside private staging. One create-new commit publishes the completed archive; source changes, collisions, cancellation and callback failures before commit leave no public partial bundle. Post-commit readback uncertainty stays visibly published but unverified. Native archive streaming and exact overhead accounting add no runtime dependency. The project schema remains 10.

FCPXML preserves exact rational timing, pixel aspect ratio, selected audio, source/record timecode and one-frame project markers with original ranged metadata. Unsupported clocks, XML characters and known excessive escaped XML size block before baking. The legacy FCP7 writer remains available. New typed dispatch and optional bundle registration connect to the existing host owner.

Independent reviews and regression material cover private-workspace/input binding, archive and metadata limits, source aliases, canonical destination readback and failed-publication cleanup. Executed totals and outstanding prerequisites are in [verification](docs/VERIFICATION.md). Rust compilation/native execution and actual editor imports remain unverified here. No model weights, external binaries, fonts or Cargo.lock are fabricated.

Step 14 remains an optional backlog; multisource/multicamera editing, continuous ramps, AAF and full `.amxv` asset backups are outside this increment. Product, host, native, editor and selected-model qualification flags remain false.

---

# 0.14.0-alpha.1 — Step 14A reviewed single-source assembly

- Continue the supplied alpha.5 source with variant-local reorder, repeat, source-range trim and per-clip constant speed.
- Preserve authoritative source cuts/protections, review approvals, locks, revision invalidation and sibling-variant independence.
- Add schema 10 migration, occurrence-aware captions/effects/preview/export, staged quarter/quadruple tempo and exact frame/sample clocks.
- Correct one-frame branch timestamp collapse and fractional concatenation drift using a global output frame index.
- Add the 17th independent reference suite and final retained-report/log hash verification. No new runtime dependency.
- Rust compilation/native/actual-host/editor qualification remain unexecuted. Current evidence is under reports/step14; earlier counts are historical.

---

# 0.13.0-alpha.5 — Step 0–13 implementation continuation

- Reconstructed from the reattached alpha.3 source; unavailable alpha.4 outputs and old execution counts are not reused as evidence.
- Added explicit action-registration ownership, persistent verified model storage, native advisory locking and optional provider workflows.
- Added RNNoise, UltraFace RFB-320 and whisper.cpp provider source, reviewed placement/face choices, transcripts, subtitles and editorial suggestions.
- Added schema 9, 0.5×/1×/2× playback, bounded dissolves, exact affine timeline mapping and floating-point JSON round trips.
- Corrected audio routing, timing, output/asset validation and export preflight; strengthened qualification and source packaging.
- Fresh Python tooling: 80 qualification/inventory, 64 packaging and 8 architecture tests passed. Independent FFmpeg 6.1 recipe evidence is separately scoped.
- Rust/Cargo and a required>=7.1 native runtime were unavailable. No Cargo.lock or Rust/model execution result is fabricated. Host/platform/editor/human quality gates remain open.

---

## Retained historical release notes

The following entries describe their named editions and are not current Step 14A qualification statements.

# 0.13.0-alpha.1 — Step 13A–B source candidate

- Added explicit verified local model identities, revokeable activations and a
  bounded guard against external ONNX tensor files and custom domains.
- Added opt-in `silero-onnx` CPU adapter, actual typed tensors, bounded inference
  cancellation and per-request model-session ownership. No runtime downloads.
- Added timestamped selected-channel decoding and speech vetoes on existing
  energy proposals. Partial/reset/gap/uncertain observations cannot authorize cuts.
- Added exact model/media/runtime/settings provenance and existing review wiring.
- Kept schema 7, required host methods and all saved non-AI decisions compatible.
- Entire Step 13, actual inference quality, Cargo execution and host qualification
  remain open. No 13C/13D/13E capability is represented as implemented.

# 0.12.0-rc.1 — targeted pre-AI source modernization

One crate; project schema 7 and existing host interfaces unchanged. Adds explicit
owner-scoped observation caches, current-project recomputation, bounded progress
mailbox, a private native runner, pinned runtime capability memoization and
workflow-aware cancellation/drain. Fixes unwind cleanup/reader ownership and
long-held capability memo locking. Existing algorithms and fixtures retained.

No model, persistent cache, new runtime dependency, installer or host engine
change. Rust compilation and actual host qualification remain unverified. See
[Step 12](docs/STEP-12.md) and [current checks](reports/step12/verification.json).

# Version 0.11.0-rc.1 — Step 11 qualification candidate

- Fix native subtitle publication's undefined source-guard call.
- Bind extension-created reviews and previews to owner cancellation and teardown;
  preserve in-memory decisions after closing and prevent re-enable revival.
- Harden Unix fingerprint/project/graphic reads and staged-file checks; reject cancelled/zero-
  deadline process requests before spawning.
- Add actual Rust lifecycle/filesystem regressions and independent FFmpeg failure,
  network-canary, permission, long-GOP, surround and resource tests.
- Add a bounded developer qualification runner using the existing test suites,
  current release documents, runtime/notices guidance and verified ZIP policy.
- No new runtime dependency, required host method, project schema or installer.
- Compilation, real host lifecycle, editor imports, other platforms and human-
  recorded/perceptual qualification remain unverified; this is not production GA.

---

# Version 0.10.1 — Step 10 manual-test handoff

- Correct legacy FCP7 XML: audio `groupindex` no longer appears on video links.
- Bind each built export document to its exact destination; moving a relative-reference document requires an explicit rebuild.
- Add six Rust regression tests and two independently executable XML-reference checks.
- Correct the stale delivery-status page; preserve historical test reports as historical.
- Add a concrete build/readback/editor-import checklist and freshly recorded local checks.
- No new runtime dependencies, public host-method changes or `.amxv` schema change.
- Rust, the OTIO SDK and editor applications remain unexecuted in this environment.

---

# Version 0.10.0 — Step 10

- Add bounded editable OTIO JSON, legacy FCP7 XML and cuts-only CMX3600 exporters.
- Keep exact source/sequence clocks, explicit splits, linked mono/stereo and mapped markers.
- Require actual selected-frame CFR evidence for source-reference exports.
- Add complete compatibility reports, explicit PCM stems / ProRes bakes and protected publication.
- Reuse existing jobs, source identity, render/stem validation and output leases.
- Correct WAV verification routing, path escaping, linkage, media revalidation and source-bitdepth reporting.
- Keep `.amxv` schema 7 and existing required host/store signatures. No new runtime dependency.
- Source is not compiled here; no NLE application/version is declared qualified.

---

# 0.9.0 — Step 9 delivery rebuild

- Adds strict, frozen edit-preset configuration separate from per-variant encoding profiles.
- Adds explicit software H.264/HEVC/VP9/AV1/ProRes delivery profiles with codec-specific output checks.
- Adds sequential multi-target reports, JSON events and fingerprint-validated retry without rerendering completed targets.
- Preserves unvisited receipts and published-but-unverified outcomes across cancellation, fail-fast and observer failure.
- Adds the existing-host run workflow, with explicit saving and pending decisions returned for review.
- Known project schemas 1–6 migrate to schema 7 without enabling new analysis.
- Rust compilation and execution remain unverified. Current independent-media and archive evidence is in reports/step9.

# 0.8.0 — Step 8 rebuild

- Supplied SRT/WebVTT, cut-aware captions, explicit sidecars and original-source preservation.
- Variant-local graphics, supplied fonts, safe static rasterization, anchors, animation, volume and source-endpoint fades.
- Project schema 6, review/preview integration, Save As rebasing and protected asset publication.
- Optional Rust-native raster dependencies and native preparation; no new terminal framework.
- Rebuilt from verified 0.7.0; the earlier missing ZIP is not a source or evidence artifact.
- Rust compilation remains unverified. Clip-to-clip overlap transitions and playback-speed changes remain unsupported.

---

# 0.7.0 — Step 7 framing and output variants

- Add exact even output sizes, variant-local Fit/padding, explicit crop rectangles and source-time pan/zoom tracks; no new dependencies or host methods.
- Persist optional framing at each variant in schema 5; known schemas 1–4 migrate without adding new processing.
- Add review/approval/lock and hypothetical before/proposed framing previews, with sibling composition and shared cuts/audio unchanged.
- Normalize orthogonal rotation and non-square pixels, return inspectable geometry and editable versioned safe-zone guides. No face, group or speaker detection.
- Validate crop bounds, raster/upscale budgets, source-time precision, bounded shot/key counts, motion derivatives, and known shot resets.
- Fix animated zoom center drift by sampling a fixed raster; cache pose expressions per frame. Fit and constant zoom retain simpler filters.
- Supply 97 additional Rust tests (83 core/internal + 14 native), bringing the source inventory to 613 declarations. These have NOT executed because Rust tools are unavailable.
- Independently execute 42 new encoded-media checks and 166 retained checks. These do not execute the Rust adapter. See the current verification report for limitations.

# 0.6.0 — Step 6 scene and SDR color

- Add one full-frame-rate, display-oriented bounded visual stream and pure scene/histogram/luma/channel/neutral/activity analysis; retain exact source PTS and known cut boundaries.
- Add conservative per-shot exposure/gamma/contrast/saturation and user-confirmed neutral-patch balance. Explicit looks remain optional; non-identity proposals need review.
- Integrate schema-4 profiles, bypass, locks, exact source binding, review decisions and original/proposed proxies; audio-only operations ignore unrelated pending pixels.
- Compile reviewed source-time filters before cutting; use explicit Rec.709 linear-light exposure/balance and bounded encoded-tone correction. Reject unqualified HDR/10-bit/interlaced/unknown color paths.
- Add one optional default-denied frame-stream method and reuse the native runner; no new runtime dependencies or terminal framework.
- Supply 90 Rust tests (78 core + 12 native), not executed. Independently execute 32 new FFmpeg/pixel tests and repeat the 134 earlier media tests.
- Rust compiler/typechecker/Cargo/Clippy remain unavailable; no compiled release or native terminal qualification is claimed.

# 0.5.0 — Step 5 classical audio

- Add bounded per-channel preflight and explicit source-bound Auto/On/Off audio settings.
- Compile DC/rumble/hum, optional non-neural denoise, EQ/de-essing/compression, edited-signal measurement, constant gain and optional oversampled limiter.
- Compensate and flush FFmpeg 7.1 afftdn delay. Validate decoded peaks after lossy encoding with at most two bounded correction rerenders.
- Add optional typed MediaHost PCM/audio operations; keep required signatures and reuse the native runner.
- Integrate schema-3 settings, review invalidation, full-timeline gain for A/B preview, and explicit PCM24 WAV stem export.
- Supply 87 new Rust tests (68 core + 19 native); correct two malformed numeric literals in retained native review tests. Rust tools are unavailable, so these source tests have not executed.
- Execute 44 new independent FFmpeg audio checks plus 90 retained media checks. No human listening or installed-host qualification is claimed.

# 0.4.0 — Step 4

- Add per-channel streaming non-AI energy metrics, conservative interior-quiet proposals and exact source-time accounting.
- Reuse project operations, review, cancellation and the existing native runner. New proposals always need review.
- Snapshot pause settings in schema 2; migrate known schema 1 without adding behavior.
- Apply saved 0–10 ms audio fades only at pause-contributed gaps without altering the time map.
- Add 83 supplied Rust regressions and 30 independently executed FFmpeg media checks.
- Rust/Cargo unavailable: no Rust build or test success is claimed. No new runtime dependency or terminal framework.

# Changes

## 0.3.0 — Video roadmap Step 3

Added renderer-independent review of real project decisions, explicit approval/rejection/lock/range commands, paginated navigation, stable view bindings and latest-request preview tickets. Added selected-variant, bounded original/proposed proxy plans and MediaHost execution, full decode validation, source/proxy revalidation and a small approved-player adapter. Private Send output leases are retained for playback and dropped without publishing.

Range changes reset operation approval to NeedsReview. The project format remains schema 1, existing MediaHost/ProjectStore signatures remain, and no dependencies, scheduler, GUI/player or model runtime are added.

Added 73 core and 20 native-review Rust tests (supplied, not compiled/executed). The 23 independent real proxy recipes plus 37 retained media recipes pass. The new proxy rotation fixture was corrected to carry actual rotation metadata before its result is checked. See STEP-3-REVIEW.md for source-review corrections and verification limits.

## 0.2.0 — Video roadmap Step 2

Added editable `.amxv` schema 1, exact chronological keep/cut maps, reversible range edits, manual/lock/protection semantics, frozen variant settings, content relinking, host-owned project persistence, dry-run/no-render methods and saved-project rendering. Kept the existing no-edit pipeline and MediaHost signatures. Added `ProjectStore` and explicit filter/bitstream-filter capability sets.

Fixed the observed rational boundary / final reordered-frame losses in the independent cut recipe. Source review also tightened saved metadata fidelity, duplicate/future JSON handling, arithmetic checks, generator ownership, cancellation and safe publication.

Added 73 Rust core cases and 16 native-project cases (supplied, not executed here). All 18 new and 19 retained independent media-recipe tests pass. Rust compilation/typechecking and actual-host integration remain unverified because the authoring environment has no Rust/Cargo toolchain.

## 0.1.0 — retained foundation

The prior package supplied the Video entry/lifecycle, bounded probe parser, unedited H.264/AAC MP4 plan, output validation and optional native adapter. Its 60 core + 14 native tests were supplied but not run. Historical verification files remain clearly labelled.
