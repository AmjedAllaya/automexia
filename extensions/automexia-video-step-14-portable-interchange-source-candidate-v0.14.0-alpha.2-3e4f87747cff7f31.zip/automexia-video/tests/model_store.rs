//! Pure host-storage lifecycle tests; protobuf fixtures are deliberately not learned models.
use automexia_video::model_pack::*;
use automexia_video::model_store::*;
use automexia_video::{Cancellation, Error, Result};
use sha2::{Digest, Sha256};
use std::collections::BTreeMap;
use std::sync::{Arc, Mutex};
fn digest(bytes: &[u8]) -> String { format!("{:x}", Sha256::digest(bytes)) }
fn pack(revision: &str) -> VerifiedModelPack {
    let weights = vec![8, 8, 58, 0];
    let notices = b"test only, not a trained model";
    let manifest = ModelManifest { schema: 1, id: "speech-fixture".into(), revision: revision.into(), source_revision: "test-only".into(),
        contract: SILERO_CONTRACT.into(), preprocessing: SPEECH_PROCESSING.into(), weights_sha256: digest(&weights), weights_bytes: weights.len() as u64,
        runtime: ModelRuntime { adapter: "fake-only".into(), build_info_sha256: "a".repeat(64), artifact_sha256: "b".repeat(64) },
        code_license: "test fixture".into(), weights_license: "test fixture".into(), notices_sha256: digest(notices) };
    let bytes = serde_json::to_vec(&manifest).unwrap();
    VerifiedModelPack::verify(&bytes, weights, notices, &digest(&bytes), &Cancellation::new()).unwrap()
}
#[derive(Default)]
struct Memory { inventory: ModelInventory, packs: BTreeMap<String, VerifiedModelPack>, fail_commit: bool, fail_remove: bool, cancel_after_commit: bool }
#[derive(Clone, Default)]
struct Backend(Arc<Mutex<Memory>>);
impl ModelStorage for Backend {
    fn load_inventory(&self, cancel: &Cancellation) -> Result<ModelInventory> { cancel.check()?; Ok(self.0.lock().unwrap().inventory.clone()) }
    fn read_pack(&self, hash: &str, cancel: &Cancellation) -> Result<VerifiedModelPack> { cancel.check()?; self.0.lock().unwrap().packs.get(hash).cloned().ok_or(Error::InputChanged) }
    fn write_pack(&self, pack: &VerifiedModelPack, cancel: &Cancellation) -> Result<()> { cancel.check()?; self.0.lock().unwrap().packs.insert(pack.identity().manifest_sha256.clone(), pack.clone()); Ok(()) }
    fn commit_inventory(&self, expected: u64, next: &ModelInventory, cancel: &Cancellation) -> Result<()> {
        cancel.check()?; let mut state = self.0.lock().unwrap();
        if state.fail_commit { return Err(Error::Io("injected commit failure")); }
        if state.inventory.generation != expected { return Err(Error::InputChanged); }
        state.inventory = next.clone(); if state.cancel_after_commit { cancel.cancel(); } Ok(())
    }
    fn remove_pack(&self, hash: &str) -> bool { let mut state = self.0.lock().unwrap(); if state.fail_remove { return false; } state.packs.remove(hash).is_some() }
}
fn store() -> (ModelStore<Backend>, Backend) { let backend = Backend::default(); (ModelStore::open(backend.clone(), &Cancellation::new()).unwrap(), backend) }
fn install_select(store: &ModelStore<Backend>, p: &VerifiedModelPack) -> ModelSelection {
    let c = Cancellation::new(); let inventory = store.install(p, 0, &c).unwrap(); store.select(&p.identity().manifest_sha256, inventory.generation, &c).unwrap()
}
#[test] fn install_does_not_select_or_load_a_session() { let (s, _) = store(); let i = s.install(&pack("1"), 0, &Cancellation::new()).unwrap(); assert_eq!(i.generation, 1); assert!(i.selected.is_empty()); assert!(s.selected(SILERO_CONTRACT, &Cancellation::new()).unwrap().is_none()); }
#[test] fn exact_reinstall_is_idempotent() { let (s, _) = store(); let p = pack("1"); s.install(&p, 0, &Cancellation::new()).unwrap(); assert_eq!(s.install(&p, 1, &Cancellation::new()).unwrap().generation, 1); }
#[test] fn same_id_revision_with_different_identity_is_rejected() { let (s, b) = store(); let p = pack("1"); s.install(&p, 0, &Cancellation::new()).unwrap(); let mut value = serde_json::from_slice::<serde_json::Value>(p.manifest_bytes()).unwrap(); value["source_revision"] = "changed".into(); let bytes = serde_json::to_vec(&value).unwrap(); let changed = VerifiedModelPack::verify(&bytes, p.weights().to_vec(), p.notices(), &digest(&bytes), &Cancellation::new()).unwrap(); assert!(s.install(&changed, 1, &Cancellation::new()).is_err()); assert_eq!(b.0.lock().unwrap().packs.len(), 1); }
#[test] fn stale_install_does_not_write_pack() { let (s, b) = store(); assert!(matches!(s.install(&pack("1"), 7, &Cancellation::new()), Err(Error::InputChanged))); assert!(b.0.lock().unwrap().packs.is_empty()); }
#[test] fn uninstalled_pack_cannot_be_selected() { let (s, _) = store(); assert!(s.select(&"a".repeat(64), 0, &Cancellation::new()).is_err()); }
#[test] fn selected_bytes_are_loaded_immutably() { let (s, b) = store(); let p = pack("1"); let selected = install_select(&s, &p); b.0.lock().unwrap().packs.clear(); assert_eq!(selected.pack().weights(), p.weights()); assert!(selected.check().is_ok()); }
#[test] fn stale_selection_cannot_revoke_current() { let (s, _) = store(); let p = pack("1"); let selected = install_select(&s, &p); assert!(s.select(&p.identity().manifest_sha256, 1, &Cancellation::new()).is_err()); assert!(selected.check().is_ok()); }
#[test] fn update_atomically_replaces_selection_and_revokes_old_readers() { let (s, _) = store(); let p = pack("1"); let old = install_select(&s, &p); let old_clone = old.clone(); let new = s.update_selected(&p.identity().manifest_sha256, &pack("2"), 2, &Cancellation::new()).unwrap(); assert!(old.check().is_err()); assert!(old_clone.check().is_err()); assert!(new.check().is_ok()); assert_eq!(s.inventory(&Cancellation::new()).unwrap().installed.len(), 2); }
#[test] fn wrong_update_previous_hash_cannot_change_selection() { let (s, _) = store(); let old = install_select(&s, &pack("1")); assert!(matches!(s.update_selected(&"f".repeat(64), &pack("2"), 2, &Cancellation::new()), Err(Error::InputChanged))); assert!(old.check().is_ok()); }
#[test] fn failed_update_commit_preserves_selection_and_generation() { let (s, b) = store(); let p = pack("1"); let old = install_select(&s, &p); b.0.lock().unwrap().fail_commit = true; assert!(s.update_selected(&p.identity().manifest_sha256, &pack("2"), 2, &Cancellation::new()).is_err()); assert!(old.check().is_ok()); assert_eq!(s.inventory(&Cancellation::new()).unwrap().generation, 2); }
#[test] fn revoke_persists_deselection_and_invalidates_every_clone() { let (s, _) = store(); let old = install_select(&s, &pack("1")); let second = s.selected(SILERO_CONTRACT, &Cancellation::new()).unwrap().unwrap(); let i = s.revoke(SILERO_CONTRACT, 2, &Cancellation::new()).unwrap(); assert!(i.selected.is_empty()); assert_eq!(i.installed.len(), 1); assert!(old.check().is_err()); assert!(second.check().is_err()); }
#[test] fn failed_revoke_commit_keeps_valid_activation() { let (s, b) = store(); let old = install_select(&s, &pack("1")); b.0.lock().unwrap().fail_commit = true; assert!(s.revoke(SILERO_CONTRACT, 2, &Cancellation::new()).is_err()); assert!(old.check().is_ok()); }
#[test] fn removal_revokes_but_outstanding_reader_bytes_remain_safe() { let (s, _) = store(); let p = pack("1"); let old = install_select(&s, &p); let removed = s.remove(&p.identity().manifest_sha256, 2, &Cancellation::new()).unwrap(); assert!(removed.files_removed); assert!(removed.inventory.installed.is_empty()); assert!(old.check().is_err()); assert_eq!(old.pack().weights(), p.weights()); }
#[test] fn failed_file_cleanup_does_not_turn_committed_removal_into_error() { let (s, b) = store(); let p = pack("1"); let old = install_select(&s, &p); b.0.lock().unwrap().fail_remove = true; let outcome = s.remove(&p.identity().manifest_sha256, 2, &Cancellation::new()).unwrap(); assert!(!outcome.files_removed); assert!(old.check().is_err()); assert!(outcome.inventory.installed.is_empty()); b.0.lock().unwrap().fail_remove = false; assert!(s.purge_unreferenced(&p.identity().manifest_sha256, 3, &Cancellation::new()).unwrap()); }
#[test] fn cannot_purge_installed_pack() { let (s, _) = store(); let p = pack("1"); s.install(&p, 0, &Cancellation::new()).unwrap(); assert!(s.purge_unreferenced(&p.identity().manifest_sha256, 1, &Cancellation::new()).is_err()); }
#[test] fn manager_drop_revokes_reader_without_erasing_persistent_selection() { let (s, b) = store(); let selected = install_select(&s, &pack("1")); drop(s); assert!(selected.check().is_err()); assert!(!b.0.lock().unwrap().inventory.selected.is_empty()); }
#[test] fn reopening_reverifies_persisted_selection_before_activation() { let (s, b) = store(); install_select(&s, &pack("1")); drop(s); b.0.lock().unwrap().packs.clear(); let reopened = ModelStore::open(b, &Cancellation::new()).unwrap(); assert!(reopened.selected(SILERO_CONTRACT, &Cancellation::new()).is_err()); }
#[test] fn reopen_recovers_persisted_selection_explicitly() { let (s, b) = store(); let previous = install_select(&s, &pack("1")); drop(s); let s = ModelStore::open(b, &Cancellation::new()).unwrap(); let current = s.selected(SILERO_CONTRACT, &Cancellation::new()).unwrap().unwrap(); assert!(previous.check().is_err()); assert!(current.check().is_ok()); }
#[test] fn cancellation_before_mutation_changes_nothing() { let (s, _) = store(); let c = Cancellation::new(); c.cancel(); assert!(matches!(s.install(&pack("1"), 0, &c), Err(Error::Cancelled))); assert_eq!(s.inventory(&Cancellation::new()).unwrap().generation, 0); }
#[test] fn cancellation_after_commit_reports_success_and_matches_disk() { let (s, b) = store(); b.0.lock().unwrap().cancel_after_commit = true; let c = Cancellation::new(); let i = s.install(&pack("1"), 0, &c).unwrap(); assert_eq!(i.generation, 1); assert!(c.is_cancelled()); assert_eq!(s.inventory(&Cancellation::new()).unwrap(), b.0.lock().unwrap().inventory); }
#[test] fn duplicate_or_unknown_inventory_json_rejected() { for bytes in [br#"{"schema":1,"schema":1,"generation":0,"installed":[],"selected":{}}"#.as_slice(), br#"{"schema":1,"generation":0,"installed":[],"selected":{},"url":"x"}"#.as_slice()] { assert!(ModelInventory::from_json(bytes).is_err()); } }
#[test] fn inventory_selection_must_match_an_installed_contract() { let mut i = ModelInventory::default(); i.installed.push(pack("1").identity().clone()); i.selected.insert(ULTRAFACE_CONTRACT.into(), i.installed[0].manifest_sha256.clone()); assert!(i.validate().is_err()); }
#[test] fn inventory_duplicate_identity_rejected() { let p = pack("1"); let mut i = ModelInventory::default(); i.installed = vec![p.identity().clone(), p.identity().clone()]; assert!(i.validate().is_err()); }
#[test] fn inventory_generation_overflow_is_rejected_before_pack_write() { let b = Backend::default(); b.0.lock().unwrap().inventory.generation = u64::MAX; let s = ModelStore::open(b.clone(), &Cancellation::new()).unwrap(); assert!(s.install(&pack("1"), u64::MAX, &Cancellation::new()).is_err()); assert!(b.0.lock().unwrap().packs.is_empty()); }
#[test] fn invalid_inventory_cannot_open_manager() { let b = Backend::default(); b.0.lock().unwrap().inventory.schema = 2; assert!(ModelStore::open(b, &Cancellation::new()).is_err()); }
#[test] fn backend_cas_conflict_is_visible_without_mutating_cached_state() { let (s, b) = store(); b.0.lock().unwrap().inventory.generation = 1; assert!(matches!(s.install(&pack("1"), 0, &Cancellation::new()), Err(Error::InputChanged))); assert_eq!(s.inventory(&Cancellation::new()).unwrap().generation, 0); }
#[test] fn exact_verified_manifest_and_notices_survive_cloning() { let p = pack("1"); let cloned = p.clone(); assert_eq!(digest(cloned.manifest_bytes()), p.identity().manifest_sha256); assert_eq!(digest(cloned.notices()), p.identity().notices_sha256); }
#[test] fn competing_mutations_from_same_review_generation_have_one_winner() {
    let (store, _) = store(); let store = Arc::new(store);
    let results = std::thread::scope(|scope| {
        let first = scope.spawn(|| store.install(&pack("1"), 0, &Cancellation::new()));
        let second = scope.spawn(|| store.install(&pack("2"), 0, &Cancellation::new()));
        [first.join().unwrap(), second.join().unwrap()]
    });
    assert_eq!(results.iter().filter(|r| r.is_ok()).count(), 1);
    assert_eq!(results.iter().filter(|r| matches!(r, Err(Error::InputChanged))).count(), 1);
    assert_eq!(store.inventory(&Cancellation::new()).unwrap().installed.len(), 1);
}
#[test] fn replacing_selection_does_not_revoke_unrelated_manual_activation() {
    let (store, _) = store(); let first = pack("1");
    let selected = install_select(&store, &first);
    let independent = ModelActivation::selected(first.identity().clone()).unwrap();
    store.update_selected(&first.identity().manifest_sha256, &pack("2"), 2, &Cancellation::new()).unwrap();
    assert!(selected.check().is_err()); assert!(independent.check().is_ok());
}
#[test] fn failed_removal_commit_preserves_files_and_readers() {
    let (store, backend) = store(); let pack = pack("1"); let selected = install_select(&store, &pack);
    backend.0.lock().unwrap().fail_commit = true;
    assert!(store.remove(&pack.identity().manifest_sha256, 2, &Cancellation::new()).is_err());
    assert!(selected.check().is_ok()); assert_eq!(backend.0.lock().unwrap().packs.len(), 1);
}
