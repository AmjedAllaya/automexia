//! Assembly planner regressions. These execute Rust when run through Cargo;
//! independent FFmpeg recipes are reported separately as reference evidence.
use automexia_video::*;
use automexia_video::assembly::{AssemblyClip,AssemblySettings};
use automexia_video::edit_render::EditRender;
use automexia_video::host::{FileStamp,InputFile};
use automexia_video::project::*;
use automexia_video::timing::{PlaybackSpeed,TimingSettings};

fn r(n:i64,d:i64)->Rational{Rational::new(n,d).unwrap()}
fn frame(n:i64)->Rational{r(1001,30000).ticks(n).unwrap()}
fn project()->Project{
    let location=std::env::temp_dir().join("amx-assembly-render/project.amxv");
    let media=automexia_video::media::parse_probe(include_bytes!("fixtures/probe-base.json")).unwrap();
    let input=InputFile{canonical_path:location.with_file_name("input.mp4"),stamp:FileStamp{size:100,modified_ns:None,sha256:"a".repeat(64),file_id:None}};
    let source=ProjectSource::from_probe("source-1",&input,&media,media.select(StreamSelection::default()).unwrap(),&location).unwrap();
    Project::new("assembly-render",source,ResolvedSettings{workflow:None,preset_name:None,preset_revision:None,pause_cleanup:None,voice_cleanup:None,voice_enhancement:None,color_correction:None,render:FrozenRenderSettings::from_options(&RenderOptions::default()).unwrap()}).unwrap()
}
fn assembly(p:&mut Project,entries:&[(i64,i64,PlaybackSpeed)]){
    let clips=entries.iter().enumerate().map(|(i,(start,end,speed))|AssemblyClip{id:format!("entry-{i}"),range:TimeRange::new(frame(*start),frame(*end)).unwrap(),speed:*speed}).collect();
    p.set_assembly("main",Some(AssemblySettings{clips,..Default::default()})).unwrap();
    p.review_assembly("main",Disposition::AutoApply,true).unwrap();
}
fn timing(p:&mut Project,speed:PlaybackSpeed,dissolve:Rational){
    p.set_timing("main",Some(TimingSettings{speed,dissolve,..Default::default()})).unwrap();
    p.review_timing("main",Disposition::AutoApply,true).unwrap();
}
#[test]
fn reordered_unit_speed_entries_require_verified_branch_rendering(){
    let mut p=project();assembly(&mut p,&[(30,60,PlaybackSpeed::Normal),(0,30,PlaybackSpeed::Normal)]);
    let edit=EditRender::from_project(&p).unwrap();
    assert!(edit.requires_branching()&&edit.changes_timing());
    let graph=edit.filter_graph(0,Some(1),false).unwrap();
    assert!(graph.starts_with("[0:0]split=2"));assert!(!graph.contains("select="));
    assert!(graph.contains("[vt0][vt1]concat=n=2:v=1:a=0"));assert!(!graph.contains("atempo="));
    assert!(graph.find("trim=start_pts=30030").unwrap()<graph.find("trim=start_pts=0").unwrap());
    assert_eq!(edit.duration,frame(60));
}
#[test]
fn repeated_entry_has_separate_video_and_audio_occurrences(){
    let mut p=project();assembly(&mut p,&[(0,20,PlaybackSpeed::Normal),(0,20,PlaybackSpeed::Normal),(0,20,PlaybackSpeed::Normal)]);
    let edit=EditRender::from_project(&p).unwrap();let graph=edit.filter_graph(0,Some(1),false).unwrap();
    assert_eq!(graph.matches("trim=start_pts=0:end_pts=20020").count(),3);
    assert_eq!(graph.matches("atrim=start_sample=0:end_sample=32032").count(),3);
    assert_eq!(edit.duration,frame(60));assert_eq!(edit.segments.len(),3);
}
#[test]
fn chronological_unit_speed_assembly_preserves_select_path(){
    let mut p=project();assembly(&mut p,&[(0,20,PlaybackSpeed::Normal),(30,60,PlaybackSpeed::Normal)]);
    let edit=EditRender::from_project(&p).unwrap();assert!(!edit.requires_branching());
    assert!(edit.filter_graph(0,Some(1),false).unwrap().starts_with("[0:0]select="));
}
#[test]
fn entry_and_global_half_speeds_multiply_to_quarter(){
    let mut p=project();assembly(&mut p,&[(0,12,PlaybackSpeed::Half)]);timing(&mut p,PlaybackSpeed::Half,r(0,1));
    let edit=EditRender::from_project(&p).unwrap();assert_eq!(edit.speed,r(1,2));assert_eq!(edit.segments[0].speed,r(1,4));
    assert_eq!(edit.duration,frame(48));let graph=edit.filter_graph(0,Some(1),false).unwrap();
    assert!(graph.contains("setpts='(PTS-0)*4/1'"));assert!(graph.contains(",atempo=0.5,atempo=0.5,"));
    assert!(!graph.contains("atempo=0.2"));assert!(graph.contains("trim=end_frame=48"));
}
#[test]
fn entry_and_global_double_speeds_use_two_supported_tempo_stages(){
    let mut p=project();assembly(&mut p,&[(0,60,PlaybackSpeed::Double)]);timing(&mut p,PlaybackSpeed::Double,r(0,1));
    let edit=EditRender::from_project(&p).unwrap();assert_eq!(edit.segments[0].speed,r(4,1));assert_eq!(edit.duration,frame(15));
    let graph=edit.filter_graph(0,Some(1),false).unwrap();assert!(graph.contains(",atempo=2.0,atempo=2.0,"));
    assert!(!graph.contains("atempo=4"));assert!(graph.contains("trim=end_frame=15"));
}
#[test]
fn opposing_entry_and_global_speeds_preserve_identity_graph(){
    let mut p=project();assembly(&mut p,&[(0,60,PlaybackSpeed::Half)]);timing(&mut p,PlaybackSpeed::Double,r(0,1));
    let edit=EditRender::from_project(&p).unwrap();assert_eq!(edit.segments[0].speed,r(1,1));assert!(!edit.requires_branching());
    let graph=edit.filter_graph(0,Some(1),false).unwrap();assert!(graph.starts_with("[0:0]select="));assert!(!graph.contains("atempo="));
}
#[test]
fn mixed_speeds_keep_exact_ntsc_sample_partition(){
    let mut p=project();assembly(&mut p,&[(30,38,PlaybackSpeed::Double),(0,4,PlaybackSpeed::Half),(30,38,PlaybackSpeed::Normal)]);
    let edit=EditRender::from_project(&p).unwrap();assert_eq!(edit.duration,frame(20));
    assert_eq!(edit.segments.iter().map(|s|s.output_samples.unwrap()).sum::<i64>(),frame(20).ceil_units(48000).unwrap());
    assert_eq!(edit.segments.iter().map(|s|s.speed).collect::<Vec<_>>(),vec![r(2,1),r(1,2),r(1,1)]);
}
#[test]
fn global_dissolve_uses_already_scaled_entry_lengths(){
    let mut p=project();assembly(&mut p,&[(30,50,PlaybackSpeed::Half),(0,20,PlaybackSpeed::Normal)]);timing(&mut p,PlaybackSpeed::Double,frame(2));
    let edit=EditRender::from_project(&p).unwrap();assert_eq!(edit.duration,frame(28));
    assert_eq!(edit.requested.segments[1].output_range.start,frame(18));
    let graph=edit.filter_graph(0,Some(1),false).unwrap();assert!(graph.contains("xfade=transition=fade"));
    assert!(graph.contains("acrossfade=ns=3203"));
}
#[test]
fn repeated_ntsc_dissolve_sample_overlaps_equal_exact_terminal_clock(){
    let mut p=project();assembly(&mut p,&[(0,12,PlaybackSpeed::Normal),(0,12,PlaybackSpeed::Normal),(0,12,PlaybackSpeed::Normal)]);timing(&mut p,PlaybackSpeed::Normal,frame(2));
    let edit=EditRender::from_project(&p).unwrap();let samples=edit.segments.iter().map(|s|s.output_samples.unwrap()).sum::<i64>();
    let overlaps=edit.requested.segments.windows(2).map(|s|s[0].output_range.end.ceil_units(48000).unwrap()-s[1].output_range.start.ceil_units(48000).unwrap()).sum::<i64>();
    assert_eq!(samples-overlaps,edit.duration.ceil_units(48000).unwrap());
}
#[test]
fn off_grid_effective_speed_fails_before_filter_publication(){
    let mut p=project();assembly(&mut p,&[(0,30,PlaybackSpeed::Double)]);timing(&mut p,PlaybackSpeed::Double,r(0,1));
    assert!(matches!(EditRender::from_project(&p),Err(Error::Unsupported(_))));
}
#[test]
fn off_grid_reorder_is_not_silently_rounded(){
    let mut p=project();let clips=vec![AssemblyClip{id:"late".into(),range:TimeRange::new(r(1,1),r(2,1)).unwrap(),speed:PlaybackSpeed::Normal},AssemblyClip{id:"early".into(),range:TimeRange::new(r(0,1),r(1,1)).unwrap(),speed:PlaybackSpeed::Normal}];
    p.set_assembly("main",Some(AssemblySettings{clips,..Default::default()})).unwrap();p.review_assembly("main",Disposition::AutoApply,true).unwrap();
    assert!(EditRender::from_project(&p).is_err());
}
#[test]
fn edited_segment_rate_cannot_diverge_from_authoritative_timeline(){
    let mut edit=EditRender::from_project(&project()).unwrap();edit.segments[0].speed=r(2,1);
    assert_eq!(edit.validate().unwrap_err(),Error::InvalidProject("render segment speed provenance"));
}
#[test]
fn edited_sample_count_cannot_diverge_from_authoritative_timeline(){
    let mut edit=EditRender::from_project(&project()).unwrap();edit.segments[0].output_samples=Some(1);
    assert_eq!(edit.validate().unwrap_err(),Error::InvalidProject("render sample clock provenance"));
}
#[test]
fn reorder_budget_blocks_unbounded_decoded_frame_retention(){
    let mut p=project();p.sources[0].media.video.width=Some(7680);p.sources[0].media.video.height=Some(4320);
    assembly(&mut p,&[(30,60,PlaybackSpeed::Normal),(0,30,PlaybackSpeed::Normal)]);
    assert!(matches!(EditRender::from_project(&p),Err(Error::LimitExceeded(_))));
}
#[test]
fn video_only_assembly_has_no_accidental_audio_graph(){
    let mut p=project();p.sources[0].media.audio=None;assembly(&mut p,&[(30,60,PlaybackSpeed::Normal),(0,30,PlaybackSpeed::Normal)]);
    let edit=EditRender::from_project(&p).unwrap();let graph=edit.filter_graph(0,None,false).unwrap();
    assert!(!graph.contains("[aout]"));assert!(!graph.contains("atempo"));assert!(edit.requires_branching());
}
#[test]
fn short_ntsc_branches_reanchor_on_one_exact_cfr_grid(){
    let mut p=project();assembly(&mut p,&[(6,7,PlaybackSpeed::Normal),(4,5,PlaybackSpeed::Normal),(2,3,PlaybackSpeed::Normal),(0,1,PlaybackSpeed::Normal)]);
    let graph=EditRender::from_project(&p).unwrap().filter_graph(0,Some(1),false).unwrap();
    assert!(graph.contains("[vassembled]trim=end_frame=4,settb=expr=1001/30000,setpts=N,settb=expr=1/1000000[vout]"));
}
#[test]
fn ordinary_cuts_keep_preexisting_non_interchange_frame_rate_support(){
    let mut p=project();p.sources[0].media.video.nominal_frame_rate=Some(r(12,1));p.sources[0].media.video.average_frame_rate=Some(r(12,1));
    let edit=EditRender::from_project(&p).unwrap();assert!(!edit.requires_branching());assert!(edit.filter_graph(0,Some(1),false).is_ok());
}
#[test]
fn assembly_omissions_do_not_inherit_unrelated_pause_join_fades(){
    let mut p=project();p.settings.pause_cleanup=Some(automexia_video::pause::PauseSettings::clean());
    assembly(&mut p,&[(0,20,PlaybackSpeed::Normal),(30,60,PlaybackSpeed::Normal)]);
    let edit=EditRender::from_project(&p).unwrap();assert!(edit.join_fades_samples.iter().all(|f|*f==(0,0)));
    assert!(!edit.filter_graph(0,Some(1),false).unwrap().contains("afade="));
}
#[test]
fn audio_only_assembly_does_not_inherit_video_buffer_restrictions(){
    let mut p=project();p.sources[0].media.video.width=Some(7680);p.sources[0].media.video.height=Some(4320);
    assembly(&mut p,&[(30,60,PlaybackSpeed::Normal),(0,30,PlaybackSpeed::Normal)]);
    let runtime=automexia_video::host::RuntimeCapabilities{filters:["asetpts","aresample","apad","atrim","anull","asplit","concat"].map(str::to_owned).into_iter().collect(),..Default::default()};
    let plan=automexia_video::plan::build_audio_plan(&p,"main",&p.sources[0].media.as_media_info(),&runtime).unwrap();
    assert_eq!(plan.edited_timeline().unwrap().duration,frame(60));
    assert!(EditRender::from_project(&p).is_err());
}
#[test]
fn tempo_uses_bounded_input_guard_without_masking_a_short_output(){
    let mut p=project();assembly(&mut p,&[(0,12,PlaybackSpeed::Double)]);
    let graph=EditRender::from_project(&p).unwrap().filter_graph(0,Some(1),false).unwrap();
    assert!(graph.contains(",apad=pad_len=12000,atempo=2.0,atrim=end_sample="));
    // Source absence may still be padded in AUDIO_BASE. Changed segments and
    // their final combined output must never gain a post-transform silence pad.
    assert_eq!(graph.matches("apad=whole_len=").count(),1);
}
#[test]
fn too_short_speed_changed_audio_is_rejected_instead_of_becoming_silent(){
    for (end,speed) in [(2,PlaybackSpeed::Half),(4,PlaybackSpeed::Double)] {
        let mut p=project();assembly(&mut p,&[(0,end,speed)]);
        assert!(matches!(EditRender::from_project(&p),Err(Error::Unsupported(message)) if message.contains("at least 100 ms")));
    }
}
#[test]
fn tiny_video_only_speed_entries_do_not_inherit_audio_window_limits(){
    let mut p=project();p.sources[0].media.audio=None;assembly(&mut p,&[(0,1,PlaybackSpeed::Half)]);
    let edit=EditRender::from_project(&p).unwrap();assert_eq!(edit.duration,frame(2));assert!(edit.filter_graph(0,None,false).is_ok());
}
#[test]
fn dissolved_audio_normalizes_packets_without_padding_samples(){
    let mut p=project();assembly(&mut p,&[(0,20,PlaybackSpeed::Half),(30,50,PlaybackSpeed::Double),(0,20,PlaybackSpeed::Normal)]);timing(&mut p,PlaybackSpeed::Normal,frame(2));
    let edit=EditRender::from_project(&p).unwrap();let graph=edit.filter_graph(0,Some(1),false).unwrap();
    assert_eq!(graph.matches(",asetnsamples=n=1024:p=0[t").count(),3);
    assert!(edit.required_filters().contains(&"asetnsamples"));
    let mut runtime=automexia_video::host::RuntimeCapabilities{filters:["asetpts","aresample","apad","atrim","anull","asplit","concat","atempo","acrossfade"].map(str::to_owned).into_iter().collect(),..Default::default()};
    let media=p.sources[0].media.as_media_info();
    assert!(matches!(automexia_video::plan::build_audio_plan(&p,"main",&media,&runtime),Err(Error::MissingCapability(_))));
    runtime.filters.insert("asetnsamples".into());assert!(automexia_video::plan::build_audio_plan(&p,"main",&media,&runtime).is_ok());
}
