//! These tests execute the Rust subtitle implementation under Cargo.
use automexia_video::{Rational,TimeRange};
use automexia_video::subtitles::*;
use automexia_video::project::{Timeline,TimelineSegment};
fn r(s:&str)->Rational{s.parse().unwrap()}
fn span(a:&str,b:&str)->TimeRange{TimeRange::new(r(a),r(b)).unwrap()}
fn sample()->SubtitleDocument{SubtitleDocument::parse(b"1\n00:00:00,500 --> 00:00:02,500\nHello\n",SubtitleFormat::Srt).unwrap()}
fn cut()->Timeline{Timeline{duration:r("2"),segments:vec![TimelineSegment{source_id:"s".into(),source_range:span("0","1"),output_range:span("0","1")},TimelineSegment{source_id:"s".into(),source_range:span("2","3"),output_range:span("1","2")}]}}
#[test]fn original_bytes_survive_bom_and_crlf(){let bytes="\u{feff}1\r\n00:00:00,000 --> 00:00:01,000\r\nCafé\r\n".as_bytes();let d=SubtitleDocument::parse(bytes,SubtitleFormat::Srt).unwrap();assert_eq!(d.original.as_bytes(),bytes);assert_eq!(d.cues[0].text,"Café");d.validate().unwrap();}
#[test]fn basic_webvtt_notes_are_not_captions(){let d=SubtitleDocument::parse(b"WEBVTT\n\nNOTE commentary\nnot a cue\n\nlabel\n00:00.500 --> 00:01.500\nHello\n",SubtitleFormat::WebVtt).unwrap();assert_eq!(d.cues.len(),1);assert_eq!(d.cues[0].range,span("1/2","3/2"));}
#[test]fn supplied_unicode_is_preserved(){let text="1\n00:00:00,000 --> 00:00:01,000\n日本語 العربية café\n";assert_eq!(SubtitleDocument::parse(text.as_bytes(),SubtitleFormat::Srt).unwrap().cues[0].text,"日本語 العربية café");}
#[test]fn character_references_become_plain_text(){let d=SubtitleDocument::parse(b"1\n00:00:00,000 --> 00:00:01,000\nA &amp; B &lt; C &gt; D &#233;\n",SubtitleFormat::Srt).unwrap();assert_eq!(d.cues[0].text,"A & B < C > D é");}
#[test]fn ordinary_ampersand_is_not_rejected(){let d=SubtitleDocument::parse(b"1\n00:00:00,000 --> 00:00:01,000\nR&D\n",SubtitleFormat::Srt).unwrap();assert_eq!(d.cues[0].text,"R&D");}
#[test]fn unsupported_formatting_is_not_silently_removed(){assert!(SubtitleDocument::parse(b"1\n00:00:00,000 --> 00:00:01,000\n<b>bold</b>\n",SubtitleFormat::Srt).is_err());}
#[test]fn vtt_position_settings_are_explicitly_unsupported(){assert!(SubtitleDocument::parse(b"WEBVTT\n\n00:00.000 --> 00:01.000 line:80%\nHi\n",SubtitleFormat::WebVtt).is_err());}
#[test]fn vtt_styles_and_regions_are_not_ignored(){for text in ["WEBVTT\n\nSTYLE\n::cue{color:red}\n","WEBVTT\n\nREGION\nid:one\n"]{assert!(SubtitleDocument::parse(text.as_bytes(),SubtitleFormat::WebVtt).is_err());}}
#[test]fn cue_spanning_cut_is_split_and_remapped(){let cues=sample().remap(&cut(),"s").unwrap();assert_eq!(cues.len(),2);assert_eq!(cues[0].range,span("1/2","1"));assert_eq!(cues[1].range,span("1","3/2"));}
#[test]fn completely_removed_cue_is_absent(){let mut d=sample();d.replace_cue("cue-1",span("1","2"),"gone".into()).unwrap();assert!(d.remap(&cut(),"s").unwrap().is_empty());}
#[test]fn half_open_cue_does_not_bleed_into_deleted_range(){let mut d=sample();d.replace_cue("cue-1",span("0","1"),"one".into()).unwrap();let c=d.remap(&cut(),"s").unwrap();assert_eq!(c.len(),1);assert_eq!(c[0].range,span("0","1"));}
#[test]fn unrelated_source_does_not_inherit_captions(){assert!(sample().remap(&cut(),"other").unwrap().is_empty());}
#[test]fn overlaps_are_preserved_for_explicit_layout_policy(){let d=SubtitleDocument::parse(b"1\n00:00:00,000 --> 00:00:02,000\nOne\n\n2\n00:00:01,000 --> 00:00:02,000\nTwo\n",SubtitleFormat::Srt).unwrap();assert_eq!(d.cues.len(),2);}
#[test]fn duplicate_ids_are_rejected(){assert!(SubtitleDocument::parse(b"1\n00:00:00,000 --> 00:00:01,000\nA\n\n1\n00:00:01,000 --> 00:00:02,000\nB\n",SubtitleFormat::Srt).is_err());}
#[test]fn invalid_time_cases_are_rejected(){for t in ["-00:00:01,000","00:60:00,000","00:00:60,000","00:00:00,12","nan","00:00:00.500"]{let s=format!("1\n{t} --> 00:00:02,000\nA\n");assert!(SubtitleDocument::parse(s.as_bytes(),SubtitleFormat::Srt).is_err(),"{t}");}}
#[test]fn reversed_or_empty_range_is_rejected(){for t in ["00:00:00,000","00:00:00,500"]{let s=format!("1\n00:00:00,500 --> {t}\nA\n");assert!(SubtitleDocument::parse(s.as_bytes(),SubtitleFormat::Srt).is_err());}}
#[test]fn invalid_utf8_control_and_bare_cr_are_rejected(){for b in [vec![0xff],b"1\r00:00:00,000 --> 00:00:01,000\rA".to_vec(),b"1\n00:00:00,000 --> 00:00:01,000\nA\0".to_vec()]{assert!(SubtitleDocument::parse(&b,SubtitleFormat::Srt).is_err());}}
#[test]fn oversized_source_and_cue_are_rejected(){assert!(SubtitleDocument::parse(&vec![b' ';MAX_SUBTITLE_BYTES+1],SubtitleFormat::Srt).is_err());let s=format!("1\n00:00:00,000 --> 00:00:01,000\n{}\n","a".repeat(MAX_CUE_BYTES+1));assert!(SubtitleDocument::parse(s.as_bytes(),SubtitleFormat::Srt).is_err());}
#[test]fn editing_is_transactional_and_preserves_original(){let mut d=sample();let old=d.original.clone();let cue=d.cues[0].clone();assert!(d.replace_cue("cue-1",span("0","1"),"\u{202e}".into()).is_err());assert_eq!(d.cues[0],cue);d.replace_cue("cue-1",span("0","1"),"A < B & C".into()).unwrap();assert_eq!(d.original,old);}
#[test]fn digest_tampering_is_rejected(){let mut d=sample();d.original.push('x');assert!(d.validate().is_err());}
#[test]fn sidecars_quantize_outward_and_escape_plain_text(){let cue=MappedCue{source_id:"c".into(),part:1,range:span("1/30000","1001/30000"),text:"A & B < C".into()};let s=String::from_utf8(sidecar(&[cue],SubtitleFormat::Srt).unwrap()).unwrap();assert!(s.contains("00:00:00,000 --> 00:00:00,034"));assert!(s.contains("A &amp; B &lt; C"));let d=SubtitleDocument::parse(s.as_bytes(),SubtitleFormat::Srt).unwrap();assert_eq!(d.cues[0].text,"A & B < C");}
#[test]fn empty_vtt_roundtrips(){let d=SubtitleDocument::parse(b"WEBVTT\n\n",SubtitleFormat::WebVtt).unwrap();assert!(d.cues.is_empty());assert_eq!(sidecar(&[],SubtitleFormat::WebVtt).unwrap(),b"WEBVTT\n\n");}
#[test]fn unsorted_cues_are_not_reordered_silently(){assert!(SubtitleDocument::parse(b"1\n00:00:01,000 --> 00:00:02,000\nA\n\n2\n00:00:00,000 --> 00:00:01,000\nB\n",SubtitleFormat::Srt).is_err());}
#[test]fn deleted_intervals_do_not_mutate_original_cues(){let d=sample();let before=serde_json::to_vec(&d).unwrap();let _=d.remap(&cut(),"s").unwrap();assert_eq!(serde_json::to_vec(&d).unwrap(),before);}
