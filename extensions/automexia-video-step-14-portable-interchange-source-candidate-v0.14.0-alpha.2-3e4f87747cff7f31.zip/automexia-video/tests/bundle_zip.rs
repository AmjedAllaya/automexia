//! Pure ZIP writer tests; no native feature, filesystem, FFmpeg or editor.
use automexia_video::{bundle_zip::*, Cancellation, Error};
use std::io::{self, Cursor, Read, Write};
use sha2::{Digest, Sha256};

fn archive(entries: &[(&str, &[u8])]) -> Vec<u8> {
    let cancel = Cancellation::new();
    let mut writer = StoredZip64::new(Vec::new(), 1_000_000).unwrap();
    for (name, bytes) in entries { writer.add_entry(name, &mut Cursor::new(*bytes), bytes.len() as u64, &cancel).unwrap(); }
    writer.finish(&cancel).unwrap()
}
fn n16(b: &[u8], n: usize) -> u16 { u16::from_le_bytes(b[n..n+2].try_into().unwrap()) }
fn n32(b: &[u8], n: usize) -> u32 { u32::from_le_bytes(b[n..n+4].try_into().unwrap()) }
fn n64(b: &[u8], n: usize) -> u64 { u64::from_le_bytes(b[n..n+8].try_into().unwrap()) }

#[test] fn zip_crc_and_sha_are_for_the_copied_bytes() {
    let mut writer = StoredZip64::new(Vec::new(), 4096).unwrap();
    let digest = writer.add_entry("README.txt", &mut Cursor::new(b"123456789"), 9, &Cancellation::new()).unwrap();
    assert_eq!(digest.crc32, 0xcbf43926);
    assert_eq!(digest.sha256, format!("{:x}", Sha256::digest(b"123456789")));
    assert_eq!(digest.size, 9);
}
#[test] fn zip64_records_sizes_offsets_and_descriptor_are_exact() {
    let bytes = archive(&[("a.txt", b"123456789")]);
    // Independent Python struct/zlib reference, consumed by Python zipfile.
    assert_eq!(format!("{:x}", Sha256::digest(&bytes)), "ce53686d787210da08f686566a56495b0cb9cd5d4590374e1f6469e399323dff");
    assert_eq!(bytes.len() as u64, archive_size(&[("a.txt", 9)]).unwrap());
    assert_eq!(n32(&bytes, 0), 0x04034b50); assert_eq!(n16(&bytes, 4), 45);
    assert_eq!(n16(&bytes, 6), 0x0808); assert_eq!(n16(&bytes, 8), 0);
    assert_eq!(n32(&bytes, 18), u32::MAX); assert_eq!(n32(&bytes, 22), u32::MAX);
    assert_eq!(n16(&bytes, 28), 20); assert_eq!(n16(&bytes, 35), 1);
    assert_eq!(n64(&bytes, 39), 0); assert_eq!(&bytes[55..64], b"123456789");
    assert_eq!(n32(&bytes, 64), 0x08074b50); assert_eq!(n32(&bytes, 68), 0xcbf43926);
    assert_eq!(n64(&bytes, 72), 9); assert_eq!(n64(&bytes, 80), 9);
    assert_eq!(n32(&bytes, 88), 0x02014b50); assert_eq!(n16(&bytes, 118), 28);
    let zip64 = bytes.len() - 98;
    assert_eq!(n32(&bytes, zip64), 0x06064b50); assert_eq!(n64(&bytes, zip64+4), 44);
    assert_eq!(n64(&bytes, zip64+24), 1); assert_eq!(n64(&bytes, zip64+40), 79);
    assert_eq!(n64(&bytes, zip64+48), 88); assert_eq!(n32(&bytes, zip64+56), 0x07064b50);
    assert_eq!(n64(&bytes, zip64+64), zip64 as u64); assert_eq!(n32(&bytes, bytes.len()-22), 0x06054b50);
}
#[test] fn zip_output_is_deterministic_and_keeps_binary_members() {
    let bytes: Vec<u8> = (0..=255).collect();
    let entries = [("manifest.json", b"{}\n".as_slice()), ("Media/source.bin", bytes.as_slice())];
    assert_eq!(archive(&entries), archive(&entries));
    let expected = archive_size(&[("manifest.json", 3), ("Media/source.bin", 256)]).unwrap();
    assert_eq!(archive(&entries).len() as u64, expected);
}
#[test] fn zip_empty_regular_file_is_legal() {
    let bytes = archive(&[("empty.txt", b"")]);
    assert_eq!(bytes.len() as u64, archive_size(&[("empty.txt", 0)]).unwrap());
}
#[test] fn zip_path_traversal_and_nonportable_names_are_rejected() {
    for name in ["", "../x", "a/../x", "/x", "a//b", "a/", "./x", "a\\x", "C:x", "a b", "x%20y", "x\0y", "é", "con", "AUX.txt", "x/COM1.mov", "lpt9", "name."] {
        assert!(validate_name(name).is_err(), "{name:?}");
    }
    assert!(validate_name(&"x".repeat(MAX_ZIP_NAME_BYTES+1)).is_err());
    assert!(validate_name("Media/source-0123.mp4").is_ok());
}
#[test] fn zip_duplicate_case_and_file_directory_conflicts_are_rejected() {
    for names in [[("x", 0), ("x", 0)], [("Media/X", 0), ("media/x", 0)], [("Media", 0), ("Media/x", 0)], [("Media/x", 0), ("Media", 0)]] {
        assert!(archive_size(&names).is_err());
    }
}
#[test] fn zip_exact_full_archive_limit_is_enforced_before_any_read() {
    struct NeverRead;
    impl Read for NeverRead { fn read(&mut self, _: &mut [u8]) -> io::Result<usize> { panic!("limit check must precede reading") } }
    let needed = archive_size(&[("a", 2)]).unwrap();
    let mut writer = StoredZip64::new(Vec::new(), needed-1).unwrap();
    assert!(matches!(writer.add_entry("a", &mut NeverRead, 2, &Cancellation::new()), Err(Error::LimitExceeded(_))));
    assert_eq!(writer.bytes_written(), 0);
    let mut exact = StoredZip64::new(Vec::new(), needed).unwrap();
    exact.add_entry("a", &mut Cursor::new(b"ok"), 2, &Cancellation::new()).unwrap();
    assert_eq!(exact.finish(&Cancellation::new()).unwrap().len() as u64, needed);
}
#[test] fn zip_count_and_checked_size_overflow_are_bounded() {
    assert!(archive_size(&[]).is_err()); assert!(archive_size(&[("large", u64::MAX)]).is_err());
    let names: Vec<String> = (0..17).map(|i| format!("{i}.bin")).collect();
    let entries: Vec<(&str,u64)> = names.iter().map(|name| (name.as_str(), 0)).collect();
    assert!(archive_size(&entries[..16]).is_ok()); assert!(archive_size(&entries).is_err());
    assert!(archive_size(&[("large", (1u64<<32)+7)]).unwrap() > u32::MAX as u64);
}
#[test] fn zip_short_and_growing_members_fail_and_cannot_be_finished() {
    for (bytes, length) in [(b"a".as_slice(),2), (b"abc".as_slice(),2)] {
        let mut writer = StoredZip64::new(Vec::new(),4096).unwrap();
        assert_eq!(writer.add_entry("a", &mut Cursor::new(bytes), length, &Cancellation::new()), Err(Error::InputChanged));
        assert!(writer.finish(&Cancellation::new()).is_err());
    }
}
#[test] fn zip_cancellation_during_read_does_not_finish() {
    struct CancelRead(Cancellation);
    impl Read for CancelRead { fn read(&mut self, out:&mut [u8])->io::Result<usize> { out.fill(7); self.0.cancel(); Ok(out.len()) } }
    let cancel=Cancellation::new(); let mut writer=StoredZip64::new(Vec::new(),200_000).unwrap();
    assert_eq!(writer.add_entry("a", &mut CancelRead(cancel.clone()), 100_000, &cancel), Err(Error::Cancelled));
    assert!(writer.finish(&Cancellation::new()).is_err());
}
#[test] fn zip_write_failure_cannot_be_recovered_as_success() {
    struct NoWrite;
    impl Write for NoWrite { fn write(&mut self,_:&[u8])->io::Result<usize>{Ok(0)} fn flush(&mut self)->io::Result<()>{Ok(())} }
    let mut writer=StoredZip64::new(NoWrite,4096).unwrap();
    assert!(matches!(writer.add_entry("a", &mut Cursor::new(b"a"),1,&Cancellation::new()),Err(Error::Io(_))));
    assert!(writer.finish(&Cancellation::new()).is_err());
}
#[test] fn zip_cancel_before_finish_rejects_complete_payload() {
    let cancel=Cancellation::new(); let mut writer=StoredZip64::new(Vec::new(),4096).unwrap();
    writer.add_entry("a",&mut Cursor::new(b"x"),1,&cancel).unwrap();cancel.cancel();
    assert!(matches!(writer.finish(&cancel),Err(Error::Cancelled)));
}
