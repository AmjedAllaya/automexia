#![cfg(feature = "native")]
//! Real filesystem publication tests. Deliberately no FFmpeg is invoked: typed
//! fixture metadata exercises the archive transaction, not media qualification.
use automexia_video::*;
use automexia_video::interchange::*;
use automexia_video::native::{NativeMediaHost, NativeSettings};
use automexia_video::project::{FrozenRenderSettings, ProjectSource, ResolvedSettings};
use automexia_video::progress::Stage;
use std::{fs, path::{Path, PathBuf}};
use tempfile::TempDir;

fn r(s: &str) -> Rational { s.parse().unwrap() }
fn info() -> MediaInfo {
    let mut value: serde_json::Value = serde_json::from_slice(include_bytes!("fixtures/probe-base.json")).unwrap();
    value["streams"][1]["duration_ts"] = serde_json::json!(96096);
    value["streams"][1]["duration"] = serde_json::json!("2.002000");
    media::parse_probe(&serde_json::to_vec(&value).unwrap()).unwrap()
}
struct Fixture { _dir: TempDir, root: PathBuf, host: NativeMediaHost, project: Project, input: InputFile, request: BundleRequest }
impl Fixture {
    fn new(max_output: u64) -> Self {
        let dir = TempDir::new().unwrap(); let root = dir.path().canonicalize().unwrap();
        let path = root.join("source α & %.mov"); fs::write(&path, b"selected original binary media\0\xff").unwrap();
        // Constructor/inspect/stage/publish never open these executable paths.
        let mut settings = NativeSettings::new(root.join("unused-ffmpeg"), root.join("unused-ffprobe"));
        settings.max_output_bytes = max_output;
        let host = NativeMediaHost::new(settings).unwrap();
        let input = host.inspect_input(&path, &Cancellation::new()).unwrap();
        let metadata = info(); let project_file = root.join("project.amxv");
        let source = ProjectSource::from_probe("source-1", &input, &metadata, metadata.select(StreamSelection::default()).unwrap(), &project_file).unwrap();
        let project = Project::new("bundle-test", source, ResolvedSettings { workflow:None, voice_cleanup:None, voice_enhancement:None,
            color_correction:None, pause_cleanup:None, preset_name:None, preset_revision:None,
            render:FrozenRenderSettings::from_options(&RenderOptions::default()).unwrap() }).unwrap();
        let request = BundleRequest::new(project_file, root.join("handoff.zip"), InterchangeFormat::Otio, EditRate::new(r("30000/1001"), false).unwrap());
        Self { _dir:dir, root, host, project, input, request }
    }
    fn stage(&self) -> Box<dyn BundleLease> {
        self.host.stage_bundle(&self.input, &[self.request.project_file.clone()], &self.request.destination, self.request.max_total_bytes, &Cancellation::new()).unwrap()
    }
    fn plan(&self, workspace: &Path) -> BundlePlan {
        let rate = self.request.rate; let cancel = Cancellation::new();
        let mut verifier = CfrVerifier::new(self.input.clone(), 0, rate, r("0"), r("2.002"), r("1/30000")).unwrap();
        for n in 0..60 { verifier.feed(format!("pts={}\n", n*1001).as_bytes(), &cancel).unwrap(); }
        let media = ExportMedia { input:self.input.clone(), info:info(), timing:Some(verifier.finish(&cancel).unwrap()), baked_video:None, baked_audio:None };
        let export = self.request.to_export_request(workspace).unwrap();
        let document = build_export(&self.project, &export, &media).unwrap();
        BundlePlan::from_document(&document, &self.request).unwrap()
    }
    fn clean(&self) {
        assert!(!fs::read_dir(&self.root).unwrap().any(|e| e.unwrap().file_name().to_string_lossy().starts_with(".automexia-video-")));
    }
}
#[test] fn native_bundle_publishes_one_archive_and_preserves_selected_source() {
    let f=Fixture::new(1_000_000);let before=fs::read(&f.input.canonical_path).unwrap();
    let lease=f.stage();let workspace=lease.workspace().to_path_buf();let plan=f.plan(lease.workspace());
    let receipt=lease.publish(&plan,&Cancellation::new(),&mut |_|{}).unwrap();
    assert_eq!(receipt.path,f.request.destination);assert_eq!(receipt.size,plan.archive_bytes());
    let observed=f.host.inspect_input(&receipt.path,&Cancellation::new()).unwrap();assert_eq!(receipt.sha256,observed.stamp.sha256);
    let bytes=fs::read(&receipt.path).unwrap();assert_eq!(&bytes[..4],b"PK\x03\x04");assert_eq!(&bytes[bytes.len()-22..bytes.len()-18],b"PK\x05\x06");
    assert_eq!(fs::read(&f.input.canonical_path).unwrap(),before);assert!(!workspace.exists());f.clean();
}
#[test] fn native_bundle_existing_destination_is_never_replaced() {
    let f=Fixture::new(1_000_000);fs::write(&f.request.destination,b"keep").unwrap();
    assert!(matches!(f.host.stage_bundle(&f.input,&[],&f.request.destination,f.request.max_total_bytes,&Cancellation::new()),Err(Error::OutputExists)));
    assert_eq!(fs::read(&f.request.destination).unwrap(),b"keep");f.clean();
}
#[test] fn native_bundle_destination_created_after_staging_is_preserved() {
    let f=Fixture::new(1_000_000);let lease=f.stage();let plan=f.plan(lease.workspace());
    let result=lease.publish(&plan,&Cancellation::new(),&mut |event|{if event.stage==Stage::Publishing{fs::write(&f.request.destination,b"concurrent owner").unwrap();}});
    assert!(matches!(result,Err(Error::OutputExists)));assert_eq!(fs::read(&f.request.destination).unwrap(),b"concurrent owner");f.clean();
}
#[test] fn native_bundle_source_change_in_last_callback_prevents_commit() {
    let f=Fixture::new(1_000_000);let lease=f.stage();let plan=f.plan(lease.workspace());
    let result=lease.publish(&plan,&Cancellation::new(),&mut |event|{if event.stage==Stage::Publishing{fs::write(&f.input.canonical_path,b"changed").unwrap();}});
    assert!(matches!(result,Err(Error::InputChanged)));assert!(!f.request.destination.exists());f.clean();
}
#[test] fn native_bundle_cancellation_cleans_private_bakes_and_archive() {
    let f=Fixture::new(1_000_000);let lease=f.stage();fs::write(lease.workspace().join("Media/owned.mov"),b"private").unwrap();let plan=f.plan(lease.workspace());
    let cancel=Cancellation::new();let result=lease.publish(&plan,&cancel,&mut |event|{if event.stage==Stage::Exporting{cancel.cancel();}});
    assert!(matches!(result,Err(Error::Cancelled)));assert!(!f.request.destination.exists());f.clean();
}
#[test] fn native_bundle_callback_panic_is_an_error_with_owned_cleanup() {
    let f=Fixture::new(1_000_000);let lease=f.stage();let plan=f.plan(lease.workspace());
    let result=lease.publish(&plan,&Cancellation::new(),&mut |_|panic!("failed callback"));
    assert!(matches!(result,Err(Error::CallbackPanicked)));assert!(!f.request.destination.exists());f.clean();
}
#[test] fn native_bundle_native_complete_archive_budget_is_enforced() {
    let f=Fixture::new(100);let lease=f.stage();let plan=f.plan(lease.workspace());
    assert!(matches!(lease.publish(&plan,&Cancellation::new(),&mut |_|{}),Err(Error::LimitExceeded(_))));
    assert!(!f.request.destination.exists());f.clean();
}
#[test] fn native_bundle_plan_is_bound_to_staged_destination() {
    let mut f=Fixture::new(1_000_000);let lease=f.stage();f.request.destination=f.root.join("different.zip");let plan=f.plan(lease.workspace());
    assert!(matches!(lease.publish(&plan,&Cancellation::new(),&mut |_|{}),Err(Error::InvalidInput(_))));
    assert!(!f.request.destination.exists());assert!(!f.root.join("handoff.zip").exists());f.clean();
}
#[test] fn native_bundle_plan_is_bound_to_leased_workspace() {
    let f=Fixture::new(1_000_000);let lease=f.stage();let plan=f.plan(&f.root);
    assert!(matches!(lease.publish(&plan,&Cancellation::new(),&mut |_|{}),Err(Error::InvalidInput(_))));
    assert!(!f.request.destination.exists());f.clean();
}
#[test] fn native_bundle_same_size_archive_mutation_during_validation_fails() {
    let f=Fixture::new(1_000_000);let lease=f.stage();let plan=f.plan(lease.workspace());let parent=lease.workspace().parent().unwrap().to_path_buf();
    let result=lease.publish(&plan,&Cancellation::new(),&mut |event|{if event.stage==Stage::Validating{
        let path=fs::read_dir(&parent).unwrap().map(|entry|entry.unwrap().path()).find(|path|path.extension().and_then(|v|v.to_str())==Some("zip")).unwrap();
        let mut bytes=fs::read(&path).unwrap();bytes[0]^=1;fs::write(path,bytes).unwrap();
    }});
    assert!(matches!(result,Err(Error::InvalidOutput(_))));assert!(!f.request.destination.exists());f.clean();
}
#[cfg(unix)] #[test] fn native_bundle_staged_hardlink_substitution_cannot_truncate_source() {
    let f=Fixture::new(1_000_000);let original=fs::read(&f.input.canonical_path).unwrap();
    let lease=f.stage();let plan=f.plan(lease.workspace());let parent=lease.workspace().parent().unwrap().to_path_buf();
    let result=lease.publish(&plan,&Cancellation::new(),&mut |event|{if event.stage==Stage::Exporting{
        let path=fs::read_dir(&parent).unwrap().map(|entry|entry.unwrap().path()).find(|path|path.extension().and_then(|v|v.to_str())==Some("zip")).unwrap();
        fs::remove_file(&path).unwrap();fs::hard_link(&f.input.canonical_path,path).unwrap();
    }});
    assert!(result.is_err());assert_eq!(fs::read(&f.input.canonical_path).unwrap(),original);assert!(!f.request.destination.exists());f.clean();
}
#[test] fn native_bundle_drop_removes_only_owned_workspace() {
    let f=Fixture::new(1_000_000);let lease=f.stage();let workspace=lease.workspace().to_path_buf();
    fs::write(workspace.join("Media/baked.mov"),b"owned").unwrap();drop(lease);
    assert!(!workspace.exists());assert!(f.input.canonical_path.exists());assert!(!f.request.destination.exists());f.clean();
}
#[test] fn native_bundle_zero_limit_and_cancelled_stage_create_no_files() {
    let f=Fixture::new(1_000_000);
    assert!(f.host.stage_bundle(&f.input,&[],&f.request.destination,0,&Cancellation::new()).is_err());
    let cancel=Cancellation::new();cancel.cancel();
    assert!(matches!(f.host.stage_bundle(&f.input,&[],&f.request.destination,f.request.max_total_bytes,&cancel),Err(Error::Cancelled)));f.clean();
}
#[test] fn native_bundle_protected_project_path_cannot_be_destination() {
    let f=Fixture::new(1_000_000);
    assert!(matches!(f.host.stage_bundle(&f.input,&[f.request.destination.clone()],&f.request.destination,f.request.max_total_bytes,&Cancellation::new()),Err(Error::SameFile)));f.clean();
}
#[test] fn native_bundle_offline_unused_protected_asset_does_not_block_publication() {
    let f=Fixture::new(1_000_000);let offline=f.root.join("missing/unused/logo.png");
    let lease=f.host.stage_bundle(&f.input,&[offline],&f.request.destination,f.request.max_total_bytes,&Cancellation::new()).unwrap();
    let plan=f.plan(lease.workspace());assert!(lease.publish(&plan,&Cancellation::new(),&mut |_|{}).is_ok());f.clean();
}
#[cfg(unix)] #[test] fn native_bundle_hardlink_of_input_cannot_be_destination() {
    let f=Fixture::new(1_000_000);fs::hard_link(&f.input.canonical_path,&f.request.destination).unwrap();
    assert!(matches!(f.host.stage_bundle(&f.input,&[],&f.request.destination,f.request.max_total_bytes,&Cancellation::new()),Err(Error::SameFile)));f.clean();
}
#[cfg(unix)] #[test] fn native_bundle_private_workspace_has_owner_only_permissions() {
    use std::os::unix::fs::PermissionsExt;
    let f=Fixture::new(1_000_000);let lease=f.stage();assert_eq!(fs::metadata(lease.workspace()).unwrap().permissions().mode()&0o777,0o700);
    assert!(lease.workspace().join("Media").is_dir());drop(lease);f.clean();
}
#[cfg(unix)] #[test] fn native_bundle_substituted_workspace_directory_is_rejected() {
    let f=Fixture::new(1_000_000);let lease=f.stage();let plan=f.plan(lease.workspace());let workspace=lease.workspace().to_path_buf();
    fs::rename(&workspace,workspace.with_file_name("moved-owned-workspace")).unwrap();fs::create_dir(&workspace).unwrap();
    assert!(matches!(lease.publish(&plan,&Cancellation::new(),&mut |_|{}),Err(Error::InputChanged)));
    assert!(!f.request.destination.exists());f.clean();
}
#[cfg(unix)] #[test] fn native_bundle_last_component_symlink_source_substitution_fails() {
    use std::os::unix::fs::symlink;
    let f=Fixture::new(1_000_000);let lease=f.stage();let plan=f.plan(lease.workspace());
    let target=f.root.join("replacement.mov");fs::write(&target,fs::read(&f.input.canonical_path).unwrap()).unwrap();
    fs::remove_file(&f.input.canonical_path).unwrap();symlink(&target,&f.input.canonical_path).unwrap();
    assert!(lease.publish(&plan,&Cancellation::new(),&mut |_|{}).is_err());assert!(!f.request.destination.exists());f.clean();
}

#[cfg(unix)] #[test] fn native_bundle_substituted_media_directory_is_rejected() {
    let f=Fixture::new(1_000_000);let lease=f.stage();let plan=f.plan(lease.workspace());let media=lease.workspace().join("Media");
    fs::rename(&media,media.with_file_name("moved-owned-media")).unwrap();fs::create_dir(&media).unwrap();
    assert!(matches!(lease.publish(&plan,&Cancellation::new(),&mut |_|{}),Err(Error::InputChanged)));
    assert!(!f.request.destination.exists());f.clean();
}
