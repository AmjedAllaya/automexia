#![cfg(feature="native")]
//! Real bounded FFmpeg frame decoding with a deterministic fixture detector.
//! Model quality is separately measured by face_qualification.rs.
use automexia_video::*;
use automexia_video::native::{NativeMediaHost,NativeSettings};
use automexia_video::model_pack::{YUNET_CONTRACT,YUNET_PROCESSING};
use std::{path::{Path,PathBuf},process::Command,time::Duration,sync::Mutex};
fn tool(name:&str)->PathBuf{std::env::var_os(name).map(PathBuf::from).unwrap_or_else(||PathBuf::from(if name=="FFMPEG"{"/usr/bin/ffmpeg"}else{"/usr/bin/ffprobe"}))}
fn source(dir:&Path)->PathBuf{let path=dir.join("face-source.mp4");assert!(Command::new(tool("FFMPEG")).args(["-v","error","-nostdin","-y","-f","lavfi","-i","color=blue:s=160x96:r=30:d=3","-f","lavfi","-i","sine=frequency=440:sample_rate=48000:duration=3","-c:v","libx264","-threads:v","1","-pix_fmt","yuv420p","-c:a","aac","-threads:a","1","-colorspace","bt709","-color_primaries","bt709","-color_trc","bt709","-color_range","tv","-x264-params","videoformat=component:colorprim=bt709:transfer=bt709:colormatrix=bt709"]).arg(&path).status().unwrap().success());path}
struct Detector{identity:ModelIdentity,seen:Mutex<Vec<Rational>>}
impl Detector{fn new()->Self{Self{identity:ModelIdentity{id:"face-native-fixture".into(),revision:"1".into(),source_revision:"synthetic".into(),manifest_sha256:"a".repeat(64),weights_sha256:"b".repeat(64),contract:YUNET_CONTRACT.into(),preprocessing:YUNET_PROCESSING.into(),runtime:ModelRuntime{adapter:"fixture-only".into(),build_info_sha256:"c".repeat(64),artifact_sha256:"d".repeat(64)},notices_sha256:"e".repeat(64)},seen:Mutex::new(vec![])}}}
impl FaceDetector for Detector{fn identity(&self)->&ModelIdentity{&self.identity}fn revalidate(&self,c:&Cancellation)->Result<()>{c.check()}fn detect(&self,input:FaceInput<'_>,c:&Cancellation)->Result<Vec<FaceDetection>>{c.check()?;assert_eq!(input.rgb.len(),input.width as usize*input.height as usize*3);self.seen.lock().unwrap().push(input.source_time);Ok(vec![FaceDetection{rect:reframe::DisplayRect{x:0.45,y:0.35,width:0.08,height:0.15},confidence:0.95}])}}
fn setup()->(tempfile::TempDir,VideoExtension<NativeMediaHost>,Project,FaceFramingRequest,Detector,ModelActivation){let dir=tempfile::TempDir::new().unwrap();let src=source(dir.path());let project_file=dir.path().join("project.amxv");let extension=VideoExtension::new(NativeMediaHost::new(NativeSettings::new(tool("FFMPEG"),tool("FFPROBE"))).unwrap(),VideoSettings::default()).unwrap();let mut project=extension.create_project(&NewProjectRequest::new("face-native",src,&project_file),&Cancellation::new(),&mut |_|{}).unwrap();project.set_variant_framing("main",Some(FramingSettings::center_crop(OutputSize::new(90,160).unwrap(),project.sources[0].duration).unwrap())).unwrap();let detector=Detector::new();let activation=ModelActivation::selected(detector.identity.clone()).unwrap();let request=FaceFramingRequest{project_file,variant_id:"main".into(),settings:FaceSettings::default(),timeout:Duration::from_secs(30)};(dir,extension,project,request,detector,activation)}
#[test]fn native_face_analysis_is_pending_and_does_not_modify_source(){let (_dir,x,mut p,request,detector,activation)=setup();let bytes=p.to_json().unwrap();let report=x.analyze_faces(&p,&request,&detector,&activation,&Cancellation::new(),&mut |_|{}).unwrap();assert!(report.metrics.sampled_frames>=10);assert_eq!(report.tracks.len(),1);assert_eq!(p.to_json().unwrap(),bytes);report.apply(&mut p,&activation).unwrap();assert_eq!(p.variant("main").unwrap().framing.as_ref().unwrap().disposition,Disposition::NeedsReview);assert!(detector.seen.lock().unwrap().windows(2).all(|t|t[0]<t[1]));}
#[test]fn native_face_report_is_invalid_after_extension_disable(){let (_dir,x,mut p,request,detector,activation)=setup();let report=x.analyze_faces(&p,&request,&detector,&activation,&Cancellation::new(),&mut |_|{}).unwrap();x.disable().unwrap();assert!(matches!(report.apply(&mut p,&activation),Err(Error::Cancelled)));}
#[test]fn native_face_cancellation_during_analysis_does_not_return_report(){let (_dir,x,p,request,detector,activation)=setup();let cancel=Cancellation::new();let signal=cancel.clone();assert!(matches!(x.analyze_faces(&p,&request,&detector,&activation,&cancel,&mut |p|{if p.stage==progress::Stage::AnalyzingFaces{signal.cancel();}}),Err(Error::Cancelled)));}

#[test]fn native_placement_report_survives_job_and_is_invalidated_by_disable(){
    use automexia_video::presentation::*;
    let (_dir,x,mut p,request,_detector,_activation)=setup();let duration=p.sources[0].duration;
    p.set_presentation("main",Some(PresentationSettings{safe_zone:SafeZone::none(),overlays:vec![Overlay{id:"logo".into(),range:TimeRange::new("0".parse().unwrap(),duration).unwrap(),content:GraphicContent::Svg{asset:AssetRef{path:"logo.svg".into(),size:10,sha256:"a".repeat(64)}},placement:Placement{anchor:Anchor::TopLeft,width:16,height:16,margin:0},animation:Animation::default(),enabled:true}],..Default::default()})).unwrap();
    let out=x.analyze_placement(&p,&PlacementRequest::new(&request.project_file,"main"),&Cancellation::new(),&mut |_|{}).unwrap();
    let mut draft=p.clone();out.apply(&mut draft,&[PlacementChoice{target:PlacementTarget::Overlay("logo".into()),anchor:Anchor::BottomRight}]).unwrap();
    x.disable().unwrap();assert!(matches!(out.apply(&mut p,&[PlacementChoice{target:PlacementTarget::Overlay("logo".into()),anchor:Anchor::BottomRight}]),Err(Error::Cancelled)));
}
#[test]fn detector_identity_panic_is_a_structured_error(){
    struct Panicking;impl FaceDetector for Panicking{fn identity(&self)->&ModelIdentity{panic!("fixture identity panic")}fn revalidate(&self,_:&Cancellation)->Result<()>{Ok(())}fn detect(&self,_:FaceInput<'_>,_:&Cancellation)->Result<Vec<FaceDetection>>{Ok(vec![])}}
    let (_dir,x,p,request,_detector,activation)=setup();assert!(matches!(x.analyze_faces(&p,&request,&Panicking,&activation,&Cancellation::new(),&mut |_|{}),Err(Error::CallbackPanicked)));
}

#[test]fn face_total_deadline_covers_initial_input_inspection(){let (_dir,x,p,mut request,detector,activation)=setup();request.timeout=Duration::from_nanos(1);assert!(matches!(x.analyze_faces(&p,&request,&detector,&activation,&Cancellation::new(),&mut |_|{}),Err(Error::Timeout)));}
#[test]fn placement_total_deadline_covers_initial_input_inspection(){
    use automexia_video::presentation::*;
    let (_dir,x,mut p,face_request,_detector,_activation)=setup();let range=TimeRange::new("0".parse().unwrap(),p.sources[0].duration).unwrap();
    p.set_presentation("main",Some(PresentationSettings{safe_zone:SafeZone::none(),overlays:vec![Overlay{id:"logo".into(),range,content:GraphicContent::Svg{asset:AssetRef{path:"logo.svg".into(),size:10,sha256:"a".repeat(64)}},placement:Placement{anchor:Anchor::TopLeft,width:16,height:16,margin:0},animation:Animation::default(),enabled:true}],..Default::default()})).unwrap();
    let mut request=PlacementRequest::new(&face_request.project_file,"main");request.timeout=Duration::from_nanos(1);assert!(matches!(x.analyze_placement(&p,&request,&Cancellation::new(),&mut |_|{}),Err(Error::Timeout)));
}
