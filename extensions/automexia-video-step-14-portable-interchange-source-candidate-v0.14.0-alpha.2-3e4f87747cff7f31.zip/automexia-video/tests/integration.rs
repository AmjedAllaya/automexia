use automexia_video::integration::*;
use automexia_video::*;
use automexia_video::host::{FileStamp, MediaTask, ToolOutput};
use std::path::Path;
use std::sync::{Arc, Mutex, atomic::{AtomicBool, AtomicUsize, Ordering}};
use std::time::Duration;
#[derive(Default)]
struct State { calls: AtomicUsize, registration_calls: AtomicUsize, actions: Mutex<Vec<String>>, events: Mutex<Vec<&'static str>>, panic_stop: AtomicBool, fail_unregister: AtomicBool, panic_unregister: AtomicBool, panic_register: AtomicBool, fail_register: AtomicBool, block: AtomicBool, token: Mutex<Option<Cancellation>>, stop_saw_cancelled: AtomicBool }
#[derive(Clone)] struct Host(Arc<State>);
impl MediaHost for Host {
    fn inspect_input(&self, _: &Path, cancel: &Cancellation) -> Result<InputFile> {
        cancel.check()?; self.0.calls.fetch_add(1, Ordering::SeqCst); *self.0.token.lock().unwrap() = Some(cancel.clone());
        if self.0.block.load(Ordering::SeqCst) { while !cancel.is_cancelled() { std::thread::yield_now(); } return Err(Error::Cancelled); }
        Ok(InputFile { canonical_path: "/explicit/input.mp4".into(), stamp: FileStamp { size: 100, modified_ns: None, sha256: "a".repeat(64), file_id: None } })
    }
    fn revalidate_input(&self, _: &InputFile, cancel: &Cancellation) -> Result<()> { cancel.check() }
    fn runtime_capabilities(&self, cancel: &Cancellation) -> Result<RuntimeCapabilities> { cancel.check()?; self.0.calls.fetch_add(1, Ordering::SeqCst); Ok(RuntimeCapabilities::default()) }
    fn run(&self, _: &MediaTask, cancel: &Cancellation, _: &mut ProgressSink<'_>) -> Result<ToolOutput> { cancel.check()?; self.0.calls.fetch_add(1, Ordering::SeqCst); Ok(ToolOutput { stdout: include_bytes!("fixtures/probe-base.json").to_vec() }) }
    fn stage_output(&self, _: &InputFile, _: &Path, _: &OutputPolicy, _: &Cancellation) -> Result<Box<dyn OutputLease>> { Err(Error::MissingCapability("test output")) }
}
struct Registry(Arc<State>);
struct Lease(Arc<State>);
impl ActionRegistry for Registry {
    fn register_video(&mut self, actions: &[ActionDescriptor]) -> Result<Box<dyn RegistrationLease>> {
        self.0.registration_calls.fetch_add(1, Ordering::SeqCst);
        if self.0.panic_register.load(Ordering::SeqCst) { panic!("injected registry panic"); }
        if self.0.fail_register.load(Ordering::SeqCst) { return Err(Error::MissingCapability("test registry")); }
        *self.0.actions.lock().unwrap() = actions.iter().map(|a| a.id.to_owned()).collect();
        Ok(Box::new(Lease(self.0.clone())))
    }
}
impl RegistrationLease for Lease {
    fn stop_playback(&mut self) -> Result<()> {
        self.0.events.lock().unwrap().push("stop");
        self.0.stop_saw_cancelled.store(self.0.token.lock().unwrap().as_ref().is_some_and(Cancellation::is_cancelled), Ordering::SeqCst);
        if self.0.panic_stop.load(Ordering::SeqCst) { panic!("injected player panic"); } Ok(())
    }
    fn unregister(&mut self) -> Result<()> { self.0.events.lock().unwrap().push("unregister"); if self.0.panic_unregister.load(Ordering::SeqCst) { panic!("injected unregister panic"); } if self.0.fail_unregister.load(Ordering::SeqCst) { return Err(Error::Io("test unregister failure")); } Ok(()) }
}
impl Drop for Lease { fn drop(&mut self) { self.0.events.lock().unwrap().push("drop"); } }
fn registered(optional: OptionalActions) -> (RegisteredVideo<Host>, Arc<State>) {
    let state = Arc::new(State::default()); let mut registry = Registry(state.clone());
    let entry = RegisteredVideo::register(Host(state.clone()), VideoSettings::default(), &mut registry, optional).unwrap(); (entry, state)
}
#[test] fn registration_and_status_do_not_probe_or_open_media() { let (entry, state) = registered(OptionalActions::default()); assert_eq!(state.registration_calls.load(Ordering::SeqCst), 1); let result = entry.dispatch(VideoCommand::Status, &Cancellation::new(), &mut |_| {}).unwrap(); assert!(matches!(result, VideoCommandResult::Status(_))); assert_eq!(state.calls.load(Ordering::SeqCst), 0); }
#[test] fn optional_model_actions_are_absent_by_default() { let (entry, _) = registered(OptionalActions::default()); for a in entry.actions() { assert!(!a.id.starts_with("video.faces.") && !a.id.starts_with("video.speech.") && !a.id.starts_with("video.enhancement.") && !a.id.starts_with("video.transcript.") && !a.id.starts_with("video.hdr.")); } }
#[test] fn each_optional_family_requires_its_own_explicit_flag() { for (options, prefix) in [(OptionalActions { speech_protection: true, ..Default::default() }, "video.speech."), (OptionalActions { voice_enhancement: true, ..Default::default() }, "video.enhancement."), (OptionalActions { face_framing: true, ..Default::default() }, "video.faces."), (OptionalActions { transcription: true, ..Default::default() }, "video.transcript.")] { let (entry, _) = registered(options); assert!(entry.actions().iter().any(|a| a.id.starts_with(prefix))); for other in ["video.speech.", "video.enhancement.", "video.faces.", "video.transcript."] { if other != prefix { assert!(!entry.actions().iter().any(|a| a.id.starts_with(other))); } } } }
#[test] fn all_optional_action_ids_are_unique() { let (entry, _) = registered(OptionalActions { speech_protection: true, voice_enhancement: true, face_framing: true, transcription: true, hdr_preservation: true, portable_bundles: true }); let ids: std::collections::BTreeSet<_> = entry.actions().iter().map(|a| a.id).collect(); assert_eq!(ids.len(), entry.actions().len()); }
#[test] fn typed_probe_dispatch_calls_existing_workflow() { let (entry, state) = registered(OptionalActions::default()); assert!(matches!(entry.dispatch(VideoCommand::Probe(Path::new("/explicit/input.mp4")), &Cancellation::new(), &mut |_| {}).unwrap(), VideoCommandResult::Probed(_))); assert_eq!(state.calls.load(Ordering::SeqCst), 2); }
#[test] fn typed_subtitle_import_keeps_filesystem_inert() { let (entry, state) = registered(OptionalActions::default()); let result = entry.dispatch(VideoCommand::ImportSubtitles { bytes: b"1\n00:00:00,000 --> 00:00:01,000\nHello\n", format: SubtitleFormat::Srt }, &Cancellation::new(), &mut |_| {}).unwrap(); assert!(matches!(result, VideoCommandResult::Subtitles(_))); assert_eq!(state.calls.load(Ordering::SeqCst), 0); }
#[test] fn typed_assembly_commands_keep_io_inert_and_honor_review_and_locks() {
    use automexia_video::project::{ProjectSource,ResolvedSettings,FrozenRenderSettings,TimeRange};
    let (entry,state)=registered(OptionalActions::default());
    let media=media::parse_probe(include_bytes!("fixtures/probe-base.json")).unwrap();
    let path=std::env::temp_dir().join("assembly-integration/project.amxv");
    let input=InputFile{canonical_path:path.with_file_name("source.mp4"),stamp:FileStamp{size:100,sha256:"a".repeat(64),modified_ns:None,file_id:None}};
    let source=ProjectSource::from_probe("source-1",&input,&media,media.select(StreamSelection::default()).unwrap(),&path).unwrap();
    let project=Project::new("assembly",source,ResolvedSettings{workflow:None,preset_name:None,preset_revision:None,pause_cleanup:None,voice_cleanup:None,voice_enhancement:None,color_correction:None,render:FrozenRenderSettings::from_options(&RenderOptions::default()).unwrap()}).unwrap();
    let settings=AssemblySettings{clips:vec![AssemblyClip{id:"one".into(),range:TimeRange::new("0".parse().unwrap(),"1".parse().unwrap()).unwrap(),speed:PlaybackSpeed::Normal}],..Default::default()};
    let VideoCommandResult::Project(pending)=entry.dispatch(VideoCommand::SetAssembly{project:&project,variant:"main",settings:Some(settings)},&Cancellation::new(),&mut |_|{}).unwrap() else{panic!("expected updated project")};
    assert!(matches!(pending.timeline_for_variant("main"),Err(Error::UnresolvedEdits)));
    let VideoCommandResult::Project(approved)=entry.dispatch(VideoCommand::ReviewAssembly{project:&pending,variant:"main",disposition:Disposition::AutoApply,enabled:true},&Cancellation::new(),&mut |_|{}).unwrap() else{panic!("expected approved project")};
    assert_eq!(approved.timeline_for_variant("main").unwrap().duration,"1".parse().unwrap());
    let VideoCommandResult::Project(locked)=entry.dispatch(VideoCommand::LockAssembly{project:&approved,variant:"main",locked:true},&Cancellation::new(),&mut |_|{}).unwrap() else{panic!("expected locked project")};
    assert!(matches!(entry.dispatch(VideoCommand::SetAssembly{project:&locked,variant:"main",settings:None},&Cancellation::new(),&mut |_|{}),Err(Error::LockedEdit)));
    assert_eq!(state.calls.load(Ordering::SeqCst),0);assert!(project.variants[0].assembly.is_none());
    assert!(entry.actions().iter().any(|a|a.id=="video.assembly.set"));
    let mut removed=approved.clone();removed.remove_range("source-1",TimeRange::new("0".parse().unwrap(),"1".parse().unwrap()).unwrap(),"remove the selected occurrence").unwrap();
    let VideoCommandResult::DryRun(report)=entry.dispatch(VideoCommand::DryRunVariant{project:&removed,variant:"main"},&Cancellation::new(),&mut |_|{}).unwrap() else{panic!("expected inspectable dry run")};
    assert!(report.timeline.is_none());assert!(report.pending_or_empty.is_some());assert!(!report.final_media_written);
}
#[test] fn pre_cancelled_dispatch_is_rejected_before_host_io() { let (entry, state) = registered(OptionalActions::default()); let cancel = Cancellation::new(); cancel.cancel(); assert!(matches!(entry.dispatch(VideoCommand::CheckRuntime, &cancel, &mut |_| {}), Err(Error::Cancelled))); assert_eq!(state.calls.load(Ordering::SeqCst), 0); }
#[test] fn deactivation_stops_players_unregisters_and_drains() { let (entry, state) = registered(OptionalActions::default()); assert!(entry.deactivate(Duration::ZERO).unwrap().complete()); assert!(!entry.is_registered()); assert_eq!(*state.events.lock().unwrap(), ["stop", "unregister", "drop"]); assert!(entry.extension().is_err()); assert!(matches!(entry.dispatch(VideoCommand::Status, &Cancellation::new(), &mut |_| {}), Err(Error::Disabled))); }
#[test] fn repeated_deactivate_and_drop_do_not_repeat_cleanup() { let (entry, state) = registered(OptionalActions::default()); entry.deactivate(Duration::ZERO).unwrap(); entry.deactivate(Duration::ZERO).unwrap(); drop(entry); assert_eq!(*state.events.lock().unwrap(), ["stop", "unregister", "drop"]); }
#[test] fn dropping_owner_performs_nonblocking_cleanup_without_explicit_deactivate() { let (entry, state) = registered(OptionalActions::default()); drop(entry); assert_eq!(*state.events.lock().unwrap(), ["stop", "unregister", "drop"]); }
#[test] fn player_panic_does_not_skip_unregister_or_drain() { let (entry, state) = registered(OptionalActions::default()); state.panic_stop.store(true, Ordering::SeqCst); let result = entry.deactivate(Duration::ZERO).unwrap(); assert_eq!(result.errors, [Error::CallbackPanicked]); assert!(result.drain.unwrap().complete); assert_eq!(*state.events.lock().unwrap(), ["stop", "unregister", "drop"]); assert!(!result.complete()); }
#[test] fn unregister_failure_remains_visible_with_successful_drain() { let (entry, state) = registered(OptionalActions::default()); state.fail_unregister.store(true, Ordering::SeqCst); let result = entry.deactivate(Duration::ZERO).unwrap(); assert_eq!(result.errors, [Error::Io("test unregister failure")]); assert!(result.drain.unwrap().complete); assert!(!result.complete()); }
#[test] fn multiple_cleanup_panics_are_isolated_and_recorded() { let (entry, state) = registered(OptionalActions::default()); state.panic_stop.store(true, Ordering::SeqCst); state.panic_unregister.store(true, Ordering::SeqCst); let result = entry.deactivate(Duration::ZERO).unwrap(); assert_eq!(result.errors, [Error::CallbackPanicked, Error::CallbackPanicked]); assert!(result.drain.unwrap().complete); drop(entry); assert_eq!(*state.events.lock().unwrap(), ["stop", "unregister", "drop"]); }
#[test] fn owner_drop_contains_host_cleanup_panics() { let (entry, state) = registered(OptionalActions::default()); state.panic_stop.store(true, Ordering::SeqCst); state.panic_unregister.store(true, Ordering::SeqCst); drop(entry); assert_eq!(*state.events.lock().unwrap(), ["stop", "unregister", "drop"]); }
#[test] fn invalid_timeout_does_not_unregister_or_disable() { let (entry, state) = registered(OptionalActions::default()); assert!(entry.deactivate(Duration::from_secs(86_401)).is_err()); assert!(entry.is_registered()); assert!(entry.extension().unwrap().status().unwrap().enabled); assert!(state.events.lock().unwrap().is_empty()); }
#[test] fn invalid_settings_fail_before_registration() { let state = Arc::new(State::default()); let result = RegisteredVideo::register(Host(state.clone()), VideoSettings { max_concurrent_jobs: 0 }, &mut Registry(state.clone()), OptionalActions::default()); assert!(result.is_err()); assert_eq!(state.registration_calls.load(Ordering::SeqCst), 0); }
#[test] fn registry_error_is_returned_without_media_execution() { let state = Arc::new(State::default()); state.fail_register.store(true, Ordering::SeqCst); assert!(RegisteredVideo::register(Host(state.clone()), VideoSettings::default(), &mut Registry(state.clone()), OptionalActions::default()).is_err()); assert_eq!(state.calls.load(Ordering::SeqCst), 0); }
#[test] fn registry_panic_is_contained() { let state = Arc::new(State::default()); state.panic_register.store(true, Ordering::SeqCst); assert!(matches!(RegisteredVideo::register(Host(state.clone()), VideoSettings::default(), &mut Registry(state), OptionalActions::default()), Err(Error::CallbackPanicked))); }
#[test] fn active_operation_is_cancelled_before_player_cleanup_and_drain() { let (entry, state) = registered(OptionalActions::default()); state.block.store(true, Ordering::SeqCst); std::thread::scope(|scope| { let worker = scope.spawn(|| entry.dispatch(VideoCommand::Probe(Path::new("/explicit/input.mp4")), &Cancellation::new(), &mut |_| {})); while state.token.lock().unwrap().is_none() { std::thread::yield_now(); } assert!(entry.deactivate(Duration::from_secs(2)).unwrap().complete()); assert!(matches!(worker.join().unwrap(), Err(Error::Cancelled))); }); assert!(state.stop_saw_cancelled.load(Ordering::SeqCst)); }

#[test] fn hdr_action_requires_explicit_host_capability() { let (entry, _) = registered(OptionalActions { hdr_preservation: true, ..Default::default() }); assert!(entry.actions().iter().any(|a| a.id == "video.hdr.render")); assert!(!entry.actions().iter().any(|a| a.id.starts_with("video.faces."))); }

struct ReentrantState { entry: Mutex<Option<std::sync::Weak<RegisteredVideo<Host>>>>, saw_busy: AtomicBool }
struct ReentrantRegistry(Arc<ReentrantState>);
struct ReentrantLease(Arc<ReentrantState>);
impl ActionRegistry for ReentrantRegistry { fn register_video(&mut self,_:&[ActionDescriptor])->Result<Box<dyn RegistrationLease>> { Ok(Box::new(ReentrantLease(self.0.clone()))) } }
impl RegistrationLease for ReentrantLease {
 fn stop_playback(&mut self)->Result<()> { if let Some(entry)=self.0.entry.lock().unwrap().as_ref().and_then(std::sync::Weak::upgrade) { self.0.saw_busy.store(matches!(entry.deactivate(Duration::ZERO),Err(Error::Busy)),Ordering::SeqCst); } Ok(()) }
 fn unregister(&mut self)->Result<()> { Ok(()) }
}
#[test] fn reentrant_deactivation_cannot_claim_completion_while_cleanup_is_running() {
 let state=Arc::new(ReentrantState{entry:Mutex::new(None),saw_busy:AtomicBool::new(false)});
 let entry=Arc::new(RegisteredVideo::register(Host(Arc::new(State::default())),VideoSettings::default(),&mut ReentrantRegistry(state.clone()),OptionalActions::default()).unwrap());
 *state.entry.lock().unwrap()=Some(Arc::downgrade(&entry));
 assert!(entry.deactivate(Duration::ZERO).unwrap().complete()); assert!(state.saw_busy.load(Ordering::SeqCst));
}

#[test]fn portable_bundle_action_requires_explicit_host_capability(){let(default,_)=registered(OptionalActions::default());assert!(!default.actions().iter().any(|a|a.id=="video.export.bundle"));assert!(default.actions().iter().any(|a|a.id=="video.export.assess"));let(enabled,state)=registered(OptionalActions{portable_bundles:true,..Default::default()});assert!(enabled.actions().iter().any(|a|a.id=="video.export.bundle"));assert_eq!(state.calls.load(Ordering::SeqCst),0);}
