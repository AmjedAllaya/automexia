#!/usr/bin/env python3
"""Independent FFmpeg timing/composition recipes, not Rust or host execution.

Reads shared audio/compositor literals and mirrors the bounded dynamic timing
recipe in src/edit_render.rs. Exact Fraction expectations are independent of the
FFmpeg output; source bytes, decoded frames, PTS and PCM samples are checked.
"""
from __future__ import annotations
import argparse, array, hashlib, json, math, os, re, subprocess, tempfile, time
from fractions import Fraction as F
from pathlib import Path
import run_media_checks as m
ROOT=Path(__file__).resolve().parents[2]
RATE=48000
WIDTH,HEIGHT=64,48

def literal(name,file='edit_render.rs'):
    hit=re.search(r'pub const '+name+r'\s*:\s*&str\s*=\s*("(?:[^"\\]|\\.)*")\s*;',(ROOT/'src'/file).read_text())
    if not hit: raise AssertionError('missing shared source literal '+name)
    return json.loads(hit.group(1))
def sub(value,**values):
    for key,item in values.items(): value=value.replace('{'+key+'}',str(item))
    return value
def ceil(value):return -((-value.numerator)//value.denominator)
def nearest(value):return (value.numerator*2+value.denominator)//(value.denominator*2)
def decimal(value):return f'{nearest(value*1000000)/1000000:.6f}'
def execute(args,timeout=90):return m.execute(args,timeout=timeout)
def pcm(path):
    out=execute([m.FFMPEG,'-v','error','-nostdin','-threads','2','-i',path,'-map','0:a:0','-c:a','pcm_s16le','-f','s16le','-'])
    samples=array.array('h');samples.frombytes(out)
    if os.sys.byteorder!='little':samples.byteswap()
    return samples

def fixture(work,rate,frames=180,*,impulses=False,origin=0):
    tag=str(rate).replace('/','-')+('-impulse' if impulses else '')+f'-o{origin}'
    raw=work/(tag+'.rgb');audio=work/(tag+'.pcm');path=work/(tag+'.mov')
    raw.write_bytes(b''.join(bytes([20+n]*3)*(WIDTH*HEIGHT) for n in range(frames)))
    count=ceil(F(frames,1)/rate*RATE)
    samples=array.array('h',[0 if impulses else 12000])*count
    if impulses:
        for frame in [0,2,4,62,77,100]:
            index=ceil(F(frame,1)/rate*RATE)+25
            if index<count:samples[index]=20000
    if os.sys.byteorder!='little':samples.byteswap()
    audio.write_bytes(samples.tobytes())
    args=[m.FFMPEG,'-v','error','-nostdin','-y','-f','rawvideo','-pixel_format','rgb24','-video_size',f'{WIDTH}x{HEIGHT}','-framerate',str(rate),'-i',raw,'-f','s16le','-ar',str(RATE),'-ac','1','-i',audio,'-map','0:v:0','-map','1:a:0','-c:v','png','-threads:v','1','-pix_fmt','rgb24','-c:a','pcm_s16le','-video_track_timescale',str(rate.numerator),'-movie_timescale',str(math.lcm(rate.numerator,RATE))]
    if origin:args+=['-output_ts_offset',str(origin)]
    execute(args+[path]);return path

def graph(path,rate,ranges,speed,dissolve,*,source_graphic=False,source_volume=False):
    meta=m.probe(path,head=False);video=m.vstream(meta);origin=F(int(video.get('start_pts',0)))*F(video['time_base']);tb=F(video['time_base'])
    duration=max(F(s['duration_ts'])*F(s['time_base']) for s in m.streams(meta,'video'))
    segments=[];cursor=F(0)
    for first,end in ranges:
        if segments:cursor-=dissolve
        start=F(first,1)/rate;stop=F(end,1)/rate;length=(stop-start)/speed
        segments.append((start,stop,cursor,cursor+length));cursor+=length
    v='[0:0]'
    prefix=''
    if source_graphic:
        # A full-source RGBA clock composed before speed and dissolve. The
        # rectangle is visible only in the later retained source segment.
        on=F(ranges[1][0],1)/rate;off=F(ranges[1][1],1)/rate
        base=f"[0:0]settb=expr={tb},setpts=PTS-({int(origin/tb)}),settb=expr=1/1000000[pres_base]"
        rgba=f"color=c=black@0.0:s={WIDTH}x{HEIGHT}:r={rate}:d={float(duration):.9f},format=rgba,drawbox=x=0:y=0:w=20:h=20:color=red@1:t=fill:replace=1:enable='gte(t,{float(on):.9f})*lt(t,{float(off):.9f})'[graphic]"
        composite=literal('COMPOSITE_GRAPH','presentation_render.rs').replace('{range}','tv').replace('{sar}','1').replace('[1:v]','[graphic]').replace('[vout]','[pres_composed]')
        prefix=f'{base};{rgba};{composite};[pres_composed]settb=expr={tb},setpts=PTS+({int(origin/tb)})[pres_source];'
        v='[pres_source]'
    n=len(segments);video_graph=v+'split='+str(n)+''.join(f'[vs{i}]' for i in range(n))
    for i,(start,end,out_start,out_end) in enumerate(segments):
        frames=(out_end-out_start)*rate;assert frames.denominator==1
        video_graph+=f";[vs{i}]trim=start_pts={ceil((origin+start)/tb)}:end_pts={ceil((origin+end)/tb)},settb=expr=1/1000000,setpts='(PTS-{nearest((origin+start)*1000000)})*{speed.denominator}/{speed.numerator}',fps=fps={rate}:start_time=0:round=near,tpad=stop_mode=clone:stop_duration=1,trim=end_frame={frames.numerator},settb=expr=1/1000000[vt{i}]"
    if n==1:video_graph+=';[vt0]null[vassembled]'
    elif dissolve:
        previous='vt0'
        for i in range(1,n):
            target='vassembled' if i==n-1 else f'vx{i}'
            video_graph+=f';[{previous}][vt{i}]xfade=transition=fade:duration={decimal(dissolve)}:offset={decimal(segments[i][2])}[{target}]';previous=target
    else:video_graph+=';'+''.join(f'[vt{i}]' for i in range(n))+f'concat=n={n}:v=1:a=0[vassembled]'
    total_frames=cursor*rate;assert total_frames.denominator==1
    video_graph+=f';[vassembled]trim=end_frame={total_frames.numerator},settb=expr={1/rate},setpts=N,settb=expr=1/1000000[vout]'
    if speed==1 and not dissolve:
        predicates=[];shifts=[]
        for start,end,out_start,out_end in segments:
            predicates.append(sub(literal('VIDEO_PREDICATE'),start=ceil((origin+start)/tb),end=ceil((origin+end)/tb)))
            shifts.append(sub(literal('VIDEO_SHIFT'),start=nearest((origin+start)*1000000),end=nearest((origin+end)*1000000),shift=nearest(out_start*1000000)-nearest((origin+start)*1000000)))
        video_graph=sub(literal('VIDEO_BASE'),video=0,select='+'.join(predicates),mapping='PTS+'+'+'.join(shifts),color='')
    audio_graph=sub(literal('AUDIO_BASE'),audio=1,origin_num=origin.numerator,origin_den=origin.denominator,rate=RATE,source_samples=ceil(duration*RATE))
    if source_volume:audio_graph=audio_graph.replace('[0:1]',f"[0:1]volume='if(lt(t-({origin}),{float(segments[1][0]):.9f}),0.25,0.75)':eval=frame:precision=double,",1)
    audio_graph+=('[a0]' if n==1 else ',asplit='+str(n)+''.join(f'[a{i}]' for i in range(n)))
    for i,(start,end,out_start,out_end) in enumerate(segments):
        process='' if speed==1 else f',apad=pad_len={ceil(F(RATE,4))},atempo={float(speed):.1f}'
        length=ceil(out_end*RATE)-ceil(out_start*RATE)
        if speed!=1:process+=f',atrim=end_sample={length}'
        elif dissolve or length!=ceil(end*RATE)-ceil(start*RATE):process+=f',apad=whole_len={length},atrim=end_sample={length}'
        if dissolve:process+=',asetnsamples=n=1024:p=0'
        audio_graph+=';'+sub(literal('AUDIO_TRIM'),index=i,start=ceil(start*RATE),end=ceil(end*RATE)).replace(f'[t{i}]',process+f'[t{i}]')
    if dissolve and n>1:
        previous='t0'
        for i in range(1,n):
            samples=ceil(segments[i-1][3]*RATE)-ceil(segments[i][2]*RATE)
            audio_graph+=f';[{previous}][t{i}]acrossfade=ns={samples}:c1=tri:c2=tri[ax{i}]';previous=f'ax{i}'
        audio_graph+=f';[{previous}]anull'
    else:audio_graph+=';'+''.join(f'[t{i}]' for i in range(n))+('anull' if n==1 else f'concat=n={n}:v=0:a=1')
    if speed==1:audio_graph+=f',apad=whole_len={ceil(cursor*RATE)}'
    audio_graph+=f',atrim=end_sample={ceil(cursor*RATE)}[aout]'
    return prefix+video_graph+';'+audio_graph,cursor,segments

def render(work,path,rate,ranges,speed=F(1),dissolve_frames=0,name='out',**options):
    dissolve=F(dissolve_frames,1)/rate;filters,duration,segments=graph(path,rate,ranges,speed,dissolve,**options)
    assert len(filters)<48*1024
    out=work/(name+'.mov');before=hashlib.sha256(path.read_bytes()).hexdigest()
    args=[m.FFMPEG,'-v','error','-nostdin','-y','-copyts','-threads','2','-i',path,'-filter_complex_threads','1','-filter_complex',filters,'-map','[vout]','-map','[aout]','-c:v','png','-threads:v','1','-pix_fmt','rgb24','-fps_mode:v','passthrough','-enc_time_base:v','1/1000000','-c:a','pcm_s16le','-video_track_timescale','1000000','-movie_timescale',str(math.lcm(rate.numerator,RATE)),out]
    execute(args);assert hashlib.sha256(path.read_bytes()).hexdigest()==before,'source changed'
    meta=m.probe(out,head=False);v=m.vstream(meta)
    times=json.loads(execute([m.FFPROBE,'-v','error','-threads','2','-select_streams','v:0','-show_frames','-show_entries','frame=pts','-of','json',out]))['frames']
    pts=[F(frame['pts'])*F(v['time_base']) for frame in times]
    expected_frames=duration*rate;assert expected_frames.denominator==1
    assert len(pts)==expected_frames.numerator,(len(pts),str(expected_frames))
    assert all(abs(at-F(i,1)/rate)<=F(2,1000000) for i,at in enumerate(pts)),'frame PTS drift'
    audio=pcm(out);assert len(audio)==ceil(duration*RATE),(len(audio),ceil(duration*RATE))
    rgb=execute([m.FFMPEG,'-v','error','-nostdin','-threads','2','-i',out,'-map','0:v:0','-filter_threads','1','-threads:v','1','-f','rawvideo','-pix_fmt','rgb24','-'])
    assert len(rgb)==len(pts)*WIDTH*HEIGHT*3
    return {'frames':len(pts),'samples':len(audio),'duration':str(duration),'source_sha256':before},audio,rgb,segments

def pixel(rgb,frame,x=32,y=24):
    offset=(frame*WIDTH*HEIGHT+y*WIDTH+x)*3;return tuple(rgb[offset:offset+3])

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,required=True);args=parser.parse_args();results=[];started=time.monotonic()
    def case(name,fn):
        at=time.monotonic()
        try:detail=fn() or {};results.append({'name':name,'status':'passed','seconds':round(time.monotonic()-at,3),'details':detail});print('PASS',name,flush=True)
        except Exception as exc:results.append({'name':name,'status':'failed','seconds':round(time.monotonic()-at,3),'error':str(exc)});print('FAIL',name,str(exc),flush=True)
    args.output.parent.mkdir(parents=True,exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='video-timing-',dir=args.output.parent) as directory:
        work=Path(directory)
        for rate in [F(30),F(30000,1001)]:
            source=fixture(work,rate);label=str(rate).replace('/','-')
            for speed in [F(1,2),F(1),F(2)]:
                for dissolve in [0,6]:
                    name=f'frames_samples_{label}_speed_{speed.numerator}-{speed.denominator}_dissolve_{dissolve}'
                    def run(s=speed,d=dissolve,n=name,p=source,r=rate):
                        detail,audio,rgb,segments=render(work,p,r,[(0,60),(90,150)],s,d,n)
                        assert abs(pixel(rgb,0)[0]-20)<=1,'first retained frame missing'
                        if d:
                            overlap=segments[1][2];mid=int((overlap+F(d,2)/r)*r);color=pixel(rgb,mid)[0]
                            assert 65<color<130,('dissolve pixel mixture',color)
                            sample=nearest((overlap+F(d,2)/r)*RATE)
                            assert abs(audio[sample]-12000)<500,('constant audio crossfade discontinuity',audio[sample])
                        return detail
                    case(name,run)
            impulse_source=fixture(work,rate,impulses=True)
            def impulse(p=impulse_source,r=rate,n=label):
                detail,audio,rgb,segments=render(work,p,r,[(0,1),(2,3),(4,5)],name='impulse-'+n)
                observed=[i for i,v in enumerate(audio) if v>15000]
                expected=[ceil(s[2]*RATE)+25 for s in segments]
                assert observed==expected,(observed,expected)
                assert pixel(rgb,0)[0]==20 and pixel(rgb,1)[0]==22 and pixel(rgb,2)[0]==24
                detail['impulse_samples']=observed;return detail
            case('fractional_cut_clock_and_impulse_'+label,impulse)
        source=fixture(work,F(30000,1001),origin=5)
        def origin():
            detail,audio,rgb,_=render(work,source,F(30000,1001),[(62,90)],name='positive-origin')
            assert pixel(rgb,0)[0]==82,('NTSC frame 62',pixel(rgb,0));return detail
        case('positive_origin_exact_ntsc_frame62',origin)
        for rate in [F(30),F(30000,1001)]:
            source=fixture(work,rate,origin=5);label=str(rate).replace('/','-')
            def compositor(p=source,r=rate,n=label):
                detail,audio,rgb,segments=render(work,p,r,[(0,60),(90,150)],dissolve_frames=12,name='graphic-'+n,source_graphic=True,source_volume=True)
                first=pixel(rgb,0,5,5);last=pixel(rgb,detail['frames']-2,5,5)
                assert max(first)-min(first)<=2,('graphic appeared before source lifetime',first)
                assert last[0]>200 and last[1]<50 and last[2]<50,('later source graphic missing',last)
                middle=int((segments[1][2]+F(6,1)/r)*r);mixed=pixel(rgb,middle,5,5)
                assert mixed[0]>mixed[1]+40 and mixed[0]<last[0]-20,('graphic did not dissolve with its source frame',mixed,last)
                assert abs(audio[10000]-3000)<5 and abs(audio[-10000]-9000)<5,('source volume clock',audio[10000],audio[-10000])
                detail['graphic_pixels']={'before':first,'dissolve':mixed,'after':last};return detail
            case('source_graphics_and_volume_before_dissolve_'+label,compositor)
    failed=sum(case['status']=='failed' for case in results)
    report={'suite':'timing-reference','qualification':'independent FFmpeg reference recipes; no Rust or Automexia host execution','ffmpeg_version':execute([m.FFMPEG,'-version']).decode().splitlines()[0],'passed':len(results)-failed,'failed':failed,'cases':results,'seconds':round(time.monotonic()-started,3)}
    args.output.parent.mkdir(parents=True,exist_ok=True);args.output.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'passed':report['passed'],'failed':failed}));return 1 if failed else 0
if __name__=='__main__':raise SystemExit(main())
