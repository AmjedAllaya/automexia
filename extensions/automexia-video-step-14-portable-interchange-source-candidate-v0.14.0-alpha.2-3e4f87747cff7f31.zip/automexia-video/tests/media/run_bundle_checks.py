#!/usr/bin/env python3
"""Independent stored ZIP64/portable-media references, not Rust execution.

Constructs the documented wire profile with Python struct/zlib, then uses the
standard library ZIP reader and ffprobe/FFmpeg as separate consumers. Sparse
large-offset cases test ZIP64 metadata without allocating or hashing 4 GiB.
"""
from __future__ import annotations
import argparse
import hashlib
import io
import json
import re
import struct
import tempfile
import time
import zipfile
import zlib
import xml.etree.ElementTree as ET
from pathlib import Path
import run_media_checks as m

SOURCE_ROOT = Path(__file__).resolve().parents[2]
FLAGS = 0x0808
DATE = 33

def local(name):
    encoded = name.encode('ascii')
    return struct.pack('<IHHHHHIIIHH', 0x04034B50, 45, FLAGS, 0, 0, DATE, 0,
                       0xFFFFFFFF, 0xFFFFFFFF, len(encoded), 20) + encoded + struct.pack('<HHQQ', 1, 16, 0, 0)

def descriptor(crc, size):
    return struct.pack('<IIQQ', 0x08074B50, crc, size, size)

def central(name, crc, size, offset):
    encoded = name.encode('ascii')
    return struct.pack('<IHHHHHHIIIHHHHHII', 0x02014B50, (3 << 8) | 45, 45,
                       FLAGS, 0, 0, DATE, crc, 0xFFFFFFFF, 0xFFFFFFFF, len(encoded),
                       28, 0, 0, 0, 0o100644 << 16, 0xFFFFFFFF) + encoded + struct.pack('<HHQQQ', 1, 24, size, size, offset)

def footer(count, size, offset):
    return (struct.pack('<IQHHIIQQQQ', 0x06064B50, 44, (3 << 8) | 45, 45, 0, 0,
                        count, count, size, offset)
            + struct.pack('<IIQI', 0x07064B50, 0, offset + size, 1)
            + struct.pack('<IHHHHIIH', 0x06054B50, 0, 0, 0xFFFF, 0xFFFF, 0xFFFFFFFF, 0xFFFFFFFF, 0))

def profile(entries):
    output = io.BytesIO()
    records = []
    for name, data in entries:
        offset = output.tell()
        crc = zlib.crc32(data)
        output.write(local(name)); output.write(data); output.write(descriptor(crc, len(data)))
        records.append(central(name, crc, len(data), offset))
    offset = output.tell()
    directory = b''.join(records)
    output.write(directory); output.write(footer(len(records), len(directory), offset))
    return output.getvalue()

def expected_size(entries):
    return 98 + sum(148 + 2 * len(name.encode('ascii')) + len(data) for name, data in entries)

def read_verified(data, expected):
    with zipfile.ZipFile(io.BytesIO(data)) as archive:
        assert archive.testzip() is None
        assert archive.namelist() == [name for name, _ in expected]
        for name, source in expected:
            info = archive.getinfo(name)
            assert info.compress_type == zipfile.ZIP_STORED
            assert info.extract_version == 45
            assert info.flag_bits == FLAGS
            assert info.date_time == (1980, 1, 1, 0, 0, 0)
            assert info.CRC == zlib.crc32(source)
            assert archive.read(name) == source
            assert (info.external_attr >> 16) == 0o100644
    assert len(data) == expected_size(expected)

def verify_rust_bundle(path):
    """Independent readback of an explicitly supplied real Rust publication."""
    with zipfile.ZipFile(path) as archive:
        infos = archive.infolist()
        assert 1 <= len(infos) <= 16, 'bounded archive entry count'
        names = [entry.filename for entry in infos]
        assert len(set(name.lower() for name in names)) == len(names), 'duplicate archive names'
        for entry in infos:
            assert re.fullmatch(r'[A-Za-z0-9_./-]{1,240}', entry.filename), 'portable member name'
            assert all(part not in ('', '.', '..') for part in entry.filename.split('/')), 'member traversal'
            assert not entry.is_dir() and entry.compress_type == zipfile.ZIP_STORED
            assert entry.file_size == entry.compress_size and entry.file_size <= 512 * 1024**3
            assert entry.extract_version == 45 and entry.flag_bits == FLAGS
        complete_size = 98 + sum(148 + 2 * len(entry.filename) + entry.file_size for entry in infos)
        assert complete_size <= 512 * 1024**3 and path.stat().st_size == complete_size
        manifest_info = archive.getinfo('manifest.json')
        assert manifest_info.file_size <= 16 * 1024**2
        manifest = json.loads(archive.read('manifest.json'))
        assert manifest['schema'] == 'automexia-interchange-bundle-manifest'
        assert manifest['version'] == 1 and manifest['archive'] == 'stored_zip64'
        assert manifest['hash_algorithm'] == 'sha256' and manifest['manifest_self_included'] is False
        rows = manifest['entries']; assert len(rows) == len(infos)-1
        assert {row['path'] for row in rows} == set(names)-{'manifest.json'}
        media = set()
        for row in rows:
            entry = archive.getinfo(row['path']); assert entry.file_size == row['size']
            digest = hashlib.sha256(); size = 0
            with archive.open(entry) as stream:
                while True:
                    part = stream.read(65536)
                    if not part: break
                    digest.update(part); size += len(part)
            assert size == row['size'] and digest.hexdigest() == row['sha256'], row['path']
            if row['kind'] == 'media': media.add(row['path'])
        timeline_name = manifest['timeline']; assert archive.getinfo(timeline_name).file_size <= 16 * 1024**2
        timeline = archive.read(timeline_name)
        references = set()
        if timeline_name.endswith('.otio'):
            def visit(value):
                if isinstance(value, dict):
                    if str(value.get('OTIO_SCHEMA', '')).startswith('ExternalReference.'):
                        references.add(value['target_url'])
                    for child in value.values(): visit(child)
                elif isinstance(value, list):
                    for child in value: visit(child)
            visit(json.loads(timeline))
        elif timeline_name.endswith('.fcpxml'):
            references = {node.attrib['src'] for node in ET.fromstring(timeline).iter('media-rep')}
        else: raise AssertionError('unexpected timeline format')
        assert references and references == media, (references, media)
        for ref in references:
            assert ref.startswith('Media/') and '..' not in ref.split('/') and '://' not in ref
        return {'archive': str(path), 'members_crc_and_sha_verified': len(rows),
                'relative_media_references': len(references), 'timeline': timeline_name,
                'qualification': 'actual supplied Rust archive independently read; editor application import remains unexecuted'}

def main():
    parser = argparse.ArgumentParser(); parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--rust-bundle', type=Path, action='append', default=[],
                        help='Independently read an explicitly supplied actual Rust archive; repeat for each format')
    args = parser.parse_args(); args.output.parent.mkdir(parents=True, exist_ok=True)
    began = time.monotonic(); results = []
    def case(name, fn):
        started = time.monotonic()
        try:
            detail = fn() or {}; row = {'name': name, 'status': 'passed', 'details': detail}
            print('PASS', name, flush=True)
        except Exception as exc:
            row = {'name': name, 'status': 'failed', 'error': str(exc)}
            print('FAIL', name, str(exc), flush=True)
        row['seconds'] = round(time.monotonic() - started, 3); results.append(row)
    with tempfile.TemporaryDirectory(prefix='video-bundle-', dir=args.output.parent) as directory:
        work = Path(directory)
        def constants():
            source = (SOURCE_ROOT / 'src/bundle_zip.rs').read_text()
            for name, value in [('END_BYTES', '98'), ('ENTRY_OVERHEAD', '148'), ('FLAGS', '0x0808'), ('DOS_DATE', '33')]:
                assert re.search(r'const\s+' + name + r':\s*\w+\s*=\s*' + value + r'\s*;', source), name
            assert '0xedb88320' in source
            return {'source': 'src/bundle_zip.rs', 'wire_profile': 'stored ZIP64 with signed 64-bit data descriptors',
                    'qualification': 'literal profile consistency only; not Rust execution'}
        case('source_profile_constants_match_reference', constants)
        for label, entries in [
            ('empty_member', [('empty.txt', b'')]),
            ('known_crc', [('a.txt', b'123456789')]),
            ('binary_and_nested', [('manifest.json', b'{}\n'), ('Media/source.bin', bytes(range(256)) * 1024)]),
            ('maximum_16_members', [(f'Media/{i}.bin', bytes([i]) * (i+1)) for i in range(16)]),
            ('maximum_name', [('Media/' + 'a' * 230 + '.mov', b'x')]),
        ]:
            def check(entries=entries):
                first = profile(entries); read_verified(first, entries)
                assert first == profile(entries)
                return {'archive_bytes': len(first), 'sha256': hashlib.sha256(first).hexdigest(), 'members': len(entries)}
            case('zip64_' + label, check)
        def crc_failure():
            data = bytearray(profile([('a.txt', b'123456789')]))
            data[len(local('a.txt'))] ^= 1
            with zipfile.ZipFile(io.BytesIO(data)) as archive:
                assert archive.testzip() == 'a.txt'
                try: archive.read('a.txt')
                except zipfile.BadZipFile: pass
                else: raise AssertionError('corrupt payload accepted')
        case('independent_zip_reader_rejects_corrupt_payload_crc', crc_failure)
        def sparse():
            path = work / 'large-offset.zip'; large = (1 << 32) + 17
            with path.open('wb') as out:
                out.write(local('Media/large.bin')); out.seek(large, 1); out.write(descriptor(0, large))
                second = out.tell(); out.write(local('tail.txt')); out.write(b'hello'); out.write(descriptor(zlib.crc32(b'hello'), 5))
                start = out.tell(); records = central('Media/large.bin', 0, large, 0) + central('tail.txt', zlib.crc32(b'hello'), 5, second)
                out.write(records); out.write(footer(2, len(records), start))
            with zipfile.ZipFile(path) as archive:
                assert archive.getinfo('Media/large.bin').file_size == large
                assert archive.getinfo('tail.txt').header_offset == second > 0xFFFFFFFF
                assert archive.read('tail.txt') == b'hello'
            detail = {'logical_archive_bytes': path.stat().st_size, 'second_header_offset': second,
                      'qualification': 'ZIP64 large sizes/offsets and small tail decoded; sparse large payload CRC not qualified'}
            path.unlink(); return detail
        case('zip64_sparse_member_size_and_offsets_beyond_4gib', sparse)
        def malformed():
            data = profile([('a.txt', b'payload')])
            for cut in (1, 10, 22, 70):
                try:
                    with zipfile.ZipFile(io.BytesIO(data[:-cut])) as archive: archive.read('a.txt')
                except (zipfile.BadZipFile, ValueError, EOFError): pass
                else: raise AssertionError(f'truncated archive accepted: {cut}')
        case('independent_zip_reader_rejects_truncated_archive', malformed)
        def manifest():
            media = bytes(range(256)) * 32; name = 'Media/' + hashlib.sha256(media).hexdigest() + '.mov'
            timeline = {'OTIO_SCHEMA': 'Timeline.1', 'name': 'Portable fixture', 'media': {'target_url': name}}
            metadata = json.dumps(timeline, sort_keys=True).encode()
            rows = [{'path': path, 'size': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
                    for path, data in [(name, media), ('timeline.otio', metadata)]]
            manifest_data = json.dumps({'entries': rows, 'manifest_self_included': False}).encode()
            entries = [(name, media), ('manifest.json', manifest_data), ('timeline.otio', metadata)]
            packed = profile(entries); read_verified(packed, entries)
            moved = work / 'moved handoff'; moved.mkdir()
            with zipfile.ZipFile(io.BytesIO(packed)) as archive:
                archive.extractall(moved)  # Only this script's fixed generated names.
            for row in json.loads((moved/'manifest.json').read_bytes())['entries']:
                copied = (moved/row['path']).read_bytes()
                assert len(copied) == row['size'] and hashlib.sha256(copied).hexdigest() == row['sha256']
            reference = json.loads((moved/'timeline.otio').read_bytes())['media']['target_url']
            assert not Path(reference).is_absolute() and '..' not in Path(reference).parts
            assert (moved/reference).read_bytes() == media
            # A modified payload must also fail the manifest hash independently
            # of ZIP CRC, after extraction where ZIP no longer verifies it.
            (moved/reference).write_bytes(b'changed')
            assert hashlib.sha256((moved/reference).read_bytes()).hexdigest() != rows[0]['sha256']
            return {'members_verified': len(entries), 'qualification': 'relative URL/hash reference; OTIO application schema import not executed'}
        case('manifest_hashes_and_relative_media_survive_relocation', manifest)
        def readback_fixture(kind='otio', mutation=None):
            data = b'actual-readback-validator-fixture'
            media_name = 'Media/' + hashlib.sha256(data).hexdigest() + '.mov'
            ref = '/outside.mov' if mutation == 'absolute_reference' else media_name
            if kind == 'otio':
                timeline = json.dumps({'OTIO_SCHEMA': 'Timeline.1', 'reference': {
                    'OTIO_SCHEMA': 'ExternalReference.1', 'target_url': ref}}).encode()
            else:
                timeline = f'<fcpxml version="1.10"><resources><asset id="r1"><media-rep src="{ref}"/></asset></resources></fcpxml>'.encode()
            timeline_name = 'timeline.' + kind
            entries = [(media_name, data), (timeline_name, timeline)]
            rows = [{'path': name, 'size': len(value), 'sha256': hashlib.sha256(value).hexdigest(),
                     'kind': 'media' if name == media_name else 'metadata'} for name, value in entries]
            if mutation == 'manifest_hash': rows[0]['sha256'] = '0' * 64
            manifest = {'schema': 'automexia-interchange-bundle-manifest', 'version': 1,
                        'archive': 'stored_zip64', 'hash_algorithm': 'sha256', 'manifest_self_included': False,
                        'timeline': timeline_name, 'entries': rows}
            entries.append(('manifest.json', json.dumps(manifest).encode()))
            if mutation == 'extra_member': entries.append(('extra.txt', b'unlisted'))
            path = work / f'readback-{kind}-{mutation}.zip'; path.write_bytes(profile(entries))
            if mutation:
                try: verify_rust_bundle(path)
                except AssertionError: return {'qualification': 'real-archive reader rejects a constructed invalid reference fixture'}
                raise AssertionError('readback validator accepted ' + mutation)
            detail = verify_rust_bundle(path)
            detail['qualification'] = 'real-archive reader exercised on constructed reference fixture; no Rust execution'
            return detail
        for kind in ('otio', 'fcpxml'):
            case('actual_readback_validator_accepts_' + kind + '_reference', lambda kind=kind: readback_fixture(kind))
        for mutation in ('manifest_hash', 'absolute_reference', 'extra_member'):
            case('actual_readback_validator_rejects_' + mutation, lambda mutation=mutation: readback_fixture(mutation=mutation))
        def media_roundtrip():
            source = work / 'generated.mov'
            m.execute([m.FFMPEG, '-v', 'error', '-nostdin', '-y', '-f', 'lavfi', '-i', 'testsrc2=size=64x48:rate=30:duration=0.2',
                       '-an', '-c:v', 'png', '-threads', '1', '-pix_fmt', 'rgb24', source], timeout=30)
            raw = source.read_bytes(); name = 'Media/' + hashlib.sha256(raw).hexdigest() + '.mov'
            packed = profile([(name, raw)])
            copied = work / 'relocated.mov'
            with zipfile.ZipFile(io.BytesIO(packed)) as archive: copied.write_bytes(archive.read(name))
            assert copied.read_bytes() == raw
            original = m.execute([m.FFMPEG, '-v', 'error', '-i', source, '-f', 'rawvideo', '-pix_fmt', 'rgb24', '-'], timeout=30)
            decoded = m.execute([m.FFMPEG, '-v', 'error', '-i', copied, '-f', 'rawvideo', '-pix_fmt', 'rgb24', '-'], timeout=30)
            assert original == decoded and len(decoded) == 6 * 64 * 48 * 3
            return {'frames_decoded': 6, 'media_sha256': hashlib.sha256(raw).hexdigest(),
                    'decoded_sha256': hashlib.sha256(decoded).hexdigest()}
        case('generated_media_archive_copy_decodes_identically', media_roundtrip)
        for index, path in enumerate(args.rust_bundle):
            case(f'actual_rust_archive_readback_{index+1}', lambda path=path: verify_rust_bundle(path))
    failed = sum(row['status'] == 'failed' for row in results)
    report = {'suite': 'step14b-bundle-reference',
              'scope': 'Independent Python wire-format and generated-media references; Rust writer, native publication and editor application imports are not executed',
              'passed': len(results)-failed, 'failed': failed, 'blocked': 0, 'cases': results,
              'seconds': round(time.monotonic()-began, 3)}
    report['actual_rust_archives_supplied'] = len(args.rust_bundle)
    args.output.write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({'passed': report['passed'], 'failed': failed})); return 1 if failed else 0

if __name__ == '__main__':
    raise SystemExit(main())
