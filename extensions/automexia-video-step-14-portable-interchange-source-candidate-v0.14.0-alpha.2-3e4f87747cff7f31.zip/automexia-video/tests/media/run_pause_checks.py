#!/usr/bin/env python3
"""Independent FFmpeg energy/cut recipes on encoded test media.

Reads fixed filter templates from Rust. This is NOT execution/typechecking of
Rust, its state machine, source grants, cancellation wrapper or .amxv serializer.
The small oracle locates known synthetic quiet regions only. Test audio includes
signals and optional formant-synthesized speech, not a human-listening study.
"""
from __future__ import annotations
import argparse, array, hashlib, json, math, os, re, shutil, subprocess, tempfile, time, wave
from fractions import Fraction as F
from pathlib import Path
import run_media_checks as m
import run_edit_checks as e

ROOT=m.ROOT

class CapabilityUnavailable(Exception):
    pass


def template(name, file='pause_workflow.rs'):
    match=re.search(r'pub const '+re.escape(name)+r'\s*:\s*&str\s*=\s*("(?:[^"\\]|\\.)*");',(ROOT/'src'/file).read_text())
    if not match:raise AssertionError('Missing source literal '+name)
    return json.loads(match.group(1))

def duration(metadata):
    v=m.vstream(metadata)
    if 'duration_ts' in v:return F(v['duration_ts'])*F(v['time_base'])
    if 'duration' in v:return F(v['duration'])
    # Harness only: the Rust project separately requires reviewed video duration.
    return F(metadata['format']['duration'])-e.exact_start(v)

def analysis_args(source, audio=1):
    meta=m.probe(source);v=m.vstream(meta);a=next(s for s in meta['streams'] if s['index']==audio)
    rate=int(a['sample_rate']);origin=e.exact_start(v);d=duration(meta)
    filt=e.substitute(template('ENERGY_FILTER'),rate=rate,start=e.ceil(origin*rate),end=e.ceil((origin+d)*rate))
    args=m.prefix('ENERGY_PREFIX','pause_workflow.rs')+[str(source),'-map',f'0:{audio}','-vn','-sn','-dn','-filter_threads','1','-af',filt,'-c:a','pcm_s16le','-threads:a','1','-map_metadata','-1','-f','null','-']
    return args,meta,a,origin,d

def parse_metrics(text, channels):
    frames=[];cur=None
    for line in text.splitlines():
        if line.startswith('frame:'):
            if cur is not None:frames.append(cur)
            matched=re.fullmatch(r'frame:(\d+)\s+pts:(-?\d+)\s+pts_time:(\S+)',line);assert matched,line
            assert int(matched[1])==len(frames)
            cur={'pts':int(matched[2]),'values':{}}
        elif line:
            assert cur is not None
            key,value=line.split('=',1);assert key not in cur['values'];cur['values'][key]=float(value)
    if cur is not None:frames.append(cur)
    assert frames,'No decoded frames'
    for f in frames:
        vals=f['values'];assert len(vals)==channels*4+1,vals
        f['samples']=int(vals['lavfi.astats.Overall.Number_of_samples']);assert f['samples']==vals['lavfi.astats.Overall.Number_of_samples'] and f['samples']>0
        f['channels']=[]
        for c in range(1,channels+1):
            prefix=f'lavfi.astats.{c}.'
            assert vals[prefix+'Number of NaNs']==0 and vals[prefix+'Number of Infs']==0
            rms,peak=vals[prefix+'RMS_level'],vals[prefix+'Peak_level']
            assert (math.isfinite(rms) and math.isfinite(peak) and rms<=peak+.001) or rms==peak==-math.inf
            f['channels'].append((rms,peak))
    return frames

def observe(source,audio=1):
    before=hashlib.sha256(source.read_bytes()).hexdigest()
    args,meta,a,origin,d=analysis_args(source,audio)
    text=m.execute([m.FFMPEG,*args]).decode('ascii');frames=parse_metrics(text,a['channels']);rate=int(a['sample_rate'])
    assert max(f['samples'] for f in frames)<=rate//4
    quantum=F(a['time_base']);tol=1 if quantum<=F(1,rate) else e.ceil(quantum*rate)+1
    assert quantum<=F(1,1000)
    deltas=[y['pts']-(x['pts']+x['samples']) for x,y in zip(frames,frames[1:])]
    assert min(deltas,default=0)>=-tol,(min(deltas),tol)
    assert hashlib.sha256(source.read_bytes()).hexdigest()==before
    return frames,rate,origin,d,text,tol

def quiet_regions(source,audio=1):
    frames,rate,origin,d,text,tol=observe(source,audio)
    # Oracle for fixture regions, not a second production analyzer implementation.
    groups=[];current=None;last=None;active=F(0);left=False
    for f in frames:
        gap=last is not None and f['pts']-last>tol
        if gap:
            if current is not None:groups.append([*current,left,False])
            current=None;active=F(0)
        last=f['pts']+f['samples']
        start=max(F(f['pts'],rate)-origin,F(0));end=min(F(last,rate)-origin,d)
        if end<=start:continue
        quiet=all(r<=-50 and p<=-40 for r,p in f['channels'])
        loud=any(r>=-42 for r,p in f['channels'])
        if quiet:
            if current is None:current=[start,end];left=active>=F(18,100)
            else:current[1]=end
            active=F(0)
        else:
            if current is not None:
                # Verify a sustained forward activity flank on fixture data.
                groups.append([*current,left,None]);current=None;active=F(0)
            active=active+end-start if loud else F(0)
            if groups and groups[-1][3] is None:
                if not loud:groups[-1][3]=False
                elif active>=F(18,100):groups[-1][3]=True
    if current is not None:groups.append([*current,left,False])
    regions=[(s,t) for s,t,l,r in groups if l and r and t-s>=F(6,5)]
    return regions,(frames,rate,origin,d,text,tol)

def fixture(path,expression='if(between(t,2,6),0,0.2*sin(2*PI*440*t))',rate=48000,video_filter=None,audio_codec='aac',extra=None,video_rate='30'):
    args=[m.FFMPEG,'-v','error','-y','-f','lavfi','-i',f'testsrc2=size=160x96:rate={video_rate}:duration=10','-f','lavfi','-i',f"aevalsrc=exprs='{expression}':sample_rate={rate}:duration=10"]
    if video_filter:args+=['-vf',video_filter]
    args+=['-c:v','libx264','-threads','2','-pix_fmt','yuv420p','-c:a',audio_codec]
    args+=(extra or [])+[str(path)];m.execute(args)

def approved_bounds(region,rate):
    start,end=region
    return F(e.ceil((start+F(225,1000))*rate),rate),F(((end-F(275,1000))*rate).__floor__(),rate)

def with_fades(graph,parts,rate,ms=5):
    fade=e.ceil(F(ms,1000)*rate)
    for i,p in enumerate(parts):
        length=p['b']-p['a'];n=min(fade,length//4);f=''
        if i>0:f+=e.substitute(e.template('AUDIO_FADE_IN'),samples=n)
        if i+1<len(parts):f+=e.substitute(e.template('AUDIO_FADE_OUT'),start=length-n,samples=n)
        if f:graph=graph.replace(f'[t{i}]',f+f'[t{i}]',1)
    return graph

def edited(source,out,ranges,audio=1,ms=5):
    before=hashlib.sha256(source.read_bytes()).hexdigest();meta=m.probe(source)
    g,d,parts=e.graph(meta,ranges,audio);a=next(s for s in meta['streams'] if s['index']==audio)
    g=with_fades(g,parts,int(a['sample_rate']),ms)
    args=m.prefix('EDITED_PREFIX','edit_render.rs')+['-threads','2']+m.prefix('INPUT_POLICY','plan.rs')+['-i',str(source),'-filter_complex_threads','1','-filter_complex',g,'-map','[vout]','-map','[aout]','-map_metadata','-1','-map_chapters','-1','-sn','-dn','-c:v','libx264','-preset','fast','-crf','18','-pix_fmt','yuv420p','-threads:v','2','-fps_mode:v','passthrough','-enc_time_base:v','1/1000000']
    fps=F(m.vstream(meta)['r_frame_rate']);args+=['-bsf:v',e.substitute(e.template('DURATION_BSF'),num=fps.numerator,den=fps.denominator),'-c:a','aac','-b:a','192k','-threads:a','1','-t',f'{float(d):.9f}','-metadata:s:v:0','rotate=0','-avoid_negative_ts','disabled','-movflags','+faststart','-progress','pipe:1','-nostats','-f','mp4',str(out)]
    assert b'progress=end' in m.execute([m.FFMPEG,*args])
    result=m.probe(out);v=m.vstream(result);oa=m.streams(result,'audio')[0]
    assert abs(float(e.exact_duration(v)-d))<.07
    assert abs(float(e.exact_duration(oa)-d))<.03
    assert oa['channels']==a['channels'] and oa['sample_rate']==a['sample_rate']
    m.execute([m.FFMPEG,*m.prefix('DECODE_PREFIX','host.rs'),str(out),'-map','0:v:0','-map','0:a:0','-f','null','-'])
    assert hashlib.sha256(source.read_bytes()).hexdigest()==before
    return d,parts,g

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,required=True);ap.add_argument('--keep',type=Path);ap.add_argument('--write-metric-fixture',action='store_true');args=ap.parse_args();results=[]
    with tempfile.TemporaryDirectory(prefix='automexia-pauses-') as td:
        work=args.keep or Path(td);work.mkdir(parents=True,exist_ok=True);args.output.parent.mkdir(parents=True,exist_ok=True)
        def case(name,fn):
            t=time.monotonic()
            try:details=fn() or {};results.append(dict(name=name,status='passed',seconds=round(time.monotonic()-t,3),details=details));print('PASS',name,flush=True)
            except CapabilityUnavailable as exc:results.append(dict(name=name,status='blocked',reason=str(exc)));print('BLOCKED',name,str(exc),flush=True)
            except Exception as exc:results.append(dict(name=name,status='failed',error=str(exc)));print('FAIL',name,repr(exc),flush=True)
            args.output.write_text(json.dumps({'scope':'Independent FFmpeg recipes and fixture oracle, NOT Rust execution','complete':False,'checks':results},indent=2)+'\n')
        base=work/'pause-input.mp4';fixture(base)
        def basic():
            runs,(frames,rate,origin,d,text,tol)=quiet_regions(base);assert len(runs)==1,runs
            assert F(2)<=runs[0][0]<F(21,10) and F(59,10)<runs[0][1]<=F(6),runs
            if args.write_metric_fixture:
                first=text.split('frame:1 ')[0];(ROOT/'tests/fixtures/pause-astats-frame.txt').write_text(first)
            return {'frames':len(frames),'quiet_interval':[str(t) for t in runs[0]],'no_resampling':rate==48000,'channels':len(frames[0]['channels'])}
        case('aac_energy_stream_has_expected_quiet_interval',basic)
        def first_render():
            runs,(_,rate,_,d,_,_)=quiet_regions(base);start,end=approved_bounds(runs[0],rate)
            out=work/'pause-shortened.mp4';actual,parts,g=edited(base,out,[(F(0),start),(end,d)])
            assert 6.4<float(actual)<6.7;assert 'afade=t=in:ss=0:ns=240' in g
            (work/'pause-decisions.json').write_text(json.dumps({'source':base.name,'source_sha256':hashlib.sha256(base.read_bytes()).hexdigest(),'quiet':[str(x) for x in runs[0]],'cut':[str(start),str(end)],'before_seconds':str(d),'after_seconds':str(actual),'provenance':'independent fixture recipe; NOT Rust-generated'},indent=2)+'\n')
            return {'before_seconds':str(d),'after_seconds':str(actual),'source_unchanged':True}
        case('approved_fixture_pause_renders_shorter_video_with_audio',first_render)
        def preserved(name,expression):
            p=work/(name+'.mp4');fixture(p,expression);runs,_=quiet_regions(p);assert not runs,runs
        case('continuous_audio_not_quiet',lambda:preserved('continuous','0.2*sin(2*PI*440*t)'))
        case('all_digital_silence_has_no_activity_flanks',lambda:preserved('silence','0'))
        case('short_pause_is_retained',lambda:preserved('short','if(between(t,2,2.5),0,0.2*sin(2*PI*440*t))'))
        case('quiet_tone_above_threshold_is_preserved',lambda:preserved('quiet','if(between(t,2,6),0.007*sin(2*PI*330*t),0.2*sin(2*PI*440*t))'))
        case('breath_like_noise_envelope_is_not_digital_silence',lambda:preserved('breath','if(between(t,2,6),0.013*sin(2*PI*1100*t)*sin(2*PI*1337*t),0.2*sin(2*PI*440*t))'))
        case('continuous_music_bed_prevents_quiet_classification',lambda:preserved('music','0.015*sin(2*PI*220*t)+if(between(t,2,6),0,0.2*sin(2*PI*440*t))'))
        case('fan_like_continuous_background_above_floor_preserved',lambda:preserved('fan','0.012*sin(2*PI*60*t)+if(between(t,2,6),0,0.2*sin(2*PI*440*t))'))
        case('audible_second_channel_never_hidden_by_silent_first',lambda:preserved('second-channel','0|0.2*sin(2*PI*440*t)'))
        case('opposite_phase_stereo_does_not_cancel_in_analysis',lambda:preserved('antiphase','0.2*sin(2*PI*440*t)|-0.2*sin(2*PI*440*t)'))
        case('leading_quiet_without_left_activity_is_preserved',lambda:preserved('leading','if(lt(t,4),0,0.2*sin(2*PI*440*t))'))
        case('trailing_quiet_without_right_activity_is_preserved',lambda:preserved('trailing','if(gt(t,4),0,0.2*sin(2*PI*440*t))'))
        def integer_pcm():
            p=work/'integer.mkv';fixture(p,audio_codec='pcm_s16le');runs,data=quiet_regions(p);assert len(runs)==1
            assert 'Number of NaNs=0.000000' in data[4];return {'frames':len(data[0]),'format':'pcm_s16le'}
        case('integer_pcm_has_explicit_finiteness_metrics',integer_pcm)
        def fractional_clock():
            p=work/'aac44100.mkv';fixture(p,rate=44100);runs,data=quiet_regions(p);assert len(runs)==1
            frames,rate,origin,d,_,tol=data;delta=[y['pts']-x['pts']-x['samples'] for x,y in zip(frames,frames[1:])]
            assert min(delta)>=-tol;return {'native_sample_rate':rate,'min_timestamp_delta_samples':min(delta),'tolerance_samples':tol}
        case('matroska_aac_44100_timestamp_rounding_is_bounded',fractional_clock)
        def opus():
            p=work/'opus.mkv';fixture(p,audio_codec='libopus');runs,data=quiet_regions(p);assert len(runs)==1;return {'native_sample_rate':data[1]}
        case('opus_preskip_does_not_shift_measured_pause',opus)
        def vfr():
            p=work/'vfr.mp4';fixture(p,video_filter="select='not(eq(mod(n,5),1))'",extra=['-fps_mode','vfr']);runs,(_,rate,_,d,_,_)=quiet_regions(p);s,t=approved_bounds(runs[0],rate)
            out=work/'vfr-cut.mp4';edited(p,out,[(0,s),(t,d)]);times=m.frames(out);assert len(set(round(float(b-a),4) for a,b in zip(times,times[1:])))>1
        case('vfr_video_and_native_audio_share_cut_map',vfr)
        def fractional_video():
            p=work/'fractional.mp4';fixture(p,video_rate='30000/1001');runs,(_,rate,_,d,_,_)=quiet_regions(p);s,t=approved_bounds(runs[0],rate);edited(p,work/'fractional-cut.mp4',[(0,s),(t,d)])
        case('fractional_frame_rate_survives_pause_cut',fractional_video)
        def origins():
            p=work/'timestamp3600.mp4';m.execute([m.FFMPEG,'-v','error','-y','-i',base,'-c','copy','-output_ts_offset','3600',p]);runs,data=quiet_regions(p);assert len(runs)==1;assert F(2)<=runs[0][0]<F(21,10);return {'origin':str(data[2])}
        case('large_source_timestamp_origin_is_not_reset_by_analysis',origins)
        def selected():
            p=work/'two-streams.mp4';m.execute([m.FFMPEG,'-v','error','-y','-i',base,'-f','lavfi','-i','sine=frequency=900:sample_rate=48000:duration=10','-map','0:v','-map','0:a','-map','1:a','-c:v','copy','-c:a','aac',p]);runs,_=quiet_regions(p,1);other,_=quiet_regions(p,2);assert len(runs)==1 and not other
        case('only_explicitly_selected_audio_is_analyzed',selected)
        def gap():
            p=work/'gap.mkv';fixture(p,extra=['-af',"aselect='not(between(t,3,5))'"])
            runs,data=quiet_regions(p);assert not runs,runs
            frames,rate,_,_,_,tol=data;assert max(b['pts']-a['pts']-a['samples'] for a,b in zip(frames,frames[1:]))>rate
        case('true_audio_timestamp_gap_is_not_filled_as_silence',gap)
        def paths():
            p=work/'剪辑 input $(literal).mp4';shutil.copyfile(base,p);assert len(quiet_regions(p)[0])==1
        case('unicode_space_and_shell_metacharacter_paths_are_literal',paths)
        def invalid():
            p=work/'corrupt.mp4';p.write_bytes(b'not-media')
            try:observe(p)
            except (AssertionError,KeyError):return
            raise AssertionError('corrupt media accepted')
        case('corrupt_input_fails_instead_of_returning_quiet',invalid)
        def cancel():
            args0,_,_,_,_=analysis_args(base);idx=args0.index('-i');args0.insert(idx,'-re')
            p=subprocess.Popen([m.FFMPEG,*args0],stdout=subprocess.PIPE,stderr=subprocess.PIPE,stdin=subprocess.DEVNULL)
            time.sleep(.15);p.kill();stdout,stderr=p.communicate(timeout=5);assert p.returncode!=0
            return {'scope':'direct FFmpeg termination; Rust cancellation not executed','bytes_before_stop':len(stdout)}
        case('stopped_decoder_exits_without_complete_success',cancel)
        def transient():
            p=work/'transient.mkv';fixture(p,"if(between(t,2,6),if(eq(mod(n,9600),0),0.02,0),0.2*sin(2*PI*440*t))",audio_codec='pcm_s16le');runs,data=quiet_regions(p);assert not runs,runs
            assert any(rms<-50 and peak>-40 for f in data[0] for rms,peak in f['channels'])
        case('brief_peak_transients_are_not_lost_in_rms_average',transient)
        def fades():
            # High-contrast amplitude step fixture. Fades use sample-count
            # literals extracted from Rust, changing amplitude but not duration.
            n=240;fadeout=e.substitute(e.template('AUDIO_FADE_OUT'),start=48000-n,samples=n)
            fadein=e.substitute(e.template('AUDIO_FADE_IN'),samples=n)
            g=f'[0:a]atrim=end_sample=48000,asetpts=PTS-STARTPTS{fadeout}[a];[1:a]atrim=end_sample=48000,asetpts=PTS-STARTPTS{fadein}[b];[a][b]concat=n=2:v=0:a=1[out]'
            raw=m.execute([m.FFMPEG,'-v','error','-f','lavfi','-i','aevalsrc=0.2:s=48000:d=1','-f','lavfi','-i','aevalsrc=-0.2:s=48000:d=1','-filter_complex',g,'-map','[out]','-f','f32le','-'])
            a=array.array('f');a.frombytes(raw);assert len(a)==96000
            step=abs(a[48000]-a[47999]);assert step<.002,step
            assert abs(a[100]-.2)<1e-6 and abs(a[-100]+.2)<1e-6
            return {'join_step':step,'unfaded_step':.4,'sample_count_unchanged':len(a)}
        case('five_millisecond_fades_reduce_join_step_without_time_change',fades)
        def sync():
            src=work/'sync-pause.mp4'
            vf="color=black:size=64x64:rate=30:duration=10,drawbox=x=0:y=0:w=iw:h=ih:color=white:t=fill:enable='between(t,1,1.06)+between(t,8,8.06)'"
            af=r"aevalsrc=0.4*sin(2*PI*1000*t)*(between(t\,1\,1.06)+between(t\,8\,8.06)):s=48000:d=10"
            m.execute([m.FFMPEG,'-v','error','-y','-f','lavfi','-i',vf,'-f','lavfi','-i',af,'-c:v','libx264','-threads','2','-pix_fmt','yuv420p','-c:a','aac',src])
            out=work/'sync-cut.mp4';edited(src,out,[(F(0),F(89,40)),(F(229,40),F(10))])
            raw=m.execute([m.FFMPEG,'-v','error','-i',out,'-vf','scale=1:1','-pix_fmt','gray','-f','rawvideo','-']);times=m.frames(out)
            flashes=[float(t) for t,b in zip(times,raw) if b>100];audio=m.pcm(out);onsets=[]
            for i in range(0,len(audio)-480,480):
                if sum(abs(x) for x in audio[i:i+480])/480>1000 and (not onsets or i/48000-onsets[-1]>.15):onsets.append(i/48000)
            assert len(onsets)==2,onsets
            errors=[min(abs(a-v) for v in flashes) for a in onsets];assert max(errors)<.035,errors
            assert abs(onsets[1]-4.5)<.02,onsets
            return {'maximum_av_error_seconds':max(errors),'audio_onsets_seconds':onsets}
        case('decoded_flash_tone_sync_after_pause_cut_and_fades',sync)
        def invalid_floats():
            p=work/'nan.mkv';fixture(p,'0/0',audio_codec='pcm_f32le')
            argv,_,_,_,_=analysis_args(p)
            text=m.execute([m.FFMPEG,*argv]).decode()
            assert any(float(n)>0 for n in re.findall(r'Number of NaNs=(.*)',text)),text[:1000]
            try:parse_metrics(text,1)
            except AssertionError:return {'invalid_samples_reported':True,'oracle_rejected':True}
            raise AssertionError('Nonfinite measurements accepted')
        case('float_nan_samples_are_reported_not_silently_quiet',invalid_floats)
        def lossless_restoration():
            out=work/'restored-no-cut.mp4';edited(base,out,[(F(0),F(10))]);assert len(m.frames(out))==len(m.frames(base))
            assert abs(float(e.exact_duration(m.vstream(m.probe(out))))-10)<.02
            return {'scope':'restored edit timing, NOT bit-identical lossy encoding'}
        case('removing_pause_decision_restores_original_duration',lossless_restoration)

        def speech():
            executable=shutil.which('espeak')
            if not executable:raise CapabilityUnavailable('espeak speech fixture generator is unavailable')
            speechwav=work/'speech.wav';m.execute([executable,'-s','140','-w',speechwav,'Quiet words and a natural breath should remain. This sentence is a synthetic test, not a listening evaluation.'])
            with wave.open(str(speechwav),'rb') as f:rate=f.getframerate();ch=f.getnchannels();width=f.getsampwidth();data=f.readframes(f.getnframes())
            assert width==2 and ch==1
            joined=work/'speech-with-pause.wav';length=F(len(data)//2,rate)
            with wave.open(str(joined),'wb') as f:f.setnchannels(1);f.setsampwidth(2);f.setframerate(rate);f.writeframes(data+b'\0\0'*(4*rate)+data)
            p=work/'speech-input.mp4';m.execute([m.FFMPEG,'-v','error','-y','-f','lavfi','-i',f'testsrc2=size=160x96:rate=30:duration={float(length*2+4):.6f}','-i',joined,'-c:v','libx264','-threads','2','-pix_fmt','yuv420p','-c:a','aac',p])
            runs,(_,sr,_,d,_,_)=quiet_regions(p)
            centre=[run for run in runs if run[0]<length+1 and run[1]>length+3];assert len(centre)==1,runs
            s,t=approved_bounds(centre[0],sr);assert s>length-F(1,2) and t<length+4
            edited(p,work/'speech-shortened.mp4',[(F(0),s),(t,d)])
            return {'formant_synthesized':True,'human_recording':False,'listening_test':False,'source_duration':str(d),'cut':[str(s),str(t)]}
        case('formant_speech_fixture_long_inserted_pause_can_be_shortened',speech)
        report={'scope':'Independent FFmpeg filters and fixture oracle; NOT Rust execution or human-listening qualification','runtime':m.execute([m.FFMPEG,'-version']).decode().splitlines()[0],'complete':True,'passed':sum(x['status']=='passed' for x in results),'failed':sum(x['status']=='failed' for x in results),'blocked':sum(x['status']=='blocked' for x in results),'checks':results}
        args.output.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'passed':report['passed'],'failed':report['failed']}))
        return int(report['failed']>0)
if __name__=='__main__':raise SystemExit(main())
