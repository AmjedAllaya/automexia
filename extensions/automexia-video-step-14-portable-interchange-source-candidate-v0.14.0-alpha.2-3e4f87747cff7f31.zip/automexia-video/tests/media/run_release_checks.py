#!/usr/bin/env python3
"""Step 11 independent failure and resource recipes; NOT Rust/host qualification."""
from __future__ import annotations
import argparse, errno, hashlib, json, os, socket, subprocess, sys, tempfile, threading, time
from pathlib import Path
import run_media_checks as m

def require(ok,msg):
    if not ok:raise AssertionError(msg)
class CapabilityUnavailable(Exception):
    """An environment capability was unavailable; never a passing assertion."""
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def execute(args):return subprocess.run(list(map(str,args)),stdin=subprocess.DEVNULL,capture_output=True,timeout=30)
def tree_rss(pid):
    todo,seen,total,observed=[pid],set(),0,False
    while todo:
        x=todo.pop()
        if x in seen:continue
        seen.add(x)
        try:
            for line in (Path('/proc')/str(x)/'status').read_text().splitlines():
                if line.startswith('VmRSS:'):
                    total+=int(line.split()[1])*1024;observed=True
            for c in (Path('/proc')/str(x)/'task').glob('*/children'):todo += list(map(int,c.read_text().split()))
        except (OSError,ValueError):pass
    return total if observed else None

def measured(argv,work,name):
    started=time.monotonic();samples=[]
    with (work/(name+'.log')).open('wb') as log:
        p=subprocess.Popen(list(map(str,argv)),stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT)
        try:
            while p.poll() is None:
                if sys.platform.startswith('linux'):
                    rss=tree_rss(p.pid)
                    if rss is not None:samples.append(rss)
                require(time.monotonic()-started<90,'benchmark deadline')
                time.sleep(.02)
            require(p.returncode==0,'benchmark process failed')
        finally:
            if p.poll() is None:p.kill();p.wait()
    return {'wall_seconds':round(time.monotonic()-started,4),'sampled_peak_process_tree_rss_bytes':max(samples) if samples else None,'sample_interval_ms':20,'scope':'FFmpeg process tree on synthetic media, not Rust/application input latency'}

class Canary:
    def __enter__(self):
        self.server=socket.socket();self.server.bind(('127.0.0.1',0));self.server.listen();self.server.settimeout(.05)
        self.hits=0;self.done=threading.Event();self.port=self.server.getsockname()[1]
        def watch():
            while not self.done.is_set():
                try:s,_=self.server.accept();self.hits+=1;s.close()
                except socket.timeout:pass
                except OSError:break
        self.thread=threading.Thread(target=watch);self.thread.start();return self
    def __exit__(self,*args):
        self.done.set();self.thread.join(timeout=1);self.server.close();require(not self.thread.is_alive(),'canary cleanup')

def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--output',type=Path,required=True);a=ap.parse_args();rows=[]
    def case(name,fn):
        t=time.monotonic()
        try:details=fn() or {};rows.append({'name':name,'status':'passed','seconds':round(time.monotonic()-t,3),'details':details});print('PASS',name,flush=True)
        except CapabilityUnavailable as e:rows.append({'name':name,'status':'blocked','reason':str(e)});print('BLOCKED',name,str(e),flush=True)
        except Exception as e:rows.append({'name':name,'status':'failed','error':str(e)});print('FAIL',name,str(e),flush=True)
    with tempfile.TemporaryDirectory(prefix='video-release-') as tmp:
        w=Path(tmp);base=w/'source.mp4';m.fixture(base,rate='30',duration='3');original=digest(base)
        def network(kind):
            with Canary() as c:
                p=w/(kind+'.mp4')
                p.write_text(f'#EXTM3U\n#EXT-X-TARGETDURATION:3\n#EXTINF:3,\nhttp://127.0.0.1:{c.port}/source.ts\n#EXT-X-ENDLIST\n' if kind=='hls' else f"ffconcat version 1.0\nfile 'http://127.0.0.1:{c.port}/source.mp4'\n")
                r=execute([m.FFPROBE,*m.prefix('PROBE_PREFIX','host.rs'),p]);time.sleep(.1)
                require(r.returncode!=0,'playlist accepted');require(c.hits==0,'network connection attempted')
            return {'localhost_connections':c.hits,'scope':'production FFprobe argument prefix; not Rust validation'}
        case('disguised_HLS_does_not_contact_localhost',lambda:network('hls'))
        case('disguised_concat_does_not_contact_localhost',lambda:network('concat'))
        def local_concat():
            p=w/'local.mp4';p.write_text(f"ffconcat version 1.0\nfile '{base}'\n");require(execute([m.FFPROBE,*m.prefix('PROBE_PREFIX','host.rs'),p]).returncode!=0,'concat accepted')
        case('local_concat_input_rejected',local_concat)
        def corrupt():
            p=w/'broken.mp4';p.write_bytes(b'not video\0'*50);require(execute([m.FFPROBE,*m.prefix('PROBE_PREFIX','host.rs'),p]).returncode!=0,'corrupt file accepted')
        case('corrupt_input_fails',corrupt)
        def truncated():
            p=w/'truncated.mp4';p.write_bytes(base.read_bytes()[:len(base.read_bytes())//3]);require(execute([m.FFMPEG,*m.prefix('DECODE_PREFIX','host.rs'),p,'-f','null','-']).returncode!=0,'truncated file decoded successfully')
        case('truncated_decode_fails',truncated)
        def filename():
            p=w/'lecture ;$(touch SHOULD_NOT_EXIST) café.mp4';p.write_bytes(base.read_bytes());m.render(p,w/'output ;$.mp4');require(not (w/'SHOULD_NOT_EXIST').exists(),'shell interpretation');require(digest(p)==original,'source changed')
        case('unicode_and_shell_chars_are_filename_data',filename)
        def surround():
            p=w/'surround.mp4';m.execute([m.FFMPEG,'-v','error','-y','-f','lavfi','-i','testsrc2=size=160x96:rate=30:duration=2','-f','lavfi','-i','anullsrc=r=48000:cl=5.1','-t','2','-c:v','libx264','-threads','2','-pix_fmt','yuv420p','-c:a','aac',p]);s=m.streams(m.render(p,w/'surround-out.mp4'),'audio')[0];require(s['channels']==6 and s['channel_layout']=='5.1','layout changed')
        case('surround_layout_preserved',surround)
        def gop():
            p=w/'gop.mp4';m.fixture(p,duration='8',rate='30000/1001',extra=['-g','240','-bf','3']);o=w/'gop-out.mp4';m.render(p,o);require(len(m.frames(p))==len(m.frames(o)),'frame loss')
        case('fractional_long_GOP_frame_count',gop)
        def interrupt(kill=False):
            for _ in range(1 if kill else 3):
                p=subprocess.Popen([m.FFMPEG,'-v','error','-nostdin','-re','-stream_loop','-1','-i',str(base),'-f','null','-'],stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
                try:time.sleep(.08);p.kill() if kill else p.terminate();p.wait(timeout=5);require(p.returncode!=0,'terminated tool reported success')
                finally:
                    if p.poll() is None:p.kill();p.wait()
            require(digest(base)==original,'original changed')
        case('repeated_cancel_reaps_process',interrupt)
        case('forced_exit_is_not_success',lambda:interrupt(True))
        def full():
            require(Path('/dev/full').exists(),'/dev/full test unavailable on this platform')
            r=execute([m.FFMPEG,'-v','error','-nostdin','-y','-i',base,'-map','0:v:0','-c','copy','-f','nut','/dev/full']);require(r.returncode!=0,'ENOSPC reported success')
        case('full_disk_device_write_failure',full)
        def absent():
            r=execute([m.FFMPEG,'-v','error','-nostdin','-i',base,'-map','0:v:0','-c','copy',w/'absent'/'out.mp4']);require(r.returncode!=0,'missing parent accepted');require(not (w/'absent').exists(),'directory silently created')
        case('missing_output_parent_not_created',absent)
        def denied():
            if os.name!='posix':raise CapabilityUnavailable('permission case requires POSIX')
            w.chmod(0o755);dest=w/'readonly';dest.mkdir();dest.chmod(0o555);base.chmod(0o644)
            kwargs={'user':65534,'group':65534} if os.geteuid()==0 else {}
            try:
                try:
                    r=subprocess.run([m.FFMPEG,'-v','error','-nostdin','-i',str(base),'-map','0:v:0','-c','copy',str(dest/'out.mp4')],stdin=subprocess.DEVNULL,capture_output=True,timeout=10,**kwargs)
                except (OSError,subprocess.SubprocessError) as error:
                    # Switching credentials can be prohibited independently of
                    # FFmpeg. A denied launch did not exercise output handling.
                    if kwargs and (isinstance(error,OSError) and error.errno in (errno.EPERM,errno.EACCES,errno.EINVAL) or
                                   type(error) is subprocess.SubprocessError and 'preexec_fn' in str(error)):
                        raise CapabilityUnavailable('cannot launch selected FFmpeg under unprivileged UID: '+type(error).__name__) from error
                    raise
                require(r.returncode!=0 and b'Permission denied' in r.stderr,'output permission denial not observed');require(not (dest/'out.mp4').exists(),'denied output exists')
            finally:dest.chmod(0o755)
        case('unprivileged_output_permission_denial',denied)
        def long():
            p=w/'long.mp4';m.fixture(p,duration='120',rate='30');o=w/'long-out.mp4';stats=measured([m.FFMPEG,*m.render_argv(p,o)],w,'render');require(len(m.frames(o))==3600,'long frame count');m.execute([m.FFMPEG,*m.prefix('DECODE_PREFIX','host.rs'),o,'-f','null','-']);stats.update(source_seconds=120,width=160,height=96,corpus='synthetic',human_recording=False);return stats
        case('two_minute_synthetic_render_resource_sample',long)
        case('decode_resource_sample',lambda:measured([m.FFMPEG,*m.prefix('DECODE_PREFIX','host.rs'),base,'-f','null','-'],w,'decode'))
        case('original_unchanged_after_failure_tests',lambda:require(digest(base)==original,'source changed'))
    report={'scope':'Independent FFmpeg failure/permission recipes, NOT Rust, host install or perceptual release qualification','runtime':m.execute([m.FFMPEG,'-version']).decode().splitlines()[0],'python':sys.version,'platform':sys.platform,'passed':sum(x['status']=='passed' for x in rows),'failed':sum(x['status']=='failed' for x in rows),'blocked':sum(x['status']=='blocked' for x in rows),'cases':rows}
    a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(json.dumps(report,indent=2)+'\n');return int(report['failed']!=0)
if __name__=='__main__':raise SystemExit(main())
