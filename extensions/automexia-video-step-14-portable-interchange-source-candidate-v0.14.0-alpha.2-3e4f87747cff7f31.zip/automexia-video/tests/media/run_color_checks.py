#!/usr/bin/env python3
"""Independent FFmpeg/pixel recipe checks for Step 6.
These execute the literal Rust filter templates, NOT the Rust crate or analyzer.
The histogram reference below checks media signals separately; Cargo tests are
required to execute the actual SceneAnalyzer, storage and review implementation.
"""
from __future__ import annotations
import argparse, hashlib, json, math, os, re, statistics, subprocess, sys, tempfile, time
from fractions import Fraction as F
from pathlib import Path
import run_media_checks as m
import run_edit_checks as e
ROOT=Path(__file__).resolve().parents[2]
COLOR=ROOT/'src/color_render.rs'
WORKFLOW=ROOT/'src/color_workflow.rs'
# Fixture tags are explicit; output tags below mirror RenderPlan exactly.
TAGS=['-colorspace','bt709','-color_trc','bt709','-color_primaries','bt709','-color_range','tv',
      '-x264-params','videoformat=component:colorprim=bt709:transfer=bt709:colormatrix=bt709']

def template(name, path=COLOR):
    hit=re.search(r'pub const '+name+r'\s*:\s*&str\s*=\s*("(?:[^"\\]|\\.)*")\s*;',path.read_text())
    assert hit,name
    return json.loads(hit.group(1))
def sub(s,**kw):
    for k,v in kw.items():s=s.replace('{'+k+'}',str(v))
    return s

def run(args,data=None):
    p=subprocess.run(list(map(str,args)),input=data,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=90)
    if p.returncode:raise AssertionError(p.stderr.decode(errors='replace')[-6000:])
    return p

def frame(w,h,kind='chart',value=0):
    buf=bytearray()
    for y in range(h):
        for x in range(w):
            if kind=='chart':
                z=round(25+140*x/max(1,w-1));rgb=[z]*3
            elif kind=='bright':
                z=round(110+120*x/max(1,w-1));rgb=[z]*3
            elif kind=='cast':
                z=round(60+60*x/max(1,w-1));rgb=[round(z*1.08),z,round(z*.93)]
            elif kind=='red':rgb=[150,25,25]
            elif kind=='blue':rgb=[25,25,150]
            elif kind=='flash':rgb=[255]*3
            elif kind=='gray':rgb=[value]*3
            elif kind=='orientation':rgb=[160,20,20] if y<h//2 else [20,20,160]
            else:raise ValueError(kind)
            buf.extend(rgb)
    return bytes(buf)

def encode(path,frames,w=96,h=54,rate='30',audio=True,extra=(),vf=None):
    args=[m.FFMPEG,'-v','error','-y','-f','rawvideo','-pixel_format','rgb24','-video_size',f'{w}x{h}','-framerate',rate,'-i','pipe:0']
    duration=F(len(frames),1)/F(rate)
    if audio:args+=['-f','lavfi','-i',f'sine=frequency=440:sample_rate=48000:duration={float(duration):.9f}']
    graph='scale=in_color_matrix=bt709:out_color_matrix=bt709:out_range=tv,format=yuv420p'
    if vf:graph+=','+vf
    args+=['-filter_threads','1','-vf',graph,'-c:v','libx264','-threads:v','1','-crf','0',*TAGS]
    if audio:args+=['-c:a','aac','-threads:a','1']
    args += [*extra,str(path)]
    run(args,b''.join(frames))
    return path

def decode(path,w=None,h=None):
    meta=m.probe(path);v=m.vstream(meta);vw,vh=v['width'],v['height']
    args=[m.FFMPEG,'-v','error','-i',str(path),'-an','-filter_threads','1']
    f='scale=in_color_matrix=bt709:in_range='+('pc' if v.get('color_range')=='pc' else 'tv')+':out_range=pc'
    if w is not None:f+=f':w={w}:h={h}';vw,vh=w,h
    args+=['-vf',f,'-fps_mode','passthrough','-pix_fmt','rgb24','-c:v','rawvideo','-threads:v','1','-f','rawvideo','-']
    raw=run(args).stdout;size=vw*vh*3;assert len(raw)%size==0
    return [raw[i:i+size] for i in range(0,len(raw),size)]

def scan(path,width=96,height=54):
    metadata=m.probe(path);v=m.vstream(metadata);tb=F(v['time_base'])
    f=sub(template('VIDEO_SCAN_FILTER',WORKFLOW),width=width,height=height,range='pc' if v.get('color_range')=='pc' else 'tv',time_base=v['time_base'])
    prefix=m.prefix('VIDEO_SCAN_PREFIX','color_workflow.rs')
    out=run([m.FFMPEG,*prefix,str(path),'-map',f"0:{v['index']}",'-an','-sn','-dn','-filter_threads','1','-vf',f,
             '-fps_mode:v','passthrough','-enc_time_base:v','demux','-c:v','rawvideo','-threads:v','1','-pix_fmt','rgb24','-flush_packets','1','-f','rawvideo','pipe:1'])
    headers=[];source_headers=[];tag_lines=[]
    for line in out.stderr.decode().splitlines():
        if line.startswith('[showinfo@amx_source @ '):
            if ' n:' in line:source_headers.append(line)
            if 'color_trc:' in line:tag_lines.append(line)
        if line.startswith('[showinfo@amx_rgb @ ') and ' n:' in line:
            fields={name: re.search(r'(?:^|\s)'+name+r':\s*(\S+)',line).group(1) for name in ['n','pts','duration','fmt','s']}
            assert fields['fmt']=='rgb24' and fields['s']==f'{width}x{height}'
            headers.append((int(fields['n']),F(int(fields['pts']))*tb,F(int(fields['duration']))*tb))
    size=width*height*3
    assert len(out.stdout)==len(headers)*size,(len(out.stdout),len(headers),size)
    assert len(source_headers)==len(headers) and all('i:P' in x for x in source_headers)
    assert len(tag_lines)==len(headers)
    assert all('color_space:bt709 color_primaries:bt709 color_trc:bt709' in x for x in tag_lines),tag_lines[:1]
    assert [h[0] for h in headers]==list(range(len(headers)))
    assert all(a[1]<b[1] for a,b in zip(headers,headers[1:]))
    frames=[out.stdout[i:i+size] for i in range(0,len(out.stdout),size)]
    return frames,headers

def features(rgb):
    yh=[0]*32;ch=[0]*64;mean=0;bright=0
    for r,g,b in zip(rgb[0::3],rgb[1::3],rgb[2::3]):
        y=(.2126*r+.7152*g+.0722*b)/255;mean+=y;bright+=max(r,g,b)>=254
        yh[min(31,int(y*32))]+=1;ch[(r//64)*16+(g//64)*4+b//64]+=1
    n=len(rgb)//3
    return yh,ch,mean/n,bright/n

def distances(a,b,fa,fb):
    n=len(a)//3
    hist=max(sum(abs(x-y) for x,y in zip(fa[0],fb[0])),sum(abs(x-y) for x,y in zip(fa[1],fb[1])))/(2*n)
    sad=sum(abs(x-y) for x,y in zip(a,b))/(255*len(a));return hist,sad

def reference_cuts(frames):
    # Independent reference math, not execution of Rust SceneAnalyzer.
    f=[features(x) for x in frames];cuts=[];flashes=[];previous_flash=False
    for i in range(1,len(frames)):
        hist,sad=distances(frames[i-1],frames[i],f[i-1],f[i]);large=hist>=.30 and sad>=.12
        flash=False
        if large and f[i][2]>.94 and f[i][3]>.8 and i+1<len(frames):
            dh,dp=distances(frames[i-1],frames[i+1],f[i-1],f[i+1]);flash=dh<.05 and dp<.08
        if flash:flashes.append(i)
        if large and not flash and not previous_flash:cuts.append(i)
        previous_flash=flash
    return cuts,flashes

def chain(meta,shots):
    v=m.vstream(meta);tb=F(v['time_base']);origin=e.exact_start(v)
    linear=any(s.get('ev',0)!=0 or s.get('wb',[1,1,1])!=[1,1,1] for s in shots)
    full=v.get('color_range')=='pc'
    out=[sub(template('COLOR_LINEAR_IN'),range='full' if full else 'limited') if linear else sub(template('COLOR_ENCODED_IN'),range='pc' if full else 'tv')]
    for s in shots:
        when=f"gte(round(t*{tb.denominator}/{tb.numerator}),{e.ceil((origin+F(s['start']))/tb)})*lt(round(t*{tb.denominator}/{tb.numerator}),{e.ceil((origin+F(s['end']))/tb)})"
        if linear and s.get('ev',0):out.append(sub(template('COLOR_EXPOSURE'),ev=f"{s['ev']:.6f}",when=when))
        if linear and s.get('wb',[1,1,1])!=[1,1,1]:out.append(sub(template('COLOR_BALANCE'),r=s['wb'][0],g=s['wb'][1],b=s['wb'][2],when=when))
    if linear:out.append(template('COLOR_LINEAR_OUT'))
    for s in shots:
        if any(s.get(k,1)!=1 for k in ['gamma','contrast','saturation']):
            when=f"gte(round(t*{tb.denominator}/{tb.numerator}),{e.ceil((origin+F(s['start']))/tb)})*lt(round(t*{tb.denominator}/{tb.numerator}),{e.ceil((origin+F(s['end']))/tb)})"
            out.append(sub(template('COLOR_TONE'),gamma=s.get('gamma',1),contrast=s.get('contrast',1),saturation=s.get('saturation',1),when=when))
    out.append(sub(template('COLOR_RANGE_OUT'),range='pc' if full else 'tv'))
    return ','.join(out)

def render(source,out,shots=(),ranges=None):
    before=hashlib.sha256(source.read_bytes()).hexdigest();meta=m.probe(source);v=m.vstream(meta);audio=m.streams(meta,'audio')
    ai=audio[0]['index'] if audio else None
    duration=e.exact_duration(v);ranges=ranges or [('0',str(duration))]
    graph,length,_=e.graph(meta,ranges,ai)
    if shots:graph=graph.replace(f"[0:{v['index']}]",f"[0:{v['index']}]"+chain(meta,shots)+',',1)
    args=[m.FFMPEG,*m.prefix('EDITED_PREFIX','edit_render.rs'),'-threads','2',*m.prefix('INPUT_POLICY','plan.rs'),'-i',str(source),
          '-filter_complex_threads','1','-filter_complex',graph,'-map','[vout]']
    args+=['-map','[aout]'] if ai is not None else ['-an']
    rate=F(v.get('r_frame_rate') or v['avg_frame_rate'])
    args+=['-c:v','libx264','-preset','medium','-crf','18','-pix_fmt','yuv420p','-threads:v','1',
           '-fps_mode:v','passthrough','-enc_time_base:v','1/1000000','-bsf:v',e.substitute(e.template('DURATION_BSF'),num=rate.numerator,den=rate.denominator),
           '-map_metadata','-1','-map_chapters','-1','-sn','-dn',*TAGS[:8],'-x264-params','videoformat=component']
    if v.get('color_range')=='pc':args+=['-color_range','pc']
    if ai is not None:args+=['-c:a','aac','-b:a','192k','-threads:a','1']
    args+=['-t',f'{float(length):.9f}','-metadata:s:v:0','rotate=0','-avoid_negative_ts','disabled','-movflags','+faststart','-y',str(out)]
    run(args);assert hashlib.sha256(source.read_bytes()).hexdigest()==before
    result=m.probe(out);ov=m.vstream(result)
    assert all(ov.get(k)=='bt709' for k in ['color_space','color_transfer','color_primaries'])
    assert ov.get('color_range')==v.get('color_range','tv')
    assert abs(float(e.exact_duration(ov)-length))<.08
    run([m.FFMPEG,'-v','error','-xerror','-i',str(out),'-f','null','-'])
    return out

def mean(rgb):return sum(rgb)/len(rgb)
def luma_range(rgb):
    values=[(.2126*r+.7152*g+.0722*b) for r,g,b in zip(rgb[0::3],rgb[1::3],rgb[2::3])]
    values.sort();return values[len(values)//10],values[len(values)*9//10]
def main():
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,required=True);parser.add_argument('--keep',type=Path);args=parser.parse_args()
    results=[]
    with tempfile.TemporaryDirectory(prefix='video-color-') as temp:
        w=args.keep or Path(temp);w.mkdir(parents=True,exist_ok=True)
        chart=frame(96,54);dark=encode(w/'dark.mp4',[chart]*60)
        bright=encode(w/'bright.mp4',[frame(96,54,'bright')]*60)
        def case(name,fn):
            start=time.monotonic()
            try:details=fn() or {};results.append(dict(name=name,status='passed',seconds=round(time.monotonic()-start,3),details=details));print('PASS',name,flush=True)
            except Exception as exc:results.append(dict(name=name,status='failed',error=str(exc)));print('FAIL',name,str(exc),flush=True)
            args.output.parent.mkdir(parents=True,exist_ok=True);args.output.write_text(json.dumps(dict(in_progress=True,cases=results),indent=2)+'\n')
        def full_scan():
            fs,hs=scan(dark);assert len(fs)==60 and hs[-1][1]+hs[-1][2]==2
            return dict(frames=len(fs),duration=str(hs[-1][1]+hs[-1][2]),protocol='actual named-showinfo/rawvideo')
        case('shared_full_rate_rgb_scan_exact_pts_and_tags',full_scan)
        def cuts():
            src=encode(w/'cuts.mp4',[chart]*15+[frame(96,54,'red')]*15+[frame(96,54,'blue')]*30)
            fs,_=scan(src);cs,fl=reference_cuts(fs);assert cs==[15,30] and not fl,(cs,fl)
        case('hard_cuts_detectable_at_decoded_frame_boundaries_reference_math',cuts)
        def single():
            src=encode(w/'one-frame.mp4',[chart]*20+[frame(96,54,'red')]+[chart]*39)
            cs,fl=reference_cuts(scan(src)[0]);assert cs==[20,21] and not fl,(cs,fl)
        case('one_frame_colored_shot_not_lost_to_downsampling',single)
        def flash():
            src=encode(w/'flash.mp4',[chart]*20+[frame(96,54,'flash')]+[chart]*39)
            cs,fl=reference_cuts(scan(src)[0]);assert cs==[] and fl==[20],(cs,fl)
        case('single_white_flash_excluded_from_reference_correction_stats',flash)
        def stable():assert reference_cuts(scan(dark)[0])==([],[])
        case('static_chart_has_no_false_shot_changes',stable)
        def vfr():
            src=encode(w/'vfr.mp4',[chart]*60,vf="select='not(eq(mod(n,5),1))'",extra=['-fps_mode:v','vfr'])
            fs,hs=scan(src);assert len(fs)==48
            assert all(abs(h[1]-t)<=F(1,1_000_000) for h,t in zip(hs,m.frames(src)))
        case('vfr_scan_keeps_every_original_pts',vfr)
        def fractional():
            src=encode(w/'fractional.mp4',[chart]*60,rate='30000/1001');fs,hs=scan(src)
            assert hs[-1][1]+hs[-1][2]==F(1001,500)
            out=render(src,w/'fractional-color.mp4',[dict(start=F(1*1001,30000),end=F(20*1001,30000),ev=.25)])
            assert len(m.frames(out))==60
        case('fractional_rate_color_predicates_preserve_frames',fractional)
        def rotate():
            src=encode(w/'ori.mp4',[frame(96,54,'orientation')]*30)
            rotated=w/'rotate.mp4';run([m.FFMPEG,'-v','error','-display_rotation','90','-i',src,'-c','copy','-y',rotated])
            fs,hs=scan(rotated,54,96);assert len(fs)==30
            p=fs[0];left=[p[(y*54+x)*3] for y in range(96) for x in range(27)];right=[p[(y*54+x)*3] for y in range(96) for x in range(27,54)]
            assert abs(statistics.mean(left)-statistics.mean(right))>70
        case('analysis_applies_display_rotation_to_actual_pixels',rotate)
        def exposure():
            out=render(dark,w/'exposure.mp4',[dict(start=0,end=2,ev=.25)])
            a,b=decode(dark)[15],decode(out)[15];assert mean(b)>mean(a)+4
            assert max(b)<254,(max(a),max(b));return dict(input_mean=mean(a),output_mean=mean(b),output_max=max(b))
        case('linear_light_exposure_lifts_chart_without_clipping',exposure)
        def darken():
            out=render(bright,w/'reduced.mp4',[dict(start=0,end=2,ev=-.25)])
            assert mean(decode(out)[20])<mean(decode(bright)[20])-8
        case('bounded_negative_exposure_reduces_bright_chart',darken)
        def gamma():
            out=render(dark,w/'gamma.mp4',[dict(start=0,end=2,gamma=1.04)])
            assert mean(decode(out)[20])>mean(decode(dark)[20])+1
        case('restrained_gamma_lifts_mids',gamma)
        def contrast():
            out=render(dark,w/'contrast.mp4',[dict(start=0,end=2,contrast=1.04)])
            lo,hi=luma_range(decode(dark)[20]);l2,h2=luma_range(decode(out)[20]);assert h2-l2>hi-lo+1
        case('restrained_contrast_increases_chart_span',contrast)
        def saturation():
            src=encode(w/'red.mp4',[frame(96,54,'red')]*60)
            out=render(src,w/'saturated.mp4',[dict(start=0,end=2,saturation=.90)])
            a,b=decode(src)[20],decode(out)[20];spread=lambda x:max(statistics.mean(x[i::3]) for i in range(3))-min(statistics.mean(x[i::3]) for i in range(3))
            assert spread(b)<spread(a)-3
        case('restrained_saturation_reduces_chroma',saturation)
        def white_balance():
            src=encode(w/'cast.mp4',[frame(96,54,'cast')]*60)
            out=render(src,w/'balanced.mp4',[dict(start=0,end=2,wb=[.96,1,1.04])])
            a,b=decode(src)[20],decode(out)[20];delta=lambda x:abs(statistics.mean(x[0::3])-statistics.mean(x[2::3]))
            assert delta(b)<delta(a)-1,(delta(a),delta(b))
        case('linear_channel_balance_reduces_known_neutral_cast',white_balance)
        def boundaries():
            out=render(dark,w/'shot-boundaries.mp4',[dict(start=F(1,30),end=F(20,30),ev=.25)])
            a,b=decode(dark),decode(out)
            ds=[mean(y)-mean(x) for x,y in zip(a,b)]
            assert abs(ds[0])<3 and ds[1]>4 and ds[19]>4 and abs(ds[20])<3,ds[:22]
        case('half_open_source_time_color_enable_is_frame_exact',boundaries)
        def constant():
            out=render(dark,w/'constant.mp4',[dict(start=0,end=2,ev=.25,gamma=1.03)])
            values=[mean(x) for x in decode(out)];assert max(values)-min(values)<.1
        case('shot_constant_correction_has_no_exposure_pumping',constant)
        def identity():
            a=render(dark,w/'identity-a.mp4');b=render(dark,w/'identity-b.mp4')
            assert decode(a)==decode(b)
        case('off_uses_unchanged_render_recipe',identity)
        def with_cuts():
            out=render(dark,w/'color-cut.mp4',[dict(start=1,end=2,ev=.25)],ranges=[('1/2','1'),('1','3/2')])
            fs=decode(out);assert len(fs)==30 and mean(fs[20])>mean(fs[5])+4
            assert abs(m.frequency(out)-440)<8
        case('source_time_correction_remains_aligned_after_cut_assembly',with_cuts)
        def offset():
            src=w/'offset.mp4';run([m.FFMPEG,'-v','error','-itsoffset','3600','-i',dark,'-c','copy','-y',src])
            fs,hs=scan(src);assert hs[0][1]==3600
            out=render(src,w/'offset-color.mp4',[dict(start=1,end=2,ev=.25)]);fs=decode(out)
            assert len(fs)==60 and mean(fs[45])>mean(fs[15])+4
        case('large_source_origin_does_not_shift_color_windows',offset)
        def sound():
            off=render(dark,w/'sound-off.mp4');on=render(dark,w/'sound-on.mp4',[dict(start=0,end=2,ev=.25)])
            assert m.pcm(off)==m.pcm(on)
        case('color_processing_does_not_modify_audio_samples',sound)
        def video_only():
            src=encode(w/'video-only.mp4',[chart]*30,audio=False);out=render(src,w/'video-only-color.mp4',[dict(start=0,end=1,ev=.25)])
            assert not m.streams(m.probe(out),'audio')
        case('video_only_correction',video_only)
        def sar():
            src=encode(w/'sar.mp4',[chart]*30,vf='setsar=4/3')
            out=render(src,w/'sar-color.mp4',[dict(start=0,end=1,gamma=1.02)])
            assert F(m.vstream(m.probe(out))['sample_aspect_ratio'].replace(':','/'))==F(4,3)
        case('render_preserves_non_square_pixel_aspect',sar)
        def full():
            src=encode(w/'full.mp4',[chart]*30,vf='scale=in_range=tv:out_range=pc',extra=['-color_range','pc'])
            fs,hs=scan(src);assert len(fs)==30
            out=render(src,w/'full-color.mp4',[dict(start=0,end=1,ev=.25)])
            assert m.vstream(m.probe(out))['color_range']=='pc'
            assert mean(decode(out)[10])>mean(decode(src)[10])+4
        case('full_range_color_path_is_not_reinterpreted_as_limited',full)
        def corrupt():
            bad=w/'broken.mp4';bad.write_bytes(b'not media');p=subprocess.run([m.FFMPEG,'-v','error','-xerror','-i',str(bad),'-f','null','-'],capture_output=True,timeout=10);assert p.returncode!=0
        case('corrupt_input_fails_media_decode',corrupt)
        def hdr():
            src=w/'hdr10.mkv';run([m.FFMPEG,'-v','error','-f','lavfi','-i','testsrc2=s=64x48:r=10:d=1','-pix_fmt','yuv420p10le','-c:v','libx265','-threads','1','-x265-params','pools=1:frame-threads=1:log-level=error:colorprim=bt2020:transfer=smpte2084:colormatrix=bt2020nc:master-display=G(13250,34500)B(7500,3000)R(34000,16000)WP(15635,16450)L(10000000,1):max-cll=1000,400','-y',src])
            v=m.vstream(m.probe(src));assert v['color_transfer']=='smpte2084' and v['pix_fmt']=='yuv420p10le'
            return dict(pixel_format=v['pix_fmt'],transfer=v['color_transfer'],rust_guard='separate Cargo negative test; not executed here')
        case('actual_HDR10_fixture_carries_non_SDR_metadata',hdr)
        def hlg():
            src=w/'hlg.mkv';run([m.FFMPEG,'-v','error','-f','lavfi','-i','testsrc2=s=64x48:r=10:d=1','-pix_fmt','yuv420p10le','-c:v','libx265','-threads','1','-x265-params','pools=1:frame-threads=1:log-level=error:colorprim=bt2020:transfer=arib-std-b67:colormatrix=bt2020nc','-y',src]);assert m.vstream(m.probe(src))['color_transfer']=='arib-std-b67'
        case('actual_HLG_fixture_carries_non_SDR_metadata',hlg)
        def interlace():
            src=encode(w/'interlace.mp4',[frame(96,56)]*30,h=56,vf='setfield=tff',extra=['-flags','+ilme+ildct','-x264-params','tff=1:videoformat=component:colorprim=bt709:transfer=bt709:colormatrix=bt709'])
            assert m.vstream(m.probe(src))['field_order']!='progressive'
        case('interlaced_input_is_detectable_not_silently_deinterlaced',interlace)
        def caps():
            raw=run([m.FFMPEG,'-v','error','-filters']).stdout.decode()
            for name in ['zscale','colorchannelmixer','exposure','eq','showinfo']:assert re.search(r'\s'+name+r'\s',raw),name
        case('required_filters_present_in_test_runtime',caps)
        def adjacent():
            out=render(dark,w/'adjacent.mp4',[dict(start=0,end=1,ev=.25),dict(start=1,end=2,ev=-.25)])
            base=decode(dark);actual=decode(out)
            assert mean(actual[29])>mean(base[29])+4
            assert mean(actual[30])<mean(base[30])-4
            assert len(actual)==60
        case('adjacent_shot_adjustments_reset_without_blending_across_cut',adjacent)
        def chroma():
            # These colors have almost equal Rec.709 luma; RGB distribution must
            # still expose the cut. This is reference signal math, not Rust.
            a=bytes([180,20,20])* (96*54);b=bytes([20,67,20])* (96*54)
            source=encode(w/'same-luma.mp4',[a]*30+[b]*30)
            cs,fl=reference_cuts(scan(source)[0]);assert cs==[30] and not fl,(cs,fl)
        case('similar_luma_chroma_cut_remains_observable',chroma)
        def tenbit():
            out=w/'sdr10.mkv'
            run([m.FFMPEG,'-v','error','-f','lavfi','-i','testsrc2=s=64x48:r=10:d=1','-pix_fmt','yuv420p10le','-c:v','libx265','-threads','1','-x265-params','pools=1:frame-threads=1:log-level=error:colorprim=bt709:transfer=bt709:colormatrix=bt709','-y',out])
            v=m.vstream(m.probe(out));assert v['color_transfer']=='bt709' and v['pix_fmt']=='yuv420p10le'
            return dict(note='10-bit SDR is deliberately not qualified by the Rust guard; guard tests supplied separately')
        case('10bit_SDR_fixture_is_not_confused_with_8bit_support',tenbit)
        def tiny():
            source=encode(w/'tiny.mp4',[frame(8,8)]*180,w=8,h=8,audio=False)
            frames,headers=scan(source,8,8)
            assert len(frames)==180 and headers[-1][1]+headers[-1][2]==6
        case('tiny_frames_flush_without_temporal_downsampling',tiny)
        report=dict(step=6,scope='Independent FFmpeg recipes and Python reference signal checks; no Rust execution or host UI test',runtime=run([m.FFMPEG,'-version']).stdout.decode().splitlines()[0],python=sys.version.split()[0],passed=sum(x['status']=='passed' for x in results),failed=sum(x['status']=='failed' for x in results),cases=results)
        args.output.parent.mkdir(parents=True,exist_ok=True);args.output.write_text(json.dumps(report,indent=2)+'\n')
        return 0 if report['failed']==0 else 1
if __name__=='__main__':raise SystemExit(main())
