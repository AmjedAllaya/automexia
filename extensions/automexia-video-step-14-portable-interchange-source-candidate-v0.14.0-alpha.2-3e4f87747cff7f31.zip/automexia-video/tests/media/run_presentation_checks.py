#!/usr/bin/env python3
"""Independent media-recipe checks, NOT execution of the Rust crate/rasterizer.

The exact COMPOSITE_GRAPH, GRAPHICS_INPUT and edit filter literals are read from
Rust. Pillow creates explicit test-only RGBA frames. Tests exercise encoded media,
not native asset authorizations, Rust subtitle parsing or host UI integration.
No font file is copied into the package. --keep retains generated media only.
"""
from __future__ import annotations
import argparse, hashlib, io, json, math, os, subprocess, tempfile, time
from fractions import Fraction as F
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
import run_media_checks as m
import run_edit_checks as e
import run_color_checks as c
import run_reframe_checks as rf

PRESENTATION=m.ROOT/'src/presentation_render.rs'
FONT=Path(os.environ.get('VIDEO_TEST_FONT','/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'))

def nearest(x):
    x=F(x);return (x.numerator+x.denominator//2)//x.denominator if x>=0 else -nearest(-x)
def times(meta,ranges,audio):
    graph,length,parts=e.graph(meta,ranges,audio)
    origin=nearest(e.exact_start(m.vstream(meta))*1_000_000)
    return graph,length,[(F(s['input_start']-origin,1_000_000),F(s['output'],1_000_000),F(parts[i+1]['output'],1_000_000) if i+1<len(parts) else length) for i,s in enumerate(parts)]
def map_events(events,segments):
    result=[]
    for ev in events:
        for ss,oo,oe in segments:
            a=max(F(ev['start']),ss);b=min(F(ev['end']),ss+oe-oo)
            if a<b:result.append({**ev,'original_end':F(ev['end']),'start':oo+a-ss,'end':oo+b-ss,'source_start':a,'origin':F(ev['start'])})
    return result

def transfer(image):
    table=[]
    for n in range(256):
        x=n/255;v=x/12.92 if x<=.04045 else ((x+.055)/1.055)**2.4
        y=4.5*v if v<.018 else 1.099*v**.45-.099;table.append(round(max(0,min(1,y))*255))
    a=image.getchannel('A');rgb=image.convert('RGB').point(table*3).convert('RGBA');rgb.putalpha(a);return rgb

def sequence(path,size,duration,events,animation_rate=60,encoded_size=None):
    path.mkdir(parents=True,exist_ok=True);end=e.ceil(F(duration)*1_000_000);clock={0,end}
    for ev in events:
        start=max(0,nearest(F(ev['start'])*1_000_000));finish=min(end,nearest(F(ev['end'])*1_000_000))
        if start>=finish:continue
        clock.update([start,finish])
        if ev.get('fade') or ev.get('fade_out') or ev.get('slide') or ev.get('zoom'):
            clock.update(n*1_000_000//animation_rate for n in range(e.ceil(F(start*animation_rate,1_000_000)),e.ceil(F(finish*animation_rate,1_000_000))))
    clock=sorted(clock);script=['ffconcat version 1.0'];written=set()
    for i,t in enumerate(clock):
        canvas=Image.new('RGBA',size,(0,0,0,0))
        for ev in events:
            if t<nearest(F(ev['start'])*1_000_000) or t>=nearest(F(ev['end'])*1_000_000):continue
            elapsed=F(ev['source_start'])+F(t,1_000_000)-F(ev['start'])-F(ev['origin'])
            patch=ev.get('image') or Image.new('RGBA',ev.get('size',(32,18)),ev.get('color',(255,255,255,255)))
            patch=patch.copy();opacity=ev.get('opacity',1.0)
            if ev.get('fade'):opacity*=min(1,max(0,float(elapsed)/ev['fade']))
            if ev.get('fade_out'):opacity*=min(1,max(0,(float(ev['original_end']-ev['origin'])-float(elapsed))/ev['fade_out']))
            if ev.get('zoom'):
                k=1+ev['zoom']*min(1,max(0,float(elapsed)/ev.get('motion_duration',1)))
                patch=patch.resize((round(patch.width*k),round(patch.height*k)),Image.Resampling.LANCZOS)
            patch.putalpha(patch.getchannel('A').point(lambda a:round(a*opacity)))
            x,y=ev.get('xy',(0,0))
            if ev.get('slide'):x+=round(ev['slide']*min(1,max(0,float(elapsed)/ev.get('motion_duration',1))))
            canvas.alpha_composite(patch,(x,y))
        if encoded_size and encoded_size!=size:canvas=canvas.resize(encoded_size,Image.Resampling.LANCZOS)
        canvas=transfer(canvas)
        name='frame-'+hashlib.sha256(canvas.tobytes()).hexdigest()+'.png'
        if name not in written:canvas.save(path/name);written.add(name)
        delta=clock[i+1]-t if i+1<len(clock) else 1
        script.extend([f"file '{name}'",'option framerate 1000000',f'duration {delta//1_000_000}.{delta%1_000_000:06d}'])
    manifest=path/'overlay.ffconcat';manifest.write_text('\n'.join(script)+'\n');return manifest

def render(source,out,events,*,ranges=None,audio='auto',cfr=None,framing=None,proxy=None,fade_in=None,volume=None,lossless=True):
    old=hashlib.sha256(source.read_bytes()).hexdigest();meta=m.probe(source);v=m.vstream(meta);audio_streams=m.streams(meta,'audio')
    ai=(audio_streams[0]['index'] if audio_streams else None) if audio=='auto' else audio
    ranges=ranges or [('0',str(e.exact_duration(v)))];graph,duration,segments=times(meta,ranges,ai)
    rotation=next((int(x.get('rotation',0))%360 for x in v.get('side_data_list',[]) if 'rotation'in x),0)
    size=(v['height'],v['width']) if rotation in [90,270] else (v['width'],v['height'])
    sar=F(v.get('sample_aspect_ratio','1:1').replace(':','/'))
    if rotation in [90,270]:sar=1/sar
    if framing:
        target,options=framing;chain=rf.framing(meta,target,**options);size=target;sar=F(1)
        graph=graph.replace(',settb=expr=1/1000000',','+chain+',settb=expr=1/1000000',1)
    if fade_in:
        origin=e.exact_start(v);f=f'setpts=PTS-({origin})/TB,fade=t=in:st=0:d={fade_in},setpts=PTS+({origin})/TB'
        graph=graph.replace(',settb=expr=1/1000000',','+f+',settb=expr=1/1000000',1)
    if volume is not None:
        clock='0'
        for ss,oo,oe in reversed(segments):clock=f'if(lt(t,{float(oe):.9f}),t+({float(ss-oo):.9f}),{clock})'
        gain=volume(clock);graph=graph.replace('[aout]',f",volume='{gain}':eval=frame:precision=double[aout]",1)
    mapped=map_events(events,segments);display=(int((nearest(F(size[0])*sar)+1)//2*2),size[1]);manifest=sequence(out.parent/(out.stem+'-sequence'),display,duration,mapped,encoded_size=size)
    template=c.template('COMPOSITE_GRAPH',PRESENTATION).replace('{range}','pc' if v.get('color_range')=='pc' else 'tv').replace('{sar}',str(sar))
    graph=graph.replace('[vout]','[pres_base]',1)+';'+template
    if proxy:
        graph=graph.replace('[vout]','[vproxy]',1)+f';[vproxy]scale=w={proxy[0]}:h={proxy[1]}:flags=bilinear,setsar=1[vout]';size=proxy;sar=F(1)
    args=[m.FFMPEG,*m.prefix('EDITED_PREFIX','edit_render.rs'),'-threads','2',*m.prefix('INPUT_POLICY','plan.rs'),'-i',source,*m.prefix('GRAPHICS_INPUT','presentation_render.rs'),manifest,
          '-filter_complex_threads','1','-filter_complex',graph,'-map','[vout]']
    args+=['-map','[aout]'] if ai is not None else ['-an']
    args+=['-map_metadata','-1','-map_chapters','-1','-sn','-dn','-c:v','libx264','-preset','medium','-crf','0' if lossless else '18','-threads:v','1','-pix_fmt','yuv420p']
    rate=F(v.get('r_frame_rate') or v['avg_frame_rate'])
    if cfr:args+=['-fps_mode:v','cfr','-r:v',str(cfr),'-enc_time_base:v',str(1/F(cfr))]
    else:args+=['-fps_mode:v','passthrough','-enc_time_base:v','1/1000000','-bsf:v',e.substitute(e.template('DURATION_BSF'),num=rate.numerator,den=rate.denominator)]
    args+=['-colorspace','bt709','-color_trc','bt709','-color_primaries','bt709','-color_range','pc' if v.get('color_range')=='pc' else 'tv','-x264-params','videoformat=component']
    if ai is not None:args+=['-c:a','aac','-b:a','192k','-threads:a','1']
    args+=['-t',f'{float(duration):.9f}','-metadata:s:v:0','rotate=0','-avoid_negative_ts','disabled','-movflags','+faststart','-progress','pipe:1','-nostats','-f','mp4',out]
    log=m.execute(args,timeout=90);assert b'progress=end'in log
    assert hashlib.sha256(source.read_bytes()).hexdigest()==old
    d=m.probe(out);ov=m.vstream(d);assert (ov['width'],ov['height'])==size
    assert F(ov.get('sample_aspect_ratio','1:1').replace(':','/'))==sar
    assert abs(float(e.exact_duration(ov)-duration))<.06
    assert bool(m.streams(d,'audio'))==(ai is not None)
    if ai is not None:
        sa=next(a for a in audio_streams if a['index']==ai);oa=m.streams(d,'audio')[0]
        assert (sa['channels'],sa['sample_rate'])==(oa['channels'],oa['sample_rate'])
    m.execute([m.FFMPEG,'-v','error','-xerror','-i',out,'-f','null','-'])
    return out

def pixel(frame,w,x,y):return tuple(frame[(y*w+x)*3:(y*w+x)*3+3])
def rms(a):return math.sqrt(sum(x*x for x in a)/len(a))
def text_image(text,light=True):
    if not FONT.is_file():raise RuntimeError('Selected test font missing; font test is not skipped')
    im=Image.new('RGBA',(140,42),(0,0,0,200) if light else (255,255,255,220));d=ImageDraw.Draw(im);font=ImageFont.truetype(str(FONT),15)
    d.multiline_text((6,3),text,fill=(255,255,255,255) if light else (0,0,0,255),font=font,spacing=2);return im

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,required=True);ap.add_argument('--keep',type=Path);opts=ap.parse_args();results=[];start=time.monotonic()
    with tempfile.TemporaryDirectory(prefix='video-step8-media-') as tmp:
        w=opts.keep or Path(tmp);w.mkdir(parents=True,exist_ok=True)
        source=c.encode(w/'source.mp4',[c.frame(160,96,'gray',60)]*120,w=160,h=96)
        def case(name,fn):
            t=time.monotonic()
            try:detail=fn() or {};results.append(dict(name=name,status='passed',seconds=round(time.monotonic()-t,3),details=detail));print('PASS',name,flush=True)
            except Exception as ex:results.append(dict(name=name,status='failed',error=str(ex)));print('FAIL',name,str(ex),flush=True)
        def ev(a='0',b='4',**kw):return dict(start=F(a),end=F(b),**kw)
        def basic():
            out=render(source,w/'transparent.mp4',[]);assert len(m.frames(out))==120
            a,b=c.decode(source),c.decode(out);assert max(abs(x-y) for x,y in zip(a[1],b[1]))<=3
            return {'frames':120}
        case('transparent_sequence_does_not_extend_video',basic)
        def boundary():
            out=render(source,w/'boundary.mp4',[ev('1/2','1',color=(255,0,0,255),size=(32,18))]);frames=c.decode(out)
            assert pixel(frames[14],160,8,8)[0]<100;assert pixel(frames[15],160,8,8)[0]>245;assert pixel(frames[29],160,8,8)[0]>245;assert pixel(frames[30],160,8,8)[0]<100
        case('opaque_overlay_half_open_edges',boundary)
        def alpha():
            out=render(source,w/'alpha.mp4',[ev(color=(255,255,255,128))]);p=pixel(c.decode(out)[0],160,8,8);assert all(146<=v<=161 for v in p),p;return {'rgb':p}
        case('straight_alpha_compositing_real_pixels',alpha)
        def hidden():
            out=render(source,w/'hidden.mp4',[ev(color=(255,0,255,0))]);a,b=c.decode(source)[0],c.decode(out)[0];assert max(abs(x-y) for x,y in zip(a,b))<=3
        case('hidden_rgb_with_zero_alpha_is_invisible',hidden)
        def order():
            out=render(source,w/'order.mp4',[ev(color=(255,0,0,255)),ev(color=(0,255,0,255),size=(16,10))]);f=c.decode(out)[0];assert pixel(f,160,8,4)[1]>245;assert pixel(f,160,24,14)[0]>245
        case('explicit_layer_order_is_stable',order)
        for color in [(255,255,255,255),(0,0,0,255),(255,0,0,255),(0,255,0,255),(0,0,255,255)]:
            def chroma(color=color):
                out=render(source,w/f'color-{color[0]}-{color[1]}-{color[2]}.mp4',[ev(color=color)]);p=pixel(c.decode(out)[0],160,8,8);assert max(abs(x-y) for x,y in zip(p,color[:3]))<5,p
            case('overlay_primary_'+str(color[:3]),chroma)
        for name,xy in [('top_left',(0,0)),('top_right',(128,0)),('bottom_left',(0,78)),('bottom_right',(128,78))]:
            def anchor(xy=xy,name=name):
                out=render(source,w/(name+'.mp4'),[ev(xy=xy,color=(255,0,0,255))]);p=pixel(c.decode(out)[0],160,xy[0]+8,xy[1]+8);assert p[0]>245,p
            case('anchor_'+name,anchor)
        for name,text in [('unicode','Café déjà vu'),('multiline','First line\nSecond line'),('literal',"%{pts} ; $HOME")]:
            def caption(text=text,name=name):
                image=text_image(text);out=render(source,w/(name+'.mp4'),[ev('1','2',image=image,xy=(10,48))]);f=c.decode(out)[30];assert max(f)>240;assert len(m.frames(out))==120
            case('caption_'+name,caption)
        def caption_colors():
            image=text_image('Dark title',False);out=render(source,w/'dark.mp4',[ev(image=image,xy=(10,48))]);f=c.decode(out)[30];assert min(f)<15 and max(f)>215
        case('dark_variant_plate_and_glyphs',caption_colors)
        def remap():
            out=render(source,w/'cut-caption.mp4',[ev('1/2','5/2',color=(255,0,0,255))],ranges=[('0','1'),('2','3')]);f=c.decode(out);assert len(f)==60
            assert pixel(f[14],160,8,8)[0]<100;assert pixel(f[15],160,8,8)[0]>240;assert pixel(f[44],160,8,8)[0]>240;assert pixel(f[45],160,8,8)[0]<100
        case('caption_spanning_cut_uses_retained_timing',remap)
        def removed():
            out=render(source,w/'removed-caption.mp4',[ev('1','2',color=(255,0,0,255))],ranges=[('0','1'),('2','3')]);assert all(pixel(f,160,8,8)[0]<100 for f in c.decode(out))
        case('wholly_deleted_caption_does_not_reappear',removed)
        def one_frame(rate='30',n=1):
            src=source if rate=='30' else c.encode(w/'fractional.mp4',[c.frame(160,96,'gray',60)]*60,w=160,h=96,rate=rate)
            a=F(n)/F(rate);b=F(n+1)/F(rate);out=render(src,w/f'one-frame-{n}.mp4',[ev(a,b,color=(255,0,0,255))]);found=[i for i,f in enumerate(c.decode(out)) if pixel(f,160,8,8)[0]>240];assert found==[n],found;return {'visible_frame':found}
        case('one_frame_graphic_at_1_over_30',one_frame)
        case('one_frame_graphic_at_fractional_pts',lambda:one_frame('30000/1001',7))
        def fade():
            out=render(source,w/'fade.mp4',[ev('0','2',fade=1,color=(255,255,255,255))]);f=c.decode(out)
            p0,p1,p2=[pixel(f[i],160,8,8)[0] for i in [0,15,30]];assert p0<70 and 130<p1<180 and p2>248,(p0,p1,p2)
        case('title_fade_does_not_retime_video',fade)
        def excerpt():
            out=render(source,w/'excerpt.mp4',[ev('0','2',fade=1,color=(255,255,255,255))],ranges=[('4/5','6/5')]);p=pixel(c.decode(out)[0],160,8,8);assert p[0]>200,p
        case('preview_excerpt_does_not_restart_title_fade',excerpt)
        def slide():
            out=render(source,w/'slide.mp4',[ev('0','2',slide=60,color=(255,0,0,255))]);f=c.decode(out);assert pixel(f[0],160,8,8)[0]>245;assert pixel(f[30],160,68,8)[0]>245;assert pixel(f[30],160,8,8)[0]<100
        case('title_slide_changes_position_not_duration',slide)
        def zoom():
            out=render(source,w/'overlay-zoom.mp4',[ev('0','2',zoom=1,color=(255,0,0,255))]);f=c.decode(out);assert pixel(f[0],160,48,10)[0]<100;assert pixel(f[30],160,48,10)[0]>245
        case('explicit_overlay_scale_animation',zoom)
        def portrait():
            src=w/'rotated.mov';m.execute([m.FFMPEG,'-v','error','-y','-display_rotation','90','-i',source,'-c','copy',src]);out=render(src,w/'rotated-overlay.mp4',[ev(color=(255,0,0,255))]);assert (m.vstream(m.probe(out))['width'],m.vstream(m.probe(out))['height'])==(96,160)
            assert pixel(c.decode(out)[0],96,8,8)[0]>245
        case('rotation_happens_before_graphics',portrait)
        for target in [(96,160),(96,96),(120,150)]:
            def target_render(target=target):
                out=render(source,w/f'target-{target[0]}-{target[1]}.mp4',[ev(color=(255,0,0,255))],framing=(target,{'mode':'fit'}));assert pixel(c.decode(out)[0],target[0],8,8)[0]>245
            case('variant_canvas_'+str(target),target_render)
        def non_square():
            src=w/'sar.mp4';m.execute([m.FFMPEG,'-v','error','-y','-i',source,'-vf','setsar=2','-c:v','libx264','-threads:v','1','-c:a','copy',*c.TAGS,src]);out=render(src,w/'sar-overlay.mp4',[ev(color=(255,0,0,255))]);assert F(m.vstream(m.probe(out))['sample_aspect_ratio'].replace(':','/'))==2
        case('non_square_source_sar_survives_composite',non_square)
        def variable():
            src=w/'vfr.mp4';m.execute([m.FFMPEG,'-v','error','-y','-i',source,'-vf',"select='not(eq(mod(n,5),1))'",'-fps_mode','vfr','-c:v','libx264','-threads:v','1','-c:a','copy',*c.TAGS,src]);out=render(src,w/'vfr-overlay.mp4',[ev('1','2',color=(255,0,0,255))]);a,b=m.frames(src),m.frames(out);assert len(a)==len(b);assert max(abs(float(x-y)) for x,y in zip(a,b))<.000003
        case('vfr_frame_times_are_not_replaced_by_overlay_rate',variable)
        def cfr():
            out=render(source,w/'cfr.mp4',[ev('1','2')],cfr='24');assert F(m.vstream(m.probe(out))['avg_frame_rate'])==24 and len(m.frames(out))==96
        case('explicit_cfr_output_works_with_sparse_graphics',cfr)
        def large_origin():
            src=w/'offset.mp4';m.execute([m.FFMPEG,'-v','error','-y','-i',source,'-c','copy','-output_ts_offset','3600',src]);out=render(src,w/'offset-graphics.mp4',[ev('1','2',color=(255,0,0,255))]);f=c.decode(out);assert pixel(f[29],160,8,8)[0]<100;assert pixel(f[30],160,8,8)[0]>240
        case('large_source_pts_does_not_shift_graphic_events',large_origin)
        def no_audio():
            src=w/'silent.mp4';m.execute([m.FFMPEG,'-v','error','-y','-i',source,'-map','0:v:0','-c','copy',src]);out=render(src,w/'silent-graphics.mp4',[ev()]);assert not m.streams(m.probe(out),'audio')
        case('graphics_on_video_only_source',no_audio)
        def second_audio():
            src=w/'two-audio.mp4';m.execute([m.FFMPEG,'-v','error','-y','-i',source,'-f','lavfi','-i','sine=frequency=880:sample_rate=48000:duration=4','-map','0:v:0','-map','0:a:0','-map','1:a:0','-c:v','copy','-c:a','aac','-threads:a','1',src]);out=render(src,w/'second-audio-graphics.mp4',[ev()],audio=2);assert 870<=m.frequency(out)<=890
        case('explicit_second_audio_stream_survives_graphics',second_audio)
        def audio_same():
            a=render(source,w/'audio-before.mp4',[]);b=render(source,w/'audio-after.mp4',[ev()]);assert m.pcm(a)==m.pcm(b)
        case('graphics_do_not_modify_audio_samples',audio_same)
        def volume():
            out=render(source,w/'volume.mp4',[],ranges=[('0','1'),('2','4')],volume=lambda t:f'if(lt({t},2),1,0.25)');pcm=m.pcm(out);a=rms(pcm[12000:36000]);b=rms(pcm[72000:96000]);assert .22<b/a<.28,b/a;return {'ratio':b/a}
        case('volume_keys_follow_source_time_after_cut',volume)
        def scene_fade():
            out=render(source,w/'video-fade.mp4',[],fade_in=1);f=c.decode(out);assert max(pixel(f[0],160,60,40))<5;assert pixel(f[30],160,60,40)[0]>50
        case('video_fade_is_explicit_and_keeps_timing',scene_fade)
        def scene_excerpt():
            out=render(source,w/'video-fade-excerpt.mp4',[],ranges=[('1','2')],fade_in=1);assert pixel(c.decode(out)[0],160,60,40)[0]>50
        case('video_fade_does_not_restart_at_preview_start',scene_excerpt)
        def preview():
            out=render(source,w/'proxy.mp4',[ev('1','2',color=(255,0,0,255))],ranges=[('1','2')],proxy=(80,48));assert pixel(c.decode(out)[0],80,4,4)[0]>240;assert len(m.frames(out))==30
        case('preview_scales_composed_pixels_after_graphics',preview)
        def hostile_path():
            src=w/"a '; $(printf bad) [x].mp4";src.write_bytes(source.read_bytes());out=render(src,w/'path-result.mp4',[ev()]);assert out.is_file()
        case('selected_filename_is_argv_not_shell_or_concat_text',hostile_path)
        def sidecar(fmt):
            path=w/f'captions.{fmt}';text='1\n00:00:00,500 --> 00:00:01,000\nCafé &amp; B\n\n2\n00:00:01,000 --> 00:00:01,500\nSecond\n\n'
            if fmt=='vtt':text='WEBVTT\n\n'+text.replace(',','.')
            path.write_text(text);data=json.loads(m.execute([m.FFPROBE,'-v','error','-show_packets','-of','json',path]));assert len(data['packets'])==2;assert abs(float(data['packets'][0]['pts_time'])-.5)<.001
        case('SRT_sidecar_actual_demux_timing',lambda:sidecar('srt'))
        case('WebVTT_sidecar_actual_demux_timing',lambda:sidecar('vtt'))
        def bad_sequence(kind):
            d=w/('bad-'+kind);d.mkdir();manifest=d/'bad.ffconcat'
            if kind=='missing':manifest.write_text("ffconcat version 1.0\nfile 'absent.png'\n")
            elif kind=='truncated':(d/'bad.png').write_bytes(b'\x89PNG\r\n\x1a\n');manifest.write_text("ffconcat version 1.0\nfile 'bad.png'\n")
            else:manifest.write_text("ffconcat version 1.0\nfile 'https://127.0.0.1:1/not-authorized.png'\n")
            p=subprocess.run([str(m.FFMPEG),'-v','error',*m.prefix('GRAPHICS_INPUT','presentation_render.rs'),str(manifest),'-f','null','-'],stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=10);assert p.returncode!=0
        for k in ['missing','truncated','network']:case('invalid_overlay_sequence_'+k,lambda k=k:bad_sequence(k))
        def cancellation():
            p=subprocess.Popen([str(m.FFMPEG),'-v','error','-re','-i',str(source),'-f','null','-'],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
            time.sleep(.15);p.terminate();p.communicate(timeout=5);assert p.returncode!=0
        case('media_child_can_be_terminated',cancellation)

        def title_out():
            out=render(source,w/'fade-out.mp4',[ev('0','2',color=(255,255,255,255),fade_out=1)]);f=c.decode(out)
            assert pixel(f[30],160,8,8)[0]>245;assert 135<pixel(f[45],160,8,8)[0]<180;assert pixel(f[60],160,8,8)[0]<70
        case('title_fade_out_ends_at_half_open_boundary',title_out)
        def out_excerpt():
            out=render(source,w/'fade-out-excerpt.mp4',[ev('0','2',color=(255,255,255,255),fade_out=1)],ranges=[('3/2','2')]);value=pixel(c.decode(out)[0],160,8,8)[0];assert 135<value<180,value
        case('fade_out_preview_retains_source_phase',out_excerpt)
        def layer_dissolve():
            out=render(source,w/'layer-dissolve.mp4',[ev('0','2',color=(255,0,0,255)),ev('1','4',color=(0,0,255,255),fade=1)]);f=c.decode(out);a=pixel(f[30],160,8,8);b=pixel(f[45],160,8,8);end=pixel(f[60],160,8,8)
            assert a[0]>245 and a[2]<5;assert 108<b[0]<119 and 108<b[2]<119 and b[1]<3,b;assert end[2]>245 and end[0]<5
        # Midpoint is composited in sRGB, then transfer-converted to Rec.709 (~113), not code value 128.
        case('explicit_graphic_to_graphic_dissolve_no_background_leak',layer_dissolve)
        def full_range():
            src=w/'full-range.mp4';m.execute([m.FFMPEG,'-v','error','-y','-i',source,'-vf','scale=in_range=tv:out_range=pc','-c:v','libx264','-threads:v','1','-c:a','copy','-color_range','pc','-colorspace','bt709','-color_trc','bt709','-color_primaries','bt709',src]);out=render(src,w/'full-range-graphics.mp4',[ev(color=(255,255,255,255))]);assert m.vstream(m.probe(out))['color_range']=='pc';assert pixel(c.decode(out)[0],160,8,8)[0]>248
        case('full_range_composition_does_not_silently_become_limited',full_range)
        def anamorphic_geometry():
            src=w/'sar.mp4';out=render(src,w/'sar-geometry.mp4',[ev(color=(255,0,0,255),size=(32,18))]);f=c.decode(out)[0];assert pixel(f,160,8,8)[0]>240;assert pixel(f,160,20,8)[0]<100
            return {'display_box_width':32,'encoded_box_width':16,'sar':'2:1'}
        case('graphics_use_square_display_space_on_anamorphic_video',anamorphic_geometry)
        def av_sync():
            src=w/'flash-tone.mp4';vf="color=black:size=160x96:rate=30:duration=4,drawbox=x=0:y=0:w=iw:h=ih:color=white:t=fill:enable='between(t,0.5,0.56)+between(t,2.5,2.56)'"
            af=r"aevalsrc=0.4*sin(2*PI*1000*t)*(between(t\,0.5\,0.56)+between(t\,2.5\,2.56)):s=48000:d=4"
            m.execute([m.FFMPEG,'-v','error','-y','-f','lavfi','-i',vf,'-f','lavfi','-i',af,'-c:v','libx264','-threads:v','1','-c:a','aac','-threads:a','1','-pix_fmt','yuv420p',*c.TAGS,src])
            out=render(src,w/'graphics-av-sync.mp4',[ev('0','4',size=(32,18),color=(255,0,0,255))],ranges=[('0','1'),('2','3')]);frames=c.decode(out);pts=m.frames(out);flashes=[float(t) for t,f in zip(pts,frames) if pixel(f,160,100,70)[0]>180];pcm=m.pcm(out);onsets=[]
            for i in range(0,len(pcm)-480,480):
                if sum(abs(x) for x in pcm[i:i+480])/480>1000 and (not onsets or i/48000-onsets[-1]>.15):onsets.append(i/48000)
            errors=[min(abs(a-v) for v in flashes) for a in onsets];assert len(onsets)==2 and max(errors)<.035,errors
            return {'maximum_av_error_seconds':max(errors)}
        case('decoded_flash_tone_sync_survives_graphics_and_cuts',av_sync)
        def phase_match():
            events=[ev('0','2',fade=1,color=(255,255,255,255))];whole=render(source,w/'whole-phase.mp4',events);part=render(source,w/'part-phase.mp4',events,ranges=[('4/5','6/5')]);assert c.decode(whole)[24]==c.decode(part)[0]
        case('lossless_same_source_frame_matches_preview_animation',phase_match)
        if opts.keep:
            (w/'SAMPLES.txt').write_text('Generated synthetic media. Pillow test rasterization; not Rust/resvg output. No font files copied.\n')
    report={'suite':'step8-presentation-media','scope':'Independent FFmpeg recipe and decoded-pixel tests; Rust code, Rust asset parser, resvg and native integration NOT executed','ffmpeg':m.execute([m.FFMPEG,'-version']).decode().splitlines()[0],'python':__import__('sys').version,'seconds':round(time.monotonic()-start,3),'passed':sum(r['status']=='passed' for r in results),'failed':sum(r['status']=='failed' for r in results),'results':results}
    opts.output.parent.mkdir(parents=True,exist_ok=True);opts.output.write_text(json.dumps(report,indent=2)+'\n');print('RESULT',report['passed'],report['failed']);return int(report['failed']!=0)
if __name__=='__main__':raise SystemExit(main())
