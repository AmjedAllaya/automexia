#!/usr/bin/env python3
import array, argparse, hashlib, json, math, os, pathlib, re, subprocess, tempfile, wave

def run(cmd):
    p=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
    if p.returncode: raise RuntimeError(p.stderr[-4000:])
    return p.stdout

def sha(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for b in iter(lambda:f.read(1<<20),b''): h.update(b)
    return h.hexdigest()

def probe(ffprobe,path):
    return json.loads(run([ffprobe,'-v','error','-show_streams','-show_format','-of','json',str(path)]))

def audio(p): return [s for s in p['streams'] if s.get('codec_type')=='audio']
def check_pcm24(p,rate,channels):
    a=audio(p)
    return len(a)==1 and a[0].get('codec_name')=='pcm_s24le' and int(a[0].get('sample_rate',0))==rate and int(a[0].get('channels',0))==channels

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--output',required=True);a=ap.parse_args()
    ffmpeg=os.environ.get('FFMPEG','ffmpeg');ffprobe=os.environ.get('FFPROBE','ffprobe')
    cases=[]
    def ok(name,cond,detail=''):
        cases.append({'name':name,'passed':bool(cond),'detail':detail})
    with tempfile.TemporaryDirectory() as td:
        td=pathlib.Path(td);src=td/'source.wav';enh=td/'enhanced.wav';bad=td/'bad16.wav';mono=td/'mono.wav'
        run([ffmpeg,'-hide_banner','-loglevel','error','-f','lavfi','-i','sine=frequency=220:sample_rate=48000:duration=2','-f','lavfi','-i','sine=frequency=440:sample_rate=48000:duration=2','-filter_complex','[0:a][1:a]amerge=inputs=2[a]','-map','[a]','-c:a','pcm_s24le',str(src)])
        before=sha(src)
        # stand-in deterministic DSP only: validates transport/timing/container contract, not learned quality
        run([ffmpeg,'-hide_banner','-loglevel','error','-i',str(src),'-af','highpass=f=60,lowpass=f=16000','-c:a','pcm_s24le',str(enh)])
        ps,pe=probe(ffprobe,src),probe(ffprobe,enh)
        ok('source_pcm24_stereo',check_pcm24(ps,48000,2));ok('enhanced_pcm24_stereo',check_pcm24(pe,48000,2))
        ds=float(ps['format']['duration']);de=float(pe['format']['duration']);ok('duration_preserved',abs(ds-de)<=2/48000,(ds,de))
        ok('source_unchanged',sha(src)==before);ok('enhanced_distinct',sha(enh)!=before)
        run([ffmpeg,'-hide_banner','-loglevel','error','-i',str(src),'-c:a','pcm_s16le',str(bad)])
        ok('pcm16_rejected_by_contract',not check_pcm24(probe(ffprobe,bad),48000,2))
        run([ffmpeg,'-hide_banner','-loglevel','error','-f','lavfi','-i','sine=frequency=330:sample_rate=48000:duration=1','-c:a','pcm_s24le',str(mono)])
        ok('mono_supported',check_pcm24(probe(ffprobe,mono),48000,1))
        # timing / path / offline invariants
        ok('enhanced_suffix_wav',enh.suffix=='.wav');ok('no_network_input',all('http' not in str(x) for x in [src,enh]));ok('finite_duration',math.isfinite(de) and de>0)
        # exact sample estimate within one ffprobe timebase quantum
        ok('sample_count_preserved',abs(round(ds*48000)-round(de*48000))<=1)
        # Decode fully to catch truncation/corruption.
        for name,path in [('source',src),('enhanced',enh),('mono',mono)]:
            r=subprocess.run([ffmpeg,'-hide_banner','-loglevel','error','-xerror','-i',str(path),'-f','null','-'],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
            ok(f'{name}_full_decode',r.returncode==0)
        # Stress exact output format with different accepted rates/channels.
        for rate in (16000,44100,48000):
            out=td/f'r{rate}.wav';run([ffmpeg,'-hide_banner','-loglevel','error','-f','lavfi','-i',f'sine=frequency=500:sample_rate={rate}:duration=0.4','-c:a','pcm_s24le',str(out)])
            ok(f'rate_{rate}',check_pcm24(probe(ffprobe,out),rate,1))
        # Corruption must fail full decode.
        corrupt=td/'corrupt.wav';data=enh.read_bytes();corrupt.write_bytes(data[:max(64,len(data)//8)])
        r=subprocess.run([ffmpeg,'-hide_banner','-loglevel','error','-xerror','-i',str(corrupt),'-f','null','-'],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        ok('truncated_rejected',r.returncode!=0)
        # Synthetic zero weights validate the actual native RNNoise parser and
        # delay path. They are not trained speech enhancement/quality evidence.
        model_dir=td/"model ,comma;semi:colon'quote[bracket]\\backslash"
        model_dir.mkdir();model=model_dir/'selected.rnnn'
        with model.open('w') as handle:
            handle.write('rnnoise-nu model file version 1\n')
            for inputs,outputs,gru in ((42,24,False),(24,24,True),(90,48,True),(114,96,True),(96,22,False),(24,1,False)):
                handle.write(f'{inputs} {outputs} 0\n')
                factor=3 if gru else 1
                counts=[inputs*outputs*factor]+([outputs*outputs*3] if gru else [])+[outputs*factor]
                for count in counts:handle.write(' '.join(['0']*count)+'\n')
        def filter_path(value):
            value=''.join(('\\'+c if c in "\\':" else c) for c in str(value))
            return ''.join(('\\'+c if c in "\\'[],;" else c) for c in value)
        impulse=array.array('f',[0.0]*4800);impulse[1000]=0.5
        for compensate in (False,True):
            chain=f'arnndn=m={filter_path(model)}:mix=0'
            if compensate:chain=f'apad=pad_len=480,{chain},atrim=start_sample=480,asetpts=PTS-STARTPTS,apad=whole_len=4800,atrim=end_sample=4800'
            completed=subprocess.run([ffmpeg,'-v','error','-nostdin','-f','f32le','-ar','48000','-ac','1','-i','pipe:0','-af',chain,'-f','f32le','pipe:1'],input=impulse.tobytes(),stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=30)
            decoded=array.array('f');decoded.frombytes(completed.stdout)
            expected=1000 if compensate else 1480
            peak=max(range(len(decoded)),key=lambda i:abs(decoded[i])) if decoded else None
            ok('rnnoise_compensated_impulse' if compensate else 'rnnoise_declared_480_sample_delay',completed.returncode==0 and len(decoded)==4800 and peak==expected,{'samples':len(decoded),'peak_sample':peak,'expected':expected})
        for rate in (16000,44100,48000):
            output=td/f'rnnoise-{rate}.wav';count=rate//5
            chain=f'aformat=channel_layouts=stereo,aresample=48000,apad=pad_len=480,arnndn=m={filter_path(model)}:mix=0.65,atrim=start_sample=480,asetpts=PTS-STARTPTS,aresample={rate},aformat=sample_rates={rate}:channel_layouts=stereo,apad=whole_len={count},atrim=end_sample={count}'
            run([ffmpeg,'-v','error','-nostdin','-f','lavfi','-i',f'aevalsrc=sin(2*PI*440*t)|sin(2*PI*660*t):sample_rate={rate}:duration=0.2','-af',chain,'-c:a','pcm_s24le',str(output)])
            observed=probe(ffprobe,output);stream=audio(observed)[0]
            ok(f'rnnoise_stereo_rate_{rate}',check_pcm24(observed,rate,2) and stream.get('channel_layout')=='stereo' and int(stream.get('duration_ts',-1))==count)
        # Source tree invariants for integration fixes.
        root=pathlib.Path(__file__).resolve().parents[2]
        plan=(root/'src/plan.rs').read_text();native=(root/'src/native.rs').read_text();inter=(root/'src/interchange/build.rs').read_text();proj=(root/'src/project.rs').read_text()
        ok('render_plan_has_enhanced_input',bool(re.search(r'enhanced_audio\s*:\s*Option\s*<\s*PathBuf\s*>',plan)) and '[1:a:0]' in plan)
        ok('staging_preserves_suffix','suffix(&suffix)' in native and 'portable output extension' in native)
        ok('interchange_never_silent','speech-enhancement' in inter and 'never silently dropped' in inter)
        version=re.search(r'PROJECT_VERSION\s*:\s*u32\s*=\s*(\d+)',proj)
        ok('current_schema_persists_enhancement',bool(version and int(version.group(1))>=8) and 'voice_enhancement' in proj)
    report={'suite':'step13c-enhancement','scope':'Independent FFmpeg transport/format, synthetic RNNoise parser/DSP timing, and static integration guards; no Rust execution or trained-model quality assessment','runtime':run([ffmpeg,'-version']).splitlines()[0],'passed':sum(c['passed'] for c in cases),'failed':sum(not c['passed'] for c in cases),'cases':cases}
    pathlib.Path(a.output).write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({'passed':report['passed'],'failed':report['failed']}))
    raise SystemExit(1 if report['failed'] else 0)
if __name__=='__main__': main()
