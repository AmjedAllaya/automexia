#!/usr/bin/env python3
"""Independent real-media checks for the Rust source's proxy filter recipe.

This runs FFmpeg, not Rust. It checks decoded output, timing, dimensions, audio,
colors and failure behavior. `cargo test --test review` and `native_review` are
separate and are required to test the actual Rust state/workflow implementation.
"""
from __future__ import annotations
import argparse, hashlib, json, os, re, subprocess, tempfile, time
from pathlib import Path
from fractions import Fraction as F
import run_media_checks as m
import run_edit_checks as e

ROOT=m.ROOT

def proxy_template():
    text=(ROOT/'src/plan.rs').read_text()
    match=re.search(r'pub const PROXY_FILTER\s*:\s*&str\s*=\s*("(?:[^"\\]|\\.)*");',text)
    if not match: raise AssertionError('Rust proxy filter constant missing')
    return json.loads(match.group(1))

def geometry(metadata,width,height):
    v=m.vstream(metadata);w,h=int(v['width']),int(v['height'])
    sar=F(v.get('sample_aspect_ratio','1:1').replace(':','/'))
    angle=next((int(round(s['rotation'])) for s in v.get('side_data_list',[]) if 'rotation' in s),int(v.get('tags',{}).get('rotate',0)))%360
    if angle%180:w,h=h,w;sar=1/sar
    f=min(F(width,w),F(height,h),F(1))
    ow=(w*f.numerator//f.denominator)//2*2
    oh=(h*f.numerator//f.denominator)//2*2
    assert ow>=2 and oh>=2
    return ow,oh,F(w,h)*sar/F(ow,oh)

def arguments(metadata,source,out,ranges,audio=1,width=80,height=48,cfr=None):
    graph,duration,segments=e.graph(metadata,ranges,audio)
    w,h,sar=geometry(metadata,width,height)
    graph=graph.replace('[vout]','[vproxy]',1)+';'+e.substitute(proxy_template(),width=w,height=h,sar=f'{sar.numerator}/{sar.denominator}')
    args=m.prefix('EDITED_PREFIX','edit_render.rs')+['-threads','2']+m.prefix('INPUT_POLICY','plan.rs')+['-i',str(source),'-filter_complex_threads','1','-filter_complex',graph,'-map','[vout]']
    args+=['-map','[aout]'] if audio is not None else ['-an']
    args+=['-map_metadata','-1','-map_chapters','-1','-sn','-dn','-c:v','libx264','-preset','fast','-crf','28','-pix_fmt','yuv420p','-threads:v','2']
    if cfr:
        rate=F(cfr);args+=['-fps_mode:v','cfr','-r:v',f'{rate.numerator}/{rate.denominator}','-enc_time_base:v',f'{rate.denominator}/{rate.numerator}']
    else:
        rate=F(m.vstream(metadata).get('r_frame_rate') or m.vstream(metadata)['avg_frame_rate'])
        args+=['-fps_mode:v','passthrough','-enc_time_base:v','1/1000000','-bsf:v',e.substitute(e.template('DURATION_BSF'),num=rate.numerator,den=rate.denominator)]
    colors=[(flag,m.vstream(metadata)[field]) for flag,field in [('-colorspace','color_space'),('-color_trc','color_transfer'),('-color_primaries','color_primaries'),('-color_range','color_range')] if m.vstream(metadata).get(field) not in [None,'unknown','unspecified']]
    if colors:args+=['-x264-params','videoformat=component']
    for flag,value in colors:args += [flag,value]
    if audio is not None:args+=['-c:a','aac','-b:a','192k','-threads:a','1']
    us=e.ceil(duration*1000000)
    args+=['-t',f'{us//1000000}.{us%1000000:06}','-metadata:s:v:0','rotate=0','-avoid_negative_ts','disabled','-movflags','+faststart','-progress','pipe:1','-nostats','-f','mp4',str(out)]
    return args,duration,(w,h,sar),colors,segments

def proxy(source,out,ranges,**options):
    before=hashlib.sha256(source.read_bytes()).hexdigest();src=m.probe(source)
    args,duration,geom,colors,segments=arguments(src,source,out,ranges,**options)
    progress=m.execute([m.FFMPEG,*args]);assert b'progress=end' in progress
    data=m.probe(out);v=m.vstream(data)
    assert (v['width'],v['height'])==geom[:2]
    actual_sar=F(v.get('sample_aspect_ratio','1:1').replace(':','/'))
    assert abs(float(actual_sar-geom[2]))<1e-5,(actual_sar,geom[2])
    assert not any(abs(s.get('rotation',0))>.01 for s in v.get('side_data_list',[]))
    assert abs(float(e.exact_duration(v)-duration))<.1,(e.exact_duration(v),duration)
    audio=options.get('audio',1)
    assert len(m.streams(data,'audio'))==(0 if audio is None else 1)
    if audio is not None:
        a=m.streams(data,'audio')[0];original=next(s for s in src['streams'] if s['index']==audio)
        assert a['channels']==original['channels'];assert a['sample_rate']==original['sample_rate']
        assert abs(float(e.exact_duration(a)-duration))<.1
    for option,value in colors:
        key={'-colorspace':'color_space','-color_trc':'color_transfer','-color_primaries':'color_primaries','-color_range':'color_range'}[option]
        assert v.get(key)==value,(key,v.get(key),value)
    m.execute([m.FFMPEG,*m.prefix('DECODE_PREFIX','host.rs'),str(out),'-map','0:v:0',*(['-map','0:a:0'] if audio is not None else []),'-f','null','-'])
    assert hashlib.sha256(source.read_bytes()).hexdigest()==before
    assert out.stat().st_size<32*1024*1024
    return data,duration,geom,segments

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,required=True);parser.add_argument('--keep',type=Path);parser.add_argument('--update-fixture',action='store_true');args=parser.parse_args()
    results=[]
    with tempfile.TemporaryDirectory(prefix='video-review-recipes-') as temporary:
        work=args.keep or Path(temporary);work.mkdir(parents=True,exist_ok=True)
        base=work/'input.mp4';m.fixture(base,duration='4',rate='30')
        args.output.parent.mkdir(parents=True,exist_ok=True)
        def case(name,fn):
            start=time.monotonic()
            try: details=fn() or {};results.append(dict(name=name,status='passed',seconds=round(time.monotonic()-start,3),details=details));print('PASS',name,flush=True)
            except Exception as exc:results.append(dict(name=name,status='failed',error=str(exc)));print('FAIL',name,str(exc),flush=True)
            args.output.write_text(json.dumps({'scope':'Independent FFmpeg recipes, NOT Rust execution','complete':False,'checks':results},indent=2)+'\n')
        def ab():
            a=work/'before.mp4';b=work/'proposed.mp4'
            _,ad,_,_=proxy(base,a,[('0','3')]);_,bd,_,_=proxy(base,b,[('0','1'),('2','3')])
            assert len(m.frames(a))==90;assert len(m.frames(b))==60
            return {'before_seconds':str(ad),'proposed_seconds':str(bd),'before_frames':90,'proposed_frames':60}
        case('original_and_proposed_are_real_distinct_playable_media',ab)
        def no_audio():
            source=work/'no-audio.mp4';m.fixture(source,audio=False,rate='30',duration='4')
            proxy(source,work/'no-audio-review.mp4',[('1','2')],audio=None)
        case('video_only_review_without_fabricated_audio',no_audio)
        def second_audio():
            source=work/'two-audio.mp4'
            m.execute([m.FFMPEG,'-v','error','-y','-i',base,'-f','lavfi','-i','sine=frequency=880:sample_rate=48000:duration=4','-map','0:v','-map','0:a','-map','1:a','-c:v','copy','-c:a','aac',source])
            out=work/'second-audio-review.mp4';proxy(source,out,[('1','3')],audio=2)
            frequency=m.frequency(out);assert 860<frequency<900,frequency
            return {'selected_audio_hz':frequency}
        case('explicit_second_audio_track_is_used_for_listening',second_audio)
        def vfr():
            source=work/'vfr.mp4';m.fixture(source,rate='30',duration='4',video_filter="select='not(eq(mod(n,5),1))'",extra=['-fps_mode','vfr'])
            out=work/'vfr-proxy.mp4';proxy(source,out,[('0','1'),('2','3')])
            original=m.frames(source);expected=[t for t in original if t<1]+[t-1 for t in original if 2<=t<3];actual=m.frames(out)
            assert len(actual)==len(expected);error=max(abs(float(a-b)) for a,b in zip(actual,expected));assert error<.001
            return {'retained_frames':len(actual),'max_pts_error_s':error}
        case('proxy_preserves_vfr_cut_timing',vfr)
        def fractional():
            source=work/'fractional.mp4';m.fixture(source,rate='30000/1001',duration='4');out=work/'fractional-proxy.mp4'
            ranges=[(F(1001,30000),F(20*1001,30000))];proxy(source,out,ranges);assert len(m.frames(out))==19
        case('fractional_boundary_keeps_first_frame',fractional)
        def rotation():
            source=work/'rotated.mp4';m.execute([m.FFMPEG,'-v','error','-y','-display_rotation:v:0','90','-i',base,'-c','copy',source]);out=work/'rotated-proxy.mp4'
            assert any(abs(x.get('rotation',0))==90 for x in m.vstream(m.probe(source)).get('side_data_list',[])), 'fixture must actually contain rotation'
            d,_,g,_=proxy(source,out,[('1','3')]);assert g[:2]==(28,48)
            source_rgb=m.execute([m.FFMPEG,'-v','error','-i',source,'-ss','1','-frames:v','1','-vf',f'scale={g[0]}:{g[1]}:flags=bilinear','-pix_fmt','rgb24','-f','rawvideo','-'])
            result_rgb=m.execute([m.FFMPEG,'-v','error','-i',out,'-frames:v','1','-pix_fmt','rgb24','-f','rawvideo','-'])
            assert len(source_rgb)==len(result_rgb)
            pixel_error=sum(abs(a-b) for a,b in zip(source_rgb,result_rgb))/len(source_rgb)
            assert pixel_error<12,pixel_error
            return {'width':g[0],'height':g[1],'sar':str(g[2]),'mean_pixel_error':pixel_error}
        case('portrait_rotation_and_display_aspect',rotation)
        def sar():
            source=work/'sar.mp4';m.fixture(source,rate='30',duration='4',video_filter='setsar=4/3');out=work/'sar-proxy.mp4'
            _,_,g,_=proxy(source,out,[('1','3')]);assert g[2]==F(4,3)
        case('non_square_pixels_are_not_stretched',sar)
        def no_upscale():
            out=work/'native-size-proxy.mp4';d,_,g,_=proxy(base,out,[('1','3')],width=640,height=360);assert g[:2]==(160,96)
        case('small_inputs_are_not_upscaled',no_upscale)
        def cfr():
            out=work/'24fps.mp4';d,_,_,_=proxy(base,out,[('1','3')],cfr='24');assert F(m.vstream(d)['avg_frame_rate'])==24
        case('explicit_saved_cfr_policy_in_proxy',cfr)
        def colors():
            source=work/'bt709.mp4';m.fixture(source,rate='30',duration='4',extra=['-colorspace','bt709','-color_trc','bt709','-color_primaries','bt709','-color_range','tv','-x264-params','videoformat=component'])
            proxy(source,work/'bt709-proxy.mp4',[('1','3')])
        case('sdr_tags_survive_proxy_scaling',colors)
        def full_range():
            source=work/'full-range.mp4';m.fixture(source,rate='30',duration='4',video_filter='scale=in_range=tv:out_range=pc',extra=['-color_range','pc','-pix_fmt','yuvj420p','-x264-params','videoformat=component'])
            proxy(source,work/'full-range-proxy.mp4',[('1','3')])
        case('full_range_proxy_remains_full_range',full_range)
        def delayed_audio():
            source=work/'delayed.mp4';m.execute([m.FFMPEG,'-v','error','-y','-i',base,'-itsoffset','0.35','-i',base,'-map','0:v','-map','1:a','-c','copy',source]);out=work/'delayed-proxy.mp4';proxy(source,out,[('0','1'),('2','3')])
            samples=m.pcm(out);rms=lambda a:(sum(x*x for x in a)/max(1,len(a)))**.5
            assert rms(samples[:10000])<10;assert rms(samples[24000:30000])>100
        case('audio_offset_preserved_at_review_cut',delayed_audio)
        def exact():
            out=work/'exact-19.mp4';proxy(base,out,[(F(1,30),F(2,3))]);assert len(m.frames(out))==19
        case('nineteen_frame_regression_still_passes_with_scaling',exact)
        def short_window():
            out=work/'short.mp4';proxy(base,out,[('1','11/10')]);assert len(m.frames(out))==3
        case('short_valid_window_is_decodable',short_window)
        def first_window():
            out=work/'first-second.mp4';proxy(base,out,[('0','1')]);pts=m.frames(out)
            assert len(pts)==30 and pts[0]==0
        case('preview_at_source_start_preserves_first_frame',first_window)
        def last_window():
            out=work/'last-second.mp4';proxy(base,out,[('3','4')]);pts=m.frames(out)
            assert len(pts)==30 and pts[0]==0
        case('preview_at_source_end_keeps_final_frame',last_window)
        def one_frame():
            out=work/'one-frame.mp4';proxy(base,out,[(F(1),F(31,30))]);assert len(m.frames(out))==1
        case('one_frame_preview_is_playable',one_frame)
        def stereo():
            source=work/'stereo-44100.mp4'
            m.execute([m.FFMPEG,'-v','error','-y','-i',base,'-f','lavfi','-i',
                'aevalsrc=0.1*sin(2*PI*440*t)|0.1*sin(2*PI*880*t):s=44100:d=4',
                '-map','0:v','-map','1:a','-c:v','copy','-c:a','aac',source])
            out=work/'stereo-review.mp4';d,_,_,_=proxy(source,out,[('0','1'),('2','3')]);audio=m.streams(d,'audio')[0]
            assert audio['channels']==2 and audio['channel_layout']=='stereo' and audio['sample_rate']=='44100'
            return {'channels':2,'sample_rate':44100}
        case('stereo_channel_layout_and_44100_sample_rate_survive',stereo)
        def oddname():
            source=work/'é ;$(touch forbidden).mp4';source.write_bytes(base.read_bytes());out=work/'审阅 ;preview.mp4';proxy(source,out,[('0','1')]);assert not (work/'forbidden').exists()
        case('unicode_and_metacharacter_paths_are_not_shell_text',oddname)
        def corrupt():
            source=work/'corrupt.mp4';source.write_bytes(b'not video')
            try:m.probe(source)
            except AssertionError:return {'rejected':True}
            raise AssertionError('Corrupt source accepted')
        case('malformed_media_is_rejected',corrupt)
        def sync():
            source=work/'flash-tone.mp4'
            m.execute([m.FFMPEG,'-v','error','-y','-f','lavfi','-i',"color=c=black:size=160x96:rate=30:duration=4,drawbox=color=white:t=fill:enable='between(t,2.5,2.7)'",'-f','lavfi','-i',"aevalsrc=if(between(t\\,2.5\\,2.7)\\,0.5*sin(2*PI*880*t)\\,0):s=48000:d=4",'-c:v','libx264','-pix_fmt','yuv420p','-threads','2','-c:a','aac',source])
            out=work/'flash-tone-proxy.mp4';proxy(source,out,[('0','1'),('2','3')])
            raw=m.execute([m.FFMPEG,'-v','error','-i',out,'-map','0:v:0','-vf','scale=1:1','-pix_fmt','gray','-f','rawvideo','-'])
            pts=m.frames(out);flash=next(float(t) for t,y in zip(pts,raw) if y>100)
            samples=m.pcm(out);tone=next(i/48000 for i,x in enumerate(samples) if abs(x)>4000)
            assert abs(tone-flash)<.04,(tone,flash)
            return {'flash_s':flash,'tone_s':tone,'difference_s':abs(tone-flash)}
        case('decoded_flash_and_tone_sync_after_cut_and_downscale',sync)
        def cancel():
            out=work/'cancelled.mp4';metadata=m.probe(base);a,_,_,_,_=arguments(metadata,base,out,[('0','4')])
            # Slow fixture rendering only for cancellation. This test does NOT
            # exercise the Rust Cancellation/lease implementation.
            at=a.index('-i');a[at:at]=['-re']
            proc=subprocess.Popen([m.FFMPEG,*a],stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
            try:time.sleep(.12);proc.terminate();proc.wait(timeout=5);assert proc.returncode!=0
            finally:
                if proc.poll() is None:proc.kill();proc.wait(timeout=5)
                out.unlink(missing_ok=True)
            return {'process_stopped':True,'rust_cancel_exercised':False}
        case('media_process_can_be_stopped_during_proxy_render',cancel)
        def golden():
            metadata=json.loads((ROOT/'tests/fixtures/probe-base.json').read_text())
            duration=e.exact_duration(m.vstream(metadata));a,_,_,_,_=arguments(metadata,'/selected/input.mp4','/private/review.mp4',[(F(0),F(1,2)),(F(1),duration)])
            fixture=ROOT/'tests/review_fixtures/proxy-argv.json'
            if args.update_fixture:fixture.write_text(json.dumps(a,indent=2)+'\n')
            assert json.loads(fixture.read_text())==a
            return {'rust_golden_fixture_prepared':True,'rust_executed':False}
        case('literal_proxy_recipe_has_cargo_golden_fixture',golden)
        report={'scope':'Independent FFmpeg proxy-recipe checks; Rust code and host UI were NOT executed.','complete':True,
            'ffmpeg':m.execute([m.FFMPEG,'-version']).decode().splitlines()[0],
            'checks':results,'passed':sum(x['status']=='passed' for x in results),'failed':sum(x['status']=='failed' for x in results)}
        args.output.parent.mkdir(parents=True,exist_ok=True);args.output.write_text(json.dumps(report,indent=2)+'\n')
        if report['failed']:raise SystemExit(1)
if __name__=='__main__':main()
