#!/usr/bin/env python3
"""Exercise the FFmpeg media recipes on real generated files.

This does NOT compile or execute Rust. Cargo unit/native tests separately exercise
Rust. The prefixes are read from Rust and the complete expected argv is also a
Cargo golden fixture. Python is a test-only dependency, never the extension.
"""
from __future__ import annotations
import argparse, array, hashlib, json, os, re, shutil, subprocess, tempfile, time
from fractions import Fraction
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
FFMPEG = os.environ.get("FFMPEG", shutil.which("ffmpeg") or "ffmpeg")
UPDATE_FIXTURES = False
FFPROBE = os.environ.get("FFPROBE", shutil.which("ffprobe") or "ffprobe")

def write_fixture(name, data):
    if not UPDATE_FIXTURES: return
    if isinstance(data,dict) and 'format' in data:
        data=json.loads(json.dumps(data));data['format']['filename']='/fixtures/'+name.replace('probe-','').replace('output-','').replace('.json','.media')
    (ROOT/'tests'/'fixtures'/name).write_text(json.dumps(data,indent=2)+'\n')

def execute(args, *, timeout=45):
    p = subprocess.run([str(x) for x in args], stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                       timeout=timeout, stdin=subprocess.DEVNULL)
    if p.returncode:
        raise AssertionError(f"Media command exited {p.returncode}: {p.stderr.decode(errors='replace')[-1800:]}")
    return p.stdout

def prefix(name, file):
    text = (ROOT/'src'/file).read_text()
    m = re.search(r'pub const '+re.escape(name)+r'\s*:\s*&\[&str\]\s*=\s*&\[(.*?)\];', text, re.S)
    if not m: raise AssertionError(f"Missing literal Rust prefix {name}")
    return re.findall(r'"([^"\\]*)"', m.group(1))

def probe(path, head=True):
    if head:
        args=prefix('PROBE_PREFIX','host.rs') + [str(path)]
    else:
        args=['-v','error','-show_streams','-show_format','-of','json',str(path)]
    return json.loads(execute([FFPROBE,*args]))

def streams(data, kind): return [x for x in data['streams'] if x['codec_type']==kind]
def vstream(data): return streams(data,'video')[0]
def frames(path):
    d=json.loads(execute([FFPROBE,'-v','error','-select_streams','v:0','-show_frames',
                         '-show_entries','frame=best_effort_timestamp_time','-of','json',path]))
    return [Fraction(x['best_effort_timestamp_time']) for x in d['frames']]

def render_argv(path, out, audio=1, cfr=None, full_range=False, colors=None):
    # Expected recipe, not a second implementation of the Video core. Cargo's
    # golden_commands test compares the Rust-built argv to the committed fixture.
    a=prefix('RENDER_PREFIX','plan.rs')+['-threads','2']+prefix('INPUT_POLICY','plan.rs')+['-i',str(path),'-map','0:0']
    a+=['-an'] if audio is None else ['-map',f'0:{audio}']
    a+=['-map_metadata','-1','-map_chapters','-1','-sn','-dn','-c:v','libx264',
        '-preset','medium','-crf','18','-pix_fmt','yuv420p','-threads:v','2','-filter_threads','1']
    if full_range: a+=['-vf','scale=in_range=pc:out_range=pc']
    if cfr:
        r=Fraction(cfr);a+=['-fps_mode:v','cfr','-r:v',f'{r.numerator}/{r.denominator}',
                           '-enc_time_base:v',f'{r.denominator}/{r.numerator}']
    else: a+=['-fps_mode:v','passthrough','-enc_time_base:v','demux']
    if colors: a+=['-x264-params','videoformat=component']
    for key,val in colors or []: a += [key,val]
    if audio is not None: a+=['-c:a','aac','-b:a','192k','-threads:a','1']
    a+=['-metadata:s:v:0','rotate=0','-avoid_negative_ts','disabled','-movflags','+faststart',
        '-progress','pipe:1','-nostats','-f','mp4',str(out)]
    return a

def render(source,out,**kw):
    before=hashlib.sha256(source.read_bytes()).hexdigest()
    metadata=probe(source);sv=vstream(metadata)
    if 'colors' not in kw:
        kw['colors']=[(flag,sv[field]) for flag,field in [('-colorspace','color_space'),('-color_trc','color_transfer'),('-color_primaries','color_primaries'),('-color_range','color_range')] if sv.get(field) not in [None,'unknown','unspecified']]
    if sv.get('color_range')=='pc' or sv.get('pix_fmt','').startswith('yuvj'):kw['full_range']=True
    progress=execute([FFMPEG,*render_argv(source,out,**kw)])
    assert b'progress=end' in progress
    assert hashlib.sha256(source.read_bytes()).hexdigest()==before, 'Source changed'
    data=probe(out)
    for flag,value in kw['colors']:
        field={'-colorspace':'color_space','-color_trc':'color_transfer','-color_primaries':'color_primaries','-color_range':'color_range'}[flag]
        assert vstream(data).get(field)==value, f'{field} changed'
    a=prefix('DECODE_PREFIX','host.rs')+[str(out),'-map','0:v:0']
    if streams(data,'audio'): a+=['-map','0:a:0']
    execute([FFMPEG,*a,'-f','null','-'])
    write_fixture('output-'+out.stem+'.json',data)
    return data

def fixture(path,audio=True,video_filter=None,rate='30000/1001',duration='2',codec='libx264',extra=None):
    a=[FFMPEG,'-hide_banner','-loglevel','error','-y','-f','lavfi','-i',f'testsrc2=size=160x96:rate={rate}:duration={duration}']
    if audio: a+=['-f','lavfi','-i',f'sine=frequency=440:sample_rate=48000:duration={duration}']
    if video_filter: a+=['-vf',video_filter]
    a+=['-c:v',codec,'-threads','2','-pix_fmt','yuv420p']
    if codec=='libx264': a+=['-preset','fast']
    if audio: a+=['-c:a','libopus' if path.suffix=='.webm' else 'aac']
    a+=(extra or [])+[str(path)]
    execute(a)

def pcm(path):
    raw=execute([FFMPEG,'-v','error','-i',path,'-map','0:a:0','-ac','1','-ar','48000','-f','s16le','-'])
    a=array.array('h');a.frombytes(raw)
    if __import__('sys').byteorder!='little':a.byteswap()
    return a

def frequency(path):
    data=pcm(path)[12000:36000];return sum(x<=0<y for x,y in zip(data,data[1:]))*2

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,default=ROOT/'reports'/'media-checks.json');ap.add_argument('--keep',type=Path);ap.add_argument('--update-fixtures',action='store_true')
    args=ap.parse_args();results=[];start=time.monotonic()
    global UPDATE_FIXTURES
    UPDATE_FIXTURES=args.update_fixtures
    temporary=tempfile.TemporaryDirectory(prefix='automexia-video-media-') if args.keep is None else None
    work=Path(temporary.name) if temporary else args.keep.resolve();work.mkdir(parents=True,exist_ok=temporary is not None)
    def case(name,fn):
        t=time.monotonic()
        try: details=fn() or {};results.append(dict(name=name,status='passed',seconds=round(time.monotonic()-t,3),details=details));print('PASS',name,flush=True)
        except Exception as exc: results.append(dict(name=name,status='failed',error=str(exc)));print('FAIL',name,str(exc),flush=True)
    base=work/'base.mp4';fixture(base);base_data=probe(base)
    write_fixture('probe-base.json',base_data)
    golden=render_argv(Path('/selected/input.mp4'),Path('/private/staged.mp4'))
    write_fixture('render-default-argv.json',golden)
    assert golden==json.loads((ROOT/'tests'/'fixtures'/'render-default-argv.json').read_text())
    def ordinary():
        out=work/'ordinary.mp4';d=render(base,out)
        assert (vstream(d)['width'],vstream(d)['height'])==(160,96)
        assert abs(float(d['format']['duration'])-float(base_data['format']['duration']))<.1
        assert len(frames(out))==len(frames(base))
        assert streams(d,'audio')[0]['sample_rate']=='48000'
        return {'video_frames':len(frames(out)),'duration':d['format']['duration']}
    case('ordinary_h264_aac_with_b_frames',ordinary)
    def no_audio():
        src=work/'silent.mkv';fixture(src,audio=False);out=work/'silent.mp4';d=render(src,out,audio=None);assert not streams(d,'audio')
    case('no_audio_mkv',no_audio)
    def rotated():
        src=work/'rotated.mov';execute([FFMPEG,'-v','error','-y','-display_rotation','90','-i',base,'-c','copy',src]);d=probe(src)
        write_fixture('probe-rotated.json',d)
        out=work/'rotated.mp4';od=render(src,out);v=vstream(od);assert (v['width'],v['height'])==(96,160)
        assert not any(x.get('rotation',0)!=0 for x in v.get('side_data_list',[]))
        # Compare decoded display-oriented frames, not only metadata dimensions.
        def rgb(p):return execute([FFMPEG,'-v','error','-i',p,'-frames:v','1','-pix_fmt','rgb24','-f','rawvideo','-'])
        a,b=rgb(src),rgb(out);assert len(a)==len(b);assert sum(abs(x-y) for x,y in zip(a,b))/len(a)<8
    case('portrait_rotation_pixels_and_metadata',rotated)
    vfr=work/'vfr.mkv';fixture(vfr,audio=True,rate='30',video_filter="select='not(eq(mod(n,5),1))'",extra=['-fps_mode','vfr'])
    def variable():
        out=work/'vfr.mp4';render(vfr,out);a,b=frames(vfr),frames(out);assert len(a)==len(b)
        assert len(set(round(float(y-x),3) for x,y in zip(a,a[1:])))>1
        origin=Fraction(probe(vfr)['format']['start_time'])
        assert max(abs(float(x-origin-y)) for x,y in zip(a,b))<.003
        return {'frames':len(a),'max_timestamp_error_s':max(abs(float(x-origin-y)) for x,y in zip(a,b))}
    case('variable_frame_rate_preserved',variable)
    def constant():
        out=work/'cfr.mp4';d=render(vfr,out,cfr='24');assert Fraction(vstream(d)['avg_frame_rate'])==24
        times=frames(out);assert max(abs(float(y-x)-1/24) for x,y in zip(times,times[1:]))<.00001
    case('explicit_cfr_conversion',constant)
    def multiple():
        src=work/'multi.mp4';execute([FFMPEG,'-v','error','-y','-i',base,'-f','lavfi','-i','sine=frequency=880:sample_rate=48000:duration=2',
            '-map','0:v','-map','0:a','-map','1:a','-c:v','copy','-c:a','aac','-disposition:a:0','0','-disposition:a:1','0',src]);d=probe(src)
        # MP4 may reinstate a default; strip only in a separately marked unit fixture.
        write_fixture('probe-multi.json',d)
        out=work/'chosen.mp4';od=render(src,out,audio=2);assert len(streams(od,'audio'))==1
        assert abs(frequency(out)-880)<6
    case('explicit_second_audio_stream',multiple)
    def delayed():
        src=work/'delayed.mp4';execute([FFMPEG,'-v','error','-y','-i',base,'-itsoffset','0.35','-i',base,
            '-map','0:v','-map','1:a','-c','copy',src]);out=work/'delayed-out.mp4';d=render(src,out)
        before=probe(src);a=streams(before,'audio')[0];b=streams(d,'audio')[0]
        assert abs(float(a['start_time'])-float(b['start_time']))<.025
        return {'input_audio_start':a['start_time'],'output_audio_start':b['start_time']}
    case('relative_audio_video_offset_preserved',delayed)
    def shifted():
        src=work/'offset.mkv';fixture(src,extra=['-output_ts_offset','5']);out=work/'offset.mp4';od=render(src,out);before=probe(src)
        expected=float(vstream(before)['start_time'])-float(before['format']['start_time'])
        assert abs(float(vstream(od)['start_time'])-expected)<.02
    case('common_nonzero_source_origin',shifted)
    def webm():
        src=work/'opus.webm';fixture(src,codec='libvpx-vp9',extra=['-deadline','realtime']);data=probe(src)
        write_fixture('probe-opus.json',data)
        out=work/'opus.mp4';d=render(src,out);assert streams(d,'audio')[0]['codec_name']=='aac';assert abs(frequency(src)-frequency(out))<4
    case('webm_opus_to_mp4_aac',webm)
    def sar():
        src=work/'sar.mp4';fixture(src,video_filter='setsar=2/1');out=work/'sar-out.mp4';d=render(src,out)
        assert vstream(d)['sample_aspect_ratio']=='2:1'
        rot=work/'sar-rot.mov';execute([FFMPEG,'-v','error','-y','-display_rotation','90','-i',src,'-c','copy',rot]);rd=render(rot,work/'sar-rot-out.mp4')
        assert vstream(rd)['sample_aspect_ratio']=='1:2'
    case('pixel_aspect_ratio_and_rotated_reciprocal',sar)
    def full_range():
        src=work/'full.mp4';fixture(src,video_filter='scale=in_range=tv:out_range=pc',extra=['-color_range','pc']);out=work/'full-out.mp4'
        d=render(src,out,full_range=True,colors=[('-color_range','pc')]);assert vstream(d)['color_range']=='pc'
    case('full_range_color_metadata',full_range)
    def tagged_color():
        src=work/'bt709.mp4';fixture(src,extra=['-colorspace','bt709','-color_trc','bt709','-color_primaries','bt709','-color_range','tv','-x264-params','colorprim=bt709:transfer=bt709:colormatrix=bt709'])
        opts=[('-colorspace','bt709'),('-color_trc','bt709'),('-color_primaries','bt709'),('-color_range','tv')]
        d=render(src,work/'bt709-out.mp4',colors=opts)
        for key in ['color_space','color_transfer','color_primaries']:assert vstream(d)[key]=='bt709'
    case('explicit_color_tags_preserved',tagged_color)
    def unsafe_name():
        src=work/'vidéo 空格 ;$(touch SHOULD_NOT_EXIST).mp4';shutil.copyfile(base,src);render(src,work/'unicode.mp4');assert not (work/'SHOULD_NOT_EXIST').exists()
    case('unicode_and_shell_metacharacters_are_literal',unsafe_name)
    def malformed():
        src=work/'corrupt.mp4';src.write_bytes(b'not media\0'*100);out=work/'bad.mp4'
        p=subprocess.run([FFMPEG,*render_argv(src,out)],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        assert p.returncode!=0
    case('corrupt_input_fails',malformed)
    def playlist():
        src=work/'remote.m3u8';src.write_text('#EXTM3U\nhttp://127.0.0.1:9/secret.ts\n')
        p=subprocess.run([FFPROBE,*prefix('PROBE_PREFIX','host.rs'),str(src)],stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=5)
        assert p.returncode!=0
    case('playlist_and_network_input_denied_by_tool_policy',playlist)
    def truncated():
        src=work/'truncated.mp4';data=(work/'ordinary.mp4').read_bytes();src.write_bytes(data[:len(data)*2//3])
        p=subprocess.run([FFMPEG,*prefix('DECODE_PREFIX','host.rs'),str(src),'-f','null','-'],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        assert p.returncode!=0
    case('full_decode_detects_truncated_media',truncated)
    def cancel():
        out=work/'cancelled.mp4'
        a=render_argv(base,out);a[a.index('-i'):a.index('-i')]=['-re'] # test-only pacing; not production policy
        p=subprocess.Popen([FFMPEG,*a],stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
        time.sleep(.2);assert p.poll() is None
        import signal
        os.killpg(p.pid,signal.SIGKILL);p.communicate(timeout=5);assert p.returncode!=0
    case('real_encoder_cancellation',cancel)
    def flash_and_tone():
        src=work/'flash-tone.mp4'
        tone=r"aevalsrc=if(between(t\,0.5\,0.55)\,0.8*sin(2*PI*1000*t)\,0):s=48000:d=2"
        execute([FFMPEG,'-v','error','-y','-f','lavfi','-i',
            "color=c=black:s=160x96:r=30:d=2,drawbox=c=white:t=fill:enable='between(t,0.5,0.6)'",
            '-f','lavfi','-i',tone,'-c:v','libx264','-threads','2','-c:a','aac',src])
        out=work/'flash-tone-out.mp4';render(src,out)
        def offsets(path):
            data=probe(path);audio=pcm(path)
            onset=next(i for i,v in enumerate(audio) if abs(v)>1000)/48000
            onset+=float(streams(data,'audio')[0].get('start_time',0))
            gray=execute([FFMPEG,'-v','error','-i',path,'-map','0:v:0','-fps_mode','passthrough',
                '-pix_fmt','gray','-f','rawvideo','-'])
            times=frames(path);size=160*96
            idx=next(i for i in range(len(times)) if sum(gray[i*size:(i+1)*size])/size>200)
            return onset-float(times[idx])
        a,b=offsets(src),offsets(out)
        assert abs(a-b)<.025, (a,b)
        return {'input_tone_minus_flash_s':a,'output_tone_minus_flash_s':b,'drift_s':abs(a-b)}
    case('decoded_audio_video_flash_tone_sync',flash_and_tone)
    def stereo():
        src=work/'stereo.mp4'
        execute([FFMPEG,'-v','error','-y','-i',base,'-map','0:v','-map','0:a','-c:v','copy',
            '-af','pan=stereo|c0=c0|c1=c0','-c:a','aac',src])
        data=render(src,work/'stereo-out.mp4');a=streams(data,'audio')[0]
        assert a['channels']==2 and a['channel_layout']=='stereo'
    case('stereo_channel_layout_preserved',stereo)
    report={'scope':'Real FFmpeg command-recipe tests; NOT Rust compilation or terminal integration.',
            'rust_compiled':False,'ffmpeg':execute([FFMPEG,'-version']).decode().splitlines()[0],
            'ffprobe':execute([FFPROBE,'-version']).decode().splitlines()[0],
            'passed':sum(x['status']=='passed' for x in results),'failed':sum(x['status']=='failed' for x in results),
            'seconds':round(time.monotonic()-start,3),'cases':results}
    args.output.parent.mkdir(parents=True,exist_ok=True);args.output.write_text(json.dumps(report,indent=2)+'\n')
    if temporary:temporary.cleanup()
    return int(report['failed']!=0)
if __name__=='__main__':raise SystemExit(main())
