#!/usr/bin/env python3
"""Independent media timing and interchange reference checks.

This script never executes Rust. --rust-exports accepts documents already
created by the Rust example and tests their structure/timing, NOT a GUI editor.
No reference fixture pass is represented as a Cargo, OTIO SDK or NLE-import pass.
"""
from pathlib import Path
from fractions import Fraction as F
import argparse,hashlib,importlib.util,json,re,subprocess,sys,tempfile,time
import run_media_checks as m
sys.path.insert(0,str(m.ROOT/'tests'))
import interchange_reference as ref

DATA=json.loads((m.ROOT/'tests/interchange_fixtures/timeline.json').read_text())

def actual_scan(path,stream=0):
    meta=m.probe(path,head=False);v=next(s for s in meta['streams'] if s['index']==stream)
    prefix=m.prefix('CFR_PROBE_PREFIX','interchange/timing.rs')
    data=m.execute([m.FFPROBE,*prefix,'-select_streams',str(stream),path])
    pts=[]
    for line in data.decode().splitlines():
        if not line:continue
        if not re.fullmatch(r'pts=-?\d+\|?',line):raise ValueError(f'unknown PTS record {line!r}')
        pts.append(int(line.rstrip('|')[4:]))
    return pts,F(v['time_base']),F(v.get('start_pts',0))*F(v['time_base']),v,meta

def cfr_check(pts,tb,origin,rate,duration):
    if not pts or duration*rate!=len(pts):raise ValueError('frame count/duration mismatch')
    for i,p in enumerate(pts):
        if i and p<=pts[i-1]:raise ValueError('nonmonotonic')
        if abs(p*tb-origin-F(i)/rate)>tb/2:raise ValueError('variable/discontinuous')
    return len(pts)

def reject(call):
    try:call()
    except (ValueError,AssertionError,KeyError):return
    raise AssertionError('invalid fixture was accepted')

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,required=True);ap.add_argument('--keep',type=Path);ap.add_argument('--rust-exports',type=Path);ap.add_argument('--require-otio-sdk',action='store_true');ns=ap.parse_args();rows=[]
    def case(name,call):
        begin=time.monotonic()
        try:result=call() or {};rows.append({'name':name,'status':'passed','seconds':round(time.monotonic()-begin,3),'details':result});print('PASS',name,flush=True)
        except Exception as error:rows.append({'name':name,'status':'failed','error':str(error)});print('FAIL',name,error,flush=True)
    with tempfile.TemporaryDirectory(prefix='amx-interchange-') as tmp:
        w=ns.keep or Path(tmp);w.mkdir(parents=True,exist_ok=True);source=w/'interchange-source.mov'
        m.execute([m.FFMPEG,'-v','error','-nostdin','-y','-f','lavfi','-i','testsrc2=size=160x96:rate=30:duration=2','-f','lavfi','-i','sine=frequency=880:sample_rate=48000:duration=2','-c:v','libx264','-threads','2','-pix_fmt','yuv420p','-colorspace','bt709','-color_trc','bt709','-color_primaries','bt709','-color_range','tv','-c:a','pcm_s24le',source])
        original=hashlib.sha256(source.read_bytes()).hexdigest();docs=ref.write_fixtures(w,source,DATA)
        def normal_scan():
            pts,tb,origin,v,_=actual_scan(source);assert cfr_check(pts,tb,origin,F(30),F(v['duration_ts'])*tb)==60;return {'frames':len(pts),'time_base':str(tb)}
        case('native_ffprobe_prefix_all_frame_pts',normal_scan)
        def fractional():
            p=w/'fractional.mov';m.fixture(p,rate='30000/1001',duration='2');pts,tb,origin,v,_=actual_scan(p);assert cfr_check(pts,tb,origin,F(30000,1001),F(v['duration_ts'])*tb)==60
        case('whole_source_fractional_cfr',fractional)
        def offset():
            p=w/'offset.mov';m.execute([m.FFMPEG,'-v','error','-y','-i',source,'-c','copy','-output_ts_offset','3600',p]);pts,tb,origin,v,_=actual_scan(p);assert origin>=3600;assert cfr_check(pts,tb,origin,F(30),F(v['duration_ts'])*tb)==60
        case('container_pts_is_not_source_timecode',offset)
        def variable():
            p=w/'vfr.mov';m.fixture(p,rate='30',duration='2',video_filter="select='not(eq(mod(n,5),1))'",extra=['-fps_mode','vfr']);pts,tb,origin,v,_=actual_scan(p);reject(lambda:cfr_check(pts,tb,origin,F(30),F(len(pts),30)))
        case('actual_vfr_is_not_reference_cfr',variable)
        def invalid_pts(kind):
            pts,tb,origin,v,_=actual_scan(source)
            if kind=='duplicate':pts[20]=pts[19]
            elif kind=='gap':pts[20]+=2000
            elif kind=='truncated':pts=pts[:-1]
            elif kind=='reverse':pts[20],pts[21]=pts[21],pts[20]
            reject(lambda:cfr_check(pts,tb,origin,F(30),F(2)))
        for k in ['duplicate','gap','truncated','reverse']:case('timestamp_'+k+'_rejected',lambda k=k:invalid_pts(k))
        def df_boundary(rate,frames,label):assert ref.frames_to_tc(frames,rate,True)==label
        case('2997_drop_frame_minute',lambda:df_boundary(F(30000,1001),1800,'00:01:00;02'))
        case('2997_drop_frame_tenth_minute',lambda:df_boundary(F(30000,1001),17982,'00:10:00;00'))
        case('2997_drop_frame_hour',lambda:df_boundary(F(30000,1001),107892,'01:00:00;00'))
        case('5994_drop_frame_minute',lambda:df_boundary(F(60000,1001),3600,'00:01:00;04'))
        def label_properties(rate):
            nominal=round(rate);maximum=nominal*86400-(nominal//15)*(1440-144)
            for n in range(0,maximum,997):assert ref.tc_to_frames(ref.frames_to_tc(n,rate,True),rate,True)==n
            for minute in range(1,1440):
                h,mm=divmod(minute,60)
                if mm%10:
                    for skip in range(nominal//15):reject(lambda h=h,mm=mm,skip=skip:ref.tc_to_frames(f'{h:02d}:{mm:02d}:00;{skip:02d}',rate,True))
            reject(lambda:ref.frames_to_tc(maximum,rate,True))
        case('2997_full_day_boundary_properties',lambda:label_properties(F(30000,1001)))
        case('5994_full_day_boundary_properties',lambda:label_properties(F(60000,1001)))
        case('negative_timecode_rejected',lambda:reject(lambda:ref.frames_to_tc(-1)))
        case('timecode_24_hours_rejected',lambda:reject(lambda:ref.tc_to_frames('24:00:00:00')))
        def otio_structure():
            clips,d=ref.read_otio(docs/'example.otio');assert len(clips)==2;assert len(d['tracks']['children'])==2;assert d['global_start_time']['value']==108000;assert not d['metadata']['automexia']['application_import_tested'];return {'schema':'Timeline.1 / Clip.2 / Marker.2'}
        case('otio_reference_structure_and_explicit_unqualification',otio_structure)
        def xml_structure():
            clips,s=ref.read_xml(docs/'example.xml');assert len(clips)==2;assert s.findtext('timecode/frame')=='108000';assert len(s.findall('marker'))==3;assert not json.loads(s.findtext('logginginfo/lognote'))['application_import_tested']
        case('legacy_xmeml_structure_links_and_report',xml_structure)
        def edl_structure():
            records,text=ref.read_edl(docs/'example.edl');assert len(records)==4;assert all(k in ['V','A'] for k,_ in records);encoded=''.join(line[len('* AMX REPORT: '):] for line in text.splitlines() if line.startswith('* AMX REPORT: '));assert json.loads(ref.unquote(encoded))['application_import_tested'] is False
        case('cmx3600_cuts_and_embedded_report',edl_structure)
        def cross_read():
            a,_=ref.read_otio(docs/'example.otio');b,_=ref.read_xml(docs/'example.xml');c,_=ref.read_edl(docs/'example.edl');assert a==b
            for row,(kind,event) in zip(a,[x for x in c if x[0]=='V']):assert (row[0]*30,(row[0]+row[1])*30,row[2]*30)==(event[0],event[1],event[2]-108000)
        case('three_formats_agree_on_retained_intervals',cross_read)
        def uri_roundtrip():
            from urllib.parse import urlsplit,unquote
            p=w/"source %25 & # α '.mov";p.write_bytes(source.read_bytes());d2=ref.write_fixtures(w/'paths',p,DATA)
            a,_=ref.read_otio(d2/'example.otio');assert Path(unquote(urlsplit(a[0][3]).path))==p
            b,_=ref.read_xml(d2/'example.xml');assert a==b
        case('unicode_reserved_character_media_uri',uri_roundtrip)
        def xml_entities():
            data=dict(DATA,name='Title <x> & "quoted"');data['markers']=[{'name':'<marker> & α','at':5,'duration':0}]
            root=ref.write_fixtures(w/'xml-safe',source,data);_,x=ref.read_xml(root/'example.xml');assert x.findtext('name')==data['name'];assert x.findtext('marker/name')=='<marker> & α'
        case('xml_names_remain_text',xml_entities)
        def reject_entities():
            p=w/'bad.xml';p.write_text('<!DOCTYPE x [<!ENTITY x SYSTEM "file:///etc/passwd">]><xmeml version="5">&x;</xmeml>');reject(lambda:ref.read_xml(p))
        case('independent_reader_rejects_external_entities',reject_entities)
        def broken_link():
            p=w/'broken.xml';p.write_text((docs/'example.xml').read_text().replace('<linkclipref>v1</linkclipref>','<linkclipref>missing</linkclipref>',1));reject(lambda:ref.read_xml(p))
        case('dangling_fcp7_link_is_not_accepted',broken_link)
        def audio_group_only():
            _,seq=ref.read_xml(docs/'example.xml')
            video=[n for n in seq.iter('link') if n.findtext('mediatype')=='video']
            audio=[n for n in seq.iter('link') if n.findtext('mediatype')=='audio']
            assert video and audio
            assert all(n.find('groupindex') is None for n in video)
            assert all(n.findtext('groupindex')=='1' for n in audio)
        case('fcp7_link_groups_are_audio_only',audio_group_only)
        def invalid_video_group():
            from xml.etree import ElementTree as ET
            tree=ET.parse(docs/'example.xml')
            link=next(n for n in tree.iter('link') if n.findtext('mediatype')=='video')
            ET.SubElement(link,'groupindex').text='1'
            path=w/'invalid-video-group.xml';tree.write(path,encoding='utf-8')
            reject(lambda:ref.read_xml(path))
        case('fcp7_video_audio_group_is_rejected',invalid_video_group)
        def video_hashes(p):
            data=m.execute([m.FFMPEG,'-v','error','-i',p,'-map','0:v:0','-an','-fps_mode','passthrough','-f','framemd5','-']).decode();return [line.split(',')[-1].strip() for line in data.splitlines() if not line.startswith('#')]
        def replay(format):
            if format=='otio':pieces,_=ref.read_otio(docs/'example.otio')
            elif format=='xml':pieces,_=ref.read_xml(docs/'example.xml')
            else:
                rows,_=ref.read_edl(docs/'example.edl');pieces=[(F(a,30),F(b-a,30),F(c-108000,30),'') for k,(a,b,c,d) in rows if k=='V']
            parts=[]
            for i,(a,d,_,_) in enumerate(pieces):
                parts += [f'[0:v]trim=start_frame={int(a*30)}:end_frame={int((a+d)*30)},setpts=PTS-STARTPTS[v{i}]',f'[0:a]atrim=start_sample={int(a*48000)}:end_sample={int((a+d)*48000)},asetpts=PTS-STARTPTS[a{i}]']
            parts.append(''.join(f'[v{i}][a{i}]' for i in range(len(pieces)))+f'concat=n={len(pieces)}:v=1:a=1[v][a]')
            out=w/(format+'-replayed.mkv');m.execute([m.FFMPEG,'-v','error','-y','-i',source,'-filter_complex',';'.join(parts),'-map','[v]','-map','[a]','-c:v','ffv1','-threads','2','-c:a','pcm_s24le',out]);orig=video_hashes(source);actual=video_hashes(out)
            assert actual==orig[:15]+orig[30:60];pcm=m.pcm(out);assert len(pcm)==72000;return {'decoded_video_frames':len(actual),'decoded_mono_audio_samples':len(pcm)}
        for format in ['otio','xml','edl']:case(format+'_readback_replays_exact_decoded_frames',lambda format=format:replay(format))
        def video_bake():
            p=w/'baked.mov';m.execute([m.FFMPEG,'-v','error','-y','-i',source,'-vf','eq=brightness=0.02','-fps_mode','cfr','-r','30','-c:v','prores_ks','-profile:v','3','-pix_fmt','yuv422p10le','-threads','2','-c:a','pcm_s24le',p]);pts,tb,origin,v,_=actual_scan(p);assert cfr_check(pts,tb,origin,F(30),F(v['duration_ts'])*tb)==60;assert v['codec_name']=='prores';assert hashlib.sha256(source.read_bytes()).hexdigest()==original
        case('explicit_prores_bake_is_real_separate_media',video_bake)
        def stem():
            p=w/'stem.wav';m.execute([m.FFMPEG,'-v','error','-y','-i',source,'-map','0:a:0','-af','atrim=start_sample=24000:end_sample=72000,asetpts=PTS-STARTPTS','-c:a','pcm_s24le',p]);a=m.streams(m.probe(p,head=False),'audio')[0];assert a['sample_rate']=='48000' and a['channels']==1 and a['duration_ts']==48000
        case('explicit_stem_preserves_sample_layout_and_duration',stem)
        def absent_media():
            p=w/'missing.mov';proc=subprocess.run([m.FFPROBE,*m.prefix('CFR_PROBE_PREFIX','interchange/timing.rs'),p],capture_output=True);assert proc.returncode!=0
        case('missing_media_has_no_successful_probe',absent_media)
        def corrupt_media():
            p=w/'corrupt.mov';p.write_bytes(b'not video');proc=subprocess.run([m.FFPROBE,*m.prefix('CFR_PROBE_PREFIX','interchange/timing.rs'),p],capture_output=True);assert proc.returncode!=0
        case('corrupt_media_has_no_successful_probe',corrupt_media)
        def cancelled_scan():
            child=subprocess.Popen([m.FFMPEG,'-v','error','-nostdin','-re','-stream_loop','-1','-i',str(source),'-f','null','-'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
            try:time.sleep(.12);child.terminate();child.wait(timeout=5);assert child.returncode!=0
            finally:
                if child.poll() is None:child.kill();child.wait()
        case('long_media_operation_can_be_reaped',cancelled_scan)
        case('original_media_unchanged',lambda: (_ for _ in ()).throw(AssertionError('source modified')) if hashlib.sha256(source.read_bytes()).hexdigest()!=original else None)
        if ns.rust_exports:
            def rust_readback():
                o,_=ref.read_otio(ns.rust_exports/'timeline.otio');x,_=ref.read_xml(ns.rust_exports/'timeline.xml');e,_=ref.read_edl(ns.rust_exports/'timeline.edl')
                wanted=[(F(0),F(1,2),F(0)),(F(1),F(1),F(1,2))]
                assert [r[:3] for r in o]==wanted
                assert [r[:3] for r in x]==wanted
                assert [row for kind,row in e if kind=='V']==[(0,15,108000,108015),(30,60,108015,108045)]
                return {'source':'documents produced by Rust example supplied externally','checked':'actual Rust clip time ranges, file definitions, links and schemas'}
            case('supplied_rust_document_readback',rust_readback)
        otio_status={'status':'not_run','reason':'OpenTimelineIO SDK not installed; no SDK or editor import is claimed'}
        if importlib.util.find_spec('opentimelineio'):
            import opentimelineio as otio
            def sdk():
                p=(ns.rust_exports/'timeline.otio') if ns.rust_exports else docs/'example.otio'
                t=otio.adapters.read_from_file(str(p));assert t.tracks;assert t.duration().to_seconds()>0;return {'sdk_version':otio.__version__,'file_origin':'rust' if ns.rust_exports else 'independent fixture'}
            case('available_otio_sdk_read',sdk);otio_status={'status':rows[-1]['status'],'fixture_origin':'rust' if ns.rust_exports else 'independent reference'}
        elif ns.require_otio_sdk:case('required_otio_sdk_present',lambda: (_ for _ in ()).throw(AssertionError('Required OTIO SDK is absent')))
    report={'scope':'Independent timestamp, interchange contract and real-media replay tests; Rust not executed by this script','rust_exports_supplied':bool(ns.rust_exports),'editor_application_imports':'not_run','otio_sdk':otio_status,'ffmpeg':m.execute([m.FFMPEG,'-version']).decode().splitlines()[0],'passed':sum(r['status']=='passed' for r in rows),'failed':sum(r['status']=='failed' for r in rows),'tests':rows}
    ns.output.parent.mkdir(parents=True,exist_ok=True);ns.output.write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n');raise SystemExit(bool(report['failed']))
if __name__=='__main__':main()
