#!/usr/bin/env python3
"""Independent Step 13D reference checks. Does not compile Rust or run a face model."""
from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import json, math, sys, re
ROOT=Path(__file__).resolve().parents[2]
checks=[]
def check(name,cond):
    checks.append({"name": name, "status": "passed" if cond else "failed"})
@dataclass(frozen=True)
class R: x:float;y:float;w:float;h:float
def area(a): return max(a.w*a.h,1e-12)
def center(a): return (a.x+a.w/2,a.y+a.h/2)
def dist(a,b): return math.hypot(a[0]-b[0],a[1]-b[1])
def iou(a,b):
    x0=max(a.x,b.x);y0=max(a.y,b.y);x1=min(a.x+a.w,b.x+b.w);y1=min(a.y+a.h,b.y+b.h)
    inter=max(0,x1-x0)*max(0,y1-y0);return inter/max(area(a)+area(b)-inter,1e-12)
def union(rs):
    return R(min(r.x for r in rs),min(r.y for r in rs),max(r.x+r.w for r in rs)-min(r.x for r in rs),max(r.y+r.h for r in rs)-min(r.y for r in rs))
def overlap(a,b): return a.x<b.x+b.w and b.x<a.x+a.w and a.y<b.y+b.h and b.y<a.y+a.h
src=re.sub(r'\s+', '', (ROOT/'src/face.rs').read_text())
choices=re.sub(r'\s+', '', (ROOT/'src/face/choices.rs').read_text())
placement=re.sub(r'\s+', '', (ROOT/'src/placement.rs').read_text())
workflow=re.sub(r'\s+', '', (ROOT/'src/face_workflow.rs').read_text())
model=(ROOT/'src/model_pack.rs').read_text()
lib=(ROOT/'src/lib.rs').read_text()
check('face module exported',re.search(r'pub\s+mod\s+face\s*;',lib) is not None and re.search(r'pub\s+mod\s+face_workflow\s*;',lib) is not None)
check('model contracts explicit','YUNET_CONTRACT' in model and 'ULTRAFACE_CONTRACT' in model)
check('no active speaker primitive','active_speaker' not in src.lower())
check('report stays pending','Disposition::NeedsReview' in src)
check('scene-safe crop track reused','CropTrack' in src and 'check_known_cut' in (ROOT/'src/reframe.rs').read_text())
check('sample cadence source-time','sample_interval_ms' in workflow and 'source.timeline_origin' in workflow)
check('provider panic contained','catch_unwind' in workflow)
check('activation revocation checked','activation.check()' in workflow and 'self.activation.check()' in choices)
check('no model bundle',not any(p.suffix.lower() in {'.onnx','.tflite','.pt','.pth'} for p in ROOT.rglob('*') if p.is_file() and not any(part in {'target','.git'} for part in p.relative_to(ROOT).parts)))
a=R(.2,.2,.2,.2);check('iou identity',abs(iou(a,a)-1)<1e-12)
check('iou separation',iou(a,R(.8,.8,.1,.1))==0)
check('association close center',dist(center(a),center(R(.21,.2,.2,.2)))<.18)
check('association size ratio',max(area(a)/area(R(.2,.2,.1,.1)),area(R(.2,.2,.1,.1))/area(a))<=10)
g=union([R(.2,.2,.1,.2),R(.32,.22,.1,.18)]);check('nearby group union',g.x==.2 and g.w>.2)
check('separated group distance',dist(center(R(.1,.2,.1,.1)),center(R(.8,.2,.1,.1)))>.22)
check('edge obstacle overlaps top left',overlap(R(0,0,.3,.2),R(.1,.05,.1,.1)))
check('opposite anchor avoids face',not overlap(R(.7,.8,.3,.2),R(.1,.05,.1,.1)))
check('face limits bounded','MAX_FACE_DETECTIONS:usize=64' in src and 'MAX_FACE_SAMPLES:usize=2048' in src and 'MAX_FACE_TRACKS:usize=128' in src)
check('one or two keys policy','keys_for_shot' in src and 'keys.push(CropKeyframe' in src)
check('motion fallback exists','track.validate(geometry,base.target,source.duration).is_err()' in src)
check('punch-ins suggestion only','safe_punch_in_ranges' in src and 'explicit_punch_ins' not in src)
check('avoidance suggestion only','FaceAvoidanceSuggestion' in src and 'update_overlay' not in src)
check('low resolution scan','analysis_width=192' in workflow and 'analysis_height=192' in workflow)
check('detector revalidation','detector.revalidate' in workflow)
check('face probability finite','confidence.is_finite' in src)
check('no direct render plan mutation','RenderPlan' not in src)
check('no filesystem/network authority','std::fs' not in src and 'https://' not in src.lower())
check('manual correction metric','manual_corrections:Option<u32>' in src and 'manual_corrections:None' in src)
check('clipping metric','face_clipping_events' in src)
check('jitter metric','mean_center_jitter' in src)
check('overlay avoidance honors safe zone','placement::envelope' in choices and 'safe_zone' in choices)
check('no face fallback centered','CropPose::centered()' in src)
check('model mismatch rejected','facedetectormodelcontract' in src)
check('private project binding','project.decision_digest()?!=self.binding' in choices)
check('private observation recomputation','self.original_samples.clone()' in choices and 'build_report(' in choices)
check('owner lifetime checked','self.owner.check()' in choices)
check('scene-local association','previous_shot!=Some(shot)' in src)
check('source-clock quantization','face sample is not on source clock'.replace(' ','') in src)
check('saved motion policy preserved','track.motion' in src and '.suppress_small_moves()' in src)
check('explicit typed face choices','FaceApplyChoices' in choices and 'PlacementTarget' in choices)
check('full-animation envelope','placement::envelope' in choices)
check('new collisions rejected','reject_new_collisions' in choices)
check('one atomic proposal revision','project.edit(' in choices)
check('model adapter implemented',(ROOT/'src/face_onnx.rs').is_file())
check('placement analysis connected',(ROOT/'src/placement_workflow.rs').is_file() and 'accepted:' in placement)
failed=sum(c['status']=='failed' for c in checks)
out={'suite':'step13d-face-reference','status':'passed' if not failed else 'failed','passed':len(checks)-failed,'failed':failed,'cases':checks,'qualification':'reference/static only; no Rust/model execution'}
path=Path(sys.argv[sys.argv.index('--output')+1]) if '--output' in sys.argv else None
if path:path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out))
raise SystemExit(1 if failed else 0)
