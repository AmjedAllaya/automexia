#!/usr/bin/env python3
"""Independent Step 13A-B decode/protocol checks. No Rust or learned model runs.

Uses the actual Rust argv/filter literals, FFmpeg and generated local media. The
small probability fixtures exercise the veto invariant, NOT VAD accuracy. A
separate Rust golden test and opt-in exact-model suite must establish integration.
"""
from __future__ import annotations
import argparse, array, hashlib, json, math, re, subprocess, tempfile, time
from pathlib import Path
import run_media_checks as m
RATE = 16000
WINDOW = 512
MAX_BYTES = 1024 * 1024


def filter_text(channel, start, end):
    text = (m.ROOT / 'src/speech_workflow.rs').read_text()
    found = re.search(r'pub const SPEECH_DECODE_FILTER:&str="([^"]+)";', text)
    if not found:
        raise AssertionError('Missing Rust speech filter literal')
    return found.group(1).replace('{channel}', str(channel)).replace('{start}', str(start)).replace('{end}', str(end))


def parse_packets(raw, log):
    """Independent full-buffer fixture reader (production is streaming/bounded)."""
    packets, offset, sequence = [], 0, 0
    if log and not log.endswith(b'\n'):
        raise ValueError('unterminated diagnostics')
    for line in log.decode('utf-8').splitlines():
        if 'Parsed_ashowinfo_' not in line:
            continue
        tail = line.split('] ', 1)[1]
        fields = {}
        for part in tail.split():
            if ':' in part:
                key, value = part.split(':', 1)
                if key in ('n', 'pts', 'fmt', 'channels', 'chlayout', 'rate', 'nb_samples'):
                    if key in fields:
                        raise ValueError('duplicate header key')
                    fields[key] = value
        if int(fields['n']) != sequence or fields['fmt'] != 'flt' or fields['channels'] != '1' or fields['chlayout'] != 'mono' or fields['rate'] != '16000':
            raise ValueError('PCM protocol mismatch')
        sequence += 1
        count, pts = int(fields['nb_samples']), int(fields['pts'])
        if not 1 <= count <= 8192 or offset + count * 4 > len(raw):
            raise ValueError('truncated or oversized PCM packet')
        data = array.array('f')
        data.frombytes(raw[offset:offset + count * 4])
        if __import__('sys').byteorder != 'little':
            data.byteswap()
        if any(not math.isfinite(x) or abs(x) > 8 for x in data):
            raise ValueError('invalid samples')
        packets.append((pts, data))
        offset += count * 4
    if not packets or offset != len(raw):
        raise ValueError('unmatched PCM/header stream')
    return packets


def decode(path, channel=0, stream=1, start=0, end=RATE*2):
    args = m.prefix('SPEECH_DECODE_PREFIX', 'speech_workflow.rs') + [str(path), '-map', f'0:{stream}', '-vn', '-sn', '-dn', '-filter_threads', '1', '-af', filter_text(channel, start, end), '-c:a', 'pcm_f32le', '-threads:a', '1', '-map_metadata', '-1', '-f', 'f32le', 'pipe:1']
    before = hashlib.sha256(path.read_bytes()).hexdigest()
    result = subprocess.run([m.FFMPEG, *args], stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=30)
    if result.returncode:
        raise AssertionError(result.stderr.decode(errors='replace')[-1800:])
    assert before == hashlib.sha256(path.read_bytes()).hexdigest()
    return parse_packets(result.stdout, result.stderr), result.stdout, result.stderr, args


def fixture(path, rate=48000, expression='0.2*sin(2*PI*440*t)', codec=None, extra=(), audio_filter=None, duration=2):
    codec = codec or ('libopus' if path.suffix == '.webm' else 'pcm_f32le' if path.suffix == '.mkv' else 'aac')
    args = [m.FFMPEG, '-v', 'error', '-nostdin', '-f', 'lavfi', '-i', f'testsrc2=size=160x96:rate=30:duration={duration}', '-f', 'lavfi', '-i', f'aevalsrc={expression}:sample_rate={rate}:duration={duration}']
    if audio_filter:
        args += ['-af', audio_filter]
    args += ['-c:v', 'libvpx-vp9' if path.suffix == '.webm' else 'libx264', '-threads', '1', '-pix_fmt', 'yuv420p', '-c:a', codec, *extra, str(path)]
    m.execute(args, timeout=40)


def signal(packets):
    return [v for _, data in packets for v in data]


def windows(packets, tolerance=0):
    """Reference reblocking. Gaps flush partial tails, never zero-fill holes."""
    result, pending, first, last = [], [], None, None
    for pts, data in packets:
        if last is not None and pts < last:
            overlap=last-pts
            if overlap>tolerance or overlap>=len(data):raise ValueError('overlapping audio')
            if pending:result.append((first,pending));pending=[];first=None
            data=data[overlap:];pts=last
            # Production additionally resets model context and marks its next
            # window uncertain; this helper exercises only timestamp geometry.
        if last is not None and pts > last and pending:
            result.append((first, pending));pending=[];first=None
        offset = 0
        while offset < len(data):
            if not pending:
                first = pts + offset
            count = min(WINDOW - len(pending), len(data) - offset)
            pending.extend(data[offset:offset + count]);offset += count
            if len(pending) == WINDOW:
                result.append((first, pending));pending=[];first=None
        last = pts + len(data)
    if pending:
        result.append((first, pending))
    return result


def monotonic(packets):
    previous = None
    for pts, data in packets:
        if previous is not None:
            assert pts >= previous, (pts, previous)
        previous = pts + len(data)


def fake_veto(cut, spans, before=.2, after=.25):
    # Deterministic test-only probability classes: no trained model is invoked.
    a, b = cut[0] - before, cut[1] + after
    covered = a
    for start, end, kind in spans:
        if end <= a or start >= b:continue
        if start > covered or kind != 'quiet':return True
        covered = max(covered, min(end, b))
    if covered < b:return True
    def speech(a,b):return sum(max(0,min(y,b)-max(x,a)) for x,y,c in spans if c=='speech')
    return speech(max(0,cut[0]-2.5),cut[0]) < .16 or speech(cut[1],cut[1]+2.5) < .16


def main():
    ap = argparse.ArgumentParser();ap.add_argument('--output', type=Path, required=True);ap.add_argument('--keep', type=Path)
    opts = ap.parse_args();rows=[]
    def case(name, action):
        start=time.monotonic()
        try:
            detail=action() or {};rows.append({'name':name,'status':'passed','seconds':round(time.monotonic()-start,4),'details':detail});print('PASS',name,flush=True)
        except Exception as ex:
            rows.append({'name':name,'status':'failed','error':str(ex)});print('FAIL',name,ex,flush=True)
    with tempfile.TemporaryDirectory(prefix='video-speech-') as temporary:
        work=opts.keep or Path(temporary);work.mkdir(parents=True,exist_ok=True)
        base=work/'base.mp4';fixture(base)
        def ordinary():
            p,_,_,_=decode(base);monotonic(p);assert sum(len(x) for _,x in p)==32000
            w=windows(p);assert len(w)==63 and len(w[-1][1])==256
            assert sum(len(x) for _,x in w)==32000
            return {'samples':32000,'model_windows':63,'final_partial':256}
        case('aac_decode_and_resampler_tail',ordinary)
        for rate in [8000,16000,22050,32000,44100,96000]:
            def rate_case(rate=rate):
                pth=work/f'rate-{rate}.mp4';fixture(pth,rate=rate);p,_,_,_=decode(pth);monotonic(p)
                assert abs(sum(len(x) for _,x in p)-32000)<=1
            case(f'sample_rate_{rate}',rate_case)
        def opus():
            src=work/'opus.webm';fixture(src);p,_,_,_=decode(src);monotonic(p)
            assert abs(sum(len(x) for _,x in p)-32000)<=128
            return {'samples':sum(len(x) for _,x in p),'first_pts':p[0][0]}
        case('opus_preskip_and_timestamp_rounding',opus)
        def pcm():
            src=work/'pcm.mkv';fixture(src);p,_,_,_=decode(src);monotonic(p);assert abs(sum(len(x) for _,x in p)-32000)<=16
        case('matroska_pcm_no_invented_continuity',pcm)
        def stereo():
            src=work/'stereo.mkv';fixture(src,expression='0.2*sin(2*PI*440*t)|-0.2*sin(2*PI*440*t)');a,*_=decode(src,channel=0);b,*_=decode(src,channel=1)
            av,bv=signal(a),signal(b);assert len(av)==len(bv);assert max(abs(x+y) for x,y in zip(av,bv))<1e-6
            assert sum(x*x for x in av)/len(av)>.015
        case('opposite_phase_stereo_never_downmixed',stereo)
        def silent_channel():
            src=work/'one-silent.mkv';fixture(src,expression='0|0.2*sin(2*PI*700*t)');a,*_=decode(src,channel=0);b,*_=decode(src,channel=1)
            assert max(abs(x) for x in signal(a))==0.;assert max(abs(x) for x in signal(b))>.15
        case('explicit_channel_selection',silent_channel)
        def offset():
            src=work/'offset.mkv';fixture(src,audio_filter='asetpts=PTS+0.2/TB');p,*_=decode(src);assert 3190<=p[0][0]<=3210
        case('audio_start_offset_not_zeroed',offset)
        def gap():
            src=work/'gap.mkv';fixture(src,audio_filter="aselect='not(between(t,0.5,1.0))'");p,*_=decode(src)
            holes=[b[0]-(a[0]+len(a[1])) for a,b in zip(p,p[1:])]
            assert max(holes)>7000;assert len(signal(p))<26000
            w=windows(p,tolerance=17);monotonic(w)
            dropped=len(signal(p))-sum(len(x) for _,x in w)
            assert 0<dropped<=17
            wh=[b[0]-(a[0]+len(a[1])) for a,b in zip(w,w[1:])]
            assert max(wh)>7000
            return {'largest_hole_samples':max(holes),'clipped_analysis_samples':dropped,'missing_coverage_preserved':True}
        case('actual_pts_gap_not_filled',gap)
        def large_origin():
            src=work/'large-origin.mkv';fixture(src,audio_filter='asetpts=PTS+3600/TB');p,*_=decode(src,start=3600*RATE,end=3602*RATE);assert abs(p[0][0]-3600*RATE)<=16
        case('large_source_timestamp_origin',large_origin)
        def no_gain():
            src=work/'quiet.mkv';fixture(src,expression='0.0001*sin(2*PI*440*t)');p,*_=decode(src);assert max(abs(x) for x in signal(p))<.0002
        case('quiet_audio_not_normalized',no_gain)
        def unusual_path():
            src=work/"speech 'semi; $name é.mkv";fixture(src);p,*_=decode(src);assert len(signal(p))>31000
        case('path_is_one_argument',unusual_path)
        def corrupt():
            pth=work/'broken.mp4';pth.write_bytes(b'not media')
            try:decode(pth)
            except AssertionError:return
            raise AssertionError('corrupt media accepted')
        case('decoder_error_not_partial_success',corrupt)
        p,raw,log,_=decode(base)
        def reject(raw2,log2):
            try:parse_packets(raw2,log2)
            except (ValueError,KeyError,IndexError):return
            raise AssertionError('bad protocol accepted')
        case('truncated_pcm_rejected',lambda:reject(raw[:-1],log))
        case('extra_pcm_rejected',lambda:reject(raw+b'\0\0\0\0',log))
        case('missing_header_rejected',lambda:reject(raw,b'ordinary diagnostic\n'))
        case('wrong_header_rate_rejected',lambda:reject(raw,log.replace(b'rate:16000',b'rate:48000',1)))
        case('duplicate_header_key_rejected',lambda:reject(raw,log.replace(b'fmt:flt',b'fmt:flt fmt:flt',1)))
        case('nonfinite_samples_rejected',lambda:reject(b'\0\0\xc0\x7f'+raw[4:],log))
        case('unterminated_diagnostics_rejected',lambda:reject(raw,log.rstrip(b'\n')))
        def reblock_gap():
            w=windows([(0,[0.]*325),(1000,[0.]*700)]);assert [(p,len(s)) for p,s in w]==[(0,325),(1000,512),(1512,188)]
        case('partial_gap_reblocking',reblock_gap)
        def overlap():
            try:windows([(0,[0.]*512),(500,[0.]*512)])
            except ValueError:return
            raise AssertionError('overlap not rejected')
        case('overlap_rejected',overlap)
        def guarded():
            spans=[(0,2,'speech'),(2,6,'quiet'),(6,10,'speech')]
            assert not fake_veto((2.3,5.7),spans)
            assert fake_veto((2.3,5.7),[(0,2,'speech'),(2,6,'uncertain'),(6,10,'speech')])
            assert fake_veto((2.3,5.7),[(0,2,'speech'),(2,3,'quiet'),(4,6,'quiet'),(6,10,'speech')])
        case('synthetic_probability_veto_invariant_not_model_quality',guarded)
        def no_flanks():assert fake_veto((2.3,5.7),[(0,10,'quiet')])
        case('all_model_silence_without_flanks_preserved',no_flanks)
        def bounded_overlap():
            w=windows([(0,[.1]*325),(322,[.2]*700)],tolerance=17);monotonic(w)
            assert sum(len(s) for _,s in w)==1022
            assert [(p,len(s)) for p,s in w]==[(0,325),(325,512),(837,185)]
        case('bounded_timestamp_overlap_analysis_only',bounded_overlap)
        def excessive_overlap():
            try:windows([(0,[0.]*512),(490,[0.]*512)],tolerance=17)
            except ValueError:return
            raise AssertionError('large overlap accepted')
        case('large_overlap_still_rejected_with_tolerance',excessive_overlap)
        def duplicate_packet():
            try:windows([(0,[0.]*10),(0,[0.]*10)],tolerance=17)
            except ValueError:return
            raise AssertionError('whole packet replay accepted')
        case('duplicate_packet_is_not_timestamp_rounding',duplicate_packet)
        def varied_packets():
            import random
            rng=random.Random(1301);samples=[rng.random() for _ in range(50000)]
            p=[];at=0
            while at<len(samples):
                n=rng.randint(1,8192);p.append((at,samples[at:at+n]));at+=len(p[-1][1])
            w=windows(p);assert [v for _,d in w for v in d]==samples;monotonic(w)
        case('seeded_packetization_no_loss',varied_packets)
        def second_stream():
            path=work/'two-audio.mp4'
            m.execute([m.FFMPEG,'-v','error','-nostdin','-f','lavfi','-i','testsrc2=size=160x96:duration=2',
              '-f','lavfi','-i','sine=frequency=440:duration=2',
              '-f','lavfi','-i','sine=frequency=880:duration=2',
              '-map','0:v','-map','1:a','-map','2:a','-c:v','libx264','-threads','1','-c:a','aac',str(path)])
            a,*_=decode(path,stream=1);b,*_=decode(path,stream=2)
            def freq(p):
                values=signal(p)[4000:24000];crossings=sum(x<=0<y for x,y in zip(values,values[1:]));return crossings*RATE/len(values)
            assert abs(freq(a)-440)<3 and abs(freq(b)-880)<3
        case('selected_second_audio_stream',second_stream)
        def cancellation():
            proc=subprocess.Popen([m.FFMPEG,'-v','error','-re','-f','lavfi','-i','sine=duration=30','-f','null','-'],stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
            try:time.sleep(.05);proc.terminate();assert proc.wait(timeout=3)!=0
            finally:
                if proc.poll() is None:proc.kill();proc.wait()
        case('test_media_child_termination',cancellation)
    record={'step':'13A-B','scope':'independent_ffmpeg_and_synthetic_protocol_not_rust_or_silero_quality','passed':sum(v['status']=='passed' for v in rows),'failed':sum(v['status']!='passed' for v in rows),'results':rows,'real_model_inference':False}
    opts.output.parent.mkdir(parents=True,exist_ok=True);opts.output.write_text(json.dumps(record,indent=2)+'\n')
    return int(record['failed']!=0)
if __name__=='__main__':raise SystemExit(main())
