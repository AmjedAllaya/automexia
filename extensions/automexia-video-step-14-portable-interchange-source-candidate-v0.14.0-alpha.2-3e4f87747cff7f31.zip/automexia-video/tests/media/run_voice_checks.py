#!/usr/bin/env python3
"""Independent FFmpeg Step-5 recipes using constants read from Rust.

These tests do NOT execute/typecheck Rust or qualify the terminal adapter.
Signal fixtures exercise DSP properties; they are not a human listening study.
Python is test-only; the Video extension gains no Python dependency.
"""
from __future__ import annotations
import argparse, array, hashlib, json, math, os, re, shutil, subprocess, sys, tempfile, time
from pathlib import Path
from fractions import Fraction as F
import run_media_checks as m
import run_edit_checks as e

ROOT=m.ROOT

class CapabilityUnavailable(Exception):
    pass


def template(name):
    found=re.search(r'pub const '+re.escape(name)+r'\s*:\s*&str\s*=\s*("(?:[^"\\]|\\.)*");',(ROOT/'src/voice_render.rs').read_text())
    if not found: raise AssertionError('missing source template '+name)
    return json.loads(found[1])

def filt(name,**kw):
    if name=='DENOISE_FILTER':
        kw.setdefault('rate',48000);kw['delay']=2*(kw['rate']//80)
    return e.substitute(template(name),**kw)
def num(x):return f'{x:.9f}'

def fixture(p:Path,expr='0.07*sin(2*PI*440*t)',seconds=6,rate=48000,layout=None,extra=None):
    a=[m.FFMPEG,'-v','error','-nostdin','-y','-f','lavfi','-i',f'testsrc2=size=160x96:rate=30:duration={seconds}',
       '-f','lavfi','-i',f"aevalsrc=exprs='{expr}':sample_rate={rate}:duration={seconds}"+(f':channel_layout={layout}' if layout else ''),
       '-c:v','libx264','-pix_fmt','yuv420p','-threads','2','-c:a','pcm_f32le']
    m.execute(a+(extra or [])+[str(p)])

def pcm(p:Path,audio=0):
    b=m.execute([m.FFMPEG,'-v','error','-nostdin','-i',str(p),'-map',f'0:a:{audio}','-c:a','pcm_f32le','-f','f32le','-'])
    a=array.array('f');a.frombytes(b)
    if sys.byteorder!='little':a.byteswap()
    return a

def rms(a):return math.sqrt(math.fsum(x*x for x in a)/max(1,len(a)))
def db(a):return 20*math.log10(max(a,1e-100))
def amplitude(a,hz,rate=48000):
    # A narrow frequency projection, on steady test tones after startup.
    a=a[rate:];omega=2*math.pi*hz/rate
    return 2*math.hypot(math.fsum(x*math.cos(i*omega) for i,x in enumerate(a)),math.fsum(x*math.sin(i*omega) for i,x in enumerate(a)))/len(a)

def process_audio(source,out,filters):
    args=[m.FFMPEG,'-v','error','-nostdin','-y','-i',str(source),'-map','0:a:0','-vn','-filter_threads','1']
    if filters:args+=['-af',filters]
    m.execute(args+['-map_metadata','-1','-c:a','pcm_f32le','-f','wav',str(out)])
    return pcm(out)

def measure(source,graph=None,stream=1):
    args=[m.FFMPEG,'-hide_banner','-loglevel','info','-nostats','-nostdin','-xerror','-copyts','-i',str(source)]
    if graph:args+=['-filter_complex_threads','1','-filter_complex',graph.replace('[aout]',','+template('MEASURE_FILTER')+'[ameter]'),'-map','[ameter]']
    else:args+=['-map',f'0:{stream}','-filter_threads','1','-af',template('MEASURE_FILTER')]
    result=subprocess.run(args+['-vn','-sn','-dn','-map_metadata','-1','-c:a','pcm_s16le','-f','null','-'],stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=45)
    assert result.returncode==0,result.stderr[-1500:]
    raw=result.stderr.decode(errors='strict');start=raw.rfind('{');end=raw.rfind('}')
    assert start>=0 and end>start,raw[-1500:]
    data=json.loads(raw[start:end+1])
    for k in ['input_i','input_tp','input_lra','input_thresh']:assert k in data
    def val(k):return None if data[k]=='-inf' else float(data[k])
    return dict(i=val('input_i'),tp=val('input_tp'),lra=val('input_lra'),raw=data)

def audio_graph(source,ranges=None,pre='',post='',audio=1):
    meta=m.probe(source);duration=e.exact_duration(m.vstream(meta));ranges=ranges or [(F(0),duration)]
    graph,d,parts=e.graph(meta,ranges,audio)
    video,ag=graph.split(';',1)
    if pre:ag=ag.replace(f'[0:{audio}]',f'[0:{audio}]'+pre+',',1)
    if post:ag=ag.replace('[aout]',','+post+'[aout]')
    return video,ag,d,meta,parts

def render_voice(source,out,pre='',post='',ranges=None,target=-18.0,peak=-1.5,normalize=True,limit=True,force_limiter=False,audio=1,stem=False):
    before_hash=hashlib.sha256(source.read_bytes()).hexdigest()
    vg,ag,d,meta,parts=audio_graph(source,ranges,pre,post,audio)
    measured=measure(source,ag)
    desired=target-measured['i'] if normalize and measured['i'] is not None else 0.0
    if abs(desired)<=.5:desired=0.0
    gain=max(-24,min(12,desired))
    ceiling=peak-.7
    if limit and measured['tp'] is not None:gain=max(-24,min(gain,ceiling-measured['tp']))
    limiter_on=limit and (force_limiter or measured['tp'] is not None and measured['tp']+gain>ceiling-.05)
    a=next(s for s in meta['streams'] if s['index']==audio);rate=int(a['sample_rate']);layout=a.get('channel_layout') or ('mono' if a['channels']==1 else 'stereo')
    correction_passes=0
    while True:
        tail=[]
        if abs(gain)>1e-6:tail.append(f'volume={num(gain)}dB')
        if limiter_on:tail.append(filt('LIMITER_FILTER',limit=num(10**(ceiling/20)),rate=rate))
        tail += [f'aformat=sample_rates={rate}:channel_layouts={layout}',f'apad=whole_len={e.ceil(d*rate)},atrim=end_sample={e.ceil(d*rate)}']
        final=ag.replace('[aout]',','+','.join(tail)+'[aout]')
        args=[m.FFMPEG,*m.prefix('EDITED_PREFIX','edit_render.rs'),'-threads','2',*m.prefix('INPUT_POLICY','plan.rs'),'-i',str(source),'-filter_complex_threads','1','-filter_complex',final if stem else vg+';'+final]
        if not stem:
            fr=F(m.vstream(meta)['r_frame_rate']);bsf=e.substitute(e.template('DURATION_BSF'),num=fr.numerator,den=fr.denominator)
            args+=['-map','[vout]','-map','[aout]','-c:v','libx264','-crf','18','-pix_fmt','yuv420p','-threads:v','2','-fps_mode:v','passthrough','-enc_time_base:v','1/1000000','-bsf:v',bsf,'-c:a','aac','-b:a','192k','-t',str(float(d)),'-metadata:s:v:0','rotate=0','-avoid_negative_ts','disabled','-movflags','+faststart','-f','mp4']
        else:args+=['-map','[aout]','-vn','-c:a','pcm_s24le','-rf64','auto','-f','wav']
        args+=['-sn','-dn','-map_metadata','-1','-threads:a','1',str(out)]
        m.execute(args)
        info=m.probe(out,head=False);oa=m.streams(info,'audio')[0]
        assert oa['channels']==a['channels'] and oa['sample_rate']==a['sample_rate'],(a,oa)
        assert oa.get('channel_layout',layout)==layout,(layout,oa)
        od=F(oa.get('duration') or info['format']['duration']);assert abs(float(od-d))<.051,(od,d)
        m.execute([m.FFMPEG,'-v','error','-nostdin','-xerror','-i',str(out),'-f','null','-'])
        checked=measure(out,stream=oa['index'])
        if not limit or checked['tp'] is None or checked['tp']<=peak+.05:break
        assert correction_passes<2,checked
        gain-=checked['tp']-peak+.3
        assert gain>=-24,'accepted attenuation limit'
        correction_passes+=1
    assert hashlib.sha256(source.read_bytes()).hexdigest()==before_hash
    return dict(input=measured,output=checked,gain=gain,limited=limiter_on,correction_passes=correction_passes,duration=float(d),sample_rate=rate,channels=a['channels']),final

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,default=ROOT/'reports/step5-media-final.json');ap.add_argument('--samples',action='store_true');args=ap.parse_args()
    results=[]
    def check(name,fn):
        started=time.monotonic()
        try:detail=fn();results.append(dict(name=name,passed=True,seconds=round(time.monotonic()-started,3),detail=detail))
        except CapabilityUnavailable as ex:results.append(dict(name=name,status='blocked',reason=str(ex)));print('BLOCKED',name,str(ex))
        except Exception as ex:results.append(dict(name=name,passed=False,seconds=round(time.monotonic()-started,3),error=str(ex)));print('FAIL',name,str(ex)[:220])
    with tempfile.TemporaryDirectory(prefix='video-voice-media-') as temp:
        d=Path(temp);base=d/'normal.mov';fixture(base)
        def basic():
            r,g=render_voice(base,d/'normalized.mp4');assert abs(r['output']['i']+18)<.7,r;return r
        check('measured_linear_gain_reaches_target_on_clean_signal',basic)
        check('PCM24_stem_has_selected_rate_layout_and_timing',lambda:render_voice(base,d/'stem.wav',stem=True)[0])
        def off():
            _,ag,_,_,_=audio_graph(base);a=process_audio(base,d/'off.wav','');b=pcm(base);assert a==b;return {'decoded_samples_identical':len(a),'graph_has_no_treatment':not any(s in ag for s in ['highpass','afftdn','volume','alimiter'])}
        check('bypass_preserves_decoded_samples',off)
        dc=d/'dc.mov';fixture(dc,'0.05+0.1*sin(2*PI*440*t)')
        def dc_test():
            before=pcm(dc);after=process_audio(dc,d/'dc.wav',template('DC_FILTER'));mean=math.fsum(after[48000:])/len(after[48000:]);assert abs(mean)<1e-4,mean;assert abs(math.fsum(before)/len(before))>.04;return {'remaining_dc':mean}
        check('DC_highpass_removes_offset_without_mean_subtraction_downmix',dc_test)
        low=d/'rumble.mov';fixture(low,'0.1*sin(2*PI*20*t)+0.1*sin(2*PI*440*t)')
        def rumble():
            before=pcm(low);after=process_audio(low,d/'rumble.wav',filt('RUMBLE_FILTER',frequency=70));reduction=db(amplitude(after,20)/amplitude(before,20));voice=db(amplitude(after,440)/amplitude(before,440));assert reduction<-15 and abs(voice)<.3,(reduction,voice);return {'rumble_change_db':reduction,'440Hz_change_db':voice}
        check('low_frequency_cleanup_restrains_voice_band_loss',rumble)
        for hz in [50,60]:
            p=d/f'hum{hz}.mov';fixture(p,f'0.05*sin(2*PI*{hz}*t)+0.03*sin(2*PI*{hz*2}*t)+0.1*sin(2*PI*440*t)')
            def hum(p=p,hz=hz):
                a=pcm(p);b=process_audio(p,d/f'hum{hz}.wav',','.join(filt('HUM_FILTER',frequency=hz*n,q=30) for n in [1,2]));changes=[db(amplitude(b,f)/amplitude(a,f)) for f in [hz,hz*2,440]];assert changes[0]<-20 and changes[1]<-20 and abs(changes[2])<.2,changes;return changes
            check(f'{hz}Hz_and_harmonic_notches_preserve_unrelated_tone',hum)
        def denoise():
            p=d/'noise.mov';fixture(p,'if(between(t,2,4),0,0.1*sin(2*PI*440*t))+0.005*(2*random(0)-1)')
            a=pcm(p);b=process_audio(p,d/'noise.wav',filt('DENOISE_FILTER',reduction=6,floor=-50));change=db(rms(b[120000:168000])/rms(a[120000:168000]));assert change<-.5,change;assert len(a)==len(b),(len(a),len(b));return {'quiet_region_change_db':change,'sample_count':len(b)}
        check('traditional_noise_reduction_on_explicit_noise_fixture',denoise)
        def eq():
            p=d/'eq.mov';fixture(p,'0.1*sin(2*PI*3000*t)');a=pcm(p);b=process_audio(p,d/'eq.wav',filt('EQ_FILTER',gain=num(1.5)));gain=db(rms(b[48000:])/rms(a[48000:]));assert abs(gain-1.5)<.1,gain;return gain
        check('bounded_presence_equalizer_gain',eq)
        def deess():
            p=d/'sibilant.mov';fixture(p,'0.2*sin(2*PI*7000*t)+0.02*sin(2*PI*220*t)');a=pcm(p);b=process_audio(p,d/'deess.wav',filt('DEESS_FILTER',intensity=num(.25),amount=num(.4)));assert len(a)==len(b);assert all(math.isfinite(v) for v in b);assert rms(b)<rms(a);return {'change_db':db(rms(b)/rms(a))}
        check('deesser_attenuates_high_frequency_test_signal',deess)
        def compressor():
            p=d/'dynamics.mov';fixture(p,'if(lt(t,3),0.03,0.6)*sin(2*PI*440*t)');a=pcm(p);b=process_audio(p,d/'dynamics.wav',filt('COMPRESS_FILTER',threshold=num(10**(-18/20)),ratio=num(2),attack=20,release=200));before=db(rms(a[192000:])/rms(a[48000:96000]));after=db(rms(b[192000:])/rms(b[48000:96000]));assert after<before-3,(before,after);assert len(a)==len(b);return {'range_before_db':before,'range_after_db':after}
        check('restrained_compression_reduces_level_spread',compressor)
        def peak():
            p=d/'peak.mov';fixture(p,'0.95*sin(2*PI*997*t)');r,g=render_voice(p,d/'peak.mp4',normalize=False,force_limiter=True);assert r['output']['tp']<=-1.45 and r['correction_passes']>0;return r
        check('decoded_AAC_true_peak_remains_below_ceiling',peak)
        def limiter():
            p=d/'limit.mov';fixture(p,'0.99*sin(2*PI*997*t)');tail=filt('LIMITER_FILTER',limit=num(10**(-2.2/20)),rate=48000);after=process_audio(p,d/'limit.wav',tail);a=pcm(p);assert len(after)==len(a),(len(after),len(a));assert db(max(map(abs,after)))<-2;return {'peak_dbfs':db(max(map(abs,after))),'samples':len(after)}
        check('lookahead_limiter_disables_auto_makeup_and_compensates_latency',limiter)
        def impulse():
            p=d/'impulse.mov';fixture(p,'if(eq(n,48000),0.99,0)');a=pcm(p);b=process_audio(p,d/'impulse.wav',filt('LIMITER_FILTER',limit=num(.75),rate=48000));i=max(range(len(a)),key=lambda n:abs(a[n]));j=max(range(len(b)),key=lambda n:abs(b[n]));assert abs(i-j)<=1,(i,j);return {'sample_offset':j-i}
        check('limiter_impulse_does_not_shift_audio_time',impulse)
        silent=d/'silence.mov';fixture(silent,'0')
        def silence():
            r,g=render_voice(silent,d/'silence.mp4');assert r['gain']==0 and r['output']['i'] is None;return r
        check('silence_does_not_produce_infinite_gain',silence)
        def short():
            p=d/'short.mov';fixture(p,seconds=.1);r,g=render_voice(p,d/'short.mp4');assert r['gain']==0;return r
        check('very_short_signal_has_no_invented_integrated_loudness',short)
        def cut():
            p=d/'levels.mov';fixture(p,'if(lt(t,3),0.02,0.2)*sin(2*PI*440*t)');whole=render_voice(p,d/'whole.mp4')[0];cut=render_voice(p,d/'cut.mp4',ranges=[(F(0),F(2))])[0];assert cut['gain']>whole['gain']+3,(whole,cut);return {'whole_gain':whole['gain'],'after_cut_gain':cut['gain']}
        check('normalization_measures_edited_content_not_original_duration',cut)
        def chain():
            pre=','.join([template('DC_FILTER'),filt('RUMBLE_FILTER',frequency=70),filt('DENOISE_FILTER',reduction=3,floor=-55)])
            post=','.join([filt('EQ_FILTER',gain=num(1)),filt('DEESS_FILTER',intensity=num(.1),amount=num(.2)),filt('COMPRESS_FILTER',threshold=num(.1259),ratio=num(1.8),attack=20,release=200)])
            return render_voice(dc,d/'chain.mp4',pre,post,[(F(0),F(1)),(F(2),F(5))],force_limiter=True)[0]
        check('complete_cleanup_cut_loudness_chain_renders_valid_video',chain)
        for rate in [44100,48000,96000]:
            def rate_test(rate=rate):
                p=d/f'rate{rate}.mov';fixture(p,rate=rate,seconds=2);r,g=render_voice(p,d/f'rate{rate}.mp4',force_limiter=True);assert r['sample_rate']==rate;return r
            check(f'{rate}Hz_sample_rate_survives_oversampling',rate_test)
        for layout,ch in [('mono',1),('stereo',2),('5.1',6)]:
            def layout_test(layout=layout,ch=ch):
                p=d/f'layout{ch}.mov';expr='|'.join(f'{.03/(n+1)}*sin(2*PI*{300+n*170}*t)' for n in range(ch));fixture(p,expr,seconds=2,layout=layout);r,g=render_voice(p,d/f'layout{ch}.mp4',pre=template('DC_FILTER'),force_limiter=True);assert r['channels']==ch;return r
            check(f'{layout}_channel_layout_is_preserved',layout_test)
        def stereo_opposite():
            p=d/'opposite.mov';fixture(p,'0.1*sin(2*PI*440*t)|-0.1*sin(2*PI*440*t)',layout='stereo');r,g=render_voice(p,d/'opposite.wav',stem=True);a=pcm(d/'opposite.wav');assert rms(a)>.01;cor=max(abs(a[n]+a[n+1]) for n in range(0,len(a),2));assert cor<1e-5,cor;return {'opposite_channel_residual':cor}
        check('no_polarity_cancelling_analysis_downmix',stereo_opposite)
        def imbalance():
            p=d/'imbalance.mov';fixture(p,'0.1*sin(2*PI*440*t)|0.01*sin(2*PI*440*t)',layout='stereo');r,g=render_voice(p,d/'imbalance.wav',stem=True);a=pcm(d/'imbalance.wav');ratio=db(rms(a[0::2])/rms(a[1::2]));assert abs(ratio-20)<.1,ratio;return {'level_difference_db':ratio}
        check('channel_imbalance_is_not_silently_corrected',imbalance)
        def selected():
            p=d/'two-audio.mov';m.execute([m.FFMPEG,'-v','error','-y','-i',str(base),'-f','lavfi','-i','sine=frequency=997:duration=6:sample_rate=48000','-map','0:v:0','-map','0:a:0','-map','1:a:0','-c:v','copy','-c:a','pcm_f32le',str(p)]);r,g=render_voice(p,d/'second.wav',audio=2,stem=True);a=pcm(d/'second.wav');assert amplitude(a,997)>amplitude(a,440)*100;return {'stream_index':2}
        check('explicit_second_audio_stream_is_processed',selected)
        def weird():
            p=d/'space {voice} ü.mov';shutil.copy2(base,p);r,g=render_voice(p,d/'output {voice} ü.mp4');return r
        check('spaces_unicode_and_braces_in_paths',weird)
        def clipped():
            p=d/'clipped.mov';fixture(p,'clip(1.5*sin(2*PI*440*t),-1,1)');a=pcm(p);count=sum(abs(x)>=.999 for x in a);assert count>1000;return {'near_full_scale_samples':count,'not_reconstructed':True}
        check('clipped_fixture_exposes_warning_evidence_not_recovery_claim',clipped)
        for rate in [8000,44100,48000,96000]:
            def denoise_sync(rate=rate):
                p=d/f'noise-sync-{rate}.mov'
                fixture(p,f'if(between(n,{rate},{rate+rate//50-1}),0.6*sin(2*PI*997*t),0)',seconds=3,rate=rate)
                a=pcm(p);b=process_audio(p,d/f'noise-sync-{rate}.wav',filt('DENOISE_FILTER',reduction=6,floor=-50,rate=rate))
                i=next(i for i,x in enumerate(a) if abs(x)>.01);j=next(i for i,x in enumerate(b) if abs(x)>.01)
                assert len(a)==len(b) and abs(j-i)<=2,(len(a),len(b),i,j)
                return {'source_onset_sample':i,'processed_onset_sample':j,'offset_samples':j-i,'samples':len(b)}
            check(f'denoise_latency_compensated_at_{rate}Hz',denoise_sync)
        def denoise_tail():
            p=d/'tail.mov';fixture(p,'if(gt(n,143040),0.5*sin(2*PI*997*t),0)',seconds=3)
            a=pcm(p);b=process_audio(p,d/'tail.wav',filt('DENOISE_FILTER',reduction=3,floor=-70))
            assert len(a)==len(b) and rms(b[-480:])>rms(a[-480:])*.8
            return {'source_tail_rms':rms(a[-480:]),'processed_tail_rms':rms(b[-480:]),'samples':len(b)}
        check('denoiser_flush_retains_final_10ms_not_just_duration',denoise_tail)
        def tiny_denoise():
            p=d/'tiny.mov';fixture(p,'0.1*sin(2*PI*997*t)',seconds=.01)
            a=pcm(p);b=process_audio(p,d/'tiny.wav',filt('DENOISE_FILTER',reduction=3,floor=-70))
            assert len(a)==len(b) and rms(b)>.04,(len(a),len(b),rms(b))
            return {'input_samples':len(a),'output_samples':len(b),'processed_rms':rms(b)}
        check('audio_shorter_than_denoise_delay_is_not_lost',tiny_denoise)
        def delayed():
            p=d/'delayed.mov'
            m.execute([m.FFMPEG,'-v','error','-y','-i',str(base),'-itsoffset','0.4','-i',str(base),'-map','0:v:0','-map','1:a:0','-c','copy',str(p)])
            r,g=render_voice(p,d/'delayed.wav',pre=filt('DENOISE_FILTER',reduction=3,floor=-70),stem=True)
            a=pcm(d/'delayed.wav');first=next(i for i,x in enumerate(a) if abs(x)>.01)
            assert abs(first/48000-.4)<.002,first
            return {'first_audio_seconds':first/48000,'duration':r['duration']}
        check('denoise_preserves_selected_audio_start_offset',delayed)
        def joined_sync():
            p=d/'sync.mov'
            m.execute([m.FFMPEG,'-v','error','-y','-f','lavfi','-i',"color=c=black:s=160x96:r=30:d=4,drawbox=c=white:t=fill:enable='between(t,2,2.08)'",'-f','lavfi','-i',"aevalsrc=exprs='if(between(t,2,2.08),0.4*sin(2*PI*997*t),0)':s=48000:d=4",'-c:v','libx264','-pix_fmt','yuv420p','-threads','2','-c:a','pcm_f32le',str(p)])
            out=d/'sync.mp4';r,g=render_voice(p,out,pre=filt('DENOISE_FILTER',reduction=3,floor=-70),ranges=[(F(0),F(1)),(F(3,2),F(4))])
            a=pcm(out);onset=next(i for i,x in enumerate(a) if abs(x)>.01)/48000
            raw=m.execute([m.FFMPEG,'-v','error','-i',str(out),'-vf','scale=1:1','-pix_fmt','gray','-f','rawvideo','-'])
            # Read actual decoded frame timestamps, not nominal frame-number timing.
            frames=json.loads(m.execute([m.FFPROBE,'-v','error','-select_streams','v:0','-show_frames','-show_entries','frame=best_effort_timestamp_time','-of','json',str(out)]))['frames']
            flash=next(float(frames[i]['best_effort_timestamp_time']) for i,x in enumerate(raw) if x>180)
            assert abs(onset-flash)<.006,(onset,flash)
            return {'audio_onset_seconds':onset,'decoded_flash_seconds':flash,'difference_seconds':onset-flash}
        check('cleanup_plus_cut_preserves_decoded_flash_tone_sync',joined_sync)
        for layout,ch in [('5.1(side)',6),('7.1',8),('quad',4)]:
            def surround(layout=layout,ch=ch):
                p=d/f'surround{ch}.mov';fixture(p,'|'.join(f'.01*sin(2*PI*{300+180*i}*t)' for i in range(ch)),seconds=2,layout=layout)
                r,g=render_voice(p,d/f'surround{ch}.mp4',force_limiter=True);assert r['channels']==ch;return r
            check(f'{layout}_layout_survives_AAC_not_just_channel_count',surround)
        # Formant speech is a synthetic test signal, not a human listening panel.
        def prepare_formant_speech():
            speech=d/'formant.wav'
            executable=shutil.which('espeak')
            if not executable:raise CapabilityUnavailable('espeak speech fixture generator is unavailable')
            m.execute([executable,'-w',str(speech),'-s','155',
                       'This is a synthetic voice recording for an audio processing test. '
                       'Keep the quiet words, breaths, and timing. The original file must remain unchanged.'])
            speech_source=d/'formant-noisy.mov'
            speech_len=float(m.probe(speech,head=False)['format']['duration'])
            m.execute([m.FFMPEG,'-v','error','-nostdin','-y','-f','lavfi','-i',
                       f'testsrc2=size=160x96:rate=30:duration={speech_len}',
                       '-i',str(speech),'-f','lavfi','-i',
                       f'aevalsrc=exprs=0.015+0.008*sin(2*PI*50*t)+0.004*sin(2*PI*100*t)+0.002*(2*random(0)-1):s=48000:d={speech_len}',
                       '-filter_complex_threads','1','-filter_complex',
                       '[1:a]aresample=48000,volume=0.7[v];[v][2:a]amix=inputs=2:duration=longest:normalize=0[a]',
                       '-map','0:v:0','-map','[a]','-c:v','libx264','-pix_fmt','yuv420p','-threads','2','-c:a','pcm_f32le',str(speech_source)])
            speech_pre=','.join([template('DC_FILTER'),filt('RUMBLE_FILTER',frequency=70),
                filt('HUM_FILTER',frequency=50,q=30),filt('HUM_FILTER',frequency=100,q=30),
                filt('DENOISE_FILTER',reduction=3,floor=-55)])
            return speech_source,speech_pre
        def formant_speech():
            speech_source,speech_pre=prepare_formant_speech()
            report,g=render_voice(speech_source,d/'formant-cleaned.mp4',pre=speech_pre)
            assert report['output']['i'] is not None and report['output']['tp']<=-1.45
            assert report['duration']>4 and report['channels']==1
            return {'signal':'formant-synthesized speech with added noise/hum/DC, not recorded human speech',
                    'render':report,'human_listening_performed':False}
        check('formant_speech_with_noise_hum_and_DC_renders_with_peak_and_sync_checks',formant_speech)
        def breathlike():
            p=d/'breathlike.mov'
            fixture(p,'if(between(t,1,1.4),0.015*(2*random(0)-1),if(between(t,2,3),0.05*sin(2*PI*440*t),0))',seconds=4)
            before=pcm(p);after=process_audio(p,d/'breathlike.wav',filt('DENOISE_FILTER',reduction=3,floor=-55))
            retained=rms(after[50400:64800])/rms(before[50400:64800])
            assert len(before)==len(after) and .2<retained<1.5,retained
            return {'synthetic_noise_burst_retained_rms_ratio':retained,'no_speech_detection_or_perceptual_claim':True}
        check('synthetic_breathlike_burst_is_not_hard_gated',breathlike)
        def corrupt():
            p=d/'bad.mov';p.write_bytes(b'not media');x=subprocess.run([m.FFMPEG,'-v','error','-xerror','-i',str(p),'-f','null','-'],stdout=subprocess.PIPE,stderr=subprocess.PIPE);assert x.returncode!=0;return {'exit':x.returncode}
        check('corrupt_media_fails_decode',corrupt)
        def cancel():
            p=subprocess.Popen([m.FFMPEG,'-v','error','-nostdin','-re','-stream_loop','-1','-i',str(base),'-af',template('DC_FILTER'),'-f','null','-'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL);time.sleep(.1);p.terminate();p.wait(timeout=3);assert p.returncode!=0;return {'terminated':True}
        check('real_FFmpeg_audio_job_can_be_terminated',cancel)
        if args.samples:
            sd=ROOT/'samples';sd.mkdir(exist_ok=True)
            source,speech_pre=prepare_formant_speech()
            out=d/'voice-cleaned.mp4';report,g=render_voice(source,out,pre=speech_pre)
            report['fixture']='formant-synthesized speech plus added noise/hum/DC; no human listening performed'
            report['generated_by']='independent FFmpeg recipe harness, not the uncompiled Rust adapter'
            m.execute([m.FFMPEG,'-v','error','-y','-i',str(source),'-c:v','copy','-c:a','aac',str(sd/'voice-original.mp4')]);shutil.copy2(out,sd/'voice-cleaned.mp4');(sd/'voice-example-report.json').write_text(json.dumps(report,indent=2)+'\n')
    report=dict(kind='independent_ffmpeg_audio_recipes_not_rust_execution',ffmpeg=m.execute([m.FFMPEG,'-version']).decode().splitlines()[0],tests=results,passed=sum(r.get('passed') is True for r in results),failed=sum(r.get('passed') is False for r in results),blocked=sum(r.get('status')=='blocked' for r in results),human_listening_performed=False)
    args.output.parent.mkdir(parents=True,exist_ok=True);args.output.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'passed':report['passed'],'failed':report['failed']}));return int(report['failed']!=0)
if __name__=='__main__':raise SystemExit(main())
