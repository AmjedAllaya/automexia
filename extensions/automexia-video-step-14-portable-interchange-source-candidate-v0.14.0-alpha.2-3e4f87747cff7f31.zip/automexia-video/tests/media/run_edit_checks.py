#!/usr/bin/env python3
"""Independent FFmpeg cut-recipe integration checks on encoded media.

Reads filter templates from Rust. Does NOT compile/run Rust, invoke MediaHost or
prove project serialization/lifecycle. Cargo projects/native_projects test those.
Python remains test-only; no Python dependency is introduced into the extension.
"""
from __future__ import annotations
import argparse, hashlib, json, os, re, subprocess, tempfile, time
from fractions import Fraction as F
from pathlib import Path
import run_media_checks as m
ROOT=m.ROOT

def template(name):
    text=(ROOT/'src/edit_render.rs').read_text()
    match=re.search(r'pub const '+name+r'\s*:\s*&str\s*=\s*("(?:[^"\\]|\\.)*");',text)
    if not match: raise AssertionError('Missing Rust literal '+name)
    return json.loads(match.group(1))

def substitute(text,**values):
    for key,value in values.items(): text=text.replace('{'+key+'}',str(value))
    return text

def ceil(r): return -(-r.numerator//r.denominator)
def exact_start(s):return F(s['start_pts'])*F(s['time_base']) if 'start_pts' in s else F(s['start_time'])
def exact_duration(s):return F(s['duration_ts'])*F(s['time_base']) if 'duration_ts' in s else F(s['duration'])

def graph(metadata,ranges,audio=1):
    v=m.vstream(metadata);origin=exact_start(v);duration=exact_duration(v);tb=F(v["time_base"])
    a=next((s for s in metadata['streams'] if s['index']==audio),None) if audio is not None else None
    rate=int(a['sample_rate']) if a else None;scale=rate or 1000000
    units=0;parts=[]
    for start,end in ranges:
        start,end=F(start),F(end)
        assert 0<=start<end<=duration
        if parts: assert start>=parts[-1]['original_end']
        x,y=ceil(start*scale),ceil(end*scale)
        assert x<y
        start_pts,end_pts=ceil((origin+start)/tb),ceil((origin+end)/tb)
        def nearest(r):
            return (r.numerator+r.denominator//2)//r.denominator if r>=0 else -((-r.numerator+r.denominator//2)//r.denominator)
        parts.append(dict(start_pts=start_pts,end_pts=end_pts,start=nearest(start_pts*tb*1000000),end=nearest(end_pts*tb*1000000),input_start=nearest((origin+start)*1000000),output=ceil(F(units,scale)*1000000),a=x,b=y,original_end=end))
        units+=y-x
    select='+'.join(substitute(template('VIDEO_PREDICATE'),start=s['start_pts'],end=s['end_pts']) for s in parts)
    mapping='PTS+'+'+'.join(substitute(template('VIDEO_SHIFT'),start=s['start'],end=s['end'],shift=s['output']-s['input_start']) for s in parts)
    full=v.get('color_range')=='pc' or v.get('pix_fmt','').startswith('yuvj')
    g=substitute(template('VIDEO_BASE'),video=v['index'],origin_us=ceil(origin*1000000),select=select,mapping=mapping,color=',scale=in_range=pc:out_range=pc' if full else '')
    if a:
        source_samples=ceil(duration*rate)
        g+=';'+substitute(template('AUDIO_BASE'),audio=audio,origin_num=origin.numerator,origin_den=origin.denominator,rate=rate,source_samples=source_samples)
        if len(parts)==1: g+='[a0]'
        else: g+=',asplit='+str(len(parts))+''.join('[a%d]'%i for i in range(len(parts)))
        for i,s in enumerate(parts):g+=';'+substitute(template('AUDIO_TRIM'),index=i,start=s['a'],end=s['b'])
        g+=';'+''.join('[t%d]'%i for i in range(len(parts)))+('anull[aout]' if len(parts)==1 else 'concat=n=%d:v=0:a=1[aout]'%len(parts))
    return g,F(units,scale),parts

def edit(source,out,ranges,audio=1,cfr=None):
    before=hashlib.sha256(source.read_bytes()).hexdigest()
    metadata=m.probe(source);g,duration,parts=graph(metadata,ranges,audio)
    args=m.prefix('EDITED_PREFIX','edit_render.rs')+['-threads','2']+m.prefix('INPUT_POLICY','plan.rs')+['-i',str(source),'-filter_complex_threads','1','-filter_complex',g,'-map','[vout]']
    args+=['-map','[aout]'] if audio is not None else ['-an']
    args+=['-map_metadata','-1','-map_chapters','-1','-sn','-dn','-c:v','libx264','-preset','medium','-crf','18','-pix_fmt','yuv420p','-threads:v','2']
    if cfr:
        r=F(cfr);args+=['-fps_mode:v','cfr','-r:v',f'{r.numerator}/{r.denominator}','-enc_time_base:v',f'{r.denominator}/{r.numerator}']
    else:
        rate=F(m.vstream(metadata).get('r_frame_rate') or m.vstream(metadata)['avg_frame_rate'])
        bsf=substitute(template('DURATION_BSF'),num=rate.numerator,den=rate.denominator)
        args+=['-fps_mode:v','passthrough','-enc_time_base:v','1/1000000','-bsf:v',bsf]
    colors=[(flag,m.vstream(metadata)[field]) for flag,field in [('-colorspace','color_space'),('-color_trc','color_transfer'),('-color_primaries','color_primaries'),('-color_range','color_range')] if m.vstream(metadata).get(field) not in [None,'unknown','unspecified']]
    if colors:args+=['-x264-params','videoformat=component']
    for flag,value in colors:args += [flag,value]
    if audio is not None:args+=['-c:a','aac','-b:a','192k','-threads:a','1']
    us=ceil(duration*1000000)
    args+=['-t',f'{us//1000000}.{us%1000000:06}','-metadata:s:v:0','rotate=0','-avoid_negative_ts','disabled','-movflags','+faststart','-progress','pipe:1','-nostats','-f','mp4',str(out)]
    progress=m.execute([m.FFMPEG,*args]);assert b'progress=end' in progress
    assert hashlib.sha256(source.read_bytes()).hexdigest()==before
    result=m.probe(out)
    for flag,value in colors:
        field={'-colorspace':'color_space','-color_trc':'color_transfer','-color_primaries':'color_primaries','-color_range':'color_range'}[flag]
        assert m.vstream(result).get(field)==value,(field,value,m.vstream(result).get(field))
    assert abs(float(exact_duration(m.vstream(result))-duration))<.1,(exact_duration(m.vstream(result)),duration)
    if audio is not None:
        assert len(m.streams(result,'audio'))==1
        assert abs(float(exact_duration(m.streams(result,'audio')[0])-duration))<.05
    m.execute([m.FFMPEG,*m.prefix('DECODE_PREFIX','host.rs'),str(out),'-map','0:v:0',*(['-map','0:a:0'] if audio is not None else []),'-f','null','-'])
    return result,duration,parts,g

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,required=True);parser.add_argument('--keep',type=Path);parser.add_argument('--update-fixtures',action='store_true');args=parser.parse_args()
    results=[]
    with tempfile.TemporaryDirectory(prefix='video-step2-') as temp:
        work=Path(temp) if args.keep is None else args.keep
        work.mkdir(parents=True,exist_ok=True)
        base=work/'base.mp4';m.fixture(base,duration='4',rate='30')
        def case(name,fn):
            t=time.monotonic()
            try:detail=fn() or {};results.append(dict(name=name,status='passed',seconds=round(time.monotonic()-t,3),details=detail));print('PASS',name,flush=True)
            except Exception as e:results.append(dict(name=name,status='failed',error=str(e)));print('FAIL',name,str(e),flush=True)
        def simple():
            out=work/'trim.mp4';d,length,_,_=edit(base,out,[('1/2','5/2')]);assert len(m.frames(out))==60
            return {'duration_s':str(length),'frames':60}
        case('single_trim_real_audio_video',simple)
        def cuts():
            out=work/'cuts.mp4';d,length,_,_=edit(base,out,[('0','1'),('2','3')]);assert len(m.frames(out))==60
            assert len(m.pcm(out))/48000>=float(length)-.01
            return {'duration_s':str(length),'frames':60}
        case('two_ranges_audio_video_same_timeline',cuts)
        def vfr():
            src=work/'vfr.mp4';m.fixture(src,rate='30',duration='4',video_filter="select='not(eq(mod(n,5),1))'",extra=['-fps_mode','vfr'])
            out=work/'vfr-cut.mp4';d,length,parts,_=edit(src,out,[('0','1'),('2','3')])
            source_times=m.frames(src);expected=[]
            for a,b,o in [(F(0),F(1),F(0)),(F(2),F(3),F(1))]:expected += [t-a+o for t in source_times if a<=t<b]
            actual=m.frames(out);assert len(actual)==len(expected),(len(actual),len(expected))
            maximum=max(abs(float(a-b)) for a,b in zip(actual,expected));assert maximum<.001,maximum
            return {'frames':len(actual),'max_timestamp_error_s':maximum}
        case('vfr_cuts_keep_frame_count_and_mapped_pts',vfr)
        def silent():
            src=work/'no-audio.mp4';m.fixture(src,audio=False,duration='4',rate='30');out=work/'silent-cut.mp4';d,_,_,_=edit(src,out,[('1/2','1'),('2','3')],audio=None);assert not m.streams(d,'audio')
        case('video_only_cuts',silent)
        def fractional():
            src=work/'fractional.mp4';m.fixture(src,rate='30000/1001',duration='4');out=work/'fractional-cut.mp4'
            ranges=[(F(7*1001,30000),F(20*1001,30000)),(F(37*1001,30000),F(63*1001,30000))]
            d,length,parts,_=edit(src,out,ranges);assert abs(float(exact_duration(m.streams(d,'audio')[0])-length))<.025
            return {'requested':[list(map(str,x)) for x in ranges],'effective_duration_s':str(length),'frames':len(m.frames(out))}
        case('fractional_rate_and_sample_quantized_cut_boundaries',fractional)
        def exact_boundary():
            out=work/'frame-boundary.mp4';d,_,_,_=edit(base,out,[(F(1,30),F(20,30))]);times=m.frames(out)
            assert len(times)==19,len(times)
            assert abs(float(times[0]))<.00005,('first retained frame was skipped',str(times[0]))
            return {'first_frame_s':str(times[0]),'frame_count':len(times)}
        case('exact_first_frame_boundary_must_not_skip_frame',exact_boundary)

        def constant():
            out=work/'24fps.mp4';d,_,_,_=edit(base,out,[('0','1'),('2','3')],cfr='24');assert F(m.vstream(d)['avg_frame_rate'])==24
        case('explicit_cfr_after_cuts',constant)
        def delayed():
            src=work/'delayed.mp4';m.execute([m.FFMPEG,'-v','error','-y','-i',base,'-itsoffset','0.35','-i',base,'-map','0:v','-map','1:a','-c','copy',src]);out=work/'delayed-cut.mp4';edit(src,out,[('0','1'),('2','3')]);pcm=m.pcm(out)
            rms=lambda a:(sum(x*x for x in a)/max(1,len(a)))**.5
            assert rms(pcm[:12000])<10,rms(pcm[:12000]);assert rms(pcm[20000:25000])>100
        case('late_audio_is_padded_not_pulled_forward',delayed)
        def late_video():
            src=work/'late-video.mp4';m.execute([m.FFMPEG,'-v','error','-y','-itsoffset','0.25','-i',base,'-i',base,'-map','0:v','-map','1:a','-c','copy',src]);out=work/'late-video-cut.mp4'
            d,length,_,_=edit(src,out,[('0','1'),('2','3')]);assert abs(float(exact_start(m.vstream(d))))<.001
            assert abs(m.frequency(out)-440)<8
        case('video_origin_shared_with_earlier_audio',late_video)
        def forty_four():
            src=work/'44100.mp4';m.execute([m.FFMPEG,'-v','error','-y','-i',base,'-c:v','copy','-c:a','aac','-ar','44100',src]);out=work/'44100-cut.mp4'
            d,length,_,_=edit(src,out,[(F(1,30),F(2,3)),(F(31,30),F(7,3))]);assert m.streams(d,'audio')[0]['sample_rate']=='44100'
            assert abs(float(exact_duration(m.streams(d,'audio')[0])-length))<.025
        case('44100_hz_sample_timeline',forty_four)

        def shortaudio():
            src=work/'short-audio.mp4';m.execute([m.FFMPEG,'-v','error','-y','-i',base,'-f','lavfi','-i','sine=frequency=440:sample_rate=48000:duration=1','-map','0:v','-map','1:a','-c:v','copy','-c:a','aac',src]);out=work/'short-audio-cut.mp4';edit(src,out,[('0','1'),('2','3')]);pcm=m.pcm(out)
            tail=pcm[60000:80000];assert sum(abs(x) for x in tail)/len(tail)<5
        case('short_audio_tail_is_silence_not_desync',shortaudio)
        def second():
            src=work/'second.mp4';m.execute([m.FFMPEG,'-v','error','-y','-i',base,'-f','lavfi','-i','sine=frequency=880:sample_rate=48000:duration=4','-map','0:v','-map','0:a','-map','1:a','-c:v','copy','-c:a','aac',src]);out=work/'second-cut.mp4';edit(src,out,[('0','1'),('2','3')],audio=2);assert abs(m.frequency(out)-880)<8
        case('explicit_second_audio_survives_edit_assembly',second)
        def rotation():
            src=work/'rotation.mov';m.execute([m.FFMPEG,'-v','error','-y','-display_rotation','90','-i',base,'-c','copy',src]);out=work/'rotation-cut.mp4';d,_,_,_=edit(src,out,[('0','1'),('2','3')]);assert (m.vstream(d)['width'],m.vstream(d)['height'])==(96,160)
            def frame(p):return m.execute([m.FFMPEG,'-v','error','-i',p,'-frames:v','1','-pix_fmt','rgb24','-f','rawvideo','-'])
            a,b=frame(src),frame(out);assert len(a)==len(b);assert sum(abs(x-y) for x,y in zip(a,b))/len(a)<8
        case('rotated_cut_pixels_and_metadata',rotation)
        def sar():
            src=work/'sar.mp4';m.fixture(src,duration='4',rate='30',video_filter='setsar=4/3');d,_,_,_=edit(src,work/'sar-cut.mp4',[('0','1'),('2','3')]);assert m.vstream(d)['sample_aspect_ratio']=='4:3'
        case('non_square_pixels_preserved',sar)
        def color():
            src=work/'color.mp4';m.fixture(src,duration='4',rate='30',extra=['-colorspace','bt709','-color_trc','bt709','-color_primaries','bt709','-color_range','tv']);edit(src,work/'color-cut.mp4',[('0','1'),('2','3')])
        case('sdr_color_tags_preserved',color)
        def weird():
            src=work/"source 測試 ; ' $name.mp4";src.write_bytes(base.read_bytes());edit(src,work/"out ' ; test.mp4",[('0','1'),('2','3')])
        case('paths_remain_arguments_not_filter_or_shell_text',weird)
        def many():
            ranges=[(F(i,10),F(i,10)+F(1,20)) for i in range(35)]
            out=work/'many.mp4';d,length,_,_=edit(base,out,ranges);assert abs(float(exact_duration(m.streams(d,'audio')[0])-length))<.025
            return {'cuts':35,'audio_duration_error_s':abs(float(exact_duration(m.streams(d,'audio')[0])-length))}
        case('many_short_cuts_no_cumulative_audio_drift',many)
        def flash():
            src=work/'flash.mp4'
            vf="color=black:size=64x64:rate=30:duration=4,drawbox=x=0:y=0:w=iw:h=ih:color=white:t=fill:enable='between(t,0.5,0.56)+between(t,2.5,2.56)'"
            af=r"aevalsrc=0.4*sin(2*PI*1000*t)*(between(t\,0.5\,0.56)+between(t\,2.5\,2.56)):s=48000:d=4"
            m.execute([m.FFMPEG,'-v','error','-y','-f','lavfi','-i',vf,'-f','lavfi','-i',af,'-c:v','libx264','-threads','2','-pix_fmt','yuv420p','-c:a','aac',src])
            out=work/'flash-cut.mp4';edit(src,out,[('0','1'),('2','3')])
            raw=m.execute([m.FFMPEG,'-v','error','-i',out,'-vf','scale=1:1','-pix_fmt','gray','-f','rawvideo','-']);times=m.frames(out)
            flashes=[float(t) for t,b in zip(times,raw) if b>100]
            pcm=m.pcm(out);onsets=[]
            for i in range(0,len(pcm)-480,480):
                energy=sum(abs(x) for x in pcm[i:i+480])/480
                if energy>1000 and (not onsets or i/48000-onsets[-1]>.15):onsets.append(i/48000)
            assert len(onsets)==2,onsets
            errors=[min(abs(a-v) for v in flashes) for a in onsets];assert max(errors)<.035,errors
            return {'audio_onsets_s':onsets,'maximum_av_error_s':max(errors)}
        case('decoded_flash_tone_sync_after_cut',flash)
        # This exact graph is compared against the Rust builder by a Cargo test.
        meta=json.loads((ROOT/'tests/fixtures/probe-base.json').read_text());g,_,_=graph(meta,[('0','1/2'),('1','2')])
        golden=ROOT/'tests/project_fixtures/edit-filter.txt'
        if args.update_fixtures:golden.write_text(g+'\n')
        else:assert golden.read_text()==g+'\n','Rust filter golden has drifted'
    report={'scope':'independent FFmpeg recipe tests; Rust execution NOT performed','ffmpeg':m.execute([m.FFMPEG,'-version']).decode().splitlines()[0],
            'passed':sum(x['status']=='passed' for x in results),'failed':sum(x['status']=='failed' for x in results),'tests':results}
    args.output.parent.mkdir(parents=True,exist_ok=True);args.output.write_text(json.dumps(report,indent=2)+'\n')
    raise SystemExit(bool(report['failed']))
if __name__=='__main__':main()
