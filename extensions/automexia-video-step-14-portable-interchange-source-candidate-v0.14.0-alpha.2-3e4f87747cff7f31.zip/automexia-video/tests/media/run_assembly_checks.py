#!/usr/bin/env python3
"""Exercise Step 14A assembly recipes on generated media, not Rust execution.

The fixture encodes its source frame index into every pixel and supplies exact
PCM samples. Shared graph literals come from Rust; the dynamic split/trim/tempo
recipe mirrors edit_render.rs. Expected source order, rational duration, output
PTS, repeated impulses, sample totals and source-time graphics are checked after
encoding and independent decoding. No learned model or host is involved.
"""
from __future__ import annotations
import argparse, array, hashlib, json, math, sys, time
from fractions import Fraction as F
from pathlib import Path
import tempfile
import run_media_checks as m
import run_timing_checks as t

RATE=t.RATE
WIDTH,HEIGHT=t.WIDTH,t.HEIGHT

def tempo(speed):
    return {F(1,4):',atempo=0.5,atempo=0.5', F(1,2):',atempo=0.5',
            F(1):'', F(2):',atempo=2.0', F(4):',atempo=2.0,atempo=2.0'}[speed]

def build_graph(source,rate,clips,global_speed=F(1),dissolve_frames=0,markers=False):
    metadata=m.probe(source,head=False);video=m.vstream(metadata)
    tb=F(video['time_base']);origin=F(int(video.get('start_pts',0)))*tb
    duration=F(video['duration_ts'])*tb;dissolve=F(dissolve_frames,1)/rate
    segments=[];cursor=F(0)
    for first,end,clip_speed in clips:
        if segments:cursor-=dissolve
        speed=clip_speed*global_speed;start=F(first,1)/rate;stop=F(end,1)/rate
        length=(stop-start)/speed
        assert length>dissolve and (length*rate).denominator==1
        segments.append((start,stop,cursor,cursor+length,speed));cursor+=length
    prefix='';v='[0:0]'
    if markers:
        # Distinct red graphic and green caption plate lifetimes use the source
        # clock. Actual subtitle shaping/parser behavior is a separate Rust gate.
        on=F(90,1)/rate;off=F(150,1)/rate
        enable=f"gte(t,{float(on):.9f})*lt(t,{float(off):.9f})"
        base=f"[0:0]settb=expr={tb},setpts=PTS-({int(origin/tb)}),settb=expr=1/1000000[pres_base]"
        graphics=f"color=c=black@0.0:s={WIDTH}x{HEIGHT}:r={rate}:d={float(duration):.9f},format=rgba,drawbox=x=0:y=0:w=16:h=16:color=red@1:t=fill:replace=1:enable='{enable}',drawbox=x=0:y=32:w=48:h=14:color=lime@1:t=fill:replace=1:enable='{enable}'[graphic]"
        midpoint=F(120,1)/rate
        phases=f",drawbox=x=20:y=0:w=8:h=8:color=blue@1:t=fill:replace=1:enable='gte(t,{float(on):.9f})*lt(t,{float(midpoint):.9f})',drawbox=x=40:y=0:w=8:h=8:color=blue@1:t=fill:replace=1:enable='gte(t,{float(midpoint):.9f})*lt(t,{float(off):.9f})'"
        graphics=graphics.replace('[graphic]',phases+'[graphic]')
        composite=t.literal('COMPOSITE_GRAPH','presentation_render.rs').replace('{range}','tv').replace('{sar}','1').replace('[1:v]','[graphic]').replace('[vout]','[pres_composed]')
        prefix=f'{base};{graphics};{composite};[pres_composed]settb=expr={tb},setpts=PTS+({int(origin/tb)})[pres_source];';v='[pres_source]'
    count=len(segments);graph=v+'split='+str(count)+''.join(f'[vs{i}]' for i in range(count))
    for i,(start,end,begin,finish,speed) in enumerate(segments):
        frames=(finish-begin)*rate
        graph+=f";[vs{i}]trim=start_pts={t.ceil((origin+start)/tb)}:end_pts={t.ceil((origin+end)/tb)},settb=expr=1/1000000,setpts='(PTS-{t.nearest((origin+start)*1000000)})*{speed.denominator}/{speed.numerator}',fps=fps={rate}:start_time=0:round=near,tpad=stop_mode=clone:stop_duration=1,trim=end_frame={frames.numerator},settb=expr=1/1000000[vt{i}]"
    if dissolve:
        previous='vt0'
        for i in range(1,count):
            target='vassembled' if i==count-1 else f'vx{i}'
            graph+=f';[{previous}][vt{i}]xfade=transition=fade:duration={t.decimal(dissolve)}:offset={t.decimal(segments[i][2])}[{target}]';previous=target
    else:graph+=';'+''.join(f'[vt{i}]' for i in range(count))+f'concat=n={count}:v=1:a=0[vassembled]'
    total_frames=cursor*rate;assert total_frames.denominator==1
    graph+=f';[vassembled]trim=end_frame={total_frames.numerator},settb=expr={1/rate},setpts=N,settb=expr=1/1000000[vout]'
    audio=t.sub(t.literal('AUDIO_BASE'),audio=1,origin_num=origin.numerator,origin_den=origin.denominator,rate=RATE,source_samples=t.ceil(duration*RATE))
    if markers:
        on=F(90,1)/rate
        audio=audio.replace('[0:1]',f"[0:1]volume='if(lt(t-({origin}),{float(on):.9f}),0.25,0.75)':eval=frame:precision=double,",1)
    audio+=',asplit='+str(count)+''.join(f'[a{i}]' for i in range(count))
    for i,(start,end,begin,finish,speed) in enumerate(segments):
        samples=t.ceil(finish*RATE)-t.ceil(begin*RATE)
        if speed!=1:
            assert end-start>=F(1,10) and finish-begin>=F(1,10),'changed-speed selected audio requires100ms source and output'
            process=f',apad=pad_len={t.ceil(F(RATE,4))}'+tempo(speed)+f',atrim=end_sample={samples}'
        else:process=f',apad=whole_len={samples},atrim=end_sample={samples}'
        if dissolve:process+=',asetnsamples=n=1024:p=0'
        audio+=';'+t.sub(t.literal('AUDIO_TRIM'),index=i,start=t.ceil(start*RATE),end=t.ceil(end*RATE)).replace(f'[t{i}]',process+f'[t{i}]')
    if dissolve:
        previous='t0'
        for i in range(1,count):
            overlap=t.ceil(segments[i-1][3]*RATE)-t.ceil(segments[i][2]*RATE)
            audio+=f';[{previous}][t{i}]acrossfade=ns={overlap}:c1=tri:c2=tri[ax{i}]';previous=f'ax{i}'
        audio+=f';[{previous}]anull'
    else:audio+=';'+''.join(f'[t{i}]' for i in range(count))+f'concat=n={count}:v=0:a=1'
    if all(segment[4]==1 for segment in segments):audio+=f',apad=whole_len={t.ceil(cursor*RATE)}'
    audio+=f',atrim=end_sample={t.ceil(cursor*RATE)}[aout]'
    return prefix+graph+';'+audio,cursor,segments

def render(work,source,rate,clips,name,**options):
    graph,duration,segments=build_graph(source,rate,clips,**options)
    assert len(graph)<48*1024
    digest=hashlib.sha256(source.read_bytes()).hexdigest();out=work/(name+'.mov')
    m.execute([m.FFMPEG,'-v','error','-nostdin','-y','-copyts','-threads','2','-i',source,
        '-filter_complex_threads','1','-filter_complex',graph,'-map','[vout]','-map','[aout]',
        '-c:v','png','-threads:v','1','-pix_fmt','rgb24','-fps_mode:v','passthrough',
        '-enc_time_base:v','1/1000000','-c:a','pcm_s16le','-video_track_timescale','1000000',
        '-movie_timescale',str(math.lcm(rate.numerator,RATE)),out],timeout=90)
    assert hashlib.sha256(source.read_bytes()).hexdigest()==digest,'source bytes changed'
    metadata=m.probe(out,head=False);video=m.vstream(metadata)
    frame_data=json.loads(m.execute([m.FFPROBE,'-v','error','-select_streams','v:0','-show_frames','-show_entries','frame=pts','-of','json',out]))['frames']
    pts=[F(row['pts'])*F(video['time_base']) for row in frame_data]
    expected_frames=duration*rate;assert expected_frames.denominator==1
    assert len(pts)==expected_frames.numerator,(len(pts),str(expected_frames))
    assert all(abs(at-F(i,1)/rate)<=F(2,1000000) for i,at in enumerate(pts)),('output frame PTS drift',[(str(at),str(F(i,1)/rate)) for i,at in enumerate(pts) if abs(at-F(i,1)/rate)>F(2,1000000)][:8])
    audio=t.pcm(out);assert len(audio)==t.ceil(duration*RATE),(len(audio),t.ceil(duration*RATE))
    rgb=m.execute([m.FFMPEG,'-v','error','-nostdin','-threads','2','-i',out,'-map','0:v:0','-filter_threads','1','-threads:v','1','-f','rawvideo','-pix_fmt','rgb24','-'])
    assert len(rgb)==len(pts)*WIDTH*HEIGHT*3
    detail={'frames':len(pts),'samples':len(audio),'duration':str(duration),'source_sha256':digest,
            'clip_speeds':[str(segment[4]) for segment in segments]}
    return detail,audio,rgb,segments

def assert_source_order(rgb,segments,rate):
    # Check interior frames away from fps rounding and clip endpoints, using an
    # independent source-time map. CFR resampling chooses the nearest output
    # frame slot; a faster rate permits half a slot in source-frame distance.
    observed=[]
    for start,end,begin,finish,speed in segments:
        output_frame=t.ceil((begin+(finish-begin)/2)*rate)
        source_time=start+(F(output_frame,1)/rate-begin)*speed
        expected=20+int(source_time*rate);actual=t.pixel(rgb,output_frame)[0]
        assert abs(actual-expected)<=max(1,t.ceil(speed/2)),('wrong source occurrence',actual,expected)
        observed.append(actual)
    return observed

def assert_audio_content(audio,segments):
    values=[]
    for _,_,begin,finish,_ in segments:
        first=t.ceil((begin+(finish-begin)/4)*RATE)
        last=t.ceil((begin+(finish-begin)*F(3,4))*RATE)
        mean=sum(abs(value) for value in audio[first:last])/(last-first)
        assert mean>6000,('tempo output was silently padded or lost',mean)
        values.append(round(mean,3))
    return values

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,required=True);args=parser.parse_args()
    args.output.parent.mkdir(parents=True,exist_ok=True);results=[];began=time.monotonic()
    def case(name,fn):
        start=time.monotonic()
        try:detail=fn() or {};row={'name':name,'status':'passed','details':detail};print('PASS',name,flush=True)
        except Exception as exc:row={'name':name,'status':'failed','error':str(exc)};print('FAIL',name,str(exc),flush=True)
        row['seconds']=round(time.monotonic()-start,3);results.append(row)
    with tempfile.TemporaryDirectory(prefix='video-assembly-',dir=args.output.parent) as directory:
        work=Path(directory)
        for sample_rate in (16000,44100,48000):
            for speed in (F(1,4),F(1,2),F(2),F(4)):
                name='minimum_audio_span_tempo_'+str(speed).replace('/','-')+'_'+str(sample_rate)
                def boundary(sr=sample_rate,s=speed,n=name):
                    source_count=t.ceil(F(sr,10)*max(F(1),s));target=t.ceil(F(source_count,1)/s)
                    assert F(source_count,sr)>=F(1,10) and F(target,sr)>=F(1,10)
                    details={}
                    for shape in ('dc','tone'):
                        samples=array.array('h',(12000 if shape=='dc' else round(12000*math.sin(2*math.pi*440*i/sr)) for i in range(source_count)))
                        if sys.byteorder!='little':samples.byteswap()
                        path=work/(n+'-'+shape+'.pcm');path.write_bytes(samples.tobytes())
                        filters=f'apad=pad_len={t.ceil(F(sr,4))}'+tempo(s)+f',atrim=end_sample={target}'
                        raw=m.execute([m.FFMPEG,'-v','error','-nostdin','-f','s16le','-ar',str(sr),'-ac','1','-i',path,'-af',filters,'-c:a','pcm_s16le','-f','s16le','-'])
                        audio=array.array('h');audio.frombytes(raw)
                        if sys.byteorder!='little':audio.byteswap()
                        assert len(audio)==target,(len(audio),target)
                        first=target//10;last=target*7//10
                        mean=sum(abs(value) for value in audio[first:last])/(last-first)
                        assert mean>(6500 if shape=='dc' else 3500),('minimum legal tempo span lost signal',shape,mean)
                        details[shape]={'samples':len(audio),'interior_mean_abs':round(mean,3),'nonzero_samples':sum(value!=0 for value in audio)}
                    return {'source_samples':source_count,'sample_rate':sr,'effective_speed':str(s),'signals':details}
                case(name,boundary)
        for rate in (F(30),F(30000,1001)):
            label=str(rate).replace('/','-');source=t.fixture(work,rate,origin=5)
            cases=[('reverse',[(120,144,F(1)),(60,84,F(1)),(0,24,F(1))]),
                   ('repeated_overlap',[(96,144,F(1)),(0,48,F(1)),(96,144,F(1))]),
                   ('trimmed_occurrences',[(96,120,F(1)),(0,24,F(1)),(144,168,F(1))])]
            for title,clips in cases:
                name=title+'_'+label
                def run(clips=clips,n=name,p=source,r=rate):
                    detail,audio,rgb,segments=render(work,p,r,clips,n)
                    detail['interior_pixels']=assert_source_order(rgb,segments,r);return detail
                case(name,run)
            for effective in (F(1,4),F(1,2),F(1),F(2),F(4)):
                # Exercise the same effective rate supplied by per-clip and
                # global speed combinations, including legal atempo chains.
                per_clip=F(1,2) if effective==F(1,4) else F(2) if effective==4 else effective
                global_speed=effective/per_clip
                clips=[(96,120,per_clip),(0,24,per_clip),(96,120,per_clip)]
                name='effective_speed_'+str(effective).replace('/','-')+'_'+label
                def run(c=clips,n=name,p=source,r=rate,g=global_speed):
                    detail,audio,rgb,segments=render(work,p,r,c,n,global_speed=g)
                    detail['interior_pixels']=assert_source_order(rgb,segments,r)
                    detail['audio_interior_mean_abs']=assert_audio_content(audio,segments);return detail
                case(name,run)
            clips=[(96,120,F(1,2)),(0,24,F(1)),(144,168,F(2))]
            for global_speed in (F(1,2),F(1),F(2)):
                name='mixed_clip_speeds_global_'+str(global_speed).replace('/','-')+'_'+label
                def run(c=clips,n=name,p=source,r=rate,g=global_speed):
                    detail,audio,rgb,segments=render(work,p,r,c,n,global_speed=g)
                    detail['interior_pixels']=assert_source_order(rgb,segments,r)
                    detail['audio_interior_mean_abs']=assert_audio_content(audio,segments);return detail
                case(name,run)
            impulses=t.fixture(work,rate,impulses=True,origin=5)
            name='reordered_repeated_impulse_samples_'+label
            def impulse(p=impulses,r=rate,n=name):
                clips=[(4,5,F(1)),(0,1,F(1)),(4,5,F(1)),(2,3,F(1))]
                detail,audio,rgb,segments=render(work,p,r,clips,n)
                actual=[i for i,value in enumerate(audio) if value>15000]
                expected=[t.ceil(begin*RATE)+25 for _,_,begin,_,_ in segments]
                assert actual==expected,(actual,expected)
                assert [t.pixel(rgb,i)[0] for i in range(4)]==[24,20,24,22]
                detail['impulse_samples']=actual;return detail
            case(name,impulse)
            name='maximum_64_one_frame_occurrences_exact_clock_'+label
            def many(p=impulses,r=rate,n=name):
                clips=[(4 if i%2==0 else 0,5 if i%2==0 else 1,F(1)) for i in range(64)]
                detail,audio,rgb,segments=render(work,p,r,clips,n)
                assert [t.pixel(rgb,i)[0] for i in range(64)]==[24 if i%2==0 else 20 for i in range(64)]
                actual=[i for i,value in enumerate(audio) if value>15000]
                expected=[t.ceil(begin*RATE)+25 for _,_,begin,_,_ in segments]
                assert actual==expected,(actual,expected)
                detail['impulse_samples']=actual;return detail
            case(name,many)
            name='source_graphic_caption_plate_and_volume_repeated_'+label
            def markers(p=source,r=rate,n=name):
                clips=[(90,150,F(1,2)),(0,60,F(1)),(90,150,F(2))]
                detail,audio,rgb,segments=render(work,p,r,clips,n,markers=True)
                pixels=[]
                for i,(_,_,begin,finish,_) in enumerate(segments):
                    frame=int((begin+(finish-begin)/2)*r)
                    graphic=t.pixel(rgb,frame,5,5);caption=t.pixel(rgb,frame,5,36)
                    if i!=1:
                        assert graphic[0]>200 and graphic[1]<50,('source graphic missing',graphic)
                        assert caption[1]>200 and caption[0]<50,('source caption plate missing',caption)
                        # The same two source animation phases must reappear in
                        # both occurrences, even though their speeds differ.
                        early=int((begin+(finish-begin)/4)*r)
                        late=int((begin+(finish-begin)*F(3,4))*r)
                        for f,x in ((early,23),(late,43)):
                            phase=t.pixel(rgb,f,x,3)
                            assert phase[2]>200 and phase[0]<50,('source animation phase shifted',phase)
                    else:
                        assert max(graphic)-min(graphic)<=2,('graphic present outside source lifetime',graphic)
                        assert max(caption)-min(caption)<=2,('caption present outside source lifetime',caption)
                    sample=t.nearest((begin+(finish-begin)/2)*RATE)
                    expected=3000 if i==1 else 9000
                    assert abs(audio[sample]-expected)<30,('wrong source volume',audio[sample],expected)
                    pixels.append({'graphic':graphic,'caption_plate':caption})
                detail['pixels']=pixels;return detail
            case(name,markers)
            name='repeated_mixed_speed_dissolve_'+label
            def dissolve(p=source,r=rate,n=name):
                clips=[(0,60,F(1,2)),(90,150,F(2)),(0,60,F(1))]
                detail,audio,rgb,segments=render(work,p,r,clips,n,dissolve_frames=6)
                for i in (1,2):
                    frame=int(segments[i][2]*r)+3
                    mixed=t.pixel(rgb,frame)[0]
                    assert 45<mixed<145,('missing mixed dissolve pixel',mixed)
                return detail
            case(name,dissolve)
    failed=sum(row['status']=='failed' for row in results)
    report={'suite':'step14-assembly-reference','scope':'Independent generated FFmpeg recipes; Rust assembly validation, subtitle parser, native workflow and Automexia host are not executed',
            'ffmpeg_version':m.execute([m.FFMPEG,'-version']).decode().splitlines()[0],
            'passed':len(results)-failed,'failed':failed,'blocked':0,'cases':results,'seconds':round(time.monotonic()-began,3)}
    args.output.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'passed':report['passed'],'failed':failed}));return 1 if failed else 0
if __name__=='__main__':raise SystemExit(main())
