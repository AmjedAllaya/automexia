#!/usr/bin/env python3
"""Independent FFmpeg Step-7 recipes, NOT execution of Rust/the host adapter.
Reads actual literal filter templates from reframe_render.rs. Assertions inspect
encoded files, decoded pixels and timestamps. Python is only a test dependency.
"""
from __future__ import annotations
import argparse, hashlib, json, math, re, subprocess, tempfile, time
from pathlib import Path
from fractions import Fraction as F
import run_media_checks as m
import run_edit_checks as e
import run_color_checks as c
ROOT=Path(__file__).resolve().parents[2]
SRC=ROOT/'src/reframe_render.rs'

def template(name):
    hit=re.search(r'pub const '+name+r'\s*:\s*&str\s*=\s*("(?:[^"\\]|\\.)*")\s*;',SRC.read_text())
    assert hit,name
    return json.loads(hit.group(1))
def sub(text,**kw):
    for key,value in kw.items():text=text.replace('{'+key+'}',str(value))
    return text

def geometry(meta):
    v=m.vstream(meta);w,h=v['width'],v['height'];sar=F(v.get('sample_aspect_ratio','1:1').replace(':','/'))
    rot=next((int(round(float(s['rotation']))) for s in v.get('side_data_list',[]) if 'rotation' in s),int(v.get('tags',{}).get('rotate',0)))
    if rot%180:w,h,sar=h,w,1/sar
    return w,h,sar

def ease_expr(meta,a,b,start,stop,symbol="t"):
    if a==b:return f'{a:.12f}'
    v=m.vstream(meta);tb=F(v['time_base']);origin=e.exact_start(v)
    t0=(origin+F(start))/tb;t1=(origin+F(stop))/tb
    assert t0.denominator==1 and t1.denominator==1
    return sub(template('EASE_EXPRESSION'),clock=f'round({symbol}*{tb.denominator}/{tb.numerator})',start=t0.numerator,span=(t1-t0).numerator,a=f'{a:.12f}',delta=f'{b-a:.12f}')

def framing(meta,target,*,mode='fit',anchor=(.5,.5),background='0x000000',center=(.5,.5),zoom=1,move=None,reset=None,max_upscale=4):
    tw,th=target;w,h,sar=geometry(meta);dw=w*float(sar);dh=h
    range_='pc' if m.vstream(meta).get('color_range')=='pc' else 'tv'
    if mode=='fit':
        factor=min(tw/dw,th/dh,max_upscale/float(sar),max_upscale)
        sw=int(math.floor(dw*factor/2+1e-10))*2;sh=int(math.floor(dh*factor/2+1e-10))*2
        rnd=lambda x:math.floor(x+.5)
        x=min(tw-sw,rnd((tw-sw)*anchor[0]/2)*2);y=min(th-sh,rnd((th-sh)*anchor[1]/2)*2)
        return sub(template('FIT_FILTER'),sw=sw,sh=sh,tw=tw,th=th,x=x,y=y,range=range_,background=background)
    scale=max(tw/dw,th/dh);bw,bh=dw*scale,dh*scale
    animated=bool((move and move.get('zoom',zoom)!=zoom) or (reset and reset[3]!=zoom));symbol='T' if animated else 't'
    cx=f'{center[0]:.12f}';cy=f'{center[1]:.12f}';z=f'{zoom:.12f}'
    if move:
        end=move.get('end',4);start=move.get('start',0)
        cx=ease_expr(meta,center[0],move.get('x',center[0]),start,end,symbol)
        cy=ease_expr(meta,center[1],move.get('y',center[1]),start,end,symbol)
        z=ease_expr(meta,zoom,move.get('zoom',zoom),start,end,symbol)
    if reset:
        at,x,y,z2=reset;v=m.vstream(meta);tb=F(v['time_base']);tick=(e.exact_start(v)+F(at))/tb
        clock=f'round({symbol}*{tb.denominator}/{tb.numerator})'
        cx=f'if(lt({clock},{tick.numerator}),{cx},{x:.12f})';cy=f'if(lt({clock},{tick.numerator}),{cy},{y:.12f})';z=f'if(lt({clock},{tick.numerator}),{z},{z2:.12f})'
    if animated:
        nw=min(1,(tw/th)/(dw/dh));nh=min(1,(dw/dh)/(tw/th))
        sx=sub(template('ZOOM_SAMPLE_X'),cx=cx,norm_w=f'{nw:.12f}',zoom=z)
        sy=sub(template('ZOOM_SAMPLE_Y'),cy=cy,norm_h=f'{nh:.12f}',zoom=z)
        init=sub(template('ZOOM_FRAME_INIT'),cx=cx,cy=cy,zoom=z)
        return sub(template('ZOOM_FILTER'),init=init,sx=sx,sy=sy,tw=tw,th=th,range=range_,format='yuvj444p' if range_=='pc' else 'yuv444p')
    return sub(template('CROP_FILTER'),base_w=f'{bw:.12f}',base_h=f'{bh:.12f}',zoom=z,cx=cx,cy=cy,tw=tw,th=th,range=range_,format='yuvj444p' if range_=='pc' else 'yuv444p')

def render(source,out,target,*,ranges=None,audio='auto',cfr=None,proxy=None,color=None,lossless=False,**options):
    before=hashlib.sha256(source.read_bytes()).hexdigest();meta=m.probe(source);v=m.vstream(meta);aud=m.streams(meta,'audio')
    ai=(aud[0]['index'] if aud else None) if audio=='auto' else audio
    ranges=ranges or [('0',str(e.exact_duration(v)))];graph,length,_=e.graph(meta,ranges,ai)
    chain=framing(meta,target,**options);marker=',settb=expr=1/1000000';assert marker in graph
    graph=graph.replace(marker,','+chain+marker,1)
    if color:graph=graph.replace(f"[0:{v['index']}]",f"[0:{v['index']}]"+c.chain(meta,color)+',',1)
    if proxy:
        graph=graph.replace('[vout]','[vproxy]',1)
        graph+=f';[vproxy]scale=w={proxy[0]}:h={proxy[1]}:flags=bilinear,setsar=1[vout]'
    assert len(graph)<48*1024
    args=[m.FFMPEG,*m.prefix('EDITED_PREFIX','edit_render.rs'),'-threads','2',*m.prefix('INPUT_POLICY','plan.rs'),'-i',str(source),
        '-filter_complex_threads','1','-filter_complex',graph,'-map','[vout]']
    args+=['-map','[aout]'] if ai is not None else ['-an']
    args+=['-map_metadata','-1','-map_chapters','-1','-sn','-dn','-c:v','libx264','-preset','medium','-crf','0' if lossless else '18','-pix_fmt','yuv420p','-threads:v','1']
    rate=F(v.get('r_frame_rate') or v['avg_frame_rate'])
    if cfr:args+=['-fps_mode:v','cfr','-r:v',str(cfr),'-enc_time_base:v',str(1/F(cfr))]
    else:args+=['-fps_mode:v','passthrough','-enc_time_base:v','1/1000000','-bsf:v',e.substitute(e.template('DURATION_BSF'),num=rate.numerator,den=rate.denominator)]
    for flag,field in [('-colorspace','color_space'),('-color_trc','color_transfer'),('-color_primaries','color_primaries'),('-color_range','color_range')]:
        if v.get(field) not in [None,'unknown','unspecified']:args += [flag,v[field]]
    args+=['-x264-params','videoformat=component']
    if ai is not None:args+=['-c:a','aac','-b:a','192k','-threads:a','1']
    args+=['-t',f'{float(length):.9f}','-metadata:s:v:0','rotate=0','-avoid_negative_ts','disabled','-movflags','+faststart','-progress','pipe:1','-nostats','-f','mp4',str(out)]
    m.execute(args,timeout=90)
    result=m.probe(out);ov=m.vstream(result);size=proxy or target
    assert (ov['width'],ov['height'])==size,ov
    assert F(ov.get('sample_aspect_ratio','1:1').replace(':','/'))==1,ov
    assert all(int(round(float(s.get('rotation',0))))%360==0 for s in ov.get('side_data_list',[]))
    assert abs(float(e.exact_duration(ov)-length))<.11,(ov,length)
    assert bool(m.streams(result,'audio'))==(ai is not None)
    if ai is not None:
        old=next(s for s in aud if s['index']==ai);new=m.streams(result,'audio')[0]
        assert old['channels']==new['channels'] and old['sample_rate']==new['sample_rate']
    m.execute([m.FFMPEG,'-v','error','-xerror','-i',out,'-f','null','-'])
    assert hashlib.sha256(source.read_bytes()).hexdigest()==before
    return out

def rgb_frame(w=320,h=180,kind='bars'):
    b=bytearray()
    for y in range(h):
        for x in range(w):
            if kind=='gradient':rgb=(round(220*x/(w-1)),round(220*y/(h-1)),40)
            else:rgb=(180,30,30) if x<w/3 else (30,180,30) if x<w*2/3 else (30,30,180)
            b.extend(rgb)
    return bytes(b)
def pixel(frame,w,x,y):return tuple(frame[(y*w+x)*3:(y*w+x)*3+3])
def center_pixel(path,index=0):
    v=m.vstream(m.probe(path));f=c.decode(path)[index];return pixel(f,v['width'],v['width']//2,v['height']//2)
def dominant(rgb,channel):assert rgb[channel]>max(v for i,v in enumerate(rgb) if i!=channel)+50,rgb

def main():
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);p.add_argument('--keep',type=Path);opts=p.parse_args()
    results=[];started=time.monotonic()
    with tempfile.TemporaryDirectory(prefix='video-step7-') as temp:
        work=opts.keep or Path(temp);work.mkdir(parents=True,exist_ok=True)
        source=c.encode(work/'bars.mp4',[rgb_frame()]*120,w=320,h=180)
        gradient=c.encode(work/'gradient.mp4',[rgb_frame(kind='gradient')]*120,w=320,h=180)
        def case(name,fn):
            t=time.monotonic()
            try:detail=fn() or {};results.append(dict(name=name,status='passed',seconds=round(time.monotonic()-t,3),details=detail));print('PASS',name,flush=True)
            except Exception as exc:results.append(dict(name=name,status='failed',seconds=round(time.monotonic()-t,3),error=str(exc)));print('FAIL',name,str(exc),flush=True)
        def fmt(target):
            out=render(source,work/f'fit-{target[0]}-{target[1]}.mp4',target)
            return {'dimensions':target,'frames':len(m.frames(out))}
        for label,target in [('16_9',(320,180)),('9_16',(108,192)),('4_5',(144,180)),('1_1',(180,180)),('custom_3_2',(210,140))]:case('fit_'+label,lambda t=target:fmt(t))
        def crop(target,center=(.5,.5),index=1):
            out=render(source,work/f'crop-{target[0]}-{center[0]}.mp4',target,mode='crop',center=center)
            dominant(center_pixel(out),index);return {'center_rgb':center_pixel(out)}
        case('center_crop_landscape_to_portrait',lambda:crop((108,192)))
        case('center_crop_square',lambda:crop((180,180)))
        case('left_edge_crop_is_not_silently_centered',lambda:crop((108,192),(.158203125,.5),0))
        case('right_edge_crop_is_not_silently_centered',lambda:crop((108,192),(.841796875,.5),2))
        def all_fit():
            f=c.decode(work/'fit-180-180.mp4')[0];dominant(pixel(f,180,20,90),0);dominant(pixel(f,180,160,90),2);assert max(pixel(f,180,90,4))<5
        case('fit_retains_both_edges_and_black_bars',all_fit)
        def anchor():
            out=render(source,work/'anchor.mp4',(180,180),anchor=(0,0),background='0xffffff')
            f=c.decode(out)[0];dominant(pixel(f,180,90,2),1);assert min(pixel(f,180,90,178))>245
        case('explicit_padding_anchor_and_color',anchor)
        def no_up():
            out=render(source,work/'no-upscale.mp4',(640,360),max_upscale=1);f=c.decode(out)[0];assert max(pixel(f,640,120,180))<5;dominant(pixel(f,640,320,180),1)
        case('fit_no_upscale_keeps_small_image_and_pads',no_up)
        def pan():
            out=render(source,work/'pan.mp4',(108,192),mode='crop',center=(.25,.5),move={'x':.75,'end':4})
            dominant(center_pixel(out,0),0);dominant(center_pixel(out,60),1);dominant(center_pixel(out,119),2);assert len(m.frames(out))==120
        case('source_time_quintic_pan_changes_real_pixels',pan)
        def zoom():
            out=render(gradient,work/'zoom.mp4',(180,180),mode='crop',move={'zoom':1.8,'end':4});frames=c.decode(out);a=frames[0];b=frames[-1]
            assert pixel(b,180,10,90)[0]>pixel(a,180,10,90)[0]+15
            assert pixel(b,180,170,90)[0]<pixel(a,180,170,90)[0]-15
        case('animated_zoom_keeps_fixed_output_raster',zoom)
        def cut_clock():
            out=render(gradient,work/'pan-cut.mp4',(108,192),ranges=[('0','1'),('2','4')],mode='crop',center=(.25,.5),move={'x':.75,'end':4})
            frames=c.decode(out);value=pixel(frames[30],108,54,96)[0];assert 100<=value<=120,value;assert len(frames)==90
            return {'red_at_output_one_second':value,'expected_source_time':'2/1'}
        case('removing_time_does_not_retime_crop_keys',cut_clock)
        def reset():
            out=render(source,work/'reset.mp4',(108,192),mode='crop',center=(.25,.5),reset=('2',.75,.5,1));frames=c.decode(out)
            dominant(pixel(frames[59],108,54,96),0);dominant(pixel(frames[60],108,54,96),2)
        case('shot_reset_changes_framing_exactly_at_boundary',reset)
        def rotation(angle):
            src=work/f'rotate-{angle}.mp4';m.execute([m.FFMPEG,'-v','error','-y','-display_rotation:v:0',str(angle),'-i',source,'-map','0','-c','copy',src])
            assert any(int(s.get('rotation',0))%360==angle%360 for s in m.vstream(m.probe(src)).get('side_data_list',[]))
            out=render(src,work/f'rotated-out-{angle}.mp4',(108,192),mode='crop');dominant(center_pixel(out),1)
            return {'rotation_normalized':angle,'center_rgb':center_pixel(out)}
        for angle in [90,180,270]:case(f'rotation_{angle}_normalized_before_framing',lambda a=angle:rotation(a))
        def nonsquare(rotate=False):
            src=work/'sar.mp4';c.encode(src,[rgb_frame()]*120,w=320,h=180,vf='setsar=2')
            if rotate:
                rot=work/'sar-rotate.mp4';m.execute([m.FFMPEG,'-v','error','-y','-display_rotation:v:0','90','-i',src,'-map','0','-c','copy',rot]);src=rot
            target=(108,192) if rotate else (320,180);out=render(src,work/f'sar-out-{rotate}.mp4',target);f=c.decode(out)[0]
            if not rotate:assert max(pixel(f,320,160,20))<5;dominant(pixel(f,320,160,90),1)
            else:assert max(pixel(f,108,4,96))<5;dominant(pixel(f,108,54,96),1)
        case('non_square_pixels_are_not_stretched',nonsquare)
        case('rotation_inverts_non_square_pixel_geometry',lambda:nonsquare(True))
        def vfr():
            src=work/'vfr.mp4';m.fixture(src,duration='4',rate='30',video_filter="select='not(eq(mod(n,5),1))'",extra=['-fps_mode','vfr'])
            out=render(src,work/'vfr-out.mp4',(108,192),mode='crop',center=(.3,.5),move={'x':.7});old=m.frames(src);new=m.frames(out)
            assert len(old)==len(new);assert max(abs(float(a-b)) for a,b in zip(old,new))<.00001
        case('animated_crop_preserves_vfr_pts',vfr)
        def frac():
            src=work/'fractional.mp4';m.fixture(src,duration='4',rate='30000/1001')
            out=render(src,work/'fractional-out.mp4',(108,192),mode='crop',ranges=[(F(1001,30000),F(20020,30000))]);assert len(m.frames(out))==19
        case('fractional_cut_boundary_survives_framing',frac)
        def cfr():
            out=render(source,work/'cfr24.mp4',(108,192),mode='crop',cfr='24');assert F(m.vstream(m.probe(out))['avg_frame_rate'])==24
        case('explicit_constant_frame_rate_with_framing',cfr)
        def offset():
            src=work/'origin3600.mp4';m.execute([m.FFMPEG,'-v','error','-y','-i',gradient,'-c','copy','-output_ts_offset','3600',src])
            out=render(src,work/'origin-out.mp4',(108,192),mode='crop',center=(.25,.5),move={'x':.75});value=center_pixel(out,60)[0]
            assert 100<=value<=120,value;assert abs(float(m.frames(out)[0]))<.001
        case('large_source_origin_does_not_shift_keyframes',offset)
        def second():
            src=work/'second.mp4';m.execute([m.FFMPEG,'-v','error','-y','-i',source,'-f','lavfi','-i','sine=frequency=880:sample_rate=48000:duration=4','-map','0:v','-map','0:a','-map','1:a','-c:v','copy','-c:a','aac',src])
            out=render(src,work/'second-out.mp4',(108,192),audio=2,mode='crop');assert abs(m.frequency(out)-880)<8
        case('selected_second_audio_unchanged_by_crop',second)
        def no_audio():
            out=render(source,work/'no-audio-out.mp4',(108,192),audio=None,mode='crop');assert not m.streams(m.probe(out),'audio')
        case('video_only_framing',no_audio)
        def unchanged_audio():
            a=render(source,work/'landscape-audio.mp4',(320,180));b=render(source,work/'portrait-audio.mp4',(108,192),mode='crop');assert m.pcm(a)==m.pcm(b)
        case('variant_geometry_does_not_change_audio_samples',unchanged_audio)
        def preview():
            full=render(gradient,work/'full-crop.mp4',(180,180),mode='crop',center=(.35,.5));small=render(gradient,work/'proxy-crop.mp4',(180,180),mode='crop',center=(.35,.5),proxy=(90,90))
            a=center_pixel(full);b=center_pixel(small);assert max(abs(x-y) for x,y in zip(a,b))<5,(a,b)
        case('preview_and_final_use_same_composition',preview)
        def colors():
            out=render(gradient,work/'color-crop.mp4',(108,192),mode='crop',color=[{'start':0,'end':4,'ev':.2}]);plain=render(gradient,work/'plain-crop.mp4',(108,192),mode='crop')
            assert sum(center_pixel(out))>sum(center_pixel(plain));assert all(m.vstream(m.probe(out)).get(k)=='bt709' for k in ['color_space','color_transfer','color_primaries'])
        case('shot_color_correction_precedes_framing',colors)
        def full_range():
            src=work/'pc.mp4';m.execute([m.FFMPEG,'-v','error','-y','-i',source,'-vf','scale=in_range=tv:out_range=pc','-pix_fmt','yuvj420p','-color_range','pc','-c:v','libx264','-threads:v','1','-c:a','copy',src])
            for mode in ['fit','crop']:
                out=render(src,work/f'pc-{mode}.mp4',(180,180),mode=mode);assert m.vstream(m.probe(out)).get('color_range')=='pc'
                if mode=='fit':assert max(pixel(c.decode(out)[0],180,90,2))<5
        case('full_range_crop_and_padding_keep_range',full_range)
        def odd_crop():
            out=render(gradient,work/'odd-crop.mp4',(108,192),mode='crop',center=(.503,.5));assert len(m.frames(out))==120
        case('odd_pixel_pan_position_uses_exact_crop',odd_crop)
        def portrait_to_landscape():
            src=work/'portrait.mp4';c.encode(src,[rgb_frame(180,320)]*120,w=180,h=320)
            a=render(src,work/'portrait-fit.mp4',(320,180));b=render(src,work/'portrait-crop.mp4',(320,180),mode='crop');dominant(center_pixel(a),1);dominant(center_pixel(b),1)
        case('portrait_to_landscape_fit_and_crop',portrait_to_landscape)
        def simultaneous():
            out=render(gradient,work/'panzoom.mp4',(108,192),mode='crop',center=(.3,.5),zoom=1,move={'x':.7,'zoom':1.6});assert center_pixel(out,0)[0]<90 and center_pixel(out,119)[0]>145
        case('simultaneous_pan_and_zoom',simultaneous)
        def aspect_extreme():
            out=render(source,work/'wide.mp4',(320,40));assert len(m.frames(out))==120
        case('extreme_aspect_fit_is_explicit_padding',aspect_extreme)
        def dynamic_vfr():
            src=work/'zoom-vfr-source.mp4';m.fixture(src,duration='4',rate='30',video_filter="select='not(eq(mod(n,4),1))'",extra=['-fps_mode','vfr'])
            out=render(src,work/'zoom-vfr.mp4',(90,160),mode='crop',move={'zoom':1.3})
            a=m.frames(src);b=m.frames(out);assert len(a)==len(b);assert max(abs(float(x-y)) for x,y in zip(a,b))<.00001
        case('animated_zoom_preserves_actual_vfr_timestamps',dynamic_vfr)
        def dynamic_cut():
            all_=render(gradient,work/'zoom-all.mp4',(96,96),mode='crop',move={'zoom':1.8},lossless=True)
            cut=render(gradient,work/'zoom-cut.mp4',(96,96),ranges=[('0','1'),('2','4')],mode='crop',move={'zoom':1.8},lossless=True)
            a=c.decode(all_)[60];b=c.decode(cut)[30]
            assert a==b, 'lossless frames at the same source timestamp must match exactly'
            assert len(m.frames(cut))==90
        case('animated_zoom_after_cut_uses_source_not_output_clock',dynamic_cut)
        def zoom_reset():
            out=render(gradient,work/'zoom-reset.mp4',(96,96),mode='crop',reset=('2',.5,.5,1.8))
            f=c.decode(out);a=pixel(f[59],96,5,48);b=pixel(f[60],96,5,48);assert b[0]>a[0]+15
            assert max(abs(x-y) for x,y in zip(pixel(f[59],96,48,48),pixel(f[60],96,48,48)))<5
        case('zoom_reset_uses_exact_shot_boundary',zoom_reset)
        def zoom_pc():
            src=work/'pc.mp4';out=render(src,work/'pc-zoom.mp4',(96,96),mode='crop',move={'zoom':1.2})
            assert m.vstream(m.probe(out))['color_range']=='pc';dominant(center_pixel(out,100),1)
        case('animated_zoom_preserves_full_range_and_color',zoom_pc)
        def zoom_rot_sar():
            src=work/'sar-rotate.mp4';out=render(src,work/'sar-rot-zoom.mp4',(90,160),mode='crop',move={'zoom':1.2})
            dominant(center_pixel(out,0),1);dominant(center_pixel(out,119),1)
        case('animated_zoom_respects_rotated_non_square_source',zoom_rot_sar)
        def center_lock():
            out=work/'zoom.mp4';frames=c.decode(out);values=[pixel(f,180,90,90) for f in frames]
            for channel in [0,1]:assert max(x[channel] for x in values)-min(x[channel] for x in values)<7
        case('animated_zoom_center_does_not_drift_across_frames',center_lock)
        def cancellation():
            out=work/'interrupted.mp4';args=[m.FFMPEG,'-v','error','-nostdin','-re','-i',str(source),'-vf',framing(m.probe(source),(108,192),mode='crop'),'-c:v','libx264','-threads:v','1','-y',str(out)]
            proc=subprocess.Popen(args,stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)
            try:time.sleep(.15);proc.terminate();proc.communicate(timeout=10)
            finally:
                if proc.poll() is None:proc.kill();proc.communicate()
            assert proc.returncode!=0;return {'scope':'FFmpeg termination only; Rust cleanup has separate native tests'}
        case('interrupting_framing_process_does_not_claim_complete_output',cancellation)
    data={'scope':'independent FFmpeg recipes; Rust crate and host integration not executed','ffmpeg':m.execute([m.FFMPEG,'-version']).decode().splitlines()[0],
        'count':len(results),'passed':sum(x['status']=='passed' for x in results),'failed':sum(x['status']=='failed' for x in results),'seconds':round(time.monotonic()-started,3),'tests':results}
    opts.output.parent.mkdir(parents=True,exist_ok=True);opts.output.write_text(json.dumps(data,indent=2)+'\n');print(json.dumps({k:v for k,v in data.items() if k!='tests'},indent=2),flush=True)
    raise SystemExit(1 if data['failed'] else 0)
if __name__=='__main__':main()
