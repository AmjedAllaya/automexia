#!/usr/bin/env python3
"""Independent HDR packet/pixel preservation recipes, not Rust/native execution.

Uses generated HEVC PQ/HLG fixtures, never user recordings or learned models.
The native Rust implementation still requires its own >=7.1 runtime qualification.
"""
import argparse
import copy
from fractions import Fraction as F
import hashlib
import json
import os
from pathlib import Path
import subprocess
import tempfile
import time

FFMPEG = os.environ.get('FFMPEG', 'ffmpeg')
FFPROBE = os.environ.get('FFPROBE', 'ffprobe')
ROOT = Path(__file__).resolve().parents[2]


def run(args):
    result = subprocess.run([str(a) for a in args], stdin=subprocess.DEVNULL,
                            capture_output=True, timeout=60)
    if result.returncode:
        raise AssertionError(result.stderr.decode(errors='replace')[-2500:])
    return result.stdout


def generate(path, transfer='smpte2084', bframes=0, rate='24', frames=24):
    static = ('master-display=G(13250,34500)B(7500,3000)R(34000,16000)'
              'WP(15635,16450)L(10000000,1):max-cll=1000,400')
    params = (f'pools=1:frame-threads=1:log-level=error:bframes={bframes}:keyint=12:'
              f'min-keyint=12:scenecut=0:hdr10=1:repeat-headers=1:colorprim=bt2020:'
              f'transfer={transfer}:colormatrix=bt2020nc:{static}')
    run([FFMPEG, '-v', 'error', '-nostdin', '-y', '-f', 'lavfi', '-i',
         f'testsrc2=size=128x72:rate={rate}:duration=2', '-frames:v', str(frames),
         '-an', '-c:v', 'libx265', '-threads', '2', '-pix_fmt', 'yuv420p10le',
         '-x265-params', params, '-color_primaries', 'bt2020', '-color_trc', transfer,
         '-colorspace', 'bt2020nc', '-color_range', 'tv', path])
    return path


def probe(path, mode):
    return json.loads(run([FFPROBE, '-v', 'error', '-threads', '2', '-select_streams',
        'v:0', '-show_streams', '-show_' + mode, '-show_data_hash', 'sha256',
        '-of', 'json', path]))


def static_metadata(row):
    kinds = ('Mastering display metadata', 'Content light level metadata')
    return [x for x in row.get('side_data_list', []) if x.get('side_data_type') in kinds]


def evidence(path):
    packets = probe(path, 'packets')
    frames = probe(path, 'frames')['frames']
    stream = packets['streams'][0]
    clock = F(stream['time_base'])
    hashes = run([FFMPEG, '-v', 'error', '-nostdin', '-xerror', '-copyts',
                  '-threads', '2', '-i', path, '-map', '0:v:0', '-an', '-sn', '-dn',
                  '-fps_mode', 'passthrough', '-enc_time_base:v', str(clock),
                  '-pix_fmt', 'yuv420p10le', '-c:v', 'rawvideo', '-threads:v', '1',
                  '-f', 'framehash', '-hash', 'sha256', 'pipe:1']).decode()
    pixels = []
    for line in hashes.splitlines():
        if line and not line.startswith('#'):
            fields = [x.strip() for x in line.split(',')]
            assert len(fields) == 6 and int(fields[4]) == 128 * 72 * 3
            pixels.append((int(fields[2]) * clock, fields[5]))
    assert len(pixels) == len(frames) == len(packets['packets'])
    return {'stream': stream, 'tb': clock, 'packets': packets['packets'],
            'frames': frames, 'pixels': pixels}


def prove(before, after, start, duration):
    keys = ('codec_name', 'pix_fmt', 'width', 'height', 'color_range', 'color_space',
            'color_transfer', 'color_primaries', 'sample_aspect_ratio', 'extradata_hash')
    assert all(before['stream'].get(k) == after['stream'].get(k) for k in keys), 'stream/header changed'
    bt, at = before['tb'], after['tb']
    selected = [p for p in before['packets'] if start <= int(p['pts']) * bt < start + duration]
    assert len(selected) == len(after['packets']) and selected
    for a, b in zip(selected, after['packets']):
        assert a['data_hash'] == b['data_hash'], 'encoded packet changed'
        assert int(a['pts']) * bt - start == int(b['pts']) * at, 'PTS changed'
        assert int(a['dts']) * bt - start == int(b['dts']) * at, 'DTS changed'
        assert int(a['duration']) * bt == int(b['duration']) * at, 'packet duration changed'
    selected_frames = [f for f in before['frames'] if start <= int(f['pts']) * bt < start + duration]
    assert len(selected_frames) == len(after['frames']) == len(selected)
    assert all(static_metadata(a) == static_metadata(b) for a,b in zip(selected_frames, after['frames'])), 'HDR metadata changed'
    expected = [(pts-start, digest) for pts,digest in before['pixels'] if start <= pts < start+duration]
    assert expected == after['pixels'], 'decoded pixel/time changed'
    return {'frames': len(selected), 'encoded_packets_equal': True,
            'codec_header_equal': True, 'decoded_pixels_equal': True,
            'normalized_pts_dts_equal': True, 'static_hdr_metadata_equal': True}


def mux(source, destination, start, duration, timescale=24, audio=None):
    args = [FFMPEG, '-v', 'error', '-nostdin', '-y', '-copyts', '-threads', '2']
    if start:
        args += ['-seek_timestamp', '1', '-ss', str(float(start)), '-itsoffset', str(-float(start))]
    args += ['-protocol_whitelist', 'file', '-format_whitelist', 'mov,matroska,webm', '-i', source]
    if audio is not None:
        args += ['-protocol_whitelist', 'file', '-format_whitelist', 'wav', '-i', audio]
    args += ['-map', '0:v:0', '-c:v', 'copy', '-map_metadata', '-1', '-map_chapters', '-1', '-sn', '-dn']
    args += ['-map', '1:a:0', '-c:a', 'aac', '-b:a', '192k', '-threads:a', '1'] if audio else ['-an']
    args += ['-t', str(float(duration)), '-avoid_negative_ts', 'disabled',
             '-movie_timescale', str(timescale), '-movflags', '+faststart+write_colr', '-f', 'mp4', destination]
    run(args)
    return destination


def reject(fn):
    try:
        fn()
    except AssertionError:
        return
    raise AssertionError('invalid preservation evidence was accepted')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    cases = []
    def case(name, fn):
        begin = time.monotonic()
        try:
            details = fn() or {}
            cases.append({'name': name, 'status': 'passed', 'details': details,
                          'seconds': round(time.monotonic()-begin, 3)})
            print('PASS', name, flush=True)
        except Exception as error:
            cases.append({'name': name, 'status': 'failed', 'error': str(error)})
            print('FAIL', name, str(error), flush=True)
    with tempfile.TemporaryDirectory(prefix='video-hdr-reference-') as tmp:
        work = Path(tmp)
        fixtures = {}
        for name, transfer, bframes in [('pq','smpte2084',0), ('hlg','arib-std-b67',0), ('pq-b','smpte2084',2)]:
            def fixture(name=name,transfer=transfer,bframes=bframes):
                path = generate(work/(name+'.mp4'),transfer,bframes)
                fixtures[name] = (path,evidence(path),hashlib.sha256(path.read_bytes()).hexdigest())
                assert fixtures[name][1]['stream']['pix_fmt'] == 'yuv420p10le'
                assert fixtures[name][1]['stream']['color_transfer'] == transfer
                assert static_metadata(fixtures[name][1]['frames'][0])
                return {'transfer': transfer, 'frames':24, 'bframes_configured':bframes}
            case('generated_'+name+'_ten_bit_static_metadata',fixture)
        for name in ('pq','hlg','pq-b'):
            def whole(name=name):
                src,before,_=fixtures[name]
                return prove(before,evidence(mux(src,work/(name+'-whole.mp4'),F(0),F(1))),F(0),F(1))
            case(name+'_whole_packet_pixel_and_clock_preservation',whole)
        for name in ('pq','hlg'):
            def trim(name=name):
                src,before,_=fixtures[name]
                assert any(int(p['pts'])*before['tb']==F(1,2) and 'K' in p['flags'] for p in before['packets'])
                return prove(before,evidence(mux(src,work/(name+'-trim.mp4'),F(1,2),F(1,2))),F(1,2),F(1,2))
            case(name+'_keyframe_trim_preservation',trim)
        def offset():
            src,_,_=fixtures['pq'];shifted=work/'offset.mp4'
            run([FFMPEG,'-v','error','-nostdin','-y','-i',src,'-c','copy','-output_ts_offset','5',shifted])
            before=evidence(shifted)
            return prove(before,evidence(mux(shifted,work/'offset-trim.mp4',F(11,2),F(1,2))),F(11,2),F(1,2))
        case('positive_origin_keyframe_trim_preservation',offset)
        def corruption(kind):
            src,before,_=fixtures['pq'];after=evidence(mux(src,work/('corrupt-'+kind+'.mp4'),F(0),F(1)))
            after=copy.deepcopy(after)
            if kind=='packet':after['packets'][0]['data_hash']='SHA256:'+'0'*64
            elif kind=='pixel':after['pixels'][0]=(after['pixels'][0][0],'0'*64)
            elif kind=='clock':after['packets'][0]['pts']+=1
            else:after['stream']['color_transfer']='arib-std-b67'
            reject(lambda:prove(before,after,F(0),F(1)))
        for kind in ('packet','pixel','clock','interpretation'):
            case('reference_comparator_rejects_'+kind+'_change',lambda kind=kind:corruption(kind))
        def ntsc_audio():
            source=generate(work/'ntsc.mp4',frames=3,rate='30000/1001')
            duration=F(1001,10000);audio=work/'audio.wav'
            run([FFMPEG,'-v','error','-nostdin','-y','-f','lavfi','-i',
                 'sine=frequency=440:sample_rate=48000:duration=0.1001','-c:a','pcm_s24le',audio])
            output=mux(source,work/'ntsc-audio.mp4',F(0),duration,240000,audio)
            proof=prove(evidence(source),evidence(output),F(0),duration)
            streams=json.loads(run([FFPROBE,'-v','error','-show_streams','-of','json',output]))['streams']
            a=next(s for s in streams if s['codec_type']=='audio');clock=F(a['time_base'])
            assert int(a.get('start_pts',0))*clock==0
            assert abs(int(a['duration_ts'])*clock-duration)<=F(1,48000)
            proof['audio_duration']=str(int(a['duration_ts'])*clock);proof['movie_timescale']=240000
            return proof
        case('ntsc_three_frame_audio_sample_clock',ntsc_audio)
        case('source_fixtures_remain_unchanged',lambda: all(hashlib.sha256(p.read_bytes()).hexdigest()==sha for p,_,sha in fixtures.values()) or (_ for _ in ()).throw(AssertionError('source changed')))
    report={'suite':'hdr-preservation-reference','passed':sum(c['status']=='passed' for c in cases),
            'failed':sum(c['status']=='failed' for c in cases),'cases':cases,
            'runtime':run([FFMPEG,'-version']).decode().splitlines()[0],
            'scope':'Independent generated-media preservation oracle and FFmpeg commands; no Rust/native host execution. Installed runtime may be below native>=7.1 qualification requirement.'}
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(report,indent=2)+'\n')
    return int(report['failed']>0)

if __name__=='__main__':
    raise SystemExit(main())
