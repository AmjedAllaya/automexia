#!/usr/bin/env python3
"""Independent Step 9 FFmpeg recipes, NOT execution of the Rust crate.
Encoder argument vectors are also compared with the Rust compiler in a supplied
Cargo test. Edit filter templates are read directly from the production source.
"""
import argparse, hashlib, json, subprocess, tempfile, time
from pathlib import Path
from fractions import Fraction as F
import run_media_checks as m
import run_edit_checks as e
ROOT=m.ROOT
PROFILES=json.loads((ROOT/'tests/delivery_fixtures/encoding-options.json').read_text())

def render(source,out,profile,audio=1,ranges=None,cfr=None,geometry=None):
    meta=m.probe(source);v=m.vstream(meta);ranges=ranges or [(F(0),e.exact_duration(v))]
    g,duration,_=e.graph(meta,ranges,audio)
    if geometry:g=g.replace('[vout]','[dv]',1)+';[dv]'+geometry+'[vout]'
    args=m.prefix('EDITED_PREFIX','edit_render.rs')+['-threads','2']+m.prefix('INPUT_POLICY','plan.rs')+['-i',str(source)]
    args+=['-filter_complex_threads','1','-filter_complex',g,'-map','[vout]']
    args+=['-map','[aout]'] if audio is not None else ['-an']
    args+=['-map_metadata','-1','-map_chapters','-1','-sn','-dn']
    if cfr:
        rate=F(cfr);args+=['-fps_mode:v','cfr','-r:v',str(rate),'-enc_time_base:v',str(1/rate)]
    else:
        rate=F(v.get('r_frame_rate') or v['avg_frame_rate'])
        args+=['-fps_mode:v','passthrough','-enc_time_base:v','1/1000000','-bsf:v',e.substitute(e.template('DURATION_BSF'),num=rate.numerator,den=rate.denominator)]
    for opt,key in [('-colorspace','color_space'),('-color_trc','color_transfer'),('-color_primaries','color_primaries'),('-color_range','color_range')]:
        if v.get(key) not in [None,'unknown','unspecified']:args += [opt,v[key]]
    args+=['-t',f'{float(duration):.6f}','-metadata:s:v:0','rotate=0','-avoid_negative_ts','disabled','-progress','pipe:1','-nostats']
    p=PROFILES[profile];args+=p['audio_options' if audio is not None else 'video_options'];args+=[str(out)]
    before=hashlib.sha256(source.read_bytes()).hexdigest()
    progress=m.execute([m.FFMPEG,*args]);assert b'progress=end' in progress
    assert before==hashlib.sha256(source.read_bytes()).hexdigest()
    d=m.probe(out);ov=m.vstream(d);oa=m.streams(d,'audio')
    assert ov['codec_name']==p['codec'],ov
    assert ov['pix_fmt']==p['pixel_format'] or (ov['pix_fmt']=='yuvj420p' and p['pixel_format']=='yuv420p'),ov
    assert bool(oa)==(audio is not None)
    if audio is not None:
        ia=next(s for s in meta['streams'] if s['index']==audio)
        assert oa[0]['codec_name']==p['audio_codec'],oa
        assert oa[0]['channels']==ia['channels']
        assert int(oa[0]['sample_rate'])==(48000 if p['audio_codec']=='opus' else int(ia['sample_rate']))
    actual=F(ov.get('duration',d['format']['duration']));assert abs(float(actual-duration))<.1,(actual,duration)
    m.execute([m.FFMPEG,*m.prefix('DECODE_PREFIX','host.rs'),str(out),'-map','0:v:0',*(['-map','0:a:0'] if audio is not None else []),'-f','null','-'])
    return d,duration,args

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,required=True);ap.add_argument('--keep',type=Path);ns=ap.parse_args();rows=[]
    with tempfile.TemporaryDirectory(prefix='video-delivery-') as temp:
        w=ns.keep or Path(temp);w.mkdir(parents=True,exist_ok=True)
        base=w/'base.mp4';m.fixture(base,rate='30',duration='2',extra=['-colorspace','bt709','-color_trc','bt709','-color_primaries','bt709','-color_range','tv','-x264-params','colorprim=bt709:transfer=bt709:colormatrix=bt709'])
        def case(name,f):
            t=time.monotonic()
            try:info=f() or {};rows.append({'name':name,'status':'passed','seconds':round(time.monotonic()-t,3),'details':info});print('PASS',name,flush=True)
            except Exception as ex:rows.append({'name':name,'status':'failed','error':str(ex)});print('FAIL',name,ex,flush=True)
        def target(profile):
            p=PROFILES[profile];out=w/(profile+'.'+p['extension']);d,length,args=render(base,out,profile)
            assert (m.vstream(d)['width'],m.vstream(d)['height'])==(160,96)
            assert len(m.frames(out))==60
            for key in ['color_space','color_transfer','color_primaries']:assert m.vstream(d).get(key)=='bt709',(key,m.vstream(d))
            return {'file_bytes':out.stat().st_size,'duration_s':str(length),'codec':p['codec'],'command':args}
        for profile in PROFILES:case('profile_'+profile,lambda p=profile:target(p))
        def no_audio(profile):
            p=PROFILES[profile];d,_,_=render(base,w/('noaudio-'+profile+'.'+p['extension']),profile,audio=None);assert not m.streams(d,'audio')
        def cut(profile):
            p=PROFILES[profile];out=w/('cut-'+profile+'.'+p['extension']);_,length,_=render(base,out,profile,ranges=[(F(0),F(1,2)),(F(1),F(2))]);assert len(m.frames(out))==45
            return {'duration_s':str(length)}
        codec_profiles=['h264_publish','hevc_publish','vp9_publish','av1_publish','prores_master']
        for profile in codec_profiles:
            case('video_only_'+profile,lambda p=profile:no_audio(p));case('edited_'+profile,lambda p=profile:cut(p))
        def vfr(profile):
            src=w/'vfr.mp4'
            if not src.exists():m.fixture(src,rate='30',duration='2',video_filter="select='not(eq(mod(n,5),1))'",extra=['-fps_mode','vfr'])
            p=PROFILES[profile];out=w/('vfr-'+profile+'.'+p['extension']);render(src,out,profile)
            expected=m.frames(src);actual=m.frames(out);assert len(expected)==len(actual),(len(expected),len(actual))
            errors=[abs(float((a-actual[0])-(b-expected[0]))) for a,b in zip(actual,expected)]
            assert max(errors)<.0011,max(errors);return {'frames':len(actual),'relative_pts_error_s':max(errors)}
        for profile in ['h264_publish','hevc_publish','vp9_publish','prores_master']:case('vfr_'+profile,lambda p=profile:vfr(p))
        def fractional(profile):
            src=w/'frac.mp4'
            if not src.exists():m.fixture(src,rate='30000/1001',duration='2')
            p=PROFILES[profile];out=w/('frac-'+profile+'.'+p['extension']);render(src,out,profile,ranges=[(F(1001,30000),F(20*1001,30000))]);assert len(m.frames(out))==19
        def constant(profile):
            p=PROFILES[profile];out=w/('cfr-'+profile+'.'+p['extension']);d,_,_=render(base,out,profile,cfr='24');assert F(m.vstream(d)['avg_frame_rate'])==24;assert len(m.frames(out))==48
        for profile in ['h264_publish','vp9_publish','prores_master']:
            case('fractional_boundary_'+profile,lambda p=profile:fractional(p));case('explicit_cfr_'+profile,lambda p=profile:constant(p))
        def second():
            src=w/'two-audio.mp4';m.execute([m.FFMPEG,'-v','error','-y','-i',base,'-f','lavfi','-i','sine=frequency=880:sample_rate=48000:duration=2','-map','0:v','-map','0:a','-map','1:a','-c:v','copy','-c:a','aac',src])
            out=w/'second.webm';render(src,out,'vp9_publish',audio=2);assert abs(m.frequency(out)-880)<12
        case('selected_second_audio_opus',second)
        def resample():
            src=w/'44100.mp4';m.execute([m.FFMPEG,'-v','error','-y','-i',base,'-c:v','copy','-c:a','aac','-ar','44100',src]);d,_,_=render(src,w/'48000.webm','vp9_publish');assert m.streams(d,'audio')[0]['sample_rate']=='48000'
        case('explicit_webm_profile_resampling',resample)
        def portrait():
            src=w/'rotated.mp4';m.execute([m.FFMPEG,'-v','error','-y','-display_rotation','90','-i',base,'-c','copy',src]);d,_,_=render(src,w/'portrait.mov','prores_master');assert (m.vstream(d)['width'],m.vstream(d)['height'])==(96,160)
        case('prores_rotation_normalization',portrait)
        def sar():
            src=w/'sar.mp4';m.fixture(src,rate='30',duration='2',video_filter='setsar=4/3');d,_,_=render(src,w/'sar.webm','vp9_publish');assert abs(F(m.vstream(d)['sample_aspect_ratio'].replace(':','/'))-F(4,3))<=F(1,160)
        case('webm_sample_aspect',sar)
        def weird():
            src=w/"source 測試 ; ' $.mp4";src.write_bytes(base.read_bytes());render(src,w/"out 測試 ; '.mp4",'hevc_publish')
        case('literal_unicode_paths',weird)
        def independent():
            a=w/'landscape.mp4';b=w/'portrait.webm';render(base,a,'h264_publish',geometry='scale=160:90,setsar=1');da=a.read_bytes();render(base,b,'vp9_publish',geometry='scale=54:90,setsar=1');assert a.read_bytes()==da
            assert abs(len(m.pcm(a))-len(m.pcm(b)))<2048
        case('independent_variants_preserve_completed_output_and_audio',independent)
        def failure():
            good=w/'good.mp4';render(base,good,'h264_publish');stamp=hashlib.sha256(good.read_bytes()).hexdigest()
            p=subprocess.run([m.FFMPEG,'-v','error','-y','-i',str(base),'-c:v','not_an_encoder',str(w/'fail.mp4')],capture_output=True);assert p.returncode!=0
            assert hashlib.sha256(good.read_bytes()).hexdigest()==stamp
        case('encoder_failure_does_not_change_other_output',failure)
        def sync(profile):
            src=w/'sync.mp4'
            if not src.exists():
                vf="color=black:size=64x64:rate=30:duration=2,drawbox=x=0:y=0:w=iw:h=ih:color=white:t=fill:enable='between(t,0.5,0.56)+between(t,1.5,1.56)'"
                af=r"aevalsrc=0.4*sin(2*PI*1000*t)*(between(t\,0.5\,0.56)+between(t\,1.5\,1.56)):s=48000:d=2"
                m.execute([m.FFMPEG,'-v','error','-y','-f','lavfi','-i',vf,'-f','lavfi','-i',af,'-c:v','libx264','-threads','2','-pix_fmt','yuv420p','-c:a','aac',src])
            p=PROFILES[profile];out=w/('sync-'+profile+'.'+p['extension']);render(src,out,profile,ranges=[(F(0),F(3,4)),(F(1),F(2))])
            raw=m.execute([m.FFMPEG,'-v','error','-i',out,'-vf','scale=1:1','-pix_fmt','gray','-fps_mode','passthrough','-f','rawvideo','-']);ts=m.frames(out)
            assert len(raw)==len(ts),(len(raw),len(ts))
            flashes=[float(t-ts[0]) for t,b in zip(ts,raw) if b>100];pcm=m.pcm(out);onsets=[]
            for i in range(0,len(pcm)-480,480):
                if sum(abs(x) for x in pcm[i:i+480])/480>1000 and (not onsets or i/48000-onsets[-1]>.15):onsets.append(i/48000)
            assert len(onsets)==2,onsets;error=max(min(abs(a-v) for v in flashes) for a in onsets);assert error<.04,error
            return {'max_av_error_s':error}
        for profile in ['h264_publish','hevc_publish','vp9_publish','prores_master']:case('decoded_av_sync_'+profile,lambda p=profile:sync(p))
        def cancellation():
            p=subprocess.Popen([m.FFMPEG,'-v','error','-nostdin','-re','-stream_loop','-1','-i',str(base),'-c:v','libx264','-preset','fast','-threads','2','-an','-f','null','-'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
            try:time.sleep(.12);p.terminate();p.wait(timeout=5);assert p.returncode!=0
            finally:
                if p.poll() is None:p.kill();p.wait()
        case('long_encoder_interrupts_and_reaps',cancellation)
    report={'scope':'Independent FFmpeg delivery recipes; Rust adapter and workflow tests NOT executed','ffmpeg':m.execute([m.FFMPEG,'-version']).decode().splitlines()[0],
            'passed':sum(x['status']=='passed' for x in rows),'failed':sum(x['status']=='failed' for x in rows),'tests':rows}
    ns.output.parent.mkdir(parents=True,exist_ok=True);ns.output.write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n');raise SystemExit(bool(report['failed']))
if __name__=='__main__':main()
