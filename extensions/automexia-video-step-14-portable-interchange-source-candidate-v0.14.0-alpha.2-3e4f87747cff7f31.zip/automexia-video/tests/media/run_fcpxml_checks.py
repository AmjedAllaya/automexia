#!/usr/bin/env python3
"""Independent FCPXML 1.10 XML/schema/clock checks; does not execute Rust.

An optional external Apple DTD adds official grammar validation. Local authored
profile validation is reported separately; neither layer is a GUI import test.
"""
from __future__ import annotations
import argparse, copy, hashlib, json, os, re, shutil, tempfile, time
from fractions import Fraction as F
from pathlib import Path
from urllib.parse import quote, unquote, urlsplit
from lxml import etree as E

ROOT=Path(__file__).resolve().parents[2]
PROFILE=ROOT/'tests/fcpxml_fixtures/automexia-cuts-profile.dtd'
APPLE_SOURCE='https://developer.apple.com/documentation/professional-video-applications/document-type-definition'
SUPPORTED_AUDIO={32000:'32k',44100:'44.1k',48000:'48k',88200:'88.2k',96000:'96k',176400:'176.4k',192000:'192k'}

def clock(value):
    value=F(value)
    if value<0 or value.denominator>2**32-1 or value.numerator>2**63-1:raise ValueError('unrepresentable exact FCPXML time')
    return f'{value.numerator}s' if value.denominator==1 else f'{value.numerator}/{value.denominator}s'

def read_clock(text):
    if not isinstance(text,str) or not re.fullmatch(r'\d+(?:/[1-9]\d*)?s',text):raise ValueError('invalid rational time')
    result=F(text[:-1]);clock(result);return result

def node(parent,tag,**attrs):return E.SubElement(parent,tag,{k:str(v) for k,v in attrs.items()})
def md(parent,key,value):return node(parent,'md',key=key,value=value)

def fixture(rate=F(30000,1001),clips=((40,60),(0,20),(40,60)),source_tc=0,record_tc=0,audio=True,audio_end=F(1001,500),sample_rate=48000,stereo=False,stem=False,markers=(),sar=(1,1),url='Media/input%20%26%20%CE%B1.mov'):
    """Small authored reference model; expected ordering is checked separately."""
    if audio and sample_rate not in SUPPORTED_AUDIO:raise ValueError('unsupported audio sequence rate')
    root=E.Element('fcpxml',version='1.10');res=node(root,'resources')
    node(res,'format',id='r-format',frameDuration=clock(1/rate),width='160',height='96',fieldOrder='progressive',paspH=sar[0],paspV=sar[1])
    original_start=F(source_tc)/rate;record_start=F(record_tc)/rate
    asset=node(res,'asset',id='r-video',name='input & α.mov',start=clock(original_start),duration=clock(max(F(60)/rate,audio_end) if audio and not stem else F(60)/rate),hasVideo='1',format='r-format',videoSources='1')
    if audio and not stem:asset.attrib.update({'hasAudio':'1','audioSources':'1','audioChannels':'2' if stereo else '1','audioRate':str(sample_rate)})
    node(asset,'media-rep',kind='original-media',src=url);md(node(asset,'metadata'),'org.automexia.media.sha256','a'*64)
    duration=sum((F(b-a)/rate for a,b in clips),F(0))
    if stem:
        a=node(res,'asset',id='r-audio',name='stem.wav',start='0s',duration=clock(duration),hasVideo='0',hasAudio='1',audioSources='1',audioChannels='2' if stereo else '1',audioRate=str(sample_rate))
        node(a,'media-rep',kind='original-media',src='Media/stem.wav');md(node(a,'metadata'),'org.automexia.media.sha256','b'*64)
    seq=node(node(node(node(root,'library'),'event',name='Automexia'),'project',name='Assembly <α & β>'),'sequence',format='r-format',duration=clock(duration),tcStart=clock(record_start),tcFormat='NDF')
    if audio:seq.attrib.update({'audioLayout':'stereo' if stereo else 'mono','audioRate':SUPPORTED_AUDIO[sample_rate]})
    spine=node(seq,'spine');record=F(0)
    for index,(first,last) in enumerate(clips):
        source=F(first)/rate;length=F(last-first)/rate;local=source+original_start
        c=node(spine,'clip',name=f'clip-{index+1}',offset=clock(record_start+record),start=clock(local),duration=clock(length),format='r-format',tcFormat='NDF')
        node(c,'video',ref='r-video',offset=clock(local),start=clock(local),duration=clock(length))
        if audio:
            available=length if stem else min(length,max(F(0),audio_end-source))
            if available:node(c,'audio',ref='r-audio' if stem else 'r-video',lane='-1',name=f'clip-{index+1}',offset=clock(local),start=clock(record if stem else local),duration=clock(available),srcCh='1,2' if stereo else '1',role='dialogue')
        ids=[];ranges=[]
        for ident,at,extent,title,comment in markers:
            if source<=at<source+length:
                mlen=min(extent,source+length-at)
                if (at*rate).denominator!=1:raise ValueError('point marker must be frame aligned')
                node(c,'marker',start=clock(original_start+at),duration=clock(1/rate),value=title,note=comment);ids.append(f'{ident}-{index+1}')
                ranges.append({'id':ids[-1],'at':str(at),'duration':str(mlen)})
        meta=node(c,'metadata');md(meta,'org.automexia.clip-id',f'clip-{index+1}')
        if ids:
            md(meta,'org.automexia.marker-ids',json.dumps(ids));md(meta,'org.automexia.marker-ranges',json.dumps(ranges))
        record+=length
    meta=node(seq,'metadata');md(meta,'org.automexia.compatibility',json.dumps({'application_import_tested':False,'note':'α & β\n\t\r'},ensure_ascii=False));md(meta,'org.automexia.fcpxml-profile','1.10 cuts; exact rational clocks; editor import unqualified')
    return root

def validate(root):
    """Decode semantics independently from authored reference construction."""
    assert root.tag=='fcpxml' and root.get('version')=='1.10'
    ids={}
    for el in root.iter():
        if ident:=el.get('id'):
            assert ident not in ids,'duplicate XML resource ID';ids[ident]=el
    for el in root.iter():
        for key in ('ref','format'):
            if value:=el.get(key):assert value in ids,'unresolved resource reference'
    for rep in root.findall('.//media-rep'):
        src=rep.get('src');parts=urlsplit(src)
        assert src and not src.startswith('//') and not parts.query and not parts.fragment
        assert parts.scheme in ('','file') and parts.netloc=='','external authority forbidden'
        if parts.scheme=='file':assert parts.path.startswith('/')
        else:assert not parts.path.startswith('/')
        assert not any(ord(c)<32 for c in src)
    seq=root.find('.//sequence');rate=1/read_clock(ids[seq.get('format')].get('frameDuration'))
    expected=read_clock(seq.get('tcStart'));finish=expected+read_clock(seq.get('duration'))
    count=0
    for clip in seq.find('spine'):
        offset=read_clock(clip.get('offset'));start=read_clock(clip.get('start'));length=read_clock(clip.get('duration'))
        assert offset==expected and length>0 and (length*rate).denominator==1,'video gap/overlap/off-grid'
        videos=clip.findall('video');assert len(videos)==1
        for component in videos+clip.findall('audio'):
            resource=ids[component.get('ref')];resource_start=read_clock(resource.get('start'));resource_end=resource_start+read_clock(resource.get('duration'))
            at=read_clock(component.get('offset'));inside=read_clock(component.get('start'));extent=read_clock(component.get('duration'))
            assert start<=at<start+length and at+extent<=start+length and extent>0,'component outside parent'
            assert resource_start<=inside and inside+extent<=resource_end,'component exceeds media'
            if component.tag=='video':assert at==start and inside==start and extent==length
            else:
                assert component.get('lane')=='-1';assert resource.get('hasAudio')=='1';assert component.get('srcCh') in ('1','1,2')
        for marker in clip.findall('marker'):
            at=read_clock(marker.get('start'));extent=read_clock(marker.get('duration'))
            assert start<=at<start+length and at+extent<=start+length,'marker outside local clip clock'
            assert extent==1/rate and (at*rate).denominator==1,'FCP markers are frame-aligned single-frame points'
        expected+=length;count+=1
    assert expected==finish,'wrong sequence duration'
    meta=seq.find("metadata/md[@key='org.automexia.compatibility']");report=json.loads(meta.get('value'))
    assert report['application_import_tested'] is False
    return {'clips':count,'duration':str(read_clock(seq.get('duration'))),'rate':str(rate)}

def reject(call):
    try:call()
    except (AssertionError,ValueError,E.XMLSyntaxError):return
    raise AssertionError('malformed reference accepted')

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,required=True);ap.add_argument('--keep',type=Path);ap.add_argument('--apple-dtd',type=Path);ap.add_argument('--rust-exports',type=Path);args=ap.parse_args()
    began=time.monotonic();rows=[];external_count=0;profile=E.DTD(str(PROFILE));official=None;official_hash=None
    path=args.apple_dtd or (Path(os.environ['AMX_FCPXML_DTD']) if os.environ.get('AMX_FCPXML_DTD') else None)
    if path:
        blob=path.read_bytes();assert re.search(rb'<!ATTLIST\s+fcpxml\s+version\s+CDATA\s+#FIXED\s+"1\.10"',blob),'external DTD is not declared FCPXML1.10'
        official=E.DTD(str(path));official_hash=hashlib.sha256(blob).hexdigest()
    def case(name,call):
        try:detail=call() or {};rows.append({'name':name,'status':'passed','details':detail});print('PASS',name,flush=True)
        except Exception as error:rows.append({'name':name,'status':'failed','error':str(error)});print('FAIL',name,str(error),flush=True)
    def grammar(doc,dtd):
        assert dtd.validate(doc),str(dtd.error_log);return {'root':'fcpxml','version':'1.10'}
    with tempfile.TemporaryDirectory(prefix='amx-fcpxml-') as temp:
        work=args.keep or Path(temp);work.mkdir(parents=True,exist_ok=True)
        fixtures={
            'repeat_ntsc':fixture(), 'video_only':fixture(audio=False), 'nonzero_clocks':fixture(source_tc=300,record_tc=900),
            'short_sample_audio':fixture(clips=((0,60),),audio_end=F(2)), 'stem_split':fixture(stem=True),
            'stereo':fixture(stereo=True),'nonsquare_pixels':fixture(sar=(4,3)),
            'unicode_markers':fixture(markers=(('note',F(45)*F(1001,30000),F(0),'<α & β>','"quoted"\n\t\r'),)),
            'ranged_marker':fixture(clips=((0,60),),markers=(('range',F(1001,30000),F(1,48000),'range',''),)),
            'relative_encoded':fixture(url='Media/'+quote('percent% & α.mov')),
            'absolute_url':fixture(url='file:///media/'+quote('input & α.mov')),
        }
        for name,doc in fixtures.items():
            blob=E.tostring(doc,xml_declaration=True,encoding='UTF-8',doctype='<!DOCTYPE fcpxml>');(work/(name+'.fcpxml')).write_bytes(blob)
            parsed=E.fromstring(blob,E.XMLParser(resolve_entities=False,no_network=True))
            case(name+'_authored_profile',lambda d=parsed:grammar(d,profile))
            case(name+'_exact_semantics',lambda d=parsed:validate(d))
            if official:case(name+'_official_apple_1_10_dtd',lambda d=parsed:grammar(d,official))
        if not official:rows.append({'name':'official_apple_1_10_dtd','status':'blocked','reason':'Supply Apple FCPXML1.10 DTD with AMX_FCPXML_DTD or --apple-dtd; authored schema is not official validation.'})
        def repeated():
            doc=fixtures['repeat_ntsc'];actual=[read_clock(v.get('start'))*F(30000,1001) for v in doc.findall('.//video')];assert actual==[40,0,40];return {'source_frames':list(map(int,actual))}
        case('repeat_order_decoded_independently',repeated)
        def short_audio():
            c=fixtures['short_sample_audio'].find('.//clip');a=c.find('audio');assert read_clock(a.get('duration'))==2;assert read_clock(c.get('duration'))-read_clock(a.get('duration'))==F(1,500)
        case('short_audio_silent_tail_exact_96_samples',short_audio)
        def stem():
            doc=fixtures['stem_split'];starts=[read_clock(a.get('start')) for a in doc.findall('.//audio')];assert starts==[F(0),F(1001,1500),F(1001,750)]
        case('stem_consumes_output_clock_across_reordered_source',stem)
        def markers():
            doc=fixtures['unicode_markers'];found=doc.findall('.//marker');assert len(found)==2;assert all(read_clock(m.get('start'))==F(3003,2000) for m in found);assert all(m.get('note')=='"quoted"\n\t\r' for m in found)
        case('repeated_marker_local_clocks_and_whitespace',markers)
        def payload():
            path=work/'Media'/'percent% & α.mov';path.parent.mkdir(exist_ok=True);path.write_bytes(b'portable media fixture')
            relocated=work/'Relocated';relocated.mkdir(exist_ok=True)
            shutil.copytree(work/'Media',relocated/'Media',dirs_exist_ok=True)
            shutil.copyfile(work/'relative_encoded.fcpxml',relocated/'timeline.fcpxml')
            imported=E.parse(str(relocated/'timeline.fcpxml'),E.XMLParser(resolve_entities=False,no_network=True))
            ref=imported.find('.//media-rep').get('src');assert (relocated/unquote(ref)).read_bytes()==path.read_bytes()
            assert (relocated/unquote(ref)).resolve()!=path.resolve();return {'relative_src':ref,'relocated':True}
        case('relocated_percent_unicode_relative_reference',payload)
        for rate in (F(24),F(25),F(30),F(48),F(50),F(60),F(24000,1001),F(30000,1001),F(60000,1001)):
            case('exact_rate_'+str(rate).replace('/','_'),lambda rate=rate:validate(fixture(rate=rate,audio=False)))
        for sr in SUPPORTED_AUDIO:case('audio_enum_'+str(sr),lambda sr=sr:grammar(fixture(sample_rate=sr),profile))
        mutations={
            'unknown_resource':lambda x:x.find('.//video').set('ref','missing'),
            'primary_gap':lambda x:x.find('.//clip').set('offset','1s'),
            'wrong_sequence_duration':lambda x:x.find('.//sequence').set('duration','3s'),
            'audio_outside_parent':lambda x:x.find('.//audio').set('duration','9s'),
            'video_outside_asset':lambda x:x.find('.//video').set('start','99s'),
            'fake_import_qualification':lambda x:x.find(".//sequence/metadata/md[@key='org.automexia.compatibility']").set('value','{"application_import_tested":true}'),
            'remote_reference':lambda x:x.find('.//media-rep').set('src','https://example.invalid/media.mov'),
        }
        for name,mutate in mutations.items():
            doc=copy.deepcopy(fixtures['repeat_ntsc']);mutate(doc);case('reject_'+name,lambda doc=doc:reject(lambda:validate(doc)))
        case('reject_wide_denominator',lambda:reject(lambda:clock(F(1,2**32))))
        case('reject_negative_time',lambda:reject(lambda:clock(F(-1))))
        case('reject_float_wire_clock',lambda:reject(lambda:read_clock('0.033366666s')))
        case('reject_unsupported_16k_sequence',lambda:reject(lambda:fixture(sample_rate=16000)))
        case('reject_nonframe_point_marker',lambda:reject(lambda:fixture(clips=((0,60),),markers=(('sample',F(1,48000),F(0),'sample',''),))))
        def marker_range():
            doc=fixtures['ranged_marker'];point=doc.find('.//marker');assert read_clock(point.get('duration'))==F(1001,30000)
            meta=doc.find(".//clip/metadata/md[@key='org.automexia.marker-ranges']");assert F(json.loads(meta.get('value'))[0]['duration'])==F(1,48000)
        case('ranged_marker_point_display_with_exact_original_metadata',marker_range)
        def invalid_version():
            d=fixture();d.set('version','1.9');assert not profile.validate(d)
        case('restricted_profile_rejects_wrong_version',invalid_version)
        def misplaced_url():
            d=fixture();d.find('.//asset').set('src','Media/a.mov');assert not profile.validate(d)
            if official:assert not official.validate(d)
        case('version_ten_rejects_legacy_asset_src',misplaced_url)
        def escaped_size(text):
            return sum({'&':5,'<':4,'>':4,'"':6,"'":6,'\t':4,'\n':5,'\r':5}.get(c,len(c.encode())) for c in text)
        def expansion(character,expect_reject):
            comment=character*1024;count=128*32
            # Measure the two places where each repeated comment is emitted:
            # native point attributes and the original range JSON attribute.
            row=json.dumps({'id':'marker-127-4096','at':'9223372036854775807/9223372036854775807','duration':'9223372036854775807/9223372036854775807','name':'','comment':comment},ensure_ascii=False,separators=(',',':'))
            identity=json.dumps('marker-127-4096')
            per=512+escaped_size(comment)+escaped_size(row)+escaped_size(identity)
            base_report=json.dumps({'markers':[{'id':f'marker-{i}','comment':comment} for i in range(128)]},ensure_ascii=False)
            estimate=escaped_size(base_report)+256*1024+128*2048+1024+count*per
            lower_bound=count*(escaped_size(comment)+escaped_size(json.dumps(comment)[1:-1]))
            if expect_reject:assert lower_bound>16*1024*1024 and estimate>16*1024*1024
            else:assert estimate<16*1024*1024
            return {'mapped_markers':count,'conservative_reference_bytes':estimate,'repeated_comment_lower_bound':lower_bound,'limit':16*1024*1024,'bake_flattens_video_but_keeps_markers':True}
        case('escaped_marker_bytes_exceed_limit_even_after_bake',lambda:expansion('&',True))
        case('quoted_marker_json_and_xml_expansion_exceeds_limit',lambda:expansion('"',True))
        case('plain_marker_reference_stays_below_conservative_budget',lambda:expansion('a',False))
        if args.rust_exports:
            external_paths=sorted(args.rust_exports.glob('*.fcpxml'));external_count=len(external_paths)
            if not external_paths:rows.append({'name':'external_rust_fcpxml_readback','status':'blocked','reason':'No .fcpxml documents found in the supplied directory.'})
            for path in external_paths:
                parsed=E.parse(str(path),E.XMLParser(resolve_entities=False,no_network=True)).getroot();case('external_rust_'+path.name+'_semantics',lambda d=parsed:validate(d));case('external_rust_'+path.name+'_profile',lambda d=parsed:grammar(d,profile))
                if official:case('external_rust_'+path.name+'_official_dtd',lambda d=parsed:grammar(d,official))
    report={'suite':'step14b-fcpxml-reference','scope':'Authored Python reference documents and independent XML/clock decoding. This run does not compile/execute Rust or import into Final Cut Pro.','passed':sum(r['status']=='passed' for r in rows),'failed':sum(r['status']=='failed' for r in rows),'blocked':sum(r['status']=='blocked' for r in rows),'official_dtd':{'source':APPLE_SOURCE,'sha256':official_hash,'provided':official is not None},'authored_profile_sha256':hashlib.sha256(PROFILE.read_bytes()).hexdigest(),'external_rust_documents_supplied':external_count>0,'external_rust_document_count':external_count,'cases':rows,'seconds':round(time.monotonic()-began,3)}
    args.output.parent.mkdir(parents=True,exist_ok=True);args.output.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:report[k] for k in ('passed','failed','blocked')}));return 1 if report['failed'] else 0
if __name__=='__main__':raise SystemExit(main())
