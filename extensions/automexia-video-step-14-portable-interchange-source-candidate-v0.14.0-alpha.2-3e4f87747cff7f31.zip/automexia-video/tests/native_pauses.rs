//! Executes the actual Rust host, analyzer, project/review model and renderer.
//! Requires approved local FFmpeg/ffprobe >=7.1. No network or model downloads.
use automexia_video::*;
use automexia_video::host::MediaHost;
use automexia_video::native::{NativeMediaHost,NativeSettings};
use automexia_video::pause::*;
use std::{fs,path::{Path,PathBuf},process::Command,time::Duration};
use tempfile::TempDir;
fn tool(name:&str)->PathBuf{std::env::var_os(name).map(PathBuf::from).unwrap_or_else(||PathBuf::from(if name=="FFMPEG"{"/usr/bin/ffmpeg"}else{"/usr/bin/ffprobe"}))}
fn ext()->VideoExtension<NativeMediaHost>{VideoExtension::new(NativeMediaHost::new(NativeSettings::new(tool("FFMPEG"),tool("FFPROBE"))).unwrap(),VideoSettings::default()).unwrap()}
fn fixture(dir:&Path,expression:&str)->PathBuf{
    let p=dir.join("recording.mp4");let result=Command::new(tool("FFMPEG")).args(["-v","error","-nostdin","-y","-f","lavfi","-i","testsrc2=size=160x96:rate=30:duration=10","-f","lavfi","-i"])
        .arg(format!("aevalsrc=exprs='{expression}':sample_rate=48000:duration=10"))
        .args(["-c:v","libx264","-threads","2","-pix_fmt","yuv420p","-c:a","aac"]).arg(&p).status().unwrap();assert!(result.success());p
}
fn ordinary(dir:&Path)->PathBuf{fixture(dir,"if(between(t,2,6),0,0.2*sin(2*PI*440*t))")}
fn create(x:&VideoExtension<NativeMediaHost>,input:&Path,where_:&Path)->Project{x.create_project(&NewProjectRequest::new("native-pauses",input,where_),&Cancellation::new(),&mut |_|{}).unwrap()}
fn analyze(x:&VideoExtension<NativeMediaHost>,p:&Project,path:&Path)->PauseReport{x.analyze_pauses(p,&PauseAnalysisRequest::new(path),&Cancellation::new(),&mut |_|{}).unwrap()}
fn approve(p:&mut Project,report:&PauseReport){for c in report.candidates(){p.review_operation(&c.operation.id,Disposition::AutoApply,true).unwrap();}}
#[test]fn actual_analyze_review_save_reopen_render_and_restore(){
    let d=TempDir::new().unwrap();let i=ordinary(d.path());let before=fs::read(&i).unwrap();let pth=d.path().join("session.amxv");let x=ext();let c=Cancellation::new();let mut p=create(&x,&i,&pth);
    let report=analyze(&x,&p,&pth);assert_eq!(report.candidates().len(),1);assert!(report.proposed_removed_duration()>"3".parse().unwrap());
    report.apply(&mut p).unwrap();assert!(matches!(p.timeline(),Err(Error::UnresolvedEdits)));approve(&mut p,&report);
    x.save_project(&p,&pth,&OutputPolicy::CreateNew,&c).unwrap();let loaded=x.load_project(&pth,&c).unwrap();assert!(loaded.project.settings.pause_cleanup.is_some());
    let out=d.path().join("shorter.mp4");let result=x.render_project(&loaded.project,&ProjectRenderRequest::new(&pth,&out),&c,&mut |_|{}).unwrap();assert!(result.media.full_decode_validated);assert_eq!(result.timeline.duration,report.proposed_duration());
    for op in &report.candidates().iter().map(|c|c.operation.id.clone()).collect::<Vec<_>>(){p.review_operation(op,Disposition::Ignore,false).unwrap();}
    let result=x.render_project(&p,&ProjectRenderRequest::new(&pth,d.path().join("restored.mp4")),&c,&mut |_|{}).unwrap();assert_eq!(result.timeline.duration,p.sources[0].duration);assert_eq!(fs::read(i).unwrap(),before);
}
#[test]fn analysis_itself_writes_no_project_cache_or_media(){let d=TempDir::new().unwrap();let i=ordinary(d.path());let pth=d.path().join("draft.amxv");let x=ext();let p=create(&x,&i,&pth);let _=analyze(&x,&p,&pth);assert!(!pth.exists());assert_eq!(fs::read_dir(d.path()).unwrap().count(),1);}
#[test]fn all_silent_source_is_not_deleted(){let d=TempDir::new().unwrap();let i=fixture(d.path(),"0");let pth=d.path().join("draft.amxv");let x=ext();let p=create(&x,&i,&pth);assert!(analyze(&x,&p,&pth).candidates().is_empty());}
#[test]fn clean_continuous_sound_has_no_pause_candidates(){let d=TempDir::new().unwrap();let i=fixture(d.path(),"0.2*sin(2*PI*440*t)");let pth=d.path().join("draft.amxv");let x=ext();let p=create(&x,&i,&pth);assert!(analyze(&x,&p,&pth).candidates().is_empty());}
#[test]fn no_downmix_hides_second_channel(){let d=TempDir::new().unwrap();let i=fixture(d.path(),"0|0.1*sin(2*PI*440*t)");let pth=d.path().join("draft.amxv");let x=ext();let p=create(&x,&i,&pth);assert!(analyze(&x,&p,&pth).candidates().is_empty());}
#[test]fn music_declaration_preserves_by_default(){let d=TempDir::new().unwrap();let i=ordinary(d.path());let pth=d.path().join("draft.amxv");let x=ext();let p=create(&x,&i,&pth);let mut req=PauseAnalysisRequest::new(&pth);req.settings.content=AudioContent::MixedMusic;assert!(x.analyze_pauses(&p,&req,&Cancellation::new(),&mut |_|{}).unwrap().candidates().is_empty());}
#[test]fn protected_native_interval_is_not_cut(){let d=TempDir::new().unwrap();let i=ordinary(d.path());let pth=d.path().join("draft.amxv");let x=ext();let mut p=create(&x,&i,&pth);p.protect_range("source-1",TimeRange::new("3".parse().unwrap(),"4".parse().unwrap()).unwrap(),"keep my pause").unwrap();assert!(analyze(&x,&p,&pth).candidates().is_empty());}
#[test]fn cancelled_metrics_cannot_return_a_partial_report(){let d=TempDir::new().unwrap();let i=ordinary(d.path());let pth=d.path().join("draft.amxv");let x=ext();let p=create(&x,&i,&pth);let c=Cancellation::new();let linked=c.clone();let result=x.analyze_pauses(&p,&PauseAnalysisRequest::new(&pth),&c,&mut |e|{if e.stage==automexia_video::progress::Stage::Analyzing&&e.out_time_us.is_some(){linked.cancel();}});assert!(matches!(result,Err(Error::Cancelled)));assert_eq!(x.status().unwrap().active_jobs,0);assert_eq!(fs::read_dir(d.path()).unwrap().count(),1);}
#[test]fn disabled_extension_does_not_start_analysis(){let d=TempDir::new().unwrap();let i=ordinary(d.path());let pth=d.path().join("draft.amxv");let x=ext();let p=create(&x,&i,&pth);x.disable().unwrap();assert!(matches!(x.analyze_pauses(&p,&PauseAnalysisRequest::new(&pth),&Cancellation::new(),&mut |_|{}),Err(Error::Disabled)));}
#[test]fn changed_source_rejected_before_analysis(){let d=TempDir::new().unwrap();let i=ordinary(d.path());let pth=d.path().join("draft.amxv");let x=ext();let p=create(&x,&i,&pth);fs::write(&i,b"changed").unwrap();assert!(matches!(x.analyze_pauses(&p,&PauseAnalysisRequest::new(&pth),&Cancellation::new(),&mut |_|{}),Err(Error::InputChanged)));}
#[test]fn panicking_progress_does_not_publish_a_report_or_leak_job(){let d=TempDir::new().unwrap();let i=ordinary(d.path());let pth=d.path().join("draft.amxv");let x=ext();let p=create(&x,&i,&pth);let result=x.analyze_pauses(&p,&PauseAnalysisRequest::new(&pth),&Cancellation::new(),&mut |e|{if e.stage==automexia_video::progress::Stage::Analyzing{panic!("test callback");}});assert!(matches!(result,Err(Error::CallbackPanicked)));assert_eq!(x.status().unwrap().active_jobs,0);}
#[test]fn timing_limit_checked_before_long_decode(){let d=TempDir::new().unwrap();let i=ordinary(d.path());let pth=d.path().join("draft.amxv");let x=ext();let p=create(&x,&i,&pth);let mut req=PauseAnalysisRequest::new(&pth);req.settings.max_analysis_seconds=1;assert!(x.analyze_pauses(&p,&req,&Cancellation::new(),&mut |_|{}).is_err());}
#[test]fn typed_stream_sink_failure_stops_child(){use automexia_video::pause_workflow::AudioAnalysisHost;let d=TempDir::new().unwrap();let i=ordinary(d.path());let pth=d.path().join("draft.amxv");let x=ext();let p=create(&x,&i,&pth);let c=Cancellation::new();let inp=x.host().inspect_input(&i,&c).unwrap();let req=AnalysisDecode::from_project(&p,inp,Duration::from_secs(30)).unwrap();assert!(matches!(x.host().stream_energy(&req,&c,&mut |_|Err(Error::Cancelled)),Err(Error::Cancelled)));}
