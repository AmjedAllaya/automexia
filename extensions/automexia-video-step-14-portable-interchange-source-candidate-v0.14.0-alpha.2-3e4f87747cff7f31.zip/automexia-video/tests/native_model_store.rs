#![cfg(feature = "native")]
use automexia_video::model_pack::*;
use automexia_video::model_store::ModelStorage;
use automexia_video::native_model_store::*;
use automexia_video::{Cancellation, Error};
use sha2::{Digest, Sha256};
use std::fs;
use std::path::Path;
// Use canonical parent paths on Windows too, where canonicalization may add
// the verbatim path prefix required by the storage adapter's explicit contract.
fn tempdir() -> tempfile::TempDir { tempfile::tempdir_in(fs::canonicalize(std::env::temp_dir()).unwrap()).unwrap() }
fn digest(bytes: &[u8]) -> String { format!("{:x}", Sha256::digest(bytes)) }
fn pack(revision: &str) -> VerifiedModelPack {
    let weights = vec![8, 8, 58, 0]; let notices = b"synthetic structural fixture, not trained weights";
    let m = ModelManifest { schema: 1, id: "speech-fixture".into(), revision: revision.into(), source_revision: "test-only".into(), contract: SILERO_CONTRACT.into(), preprocessing: SPEECH_PROCESSING.into(), weights_sha256: digest(&weights), weights_bytes: weights.len() as u64, runtime: ModelRuntime { adapter: "fake".into(), artifact_sha256: "a".repeat(64), build_info_sha256: "b".repeat(64) }, code_license: "test".into(), weights_license: "test".into(), notices_sha256: digest(notices) };
    let m = serde_json::to_vec(&m).unwrap(); VerifiedModelPack::verify(&m, weights, notices, &digest(&m), &Cancellation::new()).unwrap()
}
fn open(path: &Path) -> NativeModelStore { NativeModelStorage::open(path, &Cancellation::new()).unwrap().into_store(&Cancellation::new()).unwrap() }
#[test] fn installed_bytes_and_selection_survive_reopening() {
    let d = tempdir(); let path = d.path().join("models"); let p = pack("1"); let c = Cancellation::new();
    let s = open(&path); s.install(&p, 0, &c).unwrap(); let old = s.select(&p.identity().manifest_sha256, 1, &c).unwrap(); drop(s);
    assert!(old.check().is_err()); let s = open(&path); assert_eq!(s.inventory(&c).unwrap().generation, 2);
    let selected = s.selected(SILERO_CONTRACT, &c).unwrap().unwrap(); assert_eq!(selected.pack().identity(), p.identity()); assert_eq!(selected.pack().notices(), p.notices());
}
#[test] fn installation_does_not_create_selection() { let d = tempdir(); let s = open(&d.path().join("models")); s.install(&pack("1"), 0, &Cancellation::new()).unwrap(); assert!(s.selected(SILERO_CONTRACT, &Cancellation::new()).unwrap().is_none()); }
#[test] fn simultaneous_manager_is_rejected_and_lock_releases_on_drop() { let d = tempdir(); let p = d.path().join("models"); let first = open(&p); assert!(matches!(NativeModelStorage::open(&p, &Cancellation::new()), Err(Error::Busy))); drop(first); assert!(NativeModelStorage::open(&p, &Cancellation::new()).is_ok()); }
#[test] fn model_store_lock_child() {
    let Some(root) = std::env::var_os("VIDEO_TEST_MODEL_STORE_LOCK_ROOT") else { return; };
    assert!(matches!(NativeModelStorage::open(Path::new(&root), &Cancellation::new()), Err(Error::Busy)));
}
#[test] fn lock_excludes_another_process() {
    let d = tempdir(); let path = d.path().join("models"); let _s = open(&path);
    let status = std::process::Command::new(std::env::current_exe().unwrap()).args(["--exact", "model_store_lock_child", "--nocapture"])
        .env("VIDEO_TEST_MODEL_STORE_LOCK_ROOT", &path).status().unwrap(); assert!(status.success());
}
#[test] fn tampered_pack_is_rejected_before_selection() { let d = tempdir(); let path = d.path().join("models"); let s = open(&path); let p = pack("1"); s.install(&p, 0, &Cancellation::new()).unwrap(); fs::write(path.join("packs").join(&p.identity().manifest_sha256).join("weights.bin"), [8, 7, 58, 0]).unwrap(); assert!(s.select(&p.identity().manifest_sha256, 1, &Cancellation::new()).is_err()); assert!(s.inventory(&Cancellation::new()).unwrap().selected.is_empty()); }
#[test] fn tampered_persisted_inventory_is_not_silently_reset() { let d = tempdir(); let path = d.path().join("models"); drop(open(&path)); fs::write(path.join("inventory.json"), br#"{"schema":1,"generation":0,"installed":[],"selected":{"bad":"fake"}}"#).unwrap(); assert!(NativeModelStorage::open(&path, &Cancellation::new()).unwrap().into_store(&Cancellation::new()).is_err()); }
#[test] fn removed_pack_files_are_deleted_but_reader_bytes_remain_owned() { let d = tempdir(); let path = d.path().join("models"); let s = open(&path); let p = pack("1"); let c = Cancellation::new(); s.install(&p, 0, &c).unwrap(); let reader = s.select(&p.identity().manifest_sha256, 1, &c).unwrap(); let result = s.remove(&p.identity().manifest_sha256, 2, &c).unwrap(); assert!(result.files_removed); assert!(!path.join("packs").join(&p.identity().manifest_sha256).exists()); assert!(reader.check().is_err()); assert_eq!(reader.pack().weights(), p.weights()); }
#[test] fn unexpected_pack_file_is_not_recursively_deleted() { let d = tempdir(); let path = d.path().join("models"); let s = open(&path); let p = pack("1"); let c = Cancellation::new(); s.install(&p, 0, &c).unwrap(); let directory = path.join("packs").join(&p.identity().manifest_sha256); fs::write(directory.join("unrecognized"), b"preserve").unwrap(); let outcome = s.remove(&p.identity().manifest_sha256, 1, &c).unwrap(); assert!(!outcome.files_removed); assert_eq!(fs::read(directory.join("unrecognized")).unwrap(), b"preserve"); fs::remove_file(directory.join("unrecognized")).unwrap(); assert!(s.purge_unreferenced(&p.identity().manifest_sha256, 2, &c).unwrap()); }
#[test] fn explicit_orphan_cleanup_uses_only_requested_digest() { let d = tempdir(); let path = d.path().join("models"); let storage = NativeModelStorage::open(&path, &Cancellation::new()).unwrap(); let p = pack("1"); storage.write_pack(&p, &Cancellation::new()).unwrap(); let s = storage.into_store(&Cancellation::new()).unwrap(); assert!(s.inventory(&Cancellation::new()).unwrap().installed.is_empty()); assert!(s.purge_unreferenced(&p.identity().manifest_sha256, 0, &Cancellation::new()).unwrap()); }
#[test] fn verified_orphan_is_reused_on_explicit_install_retry() { let d = tempdir(); let path = d.path().join("models"); let storage = NativeModelStorage::open(&path, &Cancellation::new()).unwrap(); let p = pack("1"); storage.write_pack(&p, &Cancellation::new()).unwrap(); let s = storage.into_store(&Cancellation::new()).unwrap(); s.install(&p, 0, &Cancellation::new()).unwrap(); assert_eq!(fs::read_dir(path.join("packs")).unwrap().count(), 1); }
#[test] fn update_cas_and_prior_activation_are_preserved_after_restart() { let d = tempdir(); let path = d.path().join("models"); let s = open(&path); let a = pack("1"); let b = pack("2"); let c = Cancellation::new(); s.install(&a, 0, &c).unwrap(); let old = s.select(&a.identity().manifest_sha256, 1, &c).unwrap(); let current = s.update_selected(&a.identity().manifest_sha256, &b, 2, &c).unwrap(); assert!(old.check().is_err()); assert!(current.check().is_ok()); drop(s); let s = open(&path); assert_eq!(s.selected(SILERO_CONTRACT, &c).unwrap().unwrap().pack().identity(), b.identity()); }
#[test] fn malformed_digest_fails_before_selected_file_io() { let path = Path::new("/missing-model"); assert!(matches!(read_selected_pack(path, path, path, "bad", &Cancellation::new()), Err(Error::InvalidInput(_)))); }
#[test] fn relative_storage_path_is_rejected() { assert!(NativeModelStorage::open(Path::new("models"), &Cancellation::new()).is_err()); }
#[test] fn cancellation_before_open_does_not_create_directory() { let d = tempdir(); let path = d.path().join("models"); let c = Cancellation::new(); c.cancel(); assert!(matches!(NativeModelStorage::open(&path, &c), Err(Error::Cancelled))); assert!(!path.exists()); }
#[test] fn no_staging_directories_remain_after_success() { let d = tempdir(); let path = d.path().join("models"); let s = open(&path); s.install(&pack("1"), 0, &Cancellation::new()).unwrap(); for parent in [&path, &path.join("packs")] { assert!(fs::read_dir(parent).unwrap().all(|e| !e.unwrap().file_name().to_string_lossy().starts_with(".model-"))); } }
#[cfg(unix)] #[test] fn store_directory_and_installed_files_are_owner_only() { use std::os::unix::fs::PermissionsExt; let d = tempdir(); let path = d.path().join("models"); let s = open(&path); let p = pack("1"); s.install(&p, 0, &Cancellation::new()).unwrap(); for entry in [path.clone(), path.join("packs"), path.join("packs").join(&p.identity().manifest_sha256)] { assert_eq!(fs::metadata(entry).unwrap().permissions().mode() & 0o077, 0); } for entry in [path.join("inventory.json"), path.join("model-store.lock"), path.join("packs").join(&p.identity().manifest_sha256).join("weights.bin")] { assert_eq!(fs::metadata(entry).unwrap().permissions().mode() & 0o077, 0); } }
#[cfg(unix)] #[test] fn symlinked_store_or_pack_directory_is_rejected() { use std::os::unix::fs::symlink; let d = tempdir(); let real = d.path().join("real"); drop(open(&real)); let alias = d.path().join("alias"); symlink(&real, &alias).unwrap(); assert!(NativeModelStorage::open(&alias, &Cancellation::new()).is_err()); let s = open(&real); let p = pack("1"); let outside = d.path().join("outside"); fs::create_dir(&outside).unwrap(); symlink(&outside, real.join("packs").join(&p.identity().manifest_sha256)).unwrap(); assert!(s.install(&p, 0, &Cancellation::new()).is_err()); assert!(fs::read_dir(outside).unwrap().next().is_none()); }
#[cfg(unix)] #[test] fn symlinked_inventory_does_not_read_or_replace_external_file() { use std::os::unix::fs::symlink; let d = tempdir(); let path = d.path().join("models"); drop(open(&path)); let outside = d.path().join("external.json"); fs::write(&outside, b"preserve").unwrap(); symlink(&outside, path.join("inventory.json")).unwrap(); assert!(NativeModelStorage::open(&path, &Cancellation::new()).unwrap().into_store(&Cancellation::new()).is_err()); assert_eq!(fs::read(outside).unwrap(), b"preserve"); }
