//! Native export integration tests. Requires actual FFmpeg/ffprobe; no skips
//! or synthetic success markers substitute for invoking the Rust adapter.
use automexia_video::*;
use automexia_video::progress::Stage;
use automexia_video::native::{NativeMediaHost,NativeSettings};
use std::{fs,path::{Path,PathBuf},process::Command};
use tempfile::TempDir;
fn tool(name:&str)->PathBuf{std::env::var_os(name).map(PathBuf::from).unwrap_or_else(||PathBuf::from(if name=="FFMPEG"{"/usr/bin/ffmpeg"}else{"/usr/bin/ffprobe"}))}
fn setup(audio:bool)->(TempDir,VideoExtension<NativeMediaHost>,Project,PathBuf){
 let d=TempDir::new().unwrap();let dir=d.path().canonicalize().unwrap();let input=dir.join("source α & %.mp4");
 let mut c=Command::new(tool("FFMPEG"));c.args(["-v","error","-nostdin","-y","-f","lavfi","-i","testsrc2=size=160x96:rate=30:duration=2"]);
 if audio{c.args(["-f","lavfi","-i","sine=frequency=880:sample_rate=48000:duration=2"]);}
 c.args(["-c:v","libx264","-threads","2","-pix_fmt","yuv420p","-colorspace","bt709","-color_trc","bt709","-color_primaries","bt709","-color_range","tv"]);
 if audio{c.args(["-c:a","aac"]);}else{c.arg("-an");}
 assert!(c.arg(&input).status().unwrap().success());
 let x=VideoExtension::new(NativeMediaHost::new(NativeSettings::new(tool("FFMPEG"),tool("FFPROBE"))).unwrap(),VideoSettings::default()).unwrap();
 let path=dir.join("edit.amxv");let p=x.create_project(&NewProjectRequest::new("export-test",input,&path),&Cancellation::new(),&mut |_|{}).unwrap();
 (d,x,p,path)
}
fn req(path:&Path,f:InterchangeFormat)->ExportRequest{ExportRequest::new(path,path.with_file_name(format!("timeline.{}",f.extension())),f,EditRate::new("30".parse().unwrap(),false).unwrap())}
fn clean(dir:&Path){assert!(!fs::read_dir(dir).unwrap().any(|e|e.unwrap().file_name().to_string_lossy().starts_with(".automexia-video-")));}
#[test]fn native_three_formats_publish_and_keep_source(){let(d,x,p,path)=setup(true);let input=p.sources[0].resolve(&path).unwrap();let before=fs::read(&input).unwrap();for f in [InterchangeFormat::Otio,InterchangeFormat::Fcp7Xml,InterchangeFormat::Edl]{let r=req(&path,f);let o=x.export_interchange(&p,&r,&Cancellation::new(),&mut |_|{}).unwrap();assert_eq!(o.status,ExportStatus::Published,"{:?}",o.error);assert!(!fs::read(&r.destination).unwrap().is_empty());assert!(!o.compatibility.application_import_tested);}assert_eq!(fs::read(&input).unwrap(),before);clean(d.path());}
#[test]fn native_existing_output_is_not_overwritten(){let(d,x,p,path)=setup(false);let r=req(&path,InterchangeFormat::Otio);fs::write(&r.destination,b"keep me").unwrap();let o=x.export_interchange(&p,&r,&Cancellation::new(),&mut |_|{}).unwrap();assert_ne!(o.status,ExportStatus::Published);assert_eq!(fs::read(&r.destination).unwrap(),b"keep me");clean(d.path());}
#[test]fn native_reviewed_document_replacement_works(){let(d,x,p,path)=setup(false);let mut r=req(&path,InterchangeFormat::Otio);fs::write(&r.destination,b"old").unwrap();r.output_policy=OutputPolicy::ReplaceReviewed(x.host().inspect_input(&r.destination,&Cancellation::new()).unwrap().stamp);let o=x.export_interchange(&p,&r,&Cancellation::new(),&mut |_|{}).unwrap();assert_eq!(o.status,ExportStatus::Published,"{:?}",o.error);assert!(fs::read(&r.destination).unwrap().len()>3);clean(d.path());}
#[test]fn native_changed_replacement_is_rejected(){let(d,x,p,path)=setup(false);let mut r=req(&path,InterchangeFormat::Otio);fs::write(&r.destination,b"old").unwrap();r.output_policy=OutputPolicy::ReplaceReviewed(x.host().inspect_input(&r.destination,&Cancellation::new()).unwrap().stamp);fs::write(&r.destination,b"changed").unwrap();let o=x.export_interchange(&p,&r,&Cancellation::new(),&mut |_|{}).unwrap();assert_ne!(o.status,ExportStatus::Published);assert_eq!(fs::read(&r.destination).unwrap(),b"changed");clean(d.path());}
#[test]fn native_cancel_before_export_leaves_no_output(){let(d,x,p,path)=setup(false);let r=req(&path,InterchangeFormat::Otio);let cancel=Cancellation::new();cancel.cancel();assert!(x.export_interchange(&p,&r,&cancel,&mut |_|{}).is_err());assert!(!r.destination.exists());clean(d.path());}
#[test]fn native_missing_source_is_not_success(){let(d,x,p,path)=setup(false);fs::remove_file(p.sources[0].resolve(&path).unwrap()).unwrap();let r=req(&path,InterchangeFormat::Otio);let o=x.export_interchange(&p,&r,&Cancellation::new(),&mut |_|{}).unwrap();assert_ne!(o.status,ExportStatus::Published);assert!(!r.destination.exists());clean(d.path());}
#[test]fn native_source_change_is_detected(){let(d,x,p,path)=setup(false);fs::write(p.sources[0].resolve(&path).unwrap(),b"changed").unwrap();let r=req(&path,InterchangeFormat::Otio);let o=x.export_interchange(&p,&r,&Cancellation::new(),&mut |_|{}).unwrap();assert_ne!(o.status,ExportStatus::Published);assert!(!r.destination.exists());clean(d.path());}
#[test]fn native_pending_edits_do_not_bake_or_publish(){let(d,x,mut p,path)=setup(true);let id=p.remove_range("source-1",TimeRange::new("0.5".parse().unwrap(),"1".parse().unwrap()).unwrap(),"review me").unwrap();p.resolve_operation(&id,Disposition::NeedsReview).unwrap();let mut r=req(&path,InterchangeFormat::Otio);let bake=path.with_file_name("bake.mov");r.video=VisualExport::Bake{destination:bake.clone()};let o=x.export_interchange(&p,&r,&Cancellation::new(),&mut |_|{}).unwrap();assert_eq!(o.status,ExportStatus::Blocked);assert!(!bake.exists());assert!(!r.destination.exists());clean(d.path());}
#[test]fn native_explicit_stem_is_linked_not_silently_created(){let(d,x,p,path)=setup(true);let mut r=req(&path,InterchangeFormat::Fcp7Xml);let stem=path.with_file_name("stem.wav");r.audio=AudioExport::BakeStem{destination:stem.clone()};let o=x.export_interchange(&p,&r,&Cancellation::new(),&mut |_|{}).unwrap();assert_eq!(o.status,ExportStatus::Published,"{:?}",o.error);assert_eq!(o.published_media,vec![stem.clone()]);assert!(String::from_utf8(fs::read(&r.destination).unwrap()).unwrap().contains("stem.wav"));clean(d.path());}
#[test]fn native_explicit_visual_bake_is_reported_flattened(){let(d,x,p,path)=setup(true);let mut r=req(&path,InterchangeFormat::Otio);let bake=path.with_file_name("bake.mov");r.video=VisualExport::Bake{destination:bake.clone()};let o=x.export_interchange(&p,&r,&Cancellation::new(),&mut |_|{}).unwrap();assert_eq!(o.status,ExportStatus::Published,"{:?}",o.error);assert_eq!(o.published_media,vec![bake]);assert!(o.compatibility.items.iter().any(|i|i.representation==Representation::Baked));clean(d.path());}
#[test]fn native_bake_can_explicitly_omit_audio(){let(d,x,p,path)=setup(true);let mut r=req(&path,InterchangeFormat::Otio);r.video=VisualExport::Bake{destination:path.with_file_name("bake.mov")};r.audio=AudioExport::Omit;let o=x.export_interchange(&p,&r,&Cancellation::new(),&mut |_|{}).unwrap();assert_eq!(o.status,ExportStatus::Published,"{:?}",o.error);let data:serde_json::Value=serde_json::from_slice(&fs::read(&r.destination).unwrap()).unwrap();assert_eq!(data["tracks"]["children"].as_array().unwrap().len(),1);clean(d.path());}
#[test]fn native_failed_publication_keeps_explicit_stem_receipt(){let(d,x,p,path)=setup(true);let mut r=req(&path,InterchangeFormat::Otio);fs::write(&r.destination,b"occupied").unwrap();let stem=path.with_file_name("stem.wav");r.audio=AudioExport::BakeStem{destination:stem.clone()};let o=x.export_interchange(&p,&r,&Cancellation::new(),&mut |_|{}).unwrap();assert_ne!(o.status,ExportStatus::Published);if stem.exists(){assert!(o.published_media.contains(&stem));}assert_eq!(fs::read(&r.destination).unwrap(),b"occupied");clean(d.path());}
#[test]fn native_no_hidden_report_or_media_copy(){let(d,x,p,path)=setup(false);let r=req(&path,InterchangeFormat::Edl);let before=fs::read_dir(d.path()).unwrap().count();let o=x.export_interchange(&p,&r,&Cancellation::new(),&mut |_|{}).unwrap();assert_eq!(o.status,ExportStatus::Published,"{:?}",o.error);assert_eq!(fs::read_dir(d.path()).unwrap().count(),before+1);clean(d.path());}
#[cfg(unix)]#[test]fn native_source_hardlink_as_export_is_protected(){let(d,x,p,path)=setup(false);let mut r=req(&path,InterchangeFormat::Otio);let input=p.sources[0].resolve(&path).unwrap();let bytes=fs::read(&input).unwrap();fs::hard_link(&input,&r.destination).unwrap();r.output_policy=OutputPolicy::ReplaceReviewed(x.host().inspect_input(&r.destination,&Cancellation::new()).unwrap().stamp);let o=x.export_interchange(&p,&r,&Cancellation::new(),&mut |_|{}).unwrap();assert_ne!(o.status,ExportStatus::Published);assert_eq!(fs::read(&input).unwrap(),bytes);clean(d.path());}
#[test]fn native_markers_survive_cuts_in_xml(){let(d,x,mut p,path)=setup(false);p.remove_range("source-1",TimeRange::new("0.5".parse().unwrap(),"1".parse().unwrap()).unwrap(),"cut").unwrap();let mut r=req(&path,InterchangeFormat::Fcp7Xml);r.markers.push(ExportMarker{id:"note".into(),name:"A & B".into(),comment:"after cut".into(),at:"1.5".parse().unwrap(),duration:"0".parse().unwrap()});let o=x.export_interchange(&p,&r,&Cancellation::new(),&mut |_|{}).unwrap();assert_eq!(o.status,ExportStatus::Published,"{:?}",o.error);let bytes=fs::read(&r.destination).unwrap();let xml=roxmltree::Document::parse(std::str::from_utf8(&bytes).unwrap()).unwrap();let marker=xml.descendants().find(|n|n.has_tag_name("marker")).unwrap();assert_eq!(marker.children().find(|n|n.has_tag_name("in")).unwrap().text(),Some("30"));clean(d.path());}
#[test]fn native_export_does_not_mutate_unsaved_project(){let(d,x,p,path)=setup(false);let before=p.to_json().unwrap();let r=req(&path,InterchangeFormat::Otio);x.export_interchange(&p,&r,&Cancellation::new(),&mut |_|{}).unwrap();assert_eq!(p.to_json().unwrap(),before);assert!(!path.exists());clean(d.path());}
#[test]fn native_source_changed_at_publication_is_rejected(){let(d,x,p,path)=setup(false);let r=req(&path,InterchangeFormat::Otio);let input=p.sources[0].resolve(&path).unwrap();let o=x.export_interchange(&p,&r,&Cancellation::new(),&mut |event|{if event.stage==Stage::Publishing{fs::write(&input,b"changed at commit").unwrap();}}).unwrap();assert_ne!(o.status,ExportStatus::Published);assert!(!r.destination.exists());clean(d.path());}

fn assembly_range(a:&str,b:&str)->TimeRange{TimeRange::new(a.parse().unwrap(),b.parse().unwrap()).unwrap()}
fn apply_test_assembly(p:&mut Project,speed:PlaybackSpeed){
    p.set_assembly("main",Some(AssemblySettings{clips:vec![
        AssemblyClip{id:"last".into(),range:assembly_range("1","2"),speed},
        AssemblyClip{id:"first".into(),range:assembly_range("0","1"),speed:PlaybackSpeed::Normal},
        AssemblyClip{id:"repeat".into(),range:assembly_range("1","2"),speed:PlaybackSpeed::Normal},
    ],..Default::default()})).unwrap();p.review_assembly("main",Disposition::AutoApply,true).unwrap();
}
#[test]
fn native_normal_speed_assembly_exports_all_three_editable_formats(){
    let(d,x,mut p,path)=setup(true);apply_test_assembly(&mut p,PlaybackSpeed::Normal);let original=p.to_json().unwrap();
    for format in [InterchangeFormat::Otio,InterchangeFormat::Fcp7Xml,InterchangeFormat::Edl]{
        let request=req(&path,format);let result=x.export_interchange(&p,&request,&Cancellation::new(),&mut |_|{}).unwrap();
        assert_eq!(result.status,ExportStatus::Published,"{:?}",result.error);assert!(result.published_media.is_empty());
        assert!(result.compatibility.items.iter().any(|item|item.id=="assembly"&&!item.blocking));
        if format==InterchangeFormat::Otio{let value:serde_json::Value=serde_json::from_slice(&fs::read(&request.destination).unwrap()).unwrap();assert_eq!(value["tracks"]["children"][1]["children"].as_array().unwrap().len(),3);}
    }assert_eq!(p.to_json().unwrap(),original);clean(d.path());
}
#[test]
fn native_assembly_speed_blocks_before_optional_stem_or_runtime(){
    let(d,x,mut p,path)=setup(true);apply_test_assembly(&mut p,PlaybackSpeed::Half);let mut request=req(&path,InterchangeFormat::Otio);
    let stem=path.with_file_name("assembly-stem.wav");request.audio=AudioExport::BakeStem{destination:stem.clone()};let mut events=0;
    let result=x.export_interchange(&p,&request,&Cancellation::new(),&mut |_|{events+=1;}).unwrap();
    assert_eq!(result.status,ExportStatus::Blocked);assert_eq!(events,0);assert!(result.published_media.is_empty());assert!(!stem.exists());assert!(!request.destination.exists());clean(d.path());
}
#[test]
fn native_assembly_mixed_speed_explicit_bake_has_measured_flattened_duration(){
    let(d,x,mut p,path)=setup(true);apply_test_assembly(&mut p,PlaybackSpeed::Half);let mut request=req(&path,InterchangeFormat::Otio);
    let bake=path.with_file_name("assembly-bake.mov");request.video=VisualExport::Bake{destination:bake.clone()};
    let result=x.export_interchange(&p,&request,&Cancellation::new(),&mut |_|{}).unwrap();assert_eq!(result.status,ExportStatus::Published,"{:?}",result.error);
    assert_eq!(result.published_media,vec![bake]);let value:serde_json::Value=serde_json::from_slice(&fs::read(&request.destination).unwrap()).unwrap();
    let clips=&value["tracks"]["children"][1]["children"];assert_eq!(clips.as_array().unwrap().len(),1);assert_eq!(clips[0]["source_range"]["duration"]["value"],120);clean(d.path());
}
#[test]
fn native_repeated_assembly_timecode_overflow_blocks_before_visual_bake(){
    let(d,x,mut p,path)=setup(true);apply_test_assembly(&mut p,PlaybackSpeed::Normal);let mut request=req(&path,InterchangeFormat::Otio);
    request.record_start_frames=request.rate.frames_per_day()-30;let bake=path.with_file_name("overflow-bake.mov");request.video=VisualExport::Bake{destination:bake.clone()};
    let mut events=0;let result=x.export_interchange(&p,&request,&Cancellation::new(),&mut |_|{events+=1;}).unwrap();
    assert_eq!(result.status,ExportStatus::Blocked);assert_eq!(events,0);assert!(result.published_media.is_empty());assert!(!bake.exists());assert!(!request.destination.exists());clean(d.path());
}
