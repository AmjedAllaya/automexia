"""Regression tests for source delivery, not application/media behavior."""
import contextlib
import fnmatch
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import stat
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch
import warnings
import zipfile

TOOL = Path(__file__).resolve().parents[2] / 'tools' / 'package_delivery.py'
spec = importlib.util.spec_from_file_location('delivery', TOOL)
d = importlib.util.module_from_spec(spec)
spec.loader.exec_module(d)

class DeliveryTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.base = Path(self.temp.name)
        self.source = self.base / 'source'
        self.output = self.base / 'out'
        self.source.mkdir()
        self.policy = {'format_version':1, 'package_name':'automexia-video',
            'package_version':'0.8.0','milestone':8, 'delivery_label':'delivery-repair',
            'artifact_scope':'source-integrity-only',
            'required_files':['Cargo.toml','README.md','src/lib.rs','docs/STEP-8.md']}
        self.write('Cargo.toml', '[package]\nname="automexia-video"\nversion="0.8.0"\nedition="2021"\n')
        self.write('README.md', '# Synthetic packaging fixture, not a Video build\n')
        self.write('src/lib.rs', 'pub fn test_fixture() {}\n')
        self.write('docs/STEP-8.md', '# Step 8 packaging fixture\n')
        self.save_policy()

    def write(self, name, data):
        p=self.source/name; p.parent.mkdir(parents=True,exist_ok=True)
        p.write_bytes(data.encode() if isinstance(data,str) else data)
        return p

    def save_policy(self):
        self.write(d.POLICY_NAME,json.dumps(self.policy,indent=2)+'\n')

    def build(self):
        return d.build(self.source,self.output,8,'0.8.0')

    def record(self, receipt):
        return json.loads(receipt.read_text())

    def archive(self, receipt):
        return receipt.parent/self.record(receipt)['archive']

    def assert_no_artifact(self):
        if self.output.exists():
            self.assertEqual(list(self.output.iterdir()),[])

    def assert_build_refused(self):
        with self.assertRaises((d.DeliveryError,OSError)):
            self.build()
        self.assert_no_artifact()

    def rewrite_archive(self, path, transform):
        with zipfile.ZipFile(path) as z:
            items=[(i.filename,z.read(i.filename)) for i in z.infolist()]
        with zipfile.ZipFile(path,'w',compression=zipfile.ZIP_DEFLATED) as z:
            for name,data in transform(items): z.writestr(name,data)

    def raw_zip(self, names, special_mode=None, compression=zipfile.ZIP_DEFLATED):
        p=self.base/'bad.zip'
        with warnings.catch_warnings():
            warnings.simplefilter('ignore',UserWarning)
            with zipfile.ZipFile(p,'w',compression=compression) as z:
                for name,data in names:
                    if special_mode:
                        i=zipfile.ZipInfo(name); i.create_system=3; i.external_attr=special_mode<<16
                        z.writestr(i,data)
                    else: z.writestr(name,data)
        return p

    def test_build_roundtrip_identity_and_checksum(self):
        r=self.build(); record=d.verify(r,8,'0.8.0')
        info=record['archive_info']
        self.assertEqual(info['milestone'],8)
        self.assertEqual(info['file_count'],6)
        self.assertEqual(info['manifest_entries'],5)
        self.assertEqual(info['sha256'],hashlib.sha256(self.archive(r).read_bytes()).hexdigest())

    def test_exact_clean_extraction(self):
        r=self.build(); target=self.base/'extract'
        d.inspect_archive(self.archive(r),8,'0.8.0',target)
        for name,data in d.snapshot(self.source).items():
            self.assertEqual((target/'automexia-video'/name).read_bytes(),data)

    def test_zip_bytes_are_reproducible(self):
        r=self.build(); a=self.archive(r).read_bytes()
        other=d.build(self.source,self.base/'out2',8,'0.8.0')
        self.assertEqual(a,self.archive(other).read_bytes())

    def test_unchanged_build_reuses_verified_artifacts(self):
        r=self.build(); before={p.name:p.read_bytes() for p in self.output.iterdir()}
        self.assertEqual(r,self.build())
        self.assertEqual(before,{p.name:p.read_bytes() for p in self.output.iterdir()})

    def test_changed_source_creates_new_immutable_archive(self):
        r=self.build(); old=self.archive(r).read_bytes()
        self.write('src/lib.rs','pub fn another_fixture() {}\n')
        newer=self.build()
        self.assertNotEqual(r,newer)
        self.assertEqual(old,self.archive(r).read_bytes())
        d.verify(r,8,'0.8.0'); d.verify(newer,8,'0.8.0')

    def test_missing_source_no_success_output(self):
        stdout=io.StringIO(); stderr=io.StringIO()
        with contextlib.redirect_stdout(stdout),contextlib.redirect_stderr(stderr):
            code=d.main(['build','--source',str(self.base/'missing'), '--output-dir',str(self.output),
                         '--expected-step','9','--expected-version','0.9.0'])
        self.assertEqual(code,1); self.assertEqual(stdout.getvalue(),'')
        self.assertIn('DELIVERY FAILED',stderr.getvalue()); self.assert_no_artifact()

    def test_previous_date_glob_false_positive_is_rejected(self):
        self.assertTrue(fnmatch.fnmatch('automexia-video-step-8-rebuilt-2026-09-10.zip','*step*9*'))
        with self.assertRaises(d.DeliveryError):
            d.build(self.source,self.output,9,'0.9.0')
        self.assert_no_artifact()

    def test_actual_cargo_version_must_match_not_only_policy(self):
        self.policy.update(package_version='0.9.0',milestone=9)
        self.policy['required_files'][-1]='docs/STEP-9.md'; self.write('docs/STEP-9.md','# fixture')
        self.save_policy()
        with self.assertRaises(d.DeliveryError):d.build(self.source,self.output,9,'0.9.0')
        self.assert_no_artifact()

    def test_package_name_mismatch(self):
        self.write('Cargo.toml','[package]\nname="wrong"\nversion="0.8.0"')
        self.assert_build_refused()

    def test_required_source_missing(self):
        (self.source/'src/lib.rs').unlink(); self.assert_build_refused()

    def test_required_guide_missing(self):
        (self.source/'docs/STEP-8.md').unlink(); self.assert_build_refused()

    def test_required_guide_empty(self):
        self.write('docs/STEP-8.md',' \n'); self.assert_build_refused()

    def test_invalid_cargo(self):
        self.write('Cargo.toml','[package'); self.assert_build_refused()

    def test_missing_policy(self):
        (self.source/d.POLICY_NAME).unlink(); self.assert_build_refused()

    def test_duplicate_json_keys(self):
        self.write(d.POLICY_NAME,'{"milestone":8,"milestone":9}'); self.assert_build_refused()

    def test_policy_cannot_omit_milestone_guide_requirement(self):
        self.policy['required_files'].pop(); self.save_policy(); self.assert_build_refused()

    def test_unknown_policy_fields(self):
        self.policy['skip_verification']=True; self.save_policy(); self.assert_build_refused()

    def test_boolean_milestone_rejected(self):
        self.policy['milestone']=True; self.save_policy(); self.assert_build_refused()

    def test_wrong_expected_version(self):
        with self.assertRaises(d.DeliveryError):d.build(self.source,self.output,8,'0.9.0')
        self.assert_no_artifact()

    def test_output_inside_source_is_rejected(self):
        with self.assertRaises(d.DeliveryError):d.build(self.source,self.source/'release',8,'0.8.0')
        self.assertFalse((self.source/'release').exists())

    def test_source_symlink_rejected(self):
        link=self.base/'link'; link.symlink_to(self.source,target_is_directory=True)
        with self.assertRaises(d.DeliveryError):d.build(link,self.output,8,'0.8.0')
        self.assert_no_artifact()

    def test_symlink_file_rejected(self):
        (self.source/'link.rs').symlink_to(self.source/'src/lib.rs'); self.assert_build_refused()

    def test_symlink_directory_rejected(self):
        (self.source/'linkdir').symlink_to(self.source/'src',target_is_directory=True)
        self.assert_build_refused()

    def test_font_files_are_rejected(self):
        for ext in ('.ttf','.otf','.woff','.woff2','.ttc'):
            with self.subTest(ext=ext):
                p=self.write('assets/font'+ext,b'not-a-font'); self.assert_build_refused(); p.unlink()

    def test_case_colliding_paths_rejected(self):
        self.write('readme.md','other'); self.assert_build_refused()

    def test_windows_invalid_names_rejected(self):
        for name in ('CON.txt','assets/NUL','a:b','a\\b','foo.','foo ','a\nline'):
            with self.subTest(name=name):
                p=self.write(name,'x'); self.assert_build_refused(); p.unlink()

    def test_build_outputs_are_excluded(self):
        self.write('target/a.o','output'); self.write('.git/config','config')
        self.write('__pycache__/x.pyc','cache'); self.write('tools/x.pyc','cache')
        r=self.build()
        with zipfile.ZipFile(self.archive(r)) as z:
            self.assertFalse(any('/target/' in n or '/.git/' in n or n.endswith('.pyc') for n in z.namelist()))

    def test_source_changes_between_scans(self):
        real=d.snapshot; calls=0
        def changing(path):
            nonlocal calls
            calls+=1
            if calls==2:self.write('README.md','changed')
            return real(path)
        with patch.object(d,'snapshot',side_effect=changing): self.assert_build_refused()

    def test_source_changes_during_archive_creation(self):
        real=d.write_zip
        def change(*args):
            real(*args); self.write('README.md','changed during compression')
        with patch.object(d,'write_zip',side_effect=change):self.assert_build_refused()

    def test_disk_failure_cleans_partial_artifacts(self):
        def fail(path,*_):
            path.write_bytes(b'partial'); raise OSError('simulated disk full')
        with patch.object(d,'write_zip',side_effect=fail):self.assert_build_refused()

    def test_final_recheck_failure_rolls_back_owned_files(self):
        real=d.inspect_archive
        def fail_final(path,*args,**kw):
            if path.suffix=='.zip':raise d.DeliveryError('simulated final verification failure')
            return real(path,*args,**kw)
        with patch.object(d,'inspect_archive',side_effect=fail_final):self.assert_build_refused()

    def test_conflicting_existing_artifact_is_not_overwritten(self):
        r=self.build(); a=self.archive(r); a.write_bytes(b'conflict')
        with self.assertRaises(d.DeliveryError):self.build()
        self.assertEqual(a.read_bytes(),b'conflict')

    def test_truncated_archive_has_no_links(self):
        r=self.build(); a=self.archive(r); a.write_bytes(a.read_bytes()[:-40])
        with self.assertRaises(d.DeliveryError):d.links(r,8,'0.8.0',self.base)

    def test_crc_corruption_detected(self):
        p=self.raw_zip([('automexia-video/a',b'abcdef'),('automexia-video/b',b'other')],compression=zipfile.ZIP_STORED)
        data=p.read_bytes(); self.assertIn(b'abcdef',data)
        p.write_bytes(data.replace(b'abcdef',b'abcXef',1))
        with self.assertRaises(d.DeliveryError):d.inspect_archive(p,8,'0.8.0')

    def test_tampered_payload_crc_valid_still_fails(self):
        r=self.build(); a=self.archive(r)
        self.rewrite_archive(a,lambda items:[(n,b'changed' if n.endswith('src/lib.rs') else data) for n,data in items])
        with self.assertRaises(d.DeliveryError):d.inspect_archive(a,8,'0.8.0')

    def test_extra_unlisted_member_fails(self):
        r=self.build(); a=self.archive(r)
        self.rewrite_archive(a,lambda items:items+[('automexia-video/extra.rs',b'extra')])
        with self.assertRaises(d.DeliveryError):d.inspect_archive(a,8,'0.8.0')

    def test_removed_listed_member_fails(self):
        r=self.build(); a=self.archive(r)
        self.rewrite_archive(a,lambda items:[(n,data) for n,data in items if not n.endswith('README.md')])
        with self.assertRaises(d.DeliveryError):d.inspect_archive(a,8,'0.8.0')

    def test_unsafe_archive_names_fail_before_extraction(self):
        for name in ('../escape','/absolute','automexia-video/../../escape','C:/drive','automexia-video/CON'):
            with self.subTest(name=name):
                p=self.raw_zip([(name,b'x'),('automexia-video/ok',b'y')])
                with self.assertRaises(d.DeliveryError):d.inspect_archive(p,8,'0.8.0',self.base/'newdir')
                self.assertFalse((self.base/'newdir').exists())

    def test_duplicate_archive_members_rejected(self):
        p=self.raw_zip([('automexia-video/a',b'1'),('automexia-video/a',b'2')])
        with self.assertRaises(d.DeliveryError):d.inspect_archive(p,8,'0.8.0')

    def test_archive_symlinks_rejected(self):
        p=self.raw_zip([('automexia-video/a',b'target'),('automexia-video/b',b'target')],stat.S_IFLNK|0o777)
        with self.assertRaises(d.DeliveryError):d.inspect_archive(p,8,'0.8.0')

    def test_alternative_zip_compression_rejected(self):
        p=self.raw_zip([('automexia-video/a',b'x'),('automexia-video/b',b'x')],compression=zipfile.ZIP_LZMA)
        with self.assertRaises(d.DeliveryError):d.inspect_archive(p,8,'0.8.0')

    def test_resource_bound_is_enforced(self):
        with patch.object(d,'MAX_TOTAL_BYTES',20):self.assert_build_refused()

    def test_missing_checksum_sidecar_fails(self):
        r=self.build(); (r.parent/self.record(r)['checksum_file']).unlink()
        with self.assertRaises(OSError):d.verify(r,8,'0.8.0')

    def test_missing_final_archive_fails(self):
        r=self.build(); self.archive(r).unlink()
        with self.assertRaises(OSError):d.verify(r,8,'0.8.0')

    def test_stale_receipt_hash_fails(self):
        r=self.build(); rec=self.record(r); rec['archive_info']['sha256']='0'*64
        r.write_text(json.dumps(rec))
        with self.assertRaises(d.DeliveryError):d.verify(r,8,'0.8.0')

    def test_receipt_path_traversal_fails(self):
        r=self.build(); rec=self.record(r); rec['archive']='../file.zip'
        r.write_text(json.dumps(rec))
        with self.assertRaises(d.DeliveryError):d.verify(r,8,'0.8.0')

    def test_links_only_for_verified_actual_files(self):
        r=self.build(); result=d.links(r,8,'0.8.0',self.base)
        self.assertEqual(result.count('](sandbox:'),3)
        self.assertIn(self.archive(r).name,result)
        self.assertNotIn('step-9',result)

    def test_links_outside_sandbox_refused(self):
        r=self.build(); outside=self.base/'empty-root'; outside.mkdir()
        with self.assertRaises(d.DeliveryError):d.links(r,8,'0.8.0',outside)

    def test_missing_receipt_returns_nonzero_and_no_links(self):
        stdout=io.StringIO(); stderr=io.StringIO()
        with contextlib.redirect_stdout(stdout),contextlib.redirect_stderr(stderr):
            code=d.main(['links','--receipt',str(self.base/'missing.json'),
                         '--expected-step','9','--expected-version','0.9.0'])
        self.assertEqual(code,1); self.assertEqual(stdout.getvalue(),'')

    def test_python_optimized_mode_does_not_remove_checks(self):
        result=subprocess.run([sys.executable,'-O',str(TOOL),'build','--source',str(self.source),
            '--output-dir',str(self.output),'--expected-step','9','--expected-version','0.9.0'],
            capture_output=True,text=True,timeout=15)
        self.assertEqual(result.returncode,1); self.assertEqual(result.stdout,''); self.assert_no_artifact()

    def test_empty_zip_is_rejected(self):
        p=self.raw_zip([])
        with self.assertRaises(d.DeliveryError):d.inspect_archive(p,8,'0.8.0')

    def test_directory_case_collision_rejected(self):
        self.write('Assets/one.json','one'); self.write('assets/two.json','two')
        self.assert_build_refused()

    def test_file_directory_case_collision_rejected(self):
        self.write('Media','file'); self.write('media/clip.json','metadata')
        self.assert_build_refused()

    def test_unreadable_subtree_cannot_be_silently_omitted(self):
        self.write('docs/private/sub/file.json','data')
        real=d.os.scandir
        def blocked(path):
            if str(path)==str(self.source/'docs/private'):
                raise PermissionError('simulated unreadable subtree')
            return real(path)
        with patch.object(d.os,'scandir',side_effect=blocked):
            self.assert_build_refused()

    def test_receipt_cannot_upgrade_integrity_to_application_tests(self):
        r=self.build(); record=self.record(r); record['application_tests']='passed'
        r.write_text(json.dumps(record))
        with self.assertRaises(d.DeliveryError):d.verify(r,8,'0.8.0')

    def test_receipt_cannot_claim_browser_download_test(self):
        r=self.build(); record=self.record(r); record['browser_download_test']='passed'
        r.write_text(json.dumps(record))
        with self.assertRaises(d.DeliveryError):d.verify(r,8,'0.8.0')

    def test_checksum_tampering_rejected(self):
        r=self.build(); c=r.parent/self.record(r)['checksum_file']; c.write_text('wrong')
        with self.assertRaises(d.DeliveryError):d.verify(r,8,'0.8.0')

    def test_existing_extraction_is_not_overwritten(self):
        r=self.build(); target=self.base/'extract'; target.mkdir(); (target/'keep').write_text('keep')
        with self.assertRaises(d.DeliveryError):d.inspect_archive(self.archive(r),8,'0.8.0',target)
        self.assertEqual((target/'keep').read_text(),'keep')

    def test_candidate_identity_must_agree_with_source(self):
        self.write('release-candidate.json',json.dumps({'package_version':'0.7.0','step':8}))
        with self.assertRaises(d.DeliveryError):self.build()
    def test_candidate_milestone_must_agree(self):
        self.write('release-candidate.json',json.dumps({'package_version':'0.8.0','step':7}))
        with self.assertRaises(d.DeliveryError):self.build()
    def test_matching_candidate_is_accepted(self):
        self.write('release-candidate.json',json.dumps({'package_version':'0.8.0','step':8}))
        self.build()

    def test_temporary_root_copy_cannot_enter_delivery(self):
        self.write('tmpabcdef/video/src/lib.rs','unexpected nested checkout')
        self.assert_build_refused()

    def test_unreviewed_root_file_cannot_enter_delivery(self):
        self.write('debug-output.log','temporary diagnostic')
        self.assert_build_refused()

class JsonNumberTests(unittest.TestCase):
    def test_overflowed_float_cannot_hide_in_receipt(self):
        for value in ('1e999','-1e999','NaN','Infinity','-Infinity'):
            with self.subTest(value=value),self.assertRaises(d.DeliveryError):
                d.json_load(('{"details":'+value+'}').encode())

if __name__=='__main__':unittest.main()
