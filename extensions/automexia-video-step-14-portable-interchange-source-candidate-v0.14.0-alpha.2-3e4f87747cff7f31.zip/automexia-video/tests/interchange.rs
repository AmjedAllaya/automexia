//! Executable core tests: no FFmpeg, filesystem publication or editor required.
use automexia_video::*;
use automexia_video::interchange::*;
use automexia_video::host::*;
use automexia_video::project::*;
use std::path::PathBuf;
fn r(s:&str)->Rational{s.parse().unwrap()}
fn rate()->EditRate{EditRate::new(r("30000/1001"),false).unwrap()}
fn loc()->PathBuf{std::env::temp_dir().join("amx-export-tests").join("project.amxv")}
fn file()->InputFile{InputFile{canonical_path:loc().with_file_name("input & α.mov"),stamp:FileStamp{size:100,modified_ns:None,sha256:"a".repeat(64),file_id:None}}}
fn info()->MediaInfo{let mut v:serde_json::Value=serde_json::from_slice(include_bytes!("fixtures/probe-base.json")).unwrap();v["streams"][1]["duration_ts"]=serde_json::json!(96096);v["streams"][1]["duration"]=serde_json::json!("2.002000");automexia_video::media::parse_probe(&serde_json::to_vec(&v).unwrap()).unwrap()}
fn project()->Project{let m=info();let source=ProjectSource::from_probe("source-1",&file(),&m,m.select(StreamSelection::default()).unwrap(),&loc()).unwrap();Project::new("edit-1",source,ResolvedSettings{workflow:None,voice_cleanup:None,voice_enhancement:None,color_correction:None,pause_cleanup:None,preset_name:None,preset_revision:None,render:FrozenRenderSettings::from_options(&RenderOptions::default()).unwrap()}).unwrap()}
fn request(f:InterchangeFormat)->ExportRequest{ExportRequest::new(loc(),loc().with_file_name(format!("timeline.{}",f.extension())),f,rate())}
fn evidence(input:InputFile)->CfrEvidence{let c=Cancellation::new();let mut v=CfrVerifier::new(input,0,rate(),r("0"),r("2.002"),r("1/30000")).unwrap();for n in 0..60{v.feed(format!("pts={}\n",n*1001).as_bytes(),&c).unwrap();}v.finish(&c).unwrap()}
fn media()->ExportMedia{ExportMedia{input:file(),info:info(),timing:Some(evidence(file())),baked_video:None,baked_audio:None}}
fn doc(f:InterchangeFormat)->ExportDocument{build_export(&project(),&request(f),&media()).unwrap()}
fn cut_project()->Project{let mut p=project();p.set_keep_ranges("source-1",&[TimeRange::new(r("0"),rate().seconds(10).unwrap()).unwrap(),TimeRange::new(rate().seconds(20).unwrap(),rate().seconds(60).unwrap()).unwrap()]).unwrap();p}
#[test]fn exact_2997_uses_rational_rate(){assert_eq!(rate().exact_frames(r("1001/1000")).unwrap(),30);}
#[test]fn half_frame_is_not_silently_rounded(){assert!(rate().exact_frames(r("1001/60000")).is_err());}
#[test]fn valid_rates_are_deliberate(){for s in ["24","25","30","48","50","60","24000/1001","30000/1001","60000/1001"]{EditRate::new(r(s),false).unwrap();}}
#[test]fn nonstandard_rates_fail(){for s in ["0","-25","120","2997/100","1/2"]{assert!(EditRate::new(r(s),false).is_err());}}
#[test]fn df_restricted_to_legal_rate_pairs(){for s in ["24","25","30","24000/1001"]{assert!(EditRate::new(r(s),true).is_err());}}
#[test]fn df_minute_boundary(){let d=EditRate::new(r("30000/1001"),true).unwrap();assert_eq!(d.timecode(1800).unwrap(),"00:01:00;02");assert_eq!(d.timecode(17982).unwrap(),"00:10:00;00");}
#[test]fn df_hour_boundary(){let d=EditRate::new(r("30000/1001"),true).unwrap();assert_eq!(d.timecode(107892).unwrap(),"01:00:00;00");}
#[test]fn df_5994_boundary(){let d=EditRate::new(r("60000/1001"),true).unwrap();assert_eq!(d.timecode(3600).unwrap(),"00:01:00;04");assert_eq!(d.timecode(35964).unwrap(),"00:10:00;00");}
#[test]fn drop_frame_skipped_labels_are_invalid(){let d=EditRate::new(r("30000/1001"),true).unwrap();for s in ["00:01:00;00","00:01:00;01"]{assert!(d.parse_timecode(s).is_err());}}
#[test]fn timecode_roundtrip_sampled_full_day(){for rate in [rate(),EditRate::new(r("30000/1001"),true).unwrap(),EditRate::new(r("60000/1001"),true).unwrap()]{for n in (0..rate.frames_per_day()).step_by(997){assert_eq!(rate.parse_timecode(&rate.timecode(n).unwrap()).unwrap(),n);}}}
#[test]fn timecode_never_wraps_a_day(){assert!(rate().timecode(rate().frames_per_day()).is_err());assert!(rate().timecode(-1).is_err());}
#[test]fn timecode_invalid_fields(){for s in ["24:00:00:00","00:60:00:00","00:00:60:00","00:00:00:30","00:00:00;01","aa:00:00:00","00:00:00"]{assert!(rate().parse_timecode(s).is_err());}}
#[test]fn source_pts_origin_is_not_timecode(){let c=Cancellation::new();let mut v=CfrVerifier::new(file(),0,rate(),r("3600"),r("2.002"),r("1/30000")).unwrap();for n in 0..60{v.feed(format!("pts={}\n",108000000+n*1001).as_bytes(),&c).unwrap();}assert_eq!(v.finish(&c).unwrap().frames(),60);}
#[test]fn cfr_data_can_arrive_one_byte_at_a_time(){let c=Cancellation::new();let mut v=CfrVerifier::new(file(),0,rate(),r("0"),r("2.002"),r("1/30000")).unwrap();for n in 0..60{for b in format!("pts={}\n",n*1001).bytes(){v.feed(&[b],&c).unwrap();}}v.finish(&c).unwrap();}
#[test]fn cfr_rejects_missing_final_newline(){let c=Cancellation::new();let mut v=CfrVerifier::new(file(),0,rate(),r("0"),r("2.002"),r("1/30000")).unwrap();v.feed(b"pts=0",&c).unwrap();assert!(v.finish(&c).is_err());}
#[test]fn cfr_rejects_truncated_successful_stream(){let c=Cancellation::new();let mut v=CfrVerifier::new(file(),0,rate(),r("0"),r("2.002"),r("1/30000")).unwrap();v.feed(b"pts=0\n",&c).unwrap();assert!(v.finish(&c).is_err());}
#[test]fn cfr_rejects_vfr(){let c=Cancellation::new();let mut v=CfrVerifier::new(file(),0,rate(),r("0"),r("2.002"),r("1/30000")).unwrap();v.feed(b"pts=0\n",&c).unwrap();assert!(v.feed(b"pts=2002\n",&c).is_err());}
#[test]fn cfr_failure_is_sticky(){let c=Cancellation::new();let mut v=CfrVerifier::new(file(),0,rate(),r("0"),r("2.002"),r("1/30000")).unwrap();assert!(v.feed(b"pts=N/A\n",&c).is_err());assert!(v.feed(b"pts=0\n",&c).is_err());}
#[test]fn cfr_rejects_duplicate_pts(){let c=Cancellation::new();let mut v=CfrVerifier::new(file(),0,rate(),r("0"),r("2.002"),r("1/30000")).unwrap();assert!(v.feed(b"pts=0\npts=0\n",&c).is_err());}
#[test]fn cfr_cancellation_is_honored(){let c=Cancellation::new();let mut v=CfrVerifier::new(file(),0,rate(),r("0"),r("2.002"),r("1/30000")).unwrap();c.cancel();assert_eq!(v.feed(b"pts=0\n",&c),Err(Error::Cancelled));}
#[test]fn cfr_wrong_file_evidence_fails(){let mut f=file();f.stamp.sha256="b".repeat(64);assert!(evidence(file()).validate_for(&f,0,rate(),r("0"),r("2.002")).is_err());}
#[test]fn cfr_wrong_stream_evidence_fails(){assert!(evidence(file()).validate_for(&file(),1,rate(),r("0"),r("2.002")).is_err());}
#[test]fn cfr_line_is_bounded(){let c=Cancellation::new();let mut v=CfrVerifier::new(file(),0,rate(),r("0"),r("2.002"),r("1/30000")).unwrap();assert!(v.feed(&vec![b'1';257],&c).is_err());}
#[test]fn request_json_roundtrip(){let a=request(InterchangeFormat::Otio);ExportRequest::from_json(&serde_json::to_vec(&a).unwrap()).unwrap();}
#[test]fn request_unknown_field_rejected(){let mut a=serde_json::to_value(request(InterchangeFormat::Otio)).unwrap();a["shell"]="x".into();assert!(ExportRequest::from_json(&serde_json::to_vec(&a).unwrap()).is_err());}
#[test]fn request_duplicate_key_rejected(){assert!(ExportRequest::from_json(b"{\"name\":\"a\",\"name\":\"b\"}").is_err());}
#[test]fn wrong_destination_suffix_fails(){let mut a=request(InterchangeFormat::Otio);a.destination.set_extension("xml");assert!(a.validate().is_err());}
#[test]fn no_relative_write_paths(){let mut a=request(InterchangeFormat::Otio);a.destination="x.otio".into();assert!(a.validate().is_err());}
#[test]fn no_parent_components_in_write_paths(){let mut a=request(InterchangeFormat::Otio);a.destination=loc().parent().unwrap().join("../x.otio");assert!(a.validate().is_err());}
#[test]fn conflicting_bake_destination_fails(){let mut a=request(InterchangeFormat::Fcp7Xml);a.video=VisualExport::Bake{destination:a.destination.clone()};assert!(a.validate().is_err());}
#[test]fn fcp7_relative_uri_is_not_advertised(){let mut a=request(InterchangeFormat::Fcp7Xml);a.paths=PathMode::RelativeToExport;assert!(a.validate().is_err());}
#[test]fn uri_escapes_unicode_percent_and_xml(){let u=paths::media_url(&loc().with_file_name("%x & α.mp4"),&loc().with_extension("otio"),PathMode::AbsoluteFileUrl).unwrap();assert!(u.contains("%25x%20%26%20%CE%B1.mp4"));}
#[test]fn relative_uri_rebases_to_export_directory(){let p=loc().parent().unwrap().join("exports").join("x.otio");let u=paths::media_url(&file().canonical_path,&p,PathMode::RelativeToExport).unwrap();assert!(u.starts_with("../input%20"));}
#[test]fn xml_escapes_markup(){assert_eq!(paths::xml("<&\"'>"),"&lt;&amp;&quot;&apos;&gt;");}
#[test]fn otio_is_clip2_and_has_two_tracks(){let d=doc(InterchangeFormat::Otio);let j:serde_json::Value=serde_json::from_slice(d.bytes()).unwrap();assert_eq!(j["OTIO_SCHEMA"],"Timeline.1");assert_eq!(j["tracks"]["children"].as_array().unwrap().len(),2);assert_eq!(j["tracks"]["children"][1]["children"][0]["OTIO_SCHEMA"],"Clip.2");}
#[test]fn no_export_changes_project_bytes(){let p=project();let before=p.to_json().unwrap();for f in [InterchangeFormat::Otio,InterchangeFormat::Fcp7Xml,InterchangeFormat::Edl]{build_export(&p,&request(f),&media()).unwrap();}assert_eq!(before,p.to_json().unwrap());}
#[test]fn reference_export_is_deterministic(){assert_eq!(doc(InterchangeFormat::Otio).bytes(),doc(InterchangeFormat::Otio).bytes());}
#[test]fn all_formats_share_cut_boundaries(){let p=cut_project();for f in [InterchangeFormat::Otio,InterchangeFormat::Fcp7Xml,InterchangeFormat::Edl]{let d=build_export(&p,&request(f),&media()).unwrap();assert_eq!(d.timeline().duration_frames,50);assert_eq!(d.timeline().clips[1].source_in,20);assert_eq!(d.timeline().clips[1].record_in,10);}}
#[test]fn explicit_contiguous_splits_survive_export(){let mut p=project();p.split_clip("clip-1",rate().seconds(10).unwrap()).unwrap();let d=build_export(&p,&request(InterchangeFormat::Otio),&media()).unwrap();assert_eq!(d.timeline().clips.len(),2);assert_eq!(d.timeline().duration_frames,60);}
#[test]fn pending_cut_blocks_before_media(){let mut p=project();let id=p.remove_range("source-1",TimeRange::new(r("0.2"),r("0.5")).unwrap(),"pending").unwrap();p.resolve_operation(&id,Disposition::NeedsReview).unwrap();assert!(assess_export(&p,&request(InterchangeFormat::Otio)).unwrap().blocked());}
#[test]fn nonframe_cut_is_reported_not_rounded(){let mut p=project();p.remove_range("source-1",TimeRange::new(r("0.2"),r("0.5")).unwrap(),"cut").unwrap();assert!(assess_export(&p,&request(InterchangeFormat::Otio)).unwrap().blocked());}
#[test]fn absent_cfr_evidence_is_not_success(){let mut m=media();m.timing=None;assert!(build_export(&project(),&request(InterchangeFormat::Otio),&m).is_err());}
#[test]fn mismatch_fingerprint_rejects_all_exports(){let mut m=media();m.input.stamp.sha256="c".repeat(64);assert!(build_export(&project(),&request(InterchangeFormat::Otio),&m).is_err());}
#[test]fn unknown_geometry_is_not_an_xml_zero(){let mut p=project();p.sources[0].media.video.width=None;let mut m=media();m.info.streams[0].width=None;assert!(build_export(&p,&request(InterchangeFormat::Fcp7Xml),&m).is_err());}
#[test]fn fcp7_is_legacy_xmeml_and_links_tracks(){let d=doc(InterchangeFormat::Fcp7Xml);let text=std::str::from_utf8(d.bytes()).unwrap();let tree=roxmltree::Document::parse(text).unwrap();assert_eq!(tree.root_element().tag_name().name(),"xmeml");assert_eq!(tree.root_element().attribute("version"),Some("5"));assert!(text.contains("<linkclipref>v1</linkclipref>"));}
#[test]fn fcp7_file_ids_resolve(){let d=doc(InterchangeFormat::Fcp7Xml);let tree=roxmltree::Document::parse(std::str::from_utf8(d.bytes()).unwrap()).unwrap();for n in tree.descendants().filter(|n|n.has_tag_name("file")){let id=n.attribute("id").unwrap();assert!(tree.descendants().any(|x|x.has_tag_name("file")&&x.attribute("id")==Some(id)&&x.children().any(|c|c.has_tag_name("pathurl"))));}}
#[test]fn report_never_fabricates_editor_qualification(){for target in [TargetEditor::Generic,TargetEditor::Resolve,TargetEditor::Premiere]{let mut r=request(InterchangeFormat::Otio);r.target=target;r.intended_editor_version=Some("selected externally".into());assert!(!assess_export(&project(),&r).unwrap().application_import_tested);}}
#[test]fn complete_project_and_request_are_retained_in_report(){let p=project();let r=request(InterchangeFormat::Otio);let report=assess_export(&p,&r).unwrap();assert_eq!(report.source_project,serde_json::to_value(p).unwrap());assert_eq!(report.export_request,serde_json::to_value(r).unwrap());}
#[test]fn edl_is_ascii_and_has_fcm(){let d=doc(InterchangeFormat::Edl);assert!(d.bytes().is_ascii());assert!(std::str::from_utf8(d.bytes()).unwrap().starts_with("TITLE: Automexia edit\nFCM: NON-DROP FRAME"));}
#[test]fn edl_high_rate_rejected_not_mislabeled(){let mut r=request(InterchangeFormat::Edl);r.rate=EditRate::new("60".parse().unwrap(),false).unwrap();assert!(r.validate().is_err());}
#[test]fn edl_nonascii_title_rejected(){let mut r=request(InterchangeFormat::Edl);r.name="α".into();assert!(r.validate().is_err());}
#[test]fn edl_stereo_has_aa_track(){let mut p=project();p.sources[0].media.audio.as_mut().unwrap().channels=Some(2);p.sources[0].media.audio.as_mut().unwrap().channel_layout=Some("stereo".into());let mut m=media();m.info.streams[1].channels=Some(2);m.info.streams[1].channel_layout=Some("stereo".into());let d=build_export(&p,&request(InterchangeFormat::Edl),&m).unwrap();assert!(std::str::from_utf8(d.bytes()).unwrap().contains("A0000001 AA"));}
#[test]fn explicit_omit_is_disclosed(){let mut r=request(InterchangeFormat::Otio);r.audio=AudioExport::Omit;let d=build_export(&project(),&r,&media()).unwrap();assert!(d.timeline().audio.is_none());assert!(d.report().items.iter().any(|i|i.id=="audio"&&i.representation==Representation::Unsupported&&!i.blocking));}
#[test]fn short_audio_otio_contains_a_gap(){let mut p=project();p.sources[0].media.audio.as_mut().unwrap().duration_ts=Some(96000);p.sources[0].media.audio.as_mut().unwrap().duration=Some(r("2"));let mut m=media();m.info.streams[1]=p.sources[0].media.audio.clone().unwrap();let d=build_export(&p,&request(InterchangeFormat::Otio),&m).unwrap();assert!(d.timeline().audio_pieces.last().unwrap().source_start.is_none());}
#[test]fn fcp7_subframe_audio_gap_fails_instead_of_shifting(){let mut p=project();p.sources[0].media.audio.as_mut().unwrap().duration_ts=Some(96000);p.sources[0].media.audio.as_mut().unwrap().duration=Some(r("2"));let mut m=media();m.info.streams[1]=p.sources[0].media.audio.clone().unwrap();assert!(build_export(&p,&request(InterchangeFormat::Fcp7Xml),&m).is_err());}
#[test]fn offset_audio_requires_stem(){let mut p=project();p.sources[0].media.audio.as_mut().unwrap().start_pts=Some(4800);let mut m=media();m.info.streams[1]=p.sources[0].media.audio.clone().unwrap();assert!(build_export(&p,&request(InterchangeFormat::Otio),&m).is_err());}
#[test]fn multiple_source_audio_requires_stem(){let mut m=media();let mut a=m.info.streams[1].clone();a.index=2;m.info.streams.push(a);assert!(build_export(&project(),&request(InterchangeFormat::Otio),&m).is_err());}
#[test]fn selected_multichannel_is_not_downmixed(){let mut p=project();p.sources[0].media.audio.as_mut().unwrap().channels=Some(6);p.sources[0].media.audio.as_mut().unwrap().channel_layout=Some("5.1".into());let mut m=media();m.info.streams[1]=p.sources[0].media.audio.clone().unwrap();assert!(build_export(&p,&request(InterchangeFormat::Otio),&m).is_err());}
#[test]fn marker_is_mapped_through_cut(){let p=cut_project();let mut q=request(InterchangeFormat::Otio);q.markers.push(ExportMarker{id:"m1".into(),name:"after".into(),comment:"note".into(),at:rate().seconds(25).unwrap(),duration:r("0")});let d=build_export(&p,&q,&media()).unwrap();assert_eq!(d.timeline().markers[0].at,rate().seconds(15).unwrap());}
#[test]fn marker_in_removed_time_is_reported(){let p=cut_project();let mut q=request(InterchangeFormat::Otio);q.markers.push(ExportMarker{id:"m1".into(),name:"removed".into(),comment:"".into(),at:rate().seconds(15).unwrap(),duration:r("0")});let d=build_export(&p,&q,&media()).unwrap();assert!(d.timeline().markers.is_empty());assert!(d.report().items.iter().any(|i|i.id=="marker:m1"));}
#[test]fn spanning_marker_splits(){let p=cut_project();let mut q=request(InterchangeFormat::Otio);q.markers.push(ExportMarker{id:"m1".into(),name:"span".into(),comment:"".into(),at:rate().seconds(5).unwrap(),duration:rate().seconds(20).unwrap()});let d=build_export(&p,&q,&media()).unwrap();assert_eq!(d.timeline().markers.len(),2);}
#[test]fn fcp7_marker_names_are_escaped(){let mut q=request(InterchangeFormat::Fcp7Xml);q.markers.push(ExportMarker{id:"m".into(),name:"<hello & goodbye>".into(),comment:"\"a\"".into(),at:r("0"),duration:r("0")});let d=build_export(&project(),&q,&media()).unwrap();let text=std::str::from_utf8(d.bytes()).unwrap();let xml=roxmltree::Document::parse(text).unwrap();assert!(xml.descendants().any(|n|n.has_tag_name("name")&&n.text()==Some("<hello & goodbye>")));}
#[test]fn marker_overflow_rejected(){let mut q=request(InterchangeFormat::Otio);q.markers.push(ExportMarker{id:"m".into(),name:"x".into(),comment:"".into(),at:r("3"),duration:r("0")});assert!(assess_export(&project(),&q).is_err());}
#[test]fn duplicate_markers_rejected(){let mut q=request(InterchangeFormat::Otio);let m=ExportMarker{id:"m".into(),name:"x".into(),comment:"".into(),at:r("0"),duration:r("0")};q.markers=vec![m.clone(),m];assert!(q.validate().is_err());}
#[test]fn active_framing_is_blocked_without_bake(){let mut p=project();let mut f=FramingSettings::preset(TargetPreset::Square,&p.sources[0]).unwrap();f.disposition=Disposition::AutoApply;p.set_framing("main",Some(f)).unwrap();assert!(assess_export(&p,&request(InterchangeFormat::Otio)).unwrap().blocked());}
#[test]fn pending_presentation_is_never_implicitly_approved(){let mut p=project();p.set_presentation("main",Some(PresentationSettings::default())).unwrap();assert!(assess_export(&p,&request(InterchangeFormat::Otio)).unwrap().blocked());}
#[test]fn requested_bake_does_not_make_missing_media_real(){let mut q=request(InterchangeFormat::Otio);q.video=VisualExport::Bake{destination:loc().with_file_name("baked.mov")};assert!(build_export(&project(),&q,&media()).is_err());}
#[test]fn requested_stem_requires_a_real_result(){let mut q=request(InterchangeFormat::Otio);q.audio=AudioExport::BakeStem{destination:loc().with_file_name("stem.wav")};assert!(build_export(&project(),&q,&media()).is_err());}
#[test]fn source_timecode_offset_is_not_added_to_fcp_in(){let mut q=request(InterchangeFormat::Fcp7Xml);q.source_start_frames=300;q.record_start_frames=900;let d=build_export(&project(),&q,&media()).unwrap();let text=std::str::from_utf8(d.bytes()).unwrap();assert!(text.contains("<in>0</in><out>60</out>"));assert!(text.contains("<frame>300</frame>"));assert!(text.contains("<frame>900</frame>"));}
#[test]fn record_end_may_not_cross_24_hours(){let mut q=request(InterchangeFormat::Otio);q.record_start_frames=rate().frames_per_day()-30;assert!(build_export(&project(),&q,&media()).is_err());}

#[test]fn original_audio_and_video_share_link_identity(){let d=doc(InterchangeFormat::Otio);assert_eq!(d.timeline().clips[0].id,d.timeline().audio_pieces[0].id);}
#[test]fn xml_forbidden_unicode_is_rejected(){let mut q=request(InterchangeFormat::Fcp7Xml);q.name="bad\u{ffff}".into();assert!(build_export(&project(),&q,&media()).is_err());}
#[test]fn saved_cfr_intent_is_not_silently_overridden(){let mut p=project();p.variants[0].render.frame_rate=FrameRateMode::Constant(r("24"));assert!(assess_export(&p,&request(InterchangeFormat::Otio)).unwrap().blocked());}
#[test]fn file_uri_escapes_percent_once(){let p=loc().with_file_name("percent%20name.mov");let u=paths::media_url(&p,&request(InterchangeFormat::Otio).destination,PathMode::AbsoluteFileUrl).unwrap();assert!(u.contains("percent%2520name.mov"));}
#[cfg(unix)]#[test]fn literal_unix_backslash_is_not_a_directory(){let p=loc().with_file_name("back\\slash.mov");let u=paths::media_url(&p,&request(InterchangeFormat::Otio).destination,PathMode::AbsoluteFileUrl).unwrap();assert!(u.ends_with("back%5Cslash.mov"));}
#[test]fn unknown_interlace_state_is_not_progressive(){let mut p=project();p.sources[0].media.video.field_order=None;let mut m=media();m.info.streams[0].field_order=None;assert!(build_export(&p,&request(InterchangeFormat::Fcp7Xml),&m).is_err());}
#[test]fn original_depth_is_not_fabricated(){let d=doc(InterchangeFormat::Fcp7Xml);let tree=roxmltree::Document::parse(std::str::from_utf8(d.bytes()).unwrap()).unwrap();assert!(!tree.descendants().filter(|n|n.has_tag_name("file")).any(|f|f.descendants().any(|n|n.has_tag_name("depth"))));}
#[test]fn cfr_rejects_extra_compact_columns(){for s in ["pts=0||\n","pts=0|flags=1\n","pts=+0\n","pts= 0\n"]{let mut p=CfrVerifier::new(file(),0,rate(),r("0"),r("2.002"),r("1/30000")).unwrap();assert!(p.feed(s.as_bytes(),&Cancellation::new()).is_err());}}
#[test]fn one_compact_delimiter_is_valid(){let c=Cancellation::new();let mut p=CfrVerifier::new(file(),0,rate(),r("0"),r("2.002"),r("1/30000")).unwrap();for n in 0..60{p.feed(format!("pts={}|\n",n*1001).as_bytes(),&c).unwrap();}assert_eq!(p.finish(&c).unwrap().frames(),60);}
#[test]fn unknown_video_field_order_is_not_progressive(){let mut p=project();p.sources[0].media.video.field_order=None;let mut m=media();m.info.streams[0].field_order=None;assert!(build_export(&p,&request(InterchangeFormat::Otio),&m).is_err());}
#[test]fn explicit_hdr_transfer_is_rejected(){let mut p=project();p.sources[0].media.video.color_transfer=Some("smpte2084".into());let mut m=media();m.info.streams[0].color_transfer=Some("smpte2084".into());assert!(build_export(&p,&request(InterchangeFormat::Otio),&m).is_err());}
#[test]fn undeclared_audio_rate_does_not_default_to_48000(){let mut p=project();p.sources[0].media.audio.as_mut().unwrap().sample_rate=None;let mut m=media();m.info.streams[1].sample_rate=None;assert!(build_export(&p,&request(InterchangeFormat::Otio),&m).is_err());}
#[test]fn empty_editor_version_is_not_qualification(){let mut q=request(InterchangeFormat::Otio);q.intended_editor_version=Some(String::new());assert!(q.validate().is_err());}
#[test]fn report_warns_about_paths_and_authored_information(){let d=doc(InterchangeFormat::Otio);assert!(d.report().warnings.iter().any(|x|x.contains("before sharing")));}
#[test]fn markers_count_is_bounded_before_serialization(){let mut q=request(InterchangeFormat::Otio);q.markers=(0..1025).map(|n|ExportMarker{id:format!("m{n}"),name:String::new(),comment:String::new(),at:r("0"),duration:r("0")}).collect();assert!(q.validate().is_err());}
#[test]fn final_frame_end_is_not_wrapped_in_edl(){let mut q=request(InterchangeFormat::Edl);q.source_start_frames=rate().frames_per_day()-30;assert!(build_export(&project(),&q,&media()).is_err());}
#[cfg(windows)]
#[test]fn device_media_uri_is_rejected(){assert!(paths::local_path(std::path::Path::new(r"\\.\C:\media.mov")).is_err());}
#[cfg(windows)]
#[test]fn verbatim_local_drive_uri_is_not_a_network_url(){let a=std::path::Path::new(r"\\?\C:\media\a.mov");let b=std::path::Path::new(r"\\?\C:\exports\a.otio");assert_eq!(paths::media_url(a,b,PathMode::AbsoluteFileUrl).unwrap(),"file:///C:/media/a.mov");}

// 0.10.1 handoff regressions: supplied for execution with Cargo.
#[test]
fn video_links_never_claim_an_audio_output_group() {
    let d=doc(InterchangeFormat::Fcp7Xml);
    let tree=roxmltree::Document::parse(std::str::from_utf8(d.bytes()).unwrap()).unwrap();
    let video:Vec<_>=tree.descendants().filter(|n|n.has_tag_name("link")&&n.children().any(|c|c.has_tag_name("mediatype")&&c.text()==Some("video"))).collect();
    assert!(!video.is_empty());
    assert!(video.iter().all(|n|!n.children().any(|c|c.has_tag_name("groupindex"))));
}
#[test]
fn audio_link_groups_remain_available() {
    let d=doc(InterchangeFormat::Fcp7Xml);
    let tree=roxmltree::Document::parse(std::str::from_utf8(d.bytes()).unwrap()).unwrap();
    let audio:Vec<_>=tree.descendants().filter(|n|n.has_tag_name("link")&&n.children().any(|c|c.has_tag_name("mediatype")&&c.text()==Some("audio"))).collect();
    assert!(!audio.is_empty());
    assert!(audio.iter().all(|n|n.children().any(|c|c.has_tag_name("groupindex")&&c.text()==Some("1"))));
}
#[test]
fn export_document_accepts_its_bound_destination() {
    for f in [InterchangeFormat::Otio,InterchangeFormat::Fcp7Xml,InterchangeFormat::Edl] {
        doc(f).validate_destination(&request(f).destination).unwrap();
    }
}
#[test]
fn export_document_rejects_same_extension_in_another_directory() {
    let mut q=request(InterchangeFormat::Otio);q.paths=PathMode::RelativeToExport;
    let d=build_export(&project(),&q,&media()).unwrap();
    let other=q.destination.parent().unwrap().join("different").join("timeline.otio");
    assert!(d.validate_destination(&other).is_err());
}
#[test]
fn export_document_rejects_relabelling_embedded_request() {
    let q=request(InterchangeFormat::Otio);let d=doc(InterchangeFormat::Otio);
    assert!(d.validate_destination(&q.destination.with_file_name("other.otio")).is_err());
}
#[test]
fn rebuilt_document_accepts_explicitly_changed_destination() {
    let mut q=request(InterchangeFormat::Otio);q.paths=PathMode::RelativeToExport;
    q.destination=q.destination.parent().unwrap().join("different").join("timeline.otio");
    let d=build_export(&project(),&q,&media()).unwrap();
    d.validate_destination(&q.destination).unwrap();
    assert!(d.timeline().video.url.starts_with("../"));
}
#[test]fn otio_dissolve_retains_handles_and_exact_track_duration(){let mut p=cut_project();p.set_timing("main",Some(automexia_video::timing::TimingSettings{enabled:true,disposition:Disposition::AutoApply,locked:false,speed:automexia_video::timing::PlaybackSpeed::Normal,dissolve:rate().seconds(4).unwrap()})).unwrap();p.review_timing("main",Disposition::AutoApply,true).unwrap();let d=build_export(&p,&request(InterchangeFormat::Otio),&media()).unwrap();let json:serde_json::Value=serde_json::from_slice(d.bytes()).unwrap();let tracks=json["tracks"]["children"].as_array().unwrap();for track in tracks{let children=track["children"].as_array().unwrap();assert_eq!(children.len(),3);assert_eq!(children[1]["OTIO_SCHEMA"],"Transition.1");assert_eq!(children[1]["in_offset"]["value"],2);assert_eq!(children[1]["out_offset"]["value"],2);}assert_eq!(d.timeline().duration_frames,46);}
#[test]fn restricted_writers_report_dissolve_bake_requirement(){let mut p=cut_project();p.set_timing("main",Some(automexia_video::timing::TimingSettings{enabled:true,disposition:Disposition::AutoApply,locked:false,speed:automexia_video::timing::PlaybackSpeed::Normal,dissolve:rate().seconds(4).unwrap()})).unwrap();p.review_timing("main",Disposition::AutoApply,true).unwrap();for format in [InterchangeFormat::Fcp7Xml,InterchangeFormat::Edl]{assert!(assess_export(&p,&request(format)).unwrap().blocked());}}
