//! Actual crate tests: these exercise cached workflows, not a reimplementation.
use automexia_video::*;
use automexia_video::host::{FileStamp,MediaTask,ToolOutput};
use automexia_video::project::{ProjectSource,ResolvedSettings,FrozenRenderSettings};
use automexia_video::pause::{EnergyFrame,ChannelEnergy};
use automexia_video::pause_workflow::{AudioAnalysisHost,EnergySink};
use std::{path::{Path,PathBuf},sync::atomic::{AtomicBool,AtomicUsize,Ordering},time::Duration};
use serde_json::json;
struct Host { raw:Vec<u8>,input:InputFile,scans:AtomicUsize,probes:AtomicUsize,inspects:AtomicUsize,
    denied:AtomicBool,changed:AtomicBool,broken:AtomicBool,pinned:AtomicBool,runtime_generation:AtomicUsize }
impl MediaHost for Host {
    fn inspect_input(&self,p:&Path,c:&Cancellation)->Result<InputFile>{c.check()?;self.inspects.fetch_add(1,Ordering::SeqCst);if self.denied.load(Ordering::SeqCst){return Err(Error::MissingCapability("test read grant revoked"));}let mut i=self.input.clone();i.canonical_path=p.to_owned();if self.changed.load(Ordering::SeqCst){i.stamp.sha256="b".repeat(64);}Ok(i)}
    fn revalidate_input(&self,_:&InputFile,c:&Cancellation)->Result<()>{c.check()?;if self.denied.load(Ordering::SeqCst){return Err(Error::MissingCapability("test read grant revoked"));}if self.changed.load(Ordering::SeqCst){return Err(Error::InputChanged);}Ok(())}
    fn runtime_capabilities(&self,c:&Cancellation)->Result<RuntimeCapabilities>{c.check()?;let pinned=self.pinned.load(Ordering::SeqCst);Ok(RuntimeCapabilities{
        ffmpeg_identity:pinned.then(||if self.runtime_generation.load(Ordering::SeqCst)==0{"c".repeat(64)}else{"d".repeat(64)}),ffprobe_identity:pinned.then(||"e".repeat(64)),
        ffmpeg_version:"ffmpeg version 7.1 test fixture".into(),ffprobe_version:"ffprobe version 7.1 test fixture".into(),supports_demux_time_base:true,
        encoders:["pcm_s16le","libx264","aac"].into_iter().map(str::to_owned).collect(),muxers:["null","mp4"].into_iter().map(str::to_owned).collect(),
        filters:["aformat","asettb","atrim","astats","ametadata"].into_iter().map(str::to_owned).collect(),..Default::default()})}
    fn run(&self,t:&MediaTask,c:&Cancellation,_:&mut ProgressSink<'_>)->Result<ToolOutput>{c.check()?;match t{MediaTask::Probe{..}=>{self.probes.fetch_add(1,Ordering::SeqCst);Ok(ToolOutput{stdout:self.raw.clone()})},_=>Err(Error::Unsupported("no render in test host"))}}
    fn stage_output(&self,_:&InputFile,_:&Path,_:&OutputPolicy,_:&Cancellation)->Result<Box<dyn OutputLease>>{Err(Error::Unsupported("no file writes in test host"))}
}
impl AudioAnalysisHost for Host {
    fn stream_energy(&self,_:&AnalysisDecode,c:&Cancellation,sink:&mut EnergySink<'_>)->Result<()>{
        self.scans.fetch_add(1,Ordering::SeqCst);
        for i in 0..500 {c.check()?;if self.broken.load(Ordering::SeqCst)&&i==250{return Err(Error::InvalidInput("truncated test measurements"));}
            let quiet=(100..300).contains(&i);sink(EnergyFrame{pts:i*960,samples:960,channels:vec![ChannelEnergy{rms_dbfs:if quiet{None}else{Some(-20.0)},peak_dbfs:if quiet{None}else{Some(-14.0)}}]})?;
        }Ok(())
    }
}
fn setup()->(VideoExtension<Host>,Project,PathBuf){
    let loc=std::env::temp_dir().join("modernization-tests").join("edit.amxv");
    let raw=serde_json::to_vec(&json!({"format":{"format_name":"mov,mp4,m4a,3gp,3g2,mj2","start_time":"0","duration":"10"},"streams":[
        {"index":0,"codec_type":"video","codec_name":"h264","width":160,"height":96,"pix_fmt":"yuv420p","field_order":"progressive","time_base":"1/30","start_pts":0,"start_time":"0","duration":"10","duration_ts":300,"avg_frame_rate":"30/1","r_frame_rate":"30/1","sample_aspect_ratio":"1:1","color_range":"tv","color_space":"bt709","color_transfer":"bt709","color_primaries":"bt709"},
        {"index":1,"codec_type":"audio","codec_name":"aac","sample_rate":"48000","channels":1,"channel_layout":"mono","time_base":"1/48000","start_pts":0,"start_time":"0","duration":"10","duration_ts":480000}]})).unwrap();
    let m=automexia_video::media::parse_probe(&raw).unwrap();
    let input=InputFile{canonical_path:loc.with_file_name("source.mp4"),stamp:FileStamp{size:100,sha256:"a".repeat(64),modified_ns:None,file_id:None}};
    let src=ProjectSource::from_probe("source-1",&input,&m,m.select(StreamSelection::default()).unwrap(),&loc).unwrap();
    let p=Project::new("cache-fixture",src,ResolvedSettings{workflow:None,voice_cleanup:None,voice_enhancement:None,color_correction:None,pause_cleanup:None,preset_name:None,preset_revision:None,render:FrozenRenderSettings::from_options(&RenderOptions::default()).unwrap()}).unwrap();
    let h=Host{raw,input,scans:0.into(),probes:0.into(),inspects:0.into(),denied:false.into(),changed:false.into(),broken:false.into(),pinned:true.into(),runtime_generation:0.into()};
    (VideoExtension::new(h,VideoSettings::default()).unwrap(),p,loc)
}
fn scan(x:&VideoExtension<Host>,p:&Project,l:&Path,cache:&mut ObservationCache)->CachedAnalysis<PauseReport>{x.analyze_pauses_cached(p,&PauseAnalysisRequest::new(l),cache,&Cancellation::new(),&mut |_|{}).unwrap()}
#[test]fn cache_creation_has_no_host_io(){let(x,_,_)=setup();let _c=x.observation_cache(CacheLimits::default()).unwrap();assert_eq!(x.host().inspects.load(Ordering::SeqCst),0);assert_eq!(x.status().unwrap().active_jobs,0);}
#[test]fn repeat_reuses_observations_not_the_report(){let(x,p,l)=setup();let mut c=x.observation_cache(CacheLimits::default()).unwrap();let a=scan(&x,&p,&l,&mut c);let b=scan(&x,&p,&l,&mut c);assert_eq!(a.cache,CacheUse::MissStored);assert_eq!(b.cache,CacheUse::Hit);assert_eq!(serde_json::to_vec(&a.report).unwrap(),serde_json::to_vec(&b.report).unwrap());assert_eq!(x.host().scans.load(Ordering::SeqCst),1);assert_eq!(x.host().probes.load(Ordering::SeqCst),2);assert_eq!(x.host().inspects.load(Ordering::SeqCst),2);}
#[test]fn default_analysis_remains_uncached(){let(x,p,l)=setup();for _ in 0..2{x.analyze_pauses(&p,&PauseAnalysisRequest::new(&l),&Cancellation::new(),&mut |_|{}).unwrap();}assert_eq!(x.host().scans.load(Ordering::SeqCst),2);}
#[test]fn source_revocation_cannot_hit(){let(x,p,l)=setup();let mut c=x.observation_cache(CacheLimits::default()).unwrap();scan(&x,&p,&l,&mut c);x.host().denied.store(true,Ordering::SeqCst);assert!(x.analyze_pauses_cached(&p,&PauseAnalysisRequest::new(l),&mut c,&Cancellation::new(),&mut |_|{}).is_err());assert_eq!(x.host().scans.load(Ordering::SeqCst),1);}
#[test]fn changed_content_cannot_hit(){let(x,p,l)=setup();let mut c=x.observation_cache(CacheLimits::default()).unwrap();scan(&x,&p,&l,&mut c);x.host().changed.store(true,Ordering::SeqCst);assert!(matches!(x.analyze_pauses_cached(&p,&PauseAnalysisRequest::new(l),&mut c,&Cancellation::new(),&mut |_|{}),Err(Error::InputChanged)));}
#[test]fn changed_settings_miss(){let(x,p,l)=setup();let mut c=x.observation_cache(CacheLimits::default()).unwrap();scan(&x,&p,&l,&mut c);let mut req=PauseAnalysisRequest::new(l);req.settings.content=automexia_video::pause::AudioContent::MixedMusic;let r=x.analyze_pauses_cached(&p,&req,&mut c,&Cancellation::new(),&mut |_|{}).unwrap();assert_eq!(r.cache,CacheUse::MissStored);assert!(r.report.candidates().is_empty());}
#[test]fn changed_runtime_miss(){let(x,p,l)=setup();let mut c=x.observation_cache(CacheLimits::default()).unwrap();scan(&x,&p,&l,&mut c);x.host().runtime_generation.store(1,Ordering::SeqCst);assert_eq!(scan(&x,&p,&l,&mut c).cache,CacheUse::MissStored);assert_eq!(x.host().scans.load(Ordering::SeqCst),2);}
#[test]fn unpinned_runtime_is_never_cached(){let(x,p,l)=setup();x.host().pinned.store(false,Ordering::SeqCst);let mut c=x.observation_cache(CacheLimits::default()).unwrap();for _ in 0..2{assert_eq!(scan(&x,&p,&l,&mut c).cache,CacheUse::UnpinnedRuntime);}assert_eq!(c.stats().entries,0);}
#[test]fn moved_locator_can_reuse_after_real_host_revalidation(){let(x,p,l)=setup();let mut c=x.observation_cache(CacheLimits::default()).unwrap();scan(&x,&p,&l,&mut c);let moved=l.parent().unwrap().join("moved").join("edit.amxv");assert_eq!(scan(&x,&p,&moved,&mut c).cache,CacheUse::Hit);}
#[test]fn rejected_decision_does_not_reappear_on_hit(){let(x,mut p,l)=setup();let mut c=x.observation_cache(CacheLimits::default()).unwrap();let a=scan(&x,&p,&l,&mut c);assert_eq!(a.report.candidates().len(),1);a.report.apply(&mut p).unwrap();let id=a.report.candidates()[0].operation.id.clone();p.review_operation(&id,Disposition::Ignore,false).unwrap();let b=scan(&x,&p,&l,&mut c);assert_eq!(b.cache,CacheUse::Hit);b.report.apply(&mut p).unwrap();let op=p.operations.iter().find(|o|o.id==id).unwrap();assert!(!op.enabled);assert_eq!(op.disposition,Disposition::Ignore);}
#[test]fn protected_new_range_is_honored_on_hit(){let(x,mut p,l)=setup();let mut c=x.observation_cache(CacheLimits::default()).unwrap();scan(&x,&p,&l,&mut c);p.protect_range("source-1",TimeRange::new("3".parse().unwrap(),"4".parse().unwrap()).unwrap(),"manual keep").unwrap();let b=scan(&x,&p,&l,&mut c);assert_eq!(b.cache,CacheUse::Hit);assert!(b.report.candidates().is_empty());}
#[test]fn report_is_bound_to_current_revision(){let(x,mut p,l)=setup();let mut c=x.observation_cache(CacheLimits::default()).unwrap();let a=scan(&x,&p,&l,&mut c);p.protect_range("source-1",TimeRange::new("0".parse().unwrap(),"1".parse().unwrap()).unwrap(),"keep").unwrap();assert!(matches!(a.report.apply(&mut p),Err(Error::StaleReview)));let b=scan(&x,&p,&l,&mut c);assert_eq!(b.cache,CacheUse::Hit);b.report.apply(&mut p).unwrap();assert!(p.operations.iter().any(|o|o.disposition==Disposition::NeedsReview));}
#[test]fn cancelled_owner_cannot_be_revived(){let(x,p,l)=setup();let mut c=x.observation_cache(CacheLimits::default()).unwrap();scan(&x,&p,&l,&mut c);x.disable().unwrap();x.enable().unwrap();assert!(x.analyze_pauses_cached(&p,&PauseAnalysisRequest::new(l),&mut c,&Cancellation::new(),&mut |_|{}).is_err());assert_eq!(c.stats().entries,0);}
#[test]fn invalidation_requires_rescan(){let(x,p,l)=setup();let mut c=x.observation_cache(CacheLimits::default()).unwrap();scan(&x,&p,&l,&mut c);assert_eq!(c.invalidate_source(&p.sources[0].fingerprint.sha256).unwrap(),1);assert_eq!(scan(&x,&p,&l,&mut c).cache,CacheUse::MissStored);}
#[test]fn tiny_budget_does_not_make_analysis_fail(){let(x,p,l)=setup();let mut c=x.observation_cache(CacheLimits{max_payload_bytes:1,max_entry_bytes:1,..Default::default()}).unwrap();assert_eq!(scan(&x,&p,&l,&mut c).cache,CacheUse::MissNotStored);assert_eq!(c.stats().entries,0);}
#[test]fn failed_scan_stores_nothing(){let(x,p,l)=setup();x.host().broken.store(true,Ordering::SeqCst);let mut c=x.observation_cache(CacheLimits::default()).unwrap();assert!(x.analyze_pauses_cached(&p,&PauseAnalysisRequest::new(l),&mut c,&Cancellation::new(),&mut |_|{}).is_err());assert_eq!(c.stats().entries,0);assert_eq!(x.status().unwrap().active_jobs,0);}
#[test]fn cancelled_scan_stores_nothing(){let(x,p,l)=setup();let mut cache=x.observation_cache(CacheLimits::default()).unwrap();let c=Cancellation::new();let out=x.analyze_pauses_cached(&p,&PauseAnalysisRequest::new(l),&mut cache,&c,&mut |e|{if e.out_time_us.is_some(){c.cancel();}});assert!(matches!(out,Err(Error::Cancelled)));assert_eq!(cache.stats().entries,0);}
#[test]fn hit_does_not_mutate_project(){let(x,p,l)=setup();let bytes=p.to_json().unwrap();let mut c=x.observation_cache(CacheLimits::default()).unwrap();for _ in 0..2{scan(&x,&p,&l,&mut c);}assert_eq!(p.to_json().unwrap(),bytes);}
#[test]fn idle_drain_disables_and_invalidates_caches(){let(x,_,_)=setup();let mut c=x.observation_cache(CacheLimits::default()).unwrap();let result=x.disable_and_drain(Duration::ZERO).unwrap();assert!(result.complete);assert_eq!(result.remaining_jobs,0);assert_eq!(result.remaining_workflows,0);assert!(!x.status().unwrap().enabled);assert_eq!(c.stats().entries,0);assert!(x.observation_cache(CacheLimits::default()).is_err());}
#[test]fn schema_and_action_identity_stay_unchanged(){let(x,p,_)=setup();assert_eq!(p.schema_version,automexia_video::project::PROJECT_VERSION);assert_eq!(x.status().unwrap().extension_id,EXTENSION_ID);let mut ids=std::collections::BTreeSet::new();for a in ACTIONS{assert!(ids.insert(a.id));}}
