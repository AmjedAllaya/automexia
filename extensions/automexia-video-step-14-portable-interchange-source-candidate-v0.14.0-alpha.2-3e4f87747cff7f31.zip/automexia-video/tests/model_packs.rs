//! These are Rust unit tests of validation, NOT tests of a learned model.
use automexia_video::{Cancellation,Error,ModelManifest,ModelRuntime,ModelActivation,VerifiedModelPack};
use automexia_video::model_pack::*;
use sha2::{Digest,Sha256};
fn digest(v:&[u8])->String{format!("{:x}",Sha256::digest(v))}
// Minimal protobuf used ONLY to exercise the structural guard. It is not an
// executable neural network and must never be shipped as a real model pack.
fn tiny()->Vec<u8>{vec![8,8,58,0]}
fn manifest(data:&[u8])->ModelManifest{ModelManifest{schema:1,id:"silero-test".into(),revision:"fixture-v1".into(),source_revision:"test-only-not-upstream".into(),contract:SILERO_CONTRACT.into(),preprocessing:SPEECH_PROCESSING.into(),weights_sha256:digest(data),weights_bytes:data.len() as u64,runtime:ModelRuntime{adapter:"fake-test-only".into(),build_info_sha256:"a".repeat(64),artifact_sha256:"b".repeat(64)},code_license:"test fixture".into(),weights_license:"test fixture".into(),notices_sha256:digest(b"test notice")}}
fn pack()->VerifiedModelPack{let d=tiny();let m=serde_json::to_vec(&manifest(&d)).unwrap();VerifiedModelPack::verify(&m,d,b"test notice",&digest(&m),&Cancellation::new()).unwrap()}
#[test]fn verifies_explicit_exact_bytes(){let p=pack();assert_eq!(p.weights(),tiny());assert_eq!(p.identity().manifest_sha256.len(),64);}
#[test]fn wrong_manifest_is_not_selection(){let d=tiny();let m=serde_json::to_vec(&manifest(&d)).unwrap();assert!(VerifiedModelPack::verify(&m,d,b"test notice",&"a".repeat(64),&Cancellation::new()).is_err());}
#[test]fn changed_weights_rejected(){let d=tiny();let m=serde_json::to_vec(&manifest(&d)).unwrap();assert!(VerifiedModelPack::verify(&m,vec![8,7,58,0],b"test notice",&digest(&m),&Cancellation::new()).is_err());}
#[test]fn changed_notice_rejected(){let d=tiny();let m=serde_json::to_vec(&manifest(&d)).unwrap();assert!(VerifiedModelPack::verify(&m,d,b"wrong notice",&digest(&m),&Cancellation::new()).is_err());}
#[test]fn cancelled_validation_returns_cancelled(){let c=Cancellation::new();c.cancel();let d=tiny();let m=serde_json::to_vec(&manifest(&d)).unwrap();assert!(matches!(VerifiedModelPack::verify(&m,d,b"test notice",&digest(&m),&c),Err(Error::Cancelled)));}
#[test]fn duplicate_json_key_rejected(){let m=serde_json::to_string(&manifest(&tiny())).unwrap();let bad=m.replacen('{',"{\"schema\":1,",1);assert!(ModelManifest::from_json(bad.as_bytes()).is_err());}
#[test]fn unknown_manifest_field_rejected(){let mut m=serde_json::to_value(manifest(&tiny())).unwrap();m["download_url"]=serde_json::json!("https://example.invalid");assert!(ModelManifest::from_json(&serde_json::to_vec(&m).unwrap()).is_err());}
#[test]fn future_schema_is_not_guessed(){let mut m=manifest(&tiny());m.schema=2;assert!(m.validate().is_err());}
#[test]fn unknown_model_contract_rejected(){let mut m=manifest(&tiny());m.contract="another-network".into();assert!(m.validate().is_err());}
#[test]fn hidden_preprocessing_change_rejected(){let mut m=manifest(&tiny());m.preprocessing="normalize-first".into();assert!(m.validate().is_err());}
#[test]fn hash_format_is_strict(){for h in ["A".repeat(64),"0".repeat(63),"g".repeat(64)]{let mut m=manifest(&tiny());m.weights_sha256=h;assert!(m.validate().is_err());}}
#[test]fn empty_or_oversized_weight_declaration_rejected(){for n in [0,MODEL_BYTES_LIMIT as u64+1]{let mut m=manifest(&tiny());m.weights_bytes=n;assert!(m.validate().is_err());}}
#[test]fn license_text_cannot_be_empty(){let mut m=manifest(&tiny());m.weights_license=" ".into();assert!(m.validate().is_err());}
#[test]fn model_token_cannot_be_path(){let mut m=manifest(&tiny());m.id="../../escape".into();assert!(m.validate().is_err());}
#[test]fn missing_graph_rejected(){assert!(check_embedded_onnx(&[8,8],&Cancellation::new()).is_err());}
#[test]fn duplicate_graph_rejected(){assert!(check_embedded_onnx(&[8,8,58,0,58,0],&Cancellation::new()).is_err());}
#[test]fn malformed_wire_and_truncation_rejected(){for v in [vec![8],vec![8,8,58,9,0],vec![8,8,58,1,0],vec![8,8,58,1,15]]{assert!(check_embedded_onnx(&v,&Cancellation::new()).is_err());}}
#[test]fn custom_node_domain_rejected(){let node=[58,3,b'b',b'a',b'd'];let mut graph=vec![10,node.len() as u8];graph.extend(node);let mut model=vec![8,8,58,graph.len() as u8];model.extend(graph);assert!(check_embedded_onnx(&model,&Cancellation::new()).is_err());}
#[test]fn external_tensor_location_rejected(){let tensor=[112,1];let graph=[42,2,tensor[0],tensor[1]];let mut model=vec![8,8,58,4];model.extend(graph);assert!(check_embedded_onnx(&model,&Cancellation::new()).is_err());}
#[test]fn external_tensor_key_even_empty_is_rejected(){let model=[8,8,58,4,42,2,106,0];assert!(check_embedded_onnx(&model,&Cancellation::new()).is_err());}
#[test]fn nested_graph_external_tensor_rejected(){let sub=[42,2,112,1];let mut attr=vec![50,4];attr.extend(sub);let mut node=vec![42,attr.len() as u8];node.extend(attr);let mut graph=vec![10,node.len() as u8];graph.extend(node);let mut model=vec![8,8,58,graph.len() as u8];model.extend(graph);assert!(check_embedded_onnx(&model,&Cancellation::new()).is_err());}
#[test]fn local_functions_rejected(){let mut d=tiny();d.extend([202,1,0]);assert!(check_embedded_onnx(&d,&Cancellation::new()).is_err());}
#[test]fn sparse_initializers_rejected(){let d=[8,8,58,2,122,0];assert!(check_embedded_onnx(&d,&Cancellation::new()).is_err());}
#[test]fn activation_revocation_reaches_clones(){let a=ModelActivation::selected(pack().identity().clone()).unwrap();let b=a.clone();a.revoke();assert!(b.check().is_err());}
#[test]fn another_selected_activation_is_not_revoked(){let p=pack();let a=ModelActivation::selected(p.identity().clone()).unwrap();let b=ModelActivation::selected(p.identity().clone()).unwrap();a.revoke();assert!(b.check().is_ok());}
#[test]fn clones_keep_immutable_selected_bytes(){let p=pack();let c=p.clone();drop(p);assert_eq!(c.weights(),tiny());}
#[test]fn debug_does_not_print_weights(){let p=pack();let d=format!("{p:?}");assert!(d.contains("weights_bytes"));assert!(!d.contains("[8, 8, 58, 0]"));}

#[test]fn face_contracts_are_explicitly_supported(){
    use automexia_video::model_pack::{YUNET_CONTRACT,YUNET_PROCESSING,ULTRAFACE_CONTRACT,ULTRAFACE_PROCESSING};
    let base=manifest(&tiny());
    for (contract,pre) in [(YUNET_CONTRACT,YUNET_PROCESSING),(ULTRAFACE_CONTRACT,ULTRAFACE_PROCESSING)]{
        let mut m=base.clone();m.contract=contract.into();m.preprocessing=pre.into();assert!(m.validate().is_ok());
    }
}
#[test]fn mismatched_face_preprocessing_is_rejected(){
    use automexia_video::model_pack::{YUNET_CONTRACT,ULTRAFACE_PROCESSING};
    let mut m=manifest(&tiny());m.contract=YUNET_CONTRACT.into();m.preprocessing=ULTRAFACE_PROCESSING.into();
    // Current face candidates intentionally share one preprocessing contract; make
    // the mismatch unambiguously unsupported rather than relying on another face value.
    m.preprocessing="unsupported-face-preprocess".into();assert!(m.validate().is_err());
}
