//! Step 11 regressions against the actual library; run with Cargo, not a mirror.
use automexia_video::*;
use automexia_video::host::{FileStamp,MediaTask,ToolOutput};
use automexia_video::project::{ProjectSource,ResolvedSettings,FrozenRenderSettings};
use automexia_video::review::ReviewPage;
use std::{path::Path,sync::atomic::{AtomicUsize,Ordering}};

#[derive(Default)] struct NoIo { calls: AtomicUsize }
impl NoIo { fn touched<T>(&self)->Result<T>{self.calls.fetch_add(1,Ordering::SeqCst);Err(Error::Unsupported("test host has no I/O"))} }
impl MediaHost for NoIo {
    fn inspect_input(&self,_:&Path,_:&Cancellation)->Result<InputFile>{self.touched()}
    fn revalidate_input(&self,_:&InputFile,_:&Cancellation)->Result<()>{self.touched()}
    fn runtime_capabilities(&self,_:&Cancellation)->Result<RuntimeCapabilities>{self.touched()}
    fn run(&self,_:&MediaTask,_:&Cancellation,_:&mut ProgressSink<'_>)->Result<ToolOutput>{self.touched()}
    fn stage_output(&self,_:&InputFile,_:&Path,_:&OutputPolicy,_:&Cancellation)->Result<Box<dyn OutputLease>>{self.touched()}
}
fn ext()->VideoExtension<NoIo>{VideoExtension::new(NoIo::default(),VideoSettings::default()).unwrap()}
fn project()->Project{
    let location=std::env::temp_dir().join("release-fixture.amxv");
    let media=automexia_video::media::parse_probe(include_bytes!("fixtures/probe-base.json")).unwrap();
    let input=InputFile{canonical_path:location.parent().unwrap().join("fixture.mp4"),stamp:FileStamp{size:100,sha256:"a".repeat(64),modified_ns:None,file_id:None}};
    let source=ProjectSource::from_probe("source-1",&input,&media,media.select(StreamSelection::default()).unwrap(),&location).unwrap();
    Project::new("release-fixture",source,ResolvedSettings{workflow:None,voice_cleanup:None,voice_enhancement:None,color_correction:None,pause_cleanup:None,preset_name:None,preset_revision:None,render:FrozenRenderSettings::from_options(&RenderOptions::default()).unwrap()}).unwrap()
}
#[test] fn constructing_status_and_help_are_lazy(){let x=ext();assert_eq!(x.status().unwrap().active_jobs,0);assert!(!HELP.is_empty());assert_eq!(x.host().calls.load(Ordering::SeqCst),0);}
#[test] fn review_open_needs_no_tool_or_files(){let x=ext();let _s=x.review_project(&project()).unwrap();assert_eq!(x.host().calls.load(Ordering::SeqCst),0);}
#[test] fn disable_closes_owned_review(){let x=ext();let mut s=x.review_project(&project()).unwrap();let v=s.snapshot().unwrap();x.disable().unwrap();assert!(s.is_closed());assert!(matches!(s.dispatch(&v.token,ReviewCommand::Next),Err(Error::ReviewClosed)));}
#[test] fn disable_cancels_review_preview_token(){let x=ext();let s=x.review_project(&project()).unwrap();let c=s.preview_cancellation(&s.snapshot().unwrap().token).unwrap();x.disable().unwrap();assert!(c.is_cancelled());}
#[test] fn changed_view_keeps_owner_cancellation(){let x=ext();let mut s=x.review_project(&project()).unwrap();let v=s.snapshot().unwrap();s.dispatch(&v.token,ReviewCommand::Filter("source".into())).unwrap();let c=s.preview_cancellation(&s.snapshot().unwrap().token).unwrap();x.disable().unwrap();assert!(c.is_cancelled());}
#[test] fn reenabling_does_not_revive_an_old_review(){let x=ext();let s=x.review_project(&project()).unwrap();x.disable().unwrap();x.enable().unwrap();assert!(s.is_closed());assert!(!x.review_project(&project()).unwrap().is_closed());}
#[test] fn cancel_all_ends_old_review_lifetime(){let x=ext();let s=x.review_project(&project()).unwrap();x.cancel_all().unwrap();assert!(s.is_closed());assert!(!x.review_project(&project()).unwrap().is_closed());}
#[test] fn dropping_extension_cancels_outstanding_review(){let x=ext();let s=x.review_project(&project()).unwrap();let c=s.preview_cancellation(&s.snapshot().unwrap().token).unwrap();drop(x);assert!(c.is_cancelled());assert!(s.is_closed());}
#[test] fn closed_review_keeps_recoverable_edit_bytes(){let x=ext();let p=project();let s=x.review_project(&p).unwrap();x.disable().unwrap();assert_eq!(s.project().to_json().unwrap(),p.to_json().unwrap());}
#[test] fn owner_ended_snapshot_is_closed(){let x=ext();let s=x.review_project(&project()).unwrap();x.disable().unwrap();assert_eq!(s.snapshot().unwrap().page,ReviewPage::Closed);}
#[test] fn closing_one_review_does_not_close_sibling(){let x=ext();let mut a=x.review_project(&project()).unwrap();let b=x.review_project(&project()).unwrap();a.close();assert!(!b.is_closed());assert!(x.status().unwrap().enabled);}
#[test] fn standalone_review_remains_caller_owned(){let x=ext();let s=ReviewSession::new(project()).unwrap();drop(x);assert!(!s.is_closed());}
#[test] fn repeated_lifecycle_has_no_hidden_host_io(){let x=ext();for _ in 0..100{x.disable().unwrap();x.enable().unwrap();x.cancel_all().unwrap();}assert_eq!(x.host().calls.load(Ordering::SeqCst),0);}
#[test] fn invalid_limits_never_start_host(){assert!(VideoExtension::new(NoIo::default(),VideoSettings{max_concurrent_jobs:0}).is_err());}
#[test] fn disabled_runtime_query_never_starts_tool(){let x=ext();x.disable().unwrap();assert!(matches!(x.check_runtime(&Cancellation::new()),Err(Error::Disabled)));assert_eq!(x.host().calls.load(Ordering::SeqCst),0);}
