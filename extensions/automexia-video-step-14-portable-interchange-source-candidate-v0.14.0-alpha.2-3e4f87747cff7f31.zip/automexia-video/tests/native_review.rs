//! Actual Rust -> NativeMediaHost -> FFmpeg review workflow checks.
//! Missing dependencies fail; no ignored tests or simulated media success.
use automexia_video::*;
use automexia_video::host::{MediaTask, ProgressSink, ToolOutput, OutputLease};
use automexia_video::native::{NativeMediaHost,NativeSettings};
use automexia_video::preview::{PreviewOpener,VerifiedPreview};
use automexia_video::project::*;
use std::{fs,path::{Path,PathBuf},process::Command,sync::atomic::{AtomicUsize,Ordering}};
use tempfile::TempDir;

fn tool(name:&str)->PathBuf {
    std::env::var_os(name).map(PathBuf::from).unwrap_or_else(|| PathBuf::from(if name=="FFMPEG" {"/usr/bin/ffmpeg"} else {"/usr/bin/ffprobe"}))
}
fn host()->NativeMediaHost { NativeMediaHost::new(NativeSettings::new(tool("FFMPEG"),tool("FFPROBE"))).unwrap() }
fn ext()->VideoExtension<NativeMediaHost> { VideoExtension::new(host(),VideoSettings::default()).unwrap() }
fn r(s:&str)->Rational { s.parse().unwrap() }
fn range(a:&str,b:&str)->TimeRange { TimeRange::new(r(a),r(b)).unwrap() }
fn input(dir:&Path,audio:bool)->PathBuf {
    let path=dir.join("input.mp4");let mut cmd=Command::new(tool("FFMPEG"));
    cmd.args(["-v","error","-nostdin","-y","-f","lavfi","-i","testsrc2=size=160x96:rate=30:duration=3"]);
    if audio { cmd.args(["-f","lavfi","-i","sine=frequency=440:sample_rate=48000:duration=3","-c:a","aac"]); }
    cmd.args(["-c:v","libx264","-preset","fast","-threads","2","-pix_fmt","yuv420p"]).arg(&path);
    assert!(cmd.status().unwrap().success());path
}
fn pending<H:MediaHost>(x:&VideoExtension<H>,input:&Path,project_file:&Path)->Project {
    let mut p=x.create_project(&NewProjectRequest::new("review-project",input,project_file),&Cancellation::new(),&mut |_|{}).unwrap();
    p.add_operation(EditOperation{id:"candidate".into(),source_id:"source-1".into(),kind:EditKind::RemoveRange,
        range:range("1","2"),reason:"Synthetic test proposal, not a detector".into(),
        origin:EditOrigin::Generator{id:"fixture".into(),version:"1".into()},disposition:Disposition::NeedsReview,
        enabled:true,locked:false,user_override:false}).unwrap();p
}
fn request(p:&Project,path:&Path,dir:&Path)->PreviewRequest {
    let mut req=PreviewRequest::new(p,path,dir,ReviewTarget::Operation("candidate".into())).unwrap();
    req.options.context=r("1/2");req.options.max_width=80;req.options.max_height=48;req
}
fn clean(dir:&Path) {
    assert!(!fs::read_dir(dir).unwrap().any(|e|e.unwrap().file_name().to_string_lossy().starts_with(".automexia-video-")));
}
#[derive(Default)]struct Capture { paths:Vec<PathBuf> }
impl PreviewOpener for Capture {
    fn open(&mut self,p:&VerifiedPreview<'_>)->Result<()> {
        assert!(p.file().canonical_path.is_file());assert!(p.metadata().full_decode_validated);
        self.paths.push(p.file().canonical_path.clone());Ok(())
    }
}

#[test]fn actual_proxy_pair_is_temporary_validated_and_audio_bearing() {
    let d=TempDir::new().unwrap();let x=ext();let source=input(d.path(),true);let path=d.path().join("review.amxv");let p=pending(&x,&source,&path);let original=fs::read(&source).unwrap();
    let previews=x.preview_edit(&p,&request(&p,&path,d.path()),&Cancellation::new(),&mut |_|{}).unwrap();
    let a=previews.metadata(PreviewSide::Before).unwrap();let b=previews.metadata(PreviewSide::Proposed).unwrap();
    assert_eq!((a.width,a.height),(80,48));assert!(a.audio_available);assert!(b.audio_available);
    assert!((a.duration.as_f64()-2.0).abs()<0.1);assert!((b.duration.as_f64()-1.0).abs()<0.1);
    assert!(!path.exists());assert_eq!(fs::read(&source).unwrap(),original);
    let mut capture=Capture::default();x.open_preview(&previews,&p,PreviewSide::Before,&mut capture,&Cancellation::new()).unwrap();
    x.open_preview(&previews,&p,PreviewSide::Proposed,&mut capture,&Cancellation::new()).unwrap();
    assert_eq!(capture.paths.len(),2);drop(previews);for path in capture.paths {assert!(!path.exists());}clean(d.path());
}
#[test]fn native_preview_of_pending_edit_does_not_bypass_final_gate() {
    let d=TempDir::new().unwrap();let x=ext();let source=input(d.path(),true);let path=d.path().join("review.amxv");let p=pending(&x,&source,&path);let before=p.to_json().unwrap();
    let previews=x.preview_edit(&p,&request(&p,&path,d.path()),&Cancellation::new(),&mut |_|{}).unwrap();
    assert_eq!(p.to_json().unwrap(),before);let output=d.path().join("final.mp4");
    assert!(matches!(x.render_project(&p,&ProjectRenderRequest::new(&path,&output),&Cancellation::new(),&mut |_|{}),Err(Error::UnresolvedEdits)));
    assert!(!output.exists());drop(previews);clean(d.path());
}
#[test]fn review_approval_lock_save_reopen_and_final_render_work_together() {
    let d=TempDir::new().unwrap();let x=ext();let source=input(d.path(),true);let path=d.path().join("review.amxv");let p=pending(&x,&source,&path);
    let mut review=x.review_project(&p).unwrap();let v=review.snapshot().unwrap();let v=review.dispatch(&v.token,ReviewCommand::Select(ReviewTarget::Operation("candidate".into()))).unwrap();
    let v=review.dispatch(&v.token,ReviewCommand::Approve).unwrap();review.dispatch(&v.token,ReviewCommand::SetLocked(true)).unwrap();
    x.save_project(review.project(),&path,&OutputPolicy::CreateNew,&Cancellation::new()).unwrap();let loaded=x.load_project(&path,&Cancellation::new()).unwrap();
    assert!(loaded.project.operations[0].locked);assert_eq!(loaded.project.operations[0].disposition,Disposition::AutoApply);
    let output=d.path().join("accepted.mp4");x.render_project(&loaded.project,&ProjectRenderRequest::new(&path,&output),&Cancellation::new(),&mut |_|{}).unwrap();assert!(output.is_file());clean(d.path());
}
#[test]fn old_preview_cannot_be_opened_after_a_decision_change() {
    let d=TempDir::new().unwrap();let x=ext();let source=input(d.path(),false);let path=d.path().join("review.amxv");let mut p=pending(&x,&source,&path);
    let previews=x.preview_edit(&p,&request(&p,&path,d.path()),&Cancellation::new(),&mut |_|{}).unwrap();p.review_operation("candidate",Disposition::Ignore,false).unwrap();
    let mut capture=Capture::default();assert!(matches!(x.open_preview(&previews,&p,PreviewSide::Before,&mut capture,&Cancellation::new()),Err(Error::StaleReview)));assert!(capture.paths.is_empty());
}
#[test]fn changed_media_cannot_reuse_old_preview_for_review() {
    let d=TempDir::new().unwrap();let x=ext();let source=input(d.path(),false);let path=d.path().join("review.amxv");let p=pending(&x,&source,&path);
    let previews=x.preview_edit(&p,&request(&p,&path,d.path()),&Cancellation::new(),&mut |_|{}).unwrap();fs::write(&source,b"changed").unwrap();
    let mut capture=Capture::default();assert!(x.open_preview(&previews,&p,PreviewSide::Before,&mut capture,&Cancellation::new()).is_err());assert!(capture.paths.is_empty());
}
#[test]fn tampered_proxy_is_not_passed_to_host_opener() {
    let d=TempDir::new().unwrap();let x=ext();let source=input(d.path(),false);let path=d.path().join("review.amxv");let p=pending(&x,&source,&path);
    let previews=x.preview_edit(&p,&request(&p,&path,d.path()),&Cancellation::new(),&mut |_|{}).unwrap();let mut capture=Capture::default();
    x.open_preview(&previews,&p,PreviewSide::Before,&mut capture,&Cancellation::new()).unwrap();let proxy=capture.paths[0].clone();fs::write(proxy,b"changed proxy").unwrap();
    capture.paths.clear();assert!(x.open_preview(&previews,&p,PreviewSide::Before,&mut capture,&Cancellation::new()).is_err());assert!(capture.paths.is_empty());
}
#[test]fn fully_removed_proposal_has_explicit_no_media_side() {
    let d=TempDir::new().unwrap();let x=ext();let source=input(d.path(),true);let path=d.path().join("review.amxv");let mut p=pending(&x,&source,&path);
    p.operations[0].range=TimeRange::new(r("0"),p.sources[0].duration).unwrap();let previews=x.preview_edit(&p,&request(&p,&path,d.path()),&Cancellation::new(),&mut |_|{}).unwrap();
    assert!(previews.metadata(PreviewSide::Proposed).is_none());let mut capture=Capture::default();assert!(matches!(x.open_preview(&previews,&p,PreviewSide::Proposed,&mut capture,&Cancellation::new()),Err(Error::EmptyTimeline)));assert!(capture.paths.is_empty());
}
#[test]fn no_audio_input_creates_video_only_proxies() {
    let d=TempDir::new().unwrap();let x=ext();let source=input(d.path(),false);let path=d.path().join("review.amxv");let p=pending(&x,&source,&path);
    let previews=x.preview_edit(&p,&request(&p,&path,d.path()),&Cancellation::new(),&mut |_|{}).unwrap();assert!(!previews.metadata(PreviewSide::Before).unwrap().audio_available);
}
#[test]fn cancelling_render_cleans_all_proxy_leases() {
    let d=TempDir::new().unwrap();let x=ext();let source=input(d.path(),true);let path=d.path().join("review.amxv");let p=pending(&x,&source,&path);let c=Cancellation::new();let linked=c.clone();
    let result=x.preview_edit(&p,&request(&p,&path,d.path()),&c,&mut |event| {if event.stage==automexia_video::progress::Stage::Rendering {linked.cancel();}});
    assert!(matches!(result,Err(Error::Cancelled)));clean(d.path());assert_eq!(x.status().unwrap().active_jobs,0);
}
#[test]fn proxy_file_budget_is_enforced_and_cleaned() {
    let d=TempDir::new().unwrap();let x=ext();let source=input(d.path(),true);let path=d.path().join("review.amxv");let p=pending(&x,&source,&path);let mut req=request(&p,&path,d.path());req.options.max_bytes=1024;
    assert!(matches!(x.preview_edit(&p,&req,&Cancellation::new(),&mut |_|{}),Err(Error::LimitExceeded(_))));clean(d.path());
}
#[test]fn absent_source_fails_without_allocating_preview_output() {
    let d=TempDir::new().unwrap();let x=ext();let source=input(d.path(),true);let path=d.path().join("review.amxv");let p=pending(&x,&source,&path);fs::remove_file(&source).unwrap();
    assert!(x.preview_edit(&p,&request(&p,&path,d.path()),&Cancellation::new(),&mut |_|{}).is_err());clean(d.path());
}
#[test]fn absent_scratch_directory_is_not_created_implicitly() {
    let d=TempDir::new().unwrap();let x=ext();let source=input(d.path(),true);let path=d.path().join("review.amxv");let p=pending(&x,&source,&path);let missing=d.path().join("absent");
    assert!(x.preview_edit(&p,&request(&p,&path,&missing),&Cancellation::new(),&mut |_|{}).is_err());assert!(!missing.exists());clean(d.path());
}
#[test]fn disabled_extension_cannot_render_or_open_review() {
    let d=TempDir::new().unwrap();let x=ext();let source=input(d.path(),false);let path=d.path().join("review.amxv");let p=pending(&x,&source,&path);x.disable().unwrap();
    assert!(matches!(x.review_project(&p),Err(Error::Disabled)));assert!(matches!(x.preview_edit(&p,&request(&p,&path,d.path()),&Cancellation::new(),&mut |_|{}),Err(Error::Disabled)));clean(d.path());
}

struct FailSecondHost {inner:NativeMediaHost,renders:AtomicUsize}
impl MediaHost for FailSecondHost {
    fn inspect_input(&self,p:&Path,c:&Cancellation)->Result<InputFile>{self.inner.inspect_input(p,c)}
    fn revalidate_input(&self,p:&InputFile,c:&Cancellation)->Result<()>{self.inner.revalidate_input(p,c)}
    fn runtime_capabilities(&self,c:&Cancellation)->Result<RuntimeCapabilities>{self.inner.runtime_capabilities(c)}
    fn stage_output(&self,i:&InputFile,p:&Path,o:&OutputPolicy,c:&Cancellation)->Result<Box<dyn OutputLease>>{self.inner.stage_output(i,p,o,c)}
    fn run(&self,t:&MediaTask,c:&Cancellation,p:&mut ProgressSink<'_>)->Result<ToolOutput>{
        if matches!(t,MediaTask::Render{..}) && self.renders.fetch_add(1,Ordering::SeqCst)==1 {
            return Err(Error::ToolFailed{tool:"ffmpeg",exit_code:Some(99)});
        }
        self.inner.run(t,c,p)
    }
}
#[test]fn failure_of_second_branch_cleans_completed_first_branch() {
    let d=TempDir::new().unwrap();let x=VideoExtension::new(FailSecondHost{inner:host(),renders:AtomicUsize::new(0)},VideoSettings::default()).unwrap();
    let source=input(d.path(),true);let path=d.path().join("review.amxv");let p=pending(&x,&source,&path);
    assert!(matches!(x.preview_edit(&p,&request(&p,&path,d.path()),&Cancellation::new(),&mut |_|{}),Err(Error::ToolFailed{exit_code:Some(99),..})));clean(d.path());
}
#[test]fn review_rejects_late_preview_for_another_selection() {
    let d=TempDir::new().unwrap();let x=ext();let source=input(d.path(),false);let path=d.path().join("review.amxv");let p=pending(&x,&source,&path);let mut s=x.review_project(&p).unwrap();let v=s.snapshot().unwrap();let v=s.dispatch(&v.token,ReviewCommand::Select(ReviewTarget::Operation("candidate".into()))).unwrap();
    let set=x.preview_edit(s.project(),&request(s.project(),&path,d.path()),&s.preview_cancellation(&v.token).unwrap(),&mut |_|{}).unwrap();s.validate_preview(&v.token,&set).unwrap();
    s.dispatch(&v.token,ReviewCommand::First).unwrap();assert!(matches!(s.validate_preview(&v.token,&set),Err(Error::StaleReview)));
}
#[test]fn opener_failure_does_not_publish_or_modify_project() {
    struct Denied;impl PreviewOpener for Denied{fn open(&mut self,_:&VerifiedPreview<'_>)->Result<()>{Err(Error::Unsupported("host preview is unavailable"))}}
    let d=TempDir::new().unwrap();let x=ext();let source=input(d.path(),false);let path=d.path().join("review.amxv");let p=pending(&x,&source,&path);let before=p.to_json().unwrap();
    let set=x.preview_edit(&p,&request(&p,&path,d.path()),&Cancellation::new(),&mut |_|{}).unwrap();assert!(x.open_preview(&set,&p,PreviewSide::Before,&mut Denied,&Cancellation::new()).is_err());
    assert_eq!(p.to_json().unwrap(),before);drop(set);clean(d.path());
}

#[test]fn changed_preview_focus_rejects_the_older_completed_result() {
    let d=TempDir::new().unwrap();let x=ext();let source=input(d.path(),true);let path=d.path().join("review.amxv");let p=pending(&x,&source,&path);
    let mut s=x.review_project(&p).unwrap();let v=s.snapshot().unwrap();let v=s.dispatch(&v.token,ReviewCommand::Select(ReviewTarget::Operation("candidate".into()))).unwrap();
    let req=request(s.project(),&path,d.path());let first=s.begin_preview(&v.token,&req).unwrap();
    let set=x.preview_edit(s.project(),&req,&first.cancellation(),&mut |_|{}).unwrap();s.accept_preview(&first,&set).unwrap();
    let mut other=req.clone();other.focus=PreviewFocus::StartBoundary;let second=s.begin_preview(&v.token,&other).unwrap();
    assert!(s.accept_preview(&first,&set).is_err());assert!(s.accept_preview(&second,&set).is_err());drop(set);clean(d.path());
}
#[test]fn panicking_opener_returns_error_without_losing_project() {
    struct Panics;impl PreviewOpener for Panics {fn open(&mut self,_:&VerifiedPreview<'_>)->Result<()>{panic!("test-only host failure")}}
    let d=TempDir::new().unwrap();let x=ext();let source=input(d.path(),false);let path=d.path().join("review.amxv");let p=pending(&x,&source,&path);let original=p.to_json().unwrap();
    let set=x.preview_edit(&p,&request(&p,&path,d.path()),&Cancellation::new(),&mut |_|{}).unwrap();
    assert!(matches!(x.open_preview(&set,&p,PreviewSide::Before,&mut Panics,&Cancellation::new()),Err(Error::CallbackPanicked)));
    assert_eq!(original,p.to_json().unwrap());assert_eq!(x.status().unwrap().active_jobs,0);drop(set);clean(d.path());
}
#[test]fn cancellation_prevents_opener_call() {
    let d=TempDir::new().unwrap();let x=ext();let source=input(d.path(),false);let path=d.path().join("review.amxv");let p=pending(&x,&source,&path);
    let set=x.preview_edit(&p,&request(&p,&path,d.path()),&Cancellation::new(),&mut |_|{}).unwrap();let c=Cancellation::new();c.cancel();let mut capture=Capture::default();
    assert!(matches!(x.open_preview(&set,&p,PreviewSide::Before,&mut capture,&c),Err(Error::Cancelled)));assert!(capture.paths.is_empty());drop(set);clean(d.path());
}
#[test]fn proxy_set_can_move_from_worker_to_host_owner() {
    fn assert_send<T:Send>(){} assert_send::<PreviewSet>();
}

#[test]
fn native_pending_assembly_preview_plays_all_occurrences_and_cleans_both_leases(){
    let d=TempDir::new().unwrap();let x=ext();let source=input(d.path(),true);let path=d.path().join("assembly.amxv");
    let mut p=x.create_project(&NewProjectRequest::new("assembly-preview",&source,&path),&Cancellation::new(),&mut |_|{}).unwrap();
    p.set_assembly("main",Some(AssemblySettings{clips:vec![
        AssemblyClip{id:"last".into(),range:range("2","3"),speed:PlaybackSpeed::Normal},
        AssemblyClip{id:"first".into(),range:range("0","1"),speed:PlaybackSpeed::Normal},
        AssemblyClip{id:"again".into(),range:range("2","3"),speed:PlaybackSpeed::Normal},
    ],..Default::default()})).unwrap();
    let original=p.to_json().unwrap();let source_bytes=fs::read(&source).unwrap();
    let q=PreviewRequest::new(&p,&path,d.path(),ReviewTarget::AssemblyVariant("main".into())).unwrap();
    let previews=x.preview_edit(&p,&q,&Cancellation::new(),&mut |_|{}).unwrap();
    assert_eq!(previews.description().proposed_timeline.as_ref().unwrap().segments.len(),3);
    assert!((previews.metadata(PreviewSide::Proposed).unwrap().duration.as_f64()-3.0).abs()<0.05);
    assert!((previews.metadata(PreviewSide::Before).unwrap().duration.as_f64()-2.0).abs()<0.05);
    assert_eq!(p.to_json().unwrap(),original);assert_eq!(fs::read(&source).unwrap(),source_bytes);
    let mut capture=Capture::default();for side in [PreviewSide::Before,PreviewSide::Proposed]{x.open_preview(&previews,&p,side,&mut capture,&Cancellation::new()).unwrap();}
    drop(previews);for file in capture.paths{assert!(!file.exists());}clean(d.path());
}
#[test]
fn native_assembly_proxy_budget_blocks_before_runtime_or_staging(){
    let d=TempDir::new().unwrap();let x=ext();let source=input(d.path(),false);let path=d.path().join("assembly.amxv");
    let mut p=x.create_project(&NewProjectRequest::new("assembly-budget",&source,&path),&Cancellation::new(),&mut |_|{}).unwrap();
    p.set_assembly("main",Some(AssemblySettings{clips:vec![AssemblyClip{id:"slow".into(),range:range("0","3"),speed:PlaybackSpeed::Half}],..Default::default()})).unwrap();
    let mut q=PreviewRequest::new(&p,&path,d.path(),ReviewTarget::AssemblyVariant("main".into())).unwrap();q.options.max_window=r("4");
    let mut events=0;assert!(matches!(x.preview_edit(&p,&q,&Cancellation::new(),&mut |_|{events+=1;}),Err(Error::Unsupported(_))));
    assert_eq!(events,0);assert_eq!(x.status().unwrap().active_jobs,0);clean(d.path());
}
