//! Host/lifecycle tests with a deliberately synthetic transcript provider.
use automexia_video::*;
use automexia_video::host::*;
use automexia_video::project::*;
use automexia_video::progress::Stage;
use automexia_video::speech::SpeechAudioFrame;
use automexia_video::speech_pipe::SpeechAudioSink;
use automexia_video::model_pack::{WHISPER_CONTRACT,WHISPER_PROCESSING};
use std::{path::{Path,PathBuf},sync::{Arc,atomic::{AtomicUsize,AtomicBool,Ordering}},time::Duration};
fn r(s:&str)->Rational{s.parse().unwrap()}
fn identity()->ModelIdentity {ModelIdentity{id:"fake-transcript-lifecycle".into(),revision:"1".into(),source_revision:"synthetic".into(),manifest_sha256:"b".repeat(64),weights_sha256:"c".repeat(64),contract:WHISPER_CONTRACT.into(),preprocessing:WHISPER_PROCESSING.into(),runtime:ModelRuntime{adapter:"fake-only".into(),artifact_sha256:"d".repeat(64),build_info_sha256:"e".repeat(64)},notices_sha256:"f".repeat(64)}}
fn file()->InputFile {InputFile{canonical_path:std::env::temp_dir().join("transcript-workflow").join("input.mp4"),stamp:FileStamp{size:100,modified_ns:None,sha256:"a".repeat(64),file_id:None}}}
fn project()->Project {let info=automexia_video::media::parse_probe(include_bytes!("fixtures/probe-base.json")).unwrap();let source=ProjectSource::from_probe("source-1",&file(),&info,info.select(StreamSelection::default()).unwrap(),&project_path()).unwrap();Project::new("transcript-workflow",source,ResolvedSettings{workflow:None,preset_name:None,preset_revision:None,render:FrozenRenderSettings::from_options(&RenderOptions::default()).unwrap(),pause_cleanup:None,voice_cleanup:None,voice_enhancement:None,color_correction:None}).unwrap()}
fn project_path()->PathBuf {file().canonical_path.with_file_name("draft.amxv")}
struct Host { changed:Arc<AtomicBool>,runtime_changed:Arc<AtomicBool>,decoded:Arc<AtomicUsize>,gap:bool,stall_runtime:bool }
impl MediaHost for Host {
    fn inspect_input(&self,_:&Path,c:&Cancellation)->Result<InputFile>{c.check()?;Ok(file())}
    fn revalidate_input(&self,_:&InputFile,c:&Cancellation)->Result<()>{c.check()?;if self.changed.load(Ordering::SeqCst){Err(Error::InputChanged)}else{Ok(())}}
    fn runtime_capabilities(&self,c:&Cancellation)->Result<RuntimeCapabilities>{c.check()?;
        if self.stall_runtime {let started=std::time::Instant::now();while started.elapsed()<Duration::from_secs(1){c.check()?;std::thread::sleep(Duration::from_millis(1));}return Err(Error::InvalidOutput("request deadline was not passed to host"));}
        Ok(RuntimeCapabilities{ffmpeg_version:"ffmpeg synthetic test".into(),ffprobe_version:"ffprobe synthetic test".into(),ffmpeg_identity:Some(if self.runtime_changed.load(Ordering::SeqCst){"3"}else{"1"}.repeat(64)),ffprobe_identity:Some("2".repeat(64)),encoders:["pcm_f32le".into()].into_iter().collect(),muxers:["f32le".into()].into_iter().collect(),filters:["pan","aresample","asettb","atrim","aformat","ashowinfo"].into_iter().map(str::to_owned).collect(),..Default::default()})}
    fn run(&self,task:&MediaTask,c:&Cancellation,_:&mut ProgressSink<'_>)->Result<ToolOutput>{c.check()?;match task{MediaTask::Probe{..}=>Ok(ToolOutput{stdout:include_bytes!("fixtures/probe-base.json").to_vec()}),_=>Err(Error::Unsupported("fake host never renders"))}}
    fn stage_output(&self,_:&InputFile,_:&Path,_:&OutputPolicy,_:&Cancellation)->Result<Box<dyn OutputLease>>{panic!("transcription must not publish")}
}
impl SpeechAudioHost for Host {
    fn stream_speech_audio(&self,_:&SpeechScan,c:&Cancellation,sink:&mut SpeechAudioSink<'_>)->Result<()> {
        self.decoded.fetch_add(1,Ordering::SeqCst);
        for i in 0..4 {c.check()?;sink(SpeechAudioFrame{pts:i*8000+if self.gap&&i>0{100}else{0},samples:vec![0.1;8000]})?;}Ok(())
    }
}
struct Provider { id:ModelIdentity,calls:Arc<AtomicUsize>,mode:u8,changed:Arc<AtomicBool>,activation:ModelActivation }
impl TranscriptProvider for Provider {
    fn identity(&self)->&ModelIdentity{if self.mode==5 {panic!("intentional provider identity panic");}&self.id}
    fn revalidate(&self,c:&Cancellation)->Result<()>{c.check()?;if self.mode==4&&self.calls.load(Ordering::SeqCst)>0{Err(Error::ToolIdentityChanged)}else{Ok(())}}
    fn recognize(&self,samples:&[i16],language:&str,_:Duration,c:&Cancellation)->Result<Recognition>{
        c.check()?;assert_eq!(samples.len(),32000);assert_eq!(language,"en");self.calls.fetch_add(1,Ordering::SeqCst);
        if self.mode==1{panic!("intentional provider panic");}if self.mode==2{self.activation.revoke();}if self.mode==3{self.changed.store(true,Ordering::SeqCst);}
        Ok(Recognition{language:"en".into(),words:vec![RecognizedWord{text:"Hello.".into(),range:TimeRange::new(r("1/10"),r("1")).unwrap(),confidence:Some(0.9)}]})
    }
}
fn setup(mode:u8,gap:bool)->(VideoExtension<Host>,Provider,TranscriptRequest){let changed=Arc::new(AtomicBool::new(false));let activation=ModelActivation::selected(identity()).unwrap();let provider=Provider{id:identity(),calls:Arc::new(AtomicUsize::new(0)),mode,changed:changed.clone(),activation};let host=Host{changed,runtime_changed:Arc::new(AtomicBool::new(false)),decoded:Arc::new(AtomicUsize::new(0)),gap,stall_runtime:mode==6};let video=VideoExtension::new(host,VideoSettings::default()).unwrap();let mut request=TranscriptRequest::new(project_path());request.settings.language="en".into();(video,provider,request)}
#[test]fn report_survives_successful_job_and_applies_once(){let (video,provider,request)=setup(0,false);let mut p=project();let before=p.to_json().unwrap();let report=video.transcribe(&p,&request,&provider,&provider.activation,&Cancellation::new(),&mut |_|{}).unwrap();assert_eq!(p.to_json().unwrap(),before);report.apply(&mut p).unwrap();assert_eq!(p.transcript.as_ref().unwrap().words()[0].text,"Hello.");assert_eq!(report.apply(&mut p),Err(Error::StaleReview));}
#[test]fn project_change_invalidates_completed_report(){let (video,provider,request)=setup(0,false);let mut p=project();let report=video.transcribe(&p,&request,&provider,&provider.activation,&Cancellation::new(),&mut |_|{}).unwrap();p.set_clip_locked("clip-1",true).unwrap();assert_eq!(report.apply(&mut p),Err(Error::StaleReview));}
#[test]fn revoking_activation_invalidates_completed_report(){let (video,provider,request)=setup(0,false);let mut p=project();let report=video.transcribe(&p,&request,&provider,&provider.activation,&Cancellation::new(),&mut |_|{}).unwrap();provider.activation.revoke();assert!(matches!(report.apply(&mut p),Err(Error::Cancelled)));}
#[test]fn disabling_extension_invalidates_completed_report(){let (video,provider,request)=setup(0,false);let mut p=project();let report=video.transcribe(&p,&request,&provider,&provider.activation,&Cancellation::new(),&mut |_|{}).unwrap();video.disable().unwrap();assert!(matches!(report.apply(&mut p),Err(Error::Cancelled)));}
#[test]fn cancellation_before_analysis_never_calls_provider(){let (video,provider,request)=setup(0,false);let cancel=Cancellation::new();cancel.cancel();assert!(video.transcribe(&project(),&request,&provider,&provider.activation,&cancel,&mut |_|{}).is_err());assert_eq!(provider.calls.load(Ordering::SeqCst),0);}
#[test]fn revoked_activation_never_decodes(){let (video,provider,request)=setup(0,false);provider.activation.revoke();assert!(video.transcribe(&project(),&request,&provider,&provider.activation,&Cancellation::new(),&mut |_|{}).is_err());assert_eq!(video.host().decoded.load(Ordering::SeqCst),0);}
#[test]fn invalid_channel_fails_before_decode(){let (video,provider,mut request)=setup(0,false);request.settings.analysis_channel=7;assert!(video.transcribe(&project(),&request,&provider,&provider.activation,&Cancellation::new(),&mut |_|{}).is_err());assert_eq!(video.host().decoded.load(Ordering::SeqCst),0);}
#[test]fn provider_panic_becomes_structured_error(){let (video,provider,request)=setup(1,false);assert!(matches!(video.transcribe(&project(),&request,&provider,&provider.activation,&Cancellation::new(),&mut |_|{}),Err(Error::CallbackPanicked)));}
#[test]fn provider_identity_panic_becomes_structured_error(){let (video,provider,request)=setup(5,false);assert!(matches!(video.transcribe(&project(),&request,&provider,&provider.activation,&Cancellation::new(),&mut |_|{}),Err(Error::CallbackPanicked)));}
#[test]fn revocation_during_inference_discards_result(){let (video,provider,request)=setup(2,false);assert!(matches!(video.transcribe(&project(),&request,&provider,&provider.activation,&Cancellation::new(),&mut |_|{}),Err(Error::Cancelled)));}
#[test]fn source_change_during_inference_discards_result(){let (video,provider,request)=setup(3,false);assert!(matches!(video.transcribe(&project(),&request,&provider,&provider.activation,&Cancellation::new(),&mut |_|{}),Err(Error::InputChanged)));}
#[test]fn changed_provider_runtime_discards_result(){let (video,provider,request)=setup(4,false);assert!(matches!(video.transcribe(&project(),&request,&provider,&provider.activation,&Cancellation::new(),&mut |_|{}),Err(Error::ToolIdentityChanged)));}
#[test]fn decode_gaps_never_get_transcribed_as_continuous_speech(){let (video,provider,request)=setup(0,true);assert!(video.transcribe(&project(),&request,&provider,&provider.activation,&Cancellation::new(),&mut |_|{}).is_err());assert_eq!(provider.calls.load(Ordering::SeqCst),0);}
#[test]fn progress_cancellation_stops_before_inference(){let (video,provider,request)=setup(0,false);let cancel=Cancellation::new();let trigger=cancel.clone();assert!(video.transcribe(&project(),&request,&provider,&provider.activation,&cancel,&mut |p|{if p.stage==Stage::Transcribing{trigger.cancel();}}).is_err());assert_eq!(provider.calls.load(Ordering::SeqCst),0);}
#[test]fn request_deadline_reaches_shared_runtime_capability_hook(){let (video,provider,mut request)=setup(6,false);request.timeout=Duration::from_millis(20);let started=std::time::Instant::now();assert!(matches!(video.transcribe(&project(),&request,&provider,&provider.activation,&Cancellation::new(),&mut |_|{}),Err(Error::Timeout)));assert!(started.elapsed()<Duration::from_secs(1));assert_eq!(provider.calls.load(Ordering::SeqCst),0);}
#[test]fn completed_report_is_not_owned_by_request_deadline(){let (video,provider,mut request)=setup(0,false);request.timeout=Duration::from_secs(1);let mut p=project();let report=video.transcribe(&p,&request,&provider,&provider.activation,&Cancellation::new(),&mut |_|{}).unwrap();std::thread::sleep(Duration::from_millis(1100));report.apply(&mut p).unwrap();}
