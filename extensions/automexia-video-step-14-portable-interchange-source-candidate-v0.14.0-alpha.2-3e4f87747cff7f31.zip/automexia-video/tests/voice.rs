//! Step 5 tests of actual Rust domain methods. Run with Cargo; no FFmpeg needed.
use automexia_video::*;
use automexia_video::host::{FileStamp,InputFile,RuntimeCapabilities};
use automexia_video::media::parse_probe;
use automexia_video::plan::{build_edited_plan,RenderOptions};
use automexia_video::project::{ProjectSource,ResolvedSettings,FrozenRenderSettings};
use automexia_video::voice::{ChannelPreflight,PcmPreflight,resolve_stages};
use automexia_video::voice_render::*;
use std::{path::PathBuf,time::Duration};
fn r(s:&str)->Rational{s.parse().unwrap()}
fn path()->PathBuf{std::env::temp_dir().join("voice-tests").join("project.amxv")}
fn input()->InputFile{InputFile{canonical_path:path().with_file_name("source.mov"),stamp:FileStamp{size:100,modified_ns:None,sha256:"a".repeat(64),file_id:None}}}
fn project()->Project {
    let m=parse_probe(include_bytes!("fixtures/probe-base.json")).unwrap();
    let source=ProjectSource::from_probe("source-1",&input(),&m,m.select(StreamSelection::default()).unwrap(),&path()).unwrap();
    Project::new("voice-tests",source,ResolvedSettings{ workflow:None,preset_name:None,preset_revision:None,pause_cleanup:None,voice_cleanup:None,voice_enhancement:None,color_correction:None,render:FrozenRenderSettings::from_options(&RenderOptions::default()).unwrap()}).unwrap()
}
fn evidence()->AudioPreflight {AudioPreflight{sample_rate:48000,samples_per_channel:96000,complete_windows:10,
    channels:vec![ChannelPreflight{rms_dbfs:Some(-20.0),peak_dbfs:Some(-10.0),dc_offset:0.0,near_full_scale_samples:0,longest_full_scale_run:0,low_band_fraction:0.01,quiet_window_floor_dbfs:Some(-50.0),hum_50_fraction:0.0,hum_60_fraction:0.0}],channel_imbalance_db:None,warnings:vec![]}}
fn dialogue()->VoiceSettings {VoiceSettings{content:AudioContent::Dialogue,..VoiceSettings::clean()}}
fn caps()->RuntimeCapabilities {RuntimeCapabilities{ffmpeg_version:"ffmpeg version 7.1.5".into(),
    encoders:["libx264","aac","pcm_s16le","pcm_f32le","pcm_s24le"].map(str::to_owned).into_iter().collect(),
    muxers:["mp4","null","f32le","wav"].map(str::to_owned).into_iter().collect(),
    filters:["settb","setpts","select","asetpts","aresample","apad","atrim","anull","asplit","concat","scale","setsar","asettb","aformat","loudnorm","volume","highpass","bandreject","afftdn","equalizer","deesser","acompressor","alimiter"].map(str::to_owned).into_iter().collect(),
    bitstream_filters:["setts".into()].into_iter().collect(),supports_demux_time_base:true,..Default::default()}}
fn configured(settings:VoiceSettings)->Project {let mut p=project();VoiceReport::new(&p,settings,Some(evidence())).unwrap().apply(&mut p).unwrap();p}
fn voice(settings:VoiceSettings)->VoiceRender {VoiceRender::from_project(&configured(settings),&caps()).unwrap().unwrap()}
fn measurement(i:Option<f64>,tp:Option<f64>)->LoudnessMeasurement{LoudnessMeasurement{integrated_lufs:i,true_peak_dbtp:tp,range_lu:2.0,threshold_lufs:-40.0}}
fn scan<F:Fn(usize,usize)->f32>(rate:u32,channels:usize,n:usize,sample:F)->AudioPreflight {
    let mut a=PcmPreflight::new(rate,channels,4).unwrap();let c=Cancellation::new();
    let mut bytes=Vec::new();for t in 0..n{for ch in 0..channels{bytes.extend_from_slice(&sample(t,ch).to_le_bytes());}}
    for chunk in bytes.chunks(4093){a.feed(chunk,&c).unwrap();}a.finish(&c).unwrap()
}
#[test]fn presets_validate_and_have_distinct_loudness_targets(){for s in [VoiceSettings::clean(),VoiceSettings::social(),VoiceSettings::podcast(),VoiceSettings::off()]{s.validate().unwrap();}assert_ne!(VoiceSettings::social().target_lufs,VoiceSettings::podcast().target_lufs);}
#[test]fn serialized_settings_do_not_adopt_missing_defaults(){let mut s=serde_json::to_value(dialogue()).unwrap();s.as_object_mut().unwrap().remove("target_lufs");assert!(serde_json::from_value::<VoiceSettings>(s).is_err());}
#[test]fn unknown_setting_rejected(){let mut s=serde_json::to_value(dialogue()).unwrap();s["shell"]="bad".into();assert!(serde_json::from_value::<VoiceSettings>(s).is_err());}
#[test]fn nonfinite_and_out_of_range_settings_rejected(){for v in [f64::NAN,f64::INFINITY,0.0,-50.0]{let mut s=dialogue();s.target_lufs=v;assert!(s.validate().is_err());}}
#[test]fn invalid_modes_hum_and_limits_rejected(){let mut s=dialogue();s.hum_hz=Some(55);assert!(s.validate().is_err());s=dialogue();s.max_analysis_seconds=0;assert!(s.validate().is_err());s=dialogue();s.noise_reduction_db=40;assert!(s.validate().is_err());}
#[test]fn global_off_needs_no_preflight(){assert!(!resolve_stages(&VoiceSettings::off(),None).unwrap().active());}
#[test]fn unknown_clean_audio_is_preserved(){assert!(!resolve_stages(&VoiceSettings::clean(),Some(&evidence())).unwrap().active());}
#[test]fn dialogue_auto_does_not_guess_eq_deessing_or_noise(){let stages=resolve_stages(&dialogue(),Some(&evidence())).unwrap();assert!(stages.loudness&&stages.limiter);assert!(!stages.equalizer&&!stages.deesser&&!stages.denoise&&!stages.compressor);}
#[test]fn auto_noise_requires_user_confirmation(){let mut s=dialogue();s.noise_confirmed=true;assert!(resolve_stages(&s,Some(&evidence())).unwrap().denoise);}
#[test]fn music_auto_is_not_declared_dialogue(){let mut s=dialogue();s.content=AudioContent::MixedMusic;s.noise_confirmed=true;assert!(!resolve_stages(&s,Some(&evidence())).unwrap().active());}
#[test]fn explicit_on_respects_per_stage_off(){let mut s=dialogue();s.mode=TreatmentMode::On;s.dc=TreatmentMode::Off;let stages=resolve_stages(&s,Some(&evidence())).unwrap();assert!(!stages.dc&&stages.rumble&&stages.denoise);}
#[test]fn hum_on_requires_frequency_or_evidence(){let mut s=dialogue();s.hum=TreatmentMode::On;assert!(resolve_stages(&s,Some(&evidence())).is_err());s.hum_hz=Some(60);assert_eq!(resolve_stages(&s,Some(&evidence())).unwrap().hum_hz,Some(60));}
#[test]fn measured_hum_is_notched_only_for_dialogue(){let mut p=evidence();p.channels[0].hum_50_fraction=0.9;assert_eq!(resolve_stages(&dialogue(),Some(&p)).unwrap().hum_hz,Some(50));assert_eq!(resolve_stages(&VoiceSettings::clean(),Some(&p)).unwrap().hum_hz,None);}
#[test]fn conflicting_hum_evidence_is_preserved(){let mut p=evidence();p.channels[0].hum_50_fraction=0.9;p.channels[0].hum_60_fraction=0.9;assert_eq!(resolve_stages(&dialogue(),Some(&p)).unwrap().hum_hz,None);}
#[test]fn explicit_wrong_auto_mains_does_not_override_measurement(){let mut p=evidence();p.channels[0].hum_50_fraction=0.9;let mut s=dialogue();s.hum_hz=Some(60);assert_eq!(resolve_stages(&s,Some(&p)).unwrap().hum_hz,None);}
#[test]fn silence_has_no_treatment_even_on(){let p=scan(8000,1,8000,|_,_|0.0);let mut s=dialogue();s.mode=TreatmentMode::On;assert!(!resolve_stages(&s,Some(&p)).unwrap().active());}
#[test]fn preflight_rejects_nan_and_physical_inconsistency(){let mut p=evidence();p.channels[0].dc_offset=1.0;assert!(p.validate().is_err());p=evidence();p.channels[0].peak_dbfs=Some(f64::NAN);assert!(p.validate().is_err());}
#[test]fn preflight_window_count_cannot_be_forged(){let mut p=evidence();p.complete_windows=999;assert!(p.validate().is_err());}
#[test]fn preflight_rms_cannot_exceed_peak(){let mut p=evidence();p.channels[0].rms_dbfs=Some(-1.0);assert!(p.validate().is_err());}
#[test]fn near_full_scale_count_needs_corresponding_peak(){let mut p=evidence();p.channels[0].near_full_scale_samples=12;assert!(p.validate().is_err());}
#[test]fn malformed_pcm_poisoning_rejects_valid_prefix(){let mut p=PcmPreflight::new(8000,1,1).unwrap();let c=Cancellation::new();assert!(p.feed(&f32::NAN.to_le_bytes(),&c).is_err());assert!(p.feed(&0.1f32.to_le_bytes(),&c).is_err());assert!(p.finish(&c).is_err());}
#[test]fn incomplete_pcm_frame_rejected(){let mut p=PcmPreflight::new(8000,2,1).unwrap();let c=Cancellation::new();p.feed(&0.1f32.to_le_bytes(),&c).unwrap();assert!(p.finish(&c).is_err());}
#[test]fn empty_pcm_scan_rejected(){assert!(PcmPreflight::new(8000,1,1).unwrap().finish(&Cancellation::new()).is_err());}
#[test]fn oversized_pcm_chunk_rejected(){let mut p=PcmPreflight::new(8000,1,1).unwrap();assert!(p.feed(&vec![0;1024*1024+1],&Cancellation::new()).is_err());}
#[test]fn sample_count_limit_and_cancel_are_enforced(){let c=Cancellation::new();let mut p=PcmPreflight::new(8000,1,1).unwrap();assert!(p.feed(&vec![0;8001*4],&c).is_err());let mut p=PcmPreflight::new(8000,1,1).unwrap();c.cancel();assert!(matches!(p.feed(&[0;4],&c),Err(Error::Cancelled)));}
#[test]fn invalid_scan_dimensions_rejected(){for (r,c) in [(0,1),(48000,0),(48000,9),(192000,1)]{assert!(PcmPreflight::new(r,c,1).is_err());}}
#[test]fn constant_pcm_records_rms_dc_and_count(){let p=scan(8000,1,8000,|_,_|0.125);assert_eq!(p.samples_per_channel,8000);assert!((p.channels[0].dc_offset-0.125).abs()<1e-6);assert!((p.channels[0].rms_dbfs.unwrap()+18.0618).abs()<0.001);}
#[test]fn chunk_boundaries_do_not_change_statistics(){let p=scan(8000,2,8000,|t,c|if (t+c)%2==0{0.1}else{-0.1});assert!((p.channels[0].rms_dbfs.unwrap()+20.0).abs()<1e-5);assert_eq!(p.channels[0],p.channels[1]);}
#[test]fn opposite_phase_stereo_not_downmixed(){let p=scan(8000,2,8000,|t,c|{let v=(t as f32*0.3).sin()*0.1;if c==0{v}else{-v}});assert!(p.channels.iter().all(|c|c.rms_dbfs.unwrap()>-30.0));}
#[test]fn missing_channel_audio_warns_without_balancing(){let p=scan(8000,2,8000,|_,c|if c==0{0.1}else{0.0});assert!(p.warnings.iter().any(|w|w.contains("Channel levels")));assert_eq!(p.channels[1].peak_dbfs,None);}
#[test]fn input_clipping_warning_does_not_claim_reconstruction(){let p=scan(8000,1,8000,|_,_|1.0);assert_eq!(p.channels[0].near_full_scale_samples,8000);assert_eq!(p.channels[0].longest_full_scale_run,8000);assert!(p.warnings.iter().any(|w|w.contains("cannot reconstruct")));}
#[test]fn harmonic_goertzel_detects_stationary_50_and_60(){for hz in [50.0,60.0]{let p=scan(8000,1,16000,|n,_|{let t=n as f64/8000.0;(0.05*(std::f64::consts::TAU*hz*t).sin()+0.03*(std::f64::consts::TAU*2.0*hz*t).sin()+0.1*(std::f64::consts::TAU*440.0*t).sin()) as f32});let c=&p.channels[0];assert!(if hz==50.0{c.hum_50_fraction}else{c.hum_60_fraction}>0.7);}}
#[test]fn pure_unrelated_tone_is_not_hum(){let p=scan(8000,1,16000,|n,_|(0.1*(std::f64::consts::TAU*440.0*n as f64/8000.0).sin()) as f32);assert_eq!(p.channels[0].hum_50_fraction,0.0);assert_eq!(p.channels[0].hum_60_fraction,0.0);}
#[test]fn report_apply_is_explicit_and_stale_guarded(){let mut p=project();let before=p.to_json().unwrap();let report=VoiceReport::new(&p,dialogue(),Some(evidence())).unwrap();assert_eq!(p.to_json().unwrap(),before);report.apply(&mut p).unwrap();assert!(p.settings.voice_cleanup.is_some());assert!(matches!(report.apply(&mut p),Err(Error::StaleReview)));}
#[test]fn malformed_voice_profile_does_not_partially_change_project(){let mut p=project();let before=p.to_json().unwrap();let mut v=VoiceReport::new(&p,dialogue(),Some(evidence())).unwrap().cleanup().clone();v.source_sha256="b".repeat(64);assert!(p.set_voice_cleanup(Some(v)).is_err());assert_eq!(p.to_json().unwrap(),before);}
#[test]fn source_stream_and_channel_changes_invalidate_profile(){for mode in 0..3{let mut p=configured(dialogue());match mode{0=>p.settings.voice_cleanup.as_mut().unwrap().stream_index=2,1=>p.sources[0].media.audio.as_mut().unwrap().sample_rate=Some(44100),_=>p.sources[0].media.audio.as_mut().unwrap().channels=Some(2)}assert!(p.validate().is_err());}}
#[test]fn controls_roundtrip_without_global_preset_lookup(){let p=configured(dialogue());let q=Project::from_json(&p.to_json().unwrap()).unwrap();assert_eq!(p.settings.voice_cleanup,q.settings.voice_cleanup);assert_eq!(q.schema_version,automexia_video::project::PROJECT_VERSION);}
#[test]fn remove_profile_restores_original_edit_timeline(){let mut p=configured(dialogue());let t=p.timeline().unwrap().duration;p.set_voice_cleanup(None).unwrap();assert_eq!(p.timeline().unwrap().duration,t);}
#[test]fn reconfiguration_preserves_observations_and_applies_explicit_off(){let p=configured(dialogue());let v=p.settings.voice_cleanup.unwrap();let q=v.reconfigure(VoiceSettings::off()).unwrap();assert_eq!(v.preflight,q.preflight);assert!(!q.active());}
#[test]fn stage_flags_cannot_contradict_settings(){let mut p=configured(dialogue());p.settings.voice_cleanup.as_mut().unwrap().stages.equalizer=true;assert!(p.validate().is_err());}
#[test]fn schema_2_migrates_without_activating_audio(){let mut v=serde_json::to_value(project()).unwrap();v["schema_version"]=2.into();v["settings"].as_object_mut().unwrap().remove("voice_cleanup");let p=Project::from_json(&serde_json::to_vec(&v).unwrap()).unwrap();assert_eq!(p.schema_version,automexia_video::project::PROJECT_VERSION);assert!(p.settings.voice_cleanup.is_none());}
#[test]fn schema_2_cannot_smuggle_voice_settings(){let mut v=serde_json::to_value(configured(dialogue())).unwrap();v["schema_version"]=2.into();assert!(Project::from_json(&serde_json::to_vec(&v).unwrap()).is_err());}
#[test]fn future_schema_and_duplicate_voice_fields_rejected(){let mut v=serde_json::to_value(project()).unwrap();v["schema_version"]=(automexia_video::project::PROJECT_VERSION+1).into();assert!(Project::from_json(&serde_json::to_vec(&v).unwrap()).is_err());let mut s=String::from_utf8(configured(dialogue()).to_json().unwrap()).unwrap();s=s.replacen("\"voice_cleanup\":", "\"voice_cleanup\":null,\"voice_cleanup\":",1);assert!(Project::from_json(s.as_bytes()).is_err());}
#[test]fn review_audio_apply_invalidates_old_view(){let p=project();let report=VoiceReport::new(&p,dialogue(),Some(evidence())).unwrap();let mut review=ReviewSession::new(p).unwrap();let token=review.snapshot().unwrap().token;let result=review.apply_voice_report(&token,&report).unwrap();assert!(result.voice_cleanup.is_some());assert!(review.apply_voice_report(&token,&report).is_err());}
#[test]fn parser_accepts_infinite_silence_only_as_absent_levels(){let m=LoudnessMeasurement::parse(br#"{"input_i":"-inf","input_tp":"-inf","input_lra":"0","input_thresh":"-70"}"#).unwrap();assert_eq!(m.integrated_lufs,None);assert_eq!(m.true_peak_dbtp,None);}
#[test]fn parser_handles_filename_braces_before_final_object(){let m=LoudnessMeasurement::parse(b"Input source {voice}.mov\n{\"input_i\":\"-20\",\"input_tp\":\"-8\",\"input_lra\":\"1\",\"input_thresh\":\"-30\"}\n").unwrap();assert_eq!(m.integrated_lufs,Some(-20.0));}
#[test]fn parser_rejects_nan_missing_duplicate_unknown_or_unclosed(){for bytes in [b"{".as_slice(),b"} {",br#"{"input_i":"NaN","input_tp":"0","input_lra":"0","input_thresh":"-30"}"#,br#"{"input_i":"-20","input_i":"-21","input_tp":"0","input_lra":"0","input_thresh":"-30"}"#,br#"{"input_i":"-20","input_tp":"0","input_lra":"0","input_thresh":"-30","other":"0"}"#,br#"{"input_i":"-20"}"#]{assert!(LoudnessMeasurement::parse(bytes).is_err());}}
#[test]fn parser_enforces_byte_limit(){assert!(LoudnessMeasurement::parse(&vec![b' ';MAX_LOUDNESS_BYTES+1]).is_err());}
#[test]fn linear_gain_is_measured_and_bounded(){let mut v=voice(dialogue());v.resolve_gain(measurement(Some(-24.0),Some(-20.0))).unwrap();assert!((v.gain_decision().unwrap().gain_db-6.0).abs()<1e-9);assert!(!v.gain_decision().unwrap().limiter_applied);}
#[test]fn extreme_low_level_never_gets_unlimited_gain(){let mut v=voice(dialogue());v.resolve_gain(measurement(Some(-60.0),Some(-50.0))).unwrap();assert_eq!(v.gain_decision().unwrap().gain_db,12.0);assert!(v.gain_decision().unwrap().gain_limited);}
#[test]fn peak_headroom_takes_precedence_over_loudness_target(){let mut v=voice(dialogue());v.resolve_gain(measurement(Some(-24.0),Some(-2.0))).unwrap();assert!(v.gain_decision().unwrap().gain_db<0.0);}
#[test]fn small_auto_loudness_difference_is_bypassed(){let mut v=voice(dialogue());v.resolve_gain(measurement(Some(-18.2),Some(-12.0))).unwrap();assert_eq!(v.gain_decision().unwrap().gain_db,0.0);}
#[test]fn absent_integrated_loudness_does_not_boost(){let mut v=voice(dialogue());v.resolve_gain(measurement(None,None)).unwrap();assert_eq!(v.gain_decision().unwrap().gain_db,0.0);}
#[test]fn measure_is_required_before_final_audio_graph(){let v=voice(dialogue());assert!(v.final_filters(r("2")).is_err());}
#[test]fn limiter_has_no_makeup_and_compensates_lookahead(){let mut s=dialogue();s.limiter=TreatmentMode::On;let mut v=voice(s);v.resolve_gain(measurement(Some(-24.0),Some(-2.0))).unwrap();let f=v.final_filters(r("2")).unwrap();assert!(f.contains("level=0:latency=1"));assert!(f.contains("aresample=48000"));assert!(f.contains("atrim=end_sample=96000"));}
#[test]fn lossy_peak_correction_is_explicit_and_bounded(){let mut v=voice(dialogue());v.resolve_gain(measurement(Some(-18.0),Some(-3.0))).unwrap();assert!(v.correct_encoded_peak(&measurement(Some(-18.0),Some(-1.0))).unwrap());assert_eq!(v.gain_decision().unwrap().correction_passes,1);assert!(v.gain_decision().unwrap().gain_db< -0.79);assert!(v.correct_encoded_peak(&measurement(Some(-18.0),Some(-1.0))).unwrap());assert!(v.correct_encoded_peak(&measurement(Some(-18.0),Some(-1.0))).is_err());}
#[test]fn encoded_peak_failure_is_never_accepted_as_report(){let mut v=voice(dialogue());v.resolve_gain(measurement(Some(-18.0),Some(-3.0))).unwrap();assert!(v.finish_report(measurement(Some(-18.0),Some(0.0))).is_err());}
#[test]fn correction_cannot_exceed_reviewed_attenuation(){let mut s=dialogue();s.max_attenuation_db=0.0;let mut v=voice(s);v.resolve_gain(measurement(Some(-18.0),Some(-3.0))).unwrap();assert!(v.correct_encoded_peak(&measurement(Some(-18.0),Some(0.0))).is_err());}
#[test]fn qualified_layouts_never_default_multichannel_to_stereo(){assert_eq!(qualified_layout(2,None).unwrap(),"stereo");assert_eq!(qualified_layout(6,Some("5.1")).unwrap(),"5.1");assert!(qualified_layout(6,None).is_err());assert!(qualified_layout(2,Some("5.1")).is_err());assert!(qualified_layout(6,Some("5.1;bad")).is_err());}
#[test]fn denoise_delay_matches_hop_contract(){assert_eq!(afftdn_delay(48000).unwrap(),1200);assert_eq!(afftdn_delay(44100).unwrap(),1102);assert_eq!(afftdn_delay(96000).unwrap(),2400);assert!(afftdn_delay(0).is_err());}
#[test]fn unqualified_denoiser_version_is_not_assumed_compatible(){assert!(afftdn_timing_qualified("ffmpeg version 7.1.5-0"));assert!(!afftdn_timing_qualified("ffmpeg version 8.0"));assert!(!afftdn_timing_qualified("ffmpeg version 7.10"));let mut s=dialogue();s.denoise=TreatmentMode::On;let mut c=caps();c.ffmpeg_version="ffmpeg version 8.0".into();assert!(VoiceRender::from_project(&configured(s),&c).is_err());}
#[test]fn prefilters_preserve_origin_and_flush_denoiser_tail(){let mut s=dialogue();s.dc=TreatmentMode::On;s.denoise=TreatmentMode::On;let v=voice(s);let f=v.pre_filters().unwrap();assert!(f.starts_with("highpass="));assert!(f.contains("apad=pad_len=1200"));assert!(f.contains("atrim=start_sample=1200,asetpts=PTS-1200/(48000*TB)"));assert!(!f.contains("STARTPTS"));}
#[test]fn runtime_needs_all_selected_filters_before_processing(){let p=configured(dialogue());let mut c=caps();c.filters.remove("loudnorm");assert!(VoiceRender::from_project(&p,&c).is_err());c=caps();c.filters.remove("volume");assert!(VoiceRender::from_project(&p,&c).is_err());}
#[test]fn off_plan_uses_old_audio_graph(){let p=project();let m=parse_probe(include_bytes!("fixtures/probe-base.json")).unwrap();let plan=build_edited_plan(&p,"main",&m,&caps()).unwrap();let a=plan.voice_audio_graph(true).unwrap();assert!(!a.contains("loudnorm")&&!a.contains("volume")&&!a.contains("highpass"));}
#[test]fn pre_processing_precedes_cut_and_post_processing_follows_it(){let mut s=dialogue();s.dc=TreatmentMode::On;s.equalizer=TreatmentMode::On;let p=configured(s);let m=parse_probe(include_bytes!("fixtures/probe-base.json")).unwrap();let plan=build_edited_plan(&p,"main",&m,&caps()).unwrap();let g=plan.voice_audio_graph(false).unwrap();assert!(g.find("highpass").unwrap()<g.find("atrim=start_sample").unwrap());assert!(g.find("equalizer").unwrap()>g.find("atrim=start_sample").unwrap());}
#[test]fn typed_pcm_plan_selects_stream_without_downmix_or_shell(){let p=project();let plan=VoiceScan::new(&p,input(),10,Duration::from_secs(30)).unwrap();let a=plan.arguments().unwrap();assert!(a.iter().any(|s|s=="0:1"));assert!(!a.iter().any(|s|s=="-ac"));assert!(!a.iter().any(|s|s=="-ar"));assert!(a.iter().any(|s|s=="pcm_f32le"));}
#[test]fn typed_pcm_source_identity_and_limits_checked(){let p=project();let mut f=input();f.stamp.sha256="b".repeat(64);assert!(VoiceScan::new(&p,f,10,Duration::from_secs(30)).is_err());assert!(VoiceScan::new(&p,input(),1,Duration::from_secs(30)).is_err());}
#[test]fn typed_stem_rejects_source_alias_and_uses_explicit_wav_muxer(){let p=project();let m=parse_probe(include_bytes!("fixtures/probe-base.json")).unwrap();let plan=build_edited_plan(&p,"main",&m,&caps()).unwrap();let task=AudioTask::RenderStem{input:input(),plan:plan.clone(),output:input().canonical_path,timeout:Duration::from_secs(30)};assert!(task.arguments().is_err());let task=AudioTask::RenderStem{input:input(),plan,output:path().with_extension("tmp"),timeout:Duration::from_secs(30)};let a=task.arguments().unwrap();assert!(a.iter().any(|x|x=="pcm_s24le")&&a.iter().any(|x|x=="wav"));}

#[test]
fn saved_audio_float_parameters_and_observations_preserve_exact_bits() {
    // These adjacent finite values exercise decimal parsing near a rounding
    // boundary; project save/load must not silently change a review digest.
    let mut settings=dialogue();
    settings.deess_intensity=f64::from_bits(0x3fb999999999999a+1);
    settings.codec_headroom_db=f64::from_bits(0x3fe6666666666666+1);
    let mut evidence=evidence();
    evidence.channels[0].dc_offset=f64::from_bits(0x3e7ad7f29abcaf49);
    let mut p=project();VoiceReport::new(&p,settings,Some(evidence)).unwrap().apply(&mut p).unwrap();
    let bytes=p.to_json().unwrap();let loaded=Project::from_json(&bytes).unwrap();
    assert_eq!(p.settings.voice_cleanup,loaded.settings.voice_cleanup);
    assert_eq!(p.decision_digest().unwrap(),loaded.decision_digest().unwrap());
    assert_eq!(loaded.to_json().unwrap(),bytes);
}
#[test]
fn audio_only_plan_accepts_hdr_and_needs_no_video_encoder_or_filter() {
    let mut p=project();
    let video=&mut p.sources[0].media.video;video.pixel_format=Some("yuv420p10le".into());video.bits_per_raw_sample=Some(10);video.color_transfer=Some("smpte2084".into());
    let mut runtime=caps();runtime.encoders.retain(|n|n.starts_with("pcm_"));runtime.muxers.retain(|n|n=="wav"||n=="null"||n=="f32le");
    runtime.filters.retain(|n|!["settb","setpts","select","scale","setsar"].contains(&n.as_str()));runtime.bitstream_filters.clear();runtime.supports_demux_time_base=false;
    let plan=automexia_video::plan::build_audio_plan(&p,"main",&p.sources[0].media.as_media_info(),&runtime).unwrap();
    assert!(plan.voice_audio_graph(true).unwrap().contains("[aout]"));
    assert!(plan.arguments(&input().canonical_path,&path().with_extension("mp4")).is_err());
}

#[test]
fn audio_only_plan_ignores_pending_visual_only_presentation(){
    let mut p=project();p.set_presentation("main",Some(automexia_video::presentation::PresentationSettings::default())).unwrap();
    assert_eq!(p.variants[0].presentation.as_ref().unwrap().disposition,Disposition::NeedsReview);
    assert!(automexia_video::plan::build_audio_plan(&p,"main",&p.sources[0].media.as_media_info(),&caps()).is_ok());
}
