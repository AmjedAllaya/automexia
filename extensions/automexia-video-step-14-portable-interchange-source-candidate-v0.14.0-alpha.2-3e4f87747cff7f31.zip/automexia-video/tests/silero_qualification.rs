//! Opt-in REAL selected-model tests. Missing environment/assets FAIL, never skip.
//! These validate inference contracts, not linguistic accuracy or speech retention.
use automexia_video::*;
use automexia_video::speech::*;
use automexia_video::silero_onnx::*;
use std::{path::PathBuf,time::Duration,sync::Mutex};
static SERIAL:Mutex<()>=Mutex::new(());
fn path(name:&str)->PathBuf{PathBuf::from(std::env::var_os(name).unwrap_or_else(||panic!("required selected asset: {name}")))}
fn provider()->SileroCpuProvider{
 let c=Cancellation::new();let pack=read_selected_pack(&path("VIDEO_MODEL_MANIFEST"),&path("VIDEO_MODEL_WEIGHTS"),
  &path("VIDEO_MODEL_NOTICES"),&std::env::var("VIDEO_MODEL_MANIFEST_SHA256").expect("required reviewed manifest digest"),&c).unwrap();
 SileroCpuProvider::new(pack,path("VIDEO_ORT_LIBRARY"),Duration::from_secs(10)).unwrap()
}
#[test]fn selected_model_outputs_finite_state_and_probability(){
 let _lock=SERIAL.lock().unwrap();let p=provider();let c=Cancellation::new();let mut session=p.open(&c).unwrap();
 let mut state=[0.;SPEECH_STATE];
 for _ in 0..8{let output=session.infer(&[0.;SPEECH_INPUT],&state,&c).unwrap();assert!((0.0..=1.0).contains(&output.probability));assert!(output.state.iter().all(|v|v.is_finite()));state=output.state;}
}
#[test]fn loaded_model_is_released_for_next_request(){
 let _lock=SERIAL.lock().unwrap();let p=provider();let c=Cancellation::new();let first=p.open(&c).unwrap();
 assert!(matches!(p.open(&c),Err(Error::Busy)));drop(first);assert!(p.open(&c).is_ok());
}
#[test]fn cancelled_request_does_not_load_or_infer(){
 let _lock=SERIAL.lock().unwrap();let p=provider();let c=Cancellation::new();c.cancel();assert!(matches!(p.open(&c),Err(Error::Cancelled)));
}
#[test]fn new_session_resets_recurrent_state(){
 let _lock=SERIAL.lock().unwrap();let p=provider();let c=Cancellation::new();let input=[0.001;SPEECH_INPUT];
 let mut first=p.open(&c).unwrap();let a=first.infer(&input,&[0.;SPEECH_STATE],&c).unwrap();drop(first);
 let mut second=p.open(&c).unwrap();let b=second.infer(&input,&[0.;SPEECH_STATE],&c).unwrap();
 assert!((a.probability-b.probability).abs()<1e-6);assert!(a.state.iter().zip(b.state).all(|(x,y)|(*x-y).abs()<1e-6));
}
#[test]fn invalid_input_is_rejected_and_poisoned(){
 let _lock=SERIAL.lock().unwrap();let p=provider();let c=Cancellation::new();let mut s=p.open(&c).unwrap();
 let mut input=[0.;SPEECH_INPUT];input[70]=f32::NAN;assert!(s.infer(&input,&[0.;SPEECH_STATE],&c).is_err());
 assert!(s.infer(&[0.;SPEECH_INPUT],&[0.;SPEECH_STATE],&c).is_err());
}
