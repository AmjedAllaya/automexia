#![cfg(feature="face-onnx")]
//! Explicit actual-model acceptance inputs; never silently pass without them.
use automexia_video::{Cancellation,FaceDetector,FaceInput,Rational};
use automexia_video::face_onnx::UltraFaceCpuDetector;
use automexia_video::silero_onnx::read_selected_pack;
use std::{path::PathBuf,time::Duration};
fn env(name:&str)->String{std::env::var(name).unwrap_or_else(|_|panic!("explicit {name} required for actual face-model qualification"))}
fn pack()->automexia_video::VerifiedModelPack{read_selected_pack(&PathBuf::from(env("FACE_MODEL_MANIFEST")),&PathBuf::from(env("FACE_MODEL_WEIGHTS")),&PathBuf::from(env("FACE_MODEL_NOTICES")),&env("FACE_EXPECTED_MANIFEST_SHA256"),&Cancellation::new()).unwrap()}
#[test]#[ignore="requires selected UltraFace model, ORT runtime, and an explicit RGB face fixture"]
fn selected_ultraface_detects_fixture(){
    let detector=UltraFaceCpuDetector::new(pack(),PathBuf::from(env("ORT_DYLIB_PATH")),Duration::from_secs(10)).unwrap();
    let width:u32=env("FACE_FIXTURE_WIDTH").parse().unwrap();let height:u32=env("FACE_FIXTURE_HEIGHT").parse().unwrap();let bytes=std::fs::read(env("FACE_FIXTURE_RGB")).unwrap();
    let result=detector.detect(FaceInput{width,height,rgb:&bytes,source_time:Rational::new(0,1).unwrap()},&Cancellation::new()).unwrap();
    assert!(!result.is_empty(),"explicit face fixture produced no detected face");for detection in result{detection.validate().unwrap();assert!(detection.confidence>=0.5);}
}
#[test]#[ignore="requires an explicit selected UltraFace model pack"]
fn revoked_or_changed_runtime_rejected(){
    let dir=tempfile::TempDir::new().unwrap();let runtime=dir.path().join("unapproved-runtime.so");std::fs::write(&runtime,b"changed runtime artifact").unwrap();
    let detector=UltraFaceCpuDetector::new(pack(),runtime,Duration::from_secs(10)).unwrap();let cancel=Cancellation::new();cancel.cancel();
    assert!(matches!(detector.detect(FaceInput{width:1,height:1,rgb:&[0,0,0],source_time:Rational::new(0,1).unwrap()},&cancel),Err(automexia_video::Error::Cancelled)));
    assert!(matches!(detector.revalidate(&Cancellation::new()),Err(automexia_video::Error::ToolIdentityChanged)));
}
