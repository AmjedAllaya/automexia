# FCPXML verification fixtures

`automexia-cuts-profile.dtd` is an authored, deliberately restricted test schema
for the exporter. It is not Apple's DTD and passing it does not establish editor
compatibility. The Python reference suite produces its fixtures outside the
source tree and checks XML IDs, exact clocks, component selection and marker
placement independently of Rust execution.

For an additional official schema check, download the FCPXML 1.10 DTD from
[Apple's Document Type Definition](https://developer.apple.com/documentation/professional-video-applications/document-type-definition)
and set `AMX_FCPXML_DTD` to its local path, or pass `--apple-dtd`. The suite records
the supplied DTD's SHA-256 and source reference, and requires its declared
version to be 1.10. This repository does not redistribute Apple's DTD. Without
that input the official check is explicitly blocked, while local profile and
semantic checks still run. The supplied file is schema evidence, not an
assertion that Final Cut Pro has imported the document.

The implementation follows Apple's documented
[relative media URLs](https://developer.apple.com/documentation/professional-video-applications/media-rep),
[timing attributes](https://developer.apple.com/documentation/professional-video-applications/timing-attributes),
[clip components](https://developer.apple.com/documentation/professional-video-applications/clip),
and [audio channel selection](https://developer.apple.com/documentation/professional-video-applications/audio).
Full Apple documentation snapshots used during development remain outside the
project distribution.
