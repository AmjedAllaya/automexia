//! Core-only presentation/project/review tests. No files or codec process needed.
use automexia_video::*;
use automexia_video::presentation::*;
use automexia_video::project::*;
use automexia_video::host::{FileStamp,InputFile};
use automexia_video::plan::build_edited_plan;
use automexia_video::media::parse_probe;
use automexia_video::edit_render::EditRender;
use automexia_video::preview::PreviewPlan;
use std::path::{Path,PathBuf};
fn r(s:&str)->Rational{s.parse().unwrap()}
fn span(a:&str,b:&str)->TimeRange{TimeRange::new(r(a),r(b)).unwrap()}
fn loc()->PathBuf{std::env::temp_dir().join("presentation-unit").join("project.amxv")}
fn media()->MediaInfo{let mut m=parse_probe(include_bytes!("fixtures/probe-base.json")).unwrap();let v=m.streams.iter_mut().find(|s|s.kind=="video").unwrap();v.color_space=Some("bt709".into());v.color_transfer=Some("bt709".into());v.color_primaries=Some("bt709".into());v.color_range=Some("tv".into());m}
fn project()->Project{let m=media();let f=InputFile{canonical_path:loc().parent().unwrap().join("input.mp4"),stamp:FileStamp{size:100,modified_ns:None,sha256:"a".repeat(64),file_id:None}};let s=ProjectSource::from_probe("source-1",&f,&m,m.select(StreamSelection::default()).unwrap(),&loc()).unwrap();Project::new("presentation",s,ResolvedSettings{ workflow:None,voice_cleanup:None,voice_enhancement:None,color_correction:None,pause_cleanup:None,preset_name:None,preset_revision:None,render:FrozenRenderSettings::from_options(&RenderOptions::default()).unwrap()}).unwrap()}
fn asset()->AssetRef{AssetRef{path:PathBuf::from("assets/logo.png"),size:20,sha256:"b".repeat(64)}}
fn place()->Placement{Placement{anchor:Anchor::TopLeft,width:30,height:16,margin:0}}
fn overlay()->Overlay{Overlay{id:"logo".into(),range:span("0","2"),content:GraphicContent::Image{asset:asset()},placement:place(),animation:Animation::default(),enabled:true}}
fn profile()->PresentationSettings{PresentationSettings{safe_zone:SafeZone::none(),overlays:vec![overlay()],..Default::default()}}
fn caps()->RuntimeCapabilities{RuntimeCapabilities{supports_demux_time_base:true,bitstream_filters:["setts".into()].into_iter().collect(),encoders:["libx264".into(),"aac".into()].into_iter().collect(),muxers:["mp4".into()].into_iter().collect(),filters:["settb","setpts","select","asetpts","aresample","apad","atrim","anull","asplit","concat","scale","setsar","format","crop","pad","geq","overlay","volume","fade","trim","fps","split","tpad","null","atempo","xfade","acrossfade","asetnsamples"].map(str::to_owned).into_iter().collect(),..Default::default()}}
fn approved(s:PresentationSettings)->Project{let mut p=project();p.set_presentation("main",Some(s)).unwrap();p.review_presentation("main",Disposition::AutoApply,true).unwrap();p}
fn plan(p:&Project)->Result<RenderPlan>{build_edited_plan(p,"main",&media(),&caps())}
fn presentation(p:&Project)->PresentationRender{plan(p).unwrap().presentation().unwrap().clone()}
#[test]fn no_presentation_is_baseline(){assert!(plan(&project()).unwrap().presentation().is_none());}
#[test]fn new_settings_require_review(){let mut p=project();let mut s=profile();s.disposition=Disposition::AutoApply;p.set_presentation("main",Some(s)).unwrap();assert!(matches!(plan(&p),Err(Error::UnresolvedEdits)));}
#[test]fn disabled_restores_old_render_path(){let mut p=approved(profile());p.review_presentation("main",Disposition::AutoApply,false).unwrap();assert!(plan(&p).unwrap().presentation().is_none());}
#[test]fn rejected_content_is_not_rendered(){let mut p=approved(profile());p.review_presentation("main",Disposition::Ignore,false).unwrap();assert!(plan(&p).unwrap().presentation().is_none());}
#[test]fn locks_prevent_replacement_and_rejection(){let mut p=approved(profile());p.set_presentation_locked("main",true).unwrap();assert!(matches!(p.set_presentation("main",None),Err(Error::LockedEdit)));assert!(p.review_presentation("main",Disposition::Ignore,false).is_err());p.set_presentation_locked("main",false).unwrap();p.set_presentation("main",None).unwrap();}
#[test]fn invalid_change_is_atomic(){let mut p=approved(profile());let bytes=p.to_json().unwrap();let mut s=profile();s.overlays[0].range.end=r("9");assert!(p.set_presentation("main",Some(s)).is_err());assert_eq!(p.to_json().unwrap(),bytes);}
#[test]fn replacing_settings_returns_to_review(){let mut p=approved(profile());let mut s=p.variants[0].presentation.clone().unwrap();s.overlays[0].placement.anchor=Anchor::BottomRight;p.set_presentation("main",Some(s)).unwrap();assert_eq!(p.variants[0].presentation.as_ref().unwrap().disposition,Disposition::NeedsReview);}
#[test]fn sibling_and_shared_settings_are_unchanged(){let mut p=project();p.add_output_variant("portrait",p.variants[0].render.clone(),None).unwrap();let old=serde_json::to_vec(&(&p.assembly,&p.operations,&p.settings,&p.variants[0])).unwrap();p.set_presentation("portrait",Some(profile())).unwrap();assert_eq!(serde_json::to_vec(&(&p.assembly,&p.operations,&p.settings,&p.variants[0])).unwrap(),old);assert!(plan(&p).is_ok());}
#[test]fn project_roundtrip_preserves_presentation(){let p=approved(profile());let bytes=p.to_json().unwrap();assert_eq!(Project::from_json(&bytes).unwrap().to_json().unwrap(),bytes);assert_eq!(p.schema_version,automexia_video::project::PROJECT_VERSION);}
#[test]fn schema5_migration_adds_no_content(){let mut v=serde_json::to_value(project()).unwrap();v["schema_version"]=5.into();let p=Project::from_json(&serde_json::to_vec(&v).unwrap()).unwrap();assert_eq!(p.schema_version,automexia_video::project::PROJECT_VERSION);assert!(p.variants[0].presentation.is_none());}
#[test]fn old_schema_cannot_smuggle_presentation(){let mut v=serde_json::to_value(approved(profile())).unwrap();v["schema_version"]=5.into();assert!(Project::from_json(&serde_json::to_vec(&v).unwrap()).is_err());}
#[test]fn unknown_presentation_fields_are_rejected(){let mut v=serde_json::to_value(approved(profile())).unwrap();v["variants"][0]["presentation"]["shell"]="forbidden".into();assert!(Project::from_json(&serde_json::to_vec(&v).unwrap()).is_err());}
#[test]fn asset_paths_rebase_with_media_even_when_disabled(){let mut p=approved(profile());p.variants[0].presentation.as_mut().unwrap().overlays[0].enabled=false;let old=p.variants[0].presentation.as_ref().unwrap().all_asset_refs()[0].resolve(&loc()).unwrap();let target=std::env::temp_dir().join("other-location/project.amxv");p.rebase_paths(&loc(),&target).unwrap();let new=p.variants[0].presentation.as_ref().unwrap().all_asset_refs()[0].resolve(&target).unwrap();assert_eq!(old,new);}
#[test]fn path_traversal_and_bad_hash_rejected(){let mut a=asset();a.path=PathBuf::from("../secret.png");assert!(a.validate().is_err());let mut a=asset();a.sha256="g".repeat(64);assert!(a.validate().is_err());}
#[test]fn source_url_is_not_a_local_asset(){let mut a=asset();a.path=PathBuf::from("https://example.invalid/image.png");assert!(a.validate().is_err());}
#[test]fn missing_overlay_filter_is_a_capability_error(){let mut c=caps();c.filters.remove("overlay");assert!(build_edited_plan(&approved(profile()),"main",&media(),&c).is_err());}
#[test]fn unknown_color_is_not_guessed_for_compositing(){let mut p=approved(profile());p.sources[0].media.video.color_primaries=None;let mut m=media();m.streams.iter_mut().find(|s|s.kind=="video").unwrap().color_primaries=None;assert!(build_edited_plan(&p,"main",&m,&caps()).is_err());}
#[test]fn graphics_cannot_execute_without_a_prepared_lease(){let p=plan(&approved(profile())).unwrap();assert!(matches!(p.arguments(Path::new("input.mp4"),Path::new("stage.mp4")),Err(Error::MissingCapability(_))));}
#[test]fn quiet_caption_timelines_do_not_modify_edits(){let p=approved(profile());assert_eq!(p.timeline().unwrap().duration,project().timeline().unwrap().duration);}
#[test]fn anchor_fits_inside_safe_zone(){let size=OutputSize::new(160,96).unwrap();let r=Placement{anchor:Anchor::BottomRight,..place()}.rect(size,SafeZone{left:1000,right:1000,top:1000,bottom:1000}).unwrap();assert!(r.x+r.width<=144&&r.y+r.height<=86);}
#[test]fn oversized_rectangle_is_rejected_without_overflow(){let p=Placement{width:u32::MAX,height:2,margin:256,anchor:Anchor::Center};assert!(p.rect(OutputSize::new(160,96).unwrap(),SafeZone::none()).is_err());}
#[test]fn whole_animation_envelope_must_fit(){let mut s=profile();s.overlays[0].animation.keys=vec![VisualKey{at:r("0"),dx:0,dy:0,scale:1.0,opacity:1.0,easing:Easing::Linear},VisualKey{at:r("1"),dx:200,dy:0,scale:1.0,opacity:1.0,easing:Easing::Linear}];assert!(plan(&approved(s)).is_err());}
#[test]fn nonfinite_motion_and_volume_are_rejected(){let mut s=profile();s.overlays[0].animation.keys=vec![VisualKey{at:r("0"),dx:0,dy:0,scale:f64::NAN,opacity:1.0,easing:Easing::Linear}];assert!(s.validate(r("2")).is_err());s=profile();s.volume=Some(VolumeTrack{keys:vec![VolumeKey{at:r("0"),gain:f64::INFINITY,easing:Easing::Linear}]});assert!(s.validate(r("2")).is_err());}
#[test]fn all_easing_curves_preserve_endpoints_and_monotonicity(){for e in [Easing::Linear,Easing::EaseIn,Easing::EaseOut,Easing::EaseInOut]{assert_eq!(e.value(0.0),0.0);assert_eq!(e.value(1.0),1.0);for n in 0..100{assert!(e.value(n as f64/100.0)<=e.value((n+1) as f64/100.0));}}}
#[test]fn graphics_do_not_silently_restart_animation_after_cut(){let mut s=profile();s.overlays[0].animation.fade_in=r("1");let mut p=approved(s);p.set_keep_ranges("source-1",&[span("4/5","6/5")]).unwrap();let q=presentation(&p);let event=&q.events[0];let state=event.animation.state(event.elapsed(r("0")).unwrap(),event.animation_duration).unwrap();assert!((state.opacity-0.8).abs()<0.001);}
#[test]fn one_frame_edges_use_same_microsecond_clock(){let mut s=profile();s.overlays[0].range=span("1001/30000","2002/30000");let q=presentation(&approved(s));let times=q.sample_times().unwrap();assert!(times.contains(&33367));assert!(times.contains(&66733));}
#[test]fn animation_state_budget_fails_instead_of_unbounded_growth(){let mut s=profile();s.raster.max_states=3;s.overlays[0].animation.fade_in=r("1");assert!(plan(&approved(s)).is_err());}
#[test]fn known_collisions_reject_by_default(){let mut s=profile();let mut b=overlay();b.id="second".into();s.overlays.push(b);assert!(plan(&approved(s)).is_err());}
#[test]fn intentional_layering_requires_explicit_setting(){let mut s=profile();let mut b=overlay();b.id="second".into();s.overlays.push(b);s.collisions=CollisionPolicy::AllowReviewed;assert!(plan(&approved(s)).is_ok());}
#[test]fn nonoverlapping_time_is_not_a_spatial_collision(){let mut s=profile();s.overlays[0].range=span("0","1");let mut b=overlay();b.id="second".into();b.range=span("1","2");s.overlays.push(b);assert!(plan(&approved(s)).is_ok());}
#[test]fn caption_parts_share_effective_audio_rounded_timeline(){let mut p=project();p.set_keep_ranges("source-1",&[span("0","1/2"),span("1","3/2")]).unwrap();let edit=EditRender::from_project(&p).unwrap();let t=automexia_video::presentation_render::effective_timeline(&edit).unwrap();assert_eq!(t.duration,edit.duration);assert_eq!(t.segments[1].output_range.start,r("1/2"));}
#[test]fn volume_only_profile_needs_no_graphics_lease(){let mut s=PresentationSettings::default();s.volume=Some(VolumeTrack{keys:vec![VolumeKey{at:r("0"),gain:0.5,easing:Easing::Linear}]});let p=plan(&approved(s)).unwrap();assert!(!p.presentation().unwrap().has_pixels());let args=p.arguments(Path::new("input.mp4"),Path::new("output.mp4")).unwrap();assert!(args.iter().any(|s|s.to_string_lossy().contains("volume='")));}
#[test]fn sidecar_only_profile_needs_no_graphics_runtime(){let mut s=PresentationSettings::default();s.captions=Some(CaptionLayer{document:SubtitleDocument::parse(b"1\n00:00:00,000 --> 00:00:01,000\nHi\n",SubtitleFormat::Srt).unwrap(),style:None,placement:None,burn_in:false});let mut c=caps();c.filters.remove("overlay");let p=approved(s);let plan=build_edited_plan(&p,"main",&media(),&c).unwrap();assert!(!plan.presentation().unwrap().has_pixels());}
#[test]fn review_lists_presentation_and_approves_explicitly(){let mut p=project();p.set_presentation("main",Some(profile())).unwrap();let mut s=ReviewSession::new(p).unwrap();let v=s.snapshot().unwrap();let v=s.dispatch(&v.token,ReviewCommand::Select(ReviewTarget::PresentationVariant("main".into()))).unwrap();let v=s.dispatch(&v.token,ReviewCommand::Inspect).unwrap();assert!(v.detail.unwrap().presentation.is_some());s.dispatch(&v.token,ReviewCommand::Approve).unwrap();assert!(s.project().variants[0].presentation.as_ref().unwrap().active());}
#[test]fn review_change_invalidates_preview(){let mut s=ReviewSession::new(approved(profile())).unwrap();let v=s.snapshot().unwrap();let v=s.dispatch(&v.token,ReviewCommand::Select(ReviewTarget::PresentationVariant("main".into()))).unwrap();let cancel=s.preview_cancellation(&v.token).unwrap();s.dispatch(&v.token,ReviewCommand::ChangePresentation(profile())).unwrap();assert!(cancel.is_cancelled());assert!(matches!(s.dispatch(&v.token,ReviewCommand::Approve),Err(Error::StaleReview)));}
#[test]fn preview_is_hypothetical_and_before_is_unadorned(){let mut p=project();p.set_presentation("main",Some(profile())).unwrap();let old=p.to_json().unwrap();let request=PreviewRequest::new(&p,&loc(),loc().parent().unwrap(),ReviewTarget::PresentationVariant("main".into())).unwrap();let q=PreviewPlan::build(&p,&request).unwrap();assert!(q.render_plan(PreviewSide::Before,&media(),&caps()).unwrap().unwrap().presentation().is_none());assert!(q.render_plan(PreviewSide::Proposed,&media(),&caps()).unwrap().unwrap().presentation().is_some());assert_eq!(p.to_json().unwrap(),old);}
#[test]fn choosing_one_presentation_does_not_report_it_omitted(){let mut p=project();p.set_presentation("main",Some(profile())).unwrap();let req=PreviewRequest::new(&p,&loc(),loc().parent().unwrap(),ReviewTarget::PresentationVariant("main".into())).unwrap();let q=PreviewPlan::build(&p,&req).unwrap();assert!(!q.description().omitted_pending_ids.contains(&"presentation:main".into()));}
#[test]fn duplicate_placement_samples_are_not_accepted(){let x=AnchorSample{anchor:Anchor::TopLeft,luminance:0.2,edges:0.1,activity:0.0};assert!(suggest_anchor(OutputSize::new(160,96).unwrap(),(30,16),SafeZone::none(),&[],&[x,x],None).is_err());}
#[test]fn known_obstacles_exclude_occupied_anchor(){let obstacle=PixelRect{x:0,y:0,width:160,height:32};let a=suggest_anchor(OutputSize::new(160,96).unwrap(),(30,16),SafeZone::none(),&[obstacle],&[],None).unwrap();assert!(a.iter().all(|a|!matches!(a.anchor,Anchor::TopLeft|Anchor::TopCenter|Anchor::TopRight)));}

#[test]
fn nine_anchor_measurements_are_bounded_and_flat_frame_is_stable() {
    let canvas=OutputSize::new(160,96).unwrap();
    let data=vec![128;160*96*3];
    let samples=measure_anchors(canvas,(30,16),SafeZone::none(),&data,Some(&data)).unwrap();
    assert_eq!(samples.len(),9);
    for s in samples { assert!((s.luminance-128.0/255.0).abs()<1e-10);assert_eq!(s.edges,0.0);assert_eq!(s.activity,0.0); }
}
#[test]
fn anchor_measurements_reject_wrong_dimensions() {
    assert!(measure_anchors(OutputSize::new(160,96).unwrap(),(30,16),SafeZone::none(),&[0;9],None).is_err());
}
#[test]
fn anchor_stability_penalty_prefers_previous_when_otherwise_equal() {
    let a=suggest_anchor(OutputSize::new(160,96).unwrap(),(30,16),SafeZone::none(),&[],&[],Some(Anchor::BottomRight)).unwrap();
    assert_eq!(a[0].anchor,Anchor::BottomRight);
}
#[test]
fn punch_in_is_explicit_reversible_and_restrained() {
    let p=project();let f=explicit_punch_ins(&p.sources[0],OutputSize::new(160,96).unwrap(),&[span("1/2","1")],&[],1.05,r("1")).unwrap();
    assert_eq!(f.disposition,Disposition::NeedsReview);
    if let FramingMode::Crop{track}=f.mode { assert_eq!(track.shots.len(),3);assert_eq!(track.shots[1].keyframes[0].pose.zoom,1.05);assert_eq!(track.shots[0].keyframes[0].pose.zoom,1.0); } else {panic!("crop expected");}
}
#[test]
fn punch_in_cannot_cross_known_scene_cut_or_exceed_zoom() {
    let p=project();let size=OutputSize::new(160,96).unwrap();
    assert!(explicit_punch_ins(&p.sources[0],size,&[span("1/2","3/2")],&[r("1")],1.05,r("1")).is_err());
    assert!(explicit_punch_ins(&p.sources[0],size,&[],&[],1.2,r("1")).is_err());
}
#[test]
fn caption_edit_returns_profile_to_review_and_keeps_original() {
    let mut s=PresentationSettings::default();
    s.captions=Some(CaptionLayer{document:SubtitleDocument::parse(b"1\n00:00:00,000 --> 00:00:01,000\nBefore\n",SubtitleFormat::Srt).unwrap(),style:None,placement:None,burn_in:false});
    let mut p=approved(s);let raw=p.variants[0].presentation.as_ref().unwrap().captions.as_ref().unwrap().document.original.clone();
    p.change_caption("main","cue-1",span("1/4","3/4"),"After < & >".into()).unwrap();
    let s=p.variants[0].presentation.as_ref().unwrap();assert_eq!(s.disposition,Disposition::NeedsReview);assert_eq!(s.captions.as_ref().unwrap().document.original,raw);
}
#[test]
fn caption_burn_in_requires_explicit_font_and_box() {
    let mut s=PresentationSettings::default();s.captions=Some(CaptionLayer{document:SubtitleDocument::parse(b"1\n00:00:00,000 --> 00:00:01,000\nBefore\n",SubtitleFormat::Srt).unwrap(),style:None,placement:None,burn_in:true});
    assert!(s.validate(r("2")).is_err());
}
#[test]
fn editing_locked_layer_leaves_project_unchanged() {
    let mut p=approved(profile());p.set_presentation_locked("main",true).unwrap();let old=p.to_json().unwrap();
    assert!(p.update_overlay("main",overlay()).is_err());assert!(p.remove_overlay("main","logo").is_err());assert_eq!(old,p.to_json().unwrap());
}
#[test]
fn unknown_speed_controls_are_not_silently_accepted() {
    let mut value=serde_json::to_value(approved(profile())).unwrap();value["variants"][0]["presentation"]["speed"]=2.into();
    assert!(Project::from_json(&serde_json::to_vec(&value).unwrap()).is_err());
}
#[test]
fn animated_volume_cannot_invent_sample_clock_for_nan() {
    let mut s=PresentationSettings::default();s.volume=Some(VolumeTrack{keys:vec![VolumeKey{at:r("0"),gain:f64::NAN,easing:Easing::Linear}]});
    assert!(s.validate(r("2")).is_err());
}

#[test]
fn target_guides_are_not_overridden_by_weaker_presentation_guides(){
    let mut p=approved(profile());let mut f=FramingSettings::fit(OutputSize::new(160,96).unwrap()).unwrap();f.safe_zone=SafeZone{left:1000,right:1000,top:2000,bottom:2000};p.set_variant_framing("main",Some(f)).unwrap();p.decide_framing("main",FramingDecision::Approve).unwrap();
    let q=presentation(&p);assert_eq!(q.settings.safe_zone.top,2000);let (rect,_)=q.rect(&q.events[0],r("0")).unwrap();assert!(rect.x>=16&&rect.y>=20);
}

#[test]fn review_can_attach_new_presentation_without_discarding_other_unsaved_edits(){let mut session=ReviewSession::new(project()).unwrap();let view=session.snapshot().unwrap();let old=session.project().assembly.clone();let view=session.set_presentation(&view.token,"main",Some(profile())).unwrap();assert_eq!(session.project().assembly.len(),old.len());assert!(view.dirty);assert_eq!(view.selected,Some(ReviewTarget::PresentationVariant("main".into())));}
#[test]fn stale_review_cannot_attach_presentation(){let mut session=ReviewSession::new(project()).unwrap();let old=session.snapshot().unwrap();session.set_presentation(&old.token,"main",Some(profile())).unwrap();assert!(matches!(session.set_presentation(&old.token,"main",None),Err(Error::StaleReview)));}
#[test]fn captions_reject_internal_blank_lines_before_export(){let mut d=SubtitleDocument::parse(b"1\n00:00:00,000 --> 00:00:01,000\nHello\n",SubtitleFormat::Srt).unwrap();let id=d.cues[0].id.clone();let before=serde_json::to_vec(&d).unwrap();assert!(d.replace_cue(&id,span("0","1"),"Hello\n \nworld".into()).is_err());assert_eq!(serde_json::to_vec(&d).unwrap(),before);}

#[test]
fn dissolve_rasterization_uses_source_events_and_output_sidecar_clock() {
    let mut p=approved(profile());let frame=|n|r("1001/30000").ticks(n).unwrap();
    p.set_keep_ranges("source-1",&[TimeRange::new(frame(0),frame(20)).unwrap(),TimeRange::new(frame(40),frame(60)).unwrap()]).unwrap();
    p.set_timing("main",Some(TimingSettings{dissolve:frame(4),..Default::default()})).unwrap();p.review_timing("main",Disposition::AutoApply,true).unwrap();
    let edit=EditRender::from_project(&p).unwrap();let out=PresentationRender::from_project(&p,"main",&edit,OutputSize::new(160,96).unwrap(),r("1"),&caps()).unwrap().unwrap();
    assert!(out.source_composition);assert_eq!(out.duration,p.sources[0].duration);assert_eq!(out.timeline.duration,p.sources[0].duration);assert_eq!(edit.duration,frame(36));
    assert_eq!(out.events[0].range,out.events[0].source_range);
}

#[test]
fn generated_caption_words_removed_from_both_normal_and_dissolve_raster_events() {
    let frame=|n|r("1001/30000").ticks(n).unwrap();
    for dissolve in [r("0"),frame(4)] {
        let mut document=SubtitleDocument::parse(b"1\n00:00:00,000 --> 00:00:02,002\nKeep delete tail\n",SubtitleFormat::Srt).unwrap();
        let cue=document.cues[0].id.clone();document.generated_words=vec![
            automexia_video::subtitles::CaptionWord{cue_id:cue.clone(),range:TimeRange::new(frame(0),frame(20)).unwrap(),text:"Keep".into()},
            automexia_video::subtitles::CaptionWord{cue_id:cue.clone(),range:TimeRange::new(frame(20),frame(40)).unwrap(),text:"delete".into()},
            automexia_video::subtitles::CaptionWord{cue_id:cue,range:TimeRange::new(frame(40),frame(60)).unwrap(),text:"tail".into()},
        ];
        let mut s=profile();s.overlays.clear();s.captions=Some(CaptionLayer{document,style:Some(TextStyle::light(FontRef{asset:asset(),family:"Fixture Font".into()},12)),placement:Some(Placement{anchor:Anchor::BottomCenter,width:120,height:30,margin:0}),burn_in:true});
        let mut p=approved(s);p.set_keep_ranges("source-1",&[TimeRange::new(frame(0),frame(20)).unwrap(),TimeRange::new(frame(40),frame(60)).unwrap()]).unwrap();
        if dissolve.positive(){p.set_timing("main",Some(TimingSettings{dissolve,..Default::default()})).unwrap();p.review_timing("main",Disposition::AutoApply,true).unwrap();}
        let edit=EditRender::from_project(&p).unwrap();let out=PresentationRender::from_project(&p,"main",&edit,OutputSize::new(160,96).unwrap(),r("1"),&caps()).unwrap().unwrap();
        let text=out.events.iter().map(|e|match &e.content{GraphicContent::Text{text,..}=>text.as_str(),_=>panic!("caption is text")}).collect::<Vec<_>>();
        assert_eq!(text,vec!["Keep","tail"]);assert!(out.mapped_captions.iter().all(|c|!c.text.contains("delete")));
        assert!(p.variants[0].presentation.as_ref().unwrap().captions.as_ref().unwrap().document.cues[0].text.contains("delete"));
    }
}
