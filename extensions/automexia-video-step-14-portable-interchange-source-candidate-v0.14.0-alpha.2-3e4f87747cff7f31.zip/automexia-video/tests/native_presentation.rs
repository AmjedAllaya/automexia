//! Real Rust/FFmpeg integration tests. Run explicitly with --features native.
//! These tests invoke the Rust pipeline, unlike tests/media/*.py recipes.
use automexia_video::*;
use automexia_video::native::{NativeMediaHost,NativeSettings};
use automexia_video::presentation::*;
use automexia_video::preview::{PreviewOpener,VerifiedPreview};
use std::{fs,path::{Path,PathBuf},process::Command};
use tempfile::TempDir;
use sha2::{Digest,Sha256};
fn r(s:&str)->Rational{s.parse().unwrap()}
fn span(a:&str,b:&str)->TimeRange{TimeRange::new(r(a),r(b)).unwrap()}
fn tool(n:&str)->PathBuf{std::env::var_os(n).map(PathBuf::from).unwrap_or_else(||if n=="FFMPEG"{"/usr/bin/ffmpeg".into()}else{"/usr/bin/ffprobe".into()})}
fn ext()->VideoExtension<NativeMediaHost>{VideoExtension::new(NativeMediaHost::new(NativeSettings::new(tool("FFMPEG"),tool("FFPROBE"))).unwrap(),VideoSettings::default()).unwrap()}
fn source(dir:&Path)->PathBuf{let p=dir.join("source.mp4");assert!(Command::new(tool("FFMPEG")).args(["-v","error","-nostdin","-y","-f","lavfi","-i","color=c=blue:s=160x96:r=30:d=3","-f","lavfi","-i","sine=frequency=440:sample_rate=48000:duration=3","-c:v","libx264","-threads:v","1","-c:a","aac","-threads:a","1","-pix_fmt","yuv420p","-colorspace","bt709","-color_primaries","bt709","-color_trc","bt709","-color_range","tv","-x264-params","videoformat=component:colorprim=bt709:transfer=bt709:colormatrix=bt709"]).arg(&p).status().unwrap().success());p}
fn selected(path:&Path)->AssetRef{let b=fs::read(path).unwrap();AssetRef{path:path.to_owned(),size:b.len() as u64,sha256:format!("{:x}",Sha256::digest(b))}}
fn profile(dir:&Path)->PresentationSettings{let p=dir.join("logo.svg");fs::write(&p,b"<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"32\" height=\"20\"><rect width=\"32\" height=\"20\" fill=\"red\"/></svg>").unwrap();PresentationSettings{safe_zone:SafeZone::none(),overlays:vec![Overlay{id:"logo".into(),range:span("1/2","1"),content:GraphicContent::Svg{asset:selected(&p)},placement:Placement{anchor:Anchor::TopLeft,width:32,height:20,margin:0},animation:Animation::default(),enabled:true}],..Default::default()}}
fn prepared(x:&VideoExtension<NativeMediaHost>,src:&Path,path:&Path,s:PresentationSettings)->Project{let mut p=x.create_project(&NewProjectRequest::new("presentation",src,path),&Cancellation::new(),&mut |_|{}).unwrap();p.set_presentation("main",Some(s)).unwrap();p.review_presentation("main",Disposition::AutoApply,true).unwrap();p}
fn render(x:&VideoExtension<NativeMediaHost>,p:&Project,path:&Path,dest:&Path)->Result<ProjectRenderResult>{x.render_project(p,&ProjectRenderRequest::new(path,dest),&Cancellation::new(),&mut |_|{})}
fn rgb(path:&Path,frame:usize)->Vec<u8>{let p=Command::new(tool("FFMPEG")).args(["-v","error","-i"]).arg(path).args(["-vf",&format!("select=eq(n\\,{frame})"),"-frames:v","1","-an","-filter_threads","1","-threads:v","1","-f","rawvideo","-pix_fmt","rgb24","-"]).output().unwrap();assert!(p.status.success());p.stdout}
fn is_red(bytes:&[u8])->bool{let i=(8*160+8)*3;bytes[i]>150&&bytes[i+2]<100}
#[derive(Default)]struct Opener(Vec<PathBuf>);
impl PreviewOpener for Opener{fn open(&mut self,p:&VerifiedPreview<'_>)->Result<()>{self.0.push(p.file().canonical_path.clone());Ok(())}}
#[test]fn actual_svg_is_rendered_and_source_unchanged(){let d=TempDir::new().unwrap();let src=source(d.path());let original=fs::read(&src).unwrap();let path=d.path().join("p.amxv");let x=ext();let p=prepared(&x,&src,&path,profile(d.path()));let out=d.path().join("render.mp4");let result=render(&x,&p,&path,&out).unwrap();assert!(result.media.full_decode_validated);assert_eq!(result.presentation_assets.len(),1);assert!(!is_red(&rgb(&out,0)));assert!(is_red(&rgb(&out,20)));assert!(!is_red(&rgb(&out,40)));assert_eq!(fs::read(&src).unwrap(),original);}
#[test]fn actual_saved_profile_can_reopen_and_render(){let d=TempDir::new().unwrap();let src=source(d.path());let path=d.path().join("p.amxv");let x=ext();let p=prepared(&x,&src,&path,profile(d.path()));x.save_project(&p,&path,&OutputPolicy::CreateNew,&Cancellation::new()).unwrap();let saved=x.load_project(&path,&Cancellation::new()).unwrap();assert_eq!(saved.project.to_json().unwrap(),p.to_json().unwrap());render(&x,&saved.project,&path,&d.path().join("out.mp4")).unwrap();}
#[test]fn actual_graphic_timing_remaps_through_a_cut(){let d=TempDir::new().unwrap();let src=source(d.path());let path=d.path().join("p.amxv");let x=ext();let mut s=profile(d.path());s.overlays[0].range=span("2","5/2");let mut p=prepared(&x,&src,&path,s);p.remove_range("source-1",span("1","2"),"cut").unwrap();let out=d.path().join("out.mp4");render(&x,&p,&path,&out).unwrap();assert!(!is_red(&rgb(&out,20)));assert!(is_red(&rgb(&out,35)));assert!(!is_red(&rgb(&out,50)));}
#[test]fn actual_changed_asset_blocks_publication(){let d=TempDir::new().unwrap();let src=source(d.path());let path=d.path().join("p.amxv");let x=ext();let p=prepared(&x,&src,&path,profile(d.path()));fs::write(d.path().join("logo.svg"),b"changed").unwrap();let out=d.path().join("out.mp4");assert!(matches!(render(&x,&p,&path,&out),Err(Error::InputChanged)));assert!(!out.exists());}
#[test]fn actual_missing_asset_blocks_publication(){let d=TempDir::new().unwrap();let src=source(d.path());let path=d.path().join("p.amxv");let x=ext();let mut settings=profile(d.path());
    // An explicitly selected, absent path is deterministic on synchronized
    // filesystems where deleting a populated fixture can race background replay.
    let missing=d.path().join("never-created.svg");assert!(!missing.exists());
    if let GraphicContent::Svg{asset}=&mut settings.overlays[0].content{asset.path=missing;}
    let p=prepared(&x,&src,&path,settings);let out=d.path().join("out.mp4");assert!(render(&x,&p,&path,&out).is_err());assert!(!out.exists());}

#[test]fn actual_unsafe_svg_is_rejected_before_output(){let d=TempDir::new().unwrap();let src=source(d.path());let path=d.path().join("p.amxv");let x=ext();let mut s=profile(d.path());let a=d.path().join("logo.svg");fs::write(&a,b"<svg xmlns=\"http://www.w3.org/2000/svg\"><image href=\"file:///etc/passwd\"/></svg>").unwrap();s.overlays[0].content=GraphicContent::Svg{asset:selected(&a)};let p=prepared(&x,&src,&path,s);let out=d.path().join("out.mp4");assert!(render(&x,&p,&path,&out).is_err());assert!(!out.exists());}
#[test]fn actual_pending_presentation_is_not_rendered(){let d=TempDir::new().unwrap();let src=source(d.path());let path=d.path().join("p.amxv");let x=ext();let mut p=prepared(&x,&src,&path,profile(d.path()));p.review_presentation("main",Disposition::NeedsReview,true).unwrap();let out=d.path().join("out.mp4");assert!(matches!(render(&x,&p,&path,&out),Err(Error::UnresolvedEdits)));assert!(!out.exists());}
#[test]fn actual_cancellation_during_graphics_prevents_output(){let d=TempDir::new().unwrap();let src=source(d.path());let path=d.path().join("p.amxv");let x=ext();let p=prepared(&x,&src,&path,profile(d.path()));let out=d.path().join("out.mp4");let c=Cancellation::new();let signal=c.clone();let result=x.render_project(&p,&ProjectRenderRequest::new(&path,&out),&c,&mut|e|{if e.stage==automexia_video::progress::Stage::PreparingGraphics{signal.cancel();}});assert!(matches!(result,Err(Error::Cancelled)));assert!(!out.exists());}
#[test]fn actual_graphics_scratch_is_owned_by_lease(){let d=TempDir::new().unwrap();let src=source(d.path());let path=d.path().join("p.amxv");let x=ext();let p=prepared(&x,&src,&path,profile(d.path()));let c=Cancellation::new();let probe=x.probe(&src,&c,&mut |_|{}).unwrap();let caps=x.host().runtime_capabilities(&c).unwrap();let plan=automexia_video::plan::build_edited_plan(&p,"main",&probe.media,&caps).unwrap();let lease=x.host().prepare_presentation(plan.presentation().unwrap(),&path,&c).unwrap();let file=lease.sequence_path().to_owned();assert!(file.exists());assert!(lease.bytes()>0);drop(lease);assert!(!file.exists());}
#[test]fn actual_project_save_cannot_replace_asset_alias(){let d=TempDir::new().unwrap();let src=source(d.path());let path=d.path().join("p.amxv");let x=ext();let p=prepared(&x,&src,&path,profile(d.path()));fs::hard_link(d.path().join("logo.svg"),&path).unwrap();let c=Cancellation::new();let stamp=x.host().review_existing_output(&path,&c).unwrap();assert!(matches!(x.save_project(&p,&path,&OutputPolicy::ReplaceReviewed(stamp),&c),Err(Error::SameFile)));}
fn captions()->PresentationSettings{PresentationSettings{captions:Some(CaptionLayer{document:SubtitleDocument::parse(b"1\n00:00:00,500 --> 00:00:02,500\nAcross cut\n",SubtitleFormat::Srt).unwrap(),style:None,placement:None,burn_in:false}),..Default::default()}}
#[test]fn actual_sidecar_needs_no_font_and_maps_deleted_time(){let d=TempDir::new().unwrap();let src=source(d.path());let path=d.path().join("p.amxv");let x=ext();let mut p=prepared(&x,&src,&path,captions());p.remove_range("source-1",span("1","2"),"cut").unwrap();let out=d.path().join("captions.vtt");let result=x.export_subtitles(&p,"main",&path,&out,SubtitleFormat::WebVtt,&OutputPolicy::CreateNew,&Cancellation::new()).unwrap();assert_eq!(result.cue_parts,2);let s=fs::read_to_string(out).unwrap();assert!(s.contains("00:00:00.500 --> 00:00:01.000"));assert!(s.contains("00:00:01.000 --> 00:00:01.500"));}
#[test]fn actual_sidecar_cannot_replace_project_alias(){let d=TempDir::new().unwrap();let src=source(d.path());let path=d.path().join("p.amxv");let x=ext();let p=prepared(&x,&src,&path,captions());let c=Cancellation::new();x.save_project(&p,&path,&OutputPolicy::CreateNew,&c).unwrap();let out=d.path().join("alias.vtt");fs::hard_link(&path,&out).unwrap();let stamp=x.host().review_existing_output(&out,&c).unwrap();assert!(matches!(x.export_subtitles(&p,"main",&path,&out,SubtitleFormat::WebVtt,&OutputPolicy::ReplaceReviewed(stamp),&c),Err(Error::SameFile)));}
#[test]fn actual_preview_does_not_approve_and_releases_files(){let d=TempDir::new().unwrap();let src=source(d.path());let path=d.path().join("p.amxv");let x=ext();let mut p=prepared(&x,&src,&path,profile(d.path()));p.review_presentation("main",Disposition::NeedsReview,true).unwrap();let old=p.to_json().unwrap();let request=PreviewRequest::new(&p,&path,d.path(),ReviewTarget::PresentationVariant("main".into())).unwrap();let preview=x.preview_edit(&p,&request,&Cancellation::new(),&mut |_|{}).unwrap();let mut opener=Opener::default();x.open_preview(&preview,&p,PreviewSide::Before,&mut opener,&Cancellation::new()).unwrap();x.open_preview(&preview,&p,PreviewSide::Proposed,&mut opener,&Cancellation::new()).unwrap();assert!(!is_red(&rgb(&opener.0[0],20)));assert!(is_red(&rgb(&opener.0[1],20)));assert_eq!(p.to_json().unwrap(),old);drop(preview);assert!(opener.0.iter().all(|p|!p.exists()));}
#[test]fn changed_asset_invalidates_existing_preview(){let d=TempDir::new().unwrap();let src=source(d.path());let path=d.path().join("p.amxv");let x=ext();let p=prepared(&x,&src,&path,profile(d.path()));let request=PreviewRequest::new(&p,&path,d.path(),ReviewTarget::PresentationVariant("main".into())).unwrap();let preview=x.preview_edit(&p,&request,&Cancellation::new(),&mut |_|{}).unwrap();fs::write(d.path().join("logo.svg"),b"changed").unwrap();let mut opener=Opener::default();assert!(matches!(x.open_preview(&preview,&p,PreviewSide::Proposed,&mut opener,&Cancellation::new()),Err(Error::InputChanged)));assert!(opener.0.is_empty());}
#[test]fn bypass_needs_no_missing_asset(){let d=TempDir::new().unwrap();let src=source(d.path());let path=d.path().join("p.amxv");let x=ext();let mut p=prepared(&x,&src,&path,profile(d.path()));p.review_presentation("main",Disposition::AutoApply,false).unwrap();fs::remove_file(d.path().join("logo.svg")).unwrap();render(&x,&p,&path,&d.path().join("bypass.mp4")).unwrap();}
#[test]fn disabled_extension_writes_no_sidecar(){let d=TempDir::new().unwrap();let src=source(d.path());let path=d.path().join("p.amxv");let x=ext();let p=prepared(&x,&src,&path,captions());x.disable().unwrap();let out=d.path().join("captions.vtt");assert!(matches!(x.export_subtitles(&p,"main",&path,&out,SubtitleFormat::WebVtt,&OutputPolicy::CreateNew,&Cancellation::new()),Err(Error::Disabled)));assert!(!out.exists());}

#[test]
fn actual_assembly_repeats_source_graphics_at_each_requested_speed(){
    let d=TempDir::new().unwrap();let src=source(d.path());let source_before=fs::read(&src).unwrap();let path=d.path().join("p.amxv");let x=ext();
    let mut p=prepared(&x,&src,&path,profile(d.path()));
    let make=|id:&str,a:&str,b:&str,speed|AssemblyClip{id:id.into(),range:span(a,b),speed};
    p.set_assembly("main",Some(AssemblySettings{clips:vec![
        make("later","3/2","5/2",PlaybackSpeed::Normal),
        make("fast","1/2","3/2",PlaybackSpeed::Double),
        make("slow-repeat","1/2","3/2",PlaybackSpeed::Half),
        make("opening","0","1/2",PlaybackSpeed::Normal),
    ],..Default::default()})).unwrap();p.review_assembly("main",Disposition::AutoApply,true).unwrap();
    let out=d.path().join("assembly.mp4");let result=render(&x,&p,&path,&out).unwrap();assert!(result.media.full_decode_validated);
    assert!(!is_red(&rgb(&out,10)));assert!(is_red(&rgb(&out,34)));assert!(!is_red(&rgb(&out,42)));
    assert!(is_red(&rgb(&out,55)));assert!(!is_red(&rgb(&out,90)));assert!(!is_red(&rgb(&out,115)));
    assert_eq!(fs::read(&src).unwrap(),source_before);
}

#[test]
fn actual_assembly_sidecar_repeats_only_corrected_visible_words(){
    let d=TempDir::new().unwrap();let src=source(d.path());let path=d.path().join("p.amxv");let x=ext();
    let mut document=SubtitleDocument::parse(b"1\n00:00:00,000 --> 00:00:03,000\nFirst corrected last\n",SubtitleFormat::Srt).unwrap();
    document.generated_words=vec![
        CaptionWord{cue_id:"cue-1".into(),range:span("0","1"),text:"First".into()},
        CaptionWord{cue_id:"cue-1".into(),range:span("1","2"),text:"corrected".into()},
        CaptionWord{cue_id:"cue-1".into(),range:span("2","3"),text:"last".into()},
    ];
    let settings=PresentationSettings{captions:Some(CaptionLayer{document,style:None,placement:None,burn_in:false}),..Default::default()};
    let mut p=prepared(&x,&src,&path,settings);
    p.set_assembly("main",Some(AssemblySettings{clips:vec![
        AssemblyClip{id:"all".into(),range:span("0","3"),speed:PlaybackSpeed::Normal},
        AssemblyClip{id:"repeat-correction".into(),range:span("1","2"),speed:PlaybackSpeed::Double},
    ],..Default::default()})).unwrap();p.review_assembly("main",Disposition::AutoApply,true).unwrap();
    let before=p.to_json().unwrap();let out=d.path().join("assembly.vtt");
    let result=x.export_subtitles(&p,"main",&path,&out,SubtitleFormat::WebVtt,&OutputPolicy::CreateNew,&Cancellation::new()).unwrap();
    assert_eq!(result.cue_parts,4);let text=fs::read(&out).unwrap();let parsed=SubtitleDocument::parse(&text,SubtitleFormat::WebVtt).unwrap();
    assert_eq!(parsed.cues.iter().map(|c|c.text.as_str()).collect::<Vec<_>>(),vec!["First","corrected","last","corrected"]);
    assert_eq!(parsed.cues[3].range,span("3","7/2"));assert_eq!(p.to_json().unwrap(),before);
}
