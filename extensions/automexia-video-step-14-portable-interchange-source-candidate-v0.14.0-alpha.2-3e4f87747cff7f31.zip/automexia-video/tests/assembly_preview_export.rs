//! Step 14A preview and interchange regressions. These exercise production Rust
//! plans/documents; media-reference fixtures are explicit, not execution claims.
use automexia_video::*;
use automexia_video::host::{FileStamp,InputFile,RuntimeCapabilities};
use automexia_video::interchange::*;
use automexia_video::preview::PreviewPlan;
use automexia_video::project::*;
use std::path::PathBuf;

fn r(text:&str)->Rational{text.parse().unwrap()}
fn rate()->EditRate{EditRate::new(r("30000/1001"),false).unwrap()}
fn frames(n:i64)->Rational{rate().seconds(n).unwrap()}
fn range(a:i64,b:i64)->TimeRange{TimeRange::new(frames(a),frames(b)).unwrap()}
fn location()->PathBuf{std::env::temp_dir().join("assembly-preview-export").join("project.amxv")}
fn input()->InputFile{InputFile{canonical_path:location().with_file_name("original & source.mp4"),stamp:FileStamp{size:100,modified_ns:None,sha256:"a".repeat(64),file_id:None}}}
fn media_info(count:i64)->MediaInfo{
    let mut info=automexia_video::media::parse_probe(include_bytes!("fixtures/probe-base.json")).unwrap();
    info.streams[0].duration_ts=Some(count*1001);info.streams[0].duration=Some(frames(count));
    info.streams[1].duration_ts=None;info.streams[1].duration=Some(frames(count));info.duration=Some(frames(count));info
}
fn project(count:i64)->Project{
    let info=media_info(count);let source=ProjectSource::from_probe("source-1",&input(),&info,info.select(StreamSelection::default()).unwrap(),&location()).unwrap();
    Project::new("assembly-export",source,ResolvedSettings{workflow:None,voice_cleanup:None,voice_enhancement:None,color_correction:None,pause_cleanup:None,preset_name:None,preset_revision:None,render:FrozenRenderSettings::from_options(&RenderOptions::default()).unwrap()}).unwrap()
}
fn clip(id:&str,a:i64,b:i64,speed:PlaybackSpeed)->AssemblyClip{AssemblyClip{id:id.into(),range:range(a,b),speed}}
fn assembled(pending:bool)->Project{
    let mut p=project(60);p.set_assembly("main",Some(AssemblySettings{clips:vec![clip("last",40,60,PlaybackSpeed::Normal),clip("first",0,20,PlaybackSpeed::Normal),clip("repeat",40,60,PlaybackSpeed::Normal)],..Default::default()})).unwrap();
    if !pending{p.review_assembly("main",Disposition::AutoApply,true).unwrap();}p
}
fn preview_request(p:&Project)->PreviewRequest{PreviewRequest::new(p,location(),location().parent().unwrap(),ReviewTarget::AssemblyVariant("main".into())).unwrap()}
fn export_request(format:InterchangeFormat)->ExportRequest{ExportRequest::new(location(),location().with_file_name(format!("timeline.{}",format.extension())),format,rate())}
fn export_media()->ExportMedia{
    let cancel=Cancellation::new();let mut verifier=CfrVerifier::new(input(),0,rate(),r("0"),frames(60),r("1/30000")).unwrap();
    for n in 0..60{verifier.feed(format!("pts={}\n",n*1001).as_bytes(),&cancel).unwrap();}
    ExportMedia{input:input(),info:media_info(60),timing:Some(verifier.finish(&cancel).unwrap()),baked_video:None,baked_audio:None}
}
fn caps()->RuntimeCapabilities{RuntimeCapabilities{
    encoders:["libx264","aac"].map(str::to_owned).into_iter().collect(),muxers:["mp4".into()].into_iter().collect(),
    bitstream_filters:["setts".into()].into_iter().collect(),supports_demux_time_base:true,
    filters:["settb","setpts","select","split","trim","fps","tpad","null","asetpts","aresample","apad","atrim","anull","asplit","concat","scale","setsar","atempo","format"].map(str::to_owned).into_iter().collect(),..Default::default()}}

#[test]
fn pending_assembly_preview_has_every_occurrence_without_approval(){
    let p=assembled(true);let original=p.to_json().unwrap();let prepared=PreviewPlan::build(&p,&preview_request(&p)).unwrap();
    let proposed=prepared.description().proposed_timeline.as_ref().unwrap();
    assert_eq!(proposed.segments.iter().map(|s|s.source_range).collect::<Vec<_>>(),vec![range(40,60),range(0,20),range(40,60)]);
    assert_eq!(proposed.duration,frames(60));assert!(prepared.description().omitted_pending_ids.is_empty());
    assert_eq!(p.to_json().unwrap(),original);assert!(matches!(p.timeline_for_variant("main"),Err(Error::UnresolvedEdits)));
}
#[test]
fn original_assembly_preview_is_chronological_and_deduplicated(){
    let p=assembled(true);let prepared=PreviewPlan::build(&p,&preview_request(&p)).unwrap();let before=&prepared.description().before_timeline;
    assert_eq!(before.segments.iter().map(|s|s.source_range).collect::<Vec<_>>(),vec![range(0,20),range(40,60)]);
    assert_eq!(before.duration,frames(40));assert!(prepared.description().notes.iter().any(|n|n.contains("once in chronological order")));
}
#[test]
fn disjoint_short_occurrences_do_not_play_the_long_source_gap(){
    let mut p=project(600);p.set_assembly("main",Some(AssemblySettings{clips:vec![clip("end",580,600,PlaybackSpeed::Normal),clip("start",0,20,PlaybackSpeed::Normal)],..Default::default()})).unwrap();
    let request=preview_request(&p);let prepared=PreviewPlan::build(&p,&request).unwrap();
    assert!(prepared.description().source_window.duration().unwrap()>request.options.max_window);
    assert_eq!(prepared.description().proposed_timeline.as_ref().unwrap().duration,frames(40));
}
#[test]
fn assembly_preview_rejects_ambiguous_source_boundary_focus(){
    let p=assembled(false);for focus in [PreviewFocus::StartBoundary,PreviewFocus::EndBoundary,PreviewFocus::At(frames(45))]{let mut q=preview_request(&p);q.focus=focus;assert!(matches!(PreviewPlan::build(&p,&q),Err(Error::Unsupported(_))));}
}
#[test]
fn repeated_proxy_duration_is_checked_before_host_work(){
    let p=assembled(true);let mut q=preview_request(&p);q.options.max_window=frames(50);q.options.context=r("0");
    assert!(matches!(PreviewPlan::build(&p,&q),Err(Error::Unsupported(_))));
}
#[test]
fn slow_occurrence_duration_is_checked_before_host_work(){
    let mut p=assembled(true);p.variants[0].assembly.as_mut().unwrap().clips[0].speed=PlaybackSpeed::Half;
    let mut q=preview_request(&p);q.options.max_window=frames(70);q.options.context=r("0");assert!(matches!(PreviewPlan::build(&p,&q),Err(Error::Unsupported(_))));
}
#[test]
fn mixed_speed_preview_keeps_exact_occurrence_durations(){
    let mut p=assembled(true);let clips=&mut p.variants[0].assembly.as_mut().unwrap().clips;clips[0].speed=PlaybackSpeed::Half;clips[2].speed=PlaybackSpeed::Double;
    let prepared=PreviewPlan::build(&p,&preview_request(&p)).unwrap();let timeline=prepared.description().proposed_timeline.as_ref().unwrap();
    assert_eq!(timeline.segments.iter().map(|s|s.output_range.duration().unwrap()).collect::<Vec<_>>(),vec![frames(40),frames(20),frames(10)]);
    assert_eq!(timeline.duration,frames(70));
}
#[test]
fn current_resolved_preview_discloses_pending_assembly_omission(){
    let p=assembled(true);let mut q=preview_request(&p);q.intent=PreviewIntent::CurrentResolved;let prepared=PreviewPlan::build(&p,&q).unwrap();
    assert_eq!(prepared.description().proposed_timeline.as_ref().unwrap().duration,frames(60));assert_eq!(prepared.description().proposed_timeline.as_ref().unwrap().segments.len(),1);
    assert!(prepared.description().omitted_pending_ids.contains(&"assembly:main".to_owned()));
}
#[test]
fn locked_ignored_assembly_is_not_enabled_hypothetically(){
    let mut p=assembled(true);p.review_assembly("main",Disposition::Ignore,false).unwrap();p.set_assembly_locked("main",true).unwrap();
    assert!(matches!(PreviewPlan::build(&p,&preview_request(&p)),Err(Error::LockedEdit)));
}
#[test]
fn assembly_target_cannot_preview_a_different_variant(){
    let p=assembled(true);let mut q=preview_request(&p);q.variant_id="other".into();assert!(PreviewPlan::build(&p,&q).is_err());
}
#[test]
fn ordinary_cut_preview_preserves_accepted_repeats_and_cuts_each_occurrence(){
    let mut p=assembled(false);let id=p.remove_range("source-1",range(45,50),"review repeated removal").unwrap();p.resolve_operation(&id,Disposition::NeedsReview).unwrap();
    let q=PreviewRequest::new(&p,location(),location().parent().unwrap(),ReviewTarget::Operation(id)).unwrap();let prepared=PreviewPlan::build(&p,&q).unwrap();
    let timeline=prepared.description().proposed_timeline.as_ref().unwrap();assert_eq!(timeline.duration,frames(50));assert_eq!(timeline.segments.len(),5);
    assert_eq!(timeline.segments[0].source_range,range(40,45));assert_eq!(timeline.segments[3].source_range,range(40,45));
    assert_eq!(prepared.description().before_timeline.duration,frames(40));
}
#[test]
fn removing_all_selected_assembly_media_yields_no_proposed_file(){
    let mut p=assembled(false);let id=p.remove_range("source-1",range(0,60),"remove all").unwrap();p.resolve_operation(&id,Disposition::NeedsReview).unwrap();
    let q=PreviewRequest::new(&p,location(),location().parent().unwrap(),ReviewTarget::Operation(id)).unwrap();let prepared=PreviewPlan::build(&p,&q).unwrap();assert!(prepared.description().proposed_timeline.is_none());
}
#[test]
fn proxy_render_plan_keeps_assembly_duration_and_branch_order(){
    let p=assembled(true);let prepared=PreviewPlan::build(&p,&preview_request(&p)).unwrap();let plan=prepared.render_plan(PreviewSide::Proposed,&media_info(60),&caps()).unwrap().unwrap();
    let edit=plan.edited_timeline().unwrap();assert_eq!(edit.duration,frames(60));
    let args=plan.arguments(&input().canonical_path,&location().with_file_name("proxy.mp4")).unwrap();let graph=args.windows(2).find(|w|w[0]=="-filter_complex").unwrap()[1].to_str().unwrap();
    assert!(graph.contains("concat"));assert!(graph.contains("split"));
}
#[test]
fn all_editable_formats_preserve_reorder_repeat_source_and_record_bounds(){
    let p=assembled(false);let original=p.to_json().unwrap();for format in [InterchangeFormat::Otio,InterchangeFormat::Fcp7Xml,InterchangeFormat::Edl]{
        let doc=build_export(&p,&export_request(format),&export_media()).unwrap();let clips=&doc.timeline().clips;
        assert_eq!(clips.iter().map(|c|(c.source_in,c.source_out,c.record_in,c.record_out)).collect::<Vec<_>>(),vec![(40,60,0,20),(0,20,20,40),(40,60,40,60)]);
        assert_eq!(doc.timeline().audio_pieces.iter().map(|a|a.source_start).collect::<Vec<_>>(),vec![Some(frames(40)),Some(frames(0)),Some(frames(40))]);
        assert!(doc.report().items.iter().any(|i|i.id=="assembly"&&i.representation==Representation::Preserved&&!i.blocking));
    }assert_eq!(p.to_json().unwrap(),original);
}
#[test]
fn repeated_source_marker_has_unique_identity_and_correct_record_times(){
    let p=assembled(false);for format in [InterchangeFormat::Otio,InterchangeFormat::Fcp7Xml,InterchangeFormat::Edl]{
        let mut q=export_request(format);q.markers.push(ExportMarker{id:"cue".into(),name:"Repeated note".into(),comment:"source marker".into(),at:frames(45),duration:frames(5)});
        let doc=build_export(&p,&q,&export_media()).unwrap();let markers=&doc.timeline().markers;
        assert_eq!(markers.iter().map(|m|m.at).collect::<Vec<_>>(),vec![frames(5),frames(45)]);assert_eq!(markers[0].duration,frames(5));assert_ne!(markers[0].id,markers[1].id);
    }
}
#[test]
fn pending_assembly_blocks_export_even_with_explicit_visual_bake(){
    let p=assembled(true);let mut q=export_request(InterchangeFormat::Otio);q.video=VisualExport::Bake{destination:location().with_file_name("bake.mov")};
    assert!(assess_export(&p,&q).unwrap().items.iter().any(|i|i.id=="assembly"&&i.blocking));
}
#[test]
fn per_occurrence_speed_requires_visual_bake_even_with_audio_stem(){
    let mut p=assembled(false);p.variants[0].assembly.as_mut().unwrap().clips[0].speed=PlaybackSpeed::Half;
    for format in [InterchangeFormat::Otio,InterchangeFormat::Fcp7Xml,InterchangeFormat::Edl]{let mut q=export_request(format);q.audio=AudioExport::BakeStem{destination:location().with_file_name("stem.wav")};
        assert!(assess_export(&p,&q).unwrap().items.iter().any(|i|i.id=="assembly"&&i.blocking));assert!(build_export(&p,&q,&export_media()).is_err());
        q.video=VisualExport::Bake{destination:location().with_file_name("bake.mov")};assert!(!assess_export(&p,&q).unwrap().blocked());
    }
}
#[test]
fn repeated_marker_limit_is_a_compatibility_block_before_optional_bake(){
    let mut p=assembled(false);p.variants[0].assembly.as_mut().unwrap().clips=(0..5).map(|n|clip(&format!("copy-{n}"),40,60,PlaybackSpeed::Normal)).collect();
    let mut q=export_request(InterchangeFormat::Otio);q.video=VisualExport::Bake{destination:location().with_file_name("bake.mov")};q.markers=(0..1024).map(|n|ExportMarker{id:format!("m-{n}"),name:String::new(),comment:String::new(),at:frames(45),duration:r("0")}).collect();
    assert!(assess_export(&p,&q).unwrap().items.iter().any(|i|i.id=="marker-occurrences"&&i.blocking));
}
#[test]
fn generated_otio_serializes_all_repeated_references(){
    let p=assembled(false);let doc=build_export(&p,&export_request(InterchangeFormat::Otio),&export_media()).unwrap();let value:serde_json::Value=serde_json::from_slice(doc.bytes()).unwrap();
    let video=&value["tracks"]["children"][1]["children"];assert_eq!(video.as_array().unwrap().len(),3);
    assert_eq!(video[0]["source_range"]["start_time"]["value"],40);assert_eq!(video[1]["source_range"]["start_time"]["value"],0);assert_eq!(video[2]["source_range"]["start_time"]["value"],40);
}
#[test]
fn xml_repeated_clip_instances_have_distinct_links_and_exact_bounds(){
    let doc=build_export(&assembled(false),&export_request(InterchangeFormat::Fcp7Xml),&export_media()).unwrap();let xml=roxmltree::Document::parse(std::str::from_utf8(doc.bytes()).unwrap()).unwrap();
    let videos:Vec<_>=xml.descendants().filter(|n|n.has_tag_name("clipitem")&&n.attribute("id").is_some_and(|id|id.starts_with('v'))).collect();assert_eq!(videos.len(),3);
    for (index,node) in videos.iter().enumerate(){let expected=format!("v{}",index+1);assert_eq!(node.attribute("id"),Some(expected.as_str()));}
    let starts:Vec<_>=videos.iter().map(|n|n.children().find(|c|c.has_tag_name("start")).unwrap().text().unwrap()).collect();assert_eq!(starts,vec!["0","20","40"]);
}
#[test]
fn explicit_source_splits_cannot_expand_repeated_interchange_without_bound(){
    let mut p=project(60);let step=frames(60).checked_div(r("512")).unwrap();
    p.assembly=(0..512).map(|n|KeepClip{id:format!("source-part-{n}"),source_id:"source-1".into(),range:TimeRange::new(step.ticks(n).unwrap(),step.ticks(n+1).unwrap()).unwrap(),locked:false}).collect();
    p.set_assembly("main",Some(AssemblySettings{clips:(0..64).map(|n|clip(&format!("occurrence-{n}"),0,60,PlaybackSpeed::Normal)).collect(),..Default::default()})).unwrap();p.review_assembly("main",Disposition::AutoApply,true).unwrap();
    assert!(matches!(assess_export(&p,&export_request(InterchangeFormat::Otio)),Err(Error::LimitExceeded("editable interchange clip occurrences"))));
}
#[test]
fn repeated_sequence_timecode_overflow_is_blocked_during_assessment(){
    let p=assembled(false);for bake in [false,true]{let mut q=export_request(InterchangeFormat::Otio);q.record_start_frames=rate().frames_per_day()-30;
        if bake{q.video=VisualExport::Bake{destination:location().with_file_name("bake.mov")};}
        assert!(assess_export(&p,&q).unwrap().items.iter().any(|item|item.id=="record-timecode-limit"&&item.blocking));
    }
}
#[test]
fn source_timecode_overflow_is_blocked_before_a_requested_audio_stem(){
    let p=assembled(false);let mut q=export_request(InterchangeFormat::Otio);q.source_start_frames=rate().frames_per_day()-30;q.audio=AudioExport::BakeStem{destination:location().with_file_name("stem.wav")};
    assert!(assess_export(&p,&q).unwrap().items.iter().any(|item|item.id=="source-timecode-limit"&&item.blocking));
}
#[test]
fn assembly_proposed_preview_retains_accepted_framing_only_on_proposed_side(){
    let mut p=assembled(true);p.set_variant_framing("main",Some(FramingSettings::fit(OutputSize::new(80,80).unwrap()).unwrap())).unwrap();p.decide_framing("main",FramingDecision::Approve).unwrap();
    let prepared=PreviewPlan::build(&p,&preview_request(&p)).unwrap();let mut runtime=caps();runtime.filters.insert("pad".into());
    let before=prepared.render_plan(PreviewSide::Before,&media_info(60),&runtime).unwrap().unwrap();let proposed=prepared.render_plan(PreviewSide::Proposed,&media_info(60),&runtime).unwrap().unwrap();
    assert!(before.framing().is_none());assert_eq!(proposed.framing().unwrap().settings().target,OutputSize::new(80,80).unwrap());
    assert_eq!(proposed.edited_timeline().unwrap().duration,frames(60));
}
#[test]
fn assembly_review_does_not_hypothetically_approve_pending_framing(){
    let mut p=assembled(true);p.set_variant_framing("main",Some(FramingSettings::fit(OutputSize::new(80,80).unwrap()).unwrap())).unwrap();
    let prepared=PreviewPlan::build(&p,&preview_request(&p)).unwrap();assert!(prepared.description().omitted_pending_ids.contains(&"framing:main".to_owned()));
    assert!(prepared.render_plan(PreviewSide::Proposed,&media_info(60),&caps()).unwrap().unwrap().framing().is_none());
}
#[test]
fn another_variants_pending_assembly_does_not_block_selected_export(){
    let mut p=assembled(false);p.add_output_variant("other",p.variants[0].render.clone(),None).unwrap();p.set_assembly("other",Some(AssemblySettings{clips:vec![clip("draft",0,20,PlaybackSpeed::Normal)],..Default::default()})).unwrap();
    let q=export_request(InterchangeFormat::Otio);assert!(!assess_export(&p,&q).unwrap().blocked());assert_eq!(build_export(&p,&q,&export_media()).unwrap().timeline().clips.len(),3);
}
