#![cfg(feature="native")]
//! Actual Rust planner -> FFmpeg -> decoded frame/sample verification.
use automexia_video::*;
use automexia_video::native::{NativeMediaHost,NativeSettings};
use automexia_video::timing::{PlaybackSpeed,TimingSettings};
use automexia_video::assembly::{AssemblyClip,AssemblySettings};
use std::{path::{Path,PathBuf},process::Command};
use tempfile::TempDir;
fn tool(name:&str)->PathBuf{std::env::var_os(name).map(PathBuf::from).unwrap_or_else(||PathBuf::from(if name=="FFMPEG"{"/usr/bin/ffmpeg"}else{"/usr/bin/ffprobe"}))}
fn run(command:&mut Command)->Vec<u8>{let out=command.output().unwrap();assert!(out.status.success(),"{}",String::from_utf8_lossy(&out.stderr));out.stdout}
fn fixture(dir:&Path)->PathBuf{let path=dir.join("source.mp4");run(Command::new(tool("FFMPEG")).args(["-v","error","-nostdin","-y","-f","lavfi","-i","color=c=red:size=160x96:rate=30:duration=1","-f","lavfi","-i","color=c=green:size=160x96:rate=30:duration=1","-f","lavfi","-i","color=c=blue:size=160x96:rate=30:duration=1","-f","lavfi","-i","sine=frequency=440:sample_rate=48000:duration=3","-filter_complex_threads","1","-filter_complex","[0:v][1:v][2:v]concat=n=3:v=1:a=0[v]","-map","[v]","-map","3:a","-c:v","libx264","-threads:v","2","-pix_fmt","yuv420p","-c:a","aac"]).arg(&path));path}
fn frames(path:&Path)->usize{let out=run(Command::new(tool("FFPROBE")).args(["-v","error","-threads","2","-select_streams","v:0","-show_entries","frame=pts","-of","csv=p=0"]).arg(path));String::from_utf8(out).unwrap().lines().filter(|line|!line.trim().trim_matches(',').is_empty()).count()}
fn render(speed:PlaybackSpeed,dissolve:bool)->(TempDir,PathBuf){let directory=TempDir::new().unwrap();let input=fixture(directory.path());let location=directory.path().join("project.amxv");let x=VideoExtension::new(NativeMediaHost::new(NativeSettings::new(tool("FFMPEG"),tool("FFPROBE"))).unwrap(),VideoSettings::default()).unwrap();let c=Cancellation::new();let mut p=x.create_project(&NewProjectRequest::new("timing",&input,&location),&c,&mut |_|{}).unwrap();if dissolve{p.set_keep_ranges("source-1",&[TimeRange::new("0".parse().unwrap(),"1".parse().unwrap()).unwrap(),TimeRange::new("2".parse().unwrap(),"3".parse().unwrap()).unwrap()]).unwrap();}p.set_timing("main",Some(TimingSettings{enabled:true,disposition:Disposition::AutoApply,locked:false,speed,dissolve:(if dissolve{"1/2"}else{"0"}).parse().unwrap()})).unwrap();p.review_timing("main",Disposition::AutoApply,true).unwrap();let out=directory.path().join("render.mp4");x.render_project(&p,&ProjectRenderRequest::new(&location,&out),&c,&mut |_|{}).unwrap();(directory,out)}
#[test]fn actual_half_speed_has_all_180_frames(){let (_dir,out)=render(PlaybackSpeed::Half,false);assert_eq!(frames(&out),180);}
#[test]fn actual_double_speed_has_45_frames(){let (_dir,out)=render(PlaybackSpeed::Double,false);assert_eq!(frames(&out),45);}
#[test]fn actual_dissolve_has_blended_pixels_and_shorter_clock(){let (_dir,out)=render(PlaybackSpeed::Normal,true);assert_eq!(frames(&out),45);let bytes=run(Command::new(tool("FFMPEG")).args(["-v","error","-nostdin","-threads","2","-i"]).arg(&out).args(["-vf","select=eq(n\\,23),scale=1:1:flags=area,format=rgb24","-frames:v","1","-f","rawvideo","pipe:1"]));assert_eq!(bytes.len(),3);assert!(bytes[0]>60&&bytes[2]>60&&bytes[1]<50,"blend {:?}",bytes);}

fn render_assembly(entries:&[(i64,i64,PlaybackSpeed)],global:PlaybackSpeed)->(TempDir,PathBuf,PathBuf){
    render_assembly_with_dissolve(entries,global,Rational::new(0,1).unwrap())
}
fn render_assembly_with_dissolve(entries:&[(i64,i64,PlaybackSpeed)],global:PlaybackSpeed,dissolve:Rational)->(TempDir,PathBuf,PathBuf){
    let directory=TempDir::new().unwrap();let input=fixture(directory.path());let before=std::fs::read(&input).unwrap();let location=directory.path().join("assembly.amxv");
    let x=VideoExtension::new(NativeMediaHost::new(NativeSettings::new(tool("FFMPEG"),tool("FFPROBE"))).unwrap(),VideoSettings::default()).unwrap();let c=Cancellation::new();
    let mut p=x.create_project(&NewProjectRequest::new("assembly",&input,&location),&c,&mut |_|{}).unwrap();
    let clips=entries.iter().enumerate().map(|(i,(start,end,speed))|AssemblyClip{id:format!("entry-{i}"),range:TimeRange::new(Rational::new(*start,1).unwrap(),Rational::new(*end,1).unwrap()).unwrap(),speed:*speed}).collect();
    p.set_assembly("main",Some(AssemblySettings{clips,..Default::default()})).unwrap();p.review_assembly("main",Disposition::AutoApply,true).unwrap();
    if global!=PlaybackSpeed::Normal||dissolve.positive(){p.set_timing("main",Some(TimingSettings{speed:global,dissolve,..Default::default()})).unwrap();p.review_timing("main",Disposition::AutoApply,true).unwrap();}
    let out=directory.path().join("assembly.mp4");x.render_project(&p,&ProjectRenderRequest::new(&location,&out),&c,&mut |_|{}).unwrap();
    let stem=directory.path().join("assembly.wav");x.export_audio_stem(&p,&AudioStemRequest::new(&location,&stem),&c,&mut |_|{}).unwrap();
    let pcm=run(Command::new(tool("FFMPEG")).args(["-v","error","-nostdin","-threads","2","-i"]).arg(&stem).args(["-map","0:a:0","-c:a","pcm_s16le","-f","s16le","pipe:1"]));
    let expected=p.timeline_for_variant("main").unwrap().duration.ceil_units(48000).unwrap();assert_eq!(pcm.len(),usize::try_from(expected).unwrap()*2);
    assert_eq!(std::fs::read(&input).unwrap(),before);(directory,out,stem)
}
fn pixel(path:&Path,index:usize)->Vec<u8>{run(Command::new(tool("FFMPEG")).args(["-v","error","-nostdin","-threads","2","-i"]).arg(path).args(["-vf",&format!("select=eq(n\\,{index}),scale=1:1:flags=area,format=rgb24"),"-frames:v","1","-f","rawvideo","pipe:1"]))}
#[test]
fn actual_reordered_repeated_entries_keep_order_and_exact_pcm_length(){
    let (_dir,out,_stem)=render_assembly(&[(2,3,PlaybackSpeed::Normal),(0,1,PlaybackSpeed::Normal),(2,3,PlaybackSpeed::Normal)],PlaybackSpeed::Normal);
    assert_eq!(frames(&out),90);let blue=pixel(&out,10);let red=pixel(&out,40);let repeated=pixel(&out,70);
    assert!(blue[2]>180&&blue[0]<50);assert!(red[0]>180&&red[2]<50);assert_eq!(blue,repeated);
}
#[test]
fn actual_mixed_entry_rates_have_correct_boundaries(){
    let (_dir,out,_stem)=render_assembly(&[(2,3,PlaybackSpeed::Half),(0,1,PlaybackSpeed::Double)],PlaybackSpeed::Normal);
    assert_eq!(frames(&out),75);let blue=pixel(&out,59);let red=pixel(&out,60);assert!(blue[2]>180&&red[0]>180);
}
#[test]
fn actual_composed_quarter_speed_is_120_frames_for_one_source_second(){
    let (_dir,out,_stem)=render_assembly(&[(0,1,PlaybackSpeed::Half)],PlaybackSpeed::Half);assert_eq!(frames(&out),120);
}
#[test]
fn actual_composed_four_times_speed_is_15_frames_for_two_source_seconds(){
    let (_dir,out,_stem)=render_assembly(&[(0,2,PlaybackSpeed::Double)],PlaybackSpeed::Double);assert_eq!(frames(&out),15);
}
#[test]
fn actual_mixed_speed_three_entry_dissolve_preserves_all_expected_pcm(){
    let (_dir,out,stem)=render_assembly_with_dissolve(&[(0,2,PlaybackSpeed::Half),(1,3,PlaybackSpeed::Double),(0,2,PlaybackSpeed::Normal)],PlaybackSpeed::Normal,Rational::new(1,5).unwrap());
    assert_eq!(frames(&out),198);
    let bytes=run(Command::new(tool("FFMPEG")).args(["-v","error","-nostdin","-threads","2","-i"]).arg(&stem).args(["-map","0:a:0","-c:a","pcm_s16le","-f","s16le","pipe:1"]));
    assert_eq!(bytes.len(),316800*2);
    let tail=&bytes[bytes.len()-48000..];assert!(tail.chunks_exact(2).any(|s|i16::from_le_bytes([s[0],s[1]]).unsigned_abs()>500));
}
