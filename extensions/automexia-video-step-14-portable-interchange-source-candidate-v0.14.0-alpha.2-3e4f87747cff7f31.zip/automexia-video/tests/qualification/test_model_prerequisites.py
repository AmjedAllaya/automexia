"""Configuration checks, not model inference or Rust tests."""
import importlib.util
from pathlib import Path
import tempfile
import unittest
ROOT=Path(__file__).resolve().parents[2]
spec=importlib.util.spec_from_file_location('model_qualification',ROOT/'tools/qualify_release.py')
q=importlib.util.module_from_spec(spec);spec.loader.exec_module(q)
class SelectedModels(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name);self.env={'VIDEO_MODEL_MANIFEST_SHA256':'a'*64}
  for key in ('VIDEO_MODEL_MANIFEST','VIDEO_MODEL_WEIGHTS','VIDEO_MODEL_NOTICES','VIDEO_ORT_LIBRARY'):
   path=self.root/key;path.write_bytes(b'explicit test placeholder, not a model');self.env[key]=str(path)
 def tearDown(self):self.tmp.cleanup()
 def test_complete_configuration_is_present_not_qualified(self):self.assertEqual(q.model_prerequisites(self.env),[])
 def test_missing_assets_block(self):self.assertEqual(len(q.model_prerequisites({})),5)
 def test_missing_weights_block(self):Path(self.env['VIDEO_MODEL_WEIGHTS']).unlink();self.assertIn('VIDEO_MODEL_WEIGHTS',q.model_prerequisites(self.env))
 def test_relative_runtime_blocks(self):self.env['VIDEO_ORT_LIBRARY']='local-runtime';self.assertIn('VIDEO_ORT_LIBRARY',q.model_prerequisites(self.env))
 def test_directory_is_not_weights(self):self.env['VIDEO_MODEL_WEIGHTS']=str(self.root);self.assertIn('VIDEO_MODEL_WEIGHTS',q.model_prerequisites(self.env))
 def test_placeholder_digest_blocks(self):self.env['VIDEO_MODEL_MANIFEST_SHA256']='REPLACE_ME';self.assertIn('VIDEO_MODEL_MANIFEST_SHA256',q.model_prerequisites(self.env))
 def test_symlink_runtime_blocks(self):
  p=self.root/'alias';p.symlink_to(self.env['VIDEO_ORT_LIBRARY']);self.env['VIDEO_ORT_LIBRARY']=str(p);self.assertIn('VIDEO_ORT_LIBRARY',q.model_prerequisites(self.env))
 def test_configuration_check_does_not_hash_or_load_test_bytes(self):
  before={p.name:p.read_bytes() for p in self.root.iterdir()};q.model_prerequisites(self.env);self.assertEqual(before,{p.name:p.read_bytes() for p in self.root.iterdir()})
if __name__=='__main__':unittest.main()
