"""Inventory tests use explicit synthetic Cargo output, never claim Cargo ran."""
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
from types import SimpleNamespace
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[2]
spec = importlib.util.spec_from_file_location('dependency_inventory', ROOT / 'tools/dependency_inventory.py')
d = importlib.util.module_from_spec(spec)
spec.loader.exec_module(d)


class InventoryTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        (self.root / 'Cargo.toml').write_text('[package]\nname="automexia-video"\nversion="0.13.0-alpha.5"\n')
        (self.root / 'Cargo.lock').write_text('version = 4\n[[package]]\nname="fixture"\nversion="1.0.0"\nsource="registry+example"\nchecksum="' + 'a'*64 + '"\n')
        self.data = {'resolve': {'root': 'root'}, 'packages': [
            {'id': 'root', 'name': 'automexia-video', 'version': '0.13.0-alpha.5'},
            {'id': 'dependency', 'name': 'fixture', 'version': '1.0.0', 'source': 'registry+example', 'license': 'MIT'},
        ]}
    def result(self):
        return SimpleNamespace(returncode=0, stdout=json.dumps(self.data).encode(), stderr=b'')
    def test_locked_all_feature_metadata_is_required(self):
        with patch.object(d.subprocess, 'run', return_value=self.result()) as command:
            report = d.inventory(self.root)
        self.assertEqual(command.call_args.args[0], ['cargo','metadata','--locked','--all-features','--format-version','1'])
        self.assertEqual(report['dependency_count'],1)
        self.assertEqual(report['dependencies'][0]['checksum'],'a'*64)
        self.assertEqual(report['dependencies'][0]['license'],'MIT')
    def test_missing_lock_does_not_invent_dependencies(self):
        (self.root / 'Cargo.lock').unlink()
        with self.assertRaises(ValueError):d.inventory(self.root)
    def test_failed_cargo_does_not_create_inventory(self):
        failure = SimpleNamespace(returncode=1, stdout=b'', stderr=b'not resolved')
        with patch.object(d.subprocess, 'run', return_value=failure), self.assertRaises(ValueError):
            d.inventory(self.root)
    def test_changed_lock_is_rejected(self):
        def changed(*args,**kwargs):
            (self.root/'Cargo.lock').write_text('version = 4\n')
            return self.result()
        with patch.object(d.subprocess,'run',side_effect=changed),self.assertRaises(ValueError):
            d.inventory(self.root)
    def test_unknown_license_stays_unknown(self):
        del self.data['packages'][1]['license']
        with patch.object(d.subprocess,'run',return_value=self.result()):
            self.assertIsNone(d.inventory(self.root)['dependencies'][0]['license'])
    def test_checksum_is_selected_by_package_source_and_version(self):
        self.data['packages'][1]['version']='2.0.0'
        with patch.object(d.subprocess,'run',return_value=self.result()):
            self.assertIsNone(d.inventory(self.root)['dependencies'][0]['checksum'])

if __name__ == '__main__':
    unittest.main()
