import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[2]
spec = importlib.util.spec_from_file_location('qualifier', ROOT / 'tools/qualify_release.py')
q = importlib.util.module_from_spec(spec)
spec.loader.exec_module(q)

class QualificationTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.base = Path(self.temp.name)
        self.source = self.base / 'source'
        self.source.mkdir()
        (self.source/'Cargo.toml').write_text('[package]\nname="automexia-video"\nversion="0.11.0-rc.1"\n')
        (self.source/'delivery-policy.json').write_text(json.dumps({'package_name':'automexia-video','package_version':'0.11.0-rc.1','milestone':11}))
        (self.source/'release-candidate.json').write_text(json.dumps({'package_version':'0.11.0-rc.1','step':11}))
        for name in q.SOURCE_DIRS:
            (self.source/name).mkdir()
        (self.source/'src/lib.rs').write_text('// fixture\n')
        self.output = self.base/'results'
        self.output.mkdir()
    def tearDown(self):
        self.temp.cleanup()
    def execute(self, code, timeout=5):
        return q.run_command('fixture', [sys.executable, '-c', code], self.source, self.output, timeout)
    def report(self, value):
        p=self.base/'case.json';p.write_text(json.dumps(value));return p
    def test_success_records_exit_log_and_digest(self):
        r=self.execute('print("executed")')
        self.assertEqual(r['status'],'passed');self.assertEqual(r['exit_code'],0)
        self.assertEqual(r['log_sha256'],q.sha(self.output/r['log']))
    def test_final_evidence_reopens_unchanged_log(self):
        r=self.execute('print("executed")')
        audit=q.evidence_integrity(self.output,[r])
        self.assertEqual(audit['status'],'passed');self.assertEqual(len(audit['verified']),1)
    def test_final_evidence_detects_changed_log(self):
        r=self.execute('print("executed")');(self.output/r['log']).write_text('changed')
        audit=q.evidence_integrity(self.output,[r])
        self.assertEqual(audit['status'],'failed');self.assertEqual(len(audit['errors']),1)
    def test_final_evidence_detects_missing_report(self):
        r={'name':'case','case_report':{'file':'missing.json','sha256':'a'*64}}
        self.assertEqual(q.evidence_integrity(self.output,[r])['status'],'failed')
    def test_final_evidence_rejects_escape_and_symlink(self):
        p=self.output/'link.log';p.symlink_to(self.source/'Cargo.toml')
        for name in ('../source/Cargo.toml','link.log'):
            r={'name':'case','log':name,'log_sha256':q.sha(self.source/'Cargo.toml')}
            self.assertEqual(q.evidence_integrity(self.output,[r])['status'],'failed')
    def test_failure_is_not_a_pass(self):
        self.assertEqual(self.execute('raise SystemExit(3)')['status'],'failed')
    def test_missing_executable_is_blocked(self):
        r=q.run_command('fixture',[str(self.base/'missing')],self.source,self.output,5)
        self.assertEqual(r['status'],'blocked');self.assertIsNone(r['exit_code'])
    def test_timeout_is_failed(self):
        r=self.execute('import time; time.sleep(10)',.05)
        self.assertEqual(r['reason'],'check_timeout');self.assertEqual(r['status'],'failed')
    def test_no_existing_log_overwrite(self):
        (self.output/'fixture.log').write_text('existing')
        with self.assertRaises(q.QualificationError):self.execute('pass')
        self.assertEqual((self.output/'fixture.log').read_text(),'existing')
    def test_large_log_is_failed_even_after_exit(self):
        with patch.object(q,'MAX_LOG',1024):
            r=self.execute('print("x"*8192)')
        self.assertEqual(r['reason'],'check_log_limit')
    def test_child_python_assertions_enabled(self):
        with patch.dict(os.environ,{'PYTHONOPTIMIZE':'1'}):
            self.assertEqual(self.execute('import sys; assert sys.flags.optimize == 0')['status'],'passed')
    def test_shell_text_not_interpreted(self):
        r=q.run_command('fixture',[sys.executable,'-c','import sys; print(sys.argv[1])','; touch UNEXPECTED'],self.source,self.output,5)
        self.assertEqual(r['status'],'passed');self.assertFalse((self.source/'UNEXPECTED').exists())
    def test_invalid_name_rejected(self):
        with self.assertRaises(q.QualificationError):q.run_command('../bad',['echo'],self.source,self.output,5)
    def test_zero_timeout_rejected(self):
        with self.assertRaises(q.QualificationError):self.execute('pass',0)
    def test_valid_case_totals(self):
        r=q.media_result(self.report({'passed':1,'failed':0,'cases':[{'status':'passed'}]}))
        self.assertEqual(r['passed'],1)
    def test_empty_case_totals_rejected(self):
        with self.assertRaises(q.QualificationError):q.media_result(self.report({'passed':0,'failed':0,'cases':[]}))
    def test_boolean_count_rejected(self):
        with self.assertRaises(q.QualificationError):q.media_result(self.report({'passed':True,'failed':False,'cases':[{'status':'passed'}]}))
    def test_failed_case_cannot_be_hidden(self):
        with self.assertRaises(q.QualificationError):q.media_result(self.report({'passed':1,'failed':0,'cases':[{'status':'failed'}]}))
    def test_count_mismatch_rejected(self):
        with self.assertRaises(q.QualificationError):q.media_result(self.report({'passed':2,'failed':0,'cases':[{'status':'passed'}]}))
    def test_missing_report_rejected(self):
        with self.assertRaises(q.QualificationError):q.media_result(self.base/'absent.json')
    def test_failed_total_rejected(self):
        with self.assertRaises(q.QualificationError):q.media_result(self.report({'passed':1,'failed':1,'cases':[{'status':'passed'}]}))
    def test_source_edit_changes_identity(self):
        a=q.source_identity(self.source);(self.source/'src/lib.rs').write_text('// changed')
        self.assertNotEqual(a,q.source_identity(self.source))
    def test_report_does_not_change_source_identity(self):
        a=q.source_identity(self.source);(self.source/'reports').mkdir();(self.source/'reports/x.json').write_text('{}')
        self.assertEqual(a,q.source_identity(self.source))
    def test_dependency_lock_in_identity(self):
        a=q.source_identity(self.source);(self.source/'Cargo.lock').write_text('version = 4\n')
        self.assertNotEqual(a,q.source_identity(self.source))
    @unittest.skipUnless(os.name=='posix','POSIX source symlink check')
    def test_source_symlink_rejected(self):
        (self.source/'src/link.rs').symlink_to(self.source/'src/lib.rs')
        with self.assertRaises(q.QualificationError):q.source_identity(self.source)
    def test_source_change_prevents_pass(self):
        self.assertEqual(q.outcome([{'status':'passed'}],False),('failed',1))
    def test_blocked_cannot_be_passed(self):
        self.assertEqual(q.outcome([{'status':'passed'},{'status':'blocked'}]),('blocked',2))
    def test_failure_dominates_missing_tool(self):
        self.assertEqual(q.outcome([{'status':'failed'},{'status':'blocked'}]),('failed',1))
    def test_no_checks_is_blocked(self):
        self.assertEqual(q.outcome([]),('blocked',2))
    def test_output_inside_source_rejected(self):
        with self.assertRaises(q.QualificationError):q.run(self.source,self.source/'out','rust',5)
    def test_existing_output_rejected(self):
        with self.assertRaises(q.QualificationError):q.run(self.source,self.output,'rust',5)
    def test_missing_cargo_written_honestly(self):
        with patch.object(q.shutil,'which',return_value=None):
            path,code=q.run(self.source,self.base/'missing-rust','rust',5)
        d=json.loads(path.read_text());self.assertEqual(code,2)
        self.assertFalse(d['release_ready']);self.assertEqual(d['checks'][0]['status'],'blocked')
    def test_missing_lock_written_honestly(self):
        with patch.object(q.shutil,'which',return_value='/fixture/tool'):
            path,code=q.run(self.source,self.base/'missing-lock','rust',5)
        self.assertEqual(code,2);self.assertIn('Cargo.lock',path.read_text())
    def test_optimized_runner_refuses(self):
        p=subprocess.run([sys.executable,'-O',str(ROOT/'tools/qualify_release.py'),'--source',str(self.source),'--output',str(self.base/'optimized'),'--suite','rust'],capture_output=True)
        self.assertNotEqual(p.returncode,0);self.assertFalse((self.base/'optimized').exists())

    def test_duplicate_totals_are_rejected(self):
        p=self.base/'duplicate.json';p.write_text('{"passed":0,"passed":1,"failed":0,"cases":[{"status":"passed"}]}')
        with self.assertRaises((q.QualificationError,ValueError)):q.media_result(p)
    def test_nonfinite_report_is_rejected(self):
        p=self.base/'nan.json';p.write_text('{"passed":1,"failed":0,"cases":[{"status":"passed","seconds":NaN}]}')
        with self.assertRaises((q.QualificationError,ValueError)):q.media_result(p)
    def test_report_symlink_rejected(self):
        p=self.report({'passed':1,'failed':0,'cases':[{'status':'passed'}]});link=self.base/'linked.json';link.symlink_to(p)
        with self.assertRaises(q.QualificationError):q.media_result(link)
    def test_ambiguous_case_arrays_rejected(self):
        p=self.report({'passed':1,'failed':0,'cases':[{'status':'passed'}],'tests':[{'status':'failed'}]})
        with self.assertRaises(q.QualificationError):q.media_result(p)
    def test_build_script_binds_identity(self):
        a=q.source_identity(self.source);(self.source/'build.rs').write_text('fn main(){}')
        self.assertNotEqual(a,q.source_identity(self.source))
    def test_toolchain_binds_identity(self):
        a=q.source_identity(self.source);(self.source/'rust-toolchain.toml').write_text('[toolchain]\nchannel="stable"\n')
        self.assertNotEqual(a,q.source_identity(self.source))
    def test_cargo_configuration_binds_identity(self):
        a=q.source_identity(self.source);(self.source/'.cargo').mkdir();(self.source/'.cargo/config.toml').write_text('[build]\nrustflags=["--cfg=anything"]\n')
        self.assertNotEqual(a,q.source_identity(self.source))
    def test_required_source_directory_missing(self):
        (self.source/'examples').rmdir()
        with self.assertRaises(q.QualificationError):q.source_identity(self.source)
    def test_log_limit_bounds_retained_bytes(self):
        with patch.object(q,'MAX_LOG',1024):r=self.execute('print("x"*8192)')
        self.assertEqual(r['status'],'failed');self.assertLessEqual((self.output/r['log']).stat().st_size,1024)
    def test_report_top_level_list_rejected(self):
        with self.assertRaises((q.QualificationError,ValueError)):q.media_result(self.report([]))

    def test_legacy_boolean_case_pass_is_accepted(self):
        p=self.report({'passed':1,'failed':0,'tests':[{'passed':True}]})
        self.assertEqual(q.media_result(p)['passed'],1)
    def test_legacy_boolean_case_failure_is_rejected(self):
        p=self.report({'passed':1,'failed':0,'tests':[{'passed':False}]})
        with self.assertRaises(q.QualificationError):q.media_result(p)
    def test_conflicting_case_statuses_are_rejected(self):
        p=self.report({'passed':1,'failed':0,'tests':[{'passed':False,'status':'passed'}]})
        with self.assertRaises(q.QualificationError):q.media_result(p)
    def test_string_true_is_not_boolean_pass(self):
        p=self.report({'passed':1,'failed':0,'tests':[{'passed':'true'}]})
        with self.assertRaises(q.QualificationError):q.media_result(p)
    def test_sample_change_binds_identity(self):
        a=q.source_identity(self.source);(self.source/'samples/input.mp4').write_bytes(b'fixture')
        self.assertNotEqual(a,q.source_identity(self.source))


    def test_current_step_is_not_hardcoded(self):
        (self.source/'delivery-policy.json').write_text(json.dumps({'package_name':'automexia-video','package_version':'0.12.0-rc.1','milestone':12}))
        (self.source/'release-candidate.json').write_text(json.dumps({'package_version':'0.12.0-rc.1','step':12}))
        (self.source/'Cargo.toml').write_text('[package]\nname="automexia-video"\nversion="0.12.0-rc.1"\n')
        with patch.object(q.shutil,'which',return_value=None):
            path,code=q.run(self.source,self.base/'step12','rust',5)
        self.assertEqual(code,2);self.assertEqual(json.loads(path.read_text())['step'],12)
    def test_policy_version_mismatch_prevents_output(self):
        p=self.source/'release-candidate.json';p.write_text('{"step":11,"package_version":"other"}')
        with self.assertRaises(q.QualificationError):q.run(self.source,self.base/'bad-version','rust',5)
        self.assertFalse((self.base/'bad-version').exists())
    def test_boolean_milestone_is_rejected(self):
        p=self.source/'delivery-policy.json';d=json.loads(p.read_text());d['milestone']=True;p.write_text(json.dumps(d))
        with self.assertRaises(q.QualificationError):q.run(self.source,self.base/'bool-step','rust',5)
    def test_missing_identity_is_not_guessed(self):
        (self.source/'delivery-policy.json').unlink()
        with self.assertRaises(q.QualificationError):q.run(self.source,self.base/'missing-policy','rust',5)
    def test_release_identity_changes_source_digest(self):
        a=q.source_identity(self.source);(self.source/'release-candidate.json').write_text('{}')
        self.assertNotEqual(a,q.source_identity(self.source))
    def test_duplicate_release_identity_is_rejected(self):
        (self.source/'release-candidate.json').write_text('{"step":11,"step":12,"package_version":"0.11.0-rc.1"}')
        with self.assertRaises(q.QualificationError):q.run(self.source,self.base/'duplicate-policy','rust',5)


    def test_overflowing_json_float_is_rejected(self):
        p=self.base/'overflow.json'
        p.write_text('{"passed":1,"failed":0,"cases":[{"status":"passed","seconds":1e999}]}')
        with self.assertRaises(q.QualificationError):q.media_result(p)
    def test_blocked_case_is_reported_separately(self):
        p=self.report({'passed':1,'failed':0,'blocked':1,'cases':[{'status':'passed'},{'status':'blocked','reason':'UID switching unavailable'}]})
        self.assertEqual(q.media_result(p)['blocked'],1)
    def test_blocked_case_needs_reason(self):
        p=self.report({'passed':1,'failed':0,'blocked':1,'cases':[{'status':'passed'},{'status':'blocked'}]})
        with self.assertRaises(q.QualificationError):q.media_result(p)
    def test_blocked_case_cannot_claim_pass(self):
        p=self.report({'passed':1,'failed':0,'blocked':1,'cases':[{'status':'passed'},{'status':'blocked','passed':True,'reason':'missing'}]})
        with self.assertRaises(q.QualificationError):q.media_result(p)
    def test_blocked_count_cannot_hide_failed_row(self):
        p=self.report({'passed':1,'failed':0,'blocked':1,'cases':[{'status':'passed'},{'status':'failed','reason':'failed'}]})
        with self.assertRaises(q.QualificationError):q.media_result(p)
    def test_boolean_blocked_count_is_rejected(self):
        p=self.report({'passed':1,'failed':0,'blocked':False,'cases':[{'status':'passed'}]})
        with self.assertRaises(q.QualificationError):q.media_result(p)
    def test_ci_configuration_binds_identity(self):
        a=q.source_identity(self.source)
        (self.source/'.github').mkdir();(self.source/'.github/workflow.yml').write_text('name: changed')
        self.assertNotEqual(a,q.source_identity(self.source))
    def test_architecture_policy_binds_identity(self):
        a=q.source_identity(self.source);(self.source/'architecture-policy.json').write_text('{}')
        self.assertNotEqual(a,q.source_identity(self.source))
    def test_child_target_is_outside_source(self):
        r=self.execute('import os; print(os.environ["CARGO_TARGET_DIR"])')
        self.assertEqual((self.output/r['log']).read_text().strip(),str(self.output/'cargo-target'))
    def test_child_temporary_files_stay_outside_source(self):
        before=sorted(p.relative_to(self.source).as_posix() for p in self.source.rglob('*'))
        r=self.execute('import tempfile, pathlib, os, json; p=pathlib.Path(tempfile.mkdtemp()); (p/"fixture.bin").write_bytes(b"media"); print(json.dumps({"path":str(p),"env":[os.environ[k] for k in ("TMPDIR","TEMP","TMP")]}))')
        data=json.loads((self.output/r['log']).read_text())
        self.assertEqual(r['status'],'passed')
        self.assertEqual(Path(data['path']).parent,self.output/'tmp')
        self.assertEqual(data['env'],[str(self.output/'tmp')]*3)
        self.assertEqual(before,sorted(p.relative_to(self.source).as_posix() for p in self.source.rglob('*')))
    def test_full_media_matrix_includes_assembly_and_previous_adapters(self):
        self.assertEqual(len(q.MEDIA),19)
        self.assertIn('enhancement',q.MEDIA);self.assertIn('face',q.MEDIA)
        self.assertIn('timing',q.MEDIA);self.assertIn('hdr',q.MEDIA)
        self.assertIn('assembly',q.MEDIA)
        self.assertIn('fcpxml',q.MEDIA)
        self.assertIn('bundle',q.MEDIA)
        self.assertEqual(len(q.MEDIA),len(set(q.MEDIA)))


    def test_missing_rust_blocks_all_actual_interchange_readback_layers(self):
        with patch.object(q.shutil,'which',return_value=None),patch.object(q,'MEDIA',[]):
            path,code=q.run(self.source,self.base/'no-readers','media',5)
        checks={row['name']:row for row in json.loads(path.read_text())['checks']}
        self.assertEqual(code,2)
        for name in ('rust-interchange-readback','rust-fcpxml-readback','rust-bundle-readback'):
            self.assertEqual(checks[name]['status'],'blocked')
    def test_rust_readback_uses_actual_exports_and_propagates_blocked_schema(self):
        (self.source/'Cargo.lock').write_text('version = 4\n')
        calls=[]
        def command(name,argv,*args,**kwargs):
            calls.append((name,[str(a) for a in argv]))
            if name.endswith('-readback'):
                report={'passed':1,'failed':0,'cases':[{'status':'passed'}]}
                if name=='rust-fcpxml-readback':
                    report['blocked']=1
                    report['cases'].append({'status':'blocked','reason':'official DTD absent'})
                Path(argv[-1]).write_text(json.dumps(report))
            return {'name':name,'status':'passed'}
        with patch.object(q.shutil,'which',return_value='/fixture/tool'),patch.object(q,'MEDIA',[]),patch.object(q,'run_command',side_effect=command):
            path,code=q.run(self.source,self.base/'actual-readers','media',5)
        checks={row['name']:row for row in json.loads(path.read_text())['checks']}
        self.assertEqual(code,2)
        self.assertEqual(checks['rust-fcpxml-readback']['status'],'blocked')
        self.assertEqual(checks['rust-bundle-readback']['status'],'passed')
        commands=dict(calls)
        self.assertIn('bundle_fixture',commands['rust-bundle-generate'])
        self.assertEqual(commands['rust-bundle-readback'].count('--rust-bundle'),3)
        self.assertIn('--rust-exports',commands['rust-fcpxml-readback'])

    def test_rust_matrix_compiles_every_feature_and_reports_missing_models(self):
        (self.source/'Cargo.lock').write_text('version = 4\n')
        font=self.base/'font.ttf';font.write_bytes(b'fixture')
        for path in ('Cargo.toml','delivery-policy.json','release-candidate.json'):
            f=self.source/path;f.write_text(f.read_text().replace('0.11.0-rc.1','0.13.0-alpha.5').replace('"milestone": 11','"milestone": 13').replace('"step": 11','"step": 13'))
        calls=[]
        def command(name,argv,*args,**kwargs):
            calls.append((name,argv));return {'name':name,'status':'passed'}
        with patch.object(q.shutil,'which',return_value='/fixture/tool'),patch.object(q,'run_command',side_effect=command),patch.dict(os.environ,{'VIDEO_TEST_FONT':str(font)},clear=True):
            path,code=q.run(self.source,self.base/'full-rust','rust',5)
        self.assertIn(('cargo-all-feature-compile',['cargo','check','--locked','--all-features','--all-targets']),calls)
        self.assertIn(('cargo-all-feature-library',['cargo','test','--locked','--all-features','--lib']),calls)
        report=json.loads(path.read_text());self.assertEqual(code,2)
        checks={r['name']:r for r in report['checks']}
        for name in ('cargo-selected-model','cargo-selected-face','cargo-selected-whisper'):
            self.assertEqual(checks[name]['status'],'blocked')
        self.assertFalse(report['release_ready'])
    def test_selected_assets_are_explicit_regular_files(self):
        p=self.base/'weights';p.write_bytes(b'fixture')
        env={'MODEL':str(p),'SHA':'a'*64}
        self.assertEqual(q.explicit_assets(env,['MODEL'],['SHA']),[])
        env['MODEL']='relative';self.assertEqual(q.explicit_assets(env,['MODEL']),['MODEL'])
    def test_asset_symlink_is_rejected(self):
        p=self.base/'weights';p.write_bytes(b'fixture');link=self.base/'link';link.symlink_to(p)
        self.assertEqual(q.explicit_assets({'MODEL':str(link)},['MODEL']),['MODEL'])
    def test_selected_model_digest_requires_lowercase_sha256(self):
        self.assertEqual(q.explicit_assets({'SHA':'A'*64},[],['SHA']),['SHA'])
    def test_face_dimensions_are_bounded(self):
        for value in ('0','-1','8193','100000','1.0','True'):
            missing=q.face_prerequisites({'FACE_FIXTURE_WIDTH':value,'FACE_FIXTURE_HEIGHT':'240'})
            self.assertIn('FACE_FIXTURE_WIDTH',missing);self.assertNotIn('FACE_FIXTURE_HEIGHT',missing)

if __name__=='__main__':unittest.main()
