use automexia_video::{EnhancementIdentity,EnhancementMode,EnhancementReceipt,EnhancementSettings,EnhancementStrength};

fn identity()->EnhancementIdentity{EnhancementIdentity{engine:"fixture".into(),engine_version:"1".into(),runtime:"cpu".into(),model_id:Some("model".into()),model_sha256:Some("a".repeat(64))}}
fn receipt()->EnhancementReceipt{EnhancementReceipt{identity:identity(),sample_rate:48_000,channels:2,channel_layout:"stereo".into(),source_samples:96_000,output_samples:96_000,delay_samples:0,peak_dbfs:Some(-3.0),warnings:vec![]}}

#[test] fn preserve_does_not_require_speech_confirmation(){EnhancementSettings::default().validate().unwrap();}
#[test] fn learned_requires_explicit_speech_only_confirmation(){let s=EnhancementSettings{mode:EnhancementMode::Learned,strength:EnhancementStrength::Balanced,speech_only_confirmed:false,max_delay_samples:0};assert!(s.validate().is_err());}
#[test] fn receipt_must_preserve_sample_count_when_delay_is_zero(){let s=EnhancementSettings{mode:EnhancementMode::Learned,strength:EnhancementStrength::Gentle,speech_only_confirmed:true,max_delay_samples:0};receipt().validate(&s).unwrap();let mut r=receipt();r.output_samples-=1;assert!(r.validate(&s).is_err());}
#[test] fn model_identity_is_exact(){let mut i=identity();i.model_sha256=Some("bad".into());assert!(i.validate().is_err());}
#[test] fn warnings_are_bounded(){let s=EnhancementSettings{mode:EnhancementMode::Learned,strength:EnhancementStrength::Strong,speech_only_confirmed:true,max_delay_samples:0};let mut r=receipt();r.warnings=(0..33).map(|i|format!("w{i}")).collect();assert!(r.validate(&s).is_err());}

use automexia_video::*;
use automexia_video::host::{FileStamp,MediaTask,ToolOutput};
use automexia_video::project::{FrozenRenderSettings,ProjectSource,ResolvedSettings};
use std::{path::{Path,PathBuf},sync::{Arc,Mutex},time::Duration};
fn test_project_file()->PathBuf{std::env::temp_dir().join("enhancement-contract").join("project.amxv")}
fn test_input()->InputFile{InputFile{canonical_path:test_project_file().with_file_name("input.mov"),stamp:FileStamp{size:100,modified_ns:None,sha256:"a".repeat(64),file_id:None}}}
fn test_project()->Project {
    let media=automexia_video::media::parse_probe(include_bytes!("fixtures/probe-base.json")).unwrap();
    let source=ProjectSource::from_probe("source-1",&test_input(),&media,media.select(StreamSelection::default()).unwrap(),&test_project_file()).unwrap();
    Project::new("enhancement-test",source,ResolvedSettings{workflow:None,preset_name:None,preset_revision:None,pause_cleanup:None,voice_cleanup:None,voice_enhancement:None,color_correction:None,render:FrozenRenderSettings::from_options(&RenderOptions::default()).unwrap()}).unwrap()
}
fn learned()->EnhancementSettings{EnhancementSettings{mode:EnhancementMode::Learned,speech_only_confirmed:true,..Default::default()}}
#[derive(Default)]struct State{published:bool,cancel_at_commit:bool,probe_samples:u64,probe_origin:Option<String>,inspect_published:usize,delay_inspection:bool,inspection_saw_deadline:bool}
struct Host{state:Arc<Mutex<State>>}
struct Lease{path:PathBuf,destination:PathBuf,state:Arc<Mutex<State>>}
impl OutputLease for Lease{
    fn path(&self)->&Path{&self.path}
    fn publish(self:Box<Self>,cancel:&Cancellation)->Result<PathBuf>{cancel.check()?;let mut state=self.state.lock().unwrap();state.published=true;if state.cancel_at_commit{cancel.cancel();}Ok(self.destination.clone())}
}
impl MediaHost for Host{
    fn inspect_input(&self,path:&Path,cancel:&Cancellation)->Result<InputFile>{
        let delay=self.state.lock().unwrap().delay_inspection;
        if delay{std::thread::sleep(Duration::from_millis(150));}
        let checked=cancel.check();
        if delay{self.state.lock().unwrap().inspection_saw_deadline=matches!(&checked,Err(Error::Timeout));}
        checked?;if path==test_input().canonical_path{return Ok(test_input());}let mut state=self.state.lock().unwrap();if state.published{state.inspect_published+=1;}Ok(InputFile{canonical_path:path.to_owned(),stamp:FileStamp{size:288000,modified_ns:Some(1234),sha256:"b".repeat(64),file_id:Some("private-inode".into())}})}
    fn revalidate_input(&self,_:&InputFile,cancel:&Cancellation)->Result<()>{cancel.check()}
    fn runtime_capabilities(&self,_:&Cancellation)->Result<RuntimeCapabilities>{Ok(RuntimeCapabilities::default())}
    fn run(&self,task:&MediaTask,cancel:&Cancellation,_:&mut ProgressSink<'_>)->Result<ToolOutput>{cancel.check()?;match task{MediaTask::Probe{..}=>Ok(ToolOutput{stdout:include_bytes!("fixtures/probe-base.json").to_vec()}),_=>Err(Error::Unsupported("fixture operation"))}}
    fn stage_output(&self,_:&InputFile,destination:&Path,_:&OutputPolicy,cancel:&Cancellation)->Result<Box<dyn OutputLease>>{cancel.check()?;Ok(Box::new(Lease{path:destination.with_file_name("staged.wav"),destination:destination.to_owned(),state:self.state.clone()}))}
    fn run_audio(&self,task:&automexia_video::voice_render::AudioTask,cancel:&Cancellation,_:&mut ProgressSink<'_>)->Result<ToolOutput>{cancel.check()?;match task{
        automexia_video::voice_render::AudioTask::ProbeStem{..}=>{let state=self.state.lock().unwrap();let mut audio=serde_json::json!({"index":0,"codec_type":"audio","codec_name":"pcm_s24le","sample_rate":"48000","channels":1,"channel_layout":"mono","time_base":"1/48000","duration_ts":state.probe_samples});if let Some(origin)=&state.probe_origin{audio["start_time"]=origin.clone().into();}Ok(ToolOutput{stdout:serde_json::to_vec(&serde_json::json!({"format":{"format_name":"wav"},"streams":[audio]})).unwrap()})},
        automexia_video::voice_render::AudioTask::ValidateStem{..}=>Ok(ToolOutput{stdout:vec![]}),_=>Err(Error::Unsupported("fixture audio operation")),}}
}
struct Provider{bad_count:bool,panic:bool,notify:bool}
impl SpeechEnhancer for Provider{
    fn identity(&self)->Result<EnhancementIdentity>{Ok(identity())}
    fn enhance(&self,request:&EnhancementRequest,cancel:&Cancellation,progress:&mut ProgressSink<'_>)->Result<EnhancementReceipt>{assert!(request.timeout<=Duration::from_secs(10));request.validate()?;cancel.check()?;if self.panic{panic!("fixture provider");}if self.notify{progress(automexia_video::progress::Progress::stage(automexia_video::progress::Stage::EnhancingAudio));}Ok(EnhancementReceipt{identity:identity(),sample_rate:request.sample_rate,channels:request.channels,channel_layout:request.channel_layout.clone(),source_samples:request.source_samples,output_samples:request.source_samples-if self.bad_count{1}else{0},delay_samples:0,peak_dbfs:None,warnings:vec![]})}
}
fn run_fixture(state:Arc<Mutex<State>>,provider:Provider,cancel:&Cancellation,progress:&mut ProgressSink<'_>)->Result<EnhancementRunResult>{let x=VideoExtension::new(Host{state},VideoSettings::default()).unwrap();let mut req=EnhancementRunRequest::new(test_project_file(),test_project_file().with_file_name("enhanced.wav"));req.settings=learned();req.timeout=Duration::from_secs(10);x.enhance_voice(&test_project(),&req,&provider,cancel,progress)}
fn state()->Arc<Mutex<State>>{Arc::new(Mutex::new(State{probe_samples:test_project().sources[0].duration.ceil_units(48000).unwrap() as u64,..Default::default()}))}
fn provider()->Provider{Provider{bad_count:false,panic:false,notify:false}}
#[test]fn enhanced_receipt_is_validated_before_publication(){let state=state();let result=run_fixture(state.clone(),provider(),&Cancellation::new(),&mut |_|{}).unwrap();result.enhancement.check_source(&test_project().sources[0]).unwrap();assert!(state.lock().unwrap().published);assert_eq!(result.enhancement.stem_stamp.file_id,None);assert_eq!(result.enhancement.stem_stamp.modified_ns,None);}
#[test]fn cancellation_during_successful_commit_returns_committed_receipt(){let state=state();state.lock().unwrap().cancel_at_commit=true;let cancel=Cancellation::new();let result=run_fixture(state.clone(),provider(),&cancel,&mut |_|{}).unwrap();assert_eq!(result.enhancement.source_origin,Some(test_project().sources[0].timeline_origin));assert!(state.lock().unwrap().published);assert_eq!(state.lock().unwrap().inspect_published,0);}
#[test]fn wrong_provider_count_never_commits(){let state=state();let mut p=provider();p.bad_count=true;assert!(run_fixture(state.clone(),p,&Cancellation::new(),&mut |_|{}).is_err());assert!(!state.lock().unwrap().published);}
#[test]fn wrong_decoded_sample_count_never_commits(){let state=state();state.lock().unwrap().probe_samples=95999;assert!(run_fixture(state.clone(),provider(),&Cancellation::new(),&mut |_|{}).is_err());assert!(!state.lock().unwrap().published);}
#[test]fn nonzero_stem_origin_never_commits(){let state=state();state.lock().unwrap().probe_origin=Some("1".into());assert!(run_fixture(state.clone(),provider(),&Cancellation::new(),&mut |_|{}).is_err());assert!(!state.lock().unwrap().published);}
#[test]fn provider_panic_is_contained_and_no_output_commits(){let state=state();let mut p=provider();p.panic=true;assert!(matches!(run_fixture(state.clone(),p,&Cancellation::new(),&mut |_|{}),Err(Error::Io(_))));assert!(!state.lock().unwrap().published);}
#[test]fn enhancement_progress_panic_is_contained(){let state=state();let error=run_fixture(state.clone(),provider(),&Cancellation::new(),&mut |_|panic!("progress")).unwrap_err();assert_eq!(error,Error::CallbackPanicked);assert!(!state.lock().unwrap().published);}
#[test]fn saved_enhancement_rejects_changed_layout_duration_and_origin(){let mut p=test_project();let result=run_fixture(state(),provider(),&Cancellation::new(),&mut |_|{}).unwrap();p.set_voice_enhancement(Some(result.enhancement)).unwrap();for n in 0..3{let mut q=p.clone();match n{0=>q.settings.voice_enhancement.as_mut().unwrap().receipt.channel_layout="stereo".into(),1=>q.settings.voice_enhancement.as_mut().unwrap().receipt.source_samples-=1,_=>q.settings.voice_enhancement.as_mut().unwrap().source_origin=Some("1".parse().unwrap())}assert!(q.validate().is_err());}}
#[test]fn provider_progress_panic_is_contained_before_publication(){let state=state();let mut p=provider();p.notify=true;let mut events=0;let result=run_fixture(state.clone(),p,&Cancellation::new(),&mut |e|{if e.stage==automexia_video::progress::Stage::EnhancingAudio{events+=1;if events==2{panic!("provider progress");}}});assert_eq!(result.unwrap_err(),Error::CallbackPanicked);assert!(!state.lock().unwrap().published);}
#[test]fn legacy_receipt_migrates_without_inventing_source_origin(){let mut p=test_project();let mut enhancement=run_fixture(state(),provider(),&Cancellation::new(),&mut |_|{}).unwrap().enhancement;enhancement.source_origin=None;p.set_voice_enhancement(Some(enhancement)).unwrap();let mut value=serde_json::to_value(&p).unwrap();value["schema_version"]=8.into();let loaded=Project::from_json(&serde_json::to_vec(&value).unwrap()).unwrap();assert!(loaded.settings.voice_enhancement.unwrap().source_origin.is_none());}

#[test]
fn initial_host_inspection_observes_total_deadline_for_all_audio_workflows(){
    for operation in 0..3 {
        let state=state();state.lock().unwrap().delay_inspection=true;
        let extension=VideoExtension::new(Host{state:state.clone()},VideoSettings::default()).unwrap();
        let project=test_project();let cancel=Cancellation::new();let timeout=Duration::from_millis(100);
        let result=match operation {
            0=>{let mut request=EnhancementRunRequest::new(test_project_file(),test_project_file().with_file_name("enhanced.wav"));request.settings=learned();request.timeout=timeout;extension.enhance_voice(&project,&request,&provider(),&cancel,&mut |_|{}).map(|_|())},
            1=>{let mut request=VoiceAnalysisRequest::new(test_project_file());request.timeout=timeout;extension.analyze_voice(&project,&request,&cancel,&mut |_|{}).map(|_|())},
            _=>{let mut request=AudioStemRequest::new(test_project_file(),test_project_file().with_file_name("stem.wav"));request.timeout=timeout;extension.export_audio_stem(&project,&request,&cancel,&mut |_|{}).map(|_|())},
        };
        assert_eq!(result,Err(Error::Timeout));
        assert!(state.lock().unwrap().inspection_saw_deadline,"the initial host operation must receive the total deadline");
        assert!(!state.lock().unwrap().published);
        assert!(!cancel.is_cancelled(),"an operation deadline must not expire its long-lived caller token");
    }
}
