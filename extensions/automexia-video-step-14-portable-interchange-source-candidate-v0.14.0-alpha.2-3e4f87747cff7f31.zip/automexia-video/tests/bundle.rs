//! Portable-plan checks do not read files or claim editor/native qualification.
use automexia_video::*;
use automexia_video::bundle::*;
use automexia_video::host::*;
use automexia_video::interchange::*;
use automexia_video::project::*;
use sha2::{Digest, Sha256};
use std::path::PathBuf;

fn r(value: &str) -> Rational { value.parse().unwrap() }
fn rate() -> EditRate { EditRate::new(r("30000/1001"), false).unwrap() }
fn directory() -> PathBuf { std::env::temp_dir().join("amx-bundle-plan-tests") }
fn project_file() -> PathBuf { directory().join("project.amxv") }
fn input() -> InputFile {
    InputFile { canonical_path: directory().join("original & α.MOV"),
        stamp: FileStamp { size: 100, modified_ns: Some(12), sha256: "a".repeat(64), file_id: Some("device:7".into()) } }
}
fn info() -> MediaInfo {
    let mut value: serde_json::Value = serde_json::from_slice(include_bytes!("fixtures/probe-base.json")).unwrap();
    value["streams"][1]["duration_ts"] = serde_json::json!(96096);
    value["streams"][1]["duration"] = serde_json::json!("2.002000");
    automexia_video::media::parse_probe(&serde_json::to_vec(&value).unwrap()).unwrap()
}
fn project() -> Project {
    let media = info();
    let source = ProjectSource::from_probe("source-1", &input(), &media,
        media.select(StreamSelection::default()).unwrap(), &project_file()).unwrap();
    Project::new("edit-1", source, ResolvedSettings { workflow: None, voice_cleanup: None,
        voice_enhancement: None, color_correction: None, pause_cleanup: None, preset_name: None,
        preset_revision: None, render: FrozenRenderSettings::from_options(&RenderOptions::default()).unwrap() }).unwrap()
}
fn evidence() -> CfrEvidence {
    evidence_for(input())
}
fn evidence_for(input: InputFile) -> CfrEvidence {
    let cancel = Cancellation::new();
    let mut verifier = CfrVerifier::new(input, 0, rate(), r("0"), r("2.002"), r("1/30000")).unwrap();
    for n in 0..60 { verifier.feed(format!("pts={}\n", n * 1001).as_bytes(), &cancel).unwrap(); }
    verifier.finish(&cancel).unwrap()
}
fn request() -> BundleRequest {
    BundleRequest::new(project_file(), directory().join("handoff.zip"), InterchangeFormat::Otio, rate())
}
fn document(request: &BundleRequest) -> ExportDocument {
    let export = request.to_export_request(&directory().join("private")).unwrap();
    build_export(&project(), &export, &ExportMedia { input: input(), info: info(), timing: Some(evidence()),
        baked_video: None, baked_audio: None }).unwrap()
}
fn plan() -> BundlePlan { let request = request(); BundlePlan::from_document(&document(&request), &request).unwrap() }
fn static_bytes<'a>(plan: &'a BundlePlan, name: &str) -> &'a [u8] {
    match plan.entries().iter().find(|entry| entry.name() == name).unwrap() {
        BundleEntry::Bytes(entry) => entry.bytes(), _ => panic!("expected metadata"),
    }
}

#[test] fn request_roundtrip_and_default_budget() {
    let request = request();
    let mut json = serde_json::to_value(&request).unwrap(); json.as_object_mut().unwrap().remove("max_total_bytes");
    let read = BundleRequest::from_json(&serde_json::to_vec(&json).unwrap()).unwrap();
    assert_eq!(read.max_total_bytes, DEFAULT_BUNDLE_BYTES);
    assert_eq!(read.to_export_request(&directory().join("private")).unwrap().paths, PathMode::RelativeToExport);
}
#[test] fn unknown_fields_and_duplicate_keys_are_rejected() {
    let mut json = serde_json::to_value(request()).unwrap(); json["output_policy"] = serde_json::json!("replace");
    assert!(BundleRequest::from_json(&serde_json::to_vec(&json).unwrap()).is_err());
    assert!(BundleRequest::from_json(b"{\"name\":\"a\",\"name\":\"b\"}").is_err());
}
#[test] fn external_bake_destinations_cannot_enter_request_schema() {
    let mut json = serde_json::to_value(request()).unwrap();
    json["video"] = serde_json::json!({"mode":"bake","destination":"/outside.mov"});
    assert!(BundleRequest::from_json(&serde_json::to_vec(&json).unwrap()).is_err());
}
#[test] fn private_bake_paths_are_deterministic_and_create_new() {
    let mut request = request(); request.video = BundleVideo::Bake; request.audio = BundleAudio::BakeStem;
    let workspace = directory().join("private"); let export = request.to_export_request(&workspace).unwrap();
    assert_eq!(export.destination, workspace.join("timeline.otio"));
    assert!(matches!(export.output_policy, OutputPolicy::CreateNew));
    assert!(matches!(export.video, VisualExport::Bake { destination } if destination == workspace.join("Media/video.mov")));
    assert!(matches!(export.audio, AudioExport::BakeStem { destination } if destination == workspace.join("Media/audio.wav")));
}
#[test] fn legacy_formats_are_not_claimed_portable() {
    for format in [InterchangeFormat::Fcp7Xml, InterchangeFormat::Edl] {
        let mut request = request(); request.format = format; assert!(request.validate().is_err());
    }
}
#[test] fn modern_fcpxml_is_admitted_and_rebuilt_with_relative_assets() {
    let mut request = request(); request.format = InterchangeFormat::FcpXml; request.target = TargetEditor::FinalCutPro;
    let plan = BundlePlan::from_document(&document(&request), &request).unwrap();
    let xml = roxmltree::Document::parse_with_options(std::str::from_utf8(static_bytes(&plan, "timeline.fcpxml")).unwrap(),
        roxmltree::ParsingOptions { allow_dtd: true, ..Default::default() }).unwrap();
    assert!(xml.descendants().filter(|node| node.has_tag_name("media-rep")).all(|node|
        node.attribute("src").is_some_and(|url| url.starts_with("Media/") && !url.contains(".."))));
    assert!(!plan.document().report().application_import_tested);
}
#[test] fn request_rejects_bad_destination_and_budget() {
    for destination in [PathBuf::from("handoff.zip"), directory().join("../handoff.zip"), directory().join("handoff.otio")] {
        let mut request = request(); request.destination = destination; assert!(request.validate().is_err());
    }
    for budget in [0, MAX_BUNDLE_BYTES + 1] {
        let mut request = request(); request.max_total_bytes = budget; assert!(request.validate().is_err());
    }
}
#[test] fn workspace_requires_normalized_absolute_path() {
    let request = request(); assert!(request.to_export_request(std::path::Path::new("relative")).is_err());
    assert!(request.to_export_request(&directory().join("../private")).is_err());
}
#[test] fn unsafe_portable_member_names_are_rejected() {
    for name in ["", "/root", "../a", "Media/../a", "Media//a", "Media/", "Media\\a", "C:/x", "Media/a%20b", "Media/a\nb", "CON.mov", "Media/LPT1.wav", ".hidden", "file.", "Media/é.mov"] {
        assert!(validate_member_name(name).is_err(), "accepted {name:?}");
    }
    for name in ["timeline.otio", "compatibility.json", "manifest.json", "Media/abc012.mov"] { validate_member_name(name).unwrap(); }
}
#[test] fn original_audio_and_video_share_one_copied_media_entry() {
    let plan = plan();
    assert_eq!(plan.entries().len(), 4);
    assert_eq!(plan.entries().iter().filter(|entry| matches!(entry, BundleEntry::Media(_))).count(), 1);
    assert_eq!(plan.all_inputs().len(), 1);
    assert_eq!(plan.document().timeline().video.url, plan.document().timeline().audio.as_ref().unwrap().url);
}
#[test] fn rebasing_urls_preserves_real_input_identity_and_stream_selection() {
    let plan = plan(); let timeline = plan.document().timeline();
    assert_eq!(timeline.video.file.canonical_path, input().canonical_path);
    assert_eq!(timeline.video.file.stamp, input().stamp);
    assert_eq!(timeline.video.video_stream, Some(0));
    assert_eq!(timeline.audio.as_ref().unwrap().audio_stream, Some(1));
    assert_eq!(timeline.video.url, format!("Media/{}.mov", "a".repeat(64)));
}
#[test] fn otio_actual_target_urls_are_portable() {
    let plan = plan(); let value: serde_json::Value = serde_json::from_slice(static_bytes(&plan, "timeline.otio")).unwrap();
    for track in value["tracks"]["children"].as_array().unwrap() {
        for clip in track["children"].as_array().unwrap() {
            let url = clip["media_references"]["DEFAULT_MEDIA"]["target_url"].as_str().unwrap();
            assert_eq!(url, plan.document().timeline().video.url);
        }
    }
}
#[test] fn manifest_hashes_and_sizes_match_every_other_entry() {
    let plan = plan();
    let manifest: serde_json::Value = serde_json::from_slice(static_bytes(&plan, "manifest.json")).unwrap();
    let manifest_entries = manifest["entries"].as_array().unwrap();
    assert_eq!(manifest_entries.len(), plan.entries().len() - 1);
    for entry in plan.entries().iter().filter(|entry| entry.name() != "manifest.json") {
        let row = manifest_entries.iter().find(|row| row["path"] == entry.name()).unwrap();
        assert_eq!(row["size"].as_u64(), Some(entry.size())); assert_eq!(row["sha256"], entry.sha256());
    }
    assert_eq!(plan.manifest_sha256(), format!("{:x}", Sha256::digest(static_bytes(&plan, "manifest.json"))));
    assert_eq!(manifest["manifest_self_included"], false);
}
#[test] fn compatibility_retains_project_decisions_and_separate_bundle_request() {
    let plan = plan();
    let report: serde_json::Value = serde_json::from_slice(static_bytes(&plan, "compatibility.json")).unwrap();
    assert_eq!(report["interchange"]["source_project"], serde_json::to_value(project()).unwrap());
    assert_eq!(report["bundle_request"], serde_json::to_value(request()).unwrap());
    assert_eq!(report["application_import_tested"], false);
    assert!(plan.document().report().warnings.iter().any(|warning| warning.contains("not a complete .amxv backup")));
}
#[test] fn plan_does_not_modify_original_document_or_project() {
    let request = request(); let document = document(&request); let original = document.bytes().to_vec();
    let old_url = document.timeline().video.url.clone(); let project_before = project().to_json().unwrap();
    BundlePlan::from_document(&document, &request).unwrap();
    assert_eq!(original, document.bytes()); assert_eq!(old_url, document.timeline().video.url);
    assert_eq!(project_before, project().to_json().unwrap());
}
#[test] fn changing_reviewed_request_rejects_prepared_document() {
    let request = request(); let document = document(&request);
    let mut changed = request.clone(); changed.name = "another title".into();
    assert!(BundlePlan::from_document(&document, &changed).is_err());
    changed = request.clone(); changed.audio = BundleAudio::Omit; assert!(BundlePlan::from_document(&document, &changed).is_err());
    changed = request.clone(); changed.record_start_frames = 300; assert!(BundlePlan::from_document(&document, &changed).is_err());
    changed = request.clone(); changed.project_file = directory().join("another.amxv"); assert!(BundlePlan::from_document(&document, &changed).is_err());
}
#[test] fn ordinary_export_document_is_not_a_bundle_workspace_document() {
    let request = request(); let ordinary = ExportRequest::new(project_file(), directory().join("elsewhere.otio"), InterchangeFormat::Otio, rate());
    let document = build_export(&project(), &ordinary, &ExportMedia { input: input(), info: info(), timing: Some(evidence()), baked_video: None, baked_audio: None }).unwrap();
    assert!(BundlePlan::from_document(&document, &request).is_err());
}
#[test] fn full_archive_size_includes_metadata_and_zip64_overhead() {
    let plan = plan(); let payload: u64 = plan.entries().iter().map(BundleEntry::size).sum();
    let overhead: u64 = 98 + plan.entries().iter().map(|entry| 148 + 2 * entry.name().len() as u64).sum::<u64>();
    assert_eq!(plan.total_bytes(), payload); assert_eq!(plan.archive_bytes(), payload + overhead);
    assert!(plan.archive_bytes() <= plan.max_total_bytes());
}
#[test] fn insufficient_budget_does_not_create_a_partial_plan() {
    let mut request = request(); request.max_total_bytes = 100;
    assert!(matches!(BundlePlan::from_document(&document(&request), &request), Err(Error::LimitExceeded(_))));
}
#[test] fn plan_is_deterministic_for_same_verified_inputs_and_request() {
    let a = plan(); let b = plan();
    assert_eq!(a.archive_bytes(), b.archive_bytes()); assert_eq!(a.manifest_sha256(), b.manifest_sha256());
    for (a, b) in a.entries().iter().zip(b.entries()) { assert_eq!(a.name(), b.name()); assert_eq!(a.sha256(), b.sha256()); }
}
#[test] fn omitted_audio_is_explicit_and_does_not_change_source_identity() {
    let mut request = request(); request.audio = BundleAudio::Omit;
    let plan = BundlePlan::from_document(&document(&request), &request).unwrap();
    assert!(plan.document().timeline().audio.is_none()); assert!(plan.document().timeline().audio_pieces.is_empty());
    assert_eq!(plan.all_inputs().len(), 1);
}
#[test] fn requested_bake_cannot_be_substituted_with_original_reference() {
    let request = request(); let doc = document(&request); let mut bake = request; bake.video = BundleVideo::Bake;
    assert!(BundlePlan::from_document(&doc, &bake).is_err());
}
#[test] fn supplied_visual_bake_must_belong_to_the_private_requested_path() {
    let mut request = request(); request.video = BundleVideo::Bake;
    let export = request.to_export_request(&directory().join("private")).unwrap();
    // The pure interchange builder accepts supplied verified evidence, but the
    // portable authority must additionally bind it to this leased destination.
    let outside = input();
    let document = build_export(&project(), &export, &ExportMedia { input: input(), info: info(), timing: None,
        baked_video: Some((outside.clone(), info(), evidence_for(outside))), baked_audio: None }).unwrap();
    assert!(BundlePlan::from_document(&document, &request).is_err());
}
#[test] fn private_visual_bake_is_referenced_without_copying_unused_original() {
    let mut request = request(); request.video = BundleVideo::Bake;
    let workspace = directory().join("private"); let export = request.to_export_request(&workspace).unwrap();
    let mut baked = input(); baked.canonical_path = workspace.join("Media/video.mov");
    baked.stamp.sha256 = "b".repeat(64); baked.stamp.file_id = Some("device:8".into());
    let document = build_export(&project(), &export, &ExportMedia { input: input(), info: info(), timing: None,
        baked_video: Some((baked.clone(), info(), evidence_for(baked.clone()))), baked_audio: None }).unwrap();
    let plan = BundlePlan::from_document(&document, &request).unwrap();
    assert_eq!(plan.all_inputs().len(), 1); assert_eq!(plan.all_inputs()[0].canonical_path, baked.canonical_path);
    assert!(plan.document().timeline().video.url.contains(&"b".repeat(64)));
}
