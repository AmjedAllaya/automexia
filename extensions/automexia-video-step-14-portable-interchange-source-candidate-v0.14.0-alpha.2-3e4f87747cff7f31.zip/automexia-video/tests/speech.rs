//! Protocol/state tests use a deliberately synthetic probability provider.
//! Passing these is NOT evidence that Silero detects speech correctly.
use automexia_video::*;
use automexia_video::speech::*;
use automexia_video::speech_pipe::*;
use automexia_video::model_pack::{SILERO_CONTRACT,SPEECH_PROCESSING};
use std::{sync::{Arc,Mutex},time::Duration};
fn r(v:&str)->Rational{v.parse().unwrap()}
fn identity()->ModelIdentity{ModelIdentity{id:"fake-test-only".into(),revision:"1".into(),source_revision:"fixture".into(),manifest_sha256:"a".repeat(64),weights_sha256:"b".repeat(64),contract:SILERO_CONTRACT.into(),preprocessing:SPEECH_PROCESSING.into(),runtime:ModelRuntime{adapter:"fake-only".into(),build_info_sha256:"c".repeat(64),artifact_sha256:"d".repeat(64)},notices_sha256:"e".repeat(64)}}
struct Fake {id:ModelIdentity,p:f32,calls:Arc<Mutex<Vec<(Vec<f32>,Vec<f32>)>>>,panic:bool}
impl SpeechSession for Fake {
 fn identity(&self)->&ModelIdentity{&self.id}
 fn infer(&mut self,i:&[f32;SPEECH_INPUT],s:&[f32;SPEECH_STATE],_:&Cancellation)->Result<SpeechTensorOutput>{if self.panic{panic!("intentional fake session panic");}self.calls.lock().unwrap().push((i.to_vec(),s.to_vec()));Ok(SpeechTensorOutput{probability:self.p,state:[0.25;SPEECH_STATE]})}
}
fn analyzer(p:f32)->(SpeechAnalyzer,ModelActivation,Arc<Mutex<Vec<(Vec<f32>,Vec<f32>)>>>){let id=identity();let a=ModelActivation::selected(id.clone()).unwrap();let calls=Arc::new(Mutex::new(vec![]));let s=Fake{id,p,calls:Arc::clone(&calls),panic:false};(SpeechAnalyzer::new(Box::new(s),&a,SpeechSettings::default(),r("0"),r("10"),Duration::from_secs(10)).unwrap(),a,calls)}
fn frame(pts:i64,n:usize,v:f32)->SpeechAudioFrame{SpeechAudioFrame{pts,samples:vec![v;n]}}
#[test]fn first_frame_is_uncertain_even_at_zero(){let(mut s,_,_)=analyzer(0.);s.push(frame(0,512,0.),&Cancellation::new()).unwrap();assert_eq!(s.finish(&Cancellation::new()).unwrap().spans[0].class,SpeechClass::Uncertain);}
#[test]fn following_quiet_frame_qualifies(){let(mut s,_,_)=analyzer(0.);for t in [0,512]{s.push(frame(t,512,0.),&Cancellation::new()).unwrap();}assert_eq!(s.finish(&Cancellation::new()).unwrap().spans[1].class,SpeechClass::NoSpeech);}
#[test]fn uncertain_probability_is_not_silence(){let(mut s,_,_)=analyzer(0.4);for t in [0,512]{s.push(frame(t,512,0.),&Cancellation::new()).unwrap();}assert!(s.finish(&Cancellation::new()).unwrap().spans.iter().all(|v|v.class==SpeechClass::Uncertain));}
#[test]fn confident_speech_separate_from_uncertainty(){let(mut s,_,_)=analyzer(0.9);for t in [0,512]{s.push(frame(t,512,0.),&Cancellation::new()).unwrap();}assert_eq!(s.finish(&Cancellation::new()).unwrap().spans[1].class,SpeechClass::Speech);}
#[test]fn recurrent_state_and_context_match_contract(){let(mut s,_,c)=analyzer(0.);s.push(frame(0,512,0.5),&Cancellation::new()).unwrap();s.push(frame(512,512,0.1),&Cancellation::new()).unwrap();let c=c.lock().unwrap();assert_eq!(c[0].0.len(),576);assert!(c[0].0[..64].iter().all(|v|*v==0.));assert!(c[1].0[..64].iter().all(|v|*v==0.5));assert!(c[1].1.iter().all(|v|*v==0.25));}
#[test]fn gap_resets_context_and_state(){let(mut s,_,c)=analyzer(0.);s.push(frame(0,512,0.5),&Cancellation::new()).unwrap();s.push(frame(16000,512,0.1),&Cancellation::new()).unwrap();assert!(c.lock().unwrap()[1].1.iter().all(|v|*v==0.));let o=s.finish(&Cancellation::new()).unwrap();assert_eq!(o.reset_count,1);assert_eq!(o.spans[1].range.start,r("1"));assert_eq!(o.spans[1].class,SpeechClass::Uncertain);}
#[test]fn overlap_is_not_retimed(){let(mut s,_,_)=analyzer(0.);s.push(frame(0,512,0.),&Cancellation::new()).unwrap();assert!(s.push(frame(511,512,0.),&Cancellation::new()).is_err());assert!(s.finish(&Cancellation::new()).is_err());}
#[test]fn partial_tail_is_uncertain(){let(mut s,_,_)=analyzer(0.);s.push(frame(0,512,0.),&Cancellation::new()).unwrap();s.push(frame(512,25,0.),&Cancellation::new()).unwrap();assert!(s.finish(&Cancellation::new()).unwrap().spans.iter().all(|v|v.class==SpeechClass::Uncertain));}
#[test]fn partial_then_contiguous_frame_is_invalid(){let(mut s,_,_)=analyzer(0.);s.push(frame(0,1,0.),&Cancellation::new()).unwrap();assert!(s.push(frame(1,512,0.),&Cancellation::new()).is_err());}
#[test]fn revoked_pack_blocks_next_inference(){let(mut s,a,c)=analyzer(0.);a.revoke();assert!(matches!(s.push(frame(0,512,0.),&Cancellation::new()),Err(Error::Cancelled)));assert!(c.lock().unwrap().is_empty());}
#[test]fn revoked_pack_blocks_finish(){let(mut s,a,_)=analyzer(0.);s.push(frame(0,512,0.),&Cancellation::new()).unwrap();a.revoke();assert!(matches!(s.finish(&Cancellation::new()),Err(Error::Cancelled)));}
#[test]fn invalid_probabilities_poison(){for p in [f32::NAN,f32::INFINITY,-0.1,1.1]{let(mut s,_,_)=analyzer(p);assert!(s.push(frame(0,512,0.),&Cancellation::new()).is_err());assert!(s.finish(&Cancellation::new()).is_err());}}
#[test]fn invalid_pcm_rejected_before_model(){for v in [f32::NAN,f32::INFINITY,8.1]{let(mut s,_,c)=analyzer(0.);assert!(s.push(frame(0,512,v),&Cancellation::new()).is_err());assert!(c.lock().unwrap().is_empty());}}
#[test]fn clipped_pcm_is_uncertain_and_bounded(){let(mut s,_,c)=analyzer(0.);s.push(frame(0,512,2.),&Cancellation::new()).unwrap();s.push(frame(512,512,2.),&Cancellation::new()).unwrap();assert!(s.finish(&Cancellation::new()).unwrap().spans.iter().all(|v|v.class==SpeechClass::Uncertain));assert!(c.lock().unwrap()[0].0.iter().all(|v|*v<=1.));}
#[test]fn oversized_or_empty_model_frame_rejected(){for n in [0,513]{let(mut s,_,_)=analyzer(0.);assert!(s.push(frame(0,n,0.),&Cancellation::new()).is_err());}}
#[test]fn no_observations_is_not_success(){assert!(analyzer(0.).0.finish(&Cancellation::new()).is_err());}
#[test]fn cancelled_frame_does_not_call_model(){let(mut s,_,c)=analyzer(0.);let token=Cancellation::new();token.cancel();assert!(s.push(frame(0,512,0.),&token).is_err());assert!(c.lock().unwrap().is_empty());}
#[test]fn strict_settings_reject_nan_and_limits(){let mut a=SpeechSettings::default();a.no_speech_at_most=f32::NAN;assert!(a.validate().is_err());a=SpeechSettings::default();a.protect_before_ms=0;assert!(a.validate().is_err());a=SpeechSettings::default();a.analysis_channel=8;assert!(a.validate().is_err());}
#[test]fn native_packets_reblock_without_sample_loss(){let(s,_,c)=analyzer(0.);let mut b=SpeechWindowBuffer::new(s);let mut at=0;for n in [325,341,278,16]{b.push(frame(at,n,0.25),&Cancellation::new()).unwrap();at+=n as i64;}let o=b.finish(&Cancellation::new()).unwrap();assert_eq!(o.observed_duration,r("3/50"));assert_eq!(c.lock().unwrap().len(),2);}
#[test]fn gap_flushes_pending_without_filling_silence(){let(s,_,_)=analyzer(0.);let mut b=SpeechWindowBuffer::new(s);b.push(frame(0,325,0.),&Cancellation::new()).unwrap();b.push(frame(1000,700,0.),&Cancellation::new()).unwrap();let o=b.finish(&Cancellation::new()).unwrap();assert_eq!(o.observed_duration,r("1025/16000"));assert_eq!(o.reset_count,1);}
#[test]fn reblocker_rejects_overlap(){let(s,_,_)=analyzer(0.);let mut b=SpeechWindowBuffer::new(s);b.push(frame(0,10,0.),&Cancellation::new()).unwrap();assert!(b.push(frame(9,10,0.),&Cancellation::new()).is_err());assert!(b.finish(&Cancellation::new()).is_err());}
fn header(n:u32,pts:i64,count:usize)->Vec<u8>{format!("[Parsed_ashowinfo_5 @ 0x1] n:{n} pts:{pts} pts_time:0 fmt:flt channels:1 chlayout:mono rate:16000 nb_samples:{count} checksum:0 plane_checksums: [ 0 ]\n").into_bytes()}
#[test]fn pipe_accepts_pcm_before_header(){let mut output=vec![];let mut sink=|v|{output.push(v);Ok(())};let mut p=SpeechPcmPipe::new(&mut sink);p.pcm(&0.5f32.to_le_bytes()).unwrap();p.diagnostics(&header(0,42,1)).unwrap();p.finish().unwrap();assert_eq!(output[0].pts,42);assert_eq!(output[0].samples,[0.5]);}
#[test]fn pipe_accepts_header_before_pcm(){let mut output=vec![];let mut sink=|v|{output.push(v);Ok(())};let mut p=SpeechPcmPipe::new(&mut sink);p.diagnostics(&header(0,-12,1)).unwrap();for b in 0.25f32.to_le_bytes(){p.pcm(&[b]).unwrap();}p.finish().unwrap();assert_eq!(output[0].pts,-12);}
#[test]fn fragmented_header_roundtrip(){let mut count=0;let mut sink=|_|{count+=1;Ok(())};let mut p=SpeechPcmPipe::new(&mut sink);for b in header(0,0,1){p.diagnostics(&[b]).unwrap();}p.pcm(&0.0f32.to_le_bytes()).unwrap();p.finish().unwrap();assert_eq!(count,1);}
#[test]fn pipe_rejects_wrong_rate_or_channels(){for (a,b) in [("rate:16000","rate:48000"),("channels:1","channels:2"),("fmt:flt","fmt:s16"),("chlayout:mono","chlayout:stereo")]{let mut sink=|_|Ok(());let mut p=SpeechPcmPipe::new(&mut sink);let line=String::from_utf8(header(0,0,1)).unwrap().replace(a,b);assert!(p.diagnostics(line.as_bytes()).is_err());}}
#[test]fn pipe_rejects_duplicate_field(){let mut sink=|_|Ok(());let mut p=SpeechPcmPipe::new(&mut sink);let line=String::from_utf8(header(0,0,1)).unwrap().replace("pts:0","pts:0 pts:0");assert!(p.diagnostics(line.as_bytes()).is_err());}
#[test]fn pipe_requires_exact_sequence(){let mut sink=|_|Ok(());let mut p=SpeechPcmPipe::new(&mut sink);assert!(p.diagnostics(&header(1,0,1)).is_err());}
#[test]fn truncated_pcm_is_not_success(){let mut sink=|_|Ok(());let mut p=SpeechPcmPipe::new(&mut sink);p.diagnostics(&header(0,0,1)).unwrap();p.pcm(&[0,0]).unwrap();assert!(p.finish().is_err());}
#[test]fn unterminated_header_is_not_success(){let mut sink=|_|Ok(());let mut p=SpeechPcmPipe::new(&mut sink);let mut h=header(0,0,1);h.pop();p.diagnostics(&h).unwrap();assert!(p.finish().is_err());}
#[test]fn pending_pcm_bound_enforced(){let mut sink=|_|Ok(());let mut p=SpeechPcmPipe::new(&mut sink);assert!(p.pcm(&vec![0;MAX_PCM_PENDING+1]).is_err());}
#[test]fn nonfinite_float_poison_transport(){let mut sink=|_|Ok(());let mut p=SpeechPcmPipe::new(&mut sink);p.diagnostics(&header(0,0,1)).unwrap();assert!(p.pcm(&f32::NAN.to_le_bytes()).is_err());assert!(p.finish().is_err());}
#[test]fn callback_failure_is_propagated(){let mut sink=|_|Err(Error::Cancelled);let mut p=SpeechPcmPipe::new(&mut sink);p.diagnostics(&header(0,0,1)).unwrap();assert!(matches!(p.pcm(&0.0f32.to_le_bytes()),Err(Error::Cancelled)));}
#[test]fn small_declared_timestamp_overlap_resets_and_marks_uncertain(){
 let(s,_,calls)=analyzer(0.);let mut b=SpeechWindowBuffer::with_timestamp_resolution(s,Some(r("1/1000"))).unwrap();
 b.push(frame(0,325,0.2),&Cancellation::new()).unwrap();
 b.push(frame(322,700,0.1),&Cancellation::new()).unwrap();
 let o=b.finish(&Cancellation::new()).unwrap();assert_eq!(o.timestamp_repairs,1);
 assert_eq!(o.observed_duration,r("1022/16000"));assert_eq!(o.reset_count,1);
 assert!(o.spans.iter().all(|v|v.class==SpeechClass::Uncertain));
 assert!(calls.lock().unwrap()[1].1.iter().all(|v|*v==0.));
}
#[test]fn timestamp_tolerance_never_accepts_large_overlap(){
 let(s,_,_)=analyzer(0.);let mut b=SpeechWindowBuffer::with_timestamp_resolution(s,Some(r("1/1000"))).unwrap();
 b.push(frame(0,512,0.),&Cancellation::new()).unwrap();assert!(b.push(frame(490,512,0.),&Cancellation::new()).is_err());
}
#[test]fn coarse_timestamps_do_not_enable_unbounded_repair(){
 let(s,_,_)=analyzer(0.);let mut b=SpeechWindowBuffer::with_timestamp_resolution(s,Some(r("1/10"))).unwrap();
 b.push(frame(0,512,0.),&Cancellation::new()).unwrap();assert!(b.push(frame(511,512,0.),&Cancellation::new()).is_err());
}
#[test]fn identical_replayed_packet_is_rejected_with_tolerance(){
 let(s,_,_)=analyzer(0.);let mut b=SpeechWindowBuffer::with_timestamp_resolution(s,Some(r("1/1000"))).unwrap();
 b.push(frame(0,10,0.),&Cancellation::new()).unwrap();assert!(b.push(frame(0,10,0.),&Cancellation::new()).is_err());
}
#[test]fn gap_remains_uncovered_with_quantization_enabled(){
 let(s,_,_)=analyzer(0.);let mut b=SpeechWindowBuffer::with_timestamp_resolution(s,Some(r("1/1000"))).unwrap();
 b.push(frame(0,1024,0.),&Cancellation::new()).unwrap();b.push(frame(16000,1024,0.),&Cancellation::new()).unwrap();
 let o=b.finish(&Cancellation::new()).unwrap();assert_eq!(o.observed_duration,r("2048/16000"));assert_eq!(o.timestamp_repairs,0);
 assert!(o.spans.windows(2).any(|s|s[1].range.start>s[0].range.end));
}
#[test]fn strict_settings_json_does_not_accept_unknown_fields(){assert!(serde_json::from_str::<SpeechSettings>(r#"{"analysis_channel":0,"unknown":true}"#).is_err());}
#[test]fn sample_timestamp_overflow_is_rejected(){let(mut s,_,_)=analyzer(0.);assert!(s.push(frame(i64::MAX,512,0.),&Cancellation::new()).is_err());}
#[test]fn provider_panic_is_error_not_success(){
 let id=identity();let active=ModelActivation::selected(id.clone()).unwrap();
 let fake=Fake{id,p:0.,calls:Arc::new(Mutex::new(vec![])),panic:true};
 let mut s=SpeechAnalyzer::new(Box::new(fake),&active,SpeechSettings::default(),r("0"),r("10"),Duration::from_secs(2)).unwrap();
 assert!(matches!(s.push(frame(0,512,0.),&Cancellation::new()),Err(Error::CallbackPanicked)));
 assert!(s.finish(&Cancellation::new()).is_err());
}
struct RevokeDuringInference {id:ModelIdentity,active:ModelActivation}
impl SpeechSession for RevokeDuringInference {
 fn identity(&self)->&ModelIdentity{&self.id}
 fn infer(&mut self,_:&[f32;SPEECH_INPUT],_:&[f32;SPEECH_STATE],_:&Cancellation)->Result<SpeechTensorOutput>{self.active.revoke();Ok(SpeechTensorOutput{probability:0.,state:[0.;SPEECH_STATE]})}
}
#[test]fn revocation_during_inference_discards_returned_probability(){
 let id=identity();let active=ModelActivation::selected(id.clone()).unwrap();
 let mut s=SpeechAnalyzer::new(Box::new(RevokeDuringInference{id,active:active.clone()}),&active,SpeechSettings::default(),r("0"),r("10"),Duration::from_secs(2)).unwrap();
 assert!(matches!(s.push(frame(0,512,0.),&Cancellation::new()),Err(Error::Cancelled)));
}
struct InvalidState {id:ModelIdentity}
impl SpeechSession for InvalidState {
 fn identity(&self)->&ModelIdentity{&self.id}
 fn infer(&mut self,_:&[f32;SPEECH_INPUT],_:&[f32;SPEECH_STATE],_:&Cancellation)->Result<SpeechTensorOutput>{Ok(SpeechTensorOutput{probability:0.,state:[f32::NAN;SPEECH_STATE]})}
}
#[test]fn invalid_recurrent_state_is_rejected(){
 let id=identity();let active=ModelActivation::selected(id.clone()).unwrap();
 let mut s=SpeechAnalyzer::new(Box::new(InvalidState{id}),&active,SpeechSettings::default(),r("0"),r("10"),Duration::from_secs(2)).unwrap();
 assert!(matches!(s.push(frame(0,512,0.),&Cancellation::new()),Err(Error::InvalidOutput(_))));
}
#[test]fn wrong_selected_model_is_rejected_before_analysis(){
 let mut id=identity();id.weights_sha256="f".repeat(64);let active=ModelActivation::selected(identity()).unwrap();
 let fake=Fake{id,p:0.,calls:Arc::new(Mutex::new(vec![])),panic:false};
 assert!(matches!(SpeechAnalyzer::new(Box::new(fake),&active,SpeechSettings::default(),r("0"),r("10"),Duration::from_secs(2)),Err(Error::InputChanged)));
}

struct RequireLinkedCancellation {id:ModelIdentity,active:ModelActivation}
impl SpeechSession for RequireLinkedCancellation {
 fn identity(&self)->&ModelIdentity{&self.id}
 fn infer(&mut self,_:&[f32;SPEECH_INPUT],_:&[f32;SPEECH_STATE],cancel:&Cancellation)->Result<SpeechTensorOutput>{
  self.active.revoke();
  assert!(cancel.is_cancelled(),"blocking inference must observe activation revocation in its own cancellation token");
  cancel.check()?;unreachable!()
 }
}
#[test]fn activation_revocation_is_linked_into_inference_cancellation(){
 let id=identity();let active=ModelActivation::selected(id.clone()).unwrap();
 let mut s=SpeechAnalyzer::new(Box::new(RequireLinkedCancellation{id,active:active.clone()}),&active,SpeechSettings::default(),r("0"),r("10"),Duration::from_secs(2)).unwrap();
 assert!(matches!(s.push(frame(0,512,0.),&Cancellation::new()),Err(Error::Cancelled)));
}

struct PanicIdentity;
impl SpeechSession for PanicIdentity {
 fn identity(&self)->&ModelIdentity{panic!("injected identity callback panic")}
 fn infer(&mut self,_:&[f32;SPEECH_INPUT],_:&[f32;SPEECH_STATE],_:&Cancellation)->Result<SpeechTensorOutput>{unreachable!()}
}
#[test]fn model_session_identity_panic_is_contained_before_analysis(){
 let active=ModelActivation::selected(identity()).unwrap();
 assert!(matches!(SpeechAnalyzer::new(Box::new(PanicIdentity),&active,SpeechSettings::default(),r("0"),r("10"),Duration::from_secs(2)),Err(Error::CallbackPanicked)));
}

struct WaitForAnalysisDeadline {id:ModelIdentity}
impl SpeechSession for WaitForAnalysisDeadline {
 fn identity(&self)->&ModelIdentity{&self.id}
 fn infer(&mut self,_:&[f32;SPEECH_INPUT],_:&[f32;SPEECH_STATE],cancel:&Cancellation)->Result<SpeechTensorOutput>{
  let watchdog=std::time::Instant::now()+Duration::from_secs(2);
  while cancel.check().is_ok() && std::time::Instant::now()<watchdog {std::thread::yield_now();}
  assert!(matches!(cancel.check(),Err(Error::Timeout)),"analyzer deadline must reach a blocking inference provider");
  cancel.check()?;unreachable!()
 }
}
#[test]fn analyzer_timeout_reaches_inference_without_revoking_the_selected_model(){
 let id=identity();let active=ModelActivation::selected(id.clone()).unwrap();
 let mut analyzer=SpeechAnalyzer::new(Box::new(WaitForAnalysisDeadline{id}),&active,SpeechSettings::default(),r("0"),r("10"),Duration::from_millis(25)).unwrap();
 assert!(matches!(analyzer.push(frame(0,512,0.),&Cancellation::new()),Err(Error::Timeout)));
 assert!(active.check().is_ok());
}
