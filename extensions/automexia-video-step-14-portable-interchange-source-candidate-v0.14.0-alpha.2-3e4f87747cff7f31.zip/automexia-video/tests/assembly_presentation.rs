//! Step 14A source-clock presentation and occurrence-aware caption regressions.
//! These execute Rust under Cargo; reference recipe checks are a separate layer.
use automexia_video::*;
use automexia_video::edit_render::EditRender;
use automexia_video::host::{FileStamp,InputFile};
use automexia_video::presentation::*;
use automexia_video::project::*;
use automexia_video::subtitles::{sidecar,MAX_CUES};
use std::collections::BTreeSet;
use std::path::PathBuf;

fn r(value:&str)->Rational{value.parse().unwrap()}
fn span(start:&str,end:&str)->TimeRange{TimeRange::new(r(start),r(end)).unwrap()}
fn segment(start:&str,end:&str,out_start:&str,out_end:&str)->TimelineSegment{
    TimelineSegment{source_id:"source-1".into(),source_range:span(start,end),output_range:span(out_start,out_end)}
}
fn timeline(segments:Vec<TimelineSegment>)->Timeline{
    Timeline{duration:segments.last().map(|s|s.output_range.end).unwrap_or(r("0")),segments}
}
fn words()->SubtitleDocument{
    let mut document=SubtitleDocument::parse(b"1\n00:00:00,000 --> 00:00:03,000\nFirst corrected last\n",SubtitleFormat::Srt).unwrap();
    document.generated_words=vec![
        CaptionWord{cue_id:"cue-1".into(),range:span("0","1"),text:"First".into()},
        CaptionWord{cue_id:"cue-1".into(),range:span("1","2"),text:"corrected".into()},
        CaptionWord{cue_id:"cue-1".into(),range:span("2","3"),text:"last".into()},
    ];document.validate().unwrap();document
}
#[test]
fn repeated_ranges_have_one_source_cue_and_all_output_occurrences(){
    let document=words();let t=timeline(vec![segment("0","3","0","3"),segment("0","3","3","6")]);
    let prepared=document.for_timeline(&t,"source-1").unwrap();
    assert_eq!(prepared.cues,document.cues);assert_eq!(prepared.generated_words,document.generated_words);
    let mapped=prepared.remap(&t,"source-1").unwrap();assert_eq!(mapped.len(),2);
    assert_eq!(mapped[0].range,span("0","3"));assert_eq!(mapped[1].range,span("3","6"));
    assert_eq!((mapped[0].part,mapped[1].part),(1,2));
}
#[test]
fn overlapping_occurrences_partition_source_union_without_duplicate_identity(){
    let t=timeline(vec![segment("0","3","0","3"),segment("1","2","3","4")]);
    let prepared=words().for_timeline(&t,"source-1").unwrap();
    assert_eq!(prepared.cues.iter().map(|c|c.text.as_str()).collect::<Vec<_>>(),vec!["First","corrected","last"]);
    assert_eq!(prepared.cues.iter().map(|c|&c.id).collect::<BTreeSet<_>>().len(),3);
    assert_eq!(prepared.generated_words.len(),3);prepared.validate().unwrap();
    let mapped=prepared.remap(&t,"source-1").unwrap();
    assert_eq!(mapped.iter().map(|c|c.text.as_str()).collect::<Vec<_>>(),vec!["First","corrected","last","corrected"]);
    assert_eq!(mapped[3].range,span("3","4"));
}
#[test]
fn reordered_ranges_keep_exact_independent_affine_speed_mapping(){
    let document=SubtitleDocument::parse(b"1\n00:00:00,500 --> 00:00:01,500\nExplicit sentence\n",SubtitleFormat::Srt).unwrap();
    let t=timeline(vec![segment("1","2","0","1/2"),segment("0","1","1/2","5/2")]);
    let prepared=document.for_timeline(&t,"source-1").unwrap();let mapped=prepared.remap(&t,"source-1").unwrap();
    assert_eq!(mapped.len(),2);assert_eq!(mapped[0].range,span("0","1/4"));assert_eq!(mapped[1].range,span("3/2","5/2"));
    assert!(mapped.iter().all(|c|c.text=="Explicit sentence"));
}
#[test]
fn clipped_word_annotation_retains_text_and_exact_visible_range(){
    let t=timeline(vec![segment("1/2","3/2","0","1"),segment("1","2","1","2")]);
    let prepared=words().for_timeline(&t,"source-1").unwrap();prepared.validate().unwrap();
    assert_eq!(prepared.generated_words.iter().map(|w|w.range).collect::<Vec<_>>(),vec![span("1/2","1"),span("1","3/2"),span("3/2","2")]);
    assert_eq!(prepared.generated_words.iter().map(|w|w.text.as_str()).collect::<Vec<_>>(),vec!["First","corrected","corrected"]);
    for word in &prepared.generated_words{assert!(prepared.cues.iter().any(|cue|cue.id==word.cue_id&&cue.range==word.range));}
}
#[test]
fn caption_preparation_preserves_original_and_is_idempotent(){
    let document=words();let saved=serde_json::to_vec(&document).unwrap();
    let t=timeline(vec![segment("2","3","0","1"),segment("1/2","3/2","1","2")]);
    let prepared=document.for_timeline(&t,"source-1").unwrap();
    assert_eq!(prepared.original,document.original);assert_eq!(prepared.original_sha256,document.original_sha256);
    assert_eq!(serde_json::to_vec(&prepared.for_timeline(&t,"source-1").unwrap()).unwrap(),serde_json::to_vec(&prepared).unwrap());
    assert_eq!(serde_json::to_vec(&document).unwrap(),saved);
}
#[test]
fn caption_preparation_does_not_reintroduce_removed_words(){
    let t=timeline(vec![segment("2","3","0","1"),segment("0","1","1","2"),segment("2","3","2","3")]);
    let prepared=words().for_timeline(&t,"source-1").unwrap();
    assert_eq!(prepared.generated_words.len(),2);assert!(prepared.generated_words.iter().all(|w|w.text!="corrected"));
    assert_eq!(prepared.remap(&t,"source-1").unwrap().iter().map(|c|c.text.as_str()).collect::<Vec<_>>(),vec!["last","First","last"]);
}
#[test]
fn manually_replaced_cue_text_is_not_rebuilt_from_stale_word_alignment(){
    let mut document=words();document.replace_cue("cue-1",span("0","3"),"User replacement".into()).unwrap();
    let t=timeline(vec![segment("2","3","0","1"),segment("0","1","1","2")]);
    let prepared=document.for_timeline(&t,"source-1").unwrap();
    assert!(prepared.generated_words.is_empty());assert!(prepared.cues.iter().all(|c|c.text=="User replacement"));
}
#[test]
fn maximum_repeated_timeline_preserves_unique_occurrence_parts(){
    let mut rows=Vec::new();for i in 0..MAX_RENDER_SEGMENTS{rows.push(TimelineSegment{source_id:"source-1".into(),source_range:span("0","1"),output_range:TimeRange::new(Rational::new(i as i64,1).unwrap(),Rational::new(i as i64+1,1).unwrap()).unwrap()});}
    let t=timeline(rows);let prepared=words().for_timeline(&t,"source-1").unwrap();assert_eq!(prepared.cues.len(),1);
    let mapped=prepared.remap(&t,"source-1").unwrap();assert_eq!(mapped.len(),MAX_RENDER_SEGMENTS);
    assert_eq!(mapped.iter().map(|c|(&c.source_id,c.part)).collect::<BTreeSet<_>>().len(),mapped.len());
    let text=sidecar(&mapped,SubtitleFormat::Srt).unwrap();let parsed=SubtitleDocument::parse(&text,SubtitleFormat::Srt).unwrap();assert_eq!(parsed.cues.len(),mapped.len());
}
#[test]
fn output_caption_expansion_is_bounded_before_sidecar_publication(){
    let mut document=words();document.generated_words.clear();document.cues.clear();
    for i in 0..65{document.cues.push(CaptionCue{id:format!("cue-{i}"),range:span("0","1"),text:"text".into()});}
    document.validate().unwrap();let mut rows=Vec::new();
    for i in 0..MAX_RENDER_SEGMENTS{rows.push(TimelineSegment{source_id:"source-1".into(),source_range:span("0","1"),output_range:TimeRange::new(Rational::new(i as i64,1).unwrap(),Rational::new(i as i64+1,1).unwrap()).unwrap()});}
    assert!(matches!(document.remap(&timeline(rows),"source-1"),Err(Error::LimitExceeded("mapped caption parts"))));
}
#[test]
fn source_caption_partition_expansion_is_bounded(){
    let mut document=words();document.generated_words.clear();document.cues.clear();
    for i in 0..MAX_CUES{document.cues.push(CaptionCue{id:format!("cue-{i}"),range:span("0","2"),text:"text".into()});}
    document.validate().unwrap();let t=timeline(vec![segment("0","2","0","2"),segment("0","1","2","3")]);
    assert!(matches!(document.for_timeline(&t,"source-1"),Err(Error::LimitExceeded("burned caption part count"))));
}
#[test]
fn arbitrary_source_order_does_not_relax_output_validation(){
    let document=words();
    for rows in [vec![segment("2","3","1","2")],vec![segment("2","3","0","1"),segment("0","1","2","3")],vec![segment("0","3","0","3"),segment("1","2","1","2")]]{
        assert!(document.remap(&timeline(rows),"source-1").is_err());
    }
}
#[test]
fn repeated_source_dissolve_keeps_both_caption_contributors(){
    let t=timeline(vec![segment("0","3","0","3"),segment("0","3","2","5")]);
    let prepared=words().for_timeline(&t,"source-1").unwrap();assert_eq!(prepared.cues.len(),1);
    let mapped=prepared.remap(&t,"source-1").unwrap();assert_eq!(mapped.len(),2);assert!(mapped[0].range.overlaps(&mapped[1].range));
}
#[test]
fn unrelated_or_empty_source_timeline_removes_only_prepared_captions(){
    let document=words();assert!(document.for_timeline(&timeline(vec![]),"source-1").unwrap().cues.is_empty());
    assert!(document.for_timeline(&timeline(vec![segment("0","3","0","3")]),"unrelated").unwrap().generated_words.is_empty());
    assert_eq!(document.generated_words.len(),3);
}

fn frame(n:i64)->Rational{r("1001/30000").ticks(n).unwrap()}
fn media()->MediaInfo{
    let mut media=automexia_video::media::parse_probe(include_bytes!("fixtures/probe-base.json")).unwrap();
    let video=media.streams.iter_mut().find(|s|s.kind=="video").unwrap();
    video.color_space=Some("bt709".into());video.color_transfer=Some("bt709".into());video.color_primaries=Some("bt709".into());video.color_range=Some("tv".into());media
}
fn project()->Project{
    let location=std::env::temp_dir().join("assembly-presentation/project.amxv");let media=media();
    let input=InputFile{canonical_path:location.with_file_name("source.mp4"),stamp:FileStamp{size:100,modified_ns:None,sha256:"a".repeat(64),file_id:None}};
    let source=ProjectSource::from_probe("source-1",&input,&media,media.select(StreamSelection::default()).unwrap(),&location).unwrap();
    Project::new("assembly",source,ResolvedSettings{workflow:None,preset_name:None,preset_revision:None,pause_cleanup:None,voice_cleanup:None,voice_enhancement:None,color_correction:None,render:FrozenRenderSettings::from_options(&RenderOptions::default()).unwrap()}).unwrap()
}
fn caps()->RuntimeCapabilities{
    RuntimeCapabilities{supports_demux_time_base:true,bitstream_filters:["setts".into()].into_iter().collect(),encoders:["libx264".into(),"aac".into()].into_iter().collect(),muxers:["mp4".into()].into_iter().collect(),filters:["settb","setpts","select","asetpts","aresample","apad","atrim","anull","asplit","concat","scale","setsar","format","crop","pad","geq","overlay","volume","fade","trim","fps","split","tpad","null","atempo","xfade","acrossfade","asetnsamples"].map(str::to_owned).into_iter().collect(),..Default::default()}
}
fn clip(id:&str,start:i64,end:i64,speed:PlaybackSpeed)->AssemblyClip{AssemblyClip{id:id.into(),range:TimeRange::new(frame(start),frame(end)).unwrap(),speed}}
fn assemble(p:&mut Project,clips:Vec<AssemblyClip>){p.set_assembly("main",Some(AssemblySettings{clips,..Default::default()})).unwrap();p.review_assembly("main",Disposition::AutoApply,true).unwrap();}
fn asset()->AssetRef{AssetRef{path:PathBuf::from("assets/logo.png"),size:20,sha256:"b".repeat(64)}}
fn overlay()->Overlay{
    Overlay{id:"logo".into(),range:TimeRange::new(frame(0),frame(60)).unwrap(),content:GraphicContent::Image{asset:asset()},placement:Placement{anchor:Anchor::TopLeft,width:30,height:16,margin:0},animation:Animation{fade_in:frame(60),..Default::default()},enabled:true}
}
fn set_profile(p:&mut Project,profile:PresentationSettings){p.set_presentation("main",Some(profile)).unwrap();p.review_presentation("main",Disposition::AutoApply,true).unwrap();}
fn presentation(p:&Project)->PresentationRender{let edit=EditRender::from_variant(p,"main").unwrap();PresentationRender::from_project(p,"main",&edit,OutputSize::new(160,96).unwrap(),r("1"),&caps()).unwrap().unwrap()}
#[test]
fn repeated_and_retimed_graphics_are_composed_once_in_source_time(){
    let mut p=project();assemble(&mut p,vec![clip("later",30,60,PlaybackSpeed::Double),clip("repeat",30,60,PlaybackSpeed::Half)]);
    set_profile(&mut p,PresentationSettings{safe_zone:SafeZone::none(),overlays:vec![overlay()],..Default::default()});
    let plan=presentation(&p);assert!(plan.source_composition);assert_eq!(plan.events.len(),1);let event=&plan.events[0];
    assert_eq!(event.range,TimeRange::new(frame(30),frame(60)).unwrap());assert_eq!(event.range,event.source_range);
    assert_eq!(event.elapsed(frame(30)).unwrap(),frame(30));assert_eq!(event.animation_origin,r("0"));
    let state=event.animation.state(event.elapsed(frame(30)).unwrap(),event.animation_duration).unwrap();assert!((state.opacity-0.5).abs()<1e-9);
}
#[test]
fn removed_source_graphics_do_not_create_false_collisions(){
    let mut p=project();assemble(&mut p,vec![clip("later",30,60,PlaybackSpeed::Normal),clip("repeat",30,60,PlaybackSpeed::Normal)]);
    let mut first=overlay();first.range=TimeRange::new(frame(0),frame(20)).unwrap();first.animation=Animation::default();let mut second=first.clone();second.id="second".into();
    set_profile(&mut p,PresentationSettings{safe_zone:SafeZone::none(),overlays:vec![first,second],..Default::default()});
    let plan=presentation(&p);assert!(plan.source_composition);assert!(plan.events.is_empty());
}
#[test]
fn repeated_caption_burn_in_and_sidecar_share_prepared_word_partitions(){
    let mut p=project();assemble(&mut p,vec![clip("sentence",0,60,PlaybackSpeed::Normal),clip("middle",20,40,PlaybackSpeed::Double)]);
    let mut document=SubtitleDocument::parse(b"1\n00:00:00,000 --> 00:00:02,002\nFirst corrected last\n",SubtitleFormat::Srt).unwrap();
    document.generated_words=vec![
        CaptionWord{cue_id:"cue-1".into(),range:TimeRange::new(frame(0),frame(20)).unwrap(),text:"First".into()},
        CaptionWord{cue_id:"cue-1".into(),range:TimeRange::new(frame(20),frame(40)).unwrap(),text:"corrected".into()},
        CaptionWord{cue_id:"cue-1".into(),range:TimeRange::new(frame(40),frame(60)).unwrap(),text:"last".into()},
    ];
    set_profile(&mut p,PresentationSettings{safe_zone:SafeZone::none(),captions:Some(CaptionLayer{document,style:Some(TextStyle::light(FontRef{asset:asset(),family:"Fixture Font".into()},12)),placement:Some(Placement{anchor:Anchor::BottomCenter,width:120,height:30,margin:0}),burn_in:true}),..Default::default()});
    let before=p.to_json().unwrap();let plan=presentation(&p);assert!(plan.source_composition);assert_eq!(plan.events.len(),3);
    assert_eq!(plan.mapped_captions.iter().map(|c|c.text.as_str()).collect::<Vec<_>>(),vec!["First","corrected","last","corrected"]);
    assert_eq!(plan.mapped_captions[3].range,TimeRange::new(frame(60),frame(70)).unwrap());
    let prepared=&plan.settings.captions.as_ref().unwrap().document;assert_eq!(prepared.generated_words.len(),3);
    assert_eq!(serde_json::to_vec(&prepared.remap(&p.timeline_for_variant("main").unwrap(),"source-1").unwrap()).unwrap(),serde_json::to_vec(&plan.mapped_captions).unwrap());
    assert_eq!(p.to_json().unwrap(),before);
}
#[test]
fn source_volume_precedes_branching_and_runs_once_before_repeated_audio(){
    let mut p=project();assemble(&mut p,vec![clip("later",30,60,PlaybackSpeed::Normal),clip("repeat",30,60,PlaybackSpeed::Double)]);
    set_profile(&mut p,PresentationSettings{volume:Some(VolumeTrack{keys:vec![VolumeKey{at:r("0"),gain:0.5,easing:Easing::Linear}]}),..Default::default()});
    let plan=automexia_video::plan::build_edited_plan(&p,"main",&media(),&caps()).unwrap();
    let graph=plan.voice_audio_graph(false).unwrap();assert_eq!(graph.matches("volume='").count(),1);
    assert!(graph.find("volume='").unwrap()<graph.find("asplit=").unwrap());assert!(graph.contains("atempo=2.0"));
}

#[test]
fn direct_transcript_sidecars_use_the_same_prepared_source_document(){
    use automexia_video::model_pack::{WHISPER_CONTRACT,WHISPER_PROCESSING};
    use automexia_video::transcript::{RecognizedWord,Transcript,TranscriptProvenance,TranscriptSettings};
    let mut p=project();
    let model=ModelIdentity{id:"synthetic-assembly-caption".into(),revision:"1".into(),source_revision:"fixture".into(),manifest_sha256:"b".repeat(64),weights_sha256:"c".repeat(64),contract:WHISPER_CONTRACT.into(),preprocessing:WHISPER_PROCESSING.into(),runtime:ModelRuntime{adapter:"fake-only".into(),artifact_sha256:"d".repeat(64),build_info_sha256:"e".repeat(64)},notices_sha256:"f".repeat(64)};
    let provenance=TranscriptProvenance{model,settings:TranscriptSettings{language:"en".into(),..Default::default()},ffmpeg_sha256:"1".repeat(64),ffprobe_sha256:"2".repeat(64),recognized_language:"en".into(),audio_start:r("0"),audio_samples:32032,timestamp_repairs:0,clipped_samples:0};
    let observed=vec![
        RecognizedWord{text:"First".into(),range:TimeRange::new(frame(0),frame(20)).unwrap(),confidence:Some(0.99)},
        RecognizedWord{text:"original".into(),range:TimeRange::new(frame(20),frame(40)).unwrap(),confidence:Some(0.99)},
        RecognizedWord{text:"last".into(),range:TimeRange::new(frame(40),frame(60)).unwrap(),confidence:Some(0.99)},
    ];
    let transcript=Transcript::from_observations(&p,"source-1",provenance,observed).unwrap();p.set_transcript(transcript).unwrap();
    let id=p.transcript.as_ref().unwrap().words()[1].id.clone();p.correct_transcript_word(&id,"corrected".into(),TimeRange::new(frame(20),frame(40)).unwrap()).unwrap();
    assemble(&mut p,vec![clip("sentence",0,60,PlaybackSpeed::Normal),clip("middle",20,40,PlaybackSpeed::Double)]);
    let transcript=p.transcript.as_ref().unwrap();let original=transcript.original().to_vec();
    let output=transcript.subtitles_for_variant(&p,"main",SubtitleFormat::WebVtt).unwrap();let document=SubtitleDocument::parse(&output,SubtitleFormat::WebVtt).unwrap();
    assert_eq!(document.cues.iter().map(|c|c.text.as_str()).collect::<Vec<_>>(),vec!["First","corrected","last","corrected"]);
    let timeline=p.timeline_for_variant("main").unwrap();let prepared=transcript.subtitle_document(SubtitleFormat::WebVtt).unwrap().for_timeline(&timeline,"source-1").unwrap();
    assert_eq!(output,sidecar(&prepared.remap(&timeline,"source-1").unwrap(),SubtitleFormat::WebVtt).unwrap());
    let shared=transcript.subtitles_for_project(&p,SubtitleFormat::WebVtt).unwrap();assert_eq!(SubtitleDocument::parse(&shared,SubtitleFormat::WebVtt).unwrap().cues[0].text,"First corrected last");
    assert_eq!(transcript.original(),original.as_slice());assert_eq!(original[1].text,"original");
}
