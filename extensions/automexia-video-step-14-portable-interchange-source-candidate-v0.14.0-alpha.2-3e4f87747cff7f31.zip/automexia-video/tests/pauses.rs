//! Real Rust tests of Step 4. Synthetic frame fixtures isolate exact boundaries;
//! native_pauses additionally exercises the delivered Rust/FFmpeg integration.
use automexia_video::*;
use automexia_video::pause::*;
use automexia_video::pause_metrics::MetricParser;
use automexia_video::project::*;
use automexia_video::host::{FileStamp,InputFile,RuntimeCapabilities};
use automexia_video::media::parse_probe;
use std::path::PathBuf;
fn r(s:&str)->Rational{s.parse().unwrap()}
fn span(a:&str,b:&str)->TimeRange{TimeRange::new(r(a),r(b)).unwrap()}
fn location()->PathBuf{std::env::temp_dir().join("video-pause-tests").join("session.amxv")}
fn project()->Project {
    let mut m=parse_probe(include_bytes!("fixtures/probe-base.json")).unwrap();
    m.duration=Some(r("10"));m.start_time=Some(r("0"));
    for s in &mut m.streams {
        s.start_pts=Some(0);s.start_time=Some(r("0"));s.duration=Some(r("10"));
        s.duration_ts=Some(s.time_base.unwrap().inverse().unwrap().ticks(10).unwrap().numerator());
        if s.kind=="video" {s.nominal_frame_rate=Some(r("30"));s.average_frame_rate=Some(r("30"));}
    }
    let input=InputFile{canonical_path:location().parent().unwrap().join("input.mp4"),stamp:FileStamp{size:123,modified_ns:None,sha256:"a".repeat(64),file_id:None}};
    let source=ProjectSource::from_probe("source-1",&input,&m,m.select(StreamSelection::default()).unwrap(),&location()).unwrap();
    Project::new("pauses",source,ResolvedSettings{ workflow:None,voice_cleanup:None,voice_enhancement:None,color_correction:None,preset_name:Some("clean".into()),preset_revision:Some("1".into()),
        render:automexia_video::project::FrozenRenderSettings::from_options(&RenderOptions::default()).unwrap(),pause_cleanup:None}).unwrap()
}
fn level(rms:f64,peak:f64)->ChannelEnergy{ChannelEnergy{rms_dbfs:Some(rms),peak_dbfs:Some(peak)}}
fn silent()->ChannelEnergy{ChannelEnergy{rms_dbfs:None,peak_dbfs:None}}
fn frame(index:i64,channels:Vec<ChannelEnergy>)->EnergyFrame{EnergyFrame{pts:index*960,samples:960,channels}}
fn analyze(settings:PauseSettings,signal:impl Fn(i64)->Vec<ChannelEnergy>)->EnergyObservation {
    let n=signal(0).len();let mut a=EnergyAnalyzer::new(48000,n,r("0"),r("10"),settings).unwrap();
    for i in 0..500 {a.push(frame(i,signal(i)),&Cancellation::new()).unwrap();}
    a.finish(&Cancellation::new()).unwrap()
}
fn ordinary(i:i64)->Vec<ChannelEnergy>{vec![if (100..300).contains(&i){silent()}else{level(-20.0,-14.0)}]}
fn report(p:&Project,settings:PauseSettings)->PauseReport{propose_pauses(p,analyze(settings,ordinary),&Cancellation::new()).unwrap()}
fn approve_all(p:&mut Project){let ids:Vec<_>=p.operations.iter().filter(|o|ours_test(o)).map(|o|o.id.clone()).collect();for id in ids{p.review_operation(&id,Disposition::AutoApply,true).unwrap();}}
fn ours_test(o:&EditOperation)->bool{matches!(&o.origin,EditOrigin::Generator{id,..} if id==PAUSE_GENERATOR)}
fn metric(pts:i64,rms:&str,peak:&str)->String{format!("frame:0 pts:{pts} pts_time:0\nlavfi.astats.1.Peak_level={peak}\nlavfi.astats.1.RMS_level={rms}\nlavfi.astats.1.Number of NaNs=0.000000\nlavfi.astats.1.Number of Infs=0.000000\nlavfi.astats.Overall.Number_of_samples=960.000000\n")}
fn parse(text:&[u8])->Result<Vec<EnergyFrame>>{let mut p=MetricParser::new(1)?;let mut frames=vec![];p.feed(text,&mut |f|{frames.push(f);Ok(())})?;p.finish(&mut |f|{frames.push(f);Ok(())})?;Ok(frames)}

#[test]fn presets_are_valid_conservative_and_distinct(){for s in [PauseSettings::clean(),PauseSettings::social(),PauseSettings::podcast()]{s.validate().unwrap();assert!(!s.allow_mixed_music_proposals);}assert_ne!(PauseSettings::clean(),PauseSettings::podcast());}
#[test]fn settings_roundtrip_preserves_all_resolved_values(){let s=PauseSettings::social();let v=serde_json::to_vec(&s).unwrap();assert_eq!(serde_json::from_slice::<PauseSettings>(&v).unwrap(),s);}
#[test]fn aggressive_or_invalid_settings_are_rejected(){for field in ["quiet_rms_dbfs","quiet_peak_dbfs","min_quiet_ms","padding_before_ms","padding_after_ms","min_retained_pause_ms","min_segment_ms","min_cut_spacing_ms","max_cuts","max_analysis_seconds"]{let mut v=serde_json::to_value(PauseSettings::clean()).unwrap();v[field]=serde_json::json!(0);let result=serde_json::from_value::<PauseSettings>(v);assert!(result.is_err()||result.unwrap().validate().is_err(),"{field}");}}
#[test]fn missing_settings_are_not_filled_from_changed_defaults(){let mut v=serde_json::to_value(PauseSettings::clean()).unwrap();v.as_object_mut().unwrap().remove("min_retained_pause_ms");assert!(serde_json::from_value::<PauseSettings>(v).is_err());}
#[test]fn unknown_settings_are_rejected(){let mut v=serde_json::to_value(PauseSettings::clean()).unwrap();v["run"]=serde_json::json!("shell");assert!(serde_json::from_value::<PauseSettings>(v).is_err());}
#[test]fn silence_is_none_not_a_serialized_infinity(){let v=serde_json::to_value(silent()).unwrap();assert!(v["rms_dbfs"].is_null());silent().validate().unwrap();}
#[test]fn nan_positive_infinity_and_rms_above_peak_rejected(){for ch in [level(f64::NAN,0.0),level(0.0,f64::INFINITY),level(-10.0,-20.0),ChannelEnergy{rms_dbfs:None,peak_dbfs:Some(-10.0)}]{assert!(ch.validate().is_err());}}
#[test]fn ordinary_pause_is_bounded_and_measured_exactly(){let o=analyze(PauseSettings::clean(),ordinary);assert_eq!(o.quiet_intervals().len(),1);assert_eq!(o.quiet_intervals()[0].range,span("2","6"));assert!(o.quiet_intervals()[0].bounded_by_activity);assert_eq!(o.summary().observed_duration,r("10"));assert_eq!(o.summary().measured_quiet_duration,r("4"));}
#[test]fn no_frames_and_no_in_range_audio_fail(){let a=EnergyAnalyzer::new(48000,1,r("0"),r("10"),PauseSettings::clean()).unwrap();assert!(a.finish(&Cancellation::new()).is_err());}
#[test]fn long_all_silent_media_never_becomes_an_automatic_cut(){let o=analyze(PauseSettings::clean(),|_|vec![silent()]);assert!(!o.quiet_intervals()[0].bounded_by_activity);let x=propose_pauses(&project(),o,&Cancellation::new()).unwrap();assert!(x.candidates().is_empty());}
#[test]fn short_pauses_remain(){let o=analyze(PauseSettings::clean(),|i|vec![if (100..130).contains(&i){silent()}else{level(-20.0,-14.0)}]);assert!(o.quiet_intervals().is_empty());}
#[test]fn quiet_words_above_rms_floor_prevent_a_cut(){let o=analyze(PauseSettings::clean(),|i|if (100..300).contains(&i){vec![level(-46.0,-41.0)]}else{ordinary(i)});assert!(o.quiet_intervals().is_empty());}
#[test]fn low_rms_with_peak_transients_is_not_silence(){let o=analyze(PauseSettings::clean(),|i|if (100..300).contains(&i){vec![level(-60.0,-25.0)]}else{ordinary(i)});assert!(o.quiet_intervals().is_empty());}
#[test]fn one_audible_channel_prevents_phase_cancellation_false_silence(){let o=analyze(PauseSettings::clean(),|_|vec![silent(),level(-22.0,-14.0)]);assert!(o.quiet_intervals().is_empty());}
#[test]fn weak_flanks_are_not_speech_evidence(){let o=analyze(PauseSettings::clean(),|i|if (100..300).contains(&i){vec![silent()]}else{vec![level(-47.0,-38.0)]});assert!(!o.quiet_intervals()[0].bounded_by_activity);}
#[test]fn brief_click_is_not_enough_to_close_a_pause(){let o=analyze(PauseSettings::clean(),|i|if i==300{vec![level(-10.0,-2.0)]}else if (100..490).contains(&i){vec![silent()]}else{ordinary(i)});assert!(!o.quiet_intervals()[0].bounded_by_activity);}
#[test]fn timestamp_gap_breaks_quiet_continuity(){let mut a=EnergyAnalyzer::new(48000,1,r("0"),r("10"),PauseSettings::clean()).unwrap();for i in 0..100{a.push(frame(i,vec![level(-20.0,-14.0)]),&Cancellation::new()).unwrap();}for i in 100..200{a.push(frame(i,vec![silent()]),&Cancellation::new()).unwrap();}for i in 300..500{a.push(frame(i,ordinary(i)),&Cancellation::new()).unwrap();}let o=a.finish(&Cancellation::new()).unwrap();assert_eq!(o.summary().discontinuities,1);assert!(o.summary().uncovered_duration>=r("2"));assert!(o.quiet_intervals().iter().all(|q|!q.bounded_by_activity));}
#[test]fn backward_timestamps_fail_and_poison_analyzer(){let mut a=EnergyAnalyzer::new(48000,1,r("0"),r("10"),PauseSettings::clean()).unwrap();a.push(frame(1,vec![silent()]),&Cancellation::new()).unwrap();assert!(a.push(frame(0,vec![silent()]),&Cancellation::new()).is_err());assert!(a.finish(&Cancellation::new()).is_err());}
#[test]fn coarse_frames_are_not_mistaken_for_precise_speech_boundaries(){let mut a=EnergyAnalyzer::new(48000,1,r("0"),r("10"),PauseSettings::clean()).unwrap();let mut f=frame(0,vec![silent()]);f.samples=24000;assert!(a.push(f,&Cancellation::new()).is_err());}
#[test]fn source_timestamp_origin_is_subtracted_exactly(){let mut a=EnergyAnalyzer::new(48000,1,r("3600"),r("10"),PauseSettings::clean()).unwrap();for i in 0..500{let mut f=frame(i,ordinary(i));f.pts+=3600*48000;a.push(f,&Cancellation::new()).unwrap();}assert_eq!(a.finish(&Cancellation::new()).unwrap().quiet_intervals()[0].range,span("2","6"));}
#[test]fn cancelled_analysis_does_not_return_partial_observations(){let mut a=EnergyAnalyzer::new(48000,1,r("0"),r("10"),PauseSettings::clean()).unwrap();let c=Cancellation::new();c.cancel();assert!(matches!(a.push(frame(0,vec![silent()]),&c),Err(Error::Cancelled)));}
#[test]fn proposal_padding_and_retained_duration_are_exact(){let p=project();let x=report(&p,PauseSettings::clean());assert_eq!(x.candidates().len(),1);assert_eq!(x.candidates()[0].operation.range,span("89/40","229/40"));assert_eq!(x.candidates()[0].retained_pause,r("1/2"));assert_eq!(x.proposed_duration(),r("13/2"));}
#[test]fn analysis_never_mutates_project(){let p=project();let bytes=p.to_json().unwrap();let _=report(&p,PauseSettings::clean());assert_eq!(p.to_json().unwrap(),bytes);}
#[test]fn all_new_cuts_require_review_and_cannot_render(){let mut p=project();report(&p,PauseSettings::clean()).apply(&mut p).unwrap();assert!(p.operations.iter().all(|o|o.disposition==Disposition::NeedsReview&&!o.user_override&&!o.locked));assert!(matches!(p.timeline(),Err(Error::UnresolvedEdits)));}
#[test]fn approve_renders_shorter_and_reject_restores(){let mut p=project();let x=report(&p,PauseSettings::clean());x.apply(&mut p).unwrap();approve_all(&mut p);assert_eq!(p.timeline().unwrap().duration,x.proposed_duration());let id=p.operations[0].id.clone();p.review_operation(&id,Disposition::Ignore,false).unwrap();assert_eq!(p.timeline().unwrap().duration,r("10"));}
#[test]fn stale_report_is_rejected_without_half_applying(){let mut p=project();let x=report(&p,PauseSettings::clean());p.protect_range("source-1",span("0","1"),"manual").unwrap();let bytes=p.to_json().unwrap();assert!(matches!(x.apply(&mut p),Err(Error::StaleReview)));assert_eq!(p.to_json().unwrap(),bytes);}
#[test]fn changing_project_without_revision_invalidates_report(){let mut p=project();let x=report(&p,PauseSettings::clean());p.settings.preset_name=Some("changed".into());assert!(matches!(x.apply(&mut p),Err(Error::StaleReview)));}
#[test]fn protected_region_is_not_cut_or_split_around(){let mut p=project();p.protect_range("source-1",span("3","4"),"keep this").unwrap();let x=report(&p,PauseSettings::clean());assert!(x.candidates().is_empty());assert!(x.skipped().iter().any(|x|x.reason==PauseSkip::ProtectedOrReviewed));}
#[test]fn locked_assembly_is_untouched(){let mut p=project();p.set_clip_locked("clip-1",true).unwrap();assert!(report(&p,PauseSettings::clean()).candidates().is_empty());}
#[test]fn rejected_manual_range_is_not_recreated(){let mut p=project();let id=p.remove_range("source-1",span("3","4"),"consider").unwrap();p.review_operation(&id,Disposition::Ignore,false).unwrap();assert!(report(&p,PauseSettings::clean()).candidates().is_empty());}
#[test]fn recomputation_preserves_reviewed_rejection_and_lock(){let mut p=project();report(&p,PauseSettings::clean()).apply(&mut p).unwrap();let id=p.operations[0].id.clone();p.review_operation(&id,Disposition::Ignore,false).unwrap();p.set_operation_locked(&id,true).unwrap();let x=report(&p,PauseSettings::social());assert!(x.candidates().is_empty());x.apply(&mut p).unwrap();assert_eq!(p.operations[0].id,id);assert!(p.operations[0].locked);assert!(!p.operations[0].enabled);}
#[test]fn recomputation_replaces_unreviewed_proposals_not_duplicates(){let mut p=project();report(&p,PauseSettings::clean()).apply(&mut p).unwrap();let id=p.operations[0].id.clone();report(&p,PauseSettings::social()).apply(&mut p).unwrap();assert_eq!(p.operations.len(),1);assert_eq!(p.operations[0].id,id);assert_eq!(p.operations[0].disposition,Disposition::NeedsReview);}
#[test]fn reviewed_fade_settings_cannot_change_on_reanalysis(){let mut p=project();report(&p,PauseSettings::clean()).apply(&mut p).unwrap();approve_all(&mut p);let mut s=PauseSettings::clean();s.join_fade_ms=0;assert!(propose_pauses(&p,analyze(s,ordinary),&Cancellation::new()).is_err());}
#[test]fn declared_music_is_preserved_by_default(){let mut s=PauseSettings::clean();s.content=AudioContent::MixedMusic;assert!(report(&project(),s).candidates().is_empty());}
#[test]fn explicit_music_proposal_remains_pending_and_warns(){let mut s=PauseSettings::clean();s.content=AudioContent::MixedMusic;s.allow_mixed_music_proposals=true;let x=report(&project(),s);assert_eq!(x.candidates().len(),1);assert_eq!(x.candidates()[0].operation.disposition,Disposition::NeedsReview);assert!(x.warnings().iter().any(|s|s.contains("music")));}
#[test]fn fraction_limit_is_not_silently_exceeded(){let mut s=PauseSettings::clean();s.max_removed_per_mille=100;let x=report(&project(),s);assert!(x.candidates().is_empty());assert!(x.skipped().iter().any(|s|s.reason==PauseSkip::RemovalBudget));}
#[test]fn assembly_boundaries_cannot_leave_short_retained_islands(){let mut p=project();p.set_keep_ranges("source-1",&[span("2","8")]).unwrap();assert!(report(&p,PauseSettings::clean()).candidates().is_empty());}
#[test]fn no_audio_is_explicitly_unsupported(){let mut p=project();p.sources[0].media.audio=None;assert!(propose_pauses(&p,analyze(PauseSettings::clean(),ordinary),&Cancellation::new()).is_err());}
#[test]fn channel_mismatch_rejected(){let p=project();let o=analyze(PauseSettings::clean(),|i|vec![ordinary(i)[0],silent()]);assert!(propose_pauses(&p,o,&Cancellation::new()).is_err());}
#[test]fn audio_fades_apply_only_to_pause_joins(){let mut p=project();report(&p,PauseSettings::clean()).apply(&mut p).unwrap();approve_all(&mut p);let edit=automexia_video::edit_render::EditRender::from_project(&p).unwrap();assert_eq!(edit.join_fades_samples,vec![(0,240),(240,0)]);let g=edit.filter_graph(0,Some(1),false).unwrap();assert!(g.contains("afade=t=out:"));assert!(g.contains("afade=t=in:ss=0:ns=240"));assert_eq!(edit.duration,p.timeline().unwrap().duration);}
#[test]fn ordinary_manual_cuts_keep_legacy_audio_behavior(){let mut p=project();p.remove_range("source-1",span("2","4"),"manual").unwrap();let edit=automexia_video::edit_render::EditRender::from_project(&p).unwrap();assert!(edit.join_fades_samples.iter().all(|x|*x==(0,0)));assert!(!edit.filter_graph(0,Some(1),false).unwrap().contains("afade"));}
#[test]fn splitting_contiguous_clips_does_not_fade_join(){let mut p=project();p.settings.pause_cleanup=Some(PauseSettings::clean());p.split_clip("clip-1",r("5")).unwrap();let edit=automexia_video::edit_render::EditRender::from_project(&p).unwrap();assert!(edit.join_fades_samples.iter().all(|x|*x==(0,0)));}
#[test]fn zero_join_fade_is_preserved(){let mut s=PauseSettings::clean();s.join_fade_ms=0;let mut p=project();report(&p,s).apply(&mut p).unwrap();approve_all(&mut p);assert!(automexia_video::edit_render::EditRender::from_project(&p).unwrap().join_fades_samples.iter().all(|x|*x==(0,0)));}
#[test]fn v1_migration_preserves_no_pause_processing(){let mut v=serde_json::to_value(project()).unwrap();v["schema_version"]=serde_json::json!(1);let p=Project::from_json(&serde_json::to_vec(&v).unwrap()).unwrap();assert_eq!(p.schema_version,automexia_video::project::PROJECT_VERSION);assert!(p.settings.pause_cleanup.is_none());assert_eq!(p.timeline().unwrap().duration,r("10"));}
#[test]fn v1_cannot_smuggle_new_processing_fields(){let mut v=serde_json::to_value(project()).unwrap();v["schema_version"]=serde_json::json!(1);v["settings"]["pause_cleanup"]=serde_json::to_value(PauseSettings::clean()).unwrap();assert!(Project::from_json(&serde_json::to_vec(&v).unwrap()).is_err());}
#[test]fn saved_pause_config_and_decisions_roundtrip(){let mut p=project();report(&p,PauseSettings::clean()).apply(&mut p).unwrap();let b=p.to_json().unwrap();assert_eq!(Project::from_json(&b).unwrap().to_json().unwrap(),b);}
#[test]fn unknown_pause_generator_version_is_rejected(){let mut p=project();report(&p,PauseSettings::clean()).apply(&mut p).unwrap();p.operations[0].origin=EditOrigin::Generator{id:PAUSE_GENERATOR.into(),version:"999".into()};assert!(p.validate().is_err());}
#[test]fn report_application_in_review_is_dirty_and_invalidates_old_frame(){let p=project();let x=report(&p,PauseSettings::clean());let mut s=ReviewSession::new(p).unwrap();let old=s.snapshot().unwrap();let c=s.preview_cancellation(&old.token).unwrap();let view=s.apply_pause_report(&old.token,&x).unwrap();assert!(view.dirty);assert!(c.is_cancelled());assert!(s.dispatch(&old.token,ReviewCommand::Next).is_err());}
#[test]fn closed_review_refuses_late_pause_analysis(){let p=project();let x=report(&p,PauseSettings::clean());let mut s=ReviewSession::new(p).unwrap();let old=s.snapshot().unwrap();s.close();assert!(matches!(s.apply_pause_report(&old.token,&x),Err(Error::ReviewClosed)));}
#[test]fn metrics_match_real_ffmpeg_key_spelling(){let f=parse(metric(48000,"-55","-48").as_bytes()).unwrap();assert_eq!(f[0].pts,48000);assert_eq!(f[0].samples,960);assert_eq!(f[0].channels[0],level(-55.0,-48.0));}
#[test]fn metrics_accept_chunking_at_every_byte(){let text=metric(0,"-inf","-inf");let mut p=MetricParser::new(1).unwrap();let mut frames=vec![];for b in text.as_bytes(){p.feed(&[*b],&mut |f|{frames.push(f);Ok(())}).unwrap();}p.finish(&mut |f|{frames.push(f);Ok(())}).unwrap();assert_eq!(frames.len(),1);assert_eq!(frames[0].channels[0],silent());}
#[test]fn metrics_require_all_channels_samples_and_finiteness(){for bad in [metric(0,"-50","-40").replace("lavfi.astats.1.Number of NaNs=0.000000\n",""),metric(0,"-50","-40").replace("Number_of_samples=960.000000","Number_of_samples=1.2"),metric(0,"-50","-40").replace("Number of Infs=0.000000","Number of Infs=1.000000")]{assert!(parse(bad.as_bytes()).is_err());}}
#[test]fn duplicate_metric_key_rejected(){let s=metric(0,"-50","-40")+"lavfi.astats.1.RMS_level=-50\n";assert!(parse(s.as_bytes()).is_err());}
#[test]fn metrics_reject_wrong_sequence_and_missing_timestamp(){for s in [metric(0,"-50","-40").replace("frame:0","frame:2"),metric(0,"-50","-40").replace("pts:0","pts:NOPTS")]{assert!(parse(s.as_bytes()).is_err());}}
#[test]fn malformed_diagnostics_are_not_treated_as_metrics(){assert!(parse(b"file=private\n").is_err());assert!(parse(&[0,1,2,3]).is_err());}
#[test]fn metric_parser_bounds_lines_and_fails_permanently(){let mut p=MetricParser::new(1).unwrap();let mut ignore=|_|Ok(());assert!(p.feed(&vec![b'a';257],&mut ignore).is_err());assert!(p.feed(metric(0,"-50","-40").as_bytes(),&mut ignore).is_err());}
#[test]fn metric_sink_failure_is_not_a_successful_analysis(){let mut p=MetricParser::new(1).unwrap();p.feed(metric(0,"-50","-40").as_bytes(),&mut |_|Ok(())).unwrap();assert!(matches!(p.finish(&mut |_|Err(Error::Cancelled)),Err(Error::Cancelled)));}
#[test]fn fractional_sample_rounding_is_inward(){assert_eq!(r("1/3").floor_units(10).unwrap(),3);assert_eq!(r("-1/3").floor_units(10).unwrap(),-4);assert_eq!(r("1/3").ceil_units(10).unwrap(),4);}

#[test]fn coarse_container_timestamp_quantization_is_bounded_and_reported(){
    let mut a=EnergyAnalyzer::with_timestamp_resolution(48000,1,r("0"),r("10"),PauseSettings::clean(),r("1/1000")).unwrap();
    a.push(frame(0,vec![level(-20.,-10.)]),&Cancellation::new()).unwrap();
    a.push(EnergyFrame{pts:950,samples:960,channels:vec![level(-20.,-10.)]},&Cancellation::new()).unwrap();
    let x=a.finish(&Cancellation::new()).unwrap();assert_eq!(x.summary().timestamp_rounding_events,1);assert_eq!(x.summary().timestamp_tolerance_samples,49);
    assert_eq!(x.summary().observed_duration,r("191/4800"));
}
#[test]fn container_timebase_does_not_permit_arbitrary_overlap(){
    let mut a=EnergyAnalyzer::with_timestamp_resolution(48000,1,r("0"),r("10"),PauseSettings::clean(),r("1/1000")).unwrap();
    a.push(frame(0,vec![level(-20.,-10.)]),&Cancellation::new()).unwrap();
    assert!(a.push(EnergyFrame{pts:900,samples:960,channels:vec![level(-20.,-10.)]},&Cancellation::new()).is_err());
}
#[test]fn excessive_timestamp_quantization_is_not_guessed(){
    assert!(EnergyAnalyzer::with_timestamp_resolution(48000,1,r("0"),r("10"),PauseSettings::clean(),r("1/100")).is_err());
}

#[test]fn captured_native_metric_frame_uses_the_fixed_parser_contract(){
    let frames=parse(include_bytes!("fixtures/pause-astats-frame.txt")).unwrap();
    assert_eq!(frames.len(),1);assert_eq!(frames[0].pts,0);assert_eq!(frames[0].samples,1024);assert_eq!(frames[0].channels.len(),1);
}
#[test]fn all_chunk_boundaries_leave_observations_identical(){
    let text=metric(0,"-20","-14")+&metric(960,"-inf","-inf").replace("frame:0","frame:1");
    let expected=parse(text.as_bytes()).unwrap();
    for size in 1..64 {let mut parser=MetricParser::new(1).unwrap();let mut frames=vec![];
        for chunk in text.as_bytes().chunks(size){parser.feed(chunk,&mut |f|{frames.push(f);Ok(())}).unwrap();}
        parser.finish(&mut |f|{frames.push(f);Ok(())}).unwrap();
        assert_eq!(serde_json::to_value(frames).unwrap(),serde_json::to_value(&expected).unwrap());}
}
#[test]fn repeated_nonincreasing_frames_cannot_invent_quiet_time(){
    let mut a=EnergyAnalyzer::with_timestamp_resolution(48000,1,r("0"),r("10"),PauseSettings::clean(),r("1/1000")).unwrap();
    a.push(frame(0,vec![silent()]),&Cancellation::new()).unwrap();assert!(a.push(frame(0,vec![silent()]),&Cancellation::new()).is_err());
}
#[test]fn approved_fades_are_not_applied_to_unresolved_operations(){
    let mut p=project();report(&p,PauseSettings::clean()).apply(&mut p).unwrap();
    assert!(matches!(automexia_video::edit_render::EditRender::from_project(&p),Err(Error::UnresolvedEdits)));
}
#[test]fn truncated_final_numeric_metric_is_not_a_complete_frame(){
    let mut s=metric(0,"-20","-14");s.pop();assert!(parse(s.as_bytes()).is_err());
}
#[test]fn truncated_frame_missing_final_count_cannot_succeed(){
    let s=metric(0,"-20","-14");let s=s.split("lavfi.astats.Overall").next().unwrap();assert!(parse(s.as_bytes()).is_err());
}
#[test]fn missing_pause_snapshot_is_not_silently_defaulted(){
    let mut p=project();report(&p,PauseSettings::clean()).apply(&mut p).unwrap();p.settings.pause_cleanup=None;assert!(p.validate().is_err());
}
#[test]fn too_many_channels_or_zero_rate_fail_before_audio_work(){
    for (rate,channels) in [(0,1),(48000,0),(48000,9)]{assert!(EnergyAnalyzer::new(rate,channels,r("0"),r("10"),PauseSettings::clean()).is_err());}
}
#[test]fn redundant_pause_decision_does_not_fade_an_existing_manual_cut(){
    let mut p=project();report(&p,PauseSettings::clean()).apply(&mut p).unwrap();approve_all(&mut p);
    p.remove_range("source-1",span("2","6"),"already manually removed").unwrap();
    assert!(automexia_video::edit_render::EditRender::from_project(&p).unwrap().join_fades_samples.iter().all(|x|*x==(0,0)));
}
#[test]fn proposed_preview_keeps_authoritative_pause_join_fades(){
    let mut p=project();report(&p,PauseSettings::clean()).apply(&mut p).unwrap();
    let request=PreviewRequest::new(&p,location(),location().parent().unwrap(),ReviewTarget::Operation(p.operations[0].id.clone())).unwrap();
    let preview=automexia_video::preview::PreviewPlan::build(&p,&request).unwrap();
    let runtime=RuntimeCapabilities{supports_demux_time_base:true,bitstream_filters:["setts".into()].into_iter().collect(),encoders:["libx264".into(),"aac".into()].into_iter().collect(),muxers:["mp4".into()].into_iter().collect(),filters:["settb","setpts","select","asetpts","aresample","apad","atrim","anull","asplit","concat","afade","scale","setsar"].map(str::to_owned).into_iter().collect(),..Default::default()};
    let current=p.sources[0].media.as_media_info();
    let proposed=preview.render_plan(PreviewSide::Proposed,&current,&runtime).unwrap().unwrap();
    assert_eq!(proposed.edited_timeline().unwrap().join_fades_samples,vec![(0,240),(240,0)]);
    let before=preview.render_plan(PreviewSide::Before,&current,&runtime).unwrap().unwrap();
    assert!(before.edited_timeline().unwrap().join_fades_samples.iter().all(|f|*f==(0,0)));
    assert_eq!(p.operations[0].disposition,Disposition::NeedsReview);
}
