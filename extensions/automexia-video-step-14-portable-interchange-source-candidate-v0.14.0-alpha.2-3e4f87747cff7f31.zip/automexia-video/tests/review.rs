//! These are Rust tests of the delivered implementation, not Python simulations.
use automexia_video::*;
use automexia_video::host::{FileStamp, InputFile, RuntimeCapabilities};
use automexia_video::media::parse_probe;
use automexia_video::plan::{RenderOptions, build_edited_plan};
use automexia_video::preview::{PreviewPlan, MAX_PROXY_BYTES};
use automexia_video::project::*;
use automexia_video::review::*;
use std::path::PathBuf;

fn r(s:&str)->Rational { s.parse().unwrap() }
fn range(a:&str,b:&str)->TimeRange { TimeRange::new(r(a),r(b)).unwrap() }
fn location()->PathBuf { std::env::temp_dir().join("video-review-tests").join("review.amxv") }
fn project()->Project {
    let media=parse_probe(include_bytes!("fixtures/probe-base.json")).unwrap();
    let input=InputFile { canonical_path:location().parent().unwrap().join("input.mp4"),
        stamp:FileStamp {size:100,sha256:"a".repeat(64),modified_ns:None,file_id:None} };
    let source=ProjectSource::from_probe("source-1",&input,&media,media.select(StreamSelection::default()).unwrap(),&location()).unwrap();
    Project::new("review-project",source,ResolvedSettings { voice_enhancement:None,workflow:None,voice_cleanup:None,color_correction:None,pause_cleanup:None,preset_name:None,preset_revision:None,
        render:FrozenRenderSettings::from_options(&RenderOptions::default()).unwrap()}).unwrap()
}
fn pending()->Project {
    let mut p=project();
    p.add_operation(EditOperation {id:"candidate".into(),source_id:"source-1".into(),kind:EditKind::RemoveRange,
        range:range("1/2","1"),reason:"A proposed cut, not an automatic detector result".into(),
        origin:EditOrigin::Generator{id:"test-observer".into(),version:"1".into()},disposition:Disposition::NeedsReview,
        enabled:true,locked:false,user_override:false}).unwrap(); p
}
fn op()->ReviewTarget { ReviewTarget::Operation("candidate".into()) }
fn selected(p:Project)->ReviewSession {
    let mut s=ReviewSession::new(p).unwrap();let v=s.snapshot().unwrap();
    s.dispatch(&v.token,ReviewCommand::Select(op())).unwrap();s
}
fn request(p:&Project)->PreviewRequest {
    PreviewRequest::new(p,location(),location().parent().unwrap().to_owned(),op()).unwrap()
}
fn caps()->RuntimeCapabilities {
    RuntimeCapabilities { encoders:["libx264","aac"].map(str::to_owned).into_iter().collect(),
        muxers:["mp4".into()].into_iter().collect(),bitstream_filters:["setts".into()].into_iter().collect(),
        filters:["settb","setpts","select","asetpts","aresample","apad","atrim","anull","asplit","concat","scale","setsar"].map(str::to_owned).into_iter().collect(),
        supports_demux_time_base:true,..Default::default() }
}
fn describe(p:&Project,req:&PreviewRequest)->PreviewPlan { PreviewPlan::build(p,req).unwrap() }

#[test] fn review_open_does_not_change_project_bytes() {
    let p=pending();let before=p.to_json().unwrap();let s=ReviewSession::new(p).unwrap();
    assert_eq!(s.project().to_json().unwrap(),before);assert!(!s.snapshot().unwrap().dirty);
}
#[test] fn list_contains_clips_and_real_operations() {
    let v=ReviewSession::new(pending()).unwrap().snapshot().unwrap();
    assert_eq!(v.total_count,2);assert_eq!(v.matched_count,2);assert_eq!(v.rows.len(),2);
    assert!(v.rows.iter().any(|r|r.target==op() && r.disposition==Disposition::NeedsReview));
}
#[test] fn no_confidence_number_is_fabricated() {
    assert!(review_rows(&pending()).unwrap().iter().all(|r|r.confidence.is_none()));
}
#[test] fn row_uses_exact_source_time_and_reason() {
    let row=detail(&pending(),&op()).unwrap().row;
    assert_eq!(row.source_range,range("1/2","1"));assert_eq!(row.original_interval_duration,r("1/2"));
    assert!(row.reason.contains("not an automatic detector"));
}
#[test] fn pending_summary_does_not_authorize_final_render() {
    let v=summary(&pending()).unwrap();assert_eq!(v.active_pending_count,1);
    assert!(!v.decisions_renderable);assert!(v.final_duration.is_none());
}
#[test] fn detail_compares_selected_off_and_on_without_approval() {
    let p=pending();let original=p.to_json().unwrap();let d=detail(&p,&op()).unwrap();
    assert_eq!(d.duration_without_selected,Some(p.sources[0].duration));
    assert_eq!(d.duration_with_selected,Some(p.sources[0].duration.checked_sub(r("1/2")).unwrap()));
    assert_eq!(p.to_json().unwrap(),original);assert!(matches!(p.timeline(),Err(Error::UnresolvedEdits)));
}
#[test] fn approve_commits_enabled_and_disposition_in_one_revision() {
    let mut s=selected(pending());let rev=s.project().revision;let v=s.snapshot().unwrap();
    let v=s.dispatch(&v.token,ReviewCommand::Approve).unwrap();
    assert_eq!(s.project().revision,rev+1);assert!(v.dirty);assert!(v.summary.decisions_renderable);
    assert!(s.project().operations[0].enabled);assert!(s.project().operations[0].user_override);
}
#[test] fn reject_restores_omitted_footage() {
    let mut s=selected(pending());let v=s.snapshot().unwrap();s.dispatch(&v.token,ReviewCommand::Reject).unwrap();
    assert_eq!(s.project().timeline().unwrap().duration,s.project().sources[0].duration);
    assert!(!s.project().operations[0].enabled);assert_eq!(s.project().operations[0].disposition,Disposition::Ignore);
}
#[test] fn approval_preserves_original_generator_attribution() {
    let mut s=selected(pending());let v=s.snapshot().unwrap();s.dispatch(&v.token,ReviewCommand::Approve).unwrap();
    assert!(matches!(&s.project().operations[0].origin,EditOrigin::Generator{id,version} if id=="test-observer"&&version=="1"));
}
#[test] fn locked_decision_cannot_be_approved_or_rejected() {
    let mut s=selected(pending());let v=s.snapshot().unwrap();let v=s.dispatch(&v.token,ReviewCommand::SetLocked(true)).unwrap();
    let before=s.project().to_json().unwrap();assert!(matches!(s.dispatch(&v.token,ReviewCommand::Approve),Err(Error::LockedEdit)));
    assert!(matches!(s.dispatch(&v.token,ReviewCommand::Reject),Err(Error::LockedEdit)));assert_eq!(s.project().to_json().unwrap(),before);
}
#[test] fn explicit_unlock_allows_later_decision() {
    let mut s=selected(pending());let v=s.snapshot().unwrap();let v=s.dispatch(&v.token,ReviewCommand::SetLocked(true)).unwrap();
    let v=s.dispatch(&v.token,ReviewCommand::SetLocked(false)).unwrap();s.dispatch(&v.token,ReviewCommand::Approve).unwrap();
    assert!(s.project().timeline().is_ok());
}
#[test] fn range_change_invalidates_previously_approved_decision() {
    let mut s=selected(pending());let v=s.snapshot().unwrap();let v=s.dispatch(&v.token,ReviewCommand::Approve).unwrap();
    s.dispatch(&v.token,ReviewCommand::ChangeRange(range("1/4","3/4"))).unwrap();
    assert!(matches!(s.project().timeline(),Err(Error::UnresolvedEdits)));
}
#[test] fn disabled_pending_decision_is_not_applied() {
    let mut s=selected(pending());let v=s.snapshot().unwrap();s.dispatch(&v.token,ReviewCommand::SetEnabled(false)).unwrap();
    assert_eq!(s.project().timeline().unwrap().duration,s.project().sources[0].duration);
}
#[test] fn enabling_a_pending_decision_does_not_approve_it() {
    let mut s=selected(pending());let v=s.snapshot().unwrap();let v=s.dispatch(&v.token,ReviewCommand::SetEnabled(false)).unwrap();
    s.dispatch(&v.token,ReviewCommand::SetEnabled(true)).unwrap();assert!(matches!(s.project().timeline(),Err(Error::UnresolvedEdits)));
}
#[test] fn approval_of_a_disabled_decision_is_explicit_enablement() {
    let mut p=pending();p.set_operation_enabled("candidate",false).unwrap();let mut s=selected(p);let v=s.snapshot().unwrap();
    s.dispatch(&v.token,ReviewCommand::Approve).unwrap();assert!(s.project().operations[0].enabled);assert!(s.project().timeline().is_ok());
}
#[test] fn invalid_range_change_is_atomic() {
    let mut s=selected(pending());let v=s.snapshot().unwrap();let before=s.project().to_json().unwrap();
    assert!(s.dispatch(&v.token,ReviewCommand::ChangeRange(range("1","100"))).is_err());
    assert_eq!(before,s.project().to_json().unwrap());assert_eq!(v.token,s.snapshot().unwrap().token);
}
#[test] fn stale_view_cannot_apply_a_decision() {
    let mut s=selected(pending());let old=s.snapshot().unwrap();s.dispatch(&old.token,ReviewCommand::Inspect).unwrap();
    assert!(matches!(s.dispatch(&old.token,ReviewCommand::Approve),Err(Error::StaleReview)));
}
#[test] fn foreign_session_token_is_rejected() {
    let a=selected(pending());let mut b=selected(pending());
    assert!(matches!(b.dispatch(&a.snapshot().unwrap().token,ReviewCommand::Approve),Err(Error::StaleReview)));
}
#[test] fn old_binding_detects_same_revision_content_changes() {
    let p=pending();let b=ReviewBinding::capture(&p).unwrap();let mut changed=p.clone();changed.operations[0].reason="edited outside the UI".into();
    assert_eq!(p.revision,changed.revision);assert!(matches!(b.check(&changed),Err(Error::StaleReview)));
}
#[test] fn render_history_does_not_change_review_binding() {
    let p=project();let b=ReviewBinding::capture(&p).unwrap();let mut p=p;
    p.record_render(RenderHistory{delivery_profile:None,project_revision:p.revision,decision_sha256:b.decision_sha256.clone(),variant_id:"main".into(),runtime:caps(),output:location().with_extension("mp4"),fully_decoded:true}).unwrap();
    b.check(&p).unwrap();
}
#[test] fn filter_is_literal_and_keeps_selection_when_visible() {
    let mut s=selected(pending());let v=s.snapshot().unwrap();let v=s.dispatch(&v.token,ReviewCommand::Filter("CANDIDATE proposed".into())).unwrap();
    assert_eq!(v.selected,Some(op()));assert_eq!(v.matched_count,1);
    let v=s.dispatch(&v.token,ReviewCommand::Filter(".*".into())).unwrap();assert_eq!(v.matched_count,0);assert!(v.selected.is_none());
}
#[test] fn clearing_filter_recovers_valid_selection() {
    let mut s=selected(pending());let v=s.snapshot().unwrap();let v=s.dispatch(&v.token,ReviewCommand::Filter("nothing-matches".into())).unwrap();
    let v=s.dispatch(&v.token,ReviewCommand::Filter(String::new())).unwrap();assert!(v.selected.is_some());
}
#[test] fn query_limits_and_control_characters_are_enforced() {
    let mut s=selected(pending());let v=s.snapshot().unwrap();
    for q in ["x".repeat(257),"bad\nquery".into(),"bad\u{202e}query".into()] {
        assert!(s.dispatch(&v.token,ReviewCommand::Filter(q)).is_err());
    }
}
#[test] fn reasons_escape_directional_format_controls_for_display_only() {
    let mut p=pending();p.operations[0].reason="first\u{202e}last".into();let row=detail(&p,&op()).unwrap().row;
    assert!(!row.reason.contains('\u{202e}'));assert!(row.reason.contains("\\u{202e}"));assert!(p.operations[0].reason.contains('\u{202e}'));
}
#[test] fn selection_requires_a_real_visible_identity() {
    let mut s=selected(pending());let v=s.snapshot().unwrap();
    assert!(s.dispatch(&v.token,ReviewCommand::Select(ReviewTarget::Operation("row-0".into()))).is_err());
}
#[test] fn inspect_and_back_have_keyboard_complete_state_transitions() {
    let mut s=selected(pending());let v=s.snapshot().unwrap();let v=s.dispatch(&v.token,ReviewCommand::Inspect).unwrap();assert_eq!(v.page,ReviewPage::Detail);assert!(v.detail.is_some());
    let v=s.dispatch(&v.token,ReviewCommand::Back).unwrap();assert_eq!(v.page,ReviewPage::List);
    let v=s.dispatch(&v.token,ReviewCommand::Back).unwrap();assert_eq!(v.page,ReviewPage::Closed);assert!(v.restore_host_focus);
}
#[test] fn close_rejects_all_later_actions_but_keeps_unsaved_project() {
    let mut s=selected(pending());let v=s.snapshot().unwrap();let v=s.dispatch(&v.token,ReviewCommand::Approve).unwrap();let bytes=s.project().to_json().unwrap();s.close();
    assert!(matches!(s.dispatch(&v.token,ReviewCommand::Next),Err(Error::ReviewClosed)));assert_eq!(s.project().to_json().unwrap(),bytes);
}
#[test] fn changing_selection_cancels_obsolete_preview_jobs() {
    let mut s=selected(pending());let v=s.snapshot().unwrap();let c=s.preview_cancellation(&v.token).unwrap();
    s.dispatch(&v.token,ReviewCommand::First).unwrap();assert!(c.is_cancelled());
}
#[test] fn changed_decision_cancels_inflight_preview() {
    let mut s=selected(pending());let v=s.snapshot().unwrap();let c=s.preview_cancellation(&v.token).unwrap();s.dispatch(&v.token,ReviewCommand::Approve).unwrap();assert!(c.is_cancelled());
}
#[test] fn close_and_drop_cancel_preview_children() {
    let mut s=selected(pending());let c=s.preview_cancellation(&s.snapshot().unwrap().token).unwrap();s.close();assert!(c.is_cancelled());
    let s=selected(pending());let c=s.preview_cancellation(&s.snapshot().unwrap().token).unwrap();drop(s);assert!(c.is_cancelled());
}
#[test] fn sessions_have_independent_cancellation() {
    let mut a=selected(pending());let b=selected(pending());let c=b.preview_cancellation(&b.snapshot().unwrap().token).unwrap();a.close();assert!(!c.is_cancelled());
}
#[test] fn page_limits_are_explicit() {
    assert!(ReviewSession::with_page_size(project(),0).is_err());assert!(ReviewSession::with_page_size(project(),101).is_err());
    let mut s=ReviewSession::with_page_size(pending(),1).unwrap();let v=s.snapshot().unwrap();assert_eq!(v.rows.len(),1);assert!(v.has_more);
    let v=s.dispatch(&v.token,ReviewCommand::Last).unwrap();assert_eq!(v.offset,1);assert!(!v.has_more);
}
#[test] fn navigation_stops_at_list_boundaries() {
    let mut s=ReviewSession::new(pending()).unwrap();let v=s.snapshot().unwrap();let first=v.selected.clone();let v=s.dispatch(&v.token,ReviewCommand::Previous).unwrap();assert_eq!(v.selected,first);
    let v=s.dispatch(&v.token,ReviewCommand::Last).unwrap();let last=v.selected.clone();let v=s.dispatch(&v.token,ReviewCommand::Next).unwrap();assert_eq!(v.selected,last);
}
#[test] fn clip_actions_do_not_invent_enable_or_approval_semantics() {
    let mut s=ReviewSession::new(project()).unwrap();let v=s.snapshot().unwrap();assert!(s.dispatch(&v.token,ReviewCommand::Approve).is_err());
    let v=s.dispatch(&v.token,ReviewCommand::SetLocked(true)).unwrap();assert!(matches!(s.dispatch(&v.token,ReviewCommand::ChangeRange(range("0","1"))),Err(Error::LockedEdit)));
}
#[test] fn mark_saved_only_clears_matching_dirty_state() {
    let mut s=selected(pending());let old=s.binding().unwrap();let v=s.snapshot().unwrap();s.dispatch(&v.token,ReviewCommand::Approve).unwrap();
    assert!(s.mark_saved(&old).is_err());let current=s.binding().unwrap();s.mark_saved(&current).unwrap();assert!(!s.snapshot().unwrap().dirty);
}
#[test] fn reload_requires_explicit_discard_of_unsaved_changes() {
    let p=pending();let mut s=selected(p.clone());let v=s.snapshot().unwrap();s.dispatch(&v.token,ReviewCommand::Approve).unwrap();assert!(s.reload(p.clone(),false).is_err());
    s.reload(p,true).unwrap();assert_eq!(s.project().operations[0].disposition,Disposition::NeedsReview);
}
#[test] fn reload_invalidates_old_tokens_and_previews() {
    let mut s=selected(pending());let v=s.snapshot().unwrap();let c=s.preview_cancellation(&v.token).unwrap();s.reload(pending(),false).unwrap();
    assert!(c.is_cancelled());assert!(matches!(s.dispatch(&v.token,ReviewCommand::Approve),Err(Error::StaleReview)));
}
#[test] fn review_rejects_another_project_on_reload() {
    let mut s=selected(pending());let mut p=pending();p.id="other-project".into();assert!(s.reload(p,true).is_err());
}
#[test] fn reviewed_overrides_survive_generator_recomputation() {
    let mut s=selected(pending());let v=s.snapshot().unwrap();s.dispatch(&v.token,ReviewCommand::Reject).unwrap();let mut p=s.project().clone();p.replace_generated("test-observer","2",vec![]).unwrap();
    assert_eq!(p.operations.len(),1);assert_eq!(p.operations[0].disposition,Disposition::Ignore);
}
#[test] fn full_removal_stays_reviewable_without_claiming_renderability() {
    let mut p=project();p.remove_range("source-1",TimeRange::new(r("0"),p.sources[0].duration).unwrap(),"all").unwrap();
    let v=ReviewSession::new(p).unwrap().snapshot().unwrap();assert!(!v.summary.decisions_renderable);assert!(v.summary.render_blocker.unwrap().contains("No retained"));
}
#[test] fn no_operations_is_a_valid_review() {
    let v=ReviewSession::new(project()).unwrap().snapshot().unwrap();assert_eq!(v.summary.operation_count,0);assert!(v.summary.decisions_renderable);
}

#[test] fn preview_default_is_a_bounded_hypothetical_pair() {
    let p=pending();let plan=describe(&p,&request(&p));let d=plan.description();assert_eq!(d.source_window,TimeRange::new(r("0"),p.sources[0].duration).unwrap());
    assert_eq!(d.proposed_timeline.as_ref().unwrap().duration,p.sources[0].duration.checked_sub(r("1/2")).unwrap());assert!(d.omitted_pending_ids.is_empty());
}
#[test] fn preview_does_not_approve_or_save_project() {
    let p=pending();let before=p.to_json().unwrap();let _=describe(&p,&request(&p));assert_eq!(p.to_json().unwrap(),before);assert!(matches!(p.timeline(),Err(Error::UnresolvedEdits)));
}
#[test] fn current_resolved_preview_omits_pending_selected_decision() {
    let p=pending();let mut req=request(&p);req.intent=PreviewIntent::CurrentResolved;let plan=describe(&p,&req);
    assert_eq!(plan.description().proposed_timeline.as_ref().unwrap().duration,p.sources[0].duration);assert_eq!(plan.description().omitted_pending_ids,vec!["candidate"]);
}
#[test] fn other_pending_decisions_are_disclosed_not_applied() {
    let mut p=pending();let mut second=p.operations[0].clone();second.id="second".into();second.range=range("3/2","7/4");p.add_operation(second).unwrap();
    let plan=describe(&p,&request(&p));assert_eq!(plan.description().omitted_pending_ids,vec!["second"]);assert_eq!(plan.description().proposed_timeline.as_ref().unwrap().duration,p.sources[0].duration.checked_sub(r("1/2")).unwrap());
}
#[test] fn preview_handles_completely_removed_window_without_fake_media() {
    let mut p=pending();p.operations[0].range=TimeRange::new(r("0"),p.sources[0].duration).unwrap();let plan=describe(&p,&request(&p));assert!(plan.description().proposed_timeline.is_none());
    let current=p.sources[0].media.as_media_info();assert!(plan.render_plan(PreviewSide::Proposed,&current,&caps()).unwrap().is_none());
}
#[test] fn locked_ignored_proposal_is_not_silently_reenabled_for_preview() {
    let mut p=pending();p.review_operation("candidate",Disposition::Ignore,false).unwrap();p.set_operation_locked("candidate",true).unwrap();assert!(matches!(PreviewPlan::build(&p,&request(&p)),Err(Error::LockedEdit)));
}
#[test] fn stale_request_cannot_render_after_an_edit() {
    let mut p=pending();let req=request(&p);p.resolve_operation("candidate",Disposition::Ignore).unwrap();assert!(matches!(PreviewPlan::build(&p,&req),Err(Error::StaleReview)));
}
#[test] fn preview_rejects_unknown_target_and_relative_paths() {
    let p=pending();let mut req=request(&p);req.target=ReviewTarget::Operation("absent".into());assert!(PreviewPlan::build(&p,&req).is_err());
    let mut req=request(&p);req.scratch_directory=PathBuf::from("relative");assert!(PreviewPlan::build(&p,&req).is_err());
}
#[test] fn preview_rejects_parent_traversal_and_wrong_project_extension() {
    let p=pending();let mut req=request(&p);req.scratch_directory=std::env::temp_dir().join("a/../b");assert!(PreviewPlan::build(&p,&req).is_err());
    let mut req=request(&p);req.project_file=location().with_extension("mp4");assert!(PreviewPlan::build(&p,&req).is_err());
}
#[test] fn proxy_dimensions_and_file_limits_are_bounded() {
    let mut o=PreviewOptions::default();o.max_width=1281;assert!(o.validate().is_err());o=PreviewOptions::default();o.max_height=1;assert!(o.validate().is_err());
    o=PreviewOptions::default();o.max_bytes=MAX_PROXY_BYTES+1;assert!(o.validate().is_err());o.max_bytes=1023;assert!(o.validate().is_err());
}
#[test] fn proxy_time_limits_reject_negative_and_excessive_windows() {
    let mut o=PreviewOptions::default();o.max_window=r("31");assert!(o.validate().is_err());o.max_window=r("0");assert!(o.validate().is_err());
    o=PreviewOptions::default();o.context=r("-1");assert!(o.validate().is_err());
}
#[test] fn whole_window_does_not_silently_crop_long_edits() {
    let p=pending();let mut req=request(&p);req.options.max_window=r("1");req.options.context=r("1/2");assert!(PreviewPlan::build(&p,&req).is_err());
    req.focus=PreviewFocus::StartBoundary;let plan=describe(&p,&req);assert_eq!(plan.description().source_window.duration().unwrap(),r("1"));
}
#[test] fn boundary_and_position_focus_stay_inside_source() {
    let p=pending();for focus in [PreviewFocus::StartBoundary,PreviewFocus::EndBoundary,PreviewFocus::At(r("0")),PreviewFocus::At(p.sources[0].duration)] {
        let mut req=request(&p);req.focus=focus;req.options.max_window=r("1");req.options.context=r("0");let plan=describe(&p,&req);let w=plan.description().source_window;
        assert!(w.start>=r("0")&&w.end<=p.sources[0].duration);assert_eq!(w.duration().unwrap(),r("1"));
    }
}
#[test] fn out_of_source_focus_is_rejected() {
    let p=pending();let mut req=request(&p);req.focus=PreviewFocus::At(r("-1"));assert!(PreviewPlan::build(&p,&req).is_err());req.focus=PreviewFocus::At(r("100"));assert!(PreviewPlan::build(&p,&req).is_err());
}
#[test] fn preview_geometry_does_not_upscale_small_sources() {
    let p=pending();let plan=describe(&p,&request(&p));let media=p.sources[0].media.as_media_info();let render=plan.render_plan(PreviewSide::Before,&media,&caps()).unwrap().unwrap();
    assert_eq!(render.dimensions(),(160,96));assert_eq!(render.output_byte_limit(),Some(32*1024*1024));
}
#[test] fn low_resolution_graph_uses_fixed_validated_filters() {
    let p=pending();let mut req=request(&p);req.options.max_width=80;req.options.max_height=48;let plan=describe(&p,&req);let render=plan.render_plan(PreviewSide::Before,&p.sources[0].media.as_media_info(),&caps()).unwrap().unwrap();
    assert_eq!(render.dimensions(),(80,48));let args=render.arguments(&location().with_extension("mp4"),&location().with_file_name("staged.mp4")).unwrap();
    let graph=args.windows(2).find(|w|w[0]=="-filter_complex").unwrap()[1].to_str().unwrap();assert!(graph.contains("scale=w=80:h=48"));assert!(graph.contains("setsar=sar=1/1"));
}
#[test] fn missing_scale_or_setsar_rejected_before_staging() {
    let p=pending();let plan=describe(&p,&request(&p));let mut c=caps();c.filters.remove("setsar");
    assert!(matches!(plan.render_plan(PreviewSide::Before,&p.sources[0].media.as_media_info(),&c),Err(Error::MissingCapability(_))));
}
#[test] fn final_render_plan_is_not_accidentally_downscaled() {
    let mut p=pending();p.review_operation("candidate",Disposition::AutoApply,true).unwrap();let plan=build_edited_plan(&p,"main",&p.sources[0].media.as_media_info(),&caps()).unwrap();
    assert_eq!(plan.output_byte_limit(),None);assert_eq!(plan.dimensions(),(160,96));
}
#[test] fn proxy_settings_do_not_change_saved_preset_or_variants() {
    let p=pending();let original=p.to_json().unwrap();let plan=describe(&p,&request(&p));plan.render_plan(PreviewSide::Before,&p.sources[0].media.as_media_info(),&caps()).unwrap();assert_eq!(p.to_json().unwrap(),original);
}
#[test] fn preview_identity_changes_with_settings_target_and_project() {
    let p=pending();let req=request(&p);let a=describe(&p,&req).description().request_key.clone();let mut req2=req.clone();req2.options.max_width=320;
    assert_ne!(a,describe(&p,&req2).description().request_key);req2=req.clone();req2.intent=PreviewIntent::CurrentResolved;assert_ne!(a,describe(&p,&req2).description().request_key);
}
#[test] fn proxy_reuses_sample_accurate_audio_assembly() {
    let p=pending();let plan=describe(&p,&request(&p));let render=plan.render_plan(PreviewSide::Proposed,&p.sources[0].media.as_media_info(),&caps()).unwrap().unwrap();
    let edit=render.edited_timeline().unwrap();assert_eq!(edit.sample_rate,Some(48000));assert_eq!(edit.segments.len(),2);
}

#[test] fn rust_arguments_match_independently_exercised_proxy_recipe() {
    let p=pending();let mut req=request(&p);req.options.max_width=80;req.options.max_height=48;
    let prepared=PreviewPlan::build(&p,&req).unwrap();
    let plan=prepared.render_plan(PreviewSide::Proposed,&p.sources[0].media.as_media_info(),&caps()).unwrap().unwrap();
    let args:Vec<String>=plan.arguments(std::path::Path::new("/selected/input.mp4"),std::path::Path::new("/private/review.mp4"))
        .unwrap().into_iter().map(|s|s.into_string().unwrap()).collect();
    let expected:Vec<String>=serde_json::from_str(include_str!("review_fixtures/proxy-argv.json")).unwrap();
    assert_eq!(args,expected);
}

#[test] fn selected_pending_proposal_is_not_reported_as_omitted_in_detail() {
    let p=pending();let d=detail(&p,&op()).unwrap();assert!(d.omitted_pending_ids.is_empty());
}
#[test] fn new_preview_request_cancels_old_focus_without_changing_decisions() {
    let mut s=selected(pending());let v=s.snapshot().unwrap();let req=request(s.project());
    let original=s.project().to_json().unwrap();let first=s.begin_preview(&v.token,&req).unwrap();
    let mut other=req.clone();other.focus=PreviewFocus::StartBoundary;
    let second=s.begin_preview(&v.token,&other).unwrap();
    assert!(first.cancellation().is_cancelled());assert!(!second.cancellation().is_cancelled());
    assert_ne!(first.request_key(),second.request_key());assert_eq!(original,s.project().to_json().unwrap());
}
#[test] fn invalid_preview_request_does_not_cancel_a_valid_one() {
    let mut s=selected(pending());let v=s.snapshot().unwrap();let req=request(s.project());let first=s.begin_preview(&v.token,&req).unwrap();
    let mut invalid=req.clone();invalid.options.max_bytes=0;assert!(s.begin_preview(&v.token,&invalid).is_err());
    assert!(!first.cancellation().is_cancelled());
}
#[test] fn preview_request_for_nonselected_row_is_rejected() {
    let mut s=selected(pending());let v=s.snapshot().unwrap();let mut req=request(s.project());req.target=ReviewTarget::Clip("clip-1".into());
    assert!(matches!(s.begin_preview(&v.token,&req),Err(Error::StaleReview)));
}
#[test] fn closing_review_cancels_current_preview_ticket() {
    let mut s=selected(pending());let v=s.snapshot().unwrap();let req=request(s.project());let t=s.begin_preview(&v.token,&req).unwrap();
    s.close();assert!(t.cancellation().is_cancelled());
}
#[test] fn disabled_generated_cut_locked_in_place_keeps_review_readable() {
    let mut p=pending();p.set_operation_enabled("candidate",false).unwrap();p.set_operation_locked("candidate",true).unwrap();
    let d=detail(&p,&op()).unwrap();assert!(!d.can_approve);assert!(!d.can_reject);assert!(d.can_unlock);
    assert!(matches!(PreviewPlan::build(&p,&request(&p)),Err(Error::LockedEdit)));
}
#[test] fn preview_uses_requested_saved_variant_not_first_variant() {
    let mut p=pending();let mut output=p.variants[0].clone();output.id="cfr-review".into();output.render.frame_rate=automexia_video::FrameRateMode::Constant(r("24"));
    p.variants.push(output);let mut req=request(&p);req.variant_id="cfr-review".into();
    let plan=describe(&p,&req).render_plan(PreviewSide::Before,&p.sources[0].media.as_media_info(),&caps()).unwrap().unwrap();
    let args=plan.arguments(std::path::Path::new("/input.mp4"),std::path::Path::new("/review.mp4")).unwrap();
    assert!(args.windows(2).any(|w|w[0]=="-r:v"&&w[1]=="24/1"));
}
#[test] fn unknown_saved_preview_variant_is_not_guessed() {
    let p=pending();let mut req=request(&p);req.variant_id="missing".into();assert!(PreviewPlan::build(&p,&req).is_err());
}
#[test] fn output_variant_changes_preview_request_identity() {
    let mut p=pending();let mut other=p.variants[0].clone();other.id="other".into();p.variants.push(other);
    let req=request(&p);let a=describe(&p,&req).description().request_key.clone();let mut b=req;b.variant_id="other".into();
    assert_ne!(a,describe(&p,&b).description().request_key);
}
#[test] fn review_decisions_survive_real_project_json_round_trip() {
    let mut s=selected(pending());let v=s.snapshot().unwrap();let v=s.dispatch(&v.token,ReviewCommand::Reject).unwrap();s.dispatch(&v.token,ReviewCommand::SetLocked(true)).unwrap();
    let p=Project::from_json(&s.project().to_json().unwrap()).unwrap();
    assert_eq!(p.operations[0].disposition,Disposition::Ignore);assert!(!p.operations[0].enabled);assert!(p.operations[0].locked);
}

#[test]
fn timing_preview_snaps_double_speed_excerpt_to_complete_output_frames(){
    let mut p=project();p.set_timing("main",Some(automexia_video::timing::TimingSettings{speed:automexia_video::timing::PlaybackSpeed::Double,disposition:Disposition::AutoApply,..Default::default()})).unwrap();p.review_timing("main",Disposition::AutoApply,true).unwrap();
    let mut req=PreviewRequest::new(&p,location(),location().parent().unwrap(),ReviewTarget::TimingVariant("main".into())).unwrap();
    req.intent=PreviewIntent::CurrentResolved;req.focus=PreviewFocus::At(r("1001/1000"));req.options.context=r("0");req.options.max_window=r("1");
    let before=p.to_json().unwrap();let prepared=PreviewPlan::build(&p,&req).unwrap();
    let mut runtime=caps();runtime.filters.extend(["trim","fps","split","tpad","null","atempo"].map(str::to_owned));
    let rendered=prepared.render_plan(PreviewSide::Proposed,&p.sources[0].media.as_media_info(),&runtime).unwrap().unwrap();
    let edit=rendered.edited_timeline().unwrap();
    assert_eq!(edit.duration.checked_mul(edit.nominal_frame_rate).unwrap().denominator(),1);
    assert!(prepared.description().source_window.duration().unwrap()<=req.options.max_window);
    assert_eq!(before,p.to_json().unwrap());
}
#[test]
fn timing_preview_retains_dissolve_handles_when_window_budget_allows(){
    let mut p=project();p.remove_range("source-1",range("1001/1250","3003/2500"),"join").unwrap();p.set_timing("main",Some(automexia_video::timing::TimingSettings{dissolve:r("1001/5000"),disposition:Disposition::AutoApply,..Default::default()})).unwrap();p.review_timing("main",Disposition::AutoApply,true).unwrap();
    let mut req=PreviewRequest::new(&p,location(),location().parent().unwrap(),ReviewTarget::TimingVariant("main".into())).unwrap();req.intent=PreviewIntent::CurrentResolved;req.focus=PreviewFocus::At(r("1"));req.options.context=r("0");req.options.max_window=r("3");
    let prepared=PreviewPlan::build(&p,&req).unwrap();let duration=prepared.description().proposed_timeline.as_ref().unwrap().duration;assert_eq!(duration,r("7007/5000"));
    req.options.max_window=r("1/2");assert!(matches!(PreviewPlan::build(&p,&req),Err(Error::Unsupported(_))));
}
#[test]
fn old_schema_rejects_even_null_new_timing_and_transcript_fields(){
    for field in ["transcript","timing"] {let mut value=serde_json::to_value(project()).unwrap();value["schema_version"]=8.into();if field=="transcript"{value[field]=serde_json::Value::Null;}else{value["variants"][0][field]=serde_json::Value::Null;}assert!(Project::from_json(&serde_json::to_vec(&value).unwrap()).is_err());}
    let mut value=serde_json::to_value(project()).unwrap();value["schema_version"]=8.into();assert_eq!(Project::from_json(&serde_json::to_vec(&value).unwrap()).unwrap().schema_version,PROJECT_VERSION);
}

#[test]
fn changing_timing_settings_clears_prior_approval(){
    let mut p=project();p.set_timing("main",Some(automexia_video::timing::TimingSettings{speed:automexia_video::timing::PlaybackSpeed::Double,disposition:Disposition::AutoApply,..Default::default()})).unwrap();
    assert_eq!(p.variant("main").unwrap().timing.as_ref().unwrap().disposition,Disposition::NeedsReview);
    p.review_timing("main",Disposition::AutoApply,true).unwrap();
    let mut settings=p.variant("main").unwrap().timing.clone().unwrap();settings.speed=automexia_video::timing::PlaybackSpeed::Half;
    p.set_timing("main",Some(settings)).unwrap();assert_eq!(p.variant("main").unwrap().timing.as_ref().unwrap().disposition,Disposition::NeedsReview);
    assert!(matches!(p.timeline_for_variant("main"),Err(Error::UnresolvedEdits)));
}
