//! Actual optional Rust rasterizer tests, not Python substitutes.
//! Text tests require VIDEO_TEST_FONT to name an explicit single-face TTF/OTF.
use automexia_video::{Cancellation,Error};
use automexia_video::graphics::{rasterize,validate_svg,AssetBytes,resize_rgba,srgb_to_bt709};
use automexia_video::presentation::*;
use image::{RgbaImage,Rgba as Pixel,DynamicImage,ImageFormat};
use sha2::{Digest,Sha256};
use std::{io::Cursor,path::PathBuf};
fn asset(bytes:Vec<u8>,name:&str)->(AssetRef,AssetBytes){let hash=format!("{:x}",Sha256::digest(&bytes));let a=AssetRef{path:PathBuf::from(name),size:bytes.len() as u64,sha256:hash.clone()};let mut map=AssetBytes::new();map.insert(hash,bytes);(a,map)}
fn png(im:RgbaImage)->Vec<u8>{let mut b=Vec::new();DynamicImage::ImageRgba8(im).write_to(&mut Cursor::new(&mut b),ImageFormat::Png).unwrap();b}
fn svg(body:&str)->Vec<u8>{format!("<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"40\" height=\"20\">{body}</svg>").into_bytes()}
fn draw(bytes:Vec<u8>,kind:bool)->automexia_video::Result<RgbaImage>{let(a,m)=asset(bytes,if kind{"logo.svg"}else{"logo.png"});rasterize(&if kind{GraphicContent::Svg{asset:a}}else{GraphicContent::Image{asset:a}},40,20,&m,&Cancellation::new())}
fn font()->(FontRef,AssetBytes){let path=std::env::var_os("VIDEO_TEST_FONT").map(PathBuf::from).expect("Set VIDEO_TEST_FONT to an explicit TTF/OTF; no fonts are bundled");let bytes=std::fs::read(&path).unwrap();let mut db=resvg::usvg::fontdb::Database::new();db.load_font_data(bytes.clone());let family=db.faces().next().expect("single-face font").families[0].0.clone();let(mut a,m)=asset(bytes,"selected.ttf");a.path=path;(FontRef{asset:a,family},m)}
#[test]fn static_svg_is_really_rasterized(){let im=draw(svg("<rect width=\"40\" height=\"20\" fill=\"red\"/>"),true).unwrap();assert!(im.get_pixel(20,10)[0]>250);assert_eq!(im.get_pixel(20,10)[3],255);}
#[test]fn local_gradient_is_supported(){let b=svg("<defs><linearGradient id=\"g\"><stop offset=\"0\" stop-color=\"red\"/><stop offset=\"1\" stop-color=\"blue\"/></linearGradient></defs><rect width=\"40\" height=\"20\" fill=\"url(#g)\"/>");let im=draw(b,true).unwrap();assert!(im.get_pixel(2,10)[0]>im.get_pixel(37,10)[0]);}
#[test]fn svg_script_is_rejected(){assert!(validate_svg(&svg("<script>alert(1)</script>")).is_err());}
#[test]fn svg_external_image_is_rejected(){assert!(validate_svg(&svg("<image href=\"https://example.invalid/x\"/>" )).is_err());}
#[test]fn svg_local_file_image_is_rejected(){assert!(validate_svg(&svg("<image href=\"file:///etc/passwd\"/>" )).is_err());}
#[test]fn svg_css_is_rejected(){assert!(validate_svg(&svg("<style>@import url(x)</style>" )).is_err());}
#[test]fn svg_dtd_is_rejected(){assert!(validate_svg(b"<!DOCTYPE svg [<!ENTITY x SYSTEM 'file:///etc/passwd'>]><svg xmlns='http://www.w3.org/2000/svg'/>").is_err());}
#[test]fn svg_wrong_namespace_is_rejected(){assert!(validate_svg(b"<svg><rect/></svg>").is_err());}
#[test]fn svg_missing_gradient_is_rejected(){assert!(validate_svg(&svg("<rect fill=\"url(#missing)\"/>" )).is_err());}
#[test]fn svg_external_gradient_is_rejected(){assert!(validate_svg(&svg("<rect fill=\"url(https://example.invalid/g)\"/>" )).is_err());}
#[test]fn svg_text_without_explicit_font_contract_is_rejected(){assert!(validate_svg(&svg("<text>Do not use ambient fonts</text>" )).is_err());}
#[test]fn png_respects_alpha(){let im=draw(png(RgbaImage::from_pixel(40,20,Pixel([200,50,0,128]))),false).unwrap();assert_eq!(im.get_pixel(20,10)[3],128);assert!(im.get_pixel(20,10)[0]>=198);}
#[test]fn image_preserves_aspect_inside_box(){let im=draw(png(RgbaImage::from_pixel(20,20,Pixel([255,0,0,255]))),false).unwrap();assert_eq!(im.get_pixel(0,10)[3],0);assert_eq!(im.get_pixel(20,10)[3],255);}
#[test]fn truncated_image_is_rejected(){let mut b=png(RgbaImage::new(40,20));b.truncate(30);assert!(draw(b,false).is_err());}
#[test]fn trailing_png_payload_is_rejected(){let mut b=png(RgbaImage::new(40,20));b.extend(b"trailing");assert!(draw(b,false).is_err());}
#[test]fn asset_digest_mismatch_is_rejected(){let(a,mut m)=asset(svg("<rect/>"),"x.svg");m.get_mut(&a.sha256).unwrap().push(b' ');assert!(matches!(rasterize(&GraphicContent::Svg{asset:a},40,20,&m,&Cancellation::new()),Err(Error::InputChanged)));}
#[test]fn missing_asset_is_rejected(){let(a,_)=asset(svg("<rect/>"),"x.svg");assert!(rasterize(&GraphicContent::Svg{asset:a},40,20,&AssetBytes::new(),&Cancellation::new()).is_err());}
#[test]fn raster_dimensions_are_bounded(){let(a,m)=asset(svg("<rect/>"),"x.svg");assert!(rasterize(&GraphicContent::Svg{asset:a},u32::MAX,20,&m,&Cancellation::new()).is_err());}
#[test]fn cancelled_raster_does_no_work(){let(a,m)=asset(svg("<rect/>"),"x.svg");let c=Cancellation::new();c.cancel();assert!(matches!(rasterize(&GraphicContent::Svg{asset:a},40,20,&m,&c),Err(Error::Cancelled)));}
#[test]fn transparent_hidden_color_cannot_bleed_during_resize(){let mut im=RgbaImage::from_pixel(2,1,Pixel([255,0,0,0]));im.put_pixel(1,0,Pixel([0,0,255,255]));let out=resize_rgba(&im,40,20);for p in out.pixels(){if p[3]>10{assert!(p[0]<3);}}}
#[test]fn rgb_transfer_keeps_alpha_and_primary_endpoints(){let mut im=RgbaImage::from_pixel(1,1,Pixel([255,0,255,83]));srgb_to_bt709(&mut im);assert_eq!(im.get_pixel(0,0).0,[255,0,255,83]);}
#[test]fn text_is_rendered_from_supplied_font_only(){let(f,m)=font();let mut style=TextStyle::light(f,18);style.padding=4;let im=rasterize(&GraphicContent::Text{text:"Hello & < >\nsecond line".into(),style},320,80,&m,&Cancellation::new()).unwrap();assert!(im.pixels().any(|p|p[0]>180&&p[1]>180&&p[2]>180));}
#[test]fn incorrect_font_family_is_an_error(){let(mut f,m)=font();f.family="Wrong Family Identity".into();assert!(rasterize(&GraphicContent::Text{text:"Hello".into(),style:TextStyle::light(f,18)},320,80,&m,&Cancellation::new()).is_err());}
#[test]fn text_overflow_requires_explicit_layout_change(){let(f,m)=font();assert!(rasterize(&GraphicContent::Text{text:"This text cannot fit this very small box".into(),style:TextStyle::light(f,30)},20,20,&m,&Cancellation::new()).is_err());}

#[test]fn sixteen_bit_graphics_are_not_silently_truncated(){let im=image::ImageBuffer::<image::Rgba<u16>,Vec<u16>>::from_pixel(40,20,image::Rgba([65535,0,0,65535]));let mut b=Vec::new();DynamicImage::ImageRgba16(im).write_to(&mut Cursor::new(&mut b),ImageFormat::Png).unwrap();assert!(draw(b,false).is_err());}
#[test]fn hdr_png_metadata_is_not_ignored(){let mut b=png(RgbaImage::new(40,20));let pos=b.len()-12;let mut chunk=Vec::from(4u32.to_be_bytes());chunk.extend(b"cICP");chunk.extend([9,16,9,0]);chunk.extend([0;4]);b.splice(pos..pos,chunk);assert!(draw(b,false).is_err());}
#[test]fn malformed_jpeg_is_rejected(){assert!(draw(vec![0xff,0xd8,0xff,0xe1,0,2,0xff,0xda],false).is_err());}
#[test]fn zero_alpha_svg_leaves_no_visible_pixels(){let im=draw(svg("<rect width=\"40\" height=\"20\" fill=\"red\" fill-opacity=\"0\"/>"),true).unwrap();assert!(im.pixels().all(|p|p[3]==0));}
