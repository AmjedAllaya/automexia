use automexia_video::*;
use automexia_video::{host::{FileStamp,MediaTask,ToolOutput},media::{parse_probe,SelectedStreams},plan::{build_plan,validate_output},progress::{ProgressParser,Stage}};
use std::{path::{Path,PathBuf},sync::{Arc,atomic::{AtomicBool,AtomicUsize,Ordering}}};
use serde_json::{json,Value};

fn base()->MediaInfo{parse_probe(include_bytes!("fixtures/probe-base.json")).unwrap()}
fn output()->MediaInfo{parse_probe(include_bytes!("fixtures/output-ordinary.json")).unwrap()}
fn capabilities()->RuntimeCapabilities{RuntimeCapabilities{ffmpeg_version:"test ffmpeg".into(),ffprobe_version:"test ffprobe".into(),encoders:["libx264".into(),"aac".into()].into_iter().collect(),muxers:["mp4".into()].into_iter().collect(),supports_demux_time_base:true,..Default::default()}}
fn altered(f:impl FnOnce(&mut Value))->MediaInfo{let mut v=base().raw;f(&mut v);parse_probe(&serde_json::to_vec(&v).unwrap()).unwrap()}
fn stamp()->FileStamp{FileStamp{size:100,modified_ns:Some(1),sha256:"unit-fixture-only".into(),file_id:Some("fixture:1".into())}}

#[test]fn exact_fractional_frame_rate(){let r:Rational="30000/1001".parse().unwrap();assert_eq!(r.numerator(),30000);assert_eq!(r.denominator(),1001);assert_eq!(r.inverse().unwrap().to_string(),"1001/30000");}
#[test]fn decimal_timestamp_is_exact(){assert_eq!("-0.021333".parse::<Rational>().unwrap().to_string(),"-21333/1000000");}
#[test]fn rational_reduces(){assert_eq!(Rational::new(60,2).unwrap(),Rational::new(30,1).unwrap());}
#[test]fn tick_mapping_is_exact(){assert_eq!(Rational::new(1,30000).unwrap().ticks(60060).unwrap(),Rational::new(1001,500).unwrap());}
#[test]fn checked_origin_subtraction(){assert_eq!("5.35".parse::<Rational>().unwrap().checked_sub("5".parse().unwrap()).unwrap().to_string(),"7/20");}
#[test]fn invalid_rationals_rejected(){for s in ["0/0","1/-1","NaN","inf","1e99"," 1","--1","1/2/3","99999999999999999999999"]{assert!(s.parse::<Rational>().is_err(),"{s}");}}
#[test]fn rational_tick_overflow_is_error(){assert!(Rational::new(i64::MAX,1).unwrap().ticks(i64::MAX).is_err());}
#[test]fn rational_deserialization_validates(){assert!(serde_json::from_str::<Rational>("\"0/0\"").is_err());}
#[test]fn probe_keeps_raw_metadata(){let p=base();assert!(p.raw.get("format").is_some());assert!(!p.head_packets.is_empty());}
#[test]fn probe_keeps_b_frame_dts(){assert!(base().head_packets.iter().any(|p|p.dts.is_some_and(|d|d<0)));}
#[test]fn rate_metadata_not_declared_definitive(){assert_eq!(base().streams[0].frame_rate_evidence(),"metadata_only_not_proven_constant");}
#[test]fn ordinary_stream_selection(){assert_eq!(base().select(StreamSelection::default()).unwrap(),SelectedStreams{video:0,audio:Some(1)});}
#[test]fn no_audio_is_explicit(){let p=altered(|v|{v["streams"].as_array_mut().unwrap().retain(|s|s["codec_type"]=="video");v["packets"].as_array_mut().unwrap().retain(|p|p["stream_index"]==0);});assert_eq!(p.select(StreamSelection::default()).unwrap().audio,None);}
#[test]fn audio_can_be_omitted(){let s=StreamSelection{audio:AudioSelection::None,..Default::default()};assert_eq!(base().select(s).unwrap().audio,None);}
#[test]fn wrong_type_explicit_index_rejected(){assert!(base().select(StreamSelection{audio:AudioSelection::Index(0),..Default::default()}).is_err());}
#[test]fn ambiguous_audio_requires_choice(){let mut p=parse_probe(include_bytes!("fixtures/probe-multi.json")).unwrap();for s in &mut p.streams{if s.kind=="audio"{s.disposition.insert("default".into(),false);}}assert!(matches!(p.select(StreamSelection::default()),Err(Error::AmbiguousStream("audio"))));}
#[test]fn explicit_second_audio(){let p=parse_probe(include_bytes!("fixtures/probe-multi.json")).unwrap();assert_eq!(p.select(StreamSelection{audio:AudioSelection::Index(2),..Default::default()}).unwrap().audio,Some(2));}
#[test]fn attached_picture_is_not_main_video(){let p=altered(|v|v["streams"][0]["disposition"]["attached_pic"]=json!(1));assert!(p.select(StreamSelection::default()).is_err());}
#[test]fn duplicate_stream_indices_rejected(){let mut p=base().raw;p["streams"][1]["index"]=json!(0);assert!(parse_probe(&serde_json::to_vec(&p).unwrap()).is_err());}
#[test]fn oversized_probe_rejected(){assert!(matches!(parse_probe(&vec![b' ';automexia_video::media::MAX_PROBE_BYTES+1]),Err(Error::LimitExceeded(_))));}
#[test]fn malformed_probe_rejected(){for input in [b"{}".as_slice(),b"[]",b"not JSON"]{assert!(parse_probe(input).is_err());}}
#[test]fn oversized_metadata_string_rejected(){let mut p=base().raw;p["format"]["tags"]["comment"]=json!("x".repeat(16385));assert!(parse_probe(&serde_json::to_vec(&p).unwrap()).is_err());}
#[test]fn rotation_is_read_from_real_fixture(){let p=parse_probe(include_bytes!("fixtures/probe-rotated.json")).unwrap();assert_eq!(p.streams[0].rotation_degrees().unwrap(),90);let plan=build_plan(&p,&RenderOptions::default(),&capabilities()).unwrap();assert_eq!(plan.dimensions(),(96,160));}
#[test]fn mirrored_matrix_is_rejected(){let p=altered(|v|v["streams"][0]["side_data_list"]=json!([{"side_data_type":"Display Matrix","rotation":0,"displaymatrix":"00000000: -65536 0 0\n00000001: 0 65536 0\n00000002: 0 0 1073741824"}]));assert!(p.streams[0].rotation_degrees().is_err());}
#[test]fn missing_encoder_rejected(){let mut c=capabilities();c.encoders.remove("libx264");assert!(matches!(build_plan(&base(),&RenderOptions::default(),&c),Err(Error::MissingCapability("libx264"))));}
#[test]fn video_only_does_not_require_aac(){let mut c=capabilities();c.encoders.remove("aac");let mut o=RenderOptions::default();o.streams.audio=AudioSelection::None;assert!(build_plan(&base(),&o,&c).is_ok());}
#[test]fn hdr_not_silently_converted(){let p=altered(|v|v["streams"][0]["color_transfer"]=json!("smpte2084"));assert!(matches!(build_plan(&p,&RenderOptions::default(),&capabilities()),Err(Error::Unsupported(_))));}
#[test]fn ten_bit_not_silently_truncated(){let p=altered(|v|v["streams"][0]["pix_fmt"]=json!("yuv420p10le"));assert!(build_plan(&p,&RenderOptions::default(),&capabilities()).is_err());}
#[test]fn odd_dimensions_not_silently_cropped(){let p=altered(|v|v["streams"][0]["width"]=json!(161));assert!(build_plan(&p,&RenderOptions::default(),&capabilities()).is_err());}
#[test]fn interlace_requires_explicit_policy(){let p=altered(|v|v["streams"][0]["field_order"]=json!("tt"));assert!(build_plan(&p,&RenderOptions::default(),&capabilities()).is_err());}
#[test]fn unsupported_audio_rate_rejected(){let p=altered(|v|v["streams"][1]["sample_rate"]=json!("12345"));assert!(build_plan(&p,&RenderOptions::default(),&capabilities()).is_err());}
#[test]fn too_many_channels_rejected(){let p=altered(|v|v["streams"][1]["channels"]=json!(16));assert!(build_plan(&p,&RenderOptions::default(),&capabilities()).is_err());}
#[test]fn invalid_settings_rejected(){assert!(VideoSettings{max_concurrent_jobs:0}.validate().is_err());assert!(VideoSettings{max_concurrent_jobs:5}.validate().is_err());}
#[test]fn invalid_render_options_rejected(){let mut o=RenderOptions::default();o.threads=0;assert!(o.validate().is_err());o.threads=2;o.crf=51;assert!(o.validate().is_err());}
#[test]fn invalid_cfr_rejected(){let mut o=RenderOptions::default();o.frame_rate=FrameRateMode::Constant(Rational::new(0,1).unwrap());assert!(o.validate().is_err());}
#[test]fn unknown_settings_not_silently_accepted(){assert!(serde_json::from_str::<VideoSettings>(r#"{"max_concurrent_jobs":1,"network":true}"#).is_err());}
#[test]fn golden_commands_match_real_media_recipe(){let plan=build_plan(&base(),&RenderOptions::default(),&capabilities()).unwrap();let actual:Vec<_>=plan.arguments(Path::new("/selected/input.mp4"),Path::new("/private/staged.mp4")).unwrap().into_iter().map(|s|s.into_string().unwrap()).collect();let expected:Vec<String>=serde_json::from_str(include_str!("fixtures/render-default-argv.json")).unwrap();assert_eq!(actual,expected);}
#[test]fn paths_are_independent_arguments(){let plan=build_plan(&base(),&RenderOptions::default(),&capabilities()).unwrap();let input=Path::new("/video ;$(touch bad).mp4");let args=plan.arguments(input,Path::new("/tmp/out.mp4")).unwrap();assert!(args.iter().any(|s|s==input.as_os_str()));assert!(!args.iter().any(|s|s=="sh"||s=="cmd.exe"));}
#[test]fn cfr_uses_exact_inverse_time_base(){let mut o=RenderOptions::default();o.frame_rate=FrameRateMode::Constant("24000/1001".parse().unwrap());let p=build_plan(&base(),&o,&capabilities()).unwrap();let args=p.arguments(Path::new("/in.mp4"),Path::new("/out.mp4")).unwrap();assert!(args.iter().any(|s|s=="1001/24000"));}
#[test]fn unknown_input_format_rejected(){let mut p=base();p.format_names=vec!["hls".into()];assert!(build_plan(&p,&RenderOptions::default(),&capabilities()).is_err());}
#[test]fn output_properties_validate(){let p=build_plan(&base(),&RenderOptions::default(),&capabilities()).unwrap();assert!(validate_output(&base(),&output(),&p).is_ok());}
#[test]fn wrong_output_dimensions_rejected(){let p=build_plan(&base(),&RenderOptions::default(),&capabilities()).unwrap();let mut o=output();o.streams[0].width=Some(128);assert!(validate_output(&base(),&o,&p).is_err());}
#[test]fn lost_audio_rejected(){let p=build_plan(&base(),&RenderOptions::default(),&capabilities()).unwrap();let mut o=output();o.streams.retain(|s|s.kind!="audio");assert!(validate_output(&base(),&o,&p).is_err());}
#[test]fn duration_change_rejected(){let p=build_plan(&base(),&RenderOptions::default(),&capabilities()).unwrap();let mut o=output();o.streams[0].duration_ts=Some(30000);assert!(validate_output(&base(),&o,&p).is_err());}
#[test]fn parent_cancellation_propagates(){let c=Cancellation::new();let clone=c.clone();c.cancel();assert!(clone.is_cancelled());}
#[test]fn progress_handles_fragmented_input(){let mut p=ProgressParser::default();assert!(p.feed(b"out_ti").unwrap().is_empty());let e=p.feed(b"me_us=123\nframe=4\nprogress=continue\n").unwrap();assert_eq!(e[0].out_time_us,Some(123));assert_eq!(e[0].frame,Some(4));assert!(!e[0].encoding_finished);}
#[test]fn progress_end_is_only_encoding_end(){let e=ProgressParser::default().feed(b"progress=end\n").unwrap();assert!(e[0].encoding_finished);assert_eq!(e[0].stage,Stage::Rendering);}
#[test]fn progress_time_never_moves_back(){let mut p=ProgressParser::default();p.feed(b"out_time_us=200\nprogress=continue\n").unwrap();assert_eq!(p.feed(b"out_time_us=100\nprogress=continue\n").unwrap()[0].out_time_us,Some(200));}
#[test]fn progress_line_is_bounded(){assert!(ProgressParser::default().feed(&vec![b'x';4097]).is_err());}

#[derive(Default)]struct State{calls:AtomicUsize,published:AtomicBool,released:AtomicBool,fail_decode:AtomicBool,change_after_render:AtomicBool,rendered:AtomicBool}
#[derive(Clone,Default)]struct MockHost{state:Arc<State>}
struct MockLease{state:Arc<State>,path:PathBuf}
impl Drop for MockLease{fn drop(&mut self){self.state.released.store(true,Ordering::SeqCst);}}
impl OutputLease for MockLease{fn path(&self)->&Path{&self.path}fn publish(self:Box<Self>,cancel:&Cancellation)->Result<PathBuf>{cancel.check()?;self.state.published.store(true,Ordering::SeqCst);Ok(PathBuf::from("/final.mp4"))}}
impl MediaHost for MockHost{
    fn inspect_input(&self,_:&Path,c:&Cancellation)->Result<InputFile>{c.check()?;self.state.calls.fetch_add(1,Ordering::SeqCst);Ok(InputFile{canonical_path:"/selected/input.mp4".into(),stamp:stamp()})}
    fn revalidate_input(&self,_:&InputFile,c:&Cancellation)->Result<()>{c.check()?;if self.state.change_after_render.load(Ordering::SeqCst)&&self.state.rendered.load(Ordering::SeqCst){Err(Error::InputChanged)}else{Ok(())}}
    fn runtime_capabilities(&self,c:&Cancellation)->Result<RuntimeCapabilities>{c.check()?;self.state.calls.fetch_add(1,Ordering::SeqCst);Ok(capabilities())}
    fn run(&self,t:&MediaTask,c:&Cancellation,_:&mut ProgressSink<'_>)->Result<ToolOutput>{c.check()?;self.state.calls.fetch_add(1,Ordering::SeqCst);match t{
        MediaTask::Probe{input}=>Ok(ToolOutput{stdout:if input.file_name().unwrap()=="staged.mp4"{include_bytes!("fixtures/output-ordinary.json").to_vec()}else{include_bytes!("fixtures/probe-base.json").to_vec()}}),
        MediaTask::Render{..}=>{self.state.rendered.store(true,Ordering::SeqCst);Ok(ToolOutput{stdout:vec![]})},
        MediaTask::ValidateDecode{..}=>if self.state.fail_decode.load(Ordering::SeqCst){Err(Error::ToolFailed{tool:"ffmpeg",exit_code:Some(1)})}else{Ok(ToolOutput{stdout:vec![]})},
    }}
    fn stage_output(&self,_:&InputFile,_:&Path,_:&OutputPolicy,c:&Cancellation)->Result<Box<dyn OutputLease>>{c.check()?;Ok(Box::new(MockLease{state:self.state.clone(),path:"/private/staged.mp4".into()}))}
}
#[test]fn construction_and_status_have_no_io(){let h=MockHost::default();let s=h.state.clone();let x=VideoExtension::new(h,VideoSettings::default()).unwrap();x.status().unwrap();assert_eq!(s.calls.load(Ordering::SeqCst),0);}
#[test]fn disabled_extension_does_not_call_host(){let h=MockHost::default();let s=h.state.clone();let x=VideoExtension::new(h,VideoSettings::default()).unwrap();x.disable().unwrap();assert!(matches!(x.probe(Path::new("x.mp4"),&Cancellation::new(),&mut |_|{}),Err(Error::Disabled)));assert_eq!(s.calls.load(Ordering::SeqCst),0);}
#[test]fn pre_cancelled_operation_has_no_io(){let h=MockHost::default();let s=h.state.clone();let x=VideoExtension::new(h,VideoSettings::default()).unwrap();let c=Cancellation::new();c.cancel();assert!(matches!(x.probe(Path::new("x.mp4"),&c,&mut |_|{}),Err(Error::Cancelled)));assert_eq!(s.calls.load(Ordering::SeqCst),0);}
#[test]fn workflow_probes_renders_decodes_then_publishes(){let h=MockHost::default();let s=h.state.clone();let x=VideoExtension::new(h,VideoSettings::default()).unwrap();let r=x.render_unedited(&RenderRequest::new("in.mp4","out.mp4"),&Cancellation::new(),&mut |_|{}).unwrap();assert!(r.full_decode_validated);assert!(s.published.load(Ordering::SeqCst));assert_eq!(x.status().unwrap().active_jobs,0);}
#[test]fn failed_decode_cannot_publish(){let h=MockHost::default();let s=h.state.clone();s.fail_decode.store(true,Ordering::SeqCst);let x=VideoExtension::new(h,VideoSettings::default()).unwrap();assert!(x.render_unedited(&RenderRequest::new("in.mp4","out.mp4"),&Cancellation::new(),&mut |_|{}).is_err());assert!(!s.published.load(Ordering::SeqCst));assert!(s.released.load(Ordering::SeqCst));}
#[test]fn changed_source_cannot_publish(){let h=MockHost::default();let s=h.state.clone();s.change_after_render.store(true,Ordering::SeqCst);let x=VideoExtension::new(h,VideoSettings::default()).unwrap();assert!(matches!(x.render_unedited(&RenderRequest::new("in.mp4","out.mp4"),&Cancellation::new(),&mut |_|{}),Err(Error::InputChanged)));assert!(!s.published.load(Ordering::SeqCst));}
#[test]fn progress_callback_failure_cleans_job(){let x=VideoExtension::new(MockHost::default(),VideoSettings::default()).unwrap();assert!(matches!(x.probe(Path::new("in.mp4"),&Cancellation::new(),&mut |_|panic!("test callback")),Err(Error::CallbackPanicked)));assert_eq!(x.status().unwrap().active_jobs,0);}
#[test]fn wrong_output_extension_rejected_before_io(){let h=MockHost::default();let s=h.state.clone();let x=VideoExtension::new(h,VideoSettings::default()).unwrap();assert!(x.render_unedited(&RenderRequest::new("in.mp4","out.webm"),&Cancellation::new(),&mut |_|{}).is_err());assert_eq!(s.calls.load(Ordering::SeqCst),0);}
#[test]fn nested_operation_hits_existing_job_limit(){let x=VideoExtension::new(MockHost::default(),VideoSettings::default()).unwrap();let mut checked=false;x.probe(Path::new("in.mp4"),&Cancellation::new(),&mut |_|{if !checked{checked=true;assert!(matches!(x.probe(Path::new("in.mp4"),&Cancellation::new(),&mut |_|{}),Err(Error::Busy)));}}).unwrap();assert!(checked);}
#[test]fn disable_cancels_active_job(){let x=VideoExtension::new(MockHost::default(),VideoSettings::default()).unwrap();let result=x.probe(Path::new("in.mp4"),&Cancellation::new(),&mut |_|{x.disable().unwrap();});assert!(matches!(result,Err(Error::Cancelled)));x.enable().unwrap();assert!(x.probe(Path::new("in.mp4"),&Cancellation::new(),&mut |_|{}).is_ok());}

#[test]fn time_base_support_is_not_assumed(){let mut c=capabilities();c.supports_demux_time_base=false;assert!(matches!(build_plan(&base(),&RenderOptions::default(),&c),Err(Error::MissingCapability(_))));}
