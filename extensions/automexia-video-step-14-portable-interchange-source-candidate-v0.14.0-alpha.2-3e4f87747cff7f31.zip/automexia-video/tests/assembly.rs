//! Authored-order assembly regressions. These tests exercise the Rust API;
//! independent media recipes are a separate verification layer.
use automexia_video::assembly::{AssemblyClip, AssemblySettings, MAX_ASSEMBLY_CLIPS};
use automexia_video::host::{FileStamp, InputFile};
use automexia_video::project::*;
use automexia_video::timing::PlaybackSpeed;
use automexia_video::{Error, Rational, RenderOptions, StreamSelection};

fn r(value: &str) -> Rational { value.parse().unwrap() }
fn range(start: &str, end: &str) -> TimeRange { TimeRange::new(r(start), r(end)).unwrap() }
fn clip(id: &str, start: &str, end: &str, speed: PlaybackSpeed) -> AssemblyClip {
    AssemblyClip { id: id.into(), range: range(start, end), speed }
}
fn accepted(clips: Vec<AssemblyClip>) -> AssemblySettings {
    AssemblySettings { enabled: true, disposition: Disposition::AutoApply, locked: false, clips }
}
fn project() -> Project {
    let location = std::env::temp_dir().join("amx-assembly/project.amxv");
    let media = automexia_video::media::parse_probe(include_bytes!("fixtures/probe-base.json")).unwrap();
    let input = InputFile {
        canonical_path: location.with_file_name("input.mp4"),
        stamp: FileStamp { size: 100, modified_ns: None, sha256: "a".repeat(64), file_id: None },
    };
    let source = ProjectSource::from_probe("source-1", &input, &media,
        media.select(StreamSelection::default()).unwrap(), &location).unwrap();
    Project::new("assembly", source, ResolvedSettings {
        workflow: None, preset_name: None, preset_revision: None, pause_cleanup: None,
        voice_cleanup: None, voice_enhancement: None, color_correction: None,
        render: FrozenRenderSettings::from_options(&RenderOptions::default()).unwrap(),
    }).unwrap()
}
fn timeline(ranges: &[TimeRange]) -> Timeline {
    let mut cursor = r("0");
    let segments = ranges.iter().map(|source_range| {
        let end = cursor.checked_add(source_range.duration().unwrap()).unwrap();
        let segment = TimelineSegment {
            source_id: "source-1".into(), source_range: *source_range,
            output_range: TimeRange::new(cursor, end).unwrap(),
        };
        cursor = end;
        segment
    }).collect();
    Timeline { segments, duration: cursor }
}
fn same_timeline(left: &Timeline, right: &Timeline) {
    assert_eq!(serde_json::to_value(left).unwrap(), serde_json::to_value(right).unwrap());
}

#[test]
fn reorder_repeat_and_independent_speeds_preserve_authored_order() {
    let p = project();
    let settings = accepted(vec![
        clip("last", "1", "2", PlaybackSpeed::Double),
        clip("first", "0", "1/2", PlaybackSpeed::Half),
        clip("again", "1", "2", PlaybackSpeed::Normal),
    ]);
    let result = settings.apply(&p.timeline().unwrap(), &p.sources[0]).unwrap();
    assert_eq!(result.duration, r("5/2"));
    assert_eq!(result.segments.len(), 3);
    assert_eq!(result.segments.iter().map(|s| s.source_range).collect::<Vec<_>>(),
        vec![range("1", "2"), range("0", "1/2"), range("1", "2")]);
    assert_eq!(result.segments.iter().map(|s| s.output_range).collect::<Vec<_>>(),
        vec![range("0", "1/2"), range("1/2", "3/2"), range("3/2", "5/2")]);
    assert_eq!(result.output_to_source(r("1/4")).unwrap().unwrap().1, r("3/2"));
    assert_eq!(result.output_to_source(r("1")).unwrap().unwrap().1, r("1/4"));
    assert_eq!(result.output_to_source(r("2")).unwrap().unwrap().1, r("3/2"));
    assert!(result.output_to_source(r("5/2")).unwrap().is_none());
}

#[test]
fn adjacent_authored_entries_remain_distinct_joins() {
    let p = project();
    let settings = accepted(vec![clip("a", "0", "1", PlaybackSpeed::Normal),
        clip("b", "1", "2", PlaybackSpeed::Normal)]);
    let result = settings.apply(&p.timeline().unwrap(), &p.sources[0]).unwrap();
    assert_eq!(result.segments.len(), 2);
    assert_eq!(result.segments[0].source_range.end, result.segments[1].source_range.start);
}

#[test]
fn trims_intersect_each_retained_piece_without_restoring_removed_media() {
    let mut p = project();
    p.remove_range("source-1", range("1/2", "1"), "reviewed cut").unwrap();
    let settings = accepted(vec![clip("trim", "1/4", "3/2", PlaybackSpeed::Half)]);
    let result = settings.apply(&p.timeline().unwrap(), &p.sources[0]).unwrap();
    assert_eq!(result.segments.len(), 2);
    assert_eq!(result.segments[0].source_range, range("1/4", "1/2"));
    assert_eq!(result.segments[1].source_range, range("1", "3/2"));
    assert_eq!(result.duration, r("3/2"));
    assert_eq!(result.segments[1].output_range.start, r("1/2"));
}

#[test]
fn protected_generated_cuts_and_manual_override_stay_authoritative() {
    let mut p = project();
    p.add_operation(EditOperation {
        id: "suggestion".into(), source_id: "source-1".into(), kind: EditKind::RemoveRange,
        range: range("1/2", "3/2"), reason: "generated silence".into(),
        origin: EditOrigin::Generator { id: "test".into(), version: "1".into() },
        disposition: Disposition::AutoApply, enabled: true, locked: false, user_override: false,
    }).unwrap();
    p.protect_range("source-1", range("3/4", "1"), "keep this phrase").unwrap();
    p.remove_range("source-1", range("4/5", "9/10"), "explicit manual removal").unwrap();
    let settings = accepted(vec![clip("phrase", "1/2", "3/2", PlaybackSpeed::Normal)]);
    let result = settings.apply(&p.timeline().unwrap(), &p.sources[0]).unwrap();
    assert_eq!(result.segments.iter().map(|s| s.source_range).collect::<Vec<_>>(),
        vec![range("3/4", "4/5"), range("9/10", "1")]);
    assert_eq!(result.duration, r("3/20"));
}

#[test]
fn locked_keep_clip_protection_is_preserved_by_intersection() {
    let mut p = project();
    p.set_clip_locked("clip-1", true).unwrap();
    p.add_operation(EditOperation {
        id: "suggestion".into(), source_id: "source-1".into(), kind: EditKind::RemoveRange,
        range: range("1/2", "3/2"), reason: "generated silence".into(),
        origin: EditOrigin::Generator { id: "test".into(), version: "1".into() },
        disposition: Disposition::AutoApply, enabled: true, locked: false, user_override: false,
    }).unwrap();
    p.remove_range("source-1", range("3/4", "1"), "manual cut").unwrap();
    let result = accepted(vec![clip("phrase", "1/2", "3/2", PlaybackSpeed::Normal)])
        .apply(&p.timeline().unwrap(), &p.sources[0]).unwrap();
    assert_eq!(result.segments.iter().map(|s| s.source_range).collect::<Vec<_>>(),
        vec![range("1/2", "3/4"), range("1", "3/2")]);
}

#[test]
fn entirely_removed_entry_fails_instead_of_silently_disappearing() {
    let mut p = project();
    p.remove_range("source-1", range("1/2", "1"), "cut").unwrap();
    let settings = accepted(vec![clip("good", "0", "1/4", PlaybackSpeed::Normal),
        clip("removed", "1/2", "1", PlaybackSpeed::Normal)]);
    settings.validate_for_source(&p.sources[0]).unwrap();
    assert!(matches!(settings.apply(&p.timeline().unwrap(), &p.sources[0]), Err(Error::Unsupported(_))));
}

#[test]
fn half_open_endpoint_contact_retains_no_material() {
    let p = project();
    let retained = timeline(&[range("0", "1/2"), range("1", "2")]);
    let settings = accepted(vec![clip("gap", "1/2", "1", PlaybackSpeed::Normal)]);
    assert!(matches!(settings.apply(&retained, &p.sources[0]), Err(Error::Unsupported(_))));
}

#[test]
fn disabled_or_ignored_settings_are_exact_identity() {
    let p = project();
    let input = p.timeline().unwrap();
    for (enabled, disposition) in [(false, Disposition::NeedsReview), (false, Disposition::AutoApply),
        (true, Disposition::Ignore), (false, Disposition::Ignore)] {
        let mut settings = accepted(vec![clip("slice", "1", "2", PlaybackSpeed::Double)]);
        settings.enabled = enabled;
        settings.disposition = disposition;
        same_timeline(&settings.apply(&input, &p.sources[0]).unwrap(), &input);
        assert!(!settings.active());
    }
}

#[test]
fn enabled_pending_proposal_never_changes_the_timeline() {
    let p = project();
    let mut settings = accepted(vec![clip("slice", "0", "1", PlaybackSpeed::Normal)]);
    settings.disposition = Disposition::NeedsReview;
    assert_eq!(settings.apply(&p.timeline().unwrap(), &p.sources[0]).unwrap_err(), Error::UnresolvedEdits);
}

#[test]
fn source_bounds_are_checked_even_for_disabled_or_ignored_settings() {
    let p = project();
    let input = p.timeline().unwrap();
    let mut settings = accepted(vec![clip("too-long", "0", "3", PlaybackSpeed::Normal)]);
    settings.enabled = false;
    assert!(matches!(settings.apply(&input, &p.sources[0]), Err(Error::InvalidProject(_))));
    settings.enabled = true;
    settings.disposition = Disposition::Ignore;
    assert!(settings.apply(&input, &p.sources[0]).is_err());
}

#[test]
fn invalid_entry_ranges_are_not_clamped_or_sorted() {
    for invalid in [TimeRange { start: r("-1"), end: r("1") },
        TimeRange { start: r("1"), end: r("1") }, TimeRange { start: r("2"), end: r("1") }] {
        let mut settings = accepted(vec![clip("entry", "0", "1", PlaybackSpeed::Normal)]);
        settings.clips[0].range = invalid;
        assert!(settings.validate().is_err());
    }
}

#[test]
fn identity_validation_covers_duplicates_empty_non_ascii_and_length() {
    for id in ["".to_string(), "has space".into(), "slash/name".into(), "é".into(), "a".repeat(65)] {
        assert!(accepted(vec![clip(&id, "0", "1", PlaybackSpeed::Normal)]).validate().is_err());
    }
    assert!(accepted(vec![clip(&"a".repeat(64), "0", "1", PlaybackSpeed::Normal)]).validate().is_ok());
    assert!(accepted(vec![clip("same", "0", "1", PlaybackSpeed::Normal),
        clip("same", "1", "2", PlaybackSpeed::Normal)]).validate().is_err());
}

#[test]
fn every_stored_assembly_requires_one_to_sixty_four_entries() {
    for disposition in [Disposition::AutoApply, Disposition::NeedsReview, Disposition::Ignore] {
        for enabled in [false, true] {
            let mut empty = AssemblySettings::default();
            empty.disposition = disposition;
            empty.enabled = enabled;
            assert!(empty.validate().is_err());
        }
    }
    let mut settings = accepted((0..MAX_ASSEMBLY_CLIPS).map(|i|
        clip(&format!("entry-{i}"), "0", "1", PlaybackSpeed::Normal)).collect());
    settings.validate().unwrap();
    settings.clips.push(clip("one-too-many", "0", "1", PlaybackSpeed::Normal));
    assert_eq!(settings.validate().unwrap_err(), Error::LimitExceeded("assembly clips"));
}

#[test]
fn retained_fragment_expansion_accepts_exactly_128_then_rejects_more() {
    let p = project();
    let retained = timeline(&[range("0", "1/2"), range("1", "3/2")]);
    let settings = accepted((0..64).map(|i|
        clip(&format!("entry-{i}"), "0", "2", PlaybackSpeed::Normal)).collect());
    let output = settings.apply(&retained, &p.sources[0]).unwrap();
    assert_eq!(output.segments.len(), MAX_RENDER_SEGMENTS);
    assert_eq!(output.duration, r("64"));
    let retained = timeline(&[range("0", "1/4"), range("1/2", "3/4"), range("1", "3/2")]);
    assert_eq!(settings.apply(&retained, &p.sources[0]).unwrap_err(), Error::LimitExceeded("assembly render segments"));
}

#[test]
fn oversized_authoritative_timeline_is_rejected_before_expansion() {
    let p = project();
    let retained = timeline(&(0..129).map(|i| TimeRange::new(
        Rational::new(i, 100).unwrap(), Rational::new(i * 2 + 1, 200).unwrap()).unwrap()).collect::<Vec<_>>());
    assert_eq!(accepted(vec![clip("entry", "0", "2", PlaybackSpeed::Normal)])
        .apply(&retained, &p.sources[0]).unwrap_err(), Error::LimitExceeded("assembly input segments"));
}

#[test]
fn mismatched_source_is_rejected_even_outside_requested_clip() {
    let p = project();
    let mut retained = timeline(&[range("0", "1/2"), range("1", "2")]);
    retained.segments[1].source_id = "other-source".into();
    assert!(matches!(accepted(vec![clip("entry", "0", "1/4", PlaybackSpeed::Normal)])
        .apply(&retained, &p.sources[0]), Err(Error::Unsupported(_))));
}

#[test]
fn reordered_or_overlapping_input_source_ranges_are_not_authoritative() {
    let p = project();
    let settings = accepted(vec![clip("entry", "0", "2", PlaybackSpeed::Normal)]);
    for ranges in [vec![range("1", "2"), range("0", "1")],
        vec![range("0", "1"), range("1/2", "3/2")], vec![range("0", "3")]] {
        assert!(matches!(settings.apply(&timeline(&ranges), &p.sources[0]), Err(Error::InvalidProject(_))));
    }
}

#[test]
fn output_gaps_overlaps_existing_speed_and_wrong_duration_are_rejected() {
    let p = project();
    let settings = accepted(vec![clip("entry", "0", "2", PlaybackSpeed::Normal)]);
    let clean = timeline(&[range("0", "1/2"), range("1", "2")]);
    let mut gap = clean.clone();
    gap.segments[1].output_range = range("3/4", "7/4");
    gap.duration = r("7/4");
    let mut overlap = clean.clone();
    overlap.segments[1].output_range = range("1/4", "5/4");
    overlap.duration = r("5/4");
    let mut speed = timeline(&[range("0", "1")]);
    speed.segments[0].output_range = range("0", "1/2");
    speed.duration = r("1/2");
    let mut wrong_duration = clean.clone();
    wrong_duration.duration = r("2");
    let mut origin = timeline(&[range("0", "1")]);
    origin.segments[0].output_range = range("1", "2");
    origin.duration = r("2");
    for input in [gap, overlap, speed, wrong_duration, origin] {
        assert!(matches!(settings.apply(&input, &p.sources[0]), Err(Error::InvalidProject(_))));
    }
}

#[test]
fn empty_authoritative_timeline_remains_an_error() {
    let p = project();
    assert_eq!(accepted(vec![clip("entry", "0", "1", PlaybackSpeed::Normal)])
        .apply(&Timeline { segments: vec![], duration: r("0") }, &p.sources[0]).unwrap_err(), Error::EmptyTimeline);
}

#[test]
fn fractional_frames_and_repeats_use_exact_cumulative_clocks() {
    let p = project();
    let frame = r("1001/30000");
    let settings = accepted(vec![
        AssemblyClip { id: "half".into(), range: TimeRange::new(r("0"), frame.ticks(3).unwrap()).unwrap(), speed: PlaybackSpeed::Half },
        AssemblyClip { id: "double".into(), range: TimeRange::new(frame, frame.ticks(3).unwrap()).unwrap(), speed: PlaybackSpeed::Double },
        AssemblyClip { id: "repeat".into(), range: TimeRange::new(r("0"), frame.ticks(3).unwrap()).unwrap(), speed: PlaybackSpeed::Normal },
    ]);
    let output = settings.apply(&p.timeline().unwrap(), &p.sources[0]).unwrap();
    assert_eq!(output.duration, frame.ticks(10).unwrap());
    assert_eq!(output.segments[1].output_range.start, frame.ticks(6).unwrap());
    assert_eq!(output.segments[2].output_range.start, frame.ticks(7).unwrap());
}

#[test]
fn output_duration_overflow_returns_error_without_mutating_inputs() {
    let mut source = project().sources.remove(0);
    source.duration = Rational::new(i64::MAX, 1).unwrap();
    let input = timeline(&[TimeRange::new(r("0"), source.duration).unwrap()]);
    let settings = accepted(vec![AssemblyClip { id: "huge".into(),
        range: input.segments[0].source_range, speed: PlaybackSpeed::Half }]);
    let input_before = serde_json::to_value(&input).unwrap();
    let settings_before = settings.clone();
    assert!(matches!(settings.apply(&input, &source), Err(Error::InvalidInput(_))));
    assert_eq!(serde_json::to_value(&input).unwrap(), input_before);
    assert_eq!(settings, settings_before);
}

#[test]
fn repeated_output_accumulation_is_checked_for_overflow() {
    let mut source = project().sources.remove(0);
    source.duration = Rational::new(i64::MAX / 2 + 1, 1).unwrap();
    let input = timeline(&[TimeRange::new(r("0"), source.duration).unwrap()]);
    let settings = accepted(vec![
        AssemblyClip { id: "first".into(), range: input.segments[0].source_range, speed: PlaybackSpeed::Normal },
        AssemblyClip { id: "second".into(), range: input.segments[0].source_range, speed: PlaybackSpeed::Normal },
    ]);
    assert!(matches!(settings.apply(&input, &source), Err(Error::InvalidInput(_))));
}

#[test]
fn positive_media_origin_does_not_shift_relative_assembly_ranges() {
    let mut p = project();
    let input = p.timeline().unwrap();
    p.sources[0].timeline_origin = r("10");
    let output = accepted(vec![clip("slice", "1", "2", PlaybackSpeed::Normal)])
        .apply(&input, &p.sources[0]).unwrap();
    assert_eq!(output.segments[0].source_range, range("1", "2"));
    assert_eq!(output.segments[0].output_range, range("0", "1"));
}

#[test]
fn assembly_roundtrips_exact_intent_and_rejects_unknown_json_fields() {
    let settings = accepted(vec![clip("stable-id", "1/3", "4/3", PlaybackSpeed::Half)]);
    let encoded = serde_json::to_value(&settings).unwrap();
    assert_eq!(serde_json::from_value::<AssemblySettings>(encoded.clone()).unwrap(), settings);
    let mut unknown = encoded.clone();
    unknown["unreviewed_option"] = serde_json::json!(true);
    assert!(serde_json::from_value::<AssemblySettings>(unknown).is_err());
    let mut unknown_clip = encoded.clone();
    unknown_clip["clips"][0]["source_id"] = serde_json::json!("another-source");
    assert!(serde_json::from_value::<AssemblySettings>(unknown_clip).is_err());
    let mut unknown_speed = encoded;
    unknown_speed["clips"][0]["speed"] = serde_json::json!("ramp");
    assert!(serde_json::from_value::<AssemblySettings>(unknown_speed).is_err());
}

#[test]
fn first_insertion_builds_a_valid_pending_draft() {
    let mut settings = AssemblySettings::default();
    settings.insert_clip(0, clip("first", "0", "1", PlaybackSpeed::Normal)).unwrap();
    settings.validate().unwrap();
    assert_eq!(settings.disposition, Disposition::NeedsReview);
}

#[test]
fn move_indices_refer_to_final_positions_and_identity_is_stable() {
    let mut settings = accepted(vec![clip("a", "0", "1/2", PlaybackSpeed::Half),
        clip("b", "1/2", "1", PlaybackSpeed::Normal), clip("c", "1", "2", PlaybackSpeed::Double)]);
    settings.move_clip("a", 2).unwrap();
    assert_eq!(settings.clips.iter().map(|c| c.id.as_str()).collect::<Vec<_>>(), vec!["b", "c", "a"]);
    assert_eq!(settings.clips[2].speed, PlaybackSpeed::Half);
    settings.move_clip("a", 0).unwrap();
    assert_eq!(settings.clips.iter().map(|c| c.id.as_str()).collect::<Vec<_>>(), vec!["a", "b", "c"]);
    assert_eq!(settings.disposition, Disposition::NeedsReview);
}

#[test]
fn repeat_copies_content_with_new_identity_and_explicit_position() {
    let mut settings = accepted(vec![clip("original", "1/2", "1", PlaybackSpeed::Double)]);
    settings.repeat_clip("original", "repeat", 0).unwrap();
    assert_eq!(settings.clips[0].id, "repeat");
    assert_eq!(settings.clips[1].id, "original");
    assert_eq!(settings.clips[0].range, settings.clips[1].range);
    assert_eq!(settings.clips[0].speed, settings.clips[1].speed);
}

#[test]
fn trim_and_speed_changes_require_review_and_preserve_disabled_state() {
    let mut settings = accepted(vec![clip("original", "0", "2", PlaybackSpeed::Normal)]);
    settings.enabled = false;
    settings.trim_clip("original", range("1/2", "3/2")).unwrap();
    assert_eq!(settings.disposition, Disposition::NeedsReview);
    assert!(!settings.enabled);
    settings.disposition = Disposition::Ignore;
    settings.set_clip_speed("original", PlaybackSpeed::Half).unwrap();
    assert_eq!(settings.disposition, Disposition::NeedsReview);
    assert_eq!(settings.clips[0].speed, PlaybackSpeed::Half);
    assert_eq!(settings.clips[0].range, range("1/2", "3/2"));
}

#[test]
fn every_content_edit_respects_the_settings_lock() {
    let mut settings = accepted(vec![clip("original", "0", "1", PlaybackSpeed::Normal)]);
    settings.locked = true;
    let before = settings.clone();
    assert_eq!(settings.insert_clip(1, clip("new", "1", "2", PlaybackSpeed::Normal)).unwrap_err(), Error::LockedEdit);
    assert_eq!(settings.repeat_clip("original", "repeat", 1).unwrap_err(), Error::LockedEdit);
    assert_eq!(settings.move_clip("original", 0).unwrap_err(), Error::LockedEdit);
    assert_eq!(settings.remove_clip("original").unwrap_err(), Error::LockedEdit);
    assert_eq!(settings.trim_clip("original", range("0", "1/2")).unwrap_err(), Error::LockedEdit);
    assert_eq!(settings.set_clip_speed("original", PlaybackSpeed::Double).unwrap_err(), Error::LockedEdit);
    assert_eq!(settings, before);
}

#[test]
fn invalid_crud_requests_are_transactional() {
    let mut settings = accepted(vec![clip("a", "0", "1", PlaybackSpeed::Normal),
        clip("b", "1", "2", PlaybackSpeed::Normal)]);
    let before = settings.clone();
    assert!(settings.insert_clip(3, clip("c", "0", "1", PlaybackSpeed::Normal)).is_err());
    assert_eq!(settings, before);
    assert!(settings.insert_clip(0, clip("a", "0", "1", PlaybackSpeed::Normal)).is_err());
    assert_eq!(settings, before);
    assert!(settings.move_clip("missing", 0).is_err());
    assert_eq!(settings, before);
    assert!(settings.move_clip("a", 2).is_err());
    assert_eq!(settings, before);
    assert!(settings.repeat_clip("a", "b", 0).is_err());
    assert_eq!(settings, before);
    assert!(settings.repeat_clip("missing", "new", 0).is_err());
    assert_eq!(settings, before);
    assert!(settings.remove_clip("missing").is_err());
    assert_eq!(settings, before);
    assert!(settings.trim_clip("a", TimeRange { start: r("1"), end: r("1") }).is_err());
    assert_eq!(settings, before);
    assert!(settings.set_clip_speed("missing", PlaybackSpeed::Half).is_err());
    assert_eq!(settings, before);
}

#[test]
fn removing_last_entry_is_atomic_and_requires_project_level_clear() {
    let mut settings = accepted(vec![clip("only", "0", "1", PlaybackSpeed::Normal)]);
    let before = settings.clone();
    assert!(settings.remove_clip("only").is_err());
    assert_eq!(settings, before);
}

#[test]
fn insert_and_repeat_enforce_clip_limit_without_changing_intent() {
    let mut settings = accepted((0..64).map(|i|
        clip(&format!("entry-{i}"), "0", "1", PlaybackSpeed::Normal)).collect());
    let before = settings.clone();
    assert_eq!(settings.insert_clip(64, clip("extra", "1", "2", PlaybackSpeed::Normal)).unwrap_err(), Error::LimitExceeded("assembly clips"));
    assert_eq!(settings, before);
    assert_eq!(settings.repeat_clip("entry-0", "extra", 0).unwrap_err(), Error::LimitExceeded("assembly clips"));
    assert_eq!(settings, before);
}

#[test]
fn inactive_identity_still_requires_bounded_authoritative_input() {
    let p = project();
    let oversized = timeline(&(0..129).map(|i| TimeRange::new(
        Rational::new(i, 100).unwrap(), Rational::new(i * 2 + 1, 200).unwrap()).unwrap()).collect::<Vec<_>>());
    for (enabled, disposition) in [(false, Disposition::NeedsReview), (true, Disposition::Ignore)] {
        let mut settings = accepted(vec![clip("entry", "0", "1", PlaybackSpeed::Normal)]);
        settings.enabled = enabled;
        settings.disposition = disposition;
        assert_eq!(settings.apply(&oversized, &p.sources[0]).unwrap_err(), Error::LimitExceeded("assembly input segments"));
        let mut wrong = p.timeline().unwrap();
        wrong.duration = r("1");
        assert!(matches!(settings.apply(&wrong, &p.sources[0]), Err(Error::InvalidProject(_))));
    }
}

#[test]
fn supplied_source_requires_positive_duration_and_valid_identity() {
    let mut source = project().sources.remove(0);
    let settings = accepted(vec![clip("entry", "0", "1", PlaybackSpeed::Normal)]);
    source.duration = r("0");
    assert!(settings.validate_for_source(&source).is_err());
    source.duration = r("2");
    source.id = "not an identity".into();
    assert!(settings.validate_for_source(&source).is_err());
}

#[test]
fn successful_insert_and_remove_preserve_other_entry_identities() {
    let mut settings = accepted(vec![clip("a", "0", "1", PlaybackSpeed::Normal)]);
    settings.insert_clip(0, clip("b", "1", "2", PlaybackSpeed::Double)).unwrap();
    assert_eq!(settings.clips.iter().map(|c| c.id.as_str()).collect::<Vec<_>>(), vec!["b", "a"]);
    settings.disposition = Disposition::AutoApply;
    settings.remove_clip("a").unwrap();
    assert_eq!(settings.clips, vec![clip("b", "1", "2", PlaybackSpeed::Double)]);
    assert_eq!(settings.disposition, Disposition::NeedsReview);
}

#[test]
fn every_eight_interval_retention_pattern_preserves_only_retained_content() {
    let p = project();
    let unit = r("1/4");
    // Independent count/membership checks over every nonempty subset. Every
    // interval is distinct even when adjacent, as required for authored joins.
    for mask in 1u16..256 {
        let retained: Vec<_> = (0i64..8).filter(|&index| mask & (1u16 << index) != 0).map(|index|
            TimeRange::new(unit.ticks(index).unwrap(), unit.ticks(index + 1).unwrap()).unwrap()).collect();
        for speed in [PlaybackSpeed::Half, PlaybackSpeed::Normal, PlaybackSpeed::Double] {
            let result = accepted(vec![clip("all", "0", "2", speed)])
                .apply(&timeline(&retained), &p.sources[0]).unwrap();
            assert_eq!(result.duration, unit.ticks(i64::from(mask.count_ones())).unwrap().checked_div(speed.ratio()).unwrap());
            assert_eq!(result.segments.len(), mask.count_ones() as usize);
            for segment in &result.segments {
                let middle = segment.output_range.start.checked_add(segment.output_range.duration().unwrap().checked_div(r("2")).unwrap()).unwrap();
                let (_, source_time) = result.output_to_source(middle).unwrap().unwrap();
                let index = source_time.checked_div(unit).unwrap().floor_units(1).unwrap();
                assert_ne!(mask & (1u16 << index), 0);
                assert_eq!(segment.source_range.duration().unwrap(), unit);
            }
        }
    }
}
