#![cfg(feature="native")]
//! Strict parser tests use synthetic JSON. They do not claim real-model accuracy.
use automexia_video::{Rational,whisper_cpp::parse_whisper_json};
use serde_json::{json,Value};
fn fixture()->Value{json!({"systeminfo":"synthetic test only","model":{"type":"tiny","multilingual":false},"params":{"language":"en","translate":false},"result":{"language":"en"},"transcription":[{"timestamps":{"from":"00:00:00,100","to":"00:00:00,500"},"offsets":{"from":100,"to":500},"text":" Hello","tokens":[{"text":" Hello","timestamps":{"from":"00:00:00,100","to":"00:00:00,500"},"offsets":{"from":100,"to":500},"id":2425,"p":0.9943224729138364,"t_dtw":-1}]}]})}
fn parse(v:Value)->automexia_video::Result<automexia_video::Recognition>{parse_whisper_json(&serde_json::to_vec(&v).unwrap(),Rational::new(2,1).unwrap(),"en")}
#[test]fn millisecond_word_offsets_and_probability_are_retained(){let r=parse(fixture()).unwrap();assert_eq!(r.words.len(),1);assert_eq!(r.words[0].text,"Hello");assert_eq!(r.words[0].range.start,Rational::new(1,10).unwrap());assert_eq!(r.words[0].confidence,Some(0.9943224729138364));}
#[test]fn duplicate_json_fields_are_rejected(){let bytes=serde_json::to_string(&fixture()).unwrap().replacen("{","{\"result\":{},",1);assert!(parse_whisper_json(bytes.as_bytes(),Rational::new(2,1).unwrap(),"en").is_err());}
#[test]fn unknown_token_fields_are_rejected(){let mut v=fixture();v["transcription"][0]["tokens"][0]["execute"]="x".into();assert!(parse(v).is_err());}
#[test]fn offset_timestamp_disagreement_is_rejected(){let mut v=fixture();v["transcription"][0]["offsets"]["from"]=101.into();assert!(parse(v).is_err());}
#[test]fn floating_offsets_are_rejected(){let mut v=fixture();v["transcription"][0]["offsets"]["from"]=100.1.into();assert!(parse(v).is_err());}
#[test]fn negative_offsets_are_rejected(){let mut v=fixture();v["transcription"][0]["offsets"]["from"]=(-1).into();assert!(parse(v).is_err());}
#[test]fn confidence_above_one_is_rejected(){let mut v=fixture();v["transcription"][0]["tokens"][0]["p"]=1.1.into();assert!(parse(v).is_err());}
#[test]fn missing_full_token_evidence_is_rejected(){let mut v=fixture();v["transcription"][0].as_object_mut().unwrap().remove("tokens");assert!(parse(v).is_err());}
#[test]fn ordinary_segment_with_multiple_words_is_rejected(){let mut v=fixture();v["transcription"][0]["text"]="Hello world".into();assert!(parse(v).is_err());}
#[test]fn translation_is_not_accepted_as_source_transcript(){let mut v=fixture();v["params"]["translate"]=true.into();assert!(parse(v).is_err());}
#[test]fn changed_language_is_rejected(){let mut v=fixture();v["result"]["language"]="fr".into();assert!(parse(v).is_err());}
#[test]fn larger_model_output_is_rejected(){let mut v=fixture();v["model"]["type"]="large-v3".into();assert!(parse(v).is_err());}
#[test]fn inconsistent_token_text_is_rejected(){let mut v=fixture();v["transcription"][0]["tokens"][0]["text"]=" World".into();assert!(parse(v).is_err());}
#[test]fn overlapping_word_segments_are_rejected(){let mut v=fixture();let segment=v["transcription"][0].clone();v["transcription"].as_array_mut().unwrap().push(segment);assert!(parse(v).is_err());}
#[test]fn beyond_audio_duration_is_rejected(){assert!(parse_whisper_json(&serde_json::to_vec(&fixture()).unwrap(),Rational::new(1,5).unwrap(),"en").is_err());}
#[test]fn zero_duration_tokens_preserve_word_as_uncertain(){let mut v=fixture();v["transcription"][0]["tokens"][0]["offsets"]["to"]=100.into();v["transcription"][0]["tokens"][0]["timestamps"]["to"]="00:00:00,100".into();assert_eq!(parse(v).unwrap().words[0].confidence,None);}
#[test]fn known_special_tokens_do_not_enter_caption_text(){let mut v=fixture();let special=json!({"text":"[_BEG_]","id":50257,"p":0.1});v["transcription"][0]["tokens"].as_array_mut().unwrap().insert(0,special);assert_eq!(parse(v).unwrap().words[0].text,"Hello");}
#[test]fn timestamp_special_tokens_do_not_enter_caption_text(){let mut v=fixture();let special=json!({"text":"[_TT_15]","id":50378,"p":0.1});v["transcription"][0]["tokens"].as_array_mut().unwrap().insert(0,special);assert_eq!(parse(v).unwrap().words[0].text,"Hello");}
#[test]fn special_token_ids_cannot_hide_ordinary_words(){let mut v=fixture();v["transcription"][0]["tokens"][0]["id"]=50257.into();assert!(parse(v).is_err());}
#[test]fn empty_transcription_is_valid_empty_observation(){let mut v=fixture();v["transcription"]=json!([]);assert!(parse(v).unwrap().words.is_empty());}
#[test]fn control_character_in_word_is_rejected(){let mut v=fixture();v["transcription"][0]["text"]="\u{202e}Hello".into();assert!(parse(v).is_err());}
