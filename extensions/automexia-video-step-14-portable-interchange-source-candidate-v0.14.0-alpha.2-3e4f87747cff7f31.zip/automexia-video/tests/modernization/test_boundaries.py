"""Tests of the source-compatibility guard, not Rust behavior."""
import importlib.util
import json
from pathlib import Path
import shutil
import tempfile
import unittest
ROOT=Path(__file__).resolve().parents[2]
spec=importlib.util.spec_from_file_location('step12_boundary',ROOT/'tools/check_modernization.py')
guard=importlib.util.module_from_spec(spec);spec.loader.exec_module(guard)
class Boundaries(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp=tempfile.TemporaryDirectory(prefix='video-boundary-',dir=ROOT.parent.resolve())
        cls.root=Path(cls.tmp.name)/'video'
        if cls.root.resolve().is_relative_to(ROOT.resolve()):
            cls.tmp.cleanup();raise RuntimeError('Boundary fixture must be outside the source checkout')
        cls.addClassCleanup(cls.tmp.cleanup)
        policy=json.loads((ROOT/'architecture-policy.json').read_text())
        required=set(policy['required_previous_paths'])|{'Cargo.toml','architecture-policy.json'}
        required.update(p.relative_to(ROOT).as_posix() for p in (ROOT/'src').rglob('*.rs'))
        for name in sorted(required):
            relative=Path(name)
            if relative.is_absolute() or '..' in relative.parts:raise RuntimeError('Unsafe boundary fixture path')
            destination=cls.root/relative;destination.parent.mkdir(parents=True,exist_ok=True)
            shutil.copy2(ROOT/relative,destination)
    @classmethod
    def tearDownClass(cls):cls.tmp.cleanup()
    def mutate(self,name,transform):
        p=self.root/name;original=p.read_bytes()
        try:
            p.write_bytes(transform(original));self.assertEqual(guard.inspect(self.root)['status'],'failed')
        finally:p.write_bytes(original)
    def test_current_boundaries(self):self.assertEqual(guard.inspect(self.root)['errors'],[])
    def test_lifecycle_cannot_gain_process_io(self):self.mutate('src/lifecycle.rs',lambda b:b'use std::process;\n'+b)
    def test_changed_media_recipe_is_rejected(self):self.mutate('tests/media/run_media_checks.py',lambda b:b+b'\n# changed\n')
    def test_mailbox_cannot_gain_network_io(self):self.mutate('src/progress_mailbox.rs',lambda b:b'use std::net;\n'+b)
    def test_cache_cannot_gain_file_io(self):self.mutate('src/observation_cache.rs',lambda b:b'use std::fs;\n'+b)
    def test_extra_process_owner_is_rejected(self):self.mutate('src/extension.rs',lambda b:b'fn bad(){Command::new("bad");}\n'+b)
    def test_added_dependency_is_rejected(self):self.mutate('Cargo.toml',lambda b:b.replace(b'[dependencies]',b'[dependencies]\nreqwest = "0.12"'))
    def test_missing_previous_path_is_rejected(self):
        p=self.root/'src/host.rs';data=p.read_bytes();p.unlink()
        try:self.assertEqual(guard.inspect(self.root)['status'],'failed')
        finally:p.write_bytes(data)
if __name__=='__main__':unittest.main()
