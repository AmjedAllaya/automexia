use automexia_video::*;
use automexia_video::host::{FileStamp,MediaTask,ToolOutput};
use automexia_video::interchange::{CfrEvidence,CfrVerifier};
use automexia_video::project::{ProjectSource,ResolvedSettings,FrozenRenderSettings};
use std::{path::{Path,PathBuf},sync::{Arc,Mutex,atomic::{AtomicUsize,Ordering}}};
fn r(s:&str)->Rational{s.parse().unwrap()}
fn rate()->EditRate{EditRate::new(r("30000/1001"),false).unwrap()}
fn location()->PathBuf{std::env::temp_dir().join("bundle-workflow-fixture").join("project.amxv")}
fn source()->InputFile{InputFile{canonical_path:location().with_file_name("input.mov"),stamp:FileStamp{size:100,modified_ns:None,sha256:"a".repeat(64),file_id:None}}}
fn project()->Project{let m=automexia_video::media::parse_probe(include_bytes!("fixtures/probe-base.json")).unwrap();let source=ProjectSource::from_probe("source-1",&source(),&m,m.select(StreamSelection::default()).unwrap(),&location()).unwrap();Project::new("bundle-fixture",source,ResolvedSettings{workflow:None,voice_cleanup:None,voice_enhancement:None,color_correction:None,pause_cleanup:None,preset_name:None,preset_revision:None,render:FrozenRenderSettings::from_options(&RenderOptions::default()).unwrap()}).unwrap()}
fn request()->BundleRequest{BundleRequest::new(location(),location().with_file_name("handoff.zip"),InterchangeFormat::FcpXml,rate())}
#[derive(Default)]struct State{calls:AtomicUsize,staged:AtomicUsize,dropped:AtomicUsize,published:AtomicUsize,fail_probe:bool,cancel_after_commit:bool,canonical_destination:bool,manifest:Mutex<Option<String>>}
#[derive(Clone)]struct Host(Arc<State>);
struct Lease{state:Arc<State>,workspace:PathBuf,destination:PathBuf}
impl Drop for Lease{fn drop(&mut self){self.state.dropped.fetch_add(1,Ordering::SeqCst);}}
impl BundleLease for Lease{
    fn workspace(&self)->&Path{&self.workspace}
    fn publish(self:Box<Self>,plan:&BundlePlan,cancel:&Cancellation,_:&mut ProgressSink<'_>)->Result<BundlePublication>{
        cancel.check()?;assert_eq!(plan.destination(),self.destination.as_path());assert!(plan.entries().iter().any(|e|e.name().starts_with("Media/")));
        *self.state.manifest.lock().unwrap()=Some(plan.manifest_sha256().into());self.state.published.fetch_add(1,Ordering::SeqCst);
        if self.state.cancel_after_commit{cancel.cancel();}
        Ok(BundlePublication{path:if self.state.canonical_destination{self.destination.with_file_name("canonical-handoff.zip")}else{self.destination.clone()},sha256:"b".repeat(64),size:1234})
    }
}
impl MediaHost for Host{
    fn inspect_input(&self,path:&Path,cancel:&Cancellation)->Result<InputFile>{cancel.check()?;self.0.calls.fetch_add(1,Ordering::SeqCst);if path.extension().is_some_and(|e|e=="zip"){Ok(InputFile{canonical_path:if self.0.canonical_destination{path.with_file_name("canonical-handoff.zip")}else{path.into()},stamp:FileStamp{size:1234,sha256:"b".repeat(64),modified_ns:None,file_id:None}})}else{Ok(source())}}
    fn revalidate_input(&self,_:&InputFile,cancel:&Cancellation)->Result<()>{cancel.check()}
    fn runtime_capabilities(&self,_:&Cancellation)->Result<RuntimeCapabilities>{panic!("source handoff should not encode")}
    fn run(&self,task:&MediaTask,cancel:&Cancellation,_:&mut ProgressSink<'_>)->Result<ToolOutput>{cancel.check()?;self.0.calls.fetch_add(1,Ordering::SeqCst);assert!(matches!(task,MediaTask::Probe{..}));if self.0.fail_probe{return Err(Error::Io("injected probe failure"));}Ok(ToolOutput{stdout:include_bytes!("fixtures/probe-base.json").to_vec()})}
    fn stage_output(&self,_:&InputFile,_:&Path,_:&OutputPolicy,_:&Cancellation)->Result<Box<dyn OutputLease>>{panic!("bundle owns one separate archive lease")}
}
impl InterchangeHost for Host{
    fn verify_cfr(&self,input:&InputFile,_:&MediaInfo,stream:u32,rate:EditRate,cancel:&Cancellation)->Result<CfrEvidence>{let mut proof=CfrVerifier::new(input.clone(),stream,rate,r("0"),r("2.002"),r("1/30000"))?;for n in 0..60{proof.feed(format!("pts={}\n",n*1001).as_bytes(),cancel)?;}proof.finish(cancel)}
    fn publish_interchange(&self,_:&InputFile,_:&[PathBuf],_:&ExportDocument,_:&Path,_:&OutputPolicy,_:&Cancellation)->Result<PathBuf>{panic!("bundle must not publish an external document")}
}
impl BundleHost for Host{
    fn stage_bundle(&self,_:&InputFile,protected:&[PathBuf],destination:&Path,_:u64,cancel:&Cancellation)->Result<Box<dyn BundleLease>>{cancel.check()?;assert!(protected.contains(&location()));self.0.staged.fetch_add(1,Ordering::SeqCst);Ok(Box::new(Lease{state:self.0.clone(),workspace:location().with_file_name("private-workspace"),destination:destination.into()}))}
}
fn extension(state:Arc<State>)->VideoExtension<Host>{VideoExtension::new(Host(state),VideoSettings::default()).unwrap()}
#[test]fn source_bundle_has_one_transaction_and_preserves_project(){let state=Arc::new(State::default());let e=extension(state.clone());let p=project();let before=p.to_json().unwrap();let out=e.export_bundle(&p,&request(),&Cancellation::new(),&mut |_|{}).unwrap();assert_eq!(out.status,ExportStatus::Published);assert_eq!(state.staged.load(Ordering::SeqCst),1);assert_eq!(state.published.load(Ordering::SeqCst),1);assert_eq!(state.dropped.load(Ordering::SeqCst),1);assert!(state.manifest.lock().unwrap().is_some());assert_eq!(before,p.to_json().unwrap());}
#[test]fn unresolved_assembly_blocks_before_host_access(){let state=Arc::new(State::default());let e=extension(state.clone());let mut p=project();p.append_assembly_clip("main",AssemblyClip{id:"first".into(),range:TimeRange::new(r("0"),r("1")).unwrap(),speed:PlaybackSpeed::Normal}).unwrap();let out=e.export_bundle(&p,&request(),&Cancellation::new(),&mut |_|panic!("no progress")).unwrap();assert_eq!(out.status,ExportStatus::Blocked);assert_eq!(state.calls.load(Ordering::SeqCst),0);assert_eq!(state.staged.load(Ordering::SeqCst),0);}
#[test]fn cancelled_bundle_is_inert(){let state=Arc::new(State::default());let e=extension(state.clone());let c=Cancellation::new();c.cancel();assert!(matches!(e.export_bundle(&project(),&request(),&c,&mut |_|{}),Err(Error::Cancelled)));assert_eq!(state.calls.load(Ordering::SeqCst),0);}
#[test]fn failure_after_staging_drops_private_lease_without_commit(){let state=Arc::new(State{fail_probe:true,..Default::default()});let out=extension(state.clone()).export_bundle(&project(),&request(),&Cancellation::new(),&mut |_|{}).unwrap();assert_eq!(out.status,ExportStatus::Failed);assert!(out.destination.is_none());assert_eq!(state.staged.load(Ordering::SeqCst),1);assert_eq!(state.dropped.load(Ordering::SeqCst),1);assert_eq!(state.published.load(Ordering::SeqCst),0);}
#[test]fn post_commit_cancellation_is_reported_as_published_unverified(){let state=Arc::new(State{cancel_after_commit:true,..Default::default()});let out=extension(state.clone()).export_bundle(&project(),&request(),&Cancellation::new(),&mut |_|{}).unwrap();assert_eq!(out.status,ExportStatus::PublishedUnverified);assert_eq!(out.destination,Some(request().destination));assert_eq!(state.published.load(Ordering::SeqCst),1);assert!(out.error.unwrap().contains("published"));}
#[test]fn unsupported_audio_clock_blocks_before_any_bake(){let state=Arc::new(State::default());let mut p=project();p.sources[0].media.audio.as_mut().unwrap().sample_rate=Some(16000);let mut q=request();q.video=BundleVideo::Bake;q.audio=BundleAudio::BakeStem;let out=extension(state.clone()).export_bundle(&p,&q,&Cancellation::new(),&mut |_|panic!("no progress")).unwrap();assert_eq!(out.status,ExportStatus::Blocked);assert_eq!(state.calls.load(Ordering::SeqCst),0);}
#[test]fn xml_noncharacters_are_rejected_before_bake(){let state=Arc::new(State::default());let mut q=request();q.name="bad\u{ffff}".into();q.video=BundleVideo::Bake;let out=extension(state.clone()).export_bundle(&project(),&q,&Cancellation::new(),&mut |_|panic!("no progress")).unwrap();assert_eq!(out.status,ExportStatus::Blocked);assert_eq!(state.calls.load(Ordering::SeqCst),0);}
#[test]fn disabled_extension_cannot_start_bundle(){let state=Arc::new(State::default());let e=extension(state.clone());e.disable().unwrap();assert!(matches!(e.export_bundle(&project(),&request(),&Cancellation::new(),&mut |_|{}),Err(Error::Disabled)));assert_eq!(state.calls.load(Ordering::SeqCst),0);}

#[test]fn canonical_destination_is_verified_via_requested_path(){let state=Arc::new(State{canonical_destination:true,..Default::default()});let out=extension(state.clone()).export_bundle(&project(),&request(),&Cancellation::new(),&mut |_|{}).unwrap();assert_eq!(out.status,ExportStatus::Published);assert_eq!(out.destination,Some(request().destination.with_file_name("canonical-handoff.zip")));assert_eq!(state.published.load(Ordering::SeqCst),1);}
#[test]fn known_source_size_blocks_impossible_budget_before_host_access(){let state=Arc::new(State::default());let mut q=request();q.max_total_bytes=100;let out=extension(state.clone()).export_bundle(&project(),&q,&Cancellation::new(),&mut |_|panic!("no progress")).unwrap();assert_eq!(out.status,ExportStatus::Blocked);assert!(out.compatibility.items.iter().any(|item|item.id=="bundle-byte-budget"&&item.blocking));assert_eq!(state.calls.load(Ordering::SeqCst),0);}
struct Registry;
struct Registration;
impl ActionRegistry for Registry{fn register_video(&mut self,_:&[ActionDescriptor])->Result<Box<dyn RegistrationLease>>{Ok(Box::new(Registration))}}
impl RegistrationLease for Registration{fn stop_playback(&mut self)->Result<()>{Ok(())}fn unregister(&mut self)->Result<()>{Ok(())}}
#[test]fn typed_assessments_are_inert_and_deactivation_revokes_bundle_dispatch(){let state=Arc::new(State::default());let entry=RegisteredVideo::register(Host(state.clone()),VideoSettings::default(),&mut Registry,OptionalActions{portable_bundles:true,..Default::default()}).unwrap();let p=project();let q=request();let export=q.to_export_request(&location().with_file_name("private")).unwrap();assert!(matches!(entry.dispatch_interchange(InterchangeCommand::Assess{project:&p,request:&export},&Cancellation::new(),&mut |_|panic!("no progress")).unwrap(),InterchangeCommandResult::Assessment(report) if !report.blocked()));assert!(matches!(entry.dispatch_bundle(BundleCommand::Assess{project:&p,request:&q},&Cancellation::new(),&mut |_|panic!("no progress")).unwrap(),BundleCommandResult::Assessment(report) if !report.blocked()));assert_eq!(state.calls.load(Ordering::SeqCst),0);entry.deactivate(std::time::Duration::ZERO).unwrap();assert!(matches!(entry.dispatch_bundle(BundleCommand::Export{project:&p,request:&q},&Cancellation::new(),&mut |_|{}),Err(Error::Disabled)));assert_eq!(state.calls.load(Ordering::SeqCst),0);}
#[test]fn typed_bundle_export_uses_registered_host(){let state=Arc::new(State::default());let entry=RegisteredVideo::register(Host(state.clone()),VideoSettings::default(),&mut Registry,OptionalActions{portable_bundles:true,..Default::default()}).unwrap();assert!(matches!(entry.dispatch_bundle(BundleCommand::Export{project:&project(),request:&request()},&Cancellation::new(),&mut |_|{}).unwrap(),BundleCommandResult::Exported(out) if out.status==ExportStatus::Published));assert_eq!(state.published.load(Ordering::SeqCst),1);}
