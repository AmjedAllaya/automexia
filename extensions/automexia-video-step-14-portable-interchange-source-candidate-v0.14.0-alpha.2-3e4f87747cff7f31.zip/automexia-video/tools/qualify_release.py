#!/usr/bin/env python3
"""Run Video's existing checks and record exactly which verification layer ran.

Developer-only, Python 3.11+. No installer, model manager, or release authority.
Logs/output must be outside the source checkout. A missing compiler is BLOCKED,
not a successful check. Source delivery uses package_delivery.py independently.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import re
import shutil
import signal
import subprocess
import sys
import time
import tomllib
from datetime import datetime, timezone

MEDIA = ["media", "edit", "review", "pause", "voice", "color", "reframe",
         "presentation", "delivery", "interchange", "release", "speech", "enhancement", "face", "timing", "hdr", "assembly", "fcpxml", "bundle"]
SOURCE_DIRS = ("src", "tests", "examples", "tools", "samples")
BUILD_FILES = ("Cargo.toml", "Cargo.lock", "build.rs", "rust-toolchain", "rust-toolchain.toml", "rustfmt.toml", ".rustfmt.toml", "delivery-policy.json", "release-candidate.json", "architecture-policy.json")
MAX_LOG = 16 * 1024 * 1024

class QualificationError(Exception):
    pass

def require(condition, message):
    if not condition:
        raise QualificationError(message)

def finite_float(value):
    number = float(value)
    require(math.isfinite(number), "Nonfinite JSON number")
    return number

def sha(path):
    h = hashlib.sha256()
    with path.open("rb") as f:
        for part in iter(lambda: f.read(65536), b""):
            h.update(part)
    return h.hexdigest()

def source_identity(root):
    """Bind executable code, fixtures and Cargo configuration; reports are outputs."""
    require((root / "Cargo.toml").is_file(), "Cargo.toml is required")
    paths = [root / name for name in BUILD_FILES if (root / name).exists() or (root / name).is_symlink()]
    for dirname in (*SOURCE_DIRS, ".cargo", ".github"):
        directory = root / dirname
        if dirname in (".cargo", ".github") and not directory.exists() and not directory.is_symlink():
            continue
        require(directory.is_dir() and not directory.is_symlink(), "Missing or nonregular source directory")
        for base, dirs, files in os.walk(directory, followlinks=False,
                                        onerror=lambda e: (_ for _ in ()).throw(e)):
            dirs[:] = sorted(d for d in dirs if d not in {"__pycache__", "target", ".git"})
            for d in dirs:
                require(not (Path(base) / d).is_symlink(), "Source directory symlink")
            paths.extend(Path(base) / f for f in sorted(files) if not f.endswith(".pyc"))
    entries = {}
    for p in paths:
        require(p.is_file() and not p.is_symlink(), "Nonregular source file")
        entries[p.relative_to(root).as_posix()] = sha(p)
    text = json.dumps(entries, sort_keys=True, separators=(",", ":")).encode()
    return {"sha256": hashlib.sha256(text).hexdigest(), "files": entries}

def stop_process(proc):
    if proc.poll() is not None:
        return
    if os.name == "posix":
        try:
            os.killpg(proc.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
    else:
        # Test-runner cleanup only; not a production permission/execution API.
        try:
            subprocess.run(["taskkill", "/PID", str(proc.pid), "/T", "/F"],
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=10)
        except (OSError, subprocess.TimeoutExpired):
            proc.kill()
    proc.wait(timeout=15)

def run_command(name, argv, root, output, timeout, env=None):
    require(re.fullmatch(r"[a-z0-9_-]+", name) is not None, "Invalid check name")
    require(timeout > 0, "Positive timeout required")
    log = output / (name + ".log")
    require(not log.exists(), "Refusing to overwrite an earlier check log")
    child_env = dict(os.environ if env is None else env)
    child_env.pop("PYTHONOPTIMIZE", None)
    child_env["PYTHONDONTWRITEBYTECODE"] = "1"
    child_env["CARGO_TARGET_DIR"] = str(output / "cargo-target")
    temporary = output / "tmp"
    require(not temporary.is_symlink(), "Qualification temporary directory cannot be a symlink")
    temporary.mkdir(exist_ok=True)
    require(temporary.is_dir(), "Qualification temporary directory is not a directory")
    for key in ("TMPDIR", "TEMP", "TMP"):
        child_env[key] = str(temporary)
    started = time.monotonic()
    status, returncode, reason = "failed", None, None
    proc = None
    try:
        with log.open("xb") as stream:
            proc = subprocess.Popen([str(a) for a in argv], cwd=root, env=child_env,
                                    stdin=subprocess.DEVNULL, stdout=stream, stderr=subprocess.STDOUT,
                                    start_new_session=(os.name == "posix"))
            while True:
                code = proc.poll()
                # Inspect limits also on the exit iteration.
                if log.stat().st_size > MAX_LOG:
                    reason = "check_log_limit"
                    stop_process(proc)
                    break
                if code is not None:
                    returncode = code
                    status = "passed" if code == 0 else "failed"
                    break
                if time.monotonic() - started > timeout:
                    reason = "check_timeout"
                    stop_process(proc)
                    break
                time.sleep(0.025)
    except FileNotFoundError:
        status, reason = "blocked", "required_executable_missing"
    except OSError as exc:
        reason = "check_start_or_io_error:" + type(exc).__name__
    finally:
        if proc is not None:
            stop_process(proc)
    # Keep retained evidence bounded even if a fast writer exceeds the limit
    # between polling samples. This is a file-retention bound, not a disk quota.
    if log.is_file() and log.stat().st_size > MAX_LOG:
        status, reason = "failed", "check_log_limit"
        with log.open("r+b") as f:
            f.truncate(MAX_LOG)
    return {"name": name, "argv": [str(a) for a in argv], "status": status,
            "exit_code": returncode, "reason": reason,
            "seconds": round(time.monotonic() - started, 3),
            "log": log.name, "log_sha256": sha(log) if log.is_file() else None}

def media_result(path):
    require(not path.is_symlink() and path.is_file() and path.stat().st_size < 4 * 1024 * 1024,
            "Media check did not produce a bounded regular report")
    def unique(pairs):
        result = {}
        for key, value in pairs:
            require(key not in result, "Duplicate media report field")
            result[key] = value
        return result
    def invalid_number(value):
        raise QualificationError("Nonfinite media report number")
    raw = path.read_bytes()
    require(len(raw) < 4 * 1024 * 1024, "Media report size changed")
    data = json.loads(raw, object_pairs_hook=unique, parse_constant=invalid_number,
                      parse_float=finite_float)
    require(isinstance(data, dict), "Media report must be an object")
    for key in ("passed", "failed", "blocked"):
        value = data.get(key, 0) if key == "blocked" else data.get(key)
        require(type(value) is int and value >= 0, "Invalid media totals")
    require(data["passed"] > 0 and data["failed"] == 0, "Media suite failed or ran no cases")
    keys = [k for k in ("cases", "tests", "checks", "results") if k in data]
    require(len(keys) == 1, "Missing or ambiguous media case list")
    rows = data[keys[0]]
    blocked_count = data.get("blocked", 0)
    require(isinstance(rows, list) and len(rows) == data["passed"] + blocked_count,
            "Media case count mismatch")
    def passed_row(row):
        if not isinstance(row, dict):
            return False
        # Retained voice tests use a strict boolean, other suites a status enum.
        # If both appear they must agree; no truthiness or overwritten failures.
        if "status" in row:
            return row["status"] == "passed" and ("passed" not in row or row["passed"] is True)
        return row.get("passed") is True
    passed_rows = [r for r in rows if passed_row(r)]
    blocked_rows = [r for r in rows if isinstance(r, dict) and r.get("status") == "blocked"
                    and isinstance(r.get("reason"), str) and bool(r["reason"].strip())
                    and "passed" not in r]
    require(len(passed_rows) == data["passed"] and len(blocked_rows) == blocked_count,
            "Media case status mismatch")
    return {"passed": data["passed"], "failed": data["failed"], "blocked": blocked_count,
            "file": path.name, "sha256": hashlib.sha256(raw).hexdigest(),
            "scope": "independent_recipe_not_rust_execution"}

def blocked(name, reason):
    return {"name": name, "status": "blocked", "reason": reason,
            "exit_code": None, "seconds": 0}

def evidence_integrity(output, checks):
    """Reopen every recorded log/report before selecting it as final evidence."""
    verified, errors = [], []
    for check in checks:
        entries = []
        if "log" in check:
            entries.append((check["log"], check.get("log_sha256")))
        if "case_report" in check:
            row = check["case_report"]
            entries.append((row.get("file"), row.get("sha256")))
        for name, digest in entries:
            if (not isinstance(name, str) or not name or Path(name).name != name
                    or not isinstance(digest, str) or re.fullmatch(r"[a-f0-9]{64}", digest) is None):
                errors.append({"check": check["name"], "reason": "invalid_evidence_identity"})
                continue
            path = output / name
            try:
                matches = path.is_file() and not path.is_symlink() and sha(path) == digest
            except OSError:
                matches = False
            if matches:
                verified.append({"file": name, "sha256": digest})
            else:
                errors.append({"check": check["name"], "file": name, "reason": "retained_evidence_changed_or_missing"})
    return {"name": "retained-evidence-integrity", "status": "failed" if errors else "passed",
            "verified": verified, "errors": errors,
            "scope": "recorded report and log byte identity at qualification completion"}

def outcome(checks, source_unchanged=True):
    if not source_unchanged or any(c["status"] == "failed" for c in checks):
        return "failed", 1
    if not checks or any(c["status"] != "passed" for c in checks):
        return "blocked", 2
    return "passed", 0

def release_step(root, cargo):
    """Use the saved package identities, never a hardcoded or filename-derived step."""
    def read(name):
        p = root / name
        require(p.is_file() and not p.is_symlink() and p.stat().st_size <= 1024 * 1024,
                "Missing/nonregular release identity: " + name)
        def unique(pairs):
            obj = {}
            for k, v in pairs:
                require(k not in obj, "Duplicate release identity field")
                obj[k] = v
            return obj
        data = p.read_bytes()
        require(len(data) <= 1024 * 1024, "Release identity grew")
        def nonfinite(_):
            raise QualificationError("Nonfinite release identity")
        obj = json.loads(data, object_pairs_hook=unique, parse_constant=nonfinite,
                         parse_float=finite_float)
        require(isinstance(obj, dict), "Release identity must be an object")
        return obj
    policy = read("delivery-policy.json")
    candidate = read("release-candidate.json")
    step = policy.get("milestone")
    require(type(step) is int and 0 <= step <= 100 and type(candidate.get("step")) is int
            and candidate["step"] == step, "Release milestone mismatch")
    version = cargo["package"]["version"]
    require(policy.get("package_name") == cargo["package"]["name"] and
            policy.get("package_version") == candidate.get("package_version") == version,
            "Release package/version mismatch")
    return step

def model_prerequisites(env):
    """No fetching or dynamic loading. Verify explicit configuration presence."""
    missing = []
    for key in ('VIDEO_MODEL_MANIFEST','VIDEO_MODEL_WEIGHTS','VIDEO_MODEL_NOTICES','VIDEO_ORT_LIBRARY'):
        value=env.get(key)
        if not value:
            missing.append(key);continue
        p=Path(value)
        if not p.is_absolute() or not p.is_file() or p.is_symlink():missing.append(key)
    if not re.fullmatch(r'[0-9a-f]{64}',env.get('VIDEO_MODEL_MANIFEST_SHA256','')):
        missing.append('VIDEO_MODEL_MANIFEST_SHA256')
    return missing

def explicit_assets(env, paths, digests=()):
    """Require selected local bytes; never download or load unselected assets."""
    missing = []
    for key in paths:
        value = env.get(key)
        if not value:
            missing.append(key)
            continue
        path = Path(value)
        if not path.is_absolute() or not path.is_file() or path.is_symlink():
            missing.append(key)
    for key in digests:
        if not re.fullmatch(r"[0-9a-f]{64}", env.get(key, "")):
            missing.append(key)
    return missing

def whisper_prerequisites(env):
    return explicit_assets(env, (
        "AMXV_WHISPER_MANIFEST", "AMXV_WHISPER_WEIGHTS", "AMXV_WHISPER_NOTICES",
        "AMXV_WHISPER_EXECUTABLE", "AMXV_WHISPER_BUILD_INFO", "AMXV_TRANSCRIPT_INPUT",
        "AMXV_FFMPEG", "AMXV_FFPROBE"), ("AMXV_WHISPER_MANIFEST_SHA256",))

def face_prerequisites(env):
    missing = explicit_assets(env, ("FACE_MODEL_MANIFEST", "FACE_MODEL_WEIGHTS",
        "FACE_MODEL_NOTICES", "ORT_DYLIB_PATH", "FACE_FIXTURE_RGB"),
        ("FACE_EXPECTED_MANIFEST_SHA256",))
    for key in ("FACE_FIXTURE_WIDTH", "FACE_FIXTURE_HEIGHT"):
        text = env.get(key, "")
        if not re.fullmatch(r"[1-9][0-9]{0,3}", text) or int(text) > 8192:
            missing.append(key)
    return missing

def run(root, output, suite, timeout):
    require(sys.flags.optimize == 0, "Run without Python -O; recipe assertions must execute")
    root = root.resolve(strict=True)
    output = output.absolute()
    require(not output.exists(), "Use a new output directory for each qualification run")
    parent = output.parent.resolve(strict=True)
    require(parent != root and root not in parent.parents, "Output must be outside source")
    cargo = tomllib.loads((root / "Cargo.toml").read_text())
    require(cargo["package"]["name"] == "automexia-video", "Wrong package")
    step = release_step(root, cargo)
    output.mkdir()
    before = source_identity(root)
    checks = []
    env = dict(os.environ)
    env["CARGO_TARGET_DIR"] = str(output / "cargo-target")
    def execute(name, argv):
        r = run_command(name, argv, root, output, timeout, env)
        checks.append(r)
        return r
    if suite in ("all", "rust"):
        if not shutil.which("cargo") or not shutil.which("rustc"):
            checks.append(blocked("cargo-build-and-tests", "rustc_or_cargo_unavailable"))
        elif not (root / "Cargo.lock").is_file():
            checks.append(blocked("cargo-build-and-tests", "Generate_and_review_Cargo.lock_first"))
        else:
            execute("rust-version", ["rustc", "--version", "--verbose"])
            execute("cargo-version", ["cargo", "--version"])
            execute("cargo-metadata", ["cargo", "metadata", "--locked", "--all-features", "--format-version", "1"])
            execute("cargo-core", ["cargo", "test", "--locked", "--no-default-features"])
            font = env.get("VIDEO_TEST_FONT")
            if not font or not Path(font).is_file():
                checks.append(blocked("cargo-graphics-native", "VIDEO_TEST_FONT_required_not_bundled"))
            else:
                execute("cargo-graphics", ["cargo", "test", "--locked", "--features", "graphics"])
                execute("cargo-native", ["cargo", "test", "--locked", "--features", "native"])
            if step>=13:
                execute("cargo-all-feature-compile", ["cargo", "check", "--locked", "--all-features", "--all-targets"])
                execute("cargo-all-feature-library", ["cargo", "test", "--locked", "--all-features", "--lib"])
                missing=model_prerequisites(env)
                if missing:
                    checks.append(blocked("cargo-selected-model", "Explicit_reviewed_assets_required:"+','.join(missing)))
                else:
                    execute("cargo-selected-model", ["cargo", "test", "--locked", "--features", "silero-onnx", "--test", "silero_qualification", "--", "--test-threads=1"])
                missing = face_prerequisites(env)
                if missing:
                    checks.append(blocked("cargo-selected-face", "Explicit_reviewed_assets_required:" + ','.join(missing)))
                else:
                    execute("cargo-selected-face", ["cargo", "test", "--locked", "--features", "face-onnx",
                        "--test", "face_qualification", "--", "--ignored", "--test-threads=1"])
                missing = whisper_prerequisites(env)
                if missing:
                    checks.append(blocked("cargo-selected-whisper", "Explicit_reviewed_assets_required:" + ','.join(missing)))
                else:
                    env["AMXV_TRANSCRIPT_OUTPUT"] = str(output / "selected-transcript")
                    execute("cargo-selected-whisper", ["cargo", "run", "--locked", "--features", "native",
                                                      "--example", "transcript_smoke"])
            execute("cargo-package", ["cargo", "package", "--locked", "--allow-dirty"])
    if suite in ("all", "media"):
        for kind in MEDIA:
            script = root / "tests" / "media" / ("run_" + kind + "_checks.py")
            target = output / ("media-" + kind + ".json")
            args = [sys.executable, "-B", script, "--output", target]
            if kind == "interchange":
                args.extend(["--keep", output / "interchange-reference"])
            r = execute("media-" + kind, args)
            if r["status"] == "passed":
                try:
                    r["case_report"] = media_result(target)
                    if r["case_report"]["blocked"]:
                        r["status"], r["reason"] = "blocked", "media_cases_blocked"
                except (QualificationError, ValueError, OSError) as exc:
                    r["status"], r["reason"] = "failed", str(exc)
        # Separate evidence layers: actual Rust documents/archives are then
        # read independently. Constructed reference recipes cannot prove this.
        def readback(name, script, arguments, scope):
            target = output / (name + ".json")
            result = execute(name, [sys.executable, "-B", root / "tests/media" / script,
                                    *arguments, "--output", target])
            if result["status"] == "passed":
                try:
                    result["case_report"] = media_result(target)
                    result["case_report"]["scope"] = scope
                    if result["case_report"]["blocked"]:
                        result["status"], result["reason"] = "blocked", "readback_cases_blocked"
                except (QualificationError, ValueError, OSError) as exc:
                    result["status"], result["reason"] = "failed", str(exc)
        names = ("rust-interchange-readback", "rust-fcpxml-readback", "rust-bundle-readback")
        if shutil.which("cargo") and shutil.which("rustc") and (root / "Cargo.lock").is_file():
            exports = output / "interchange-rust"
            exports.mkdir()
            generated = execute("rust-interchange-generate", ["cargo", "run", "--locked",
                "--features", "native", "--example", "interchange_fixture", "--",
                output / "interchange-reference" / "interchange-source.mov", exports])
            if generated["status"] == "passed":
                readback(names[0], "run_interchange_checks.py", ["--rust-exports", exports],
                         "independent_reader_of_rust_generated_documents")
                readback(names[1], "run_fcpxml_checks.py", ["--rust-exports", exports],
                         "independent_reader_of_rust_generated_fcpxml_and_reference_cases")
            else:
                for name in names[:2]:
                    checks.append(blocked(name, "rust_document_generation_did_not_pass"))
            bundles = output / "bundle-rust"
            bundles.mkdir()
            generated = execute("rust-bundle-generate", ["cargo", "run", "--locked",
                "--features", "native", "--example", "bundle_fixture", "--",
                output / "interchange-reference" / "interchange-source.mov", bundles])
            if generated["status"] == "passed":
                arguments = []
                for filename in ("bundle-source-otio.zip", "bundle-source-fcpxml.zip", "bundle-baked-fcpxml.zip"):
                    arguments.extend(["--rust-bundle", bundles / filename])
                readback(names[2], "run_bundle_checks.py", arguments,
                         "independent_reader_of_rust_generated_archives_and_reference_cases")
            else:
                checks.append(blocked(names[2], "rust_bundle_generation_did_not_pass"))
        else:
            for name in names:
                checks.append(blocked(name, "rust_toolchain_and_reviewed_lock_required"))
    if suite in ("all", "packaging"):
        execute("packaging-tests", [sys.executable, "-B", "-m", "unittest", "discover", "-s", "tests/packaging", "-v"])
        execute("qualification-runner-tests", [sys.executable, "-B", "-m", "unittest", "discover", "-s", "tests/qualification", "-v"])
        execute("architecture-boundaries", [sys.executable, "-B", "tools/check_modernization.py"])
        execute("architecture-guard-tests", [sys.executable, "-B", "-m", "unittest", "discover", "-s", "tests/modernization", "-v"])
    checks.append(evidence_integrity(output, checks))
    after = source_identity(root)
    status, code = outcome(checks, before == after)
    report = {"format_version": 1, "step": step, "version": cargo["package"]["version"],
              "generated_at_utc": datetime.now(timezone.utc).isoformat(),
              "requested_suite": suite, "automated_status": status,
              "source_unchanged": before == after, "source_identity": before,
              "checks": checks, "release_ready": False,
              "release_reason": "Local checks cannot qualify host installation, editor import, platform matrix, rights, or perceptual acceptance",
              "not_executed_here": ["Automexia_install_update_remove", "target_editor_imports",
                                    "unrun_platforms", "human_recorded_corpus_review", "typing_latency_in_actual_host"]}
    final = output / "qualification.json"
    with final.open("x", encoding="utf-8") as f:
        json.dump(report, f, indent=2); f.write("\n")
    return final, code

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--source", type=Path, default=Path(__file__).resolve().parents[1])
    p.add_argument("--output", type=Path, required=True)
    p.add_argument("--suite", choices=("all", "rust", "media", "packaging"), default="all")
    p.add_argument("--timeout", type=int, default=1800)
    a = p.parse_args()
    try:
        require(1 <= a.timeout <= 14400, "Timeout must be 1..14400 seconds")
        report, code = run(a.source, a.output, a.suite, a.timeout)
        print(json.dumps({"report": str(report), "exit_code": code}))
        return code
    except (QualificationError, OSError, ValueError, KeyError) as exc:
        print("QUALIFICATION FAILED: " + str(exc), file=sys.stderr)
        return 1
if __name__ == "__main__":
    raise SystemExit(main())
