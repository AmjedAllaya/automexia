#!/usr/bin/env python3
"""Produce a dependency inventory from actual locked all-feature Cargo metadata.

No guessed transitive dependencies or reused old verification. Requires a
reviewed Cargo.lock and working Cargo. Outputs only after successful resolution.
"""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tomllib


def inventory(root):
    root = root.resolve(strict=True)
    lock = root / 'Cargo.lock'
    if not lock.is_file() or lock.is_symlink():
        raise ValueError('A reviewed regular Cargo.lock is required; generate and review it with Cargo first')
    before = lock.read_bytes()
    lock_data = tomllib.loads(before.decode())
    package = tomllib.loads((root / 'Cargo.toml').read_text())['package']
    result = subprocess.run(['cargo', 'metadata', '--locked', '--all-features', '--format-version', '1'],
                            cwd=root, stdin=subprocess.DEVNULL, capture_output=True, timeout=300)
    if result.returncode:
        raise ValueError('Cargo metadata failed: ' + result.stderr.decode(errors='replace')[-3000:])
    if len(result.stdout) > 16 * 1024 * 1024:
        raise ValueError('Cargo metadata exceeds bounded inventory size')
    data = json.loads(result.stdout)
    if lock.read_bytes() != before:
        raise ValueError('Cargo.lock changed during inventory')
    checksums = {(p['name'], p['version'], p.get('source')): p.get('checksum')
                 for p in lock_data.get('package', [])}
    root_id = data.get('resolve', {}).get('root')
    rows = []
    for p in data['packages']:
        if p['id'] == root_id:
            continue
        rows.append({'name': p['name'], 'version': p['version'], 'source': p.get('source'),
                     'license': p.get('license'), 'repository': p.get('repository'),
                     'checksum': checksums.get((p['name'], p['version'], p.get('source')))})
    rows.sort(key=lambda p: (p['name'], p['version']))
    return {'format_version': 1, 'package': package['name'], 'version': package['version'],
            'scope': 'all-feature locked Cargo metadata; licenses are metadata, not legal approval',
            'cargo_lock_sha256': hashlib.sha256(before).hexdigest(),
            'dependency_count': len(rows), 'dependencies': rows}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    try:
        data = inventory(args.source)
        with args.output.open('x', encoding='utf-8') as stream:
            json.dump(data, stream, indent=2, allow_nan=False)
            stream.write('\n')
    except (OSError, ValueError, KeyError, subprocess.TimeoutExpired) as error:
        print('DEPENDENCY INVENTORY BLOCKED: ' + str(error), file=sys.stderr)
        return 1
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
