#!/usr/bin/env python3
"""Static dependency/process guards, not Rust parsing or behavioral compatibility.

The reviewed architecture policy explicitly binds dependency boundaries and
retained fixtures. Intentional implementation changes are tested by Cargo; this
checker does not pretend a source-text digest is an implementation test.
"""
import argparse
import hashlib
import json
from pathlib import Path
import re
import tomllib


def inspect(root):
    root = Path(root)
    policy = json.loads((root / 'architecture-policy.json').read_text())
    if policy.get('format_version') != 1:
        raise ValueError('unsupported architecture policy')
    errors, preserved = [], []
    for name in policy['required_previous_paths']:
        p = root / name
        if not p.is_file() or p.is_symlink():
            errors.append('missing/nonregular previous path: ' + name)
    for name, expected in policy['preserved_fixture_hashes'].items():
        p = root / name
        if not p.is_file() or p.is_symlink():
            errors.append('missing/nonregular fixture: ' + name)
        elif hashlib.sha256(p.read_bytes()).hexdigest() != expected:
            errors.append('retained fixture changed: ' + name)
        else:
            preserved.append(name)
    cargo = tomllib.loads((root / 'Cargo.toml').read_text())
    for name in ('dependencies', 'features', 'target', 'dev-dependencies'):
        if cargo.get(name, {}) != policy['cargo'].get(name, {}):
            errors.append('dependency/feature boundary changed: ' + name)
    for name in policy['pure_modules']:
        p = root / name
        if not p.is_file() or p.is_symlink():
            errors.append('missing pure module: ' + name)
            continue
        text = p.read_text().split('#[cfg(test)]')[0]
        for pattern in (r'\bstd::(?:fs|process|net)\b', r'\b(?:Command|File)::',
                        r'\b(?:native|graphics_native)::', r'\bthread::(?:spawn|Builder)'):
            if re.search(pattern, text):
                errors.append('I/O/process boundary in ' + name)
    spawn = []
    for p in sorted((root / 'src').rglob('*.rs')):
        text = p.read_text().split('#[cfg(test)]')[0]
        if re.search(r'\bCommand::new\(', text):
            spawn.append(p.relative_to(root).as_posix())
    if spawn != policy['process_owners']:
        errors.append('unexpected process construction owners: ' + str(spawn))
    return {'status': 'passed' if not errors else 'failed',
            'verification_layer': 'static_source_boundaries_not_compilation',
            'preserved_files': preserved, 'process_construction_owners': spawn,
            'errors': errors}


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--source', type=Path, default=Path(__file__).resolve().parents[1])
    args = ap.parse_args()
    try:
        r = inspect(args.source)
    except (OSError, ValueError, KeyError) as e:
        r = {'status': 'failed', 'errors': [str(e)]}
    print(json.dumps(r, indent=2))
    return 0 if r['status'] == 'passed' else 1


if __name__ == '__main__':
    raise SystemExit(main())
