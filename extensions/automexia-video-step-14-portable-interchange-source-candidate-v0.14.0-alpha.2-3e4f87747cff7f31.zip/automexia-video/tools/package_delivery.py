#!/usr/bin/env python3
"""Build and reverify an immutable source delivery. Python 3.11+, standard library.

Integrity only: does not compile Rust, run media tests, prove feature completeness,
or upload a file. `links` reopens the artifacts and fails without printing links
if any check fails. A receipt is an integrity record, not a digital signature.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import math
import os
from pathlib import Path, PurePosixPath
import re
import stat
import sys
import tempfile
import tomllib
import unicodedata
import zipfile
from datetime import datetime, timezone

MAX_FILES = 4096
MAX_FILE_BYTES = 64 * 1024 * 1024
MAX_TOTAL_BYTES = 128 * 1024 * 1024
MAX_JSON_BYTES = 1024 * 1024
MAX_ARCHIVE_BYTES = MAX_TOTAL_BYTES + 4 * 1024 * 1024
POLICY_NAME = 'delivery-policy.json'
MANIFEST_NAME = 'SHA256SUMS'
OMIT_DIRS = {'.git', 'target', '__pycache__', '.pytest_cache'}
ROOT_DIRS = {'src', 'tests', 'examples', 'tools', 'samples', 'docs', 'reports', 'assets',
             '.cargo', '.github'}
ROOT_FILES = {'Cargo.toml', 'Cargo.lock', 'README.md', 'CHANGELOG.md',
              'THIRD-PARTY-NOTICES.md', 'delivery-policy.json', 'release-candidate.json',
              'architecture-policy.json', 'SHA256SUMS', 'build.rs', 'rustfmt.toml',
              '.rustfmt.toml', 'rust-toolchain', 'rust-toolchain.toml', '.gitignore',
              '.gitattributes', '.editorconfig', 'LICENSE', 'LICENSE.md', 'LICENSE.txt',
              'NOTICE', 'NOTICE.md', 'NOTICE.txt'}
FORBIDDEN_SUFFIXES = {'.ttf', '.otf', '.ttc', '.otc', '.woff', '.woff2'}
VERIFICATION_CHECKS = ['all_member_crc', 'exact_sha256_manifest', 'identity_and_required_files',
                       'fresh_extraction_byte_comparison', 'source_stability', 'published_file_reopen']
RECEIPT_FIELDS = {'format_version', 'status', 'verified_at_utc', 'archive', 'checksum_file',
                  'archive_info', 'checks', 'application_tests', 'browser_download_test'}
POLICY_FIELDS = {'format_version', 'package_name', 'package_version', 'milestone',
                 'delivery_label', 'artifact_scope', 'required_files'}
HEX = re.compile(r'[0-9a-f]{64}')
TOKEN = re.compile(r'[A-Za-z0-9][A-Za-z0-9._-]{0,90}')

class DeliveryError(Exception):
    """No delivery or links may be advertised after this error."""

def require(condition: bool, message: str) -> None:
    if not condition:
        raise DeliveryError(message)

def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def safe_relative(name: str) -> str:
    require(isinstance(name, str) and bool(name), 'Empty or invalid path')
    require(name == unicodedata.normalize('NFC', name), 'Non-canonical Unicode path')
    require(not name.startswith('/') and '\\' not in name and ':' not in name,
            'Absolute, drive or backslash path rejected')
    require(len(name.encode('utf-8')) <= 220, 'Relative path is too long for this delivery profile')
    parts = name.split('/')
    for part in parts:
        require(part not in ('', '.', '..'), 'Empty or traversal component')
        require(not part.endswith((' ', '.')), 'Non-portable trailing space/dot')
        require(not any(ord(c) < 32 or ord(c) == 127 or c in '<>"|?*' for c in part),
                'Control or non-portable path character')
        base = part.split('.')[0].upper()
        require(base not in {'CON', 'PRN', 'AUX', 'NUL', 'CLOCK$'}
                and not re.fullmatch(r'(COM|LPT)[0-9¹²³]', base), 'Reserved device name')
    return name

def check_namespace(names) -> None:
    """Reject case-colliding directories and file/directory aliases as well as files."""
    seen: dict[str, tuple[str, bool]] = {}
    for name in names:
        parts = safe_relative(name).split('/')
        for index in range(1, len(parts) + 1):
            prefix = '/'.join(parts[:index])
            is_file = index == len(parts)
            key = prefix.casefold()
            if key in seen:
                previous, previous_is_file = seen[key]
                require(previous == prefix, 'Case-colliding path component')
                require(not previous_is_file and not is_file, 'Duplicate file or file/directory conflict')
            else:
                seen[key] = (prefix, is_file)

def walk_error(error: OSError) -> None:
    raise DeliveryError('Unreadable source subtree; refusing incomplete package') from error

def no_symlink_components(path: Path) -> None:
    absolute = Path(os.path.abspath(path))
    for candidate in (absolute, *absolute.parents):
        require(not candidate.is_symlink(), 'Symlink path component rejected')

def read_regular(path: Path, limit: int = MAX_FILE_BYTES) -> bytes:
    no_symlink_components(path)
    before = path.lstat()
    require(stat.S_ISREG(before.st_mode), 'Expected a regular file')
    require(before.st_size <= limit, 'File size limit exceeded')
    flags = os.O_RDONLY | getattr(os, 'O_NOFOLLOW', 0) | getattr(os, 'O_BINARY', 0)
    fd = os.open(path, flags)
    with os.fdopen(fd, 'rb') as handle:
        opened = os.fstat(handle.fileno())
        require((before.st_dev, before.st_ino) == (opened.st_dev, opened.st_ino),
                'File changed while opening')
        data = handle.read(limit + 1)
        after = os.fstat(handle.fileno())
    require(len(data) <= limit, 'File size limit exceeded')
    require((opened.st_size, opened.st_mtime_ns, opened.st_ctime_ns) ==
            (after.st_size, after.st_mtime_ns, after.st_ctime_ns), 'File changed while reading')
    require(len(data) == after.st_size, 'Truncated file read')
    return data

def json_load(data: bytes) -> dict:
    require(len(data) <= MAX_JSON_BYTES, 'JSON size limit exceeded')
    def pairs(items):
        result = {}
        for key, value in items:
            require(key not in result, 'Duplicate JSON key')
            result[key] = value
        return result
    def constant(_):
        raise DeliveryError('Nonfinite JSON number')
    def finite_float(text):
        value = float(text)
        require(math.isfinite(value), 'Nonfinite JSON number')
        return value
    try:
        value = json.loads(data.decode('utf-8'), object_pairs_hook=pairs,
                           parse_constant=constant, parse_float=finite_float)
    except (UnicodeError, ValueError, RecursionError) as exc:
        raise DeliveryError('Invalid JSON') from exc
    require(type(value) is dict, 'Expected a JSON object')
    return value

def policy_load(data: bytes, step: int, version: str) -> dict:
    policy = json_load(data)
    require(set(policy) == POLICY_FIELDS, 'Unexpected or missing delivery policy fields')
    require(type(policy['format_version']) is int and policy['format_version'] == 1,
            'Unsupported delivery policy format')
    require(type(step) is int and step >= 0, 'Invalid expected step')
    require(type(policy['milestone']) is int and policy['milestone'] == step,
            'Milestone mismatch: refusing to label another step as the requested delivery')
    require(policy['package_version'] == version, 'Expected version differs from policy')
    for key in ('package_name', 'package_version', 'delivery_label'):
        require(isinstance(policy[key], str) and TOKEN.fullmatch(policy[key]) is not None,
                'Invalid package identity')
    require(policy['artifact_scope'] == 'source-integrity-only', 'Unsupported verification scope')
    paths = policy['required_files']
    require(type(paths) is list and 1 <= len(paths) <= MAX_FILES, 'Required file list missing')
    for path in paths:
        safe_relative(path)
    require(len(paths) == len(set(paths)), 'Duplicate required file')
    require({'Cargo.toml', 'README.md', 'src/lib.rs', f'docs/STEP-{step}.md'} <= set(paths),
            'Required identity, source or milestone documentation absent from policy')
    return policy

def check_payload(payload: dict[str, bytes], step: int, version: str) -> dict:
    require(POLICY_NAME in payload, 'Delivery policy missing from payload')
    policy = policy_load(payload[POLICY_NAME], step, version)
    require(len(payload) > 1, 'Empty source package')
    for path in policy['required_files']:
        require(path in payload and bool(payload[path].strip()), 'Required content missing or empty: ' + path)
    try:
        cargo = tomllib.loads(payload['Cargo.toml'].decode('utf-8'))
    except (KeyError, ValueError, UnicodeError) as exc:
        raise DeliveryError('Invalid Cargo.toml') from exc
    require(cargo.get('package', {}).get('name') == policy['package_name'], 'Cargo package name mismatch')
    require(cargo.get('package', {}).get('version') == version,
            'Cargo version mismatch: older code cannot be published as the requested version')
    if 'release-candidate.json' in payload:
        candidate = json_load(payload['release-candidate.json'])
        require(candidate.get('package_version') == version,
                'Release candidate version differs from delivered Cargo source')
        require(type(candidate.get('step')) is int and candidate['step'] == step,
                'Release candidate milestone differs from delivery policy')
    return policy

def snapshot(source: Path) -> dict[str, bytes]:
    no_symlink_components(source)
    require(source.is_dir(), 'Source directory does not exist')
    for entry in source.iterdir():
        if entry.is_dir() and not entry.is_symlink():
            require(entry.name in ROOT_DIRS | OMIT_DIRS,
                    'Unexpected source-root directory; review/remove generated artifacts before packaging: ' + entry.name)
        else:
            require(entry.name in ROOT_FILES or entry.suffix == '.pyc',
                    'Unexpected source-root file; review it before packaging: ' + entry.name)
    result: dict[str, bytes] = {}
    keys: set[str] = set()
    total = 0
    for parent, directories, filenames in os.walk(source, followlinks=False, onerror=walk_error):
        directories[:] = sorted(d for d in directories if d not in OMIT_DIRS)
        for d in directories:
            require(not (Path(parent) / d).is_symlink(), 'Source directory symlink rejected')
        for filename in sorted(filenames):
            path = Path(parent) / filename
            rel = path.relative_to(source).as_posix()
            if rel == MANIFEST_NAME or path.suffix == '.pyc':
                continue
            safe_relative(rel)
            require(path.suffix.lower() not in FORBIDDEN_SUFFIXES, 'Font files must not be distributed')
            key = rel.casefold()
            require(key not in keys, 'Case-insensitive duplicate source path')
            keys.add(key)
            data = read_regular(path)
            total += len(data)
            require(total <= MAX_TOTAL_BYTES and len(result) < MAX_FILES - 1, 'Source package limits exceeded')
            result[rel] = data
    require(bool(result), 'Empty source directory')
    check_namespace(result)
    return result

def manifest(payload: dict[str, bytes]) -> bytes:
    return ''.join(f'{digest(payload[name])}  {name}\n' for name in sorted(payload)).encode('utf-8')

def write_zip(path: Path, payload: dict[str, bytes], root: str) -> None:
    with zipfile.ZipFile(path, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6,
                         allowZip64=False) as z:
        for name in sorted(payload):
            info = zipfile.ZipInfo(root + '/' + name, date_time=(2020, 1, 1, 0, 0, 0))
            info.create_system = 3
            info.external_attr = (stat.S_IFREG | 0o644) << 16
            info.compress_type = zipfile.ZIP_DEFLATED
            z.writestr(info, payload[name], compresslevel=6)
    with path.open('rb') as f:
        os.fsync(f.fileno())

def inspect_archive(path: Path, step: int, version: str, extract: Path | None = None) -> dict:
    """Bounded all-member read validates CRC, then exact SHA manifest and identity."""
    data = read_regular(path, MAX_ARCHIVE_BYTES)
    import io
    payload: dict[str, bytes] = {}
    casekeys: set[str] = set()
    root: str | None = None
    total = 0
    try:
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            infos = z.infolist()
            require(1 < len(infos) <= MAX_FILES, 'Empty or oversized ZIP entry list')
            for info in infos:
                name = safe_relative(info.filename)
                require(info.orig_filename == name, 'Altered/NUL ZIP name')
                require(not info.is_dir(), 'Delivery ZIP contains unexpected directory entry')
                require(not (info.flag_bits & 1), 'Encrypted ZIP is not a supported delivery')
                require(info.compress_type in (zipfile.ZIP_STORED, zipfile.ZIP_DEFLATED),
                        'Non-portable ZIP compression rejected')
                mode = info.external_attr >> 16
                require(stat.S_IFMT(mode) in (0, stat.S_IFREG), 'Special-file or symlink ZIP member')
                require('/' in name, 'Missing package root')
                this_root, rel = name.split('/', 1)
                if root is None:
                    root = this_root
                require(this_root == root, 'Multiple package roots')
                require(name.casefold() not in casekeys, 'Duplicate/case-colliding ZIP member')
                casekeys.add(name.casefold())
                require(PurePosixPath(rel).suffix.lower() not in FORBIDDEN_SUFFIXES,
                        'Font files must not be distributed')
                total += info.file_size
                require(0 <= info.file_size <= MAX_FILE_BYTES and total <= MAX_TOTAL_BYTES,
                        'ZIP expansion limits exceeded')
                with z.open(info) as member:
                    content = member.read(MAX_FILE_BYTES + 1)
                require(len(content) == info.file_size and len(content) <= MAX_FILE_BYTES,
                        'ZIP entry size mismatch')
                payload[rel] = content
    except (zipfile.BadZipFile, RuntimeError, NotImplementedError, EOFError) as exc:
        raise DeliveryError('Unreadable, truncated or corrupt ZIP') from exc
    check_namespace(payload)
    require(MANIFEST_NAME in payload, 'SHA256SUMS missing')
    stored = payload.pop(MANIFEST_NAME)
    require(stored == manifest(payload), 'SHA manifest differs from exact payload: missing, changed or extra content')
    policy = check_payload(payload, step, version)
    require(root == policy['package_name'], 'ZIP root differs from package identity')
    payload[MANIFEST_NAME] = stored
    if extract is not None:
        require(not extract.exists(), 'Extraction destination must be new')
        extract.mkdir(parents=True)
        for rel, content in payload.items():
            target = extract / str(root) / rel
            target.parent.mkdir(parents=True, exist_ok=True)
            with target.open('xb') as f:
                f.write(content)
            require(digest(read_regular(target)) == digest(content), 'Extraction verification failed')
    return {'sha256': digest(data), 'size_bytes': len(data), 'file_count': len(payload),
            'manifest_entries': len(payload)-1, 'package_name': root, 'package_version': version,
            'milestone': step, 'delivery_label': policy['delivery_label'],
            'payload_sha256': digest(stored), 'verification_scope': policy['artifact_scope']}

def publish(source: Path, destination: Path) -> bool:
    """No-clobber, atomic publication on the same filesystem. Returns ownership."""
    try:
        os.link(source, destination)
        return True
    except FileExistsError:
        require(read_regular(destination, MAX_ARCHIVE_BYTES) == read_regular(source, MAX_ARCHIVE_BYTES),
                'Existing artifact conflicts; refusing overwrite')
        return False

def build(source: Path, output: Path, step: int, version: str) -> Path:
    no_symlink_components(source)
    source = source.resolve(strict=True)
    output = Path(os.path.abspath(output))
    no_symlink_components(output)
    require(output != source and source not in output.parents, 'Output must be outside the source tree')
    first = snapshot(source)
    policy = check_payload(first, step, version)
    require(first == snapshot(source), 'Source changed between full scans')
    payload = dict(first)
    payload[MANIFEST_NAME] = manifest(payload)
    require(sum(map(len, payload.values())) <= MAX_TOTAL_BYTES, 'Manifest exceeds total budget')
    output.mkdir(parents=True, exist_ok=True)
    owned: list[Path] = []
    try:
        with tempfile.TemporaryDirectory(prefix='.delivery-', dir=output) as temp:
            stage = Path(temp)
            candidate = stage/'archive.partial'
            write_zip(candidate, payload, policy['package_name'])
            info = inspect_archive(candidate, step, version, stage/'fresh-extraction')
            require(first == snapshot(source), 'Source changed during packaging')
            stem = (f"{policy['package_name']}-step-{step}-{policy['delivery_label']}-"
                    f"v{version}-{info['sha256'][:16]}")
            archive = output/(stem+'.zip')
            checksum = output/(stem+'.zip.sha256')
            receipt = output/(stem+'.delivery.json')
            checksum_bytes = f"{info['sha256']}  {archive.name}\n".encode()
            (stage/'checksum').write_bytes(checksum_bytes)
            for a, b in ((candidate, archive), (stage/'checksum', checksum)):
                if publish(a, b):
                    owned.append(b)
            require(inspect_archive(archive, step, version) == info, 'Published ZIP failed recheck')
            record = {'format_version': 1, 'status': 'verified',
                      'verified_at_utc': datetime.now(timezone.utc).isoformat(),
                      'archive': archive.name, 'checksum_file': checksum.name, 'archive_info': info,
                      'checks': VERIFICATION_CHECKS,
                      'application_tests': 'not_run_by_packager',
                      'browser_download_test': 'not_available_from_local_tools'}
            # A matching immutable receipt is reusable. Its contents are rechecked.
            if receipt.exists():
                verify(receipt, step, version)
            else:
                (stage/'receipt').write_text(json.dumps(record, indent=2)+'\n', encoding='utf-8')
                if publish(stage/'receipt', receipt):
                    owned.append(receipt)
            verify(receipt, step, version)
            return receipt
    except BaseException:
        for path in reversed(owned):
            try:
                path.unlink()
            except OSError:
                pass
        raise

def verify(receipt: Path, step: int, version: str) -> dict:
    record = json_load(read_regular(receipt, MAX_JSON_BYTES))
    require(set(record) == RECEIPT_FIELDS, 'Unexpected or missing receipt fields')
    require(record.get('application_tests') == 'not_run_by_packager',
            'Receipt cannot certify application tests')
    require(record.get('browser_download_test') == 'not_available_from_local_tools',
            'Receipt cannot certify browser downloads')
    require(record.get('checks') == VERIFICATION_CHECKS, 'Unexpected verification scope')
    try:
        timestamp = datetime.fromisoformat(record.get('verified_at_utc', ''))
    except (ValueError, TypeError) as exc:
        raise DeliveryError('Invalid verification timestamp') from exc
    require(timestamp.tzinfo is not None and timestamp <= datetime.now(timezone.utc),
            'Missing timezone or future verification timestamp')
    require(type(record.get('format_version')) is int and record['format_version'] == 1,
            'Unsupported receipt format')
    require(record.get('status') == 'verified' and type(record.get('archive_info')) is dict,
            'Receipt is not a verified-delivery record')
    for field in ('archive', 'checksum_file'):
        name = safe_relative(record.get(field, ''))
        require('/' not in name, 'Receipt artifact must be an adjacent basename')
    info = inspect_archive(receipt.parent/record['archive'], step, version)
    require(info == record['archive_info'], 'Receipt is stale or mismatched')
    expected = f"{info['sha256']}  {record['archive']}\n".encode()
    require(read_regular(receipt.parent/record['checksum_file'], MAX_JSON_BYTES) == expected,
            'Archive checksum sidecar mismatch')
    return record

def links(receipt: Path, step: int, version: str, sandbox_root: Path = Path('/mnt/data')) -> str:
    record = verify(receipt, step, version)
    base = sandbox_root.resolve(strict=True)
    files = [(f"Step {step} source — {version} ({record['archive_info']['delivery_label']})",
              receipt.parent/record['archive']), ('SHA-256 checksum', receipt.parent/record['checksum_file']),
             ('Verified delivery receipt', receipt)]
    output = []
    for label, path in files:
        absolute = path.resolve(strict=True)
        require(absolute != base and base in absolute.parents, 'Artifact is outside the sandbox root')
        # URI only for verified adjacent files. No wildcard search and no guessed paths.
        from urllib.parse import quote
        output.append(f'[{label}](sandbox:{quote(absolute.as_posix(), safe="/")})')
    return '\n\n'.join(output)+'\n'

def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    subs = parser.add_subparsers(dest='command', required=True)
    for command in ('build', 'verify', 'links'):
        p = subs.add_parser(command)
        p.add_argument('--expected-step', required=True, type=int)
        p.add_argument('--expected-version', required=True)
        if command == 'build':
            p.add_argument('--source', required=True, type=Path)
            p.add_argument('--output-dir', required=True, type=Path)
        else:
            p.add_argument('--receipt', required=True, type=Path)
    args = parser.parse_args(argv)
    try:
        if args.command == 'build':
            receipt = build(args.source, args.output_dir, args.expected_step, args.expected_version)
            print(json.dumps({'status': 'verified', 'receipt': str(receipt)}))
        elif args.command == 'verify':
            print(json.dumps(verify(args.receipt, args.expected_step, args.expected_version), indent=2))
        else:
            print(links(args.receipt, args.expected_step, args.expected_version), end='')
        return 0
    except (DeliveryError, OSError, ValueError, OverflowError) as exc:
        print('DELIVERY FAILED: ' + str(exc), file=sys.stderr)
        return 1

if __name__ == '__main__':
    raise SystemExit(main())
