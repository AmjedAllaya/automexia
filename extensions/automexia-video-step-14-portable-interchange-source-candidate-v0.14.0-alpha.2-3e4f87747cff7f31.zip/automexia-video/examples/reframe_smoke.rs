//! Provider-side integration example, not a new installed CLI/extension loader.
//! cargo run --features native --example reframe_smoke -- INPUT.mp4 PROJECT.amxv OUTPUT_DIR
use automexia_video::*;
use automexia_video::native::{NativeMediaHost,NativeSettings};
use automexia_video::progress::Progress;
use std::path::PathBuf;
fn main()->std::result::Result<(),Box<dyn std::error::Error>>{
    let args=std::env::args_os().skip(1).collect::<Vec<_>>();
    if args.len()!=3{return Err("expected INPUT PROJECT OUTPUT_DIRECTORY".into());}
    let input=PathBuf::from(&args[0]);let project_file=PathBuf::from(&args[1]);let output=PathBuf::from(&args[2]);
    if !output.is_dir(){return Err("output directory must already exist".into());}
    let ffmpeg=std::env::var_os("FFMPEG").map(PathBuf::from).ok_or("set FFMPEG to an approved executable")?;
    let ffprobe=std::env::var_os("FFPROBE").map(PathBuf::from).ok_or("set FFPROBE to an approved executable")?;
    let extension=VideoExtension::new(NativeMediaHost::new(NativeSettings::new(ffmpeg,ffprobe))?,VideoSettings::default())?;
    let cancel=Cancellation::new();let mut progress=|event:Progress|{eprintln!("{:?} {:?}",event.stage,event.out_time_us);};
    let mut project=extension.create_project(&NewProjectRequest::new("framing-example",&input,&project_file),&cancel,&mut progress)?;
    for (id,preset) in [("youtube",TargetPreset::YouTube),("portrait",TargetPreset::Reel),("square",TargetPreset::Square)]{
        let settings=FramingSettings::preset(preset,&project.sources[0])?;
        project.add_output_variant(id,project.variants[0].render.clone(),Some(settings))?;
        // A real UI would request review first. This example deliberately opts
        // into default Fit compositions, not automatic content-discarding crops.
        project.decide_framing(id,FramingDecision::Approve)?;
    }
    extension.save_project(&project,&project_file,&OutputPolicy::CreateNew,&cancel)?;
    for id in ["youtube","portrait","square"]{
        let mut request=ProjectRenderRequest::new(&project_file,output.join(format!("{id}.mp4")));request.variant=id.into();
        let result=extension.render_project(&project,&request,&cancel,&mut progress)?;
        eprintln!("{id}: validated {} seconds",result.timeline.duration);
    }
    Ok(())
}
