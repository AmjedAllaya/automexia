//! Deliberate short assembly demonstration using the real native workflow.
//! Plays a later source clip, then an earlier clip at half speed, then repeats
//! the later clip at double speed. Each source clip spans an even number of
//! frames covering at least one second, so retimed audio exceeds the minimum
//! supported duration. Invoking this example approves those demo choices.
//! cargo run --features native --example assembly_smoke -- INPUT PROJECT.amxv OUTPUT.mp4 FFMPEG FFPROBE
use automexia_video::*;
use automexia_video::native::{NativeMediaHost,NativeSettings};
use automexia_video::project::TimeRange;
use std::{env,path::{Path,PathBuf}};
fn absolute(path:&Path)->std::io::Result<PathBuf>{
    let path=if path.is_absolute(){path.to_owned()}else{env::current_dir()?.join(path)};
    Ok(path.parent().ok_or(std::io::ErrorKind::InvalidInput)?.canonicalize()?.join(path.file_name().ok_or(std::io::ErrorKind::InvalidInput)?))
}
fn main()->std::result::Result<(),Box<dyn std::error::Error>>{
    let args:Vec<_>=env::args_os().skip(1).map(PathBuf::from).collect();
    if args.len()!=5{eprintln!("Usage: assembly_smoke INPUT PROJECT.amxv OUTPUT.mp4 FFMPEG FFPROBE");std::process::exit(2);}
    let input=absolute(&args[0])?;let project_file=absolute(&args[1])?;let output=absolute(&args[2])?;
    let extension=VideoExtension::new(NativeMediaHost::new(NativeSettings::new(absolute(&args[3])?,absolute(&args[4])?))?,VideoSettings::default())?;
    let cancel=Cancellation::new();let mut progress=|event:automexia_video::progress::Progress|eprintln!("{:?} {:?}",event.stage,event.out_time_us);
    let mut project=extension.create_project(&NewProjectRequest::new("assembly-example",input,&project_file),&cancel,&mut progress)?;
    let source=&project.sources[0];let fps=source.media.video.nominal_frame_rate.or(source.media.video.average_frame_rate).ok_or(Error::Unsupported("assembly demo needs a known frame rate"))?;
    let frame=Rational::new(1,1)?.checked_div(fps)?;
    let clip_frames=fps.checked_div(Rational::new(2,1)?)?.ceil_units(1)?.checked_mul(2).ok_or(Error::InvalidInput("assembly demo frame count overflow"))?;
    let later_start=clip_frames.checked_mul(2).ok_or(Error::InvalidInput("assembly demo frame count overflow"))?;
    let later_end=clip_frames.checked_mul(3).ok_or(Error::InvalidInput("assembly demo frame count overflow"))?;
    if source.duration<frame.ticks(later_end)?{return Err(Error::InvalidInput("assembly demo needs three complete even-frame clips of at least one second each").into());}
    let clip=|id:&str,start:i64,end:i64,speed|->Result<AssemblyClip>{Ok(AssemblyClip{id:id.into(),range:TimeRange::new(frame.ticks(start)?,frame.ticks(end)?)?,speed})};
    project.set_assembly("main",Some(AssemblySettings{clips:vec![
        clip("later",later_start,later_end,PlaybackSpeed::Normal)?,clip("earlier-slow",0,clip_frames,PlaybackSpeed::Half)?,clip("repeat-fast",later_start,later_end,PlaybackSpeed::Double)?,
    ],..Default::default()}))?;
    println!("{}",serde_json::to_string_pretty(&extension.dry_run(&project)?)?);
    project.review_assembly("main",Disposition::AutoApply,true)?;
    extension.no_render(&project,&project_file,&OutputPolicy::CreateNew,&cancel)?;
    let mut loaded=extension.load_project(&project_file,&cancel)?;
    let result=extension.render_project(&loaded.project,&ProjectRenderRequest::new(&project_file,output),&cancel,&mut progress)?;
    loaded.project.record_render(result.history())?;
    extension.save_project(&loaded.project,&project_file,&OutputPolicy::ReplaceReviewed(loaded.stamp),&cancel)?;
    println!("{}",serde_json::to_string_pretty(&result)?);Ok(())
}
