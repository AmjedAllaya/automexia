//! Integration example, not another end-user application or scheduler.
use automexia_video::*;
use automexia_video::native::{NativeMediaHost,NativeSettings};
use std::{path::PathBuf,time::Duration};
fn main()->std::result::Result<(),Box<dyn std::error::Error>>{
    let mut args=std::env::args_os().skip(1);
    let input=PathBuf::from(args.next().ok_or("supply an explicitly selected media file")?).canonicalize()?;
    let project_file=PathBuf::from(args.next().ok_or("supply absolute intended .amxv location")?);
    if args.next().is_some(){return Err("unexpected argument".into());}
    let ffmpeg=PathBuf::from(std::env::var_os("FFMPEG").ok_or("set FFMPEG")?);
    let ffprobe=PathBuf::from(std::env::var_os("FFPROBE").ok_or("set FFPROBE")?);
    let video=VideoExtension::new(NativeMediaHost::new(NativeSettings::new(ffmpeg,ffprobe))?,VideoSettings::default())?;
    let cancel=Cancellation::new();let (sender,receiver)=progress_mailbox(cancel.clone())?;
    let mut progress=|event|{let _=sender.publish(event);};
    let project=video.create_project(&NewProjectRequest::new("cache-demo",input,&project_file),&cancel,&mut progress)?;
    let mut cache=video.observation_cache(CacheLimits::default())?;
    let request=PauseAnalysisRequest::new(project_file);
    let first=video.analyze_pauses_cached(&project,&request,&mut cache,&cancel,&mut progress)?;
    let repeated=video.analyze_pauses_cached(&project,&request,&mut cache,&cancel,&mut progress)?;
    println!("first={:?}, repeat={:?}, candidates={}, stats={:?}",first.cache,repeated.cache,repeated.report.candidates().len(),cache.stats());
    let _last=receiver.take()?;
    // No apply/save/render above. After explicit user review, use existing APIs.
    let drained=video.disable_and_drain(Duration::from_secs(5))?;
    if !drained.complete{return Err("host must finish remaining work before unloading".into());}
    drop(cache);drop(receiver);
    Ok(())
}
