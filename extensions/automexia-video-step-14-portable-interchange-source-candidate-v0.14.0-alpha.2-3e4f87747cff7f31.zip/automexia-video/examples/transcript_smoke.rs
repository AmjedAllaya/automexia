//! Actual selected-model qualification. Missing assets are errors, never skips.
//! This explicitly invoked example creates one new output directory containing
//! the editable project, generated subtitles and a provenance/metrics record.
use automexia_video::*;
use automexia_video::native::{NativeMediaHost,NativeSettings};
use automexia_video::whisper_cpp::{read_selected_pack,WhisperCppProvider};
use std::{path::PathBuf,fs,time::{Duration,Instant}};
fn path(name:&str)->std::result::Result<PathBuf,Box<dyn std::error::Error>> {
    Ok(PathBuf::from(std::env::var_os(name).ok_or_else(||format!("set {name}"))?))
}
fn main()->std::result::Result<(),Box<dyn std::error::Error>> {
    let cancel=Cancellation::new();let started=Instant::now();
    let pack=read_selected_pack(&path("AMXV_WHISPER_MANIFEST")?,&path("AMXV_WHISPER_WEIGHTS")?,
        &path("AMXV_WHISPER_NOTICES")?,&std::env::var("AMXV_WHISPER_MANIFEST_SHA256")?,&cancel)?;
    let output=path("AMXV_TRANSCRIPT_OUTPUT")?;
    if !output.is_absolute()||output.exists(){return Err("select an absolute, nonexistent AMXV_TRANSCRIPT_OUTPUT directory".into());}
    let parent=output.parent().ok_or("output directory parent")?.canonicalize()?;
    if output.parent()!=Some(parent.as_path()){return Err("output parent must be canonical".into());}
    let model=pack.identity().clone();let activation=ModelActivation::selected(model.clone())?;
    let provider=WhisperCppProvider::new(pack,path("AMXV_WHISPER_EXECUTABLE")?.canonicalize()?,
        path("AMXV_WHISPER_BUILD_INFO")?.canonicalize()?,parent.clone())?;
    let video=VideoExtension::new(NativeMediaHost::new(NativeSettings::new(path("AMXV_FFMPEG")?,path("AMXV_FFPROBE")?))?,VideoSettings::default())?;
    let project_file=output.join("transcript.amxv");
    let mut project=video.create_project(&NewProjectRequest::new("transcript-smoke",path("AMXV_TRANSCRIPT_INPUT")?.canonicalize()?,&project_file),&cancel,&mut |_|{})?;
    let mut request=TranscriptRequest::new(&project_file);
    if let Ok(language)=std::env::var("AMXV_TRANSCRIPT_LANGUAGE"){request.settings.language=language;}
    if let Ok(channel)=std::env::var("AMXV_TRANSCRIPT_CHANNEL"){request.settings.analysis_channel=channel.parse()?;}
    let report=video.transcribe(&project,&request,&provider,&activation,&cancel,&mut |_|{})?;
    report.apply(&mut project)?;
    let transcript=project.transcript.as_ref().ok_or("transcript was not installed")?;
    let words=transcript.words().len();
    if words==0{return Err("selected real-recording smoke requires a nonempty transcription".into());}
    let subtitles=transcript.subtitles_for_project(&project,SubtitleFormat::WebVtt)?;
    let bytes=project.to_json()?;
    if Project::from_json(&bytes)?.to_json()?!=bytes{return Err("transcript project roundtrip differs".into());}
    let metrics=serde_json::json!({"kind":"actual-selected-whisper-cpp-cpu-execution","model":model,
        "words":words,"sentences":transcript.sentences()?.len(),"source_seconds":project.sources[0].duration.as_f64(),
        "elapsed_seconds":started.elapsed().as_secs_f64(),"provenance":transcript.provenance(),
        "project_roundtrip":true,"subtitle_bytes":subtitles.len(),"quality_qualified":false});
    // Compute everything before creating output; never replace an existing file.
    fs::create_dir(&output)?;
    for (name,data) in [("transcript.amxv",bytes),("transcript.vtt",subtitles),("transcript.json",serde_json::to_vec_pretty(&metrics)?)] {
        use std::io::Write;
        let mut file=fs::OpenOptions::new().write(true).create_new(true).open(output.join(name))?;
        file.write_all(&data)?;file.sync_all()?;
    }
    activation.revoke();drop(provider);
    if !video.disable_and_drain(Duration::from_secs(5))?.complete{return Err("native operation still active".into());}
    println!("{}",serde_json::to_string_pretty(&metrics)?);Ok(())
}
