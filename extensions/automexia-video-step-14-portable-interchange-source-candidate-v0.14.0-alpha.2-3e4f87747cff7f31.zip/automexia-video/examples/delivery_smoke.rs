//! Integration example for the existing host worker, not a second product CLI.
//! Pass a selected source and an EXISTING output directory. No automatic overwrite.
//! Encoders must exist in the approved FFMPEG runtime. JSON events go to stderr;
//! final structured receipt goes to stdout. This example performs no AI/analysis.
use automexia_video::*;
use automexia_video::native::{NativeMediaHost,NativeSettings};
use std::path::PathBuf;
fn main()->std::result::Result<(),Box<dyn std::error::Error>>{
    let mut args=std::env::args_os().skip(1);
    let input=std::fs::canonicalize(args.next().ok_or("supply selected input and output directory")?)?;
    let directory=std::fs::canonicalize(args.next().ok_or("supply existing output directory")?)?;
    if args.next().is_some()||!directory.is_dir(){return Err("unexpected arguments or non-directory output".into());}
    let host=NativeMediaHost::new(NativeSettings::new(PathBuf::from(std::env::var_os("FFMPEG").ok_or("set FFMPEG to approved executable")?),PathBuf::from(std::env::var_os("FFPROBE").ok_or("set FFPROBE")?)))?;
    let video=VideoExtension::new(host,VideoSettings::default())?;let cancel=Cancellation::new();
    let project_file=directory.join("delivery.amxv");
    let mut project=video.create_project(&NewProjectRequest::new("delivery-example",&input,&project_file),&cancel,&mut |_|{})?;
    let snapshot=resolve_workflow(None,None,None,None)?;snapshot.apply(&mut project,"main")?;
    let mut web=project.variants[0].clone();web.id="web".into();web.output_profile=Some(DeliveryProfile::preset(RenderIntent::Publish,Some(DeliveryFormat::Vp9Webm)));
    let mut master=project.variants[0].clone();master.id="master".into();master.output_profile=Some(DeliveryProfile::preset(RenderIntent::Master,None));
    project.edit(|p|{p.variants.push(web);p.variants.push(master);Ok(())})?;
    video.save_project(&project,&project_file,&OutputPolicy::CreateNew,&cancel)?;
    let request=DeliveryRequest{project_file,targets:vec![
        DeliveryTarget::new("publish","main",directory.join("publish.mp4")),
        DeliveryTarget::new("web","web",directory.join("web.webm")),
        DeliveryTarget::new("master","master",directory.join("master.mov"))],fail_fast:false};
    let result=video.render_targets(&project,&request,&cancel,&mut |event|{
        if let Ok(line)=event.json_line(){use std::io::Write;let _=std::io::stderr().write_all(&line);}
    })?;
    use std::io::Write;std::io::stdout().write_all(&result.to_json()?)?;
    if !result.complete(){return Err("one or more targets failed; preserve the JSON receipt for a reviewed retry".into());}
    Ok(())
}
