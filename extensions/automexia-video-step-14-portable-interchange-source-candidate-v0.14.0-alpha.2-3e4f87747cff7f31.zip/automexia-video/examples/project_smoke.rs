//! Demonstrates the actual core API; not a separate video-editor product.
//! cargo run --features native --example project_smoke -- INPUT PROJECT.amxv OUTPUT.mp4 FFMPEG FFPROBE
use automexia_video::*;
use automexia_video::native::{NativeMediaHost,NativeSettings};
use std::{env,path::{Path,PathBuf}};
fn absolute(path:&Path)->std::io::Result<PathBuf>{
    let p=if path.is_absolute(){path.to_owned()}else{env::current_dir()?.join(path)};
    Ok(p.parent().ok_or(std::io::ErrorKind::InvalidInput)?.canonicalize()?.join(p.file_name().ok_or(std::io::ErrorKind::InvalidInput)?))
}
fn main()->std::result::Result<(),Box<dyn std::error::Error>>{
    let a:Vec<_>=env::args_os().skip(1).map(PathBuf::from).collect();
    if a.len()!=5{eprintln!("Usage: project_smoke INPUT PROJECT.amxv OUTPUT.mp4 FFMPEG FFPROBE");std::process::exit(2);}
    let path=absolute(&a[1])?;let output=absolute(&a[2])?;
    let x=VideoExtension::new(NativeMediaHost::new(NativeSettings::new(absolute(&a[3])?,absolute(&a[4])?))?,VideoSettings::default())?;
    let c=Cancellation::new();let mut log=|p:automexia_video::progress::Progress|eprintln!("{:?} {:?}",p.stage,p.out_time_us);
    let mut project=x.create_project(&NewProjectRequest::new("example-project",&a[0],&path),&c,&mut log)?;
    let third=project.sources[0].duration.checked_div(Rational::new(3,1)?)?;
    project.remove_range("source-1",TimeRange::new(third,third.checked_add(third)?)?,"Explicit example: remove the middle third")?;
    let preparation=x.no_render(&project,&path,&OutputPolicy::CreateNew,&c)?;
    println!("{}",serde_json::to_string_pretty(&preparation)?);
    let mut loaded=x.load_project(&path,&c)?;
    let rendered=x.render_project(&loaded.project,&ProjectRenderRequest::new(&path,&output),&c,&mut log)?;
    loaded.project.record_render(rendered.history())?;
    x.save_project(&loaded.project,&path,&OutputPolicy::ReplaceReviewed(loaded.stamp),&c)?;
    println!("{}",serde_json::to_string_pretty(&rendered)?);Ok(())
}
