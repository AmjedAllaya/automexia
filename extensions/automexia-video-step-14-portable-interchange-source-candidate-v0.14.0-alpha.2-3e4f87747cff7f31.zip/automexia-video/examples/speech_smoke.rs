//! Host-integration example. Explicit selected media/model/runtime files only.
//! It prints a proposal report; it never approves, saves, edits or renders media.
//! Must run in the trusted provider process before any other ort initialization.
use automexia_video::*;
use automexia_video::native::{NativeMediaHost,NativeSettings};
use automexia_video::silero_onnx::{read_selected_pack,SileroCpuProvider};
use std::{path::PathBuf,time::Duration};
fn env_path(name:&str)->std::result::Result<PathBuf,Box<dyn std::error::Error>>{
 Ok(PathBuf::from(std::env::var_os(name).ok_or_else(||format!("set {name}"))?))
}
fn main()->std::result::Result<(),Box<dyn std::error::Error>>{
 let mut args=std::env::args_os().skip(1);
 let input=PathBuf::from(args.next().ok_or("supply the selected media file")?).canonicalize()?;
 let project_path=PathBuf::from(args.next().ok_or("supply the intended absolute .amxv location")?);
 if !project_path.is_absolute()||args.next().is_some(){return Err("expected two arguments and an absolute project location".into());}
 let cancel=Cancellation::new();
 let pack=read_selected_pack(&env_path("VIDEO_MODEL_MANIFEST")?,&env_path("VIDEO_MODEL_WEIGHTS")?,
  &env_path("VIDEO_MODEL_NOTICES")?,&std::env::var("VIDEO_MODEL_MANIFEST_SHA256")?,&cancel)?;
 let activation=ModelActivation::selected(pack.identity().clone())?;
 let provider=SileroCpuProvider::new(pack,env_path("VIDEO_ORT_LIBRARY")?,Duration::from_secs(5))?;
 let video=VideoExtension::new(NativeMediaHost::new(NativeSettings::new(env_path("FFMPEG")?,env_path("FFPROBE")?))?,VideoSettings::default())?;
 let project=video.create_project(&NewProjectRequest::new("speech-review",input,&project_path),&cancel,&mut |_|{})?;
 let mut request=SpeechPauseRequest::new(project_path);
 // Do not manufacture a dialogue or music-removal declaration. Unknown content
 // remains conservative. The host can supply reviewed content/settings explicitly.
 if let Ok(channel)=std::env::var("VIDEO_ANALYSIS_CHANNEL"){request.speech.analysis_channel=channel.parse()?;}
 let report=video.analyze_speech_pauses(&project,&request,&provider,&activation,&cancel,&mut |_|{})?;
 println!("{}",serde_json::to_string_pretty(&report)?);
 // report.apply(&mut project) adds NeedsReview operations ONLY after host consent.
 // Accepted decisions subsequently render without a model installed. No apply here.
 activation.revoke();drop(provider);
 if !video.disable_and_drain(Duration::from_secs(5))?.complete{return Err("finish native work before unloading".into());}
 Ok(())
}
