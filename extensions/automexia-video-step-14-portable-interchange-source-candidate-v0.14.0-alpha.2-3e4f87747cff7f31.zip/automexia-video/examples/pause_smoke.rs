//! Integration smoke example; not a new end-user CLI or host loader.
//! cargo run --features native --example pause_smoke -- /path/input.mp4 /path/draft.amxv
//! Optional third argument --approve-for-fixture renders a TEST FIXTURE only.
use automexia_video::*;
use automexia_video::native::{NativeMediaHost,NativeSettings};
use std::path::PathBuf;
fn main()->Result<()> {
    let args:Vec<_>=std::env::args_os().skip(1).collect();
    if args.len()<2||args.len()>3{return Err(Error::InvalidInput("supply input and absolute .amxv path; optional fixture approval"));}
    if args.len()==3 && args[2]!="--approve-for-fixture"{return Err(Error::InvalidInput("unknown fixture option"));}
    let input=std::fs::canonicalize(PathBuf::from(&args[0])).map_err(|_|Error::Io("resolve example input"))?;
    let project_path=PathBuf::from(&args[1]);
    let ffmpeg=std::env::var_os("FFMPEG").map(PathBuf::from).unwrap_or_else(||"/usr/bin/ffmpeg".into());
    let ffprobe=std::env::var_os("FFPROBE").map(PathBuf::from).unwrap_or_else(||"/usr/bin/ffprobe".into());
    let core=VideoExtension::new(NativeMediaHost::new(NativeSettings::new(ffmpeg,ffprobe))?,VideoSettings::default())?;
    let cancel=Cancellation::new();
    let mut project=core.create_project(&NewProjectRequest::new("pause-example",&input,&project_path),&cancel,&mut |_|{})?;
    let report=core.analyze_pauses(&project,&PauseAnalysisRequest::new(&project_path),&cancel,&mut |_|{})?;
    println!("{} proposed cuts; duration {} -> {}. Each new proposal requires review.",report.candidates().len(),report.accepted_duration(),report.proposed_duration());
    report.apply(&mut project)?;
    if args.len()==3 {
        // Only for generated test footage, never automatic product approval.
        let ids:Vec<_>=report.candidates().iter().map(|c|c.operation.id.clone()).collect();
        for id in ids{project.review_operation(&id,Disposition::AutoApply,true)?;}
    }
    core.save_project(&project,&project_path,&OutputPolicy::CreateNew,&cancel)?;
    if args.len()==3 {
        core.render_project(&project,&ProjectRenderRequest::new(&project_path,project_path.with_extension("mp4")),&cancel,&mut |_|{})?;
    }
    Ok(())
}
