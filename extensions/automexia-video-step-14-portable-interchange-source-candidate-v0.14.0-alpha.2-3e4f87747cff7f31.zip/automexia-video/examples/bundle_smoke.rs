//! Explicit portable handoff from a saved, reviewed project. No edit is approved
//! by this example. Optional bake arguments select work inside the bundle lease.
use automexia_video::*;
use automexia_video::native::{NativeMediaHost,NativeSettings};
use std::path::{Path,PathBuf};
fn output(path:&Path)->Result<PathBuf>{
    let path=if path.is_absolute(){path.to_owned()}else{std::env::current_dir().map_err(|_|Error::Io("current directory"))?.join(path)};
    let parent=std::fs::canonicalize(path.parent().ok_or(Error::InvalidInput("bundle parent"))?).map_err(|_|Error::Io("select bundle parent"))?;
    Ok(parent.join(path.file_name().ok_or(Error::InvalidInput("bundle filename"))?))
}
fn main()->Result<()> {
    let args:Vec<_>=std::env::args_os().skip(1).collect();
    if args.len()!=6{return Err(Error::InvalidInput("usage: bundle_smoke PROJECT.amxv OUTPUT.zip otio|fcpxml RATE source|bake source|stem|omit"));}
    let project_file=std::fs::canonicalize(&args[0]).map_err(|_|Error::Io("select project"))?;
    let destination=output(Path::new(&args[1]))?;
    let format=match args[2].to_str(){Some("otio")=>InterchangeFormat::Otio,Some("fcpxml")=>InterchangeFormat::FcpXml,_=>return Err(Error::InvalidInput("portable interchange format"))};
    let rate=EditRate::new(args[3].to_str().ok_or(Error::InvalidInput("frame rate UTF-8"))?.parse()?,false)?;
    let mut request=BundleRequest::new(&project_file,destination,format,rate);
    request.video=match args[4].to_str(){Some("source")=>BundleVideo::Source,Some("bake")=>BundleVideo::Bake,_=>return Err(Error::InvalidInput("bundle visual mode"))};
    request.audio=match args[5].to_str(){Some("source")=>BundleAudio::Source,Some("stem")=>BundleAudio::BakeStem,Some("omit")=>BundleAudio::Omit,_=>return Err(Error::InvalidInput("bundle audio mode"))};
    if format==InterchangeFormat::FcpXml{request.target=TargetEditor::FinalCutPro;}
    let ffmpeg=std::env::var_os("FFMPEG").map(PathBuf::from).ok_or(Error::MissingCapability("FFMPEG approved absolute path"))?;
    let ffprobe=std::env::var_os("FFPROBE").map(PathBuf::from).ok_or(Error::MissingCapability("FFPROBE approved absolute path"))?;
    let extension=VideoExtension::new(NativeMediaHost::new(NativeSettings::new(ffmpeg,ffprobe))?,VideoSettings::default())?;
    let cancel=Cancellation::new();let project=extension.load_project(&project_file,&cancel)?;
    let assessment=assess_bundle(&project.project,&request)?;
    println!("{}",String::from_utf8(assessment.to_json()?).map_err(|_|Error::InvalidOutput("assessment UTF-8"))?);
    if assessment.blocked(){std::process::exit(2);}
    let result=extension.export_bundle(&project.project,&request,&cancel,&mut |event|eprintln!("{:?}",event.stage))?;
    println!("{}",String::from_utf8(result.to_json()?).map_err(|_|Error::InvalidOutput("bundle result UTF-8"))?);
    if result.exit_code()!=0{std::process::exit(result.exit_code());}Ok(())
}
