//! Privileged setup: loads an explicitly approved native ONNX Runtime library.
//! Run as the first ort user in the existing isolated provider process.
use automexia_video::{Cancellation,silero_onnx::initialize_selected_runtime};
use std::path::PathBuf;
fn main()->std::result::Result<(),Box<dyn std::error::Error>>{
 let mut args=std::env::args();args.next();
 let path=PathBuf::from(args.next().ok_or("supply canonical approved ONNX Runtime library path")?);
 let hash=args.next().ok_or("supply reviewed SHA-256 of that library")?;
 if args.next().is_some(){return Err("unexpected argument".into());}
 println!("{}",initialize_selected_runtime(&path,&hash,&Cancellation::new())?);Ok(())
}
