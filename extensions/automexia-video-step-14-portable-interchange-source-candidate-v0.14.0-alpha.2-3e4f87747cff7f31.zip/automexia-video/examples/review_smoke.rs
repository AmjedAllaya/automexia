//! Developer integration example, not a replacement video application or GUI.
//! cargo run --features native --example review_smoke -- INPUT.mp4 EXISTING_DIR
//! Creates a *synthetic* cut proposal, real A/B media, a reviewed project and a
//! final render. Output paths must not already exist. No model/detector is run.
use automexia_video::*;
use automexia_video::native::{NativeMediaHost,NativeSettings};
use automexia_video::preview::{PreviewOpener,VerifiedPreview};
use std::{fs::{File,OpenOptions},io,path::PathBuf};

struct CopyForDemo {destination:PathBuf}
impl PreviewOpener for CopyForDemo {
    fn open(&mut self,p:&VerifiedPreview<'_>)->Result<()> {
        // Explicit example-only archival copy, not an invented OS player. A real
        // Automexia adapter passes this validated file to its approved opener.
        let mut src=File::open(&p.file().canonical_path).map_err(|_|Error::Io("open verified demo proxy"))?;
        let mut dst=OpenOptions::new().write(true).create_new(true).open(&self.destination)
            .map_err(|_|Error::Io("create new demonstration copy"))?;
        let result=io::copy(&mut src,&mut dst).and_then(|_|dst.sync_all());
        if result.is_err() {
            drop(dst);
            let _ = std::fs::remove_file(&self.destination);
            return Err(Error::Io("copy demonstration proxy"));
        }
        Ok(())
    }
}
fn main()->std::result::Result<(),Box<dyn std::error::Error>> {
    let args:Vec<_>=std::env::args_os().collect();
    if args.len()!=3 {return Err("usage: review_smoke INPUT.mp4 EXISTING_OUTPUT_DIRECTORY".into());}
    let input=std::fs::canonicalize(&args[1])?;
    let dir=std::fs::canonicalize(&args[2])?;
    if !dir.is_dir(){return Err("output must be an existing directory".into());}
    let tool=|key:&str,default:&str|std::env::var_os(key).map(PathBuf::from).unwrap_or_else(||PathBuf::from(default));
    let host=NativeMediaHost::new(NativeSettings::new(tool("FFMPEG","/usr/bin/ffmpeg"),tool("FFPROBE","/usr/bin/ffprobe")))?;
    let video=VideoExtension::new(host,VideoSettings::default())?;
    let cancel=Cancellation::new();let project_file=dir.join("reviewed.amxv");
    let mut p=video.create_project(&NewProjectRequest::new("review-demo",input,&project_file),&cancel,&mut |_|{})?;
    if p.sources[0].duration < "2".parse()? {return Err("example requires at least two seconds".into());}
    p.add_operation(EditOperation{id:"demo-cut".into(),source_id:"source-1".into(),kind:EditKind::RemoveRange,
        range:TimeRange::new("1/2".parse()?,"3/2".parse()?)?,
        reason:"Explicit demonstration proposal, not automatically detected silence".into(),
        origin:EditOrigin::Generator{id:"example".into(),version:"1".into()},disposition:Disposition::NeedsReview,
        enabled:true,locked:false,user_override:false})?;
    let mut review=video.review_project(&p)?;
    let view=review.snapshot()?;
    let view=review.dispatch(&view.token,ReviewCommand::Select(ReviewTarget::Operation("demo-cut".into())))?;
    let view=review.dispatch(&view.token,ReviewCommand::Inspect)?;
    println!("{}",serde_json::to_string_pretty(&view)?);
    let request=PreviewRequest::new(review.project(),&project_file,&dir,review.selected_target(&view.token)?)?;
    let ticket=review.begin_preview(&view.token,&request)?;
    let previews=video.preview_edit(review.project(),&request,&ticket.cancellation(),&mut |_|{})?;
    review.accept_preview(&ticket,&previews)?;
    video.open_preview(&previews,review.project(),PreviewSide::Before,&mut CopyForDemo{destination:dir.join("before-review.mp4")},&cancel)?;
    if previews.metadata(PreviewSide::Proposed).is_some() {
        video.open_preview(&previews,review.project(),PreviewSide::Proposed,&mut CopyForDemo{destination:dir.join("proposed-review.mp4")},&cancel)?;
    }
    // Here the demonstration deliberately chooses approve and lock. An actual
    // UI waits for the user's corresponding typed review action.
    let view=review.dispatch(&view.token,ReviewCommand::Approve)?;
    review.dispatch(&view.token,ReviewCommand::SetLocked(true))?;
    assert!(previews.check_current(review.project()).is_err());
    drop(previews); // Remove the original private proxy files; demo copies remain.
    video.save_project(review.project(),&project_file,&OutputPolicy::CreateNew,&cancel)?;
    let saved_binding=review.binding()?;
    review.mark_saved(&saved_binding)?;
    video.render_project(review.project(),&ProjectRenderRequest::new(&project_file,dir.join("reviewed-final.mp4")),&cancel,&mut |_|{})?;
    println!("Saved explicit reviewed decisions and rendered them; no AI or hidden activation was used.");
    Ok(())
}
