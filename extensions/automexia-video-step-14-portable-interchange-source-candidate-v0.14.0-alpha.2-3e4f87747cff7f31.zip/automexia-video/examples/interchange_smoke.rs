use automexia_video::*;
use automexia_video::native::{NativeMediaHost,NativeSettings};
use std::path::PathBuf;
fn main()->Result<()> {
    let args:Vec<_>=std::env::args_os().collect();
    if args.len()!=4{return Err(Error::InvalidInput("usage: interchange_smoke PROJECT.amxv OUTPUT.otio|xml|fcpxml|edl RATE"));}
    let project_file=std::fs::canonicalize(&args[1]).map_err(|_|Error::Io("select project"))?;
    let output=PathBuf::from(&args[2]);
    let rate=args[3].to_str().ok_or(Error::InvalidInput("rate UTF-8"))?.parse()?;
    let format=match output.extension().and_then(|s|s.to_str()){Some("otio")=>InterchangeFormat::Otio,Some("xml")=>InterchangeFormat::Fcp7Xml,Some("fcpxml")=>InterchangeFormat::FcpXml,Some("edl")=>InterchangeFormat::Edl,_=>return Err(Error::InvalidInput("export suffix"))};
    let ffmpeg=std::env::var_os("FFMPEG").map(PathBuf::from).ok_or(Error::MissingCapability("FFMPEG absolute approved path"))?;
    let ffprobe=std::env::var_os("FFPROBE").map(PathBuf::from).ok_or(Error::MissingCapability("FFPROBE absolute approved path"))?;
    let x=VideoExtension::new(NativeMediaHost::new(NativeSettings::new(ffmpeg,ffprobe))?,VideoSettings::default())?;
    let cancel=Cancellation::new();let loaded=x.load_project(&project_file,&cancel)?;
    let request=ExportRequest::new(&project_file,&output,format,EditRate::new(rate,false)?);
    let report=x.export_interchange(&loaded.project,&request,&cancel,&mut |_|{})?;
    println!("{}",String::from_utf8(report.to_json()?).map_err(|_|Error::InvalidOutput("result UTF-8"))?);
    if report.exit_code()!=0{std::process::exit(report.exit_code());}Ok(())
}
