//! Generate actual Rust exports for the independent reader to inspect.
//! This is a development fixture, not a replacement end-user video application.
use automexia_video::*;
use automexia_video::native::{NativeMediaHost, NativeSettings};
use std::path::PathBuf;

fn main() -> Result<()> {
    let args: Vec<_> = std::env::args_os().collect();
    if args.len() != 3 {
        return Err(Error::InvalidInput("usage: interchange_fixture SOURCE.mov EXISTING_OUTPUT_DIRECTORY"));
    }
    let input = std::fs::canonicalize(&args[1]).map_err(|_| Error::Io("fixture source"))?;
    let directory = std::fs::canonicalize(&args[2]).map_err(|_| Error::Io("fixture export directory"))?;
    let tool = |name: &str| -> Result<PathBuf> {
        std::env::var_os(name).map(PathBuf::from).ok_or(Error::MissingCapability("FFMPEG and FFPROBE must be explicitly selected"))
    };
    let extension = VideoExtension::new(NativeMediaHost::new(NativeSettings::new(tool("FFMPEG")?, tool("FFPROBE")?))?, VideoSettings::default())?;
    let cancel = Cancellation::new();
    let project_file = directory.join("fixture.amxv");
    let mut project = extension.create_project(&NewProjectRequest::new("interchange-fixture", &input, &project_file), &cancel, &mut |_| {})?;
    project.remove_range("source-1", TimeRange::new("0.5".parse()?, "1".parse()?)?, "Explicit fixture cut")?;
    let rate = EditRate::new("30".parse()?, false)?;
    for format in [InterchangeFormat::Otio, InterchangeFormat::Fcp7Xml, InterchangeFormat::FcpXml, InterchangeFormat::Edl] {
        let mut request = ExportRequest::new(&project_file, directory.join(format!("timeline.{}", format.extension())), format, rate);
        if format == InterchangeFormat::FcpXml { request.target = TargetEditor::FinalCutPro; }
        request.record_start_frames = 108_000;
        request.markers.push(ExportMarker { id: "after".into(), name: "After cut".into(), comment: "Point at source 1.5 seconds".into(), at: "1.5".parse()?, duration: "0".parse()? });
        let outcome = extension.export_interchange(&project, &request, &cancel, &mut |_| {})?;
        if outcome.status != ExportStatus::Published {
            eprintln!("{}", String::from_utf8_lossy(&outcome.to_json()?));
            return Err(Error::InvalidOutput("fixture export was not published and verified"));
        }
    }
    Ok(())
}
