//! Generate actual Rust archives for independent ZIP/manifest/media readers.
//! The qualifier supplies its generated 30fps source, never a user's project.
//! All fixture edits and the optional private bakes are explicit below.
use automexia_video::*;
use automexia_video::native::{NativeMediaHost, NativeSettings};
use std::path::PathBuf;

fn main() -> Result<()> {
    let args: Vec<_> = std::env::args_os().collect();
    if args.len() != 3 {
        return Err(Error::InvalidInput("usage: bundle_fixture GENERATED_SOURCE.mov EXISTING_OUTPUT_DIRECTORY"));
    }
    let input = std::fs::canonicalize(&args[1]).map_err(|_| Error::Io("generated bundle fixture source"))?;
    let directory = std::fs::canonicalize(&args[2]).map_err(|_| Error::Io("bundle fixture directory"))?;
    if !directory.is_dir() { return Err(Error::InvalidInput("bundle fixture output directory")); }
    let tool = |name: &str| -> Result<PathBuf> {
        std::env::var_os(name).map(PathBuf::from)
            .ok_or(Error::MissingCapability("FFMPEG and FFPROBE must be explicitly selected"))
    };
    let extension = VideoExtension::new(
        NativeMediaHost::new(NativeSettings::new(tool("FFMPEG")?, tool("FFPROBE")?))?,
        VideoSettings::default(),
    )?;
    let cancel = Cancellation::new();
    let project_file = directory.join("bundle-fixture.amxv");
    let mut project = extension.create_project(
        &NewProjectRequest::new("bundle-fixture", &input, &project_file), &cancel, &mut |_| {},
    )?;
    project.remove_range("source-1", TimeRange::new("0.5".parse()?, "1".parse()?)?, "Explicit generated-fixture cut")?;
    let rate = EditRate::new("30".parse()?, false)?;
    let cases = [
        ("bundle-source-otio.zip", InterchangeFormat::Otio, BundleVideo::Source, BundleAudio::Source),
        ("bundle-source-fcpxml.zip", InterchangeFormat::FcpXml, BundleVideo::Source, BundleAudio::Source),
        ("bundle-baked-fcpxml.zip", InterchangeFormat::FcpXml, BundleVideo::Bake, BundleAudio::BakeStem),
    ];
    for (name, format, video, audio) in cases {
        let mut request = BundleRequest::new(&project_file, directory.join(name), format, rate);
        request.video = video; request.audio = audio;
        request.name = "Generated portable handoff fixture".into();
        request.record_start_frames = 108_000;
        if format == InterchangeFormat::FcpXml { request.target = TargetEditor::FinalCutPro; }
        request.markers.push(ExportMarker { id: "after".into(), name: "After cut".into(),
            comment: "Point at source 1.5 seconds".into(), at: "1.5".parse()?, duration: "0".parse()? });
        let outcome = extension.export_bundle(&project, &request, &cancel, &mut |_| {})?;
        println!("{}", String::from_utf8_lossy(&outcome.to_json()?));
        if outcome.status != ExportStatus::Published {
            return Err(Error::InvalidOutput("bundle fixture archive was not published and verified"));
        }
    }
    Ok(())
}
