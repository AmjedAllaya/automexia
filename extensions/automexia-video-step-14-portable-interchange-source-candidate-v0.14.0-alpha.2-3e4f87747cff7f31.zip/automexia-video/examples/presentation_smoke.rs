//! Host-side integration smoke example, not a separate end-user application.
//! Uses only explicitly supplied media, font and output directory.
//! FFMPEG/FFPROBE and VIDEO_TEST_FONT point to approved installed files.
use automexia_video::*;
use automexia_video::presentation::*;
use automexia_video::native::{NativeMediaHost,NativeSettings};
use std::path::PathBuf;
fn main()->std::result::Result<(),Box<dyn std::error::Error>> {
    let mut args=std::env::args_os().skip(1);
    let input=std::fs::canonicalize(args.next().ok_or("supply input video and output directory")?)?;
    let output=std::fs::canonicalize(args.next().ok_or("supply an existing output directory")?)?;
    if args.next().is_some(){return Err("unexpected argument".into());}
    let host=NativeMediaHost::new(NativeSettings::new(PathBuf::from(std::env::var_os("FFMPEG").ok_or("set FFMPEG")?),PathBuf::from(std::env::var_os("FFPROBE").ok_or("set FFPROBE")?)))?;
    let video=VideoExtension::new(host,VideoSettings::default())?;let cancel=Cancellation::new();
    let project_file=output.join("presentation.amxv");
    let mut project=video.create_project(&NewProjectRequest::new("presentation-example",&input,&project_file),&cancel,&mut |p|eprintln!("{:?}",p.stage))?;
    let font_path=std::fs::canonicalize(std::env::var_os("VIDEO_TEST_FONT").ok_or("set VIDEO_TEST_FONT to your selected single-face font")?)?;
    let font_input=video.host().inspect_input(&font_path,&cancel)?;
    let family=std::env::var("VIDEO_FONT_FAMILY").map_err(|_|"set VIDEO_FONT_FAMILY to the exact family in that font")?;
    let font=FontRef{asset:AssetRef{path:font_path,size:font_input.stamp.size,sha256:font_input.stamp.sha256},family};
    let mut style=TextStyle::light(font,28);style.padding=8;
    let end=project.sources[0].duration.min(Rational::new(3,1)?);
    let mut presentation=PresentationSettings::default();presentation.overlays.push(Overlay{id:"opening-title".into(),range:TimeRange::new(Rational::new(0,1)?,end)?,content:GraphicContent::Text{text:"Automexia Video".into(),style},placement:Placement{anchor:Anchor::BottomCenter,width:480,height:60,margin:8},animation:Animation{fade_in:Rational::new(1,4)?,fade_out:Rational::new(1,4)?,..Default::default()},enabled:true});
    project.set_presentation("main",Some(presentation))?;
    // This example records an explicit operator choice. A real host uses review.
    project.review_presentation("main",Disposition::AutoApply,true)?;
    video.save_project(&project,&project_file,&OutputPolicy::CreateNew,&cancel)?;
    let result=video.render_project(&project,&ProjectRenderRequest::new(&project_file,output.join("presentation.mp4")),&cancel,&mut |p|eprintln!("{:?}",p.stage))?;
    println!("{}",serde_json::to_string_pretty(&result)?);Ok(())
}
