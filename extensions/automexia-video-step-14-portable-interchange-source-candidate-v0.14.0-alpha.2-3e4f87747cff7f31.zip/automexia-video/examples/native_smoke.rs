//! Build/use demonstration of the extension core, NOT an alternative editor UI.
//! cargo run --features native --example native_smoke -- INPUT OUTPUT FFMPEG FFPROBE
use automexia_video::{Cancellation,RenderRequest,VideoExtension,VideoSettings};
use automexia_video::native::{NativeMediaHost,NativeSettings};
use std::{env,path::PathBuf};

fn main()->Result<(),Box<dyn std::error::Error>>{
    let args:Vec<_>=env::args_os().skip(1).collect();
    if args.len()!=4 {
        eprintln!("Usage: native_smoke INPUT OUTPUT.mp4 /absolute/ffmpeg /absolute/ffprobe");
        std::process::exit(2);
    }
    let host=NativeMediaHost::new(NativeSettings::new(PathBuf::from(&args[2]),PathBuf::from(&args[3])))?;
    let video=VideoExtension::new(host,VideoSettings::default())?;
    let request=RenderRequest::new(PathBuf::from(&args[0]),PathBuf::from(&args[1]));
    let result=video.render_unedited(&request,&Cancellation::new(),&mut |event|{
        eprintln!("{:?}: time_us={:?} frame={:?}",event.stage,event.out_time_us,event.frame);
    })?;
    println!("{}",serde_json::to_string_pretty(&result)?);
    Ok(())
}
