//! Existing-host integration example, not a new extension loader or player.
//! The default only analyzes; --save-review explicitly saves pending decisions.
use automexia_video::*;
use automexia_video::native::{NativeMediaHost,NativeSettings};
use std::path::PathBuf;
fn main()->Result<()> {
    let args:Vec<_>=std::env::args_os().skip(1).collect();
    if args.len()<2 || args.len()>3 || args.len()==3&&args[2]!="--save-review" {
        return Err(Error::InvalidInput("supply input and absolute .amxv path; optional --save-review"));
    }
    let input=std::fs::canonicalize(PathBuf::from(&args[0])).map_err(|_|Error::Io("resolve input"))?;
    let path=PathBuf::from(&args[1]);
    let tool=|name:&str,fallback:&str|std::env::var_os(name).map(PathBuf::from).unwrap_or_else(||fallback.into());
    let core=VideoExtension::new(NativeMediaHost::new(NativeSettings::new(tool("FFMPEG","/usr/bin/ffmpeg"),tool("FFPROBE","/usr/bin/ffprobe")))?,VideoSettings::default())?;
    let cancel=Cancellation::new();
    let mut project=core.create_project(&NewProjectRequest::new("color-example",&input,&path),&cancel,&mut |_|{})?;
    let report=core.analyze_color(&project,&ColorAnalysisRequest::new(&path),&cancel,&mut |_|{})?;
    println!("{}",serde_json::to_string_pretty(&report).map_err(|_|Error::InvalidOutput("color report serialization"))?);
    if args.len()==3 {
        report.apply(&mut project)?;
        core.save_project(&project,&path,&OutputPolicy::CreateNew,&cancel)?;
        // The user's existing review UI invokes decide_color / ReviewCommand
        // for EACH shot. This example deliberately does not auto-approve them.
        println!("Saved for review; no delivery video has been rendered.");
    }
    Ok(())
}
