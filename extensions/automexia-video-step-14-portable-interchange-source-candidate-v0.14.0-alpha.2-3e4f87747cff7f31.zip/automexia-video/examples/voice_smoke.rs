//! Integration smoke example, not a new standalone editor/loader.
//! First invocation only analyzes. Explicit --apply renders the chosen settings.
use automexia_video::*;
use automexia_video::native::{NativeMediaHost,NativeSettings};
use std::path::PathBuf;
fn main()->Result<()> {
    let args:Vec<_>=std::env::args_os().skip(1).collect();
    if args.len()<2||args.len()>3||args.len()==3&&args[2]!="--apply" {return Err(Error::InvalidInput("supply input and absolute .amxv path; optional --apply"));}
    let input=std::fs::canonicalize(PathBuf::from(&args[0])).map_err(|_|Error::Io("resolve sample input"))?;
    let path=PathBuf::from(&args[1]);
    let ffmpeg=std::env::var_os("FFMPEG").map(PathBuf::from).unwrap_or_else(||"/usr/bin/ffmpeg".into());
    let ffprobe=std::env::var_os("FFPROBE").map(PathBuf::from).unwrap_or_else(||"/usr/bin/ffprobe".into());
    let core=VideoExtension::new(NativeMediaHost::new(NativeSettings::new(ffmpeg,ffprobe))?,VideoSettings::default())?;
    let c=Cancellation::new();let mut project=core.create_project(&NewProjectRequest::new("voice-example",&input,&path),&c,&mut |_|{})?;
    let mut request=VoiceAnalysisRequest::new(&path);
    // This example is for an explicitly selected dialogue track. The product's
    // default is Unknown; it must not guess dialogue from a filename.
    request.settings.content=AudioContent::Dialogue;
    let report=core.analyze_voice(&project,&request,&c,&mut |_|{})?;
    println!("{}",serde_json::to_string_pretty(&report).map_err(|_|Error::InvalidInput("report serialization"))?);
    if args.len()==3 {
        report.apply(&mut project)?;core.save_project(&project,&path,&OutputPolicy::CreateNew,&c)?;
        let result=core.render_project(&project,&ProjectRenderRequest::new(&path,path.with_extension("mp4")),&c,&mut |_|{})?;
        println!("{}",serde_json::to_string_pretty(&result.audio).map_err(|_|Error::InvalidInput("result serialization"))?);
        core.export_audio_stem(&project,&AudioStemRequest::new(&path,path.with_extension("wav")),&c,&mut |_|{})?;
    }
    Ok(())
}
